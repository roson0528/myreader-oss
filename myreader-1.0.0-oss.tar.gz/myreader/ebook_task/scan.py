#!/usr/bin/env python3
# Full SFTP recursive scan of /books -> state/manifest.json
import paramiko, json, os, time, sys

# 连接信息走环境变量（与 book_manager/config.py 同一套变量）
HOST = os.environ.get("BOOKMGR_FTP_HOST", "127.0.0.1")
PORT = int(os.environ.get("BOOKMGR_SFTP_PORT", "22"))
USER = os.environ.get("BOOKMGR_FTP_USER", "bookadmin")
PWD = os.environ.get("BOOKMGR_FTP_PASS", "")
BASE = os.environ.get("BOOKMGR_FTP_BASE", "/books")
W = os.path.dirname(os.path.abspath(__file__))


def conn():
    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    c.connect(HOST, port=PORT, username=USER, password=PWD, timeout=30,
              allow_agent=False, look_for_keys=False)
    return c


def scan(c):
    s = c.open_sftp()
    files = []
    dirs = []
    errors = []

    def walk(path, rel, depth):
        try:
            entries = s.listdir_attr(path)
        except Exception as e:
            errors.append((rel, str(e)))
            return
        for e in entries:
            if e.filename in ('.', '..'):
                continue
            r = rel + '/' + e.filename if rel else e.filename
            isdir = bool(e.st_mode & 0o040000) if e.st_mode else False
            if isdir:
                dirs.append(r)
                if depth < 25:
                    walk(path + '/' + e.filename, r, depth + 1)
            else:
                files.append({'path': r, 'size': e.st_size})

    t0 = time.time()
    walk(BASE, '', 1)
    print("scan took %.1fs" % (time.time() - t0), file=sys.stderr)
    return files, dirs, errors


c = conn()
files, dirs, errors = scan(c)
c.close()
data = {'base': BASE, 'files': files, 'dirs': dirs, 'errors': errors,
        'ts': time.time()}
json.dump(data, open(W + '/state/manifest.json', 'w'), ensure_ascii=False)
print("files:", len(files), "dirs:", len(dirs), "errors:", len(errors))
for r, e in errors[:20]:
    print("ERR", r, e)
tot = sum(f['size'] for f in files)
print("total bytes %.1f GB" % (tot / 1e9))
