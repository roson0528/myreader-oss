# -*- coding: utf-8 -*-
"""认证与权限：密码散列、JWT、角色"""
import hashlib, os, time
import jwt
from fastapi import Depends, HTTPException, Header
import config, db

ROLE_ADMIN = "admin"
ROLE_USER = "user"

# 游客（未登录）用户：仅可浏览 / 试读范例图书，其余接口一律 401/403
GUEST_USER = {"id": 0, "username": "guest", "role": "guest", "enabled": 1,
              "permissions": {}, "name": "", "email": "", "phone": "",
              "group_id": None, "owner_id": None}


# ---------------- 分享在线阅读券（§14.113）----------------
# 分享页点「在线阅读」时给未登录访客发一张短期券：只能读券里指定的那一本书，
# 与登录令牌互不通用（载荷 typ=share）。拿券的人也仍然是游客身份 ——
# 进度、书签、笔记这些需要账号的功能天然不会落库。
SHARE_TICKET_TTL = 6 * 3600        # 6 小时，够读完一本书


def share_guest(book_id):
    """分享读者的“用户”身份：游客 + 券里那本书的只读权限"""
    u = dict(GUEST_USER)
    u["_share_bid"] = int(book_id or 0)
    return u


def create_share_ticket(share_id, book_id, ttl=SHARE_TICKET_TTL):
    payload = {"typ": "share", "sid": int(share_id), "bid": int(book_id),
               "exp": int(time.time()) + int(ttl)}
    return jwt.encode(payload, config.JWT_SECRET, algorithm=config.JWT_ALG)


def decode_share_ticket(tok):
    try:
        p = jwt.decode(tok, config.JWT_SECRET, algorithms=[config.JWT_ALG])
    except Exception:
        return None
    if not p or p.get("typ") != "share" or not p.get("bid"):
        return None
    return p


def hash_password(pw: str) -> str:
    salt = os.urandom(16)
    dk = hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"), salt, 120000)
    return salt.hex() + "$" + dk.hex()


def verify_password(pw: str, stored: str) -> bool:
    try:
        salt_hex, dk_hex = stored.split("$")
        dk = hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"), bytes.fromhex(salt_hex), 120000)
        return dk.hex() == dk_hex
    except Exception:
        return False


def create_token(user):
    payload = {"uid": user["id"], "username": user["username"],
               "role": user["role"], "exp": int(time.time()) + config.TOKEN_TTL}
    return jwt.encode(payload, config.JWT_SECRET, algorithm=config.JWT_ALG)


def decode_token(token: str):
    try:
        return jwt.decode(token, config.JWT_SECRET, algorithms=[config.JWT_ALG])
    except Exception:
        return None


def get_optional_user(authorization: str = Header(default="")):
    """未登录（无 Authorization 头）→ 返回游客用户（仅可见/可读范例图书）；
    携带无效 token → 401；有效 token → 返回真实用户"""
    if authorization.startswith("Share "):        # 分享在线阅读券（§14.113）
        p = decode_share_ticket(authorization[6:].strip())
        if not p:
            raise HTTPException(401, "阅读链接已失效，请回到分享页重新打开")
        return share_guest(p["bid"])
    if not authorization.startswith("Bearer "):
        return GUEST_USER
    token = authorization[7:]
    payload = decode_token(token)
    if not payload:
        raise HTTPException(401, "登录已过期，请重新登录")
    user = db.q("SELECT * FROM users WHERE id=?", (payload["uid"],), one=True)
    if not user or not user["enabled"]:
        raise HTTPException(401, "账号不存在或已禁用")
    return user


def get_current_user(authorization: str = Header(default="")):
    u = get_optional_user(authorization)
    if u["id"] == 0:
        raise HTTPException(401, "未登录")
    _sweep_upgrades()
    return u


# 分组兑换到期回退：每个请求入口做节流扫描（默认 60 秒一次），
# 保证兑换到期后权限不会被长期占用，同时不给正常请求带来明显开销。
_SWEEP_INTERVAL = 60
_last_sweep = [0.0]


def _sweep_upgrades():
    now = time.time()
    if now - _last_sweep[0] < _SWEEP_INTERVAL:
        return
    _last_sweep[0] = now
    try:
        db.expire_group_upgrades()
    except Exception:
        pass   # 扫描失败不影响正常请求


def require_admin(user=Depends(get_current_user)):
    if user["role"] != ROLE_ADMIN:
        raise HTTPException(403, "需要管理员权限")
    return user


def can_manage_book(user, book):
    """用户能否管理(增删改)这本书：管理员可管理全部；普通用户仅管理自己上传的书"""
    if user["role"] == ROLE_ADMIN:
        return True
    return book and book["owner_id"] == user["id"]


# 免审批分组：这个分组的用户（总编）发布书单、共享书籍等**不需要管理员审批**，直接通过。
# 注意这是「分组」而不是「角色」—— role 只有 admin/user 两种，总编是 user_groups 里
# code='writer' 的那个分组（历史上叫「作家」，更名迁移过，所以**按 code 判断，别按名字**）。
TRUSTED_GROUP_CODE = "writer"


def is_trusted(user):
    """管理员，或总编分组的用户 —— 需要审批的「发布」操作对他们直接放行。

    为什么用分组而不是权限位：书单/共享的审批判断原本写死的是 `user["role"] == "admin"`，
    而总编这个身份在 role 里根本表达不出来（role 只有 admin/user）。用户要的是
    「管理员和总编不用审批」，所以这里把身份统一成一个判断，供各发布入口复用。

    ★ 只影响「发布是否需要审批」，**不授予任何管理权限**：
      能不能审核别人的、能不能改别人的书单，仍然走 require_admin / 作者本人判断。
    """
    if not user:
        return False
    try:
        if user["role"] == ROLE_ADMIN:
            return True
    except Exception:
        return False
    try:
        g = group_of(user)
        if g and (g["code"] or "") == TRUSTED_GROUP_CODE:
            return True
    except Exception:
        pass
    return False


# 可赋权的权限位（由用户所在分组决定）
PERMS = ("share", "edit", "cover", "download", "delete", "private_shelf", "convert", "listen", "public_library", "publish_booklist")


def group_of(user):
    """返回用户所在分组；未分组时按角色兜底（admin→管理员组，其余→会员(guest)组）"""
    try:
        gid = user["group_id"]
    except Exception:
        gid = None
    if gid:
        g = db.get_group(gid)
        if g:
            return g
    code = ROLE_ADMIN if user["role"] == ROLE_ADMIN else "guest"
    return db.group_by_code(code)


def limits_of(user):
    """返回用户所属分组的限额（0=不限）"""
    g = group_of(user)
    if g is None:
        return {"share_max_days": 0, "share_max_links": 0,
                "download_monthly_limit": 0, "listen_monthly_limit": 0,
                "shelf_limit": 0, "convert_daily_limit": 0, "upload_max_mb": 0}
    return {
        "share_max_days": int(g["share_max_days"] or 0),
        "share_max_links": int(g["share_max_links"] or 0),
        "download_monthly_limit": int(g["download_monthly_limit"] or 0),
        "listen_monthly_limit": int(g["listen_monthly_limit"] or 0),
        "shelf_limit": int(g["shelf_limit"] or 0),
        "convert_daily_limit": int(g["convert_daily_limit"] or 0),
        "upload_max_mb": int(g["upload_max_mb"] or 0),
    }


def can(user, perm):
    """检查某项权限：管理员恒通过；普通用户看所属分组的 can_<perm> 开关"""
    if user["role"] == ROLE_ADMIN:
        return True
    g = group_of(user)
    if not g:
        return False
    try:
        return bool(g["can_" + perm])
    except (KeyError, IndexError):
        return False


def visible_where(user, alias="b"):
    """返回书籍可见性过滤 SQL 片段：管理员见全部（含已下架）；普通用户视「公共书库」权限见公共书 + 自己上传的书 + 站内分享给自己的书，且排除已下架；游客仅见范例图书"""
    if user["role"] == ROLE_ADMIN:
        return "", []
    if user["id"] == 0:  # 游客：仅访客推荐书籍
        return (f"({alias}.guest_featured = 1 AND COALESCE({alias}.hidden, 0) = 0)"), []
    grant_sql = f"{alias}.id IN (SELECT book_id FROM book_grants WHERE to_user_id = ?)"
    if can(user, "public_library"):
        return (f"(({alias}.owner_id IS NULL OR {alias}.owner_id = ? OR {grant_sql}) "
                f"AND COALESCE({alias}.hidden, 0) = 0)"), [user["id"], user["id"]]
    return (f"(({alias}.owner_id = ? OR {grant_sql}) AND COALESCE({alias}.hidden, 0) = 0)"), [user["id"], user["id"]]


def can_access_book(user, book):
    """用户能否访问(读)这本书：管理员见全部；普通用户按「公共书库」权限见公共书，始终可见自己上传的书与站内分享给自己的书，且不可访问已下架书；游客仅可读范例图书"""
    if user["role"] == ROLE_ADMIN:
        return True
    # 分享在线阅读券：只放行券里指定的那一本（下架书不放行）
    try:
        sb = int(user["_share_bid"] or 0)
    except (KeyError, IndexError, TypeError):
        sb = 0
    if sb:
        return book is not None and not book["hidden"] and int(book["id"]) == sb
    if user["id"] == 0:  # 游客：仅访客推荐书籍
        return book is not None and bool(book["guest_featured"]) and not book["hidden"]
    if book is None or book["hidden"]:
        return False
    if book["owner_id"] is None:
        return can(user, "public_library")
    if book["owner_id"] == user["id"]:
        return True
    return bool(db.q("SELECT id FROM book_grants WHERE book_id=? AND to_user_id=?",
                     (book["id"], user["id"]), one=True))


def user_public(user):
    """返回给前端的用户信息（含分组、权限位、限额）"""
    g = group_of(user)
    return {
        "id": user["id"], "username": user["username"], "role": user["role"],
        "name": user["name"] or "", "email": user["email"] or "", "phone": user["phone"] or "",
        "quota": user["quota"], "enabled": bool(user["enabled"]),
        "group": {"id": g["id"], "code": g["code"], "name": g["name"]} if g else None,
        "permissions": {p: can(user, p) for p in PERMS},
        "limits": limits_of(user),
        # 免审批身份（管理员 / 总编）。前端据此调整「发表后需管理员审核」这类提示文案，
        # 判据只在这里写一份，免得前后端两边各写一套判断而走偏。
        "trusted": is_trusted(user),
    }
