# -*- coding: utf-8 -*-
"""站内消息 + Server酱推送（Server酱³ / sctapi.ftqq.com）。

设计要点：
- 所有通知统一走本模块的 notify_admins / notify_user，站内消息**一定**写入 SQLite
  （网页与 App 都能看到、并驱动「我的」红点）。
- Server酱推送在**后台线程**发出：既不阻塞业务请求，任何异常也被吞掉，
  推送失败绝不影响审核、分享等主流程。
- 管理员通知（共享审核 / 书单审核 / 举报处理）在站内消息之外**同时**推送 Server酱；
  会员通知只做站内消息（按需求约定）。
"""
import contextvars
import json
import os
import sys
import threading
import urllib.parse
import urllib.request

import db

# 本次请求是否禁止真推。用 contextvar 而不是全局变量：服务端是并发的，
# 全局变量会把「测试请求」的影响溅到同时进行的真实请求上。
_no_push = contextvars.ContextVar("bm_no_push", default=False)


def set_no_push(v):
    """只对**当前请求**生效；由 app.py 的中间件按 X-BM-No-Push 头设置。"""
    _no_push.set(bool(v))

# 默认 Server酱 Key（可在后台「系统配置」用 serverchan_key 覆盖）
DEFAULT_SERVERCHAN_KEY = "SCT347708Ts2GqSaEzbc2E2cQ2mw28E36u"
SERVERCHAN_API = "https://sctapi.ftqq.com/{key}.send"


def serverchan_key():
    return (db.get_config("serverchan_key", "") or DEFAULT_SERVERCHAN_KEY).strip()


def serverchan_enabled():
    return db.get_config("serverchan_enabled", "1") == "1"


def push_suppressed():
    """现在是不是**绝对不能真推**的状态？

    ★ 为什么需要这个开关（2026-10-09 事故）：
      回归测试会建真的测试账号、真的发共享申请/书单，那条路会走到
      notify_admins -> push_async，于是**每跑一次测试就给管理员手机
      推一条真通知**。审计日志里能查到 16 次共享申请 + 8 次书单发表
      都是 zzt_sim_* / zzam_pub_* 这些测试账号触发的 —— 管理员收到
      一堆「不相关的推送」，根因就在这里。

    ★ 为什么用「自动识别测试脚本」而不是只留一个环境变量：
      环境变量要靠每个测试自己记得设置，新加的测试一定会忘。
      这里按入口脚本判断，谁都不用记 —— 忘不掉。

    ★ 为什么不会误伤线上：bookmgr.service 的 ExecStart 是
      `python -m uvicorn app:app`，入口不是 tests/ 下的脚本，
      也不以 test_ 开头，所以线上推送行为完全不变。
    """
    if _no_push.get():
        return True
    v = (os.environ.get("BM_NO_SERVERCHAN") or "").strip()
    if v in ("1", "true", "on", "yes"):
        return True
    if v in ("0", "false", "off", "no"):
        return False                      # 显式要求真发（调试推送时用）
    try:
        a = os.path.abspath(sys.argv[0] or "")
    except Exception:
        return False
    base = os.path.basename(a)
    if base.startswith("test_") or base.startswith("verify_"):
        return True
    return (os.sep + "tests" + os.sep) in (a + os.sep)


def _serverchan_post(key, title, desp):
    data = urllib.parse.urlencode({"title": (title or "")[:100], "desp": desp or ""}).encode("utf-8")
    req = urllib.request.Request(SERVERCHAN_API.format(key=key), data=data,
                                 headers={"Content-Type": "application/x-www-form-urlencoded"})
    try:
        with urllib.request.urlopen(req, timeout=12) as r:
            body = r.read().decode("utf-8", "replace")
        j = json.loads(body)
        return {"ok": j.get("code") == 0,
                "error": (j.get("data") or {}).get("error") or j.get("message") or ""}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def push_async(title, desp=""):
    """后台线程推送 Server酱；未开启或失败都静默（失败写入审计日志便于排查）"""
    if push_suppressed():
        # ★ 测试期绝不真推，也不写审计（否则每次测试都刷一条，更难查）
        return False
    if not serverchan_enabled():
        return False
    key = serverchan_key()
    if not key:
        return False

    def run():
        try:
            r = _serverchan_post(key, title, desp)
            if not r.get("ok"):
                db.log_audit(None, "serverchan_fail", "system", None,
                             f"Server酱推送失败：{r.get('error')}")
        except Exception:
            pass

    threading.Thread(target=run, daemon=True).start()
    return True


def push_now(title, desp=""):
    """同步推送（仅用于后台「测试推送」按钮，便于把错误直接回显）"""
    if push_suppressed():
        return {"ok": False, "error": "当前处于测试环境，已阻止真实推送（BM_NO_SERVERCHAN=1 或入口是测试脚本）"}
    key = serverchan_key()
    if not key:
        return {"ok": False, "error": "未配置 Server酱 Key"}
    return _serverchan_post(key, title, desp)


def _fmt(body, lines):
    parts = [body or ""]
    for k, v in lines:
        if v:
            parts.append(f"{k}：{v}")
    return "\n\n".join(p for p in parts if p)


def notify_admins(title, body="", kind="review", link="", ref_type=None, ref_id=None,
                  push=True, extra=None):
    """通知全体启用的管理员：站内消息（全部）+ Server酱（一条）"""
    ids = db.admin_ids()
    for uid in ids:
        db.add_message(uid, title, body, kind=kind, link=link, ref_type=ref_type, ref_id=ref_id)
    if push and ids:
        desc = _fmt(body, (extra or []))
        push_async("【云阅读】" + title, desc)
    return len(ids)


def notify_user(to_id, title, body="", kind="system", from_id=None, link="",
                ref_type=None, ref_id=None, push=False, extra=None):
    """通知单个会员：站内消息（+ 可选 Server酱）"""
    if not to_id:
        return 0
    db.add_message(to_id, title, body, kind=kind, from_id=from_id, link=link,
                   ref_type=ref_type, ref_id=ref_id)
    if push:
        push_async("【云阅读】" + title, _fmt(body, (extra or [])))
    return 1
