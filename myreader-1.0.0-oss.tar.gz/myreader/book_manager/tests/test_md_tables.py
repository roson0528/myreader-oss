# -*- coding: utf-8 -*-
"""Markdown 表格在阅读页（尤其手机端）的排版回归测试。

背景（站长报的问题）：手机上看 md 文档，表格显示混乱。两个原因叠在一起：

  ① 表格比屏幕宽时没有滚动容器 —— 分页模式是 CSS 多栏布局，宽表格会直接
     压到相邻一栏，和正文重叠；滚动模式下则撑破版面、把整页顶出屏幕。
  ② 单元格内边距按桌面尺寸给（5px 10px），窄屏 4 列以上就挤成一团；
     长英文/链接不换行，进一步把表格撑宽。

修法：后端渲染不变（python-markdown 的 tables 扩展），前端给每个 `<table>`
套一层 `.md-tw` 容器（`reader.js: mdWrapTables`），容器负责横向滚动与
`break-inside: avoid`；`reader.html` 里补单元格换行、行不断裂、手机端
（≤520px）字号与内边距收敛。

本测试**不联网、只读**：纯函数 + 静态检查，另用真实 md 书渲染一遍比对。
"""
import io
import os
import re
import shutil
import subprocess
import sys
import tempfile
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
os.chdir(_ROOT)
import reader  # noqa: E402

PASS = [0]
FAIL = []


def ok(name, cond, extra=''):
    if cond:
        PASS[0] += 1
        print('  [ok] ' + name)
    else:
        FAIL.append(name + ((' — ' + extra) if extra else ''))
        print('  [FAIL] ' + name + ((' — ' + extra) if extra else ''))


MD_SAMPLE = """# 标题

| 书目 | 作者 | 分类 | 出版年 | 价格（元） | 备注 |
|---|---|---|---|---|---|
| 云阅读使用手册 | 站点管理员 | 工具 | 2026 | 0.00 | 一段比较长的说明文字 |
| 深入理解计算机系统 | Randal E. Bryant | 计算机 | 2016 | 139.00 | 厚 |

| 项目 | 数量 |
|---|---|
| 章节 | 12 |
"""


def main():
    print('=== 一、服务端 Markdown 渲染 ===')
    html = reader.md_to_html(MD_SAMPLE)
    ok('表格渲染成 <table>', '<table>' in html)
    ok('表头带 <thead>/<th>', '<thead>' in html and '<th>' in html)
    ok('一章两张表都保留', html.count('<table') == 2, '实际 %d' % html.count('<table'))
    ok('单元格里没有多余的 <br>（nl2br 不该污染表格）',
       not re.search(r'<td>[^<]*<br', html), '出现了 <br>')

    print('=== 二、前端包表逻辑（reader.js: mdWrapTables）===')
    js = io.open('static/reader.js', encoding='utf-8').read()
    ok('contentHtml 走 mdWrapTables', 'MD ? mdWrapTables(text)' in js)
    ok('有幂等保护，不会叠套', 'class="md-tw"' in js)

    node = shutil.which('node')
    if node:
        script = r'''
const fs = require('fs'), vm = require('vm');
const src = fs.readFileSync('static/reader.js', 'utf8');
const i = src.indexOf('function mdWrapTables(html) {');
if (i < 0) { console.log('NOT_FOUND'); process.exit(0); }
let d = 1, j = i + 'function mdWrapTables(html) {'.length;
for (; j < src.length; j++) { if (src[j] === '{') d++; else if (src[j] === '}') { d--; if (!d) break; } }
const ctx = {}; vm.createContext(ctx);
vm.runInContext(src.slice(i, j + 1), ctx);
const one = ctx.mdWrapTables('<table><tr><td>1</td></tr></table>');
const two = ctx.mdWrapTables(one);
const html = fs.readFileSync('/tmp/_md_tables_sample.html', 'utf8');
const real = ctx.mdWrapTables(html);
console.log(JSON.stringify({
  single: (one.match(/md-tw/g) || []).length,
  idempotent: (two.match(/md-tw/g) || []).length,
  real_tables: (real.match(/<table/g) || []).length,
  real_wrapped: (real.match(/class="md-tw"/g) || []).length,
  unchanged_when_none: ctx.mdWrapTables('<p>纯文字</p>') === '<p>纯文字</p>'
}));
'''
        with tempfile.NamedTemporaryFile('w', suffix='.js', delete=False,
                                         dir='/tmp', encoding='utf-8') as fh:
            fh.write(script)
            js_path = fh.name
        io.open('/tmp/_md_tables_sample.html', 'w', encoding='utf-8').write(html)
        try:
            out = subprocess.run([node, js_path], capture_output=True, text=True, timeout=60)
            raw = (out.stdout or '').strip().splitlines()
            if raw and raw[-1].startswith('{'):
                import json
                d = json.loads(raw[-1])
                ok('单张表包一层', d['single'] == 1, str(d))
                ok('重复处理不叠套', d['idempotent'] == 1, str(d))
                ok('真实章节两张表全部包好',
                   d['real_tables'] == 2 and d['real_wrapped'] == d['real_tables'], str(d))
                ok('没有表格时原样返回', d['unchanged_when_none'], str(d))
            else:
                ok('node 跑通包表逻辑', False, (out.stderr or out.stdout)[:200])
        finally:
            for p in (js_path, '/tmp/_md_tables_sample.html'):
                try:
                    os.unlink(p)
                except OSError:
                    pass
    else:
        print('  [skip] 没有 node，跳过 JS 行为测试（静态检查已覆盖关键点）')

    print('=== 三、样式（reader.html）===')
    css = io.open('static/reader.html', encoding='utf-8').read()
    ok('.md-tw 容器可横向滚动', re.search(r'\.md-tw\s*\{[^}]*overflow-x:\s*auto', css, re.S))
    ok('.md-tw 不被跨栏切断', re.search(r'\.md-tw\s*\{[^}]*break-inside:\s*avoid', css, re.S))
    ok('表格不再被 max-width 压变形',
       re.search(r'#txt-content\.md table\s*\{[^}]*max-width:\s*none', css))
    ok('单元格允许长串换行',
       re.search(r'#txt-content\.md td\s*\{[^}]*overflow-wrap', css, re.S))
    ok('行不跨栏断裂', re.search(r'#txt-content\.md tr\s*\{[^}]*break-inside:\s*avoid', css))
    ok('手机端媒体查询存在', re.search(r'@media \(max-width: 520px\)', css))
    ok('手机端缩小单元格内边距',
       re.search(r'@media \(max-width: 520px\)[\s\S]*?#txt-content\.md td\s*\{[^}]*padding:\s*3px', css))

    print('=== 四、手势不会和表格滚动打架（reader.js）===')
    ok('横向拖动可滚动表格时不翻页', 'scrollWidth > tw.clientWidth' in js and
       "closest('.md-tw')" in js)
    ok('点可滚动表格不翻页', js.count("closest('.md-tw')") >= 2)

    print()
    if FAIL:
        print('md 表格排版回归测试：%d 通过 / %d 失败' % (PASS[0], len(FAIL)))
        for f in FAIL:
            print('  失败：' + f)
        return 1
    print('md 表格排版回归测试：%d 通过 / 0 失败' % PASS[0])
    return 0


if __name__ == '__main__':
    sys.exit(main())
