# -*- coding: utf-8 -*-
"""把「读请求体」这一步单独做成异步依赖，让路由能改成同步函数。

背景：FastAPI 对 async def 路由是在**事件循环线程**上直接执行的。本项目大量路由
（reading_heartbeat / save_progress / listen_* / booklist_* 等）写成了 async def，
但内部其实全是同步的 SQLite 读写和文件 IO。一旦某次写入撞上库锁，SQLite 的 busy
handler 会用 nanosleep 退避等待，这段时间**整个事件循环都被占住** —— 所有请求
（连静态文件）全部无响应，内核连接队列堆积，表现为「网站打不开」。

把路由改成同步 def 后，FastAPI 会自动用线程池执行（Starlette 默认 40 个工作线程），
阻塞只影响那一个线程，事件循环始终能 accept 新连接。

唯一必须留在异步侧的只有读请求体，所以这里做成依赖：它照旧在事件循环上
await request.json()，把结果提前交给后面的同步函数。两个版本对应原来两种写法，
语义与改造前逐字保持：
  - json_body          <=> body = await request.json()        （失败即抛错）
  - json_body_or_empty <=> try: body = await request.json()
                           except Exception: body = {}        （失败退化为空字典）
"""
from fastapi import Request


async def json_body(request: Request):
    """等价于 await request.json()：空 body、非法 JSON 都照旧抛错。"""
    return await request.json()


async def json_body_or_empty(request: Request):
    """等价于 try/except 包起来的读法：任何异常都退化为空字典。"""
    try:
        return await request.json()
    except Exception:
        return {}
