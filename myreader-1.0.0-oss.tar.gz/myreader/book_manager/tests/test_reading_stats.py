#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""reading_stats 回归测试（§14.112）

用本地临时目录替代 WebDAV 后端（只替换 _read_json/_write_json 两个 I/O 点），
验证：日明细结构、会话判定、落盘幂等、日→周/月汇总、书籍维度人数/次数、多用户去重。
跑法：venv/bin/python tests/test_reading_stats.py
"""
import os
import sys
import json
import time
import shutil
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))

import reading_stats as rs

_ok = _fail = 0


def ok(cond, msg):
    global _ok, _fail
    if cond:
        _ok += 1
        print("  ✓ " + msg)
    else:
        _fail += 1
        print("  ✗ " + msg)


# ---------------- 本地目录替代 WebDAV ----------------
TMP = tempfile.mkdtemp(prefix="rstats_")


def _local_read(path):
    p = os.path.join(TMP, path)
    if not os.path.isfile(p):
        return None
    try:
        with open(p, encoding="utf-8") as fh:
            d = json.load(fh)
        return d if isinstance(d, dict) else None
    except Exception:
        return None


def _local_write(path, doc):
    p = os.path.join(TMP, path)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8") as fh:
        json.dump(doc, fh, ensure_ascii=False, indent=1)
    return True


def _local_delete(path):
    p = os.path.join(TMP, path)
    if os.path.isfile(p):
        os.remove(p)
        return True
    return False


rs._read_json = _local_read
rs._write_json = _local_write
rs.ftp_service.delete = _local_delete
rs.log = lambda m: None


def _reset(day="2026-10-27"):
    """清空内存与目录，并把“今天”固定到指定日期"""
    with rs._lock:
        rs._pending.clear()
        rs._last_seen.clear()
        rs._day_cache.clear()
    for n in os.listdir(TMP):
        p = os.path.join(TMP, n)
        shutil.rmtree(p) if os.path.isdir(p) else os.remove(p)
    rs.today = lambda: day
    rs._hour = lambda: 21


def main():
    # ---- 1. 日明细结构 ----
    _reset()
    rs.record(15, 498607, 30, "md", "测试报告")
    rs.record(15, 498607, 30, "md", "测试报告")
    n = rs.flush()
    day = _local_read(rs.day_path("2026-10-27"))
    u = (day or {}).get("users", {}).get("15", {})
    b = (day or {}).get("books", {}).get("498607", {})
    ok(n == 1 and u.get("sec") == 60, "落盘 1 天，用户当天时长 60 秒")
    ok(u.get("hours", {}).get("21") == 60, "时段分布记到 21 点")
    ok(u.get("books", {}).get("498607", {}).get("sec") == 60
       and u["books"]["498607"]["title"] == "测试报告", "用户×书籍明细带书名")
    ok(u.get("opens") == 1 and b.get("opens") == 1, "连续心跳只算 1 次开读")
    ok(b.get("readers") == [15] and b.get("sec") == 60, "书籍维度：读者 1 人、60 秒")

    # ---- 2. 重复落盘不重复计数 ----
    n2 = rs.flush()
    day2 = _local_read(rs.day_path("2026-10-27"))
    ok(n2 == 0 and day2["users"]["15"]["sec"] == 60, "无新数据时再落盘不改变内容（幂等）")

    # ---- 3. 会话判定：隔 30 分钟以上算新开读 ----
    rs._last_seen[(15, 498607)] = time.time() - 3600
    rs.record(15, 498607, 30, "md", "测试报告")
    rs.flush()
    day3 = _local_read(rs.day_path("2026-10-27"))
    ok(day3["users"]["15"]["opens"] == 2 and day3["books"]["498607"]["opens"] == 2,
       "间隔 1 小时后再读 → 开读次数 +1")

    # ---- 4. 多用户读同一本书 ----
    rs.record(16, 498607, 60, "md", "测试报告")
    rs.flush()
    day4 = _local_read(rs.day_path("2026-10-27"))
    ok(sorted(day4["books"]["498607"]["readers"]) == [15, 16]
       and day4["books"]["498607"]["sec"] == 150, "两个用户读同一本书：读者 2 人、时长累加")

    # ---- 5. 无 book_id 也记（只记总时长） ----
    rs.record(17, 0, 30, "", "")
    rs.flush()
    day5 = _local_read(rs.day_path("2026-10-27"))
    ok(day5["users"]["17"]["sec"] == 30 and not day5["users"]["17"]["books"],
       "旧客户端不带 book_id：只记用户时长，不产生书籍条目")

    # ---- 6. 汇总：用户年度文件（日/周/月/时段/书单/连续天数） ----
    u1, b1 = rs.rollup_day("2026-10-27")
    uf = _local_read(rs.user_path(15, "2026"))
    ok(u1 == 3 and b1 == 1, "汇总 3 个用户 + 1 本书")
    ok(uf["days"]["2026-10-27"] == 90 and uf["total_sec"] == 90, "用户当天 90 秒、累计 90 秒")
    ok(uf["weeks"].get("2026-W44") == 90 and uf["months"].get("2026-10") == 90,
       "周/月汇总正确（2026-W44 / 2026-10）")
    ok(uf["books"]["498607"]["sec"] == 90 and uf["books"]["498607"]["title"] == "测试报告",
       "书单带书名与时长")
    ok(uf["active_days"] == 1 and uf["book_count"] == 1, "活跃天数 1、读过 1 本")

    bf = _local_read(rs.book_path(498607))
    ok(bf["total_sec"] == 150 and bf["reader_count"] == 2 and bf["opens"] == 3,
       "书籍文件：总时长 150 秒、阅读人数 2、阅读次数 3")
    ok(bf["days_read"] == 1 and bf["first_read"] == "2026-10-27", "书籍按天曲线与首读日期")

    # ---- 7. 汇总幂等：重复跑数字不变 ----
    rs.rollup_day("2026-10-27")
    uf2 = _local_read(rs.user_path(15, "2026"))
    bf2 = _local_read(rs.book_path(498607))
    ok(uf2["total_sec"] == 90 and bf2["total_sec"] == 150
       and bf2["reader_count"] == 2, "重复汇总不重复计数（幂等）")

    # ---- 8. 跨天：周/月/连续天数 ----
    rs.today = lambda: "2026-10-28"
    rs.record(15, 498607, 120, "md", "测试报告")
    rs.flush()
    rs.rollup_day("2026-10-28")
    uf3 = _local_read(rs.user_path(15, "2026"))
    ok(uf3["total_sec"] == 210 and len(uf3["days"]) == 2, "第二天累计到 210 秒、2 天明细")
    ok(uf3["max_streak"] == 2, "连续阅读 2 天")
    ok(uf3["weeks"]["2026-W44"] == 210, "同一周内两天时长合并")

    # ---- 9. 清理：三年以前的日文件被删、累计保留 ----
    rs._list_day_dates = lambda: ["2026-10-27", "2019-01-01"]
    old = rs.day_path("2019-01-01")
    _local_write(old, {"date": "2019-01-01", "users": {}, "books": {}})
    removed = rs.prune(days=365 * 3)
    ok(removed == 1 and not os.path.exists(os.path.join(TMP, old)),
       "清理三年以前的老日文件")
    uf4 = _local_read(rs.user_path(15, "2026"))
    ok(uf4["total_sec"] == 210, "清理不动累计总数")

    print("reading_stats 回归测试：%d 通过 / %d 失败" % (_ok, _fail))
    shutil.rmtree(TMP, ignore_errors=True)
    sys.exit(0 if _fail == 0 else 1)


if __name__ == "__main__":
    main()
