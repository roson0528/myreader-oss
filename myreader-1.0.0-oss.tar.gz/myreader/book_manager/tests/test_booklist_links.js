// 「友情链接」端到端回归：
//   1. 书单页右侧栏「浏览排行」下面新增「友情链接」，最多 5 条
//   2. 后台「概览 → 友情链接管理」（在「分组管理」下面）能增 / 删 / 改
//   3. 一条都没配时整块隐藏（连标题一起，不留空壳）
//   4. 地址只收 http/https（javascript: 之类不能进 href）
//   5. 名称留空时侧栏直接显示地址
//
// 前置：服务在 https://127.0.0.1:9000 运行。
// ★ 本脚本会**改配置**（site_links），结束时一定还原成跑之前的值（finally 里）。
// 运行：NODE_PATH=/tmp/pwtest/node_modules node tests/test_booklist_links.js
const { chromium } = require('playwright-core');
const { execSync } = require('child_process');
const CHROME = '/srv/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome';
const ROOT = '/srv/myreader/book_manager';
const BASE = 'https://127.0.0.1:9000';

let pass = 0, fail = 0;
const ck = (n, ok, extra) => {
  if (ok) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (extra ? '  → ' + extra : '')); }
};
const py = (code) => execSync('venv/bin/python -', { cwd: ROOT, encoding: 'utf8', input: code }).trim();
const pyJson = (code) => JSON.parse(py(code));

// 直接读库：验证「后端真的存成什么样」，而不是只看界面
const readLinks = () => pyJson(`
import sys, json
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
import booklists
print(json.dumps(booklists.site_links(), ensure_ascii=False))
`);
const rawConfig = () => py(`
import sys
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
import db
print(db.get_config('site_links', '') or '')
`);
const writeLinks = (items) => py(`
import sys, json
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
import db
db.set_config('site_links', json.dumps(json.loads(${JSON.stringify(JSON.stringify(items))}), ensure_ascii=False))
print('ok')
`);

(async () => {
  const orig = rawConfig();          // ★ 跑完必须还原
  const info = pyJson(`
import sys, json
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
import db, auth
a = db.q("SELECT * FROM users WHERE role='admin' AND enabled=1 ORDER BY id LIMIT 1", one=True)
t = db.q("SELECT * FROM users WHERE username='test' AND enabled=1 LIMIT 1", one=True)
print(json.dumps({"admin": {"token": auth.create_token(a), "user": dict(a)},
                  "test": {"token": auth.create_token(t), "user": dict(t)}}))
`);

  const browser = await chromium.launch({ executablePath: CHROME, args: ['--no-sandbox'] });
  const errs = [];
  const mkPage = async (who, w, h) => {
    const ctx = await browser.newContext({ ignoreHTTPSErrors: true, viewport: { width: w, height: h } });
    // ★ 每个请求都带 no-cache：/api/booklists/sidebar 是同一 URL 反复读，
    //   浏览器会拿 HTTP 缓存里的旧响应（第一版测试就是这么假红的：
    //   库里已经改了，页面读到的还是上一次的 links）。
    await ctx.setExtraHTTPHeaders({ 'Cache-Control': 'no-cache', 'Pragma': 'no-cache' });
    await ctx.addInitScript(([t, u]) => {
      localStorage.setItem('bm_token', t); localStorage.setItem('bm_user', u);
    }, [info[who].token, JSON.stringify(info[who].user)]);
    const p = await ctx.newPage();
    p.on('pageerror', e => errs.push(String(e)));
    return p;
  };
  // 侧栏是异步填的，必须等它渲染成**期望的样子**再断言。
  // ★ 两个坑都踩过：
  //   1) 页面已经在 #/booklists 上时再 goto 同一个 URL 是同文档导航，不重新加载
  //      —— 读到的是上一轮的旧 DOM，所以先 reload；
  //   2) 「隐藏」和「还没加载完」长得一模一样（空列表 + display:none），
  //      只等「隐藏或非空」会立刻返回然后读到空 —— 所以要等具体的期望值：
  //      want='hidden' 等隐藏，want=N 等 N 条。
  const readSide = async (p, want) => {
    await p.goto(BASE + '/#/booklists', { waitUntil: 'domcontentloaded' });
    await p.reload({ waitUntil: 'domcontentloaded' });
    const matched = await p.waitForFunction((w) => {
      const c = document.getElementById('bl-links-card');
      const list = document.getElementById('bl-links');
      if (!c || !list) return false;
      const shown = c.style.display !== 'none';
      return (w === 'hidden') ? !shown : (shown && list.children.length === w);
    }, want, { timeout: 15000 }).then(() => true).catch(() => false);
    // ★ matched 是 Node 侧的变量，必须当参数传进 evaluate —— 直接写在返回对象里
    //   会在浏览器里报 ReferenceError: matched is not defined（第一版就这么炸的）。
    return p.evaluate((matched) => {
      const card = document.getElementById('bl-links-card');
      const list = document.getElementById('bl-links');
      const heads = Array.from(document.querySelectorAll('.bl-side .card h3')).map(h => h.textContent.trim());
      const visible = el => !!(el && el.offsetParent !== null);
      return {
        matched,
        cardExists: !!card,
        cardVisible: visible(card),
        heads,
        items: list ? Array.from(list.querySelectorAll('a.bl-link')).map(a => ({
          text: a.textContent.trim(), href: a.getAttribute('href'),
          target: a.getAttribute('target'), rel: a.getAttribute('rel') || '',
        })) : null,
      };
    }, matched);
  };

  try {
    // ============ A. 清空：整块隐藏（连标题一起） ============
    writeLinks([]);
    const admin = await mkPage('admin', 1400, 1000);
    const user = await mkPage('test', 1400, 1000);
    let side = await readSide(user, 'hidden');   // A. 清空后应隐藏
    ck('侧栏有「友情链接」这块卡片（DOM 在）', side.cardExists, JSON.stringify(side));
    ck('没配友链时整块隐藏（标题也不显示）', side.cardExists && !side.cardVisible, JSON.stringify(side));
    ck('隐藏时列表是空的', Array.isArray(side.items) && side.items.length === 0, JSON.stringify(side.items));

    // ============ B. 后台界面：分组管理下面有「友情链接管理」，能加两条 ============
    await admin.goto(BASE + '/admin', { waitUntil: 'domcontentloaded' });
    await admin.waitForTimeout(2500);
    const block = await admin.evaluate(() => {
      const hs = Array.from(document.querySelectorAll('#app .card h3')).map(h => h.textContent.trim());
      const gi = hs.findIndex(h => h.includes('分组管理'));
      const li = hs.findIndex(h => h.includes('友情链接管理'));
      return { hs: hs.slice(0, 40), gi, li,
               addBtn: !!document.getElementById('link-add-btn'),
               saveBtn: !!document.getElementById('link-save-btn') };
    });
    ck('后台有「友情链接管理」卡片', block.li >= 0, block.hs.join(' | ').slice(0, 200));
    ck('它排在「分组管理」下面', block.gi >= 0 && block.li > block.gi, 'gi=' + block.gi + ' li=' + block.li);
    ck('有「添加友链」「保存友链」按钮', block.addBtn && block.saveBtn);

    // 加两条：一条带名称，一条只填地址（名称留空要能显示地址）
    await admin.click('#link-add-btn');
    await admin.click('#link-add-btn');
    await admin.fill('.link-name[data-i="0"]', '示例的小站');
    await admin.fill('.link-url[data-i="0"]', 'https://localhost:9000');
    await admin.fill('.link-url[data-i="1"]', 'https://example.com/a?x=1&y=2');
    await admin.click('#link-save-btn');
    await admin.waitForTimeout(1200);
    let saved = readLinks();
    ck('后台保存后库里是 2 条', saved.length === 2, JSON.stringify(saved, null, 0));
    ck('名称与地址都存对了', saved[0] && saved[0].name === '示例的小站' &&
       saved[0].url === 'https://localhost:9000' && saved[1].url === 'https://example.com/a?x=1&y=2',
       JSON.stringify(saved));

    // ============ C. 书单页：块显示出来、两个链接正确 ============
    side = await readSide(user, 2);
    ck('配了友链后整块显示出来', side.cardVisible, JSON.stringify(side));
    ck('侧栏有「友情链接」标题', side.heads.some(h => h.includes('友情链接')), side.heads.join(' | '));
    ck('「友情链接」排在「浏览排行」下面',
       side.heads.findIndex(h => h.includes('浏览排行')) < side.heads.findIndex(h => h.includes('友情链接')),
       side.heads.join(' | '));
    ck('显示 2 条友链', side.items.length === 2, JSON.stringify(side.items));
    ck('第 1 条显示名称、href 正确', side.items[0] &&
       side.items[0].text === '示例的小站' && side.items[0].href === 'https://localhost:9000',
       JSON.stringify(side.items[0]));
    ck('第 2 条没填名称 → 直接显示地址', side.items[1] &&
       side.items[1].text === 'https://example.com/a?x=1&y=2' &&
       side.items[1].href === 'https://example.com/a?x=1&y=2', JSON.stringify(side.items[1]));
    ck('外链带 target=_blank 且 rel 含 noopener',
       side.items.every(x => x.target === '_blank' && /noopener/.test(x.rel)), JSON.stringify(side.items));

    // ============ D. 改名称：侧栏跟着变 ============
    await admin.goto(BASE + '/admin', { waitUntil: 'domcontentloaded' });
    await admin.waitForTimeout(2500);
    await admin.fill('.link-name[data-i="0"]', '云阅读');
    await admin.click('#link-save-btn');
    await admin.waitForTimeout(1200);
    saved = readLinks();
    ck('改名后库里是新名字', saved[0] && saved[0].name === '云阅读', JSON.stringify(saved));
    side = await readSide(user, 1);
    ck('书单页显示的是新名字', side.items[0] && side.items[0].text === '云阅读', JSON.stringify(side.items[0]));

    // ============ E. 删除一条 ============
    await admin.goto(BASE + '/admin', { waitUntil: 'domcontentloaded' });
    await admin.waitForTimeout(2500);
    await admin.click('#link-list button:has-text("删除")');
    await admin.click('#link-save-btn');
    await admin.waitForTimeout(1200);
    saved = readLinks();
    ck('删除后库里剩 1 条', saved.length === 1, JSON.stringify(saved));
    side = await readSide(user, 1);
    ck('书单页也只剩 1 条', side.items.length === 1, JSON.stringify(side.items));

    // ============ F. 非法地址：前端拦下 + 后端也拒绝 ============
    await admin.goto(BASE + '/admin', { waitUntil: 'domcontentloaded' });
    await admin.waitForTimeout(2500);
    const before = rawConfig();
    await admin.click('#link-add-btn');
    await admin.fill('.link-url[data-i="1"]', 'javascript:alert(1)');
    await admin.click('#link-save-btn');
    await admin.waitForTimeout(900);
    const toastTxt = await admin.evaluate(() => (document.getElementById('toast') || {}).textContent || '');
    ck('前端拦下 javascript: 地址并提示', /http:\/\/|https:\/\//.test(toastTxt), toastTxt);
    ck('被拦下时**没有**把坏数据写进库', rawConfig() === before, rawConfig().slice(0, 80));
    // 后端也要拒绝（前端绕过 / 直接调接口的情况）
    const apiResp = pyJson(`
import sys, json
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
import booklists
from fastapi import HTTPException
try:
    booklists.site_links_save([{"name": "", "url": "javascript:alert(1)"}])
    print(json.dumps({"ok": True}))
except HTTPException as e:
    print(json.dumps({"ok": False, "detail": e.detail}))
`);
    ck('后端直接拒绝 javascript: 地址（400）', apiResp.ok === false, JSON.stringify(apiResp));

    // ============ G. 上限 5 条：按钮禁用 ============
    writeLinks([
      { name: '友链一', url: 'https://a1.example.com' },
      { name: '友链二', url: 'https://a2.example.com' },
      { name: '友链三', url: 'https://a3.example.com' },
      { name: '友链四', url: 'https://a4.example.com' },
      { name: '友链五', url: 'https://a5.example.com' },
    ]);
    side = await readSide(user, 5);
    ck('5 条友链全部显示', side.items.length === 5, JSON.stringify(side.items.map(x => x.text)));
    await admin.goto(BASE + '/admin', { waitUntil: 'domcontentloaded' });
    await admin.waitForTimeout(2500);
    const cap = await admin.evaluate(() => {
      const b = document.getElementById('link-add-btn');
      return { disabled: !!b.disabled, text: b.textContent.trim() };
    });
    ck('满 5 条后「添加友链」按钮禁用', cap.disabled, JSON.stringify(cap));
    ck('第 6 条进不来（后端也卡）', (() => {
      const r = pyJson(`
import sys, json
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
import booklists
from fastapi import HTTPException
try:
    booklists.site_links_save([{"url": "https://x%d.com" % i} for i in range(6)])
    print(json.dumps({"ok": True}))
except HTTPException as e:
    print(json.dumps({"ok": False, "detail": e.detail}))
`);
      return r.ok === false;
    })());

    // ============ H. 清空 → 整块又隐藏 ============
    await admin.goto(BASE + '/admin', { waitUntil: 'domcontentloaded' });
    await admin.waitForTimeout(2500);
    for (let i = 0; i < 5; i++) await admin.click('#link-list button:has-text("删除")');
    await admin.click('#link-save-btn');
    await admin.waitForTimeout(1200);
    ck('清空后库里是 0 条', readLinks().length === 0, rawConfig().slice(0, 60));
    side = await readSide(user, 'hidden');
    ck('清空后书单页整块隐藏', !side.cardVisible, JSON.stringify(side));

    ck('全程没有 JS 报错', errs.length === 0, errs.slice(0, 3).join(' | '));
  } finally {
    // ★ 还原成跑之前的值：测试改的是线上配置
    if (orig === '' || orig === null) {
      py(`
import sys
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
import db
db.ex("DELETE FROM system_config WHERE key='site_links'")
print('ok')
`);
    } else {
      py(`
import sys
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
import db
db.set_config('site_links', ${JSON.stringify(orig)})
print('ok')
`);
    }
    console.log('  · 已还原 site_links = ' + JSON.stringify((rawConfig() || '').slice(0, 60)));
    await browser.close();
  }

  console.log('\n  通过 ' + pass + ' / 失败 ' + fail);
  process.exit(fail ? 1 : 0);
})();
