#!/usr/bin/env bash
# 开发/简易启动：起一个 uvicorn 进程。生产环境建议用 systemd（见 docs/DEPLOY.md）
set -euo pipefail
cd "$(dirname "$0")"

# 有 .env 就加载（仓库根目录），没有就完全靠外部环境变量
if [ -f ../.env ]; then
  set -a
  . ../.env
  set +a
fi

PY="${PYTHON:-python3}"
HOST="${HOST:-0.0.0.0}"
PORT="${PORT:-9000}"

echo "云阅读启动: http://${HOST}:${PORT}"
exec "$PY" -m uvicorn app:app --host "$HOST" --port "$PORT"
