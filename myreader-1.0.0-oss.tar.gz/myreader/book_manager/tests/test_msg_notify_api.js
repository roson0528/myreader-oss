// 「我的消息」系统通知用的轻量轮询接口 /api/messages/notify。
//
// APP 的后台轮询（AlarmManager，见 reader_android 的 MessageNotifier.java）
// 每 15 分钟打的就是这个接口，所以它的口径必须和消息列表**完全一致**：
//   · unread   = 未读条数
//   · max_id   = 未读里最大的 id（客户端靠它判断「有没有更新的」，避免重复弹）
//   · latest   = 最新的那条未读（标题/发送人），通知里直接显示
//   · 未读为 0 时 max_id=0、latest=null（客户端据此撤通知、清角标）
// 这个测试用测试账号 test，自己造消息、按精确 id 清理。
const { execSync } = require('child_process');
const ROOT = '/srv/myreader/book_manager';
const BASE = 'https://127.0.0.1:9000';

let pass = 0, fail = 0;
const ck = (n, ok, extra) => {
  if (ok) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (extra ? '  → ' + extra : '')); }
};
const py = (c) => execSync('venv/bin/python -', { cwd: ROOT, encoding: 'utf8', input: c }).trim();
const H = (tok) => ({ 'Authorization': 'Bearer ' + tok, 'X-BM-No-Push': '1' });

process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

(async () => {
  const info = JSON.parse(py(`
import sys, json
sys.path.insert(0, '${ROOT}')
import db, auth
u = db.q("SELECT * FROM users WHERE username='test' AND enabled=1", one=True)
if not u:
    raise SystemExit('测试账号 test 不存在')
print(json.dumps({"tok": auth.create_token(u), "uid": u["id"]}))`));
  const { tok, uid } = info;

  const get = async (t) => {
    const r = await fetch(`${BASE}/api/messages/notify`, { headers: H(t || tok) });
    return { status: r.status, body: await r.json().catch(() => null) };
  };
  // 本次造的两条消息 id（finally 里按精确 id 删）
  const made = [];

  try {
    // 0) 起点：先把该账号的未读清干净，便于观察（只动本账号自己的消息）
    const base = JSON.parse(py(`
import sys, json
sys.path.insert(0, '${ROOT}')
import db
db.ex("UPDATE messages SET is_read=1 WHERE to_id=? AND is_read=0", (${uid},))
r = db.q("SELECT COUNT(*) c FROM messages WHERE to_id=? AND is_read=0", (${uid},), one=True)
print(json.dumps({"unread": r["c"]}))`));
    ck('起点未读已清零', base.unread === 0, 'unread=' + base.unread);

    // 1) 没有未读时：unread=0 / max_id=0 / latest=null
    let r1 = await get();
    ck('接口可用（HTTP 200）', r1.status === 200, 'HTTP ' + r1.status);
    ck('无未读时 unread=0', r1.body.unread === 0, JSON.stringify(r1.body));
    ck('★ 无未读时 max_id=0（客户端据此清角标）', r1.body.max_id === 0, 'max_id=' + r1.body.max_id);
    ck('★ 无未读时 latest=null', r1.body.latest === null, JSON.stringify(r1.body.latest));

    // 2) 造一条系统消息（无发送人）→ latest.from_name 应为「系统」
    const id1 = Number(py(`
import sys
sys.path.insert(0, '${ROOT}')
import db
db.add_message(${uid}, "通知测试·系统消息", "正文", kind="system")
print(db.q("SELECT MAX(id) m FROM messages", one=True)["m"])`));
    made.push(id1);
    let r2 = await get();
    ck('★ 有未读时 unread 正确', r2.body.unread === 1, 'unread=' + r2.body.unread);
    ck('★ max_id 就是这条消息的 id', r2.body.max_id === id1, `${r2.body.max_id} ≠ ${id1}`);
    ck('latest 带上了标题', r2.body.latest && r2.body.latest.title === '通知测试·系统消息',
       JSON.stringify(r2.body.latest));
    ck('★ 无发送人的消息 from_name 是「系统」',
       r2.body.latest && r2.body.latest.from_name === '系统',
       JSON.stringify(r2.body.latest && r2.body.latest.from_name));

    // 3) 再补一条带发送人的（从 uid=15 示例发来）→ latest 应变成新的那条，from_name 是发送人
    const id2 = Number(py(`
import sys
sys.path.insert(0, '${ROOT}')
import db
db.add_message(${uid}, "通知测试·私信", "正文", kind="pm", from_id=15)
print(db.q("SELECT MAX(id) m FROM messages", one=True)["m"])`));
    made.push(id2);
    let r3 = await get();
    ck('多了一条后 unread=2', r3.body.unread === 2, 'unread=' + r3.body.unread);
    ck('★ max_id 跟着变成最新那条', r3.body.max_id === id2, `${r3.body.max_id} ≠ ${id2}`);
    ck('★ latest 的 from_name 是发送人（不是「系统」）',
       r3.body.latest && r3.body.latest.from_name === '示例',
       JSON.stringify(r3.body.latest && r3.body.latest.from_name));

    // 4) 与消息列表口径一致（title/from_name 必须对得上）
    const listRow = JSON.parse(py(`
import sys, json
sys.path.insert(0, '${ROOT}')
import db
d = db.list_messages(${uid}, page=1, page_size=5)
m = [x for x in d["items"] if not x["is_read"]][0]
print(json.dumps({"id": m["id"], "title": m["title"], "from_name": m["from_name"]}))`));
    ck('★ 与消息列表的口径一致（id/标题/发送人）',
       listRow.id === r3.body.latest.id && listRow.title === r3.body.latest.title
       && listRow.from_name === r3.body.latest.from_name,
       JSON.stringify({ list: listRow, notify: r3.body.latest }));

    // 5) 只读掉最新那条 → max_id 回退到剩下那条（客户端不会因此重弹）
    py(`import sys
sys.path.insert(0, '${ROOT}')
import db
db.ex("UPDATE messages SET is_read=1 WHERE id=?", (${id2},))
print("ok")`);
    let r4 = await get();
    ck('★ 读掉最新那条后 unread 减少、max_id 回退（不回退成 0）',
       r4.body.unread === 1 && r4.body.max_id === id1,
       `unread=${r4.body.unread} max_id=${r4.body.max_id}`);

    // 6) 全读完 → 回到 unread=0 / max_id=0 / latest=null
    py(`import sys
sys.path.insert(0, '${ROOT}')
import db
db.ex("UPDATE messages SET is_read=1 WHERE id=?", (${id1},))
print("ok")`);
    let r5 = await get();
    ck('★ 全部读完后又回到 unread=0/max_id=0/latest=null',
       r5.body.unread === 0 && r5.body.max_id === 0 && r5.body.latest === null,
       JSON.stringify(r5.body));

    // 7) 游客/无令牌不能读（这个接口要拿未读数，必须登录）
    const anon = await fetch(`${BASE}/api/messages/notify`);
    ck('★ 未登录拿不到（401）', anon.status === 401, 'HTTP ' + anon.status);
    const rGuest = await fetch(`${BASE}/api/messages/notify`, { headers: H('bad.token.here') });
    ck('★ 无效令牌也拿不到（401）', rGuest.status === 401, 'HTTP ' + rGuest.status);
  } finally {
    // 按精确 id 清掉本次造的消息（不碰这个账号已有的历史消息）
    const ids = made.filter(Boolean);
    const left = JSON.parse(py(`
import sys, json
sys.path.insert(0, '${ROOT}')
import db
for i in ${JSON.stringify(ids)}:
    db.ex("DELETE FROM messages WHERE id=? AND to_id=?", (i, ${uid}))
n = db.q("SELECT COUNT(*) c FROM messages WHERE to_id=? AND is_read=0", (${uid},), one=True)["c"]
print(json.dumps({"left": n}))`));
    ck('测试数据已按精确 id 清理', left.left === 0, '还剩 ' + left.left + ' 条未读');
  }

  console.log(`\n消息通知接口：${pass} 通过 / ${fail} 失败`);
  process.exit(fail ? 1 : 0);
})();
