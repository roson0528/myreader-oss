"""AI 接口适配：角色识别 + 音色分配。

支持两种协议，加自定义 base_url / key / model —— 换服务商只改配置：

  openai-completions  POST {base}/chat/completions   → choices[0].message.content
  openai-responses    POST {base}/responses          → output[].content[].text

★ 分工：**「哪一段是引号内」由 speech.split_spans 确定性切**，
  AI 只回答「这一句是谁说的」和「有哪些角色、什么性别」。
  实测把切分也交给 AI 会出错（整行标成同一人），而且白白多花 token。
"""
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE)

PROTOCOLS = ("openai-completions", "openai-responses")

SYS_PROMPT = (
    "你是有声书制作的角色分析器。给你一章小说的句子（带序号），你要做两件事：\n"
    "1. 找出这一章出现过的所有**说话的角色**，给出名字、性别（男/女/未知）、"
    "一句话音色特征（年龄感、音色粗细、语速等）。只列真正说话的角色，"
    "不要列只被提到的人。\n"
    "2. 给每一句标注说话人：如果是引号里的对白，填角色名；"
    "如果整句都是叙述、描写、心理活动，填「旁白」。\n"
    "只输出 JSON，不要解释，不要 markdown 代码围栏。格式：\n"
    '{"characters":[{"name":"角色名","gender":"男","desc":"音色特征"}],'
    '"speakers":{"句子序号":"角色名或旁白"}}'
)


class AIError(RuntimeError):
    pass


def _url(base, path):
    b = (base or "").strip().rstrip("/")
    if not b:
        raise AIError("AI 接口地址（base_url）没配")
    if b.endswith("/v1") and path.startswith("/v1/"):
        b = b[:-3]
    return b + path


def _post(url, payload, key, timeout, retries=5):
    """POST + 限流重试。

    ★ 第三方 AI 接口普遍有 TPM/RPM 限制，实测这家的免费额度会直接回
      `429 RateLimitExceeded.EndpointTPMExceeded`。一本书要发几十次分析请求，
      中间撞上限额是常态而不是异常 —— 不重试的话任何稍大的书都会整本失败。
      所以 429 和 5xx 都要退避重试，并且优先听服务端的 Retry-After。
    """
    delay = 6.0
    last = None
    for attempt in range(max(1, retries)):
        req = urllib.request.Request(url, data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                                     method="POST")
        req.add_header("Content-Type", "application/json")
        if key:
            req.add_header("Authorization", "Bearer " + key)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return json.loads(r.read().decode("utf-8", "replace"))
        except urllib.error.HTTPError as e:
            body = ""
            try:
                body = e.read().decode("utf-8", "replace")[:400]
            except Exception:
                pass
            last = AIError("AI 接口返回 %d：%s" % (e.code, body))
            if e.code in (429, 500, 502, 503, 504) and attempt < retries - 1:
                wait = delay
                ra = e.headers.get("Retry-After") if e.headers else None
                if ra:
                    try:
                        wait = max(wait, float(ra))
                    except Exception:
                        pass
                time.sleep(min(wait, 120))
                delay = min(delay * 2, 120)
                continue
            raise last
        except Exception as e:
            last = AIError("AI 接口连不上：%s" % e)
            if attempt < retries - 1:
                time.sleep(min(delay, 60))
                delay = min(delay * 2, 60)
                continue
            raise last
    raise last or AIError("AI 接口调用失败")


def _get(url, key, timeout):
    req = urllib.request.Request(url, method="GET")
    if key:
        req.add_header("Authorization", "Bearer " + key)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8", "replace"))
    except urllib.error.HTTPError as e:
        raise AIError("AI 接口返回 %d" % e.code)
    except Exception as e:
        raise AIError("AI 接口连不上：%s" % e)


def _extract(d):
    """从两种协议的响应里取出正文文本。"""
    # openai-completions
    try:
        c = d["choices"][0]["message"]["content"]
        if isinstance(c, list):
            return "".join(x.get("text", "") for x in c if isinstance(x, dict))
        if c:
            return c
    except Exception:
        pass
    # openai-responses
    try:
        buf = []
        for item in d.get("output") or []:
            for c in item.get("content") or []:
                if isinstance(c, dict) and c.get("text"):
                    buf.append(c["text"])
        if buf:
            return "".join(buf)
    except Exception:
        pass
    # 有些兼容层直接给 output_text
    if isinstance(d.get("output_text"), str):
        return d["output_text"]
    # ★ 推理模型（deepseek-v4-pro 这类）有时把正文留在 reasoning_content 里，
    #   content 是空串。实测就撞到过：{"content": "", "reasoning_content": "..."}，
    #   这时要把 reasoning_content 当正文用，否则整章分析白白失败。
    try:
        msg = d["choices"][0]["message"]
        for k in ("reasoning_content", "reasoning", "thinking"):
            v = msg.get(k)
            if isinstance(v, str) and v.strip():
                return v
            if isinstance(v, list):
                t = "".join(x.get("text", "") for x in v if isinstance(x, dict))
                if t.strip():
                    return t
    except Exception:
        pass
    # 响应里夹了错误信息就把它带出来，比"认不出格式"有用得多
    err = ""
    try:
        err = json.dumps(d.get("error") or {}, ensure_ascii=False)[:200]
    except Exception:
        err = ""
    fin = ""
    try:
        fin = str(d["choices"][0].get("finish_reason") or "")
    except Exception:
        pass
    raise AIError("认不出的响应格式%s%s：%s" % (
        "（finish_reason=%s）" % fin if fin else "",
        "（接口报错 %s）" % err if err and err != "{}" else "",
        json.dumps(d, ensure_ascii=False)[:300]))


def chat(messages, cfg, timeout=None, max_tokens=4096):
    proto = (cfg.get("ai_protocol") or "openai-completions").strip()
    base = cfg.get("ai_base_url") or ""
    key = cfg.get("ai_key") or ""
    model = (cfg.get("ai_model") or "").strip()
    if not model:
        raise AIError("AI 模型名没配")
    to = int(timeout or cfg.get("ai_timeout") or 180)
    if proto == "openai-responses":
        url = _url(base, "/v1/responses")
        payload = {"model": model, "input": messages, "max_output_tokens": max_tokens}
        # 有的兼容层只认 input 是字符串
        payload["input"] = [{"role": m.get("role", "user"),
                             "content": [{"type": "input_text", "text": m.get("content", "")}]}
                            for m in messages]
    else:
        url = _url(base, "/v1/chat/completions")
        payload = {"model": model, "messages": messages, "temperature": 0.2,
                   "max_tokens": max_tokens}
    d = _post(url, payload, key, to)
    return _extract(d)


def models(cfg):
    """列出可用模型（后台「测试连接」按钮用）。"""
    d = _get(_url(cfg.get("ai_base_url") or "", "/v1/models"),
             cfg.get("ai_key") or "", int(cfg.get("ai_timeout") or 60))
    return [m.get("id") for m in (d.get("data") or []) if isinstance(m, dict) and m.get("id")]


def probe(cfg):
    """连通性自检：能列出模型最好，列不出就发一句最短的请求。"""
    t0 = time.time()
    try:
        ms = models(cfg)
        return {"ok": True, "how": "models", "count": len(ms), "models": ms[:80],
                "elapsed": round(time.time() - t0, 1)}
    except AIError as e:
        pass
    txt = chat([{"role": "user", "content": "回复两个字：可以"}], cfg, timeout=60, max_tokens=16)
    return {"ok": True, "how": "chat", "reply": (txt or "").strip()[:40],
            "elapsed": round(time.time() - t0, 1)}


def _json_of(text):
    """从模型输出里抠出 JSON。

    模型经常裹一层 markdown 代码围栏，或者在 JSON 前后加一句话；
    实测 deepseek/glm 都规矩，但不能赌，所以做三层兜底。
    """
    s = (text or "").strip()
    s = re.sub(r"^```[a-zA-Z]*\s*", "", s)
    s = re.sub(r"\s*```$", "", s).strip()
    try:
        return json.loads(s)
    except Exception:
        pass
    i, j = s.find("{"), s.rfind("}")
    if i >= 0 and j > i:
        try:
            return json.loads(s[i:j + 1])
        except Exception:
            pass
    raise AIError("模型没有返回可解析的 JSON：%s" % s[:200])


def analyze(sentences, cfg, chunk=120):
    """给一批句子做角色识别 + 说话人标注。

    sentences: [str]，返回 {"characters":[...], "speakers":{句序号: 角色名}}。
    句子多的时候分块请求，块之间把已识别的角色名带过去，避免同一个角色
    在不同块里被起成两个名字。
    """
    chars, speakers = {}, {}
    known = []
    for base_i in range(0, len(sentences), chunk):
        part = sentences[base_i:base_i + chunk]
        lines = "\n".join("[%d] %s" % (base_i + k, s) for k, s in enumerate(part))
        hint = ""
        if known:
            hint = "\n已知角色（能对上就用这些名字，不要另起新名）：" + "、".join(known)
        msg = "章节内容（共 %d 句）：\n%s%s" % (len(sentences), lines, hint)
        sys_p = (cfg.get("ai_prompt") or "").strip() or SYS_PROMPT
        # ★ 模型偶尔会整段输出推理、把 JSON 挤没了（实测 deepseek-v4-pro 在这本书
        #   第 3 章的第 3 块上烧了 2 分钟，回的全是「We need answer JSON only…」，
        #   前两块却完全正常）。这种不是配置问题，重问一次基本就规矩了，
        #   所以这里解析失败就再问，第二次起在用户消息里额外钉一句「只输出 JSON」。
        d, last_err = None, ""
        user_msg = msg
        for attempt in range(3):
            raw = chat([{"role": "system", "content": sys_p},
                        {"role": "user", "content": user_msg}], cfg, max_tokens=8192)
            try:
                d = _json_of(raw)
                break
            except AIError as e:
                last_err = str(e)
                user_msg = msg + "\n\n（只输出 JSON，不要任何解释、不要 markdown 围栏。）"
                if attempt < 2:
                    time.sleep(1.0)
        if d is None:
            raise AIError("%s（已重问 3 次）" % last_err)
        for c in (d.get("characters") or []):
            n = (c.get("name") or "").strip()
            if n and n not in chars:
                chars[n] = {"name": n, "gender": (c.get("gender") or "未知").strip(),
                            "desc": (c.get("desc") or "").strip()}
        sp = d.get("speakers") or d.get("lines") or {}
        if isinstance(sp, list):        # 有的模型返回 [{i,speaker}]
            sp = {str(x.get("i")): x.get("speaker") for x in sp if isinstance(x, dict)}
        for k, v in (sp or {}).items():
            try:
                idx = int(str(k).strip())
            except Exception:
                continue
            if 0 <= idx < len(sentences):
                speakers[idx] = (v or "旁白").strip() or "旁白"
        known = list(chars.keys())
    return {"characters": list(chars.values()), "speakers": speakers}


# 角色特征 → 音色名里的关键词。
# 起因：只按性别轮询会把「加贺」（中年男性刑警）分到「正太音」——池子里男声少，
# 轮到的就是这个。AI 其实给了「音色特征」描述（年龄感、粗细、语速），
# 而音色池的名字本身就很有描述性（御姐女声/知性女声/男声烟嗓/低音炮/正太音…），
# 两者对得上就能选准得多。
_FEAT = [
    (("童", "少年", "小孩", "稚", "孩子"), ("童", "正太")),
    (("少女", "姑娘", "年轻女子", "青春"), ("少女", "御姐", "甜")),
    (("青年", "年轻男"), ("青年", "清朗", "清亮")),
    (("中年", "成熟"), ("御姐", "知性", "沉稳", "低音炮")),
    (("老年", "苍老", "沧桑", "年迈", "苍凉", "老者"), ("老年", "沧桑", "低沉", "低音炮")),
    (("沙哑", "烟嗓", "嘶哑", "嗓子哑", "粗粝"), ("烟嗓",)),
    (("低沉", "浑厚", "厚重", "磁性", "醇厚", "低频"), ("低沉", "低音炮", "浑厚")),
    (("清亮", "清脆", "清朗", "明亮", "爽朗", "干净"), ("清爽", "清脆", "清朗")),
    (("温柔", "温润", "柔和", "轻软", "软糯", "和煦"), ("温柔", "温润", "轻柔", "酥柔")),
    (("空灵", "飘渺", "空悠"), ("空灵",)),
    (("知性", "书卷", "优雅", "端庄", "冷静"), ("知性", "御姐")),
    (("甜", "甜美", "甜脆", "娇"), ("甜",)),
    (("慢", "缓慢", "语速慢", "不紧不慢", "悠然"), ("慢",)),
    (("大嗓门", "洪亮", "嗓门大", "粗犷"), ("大嗓门", "泼妇")),
    (("娘娘腔", "阴柔", "女性化"), ("娘娘腔",)),
    (("霸道", "强势", "威严", "气场"), ("霸道总裁", "大嗓门")),
]


# 冲突惩罚：音色名里有某个特征词，但角色的描述里**没有**对应特征 → 扣分。
# 起因：美千代（中年女性，温柔细腻、语速缓慢）被分到「女童慢音」——
# 「慢」加了分，可描述里根本没有「童」，名字里的「童」却不扣分，
# 于是一个中年妇女配了童声。同理老年/大嗓门/娘娘腔也要这样反向排除。
_PENALTY = [
    (("童", "正太"), ("童", "少年", "小孩", "稚", "孩子", "幼")),
    (("老年", "沧桑", "苍凉"), ("老年", "苍老", "沧桑", "年迈", "苍凉", "老者")),
    (("大嗓门", "泼妇"), ("大嗓门", "洪亮", "嗓门大", "泼妇", "粗犷")),
    (("娘娘腔",), ("娘娘腔", "阴柔", "女性化")),
    (("相声", "评书"), ("相声", "评书")),
    # 特殊/猎奇音色（猫女音、妖媚、鬼怪、机械音…）是给对应角色的，普通人不能拿。
    # 实测把一个「临时职员、口吻礼貌拘谨」配成了**猫女音**，只因为所有女声
    # 在特征分上打平、按池子顺序取就取到了它。
    (("猫", "妖", "鬼", "怪", "机械", "机器人", "兽"), ("猫", "妖", "鬼", "怪", "机械", "兽")),
]
_PEN = 2.0


def _ftscore(desc, gender, v):
    """给「这个角色 → 这个音色」打分。

    ★ 性别以**音色名**为准而不是 gender 字段：实测池子里 `pool_47` 名字叫
      「男童声」而 gender 字段标的是「女」，字段是错的，名字是对的。
    """
    name = v.get("name") or ""
    desc = desc or ""
    s = 0.0
    for kws, names in _FEAT:
        if any(k in desc for k in kws) and any(n in name for n in names):
            s += 3.0
    for names, kws in _PENALTY:
        if any(n in name for n in names) and not any(k in desc for k in kws):
            s -= _PEN
    if gender == "男":
        if "男" in name or (v.get("gender") or "") == "男":
            s += 1.0
    elif gender == "女":
        if "女" in name or (v.get("gender") or "") == "女":
            s += 1.0
    return s


def assign_voices(characters, pool, narrator):
    """给每个角色挑一个音色。

    两级策略：
      1) 先用 AI 给的「音色特征」和音色名做匹配打分（见 _FEAT），选最贴合的；
      2) 全部打平（描述里没有可识别的特征词）时，退回按性别轮流分。
    同一性别内按音色列表顺序取，所以结果是**确定性**的，重跑一致。
    旁白占掉的音色不再分给角色。最后后台还能人工覆盖。
    """
    free = [v for v in pool if v.get("voice") != narrator]
    if not free:
        return {}
    male = [v for v in free if _is_male(v)]
    female = [v for v in free if not _is_male(v)]
    used = set()
    out = {}
    mi = fi = 0
    for c in characters or []:
        g = (c.get("gender") or "未知").strip()
        desc = c.get("desc") or ""
        free_left = [v for v in free if v["voice"] not in used]
        # ★ 硬性别约束：特征匹配只在**性别正确**的音色里挑。
        #   否则「中年」这类描述一旦和宽泛的音色名撞上（曾经把「男声」写进中年规则），
        #   就会盖过性别的 +1，把女性角色分到男声上——实测出现过。
        #   性别判断用 _is_male（名字优先），因为池子里有 gender 字段标错的。
        if g == "男":
            same = [v for v in free_left if _is_male(v)]
        elif g == "女":
            same = [v for v in free_left if not _is_male(v)]
        else:
            same = free_left
        cands = same or free_left
        # 1) 特征匹配：取分数最高的。
        #   ★ 阈值必须是 >= 1，不能是 > 1。性别对得上恰好就是 +1 分，写成 > 1
        #     就等于「描述里没命中特征词时打分机制完全失效」，直接掉进下面的
        #     按性别轮流兜底 —— 而兜底是按池子顺序取的，实测把一个「年轻刑警、
        #     音色偏低而清冷」配成了**正太音（儿童音色）**，因为池子里
        #     pool_28 正好排在所有男声最前面。这类错配还很隐蔽：日志上看不出
        #     任何异常，只是"配得不对"。
        pick = None
        if cands:
            scored = sorted(((_ftscore(desc, g, v), -i, v) for i, v in enumerate(cands)),
                            key=lambda x: (-x[0], -x[1]))
            if scored and scored[0][0] >= 1.0:
                pick = scored[0][2]
        # 2) 退回按性别轮流
        if pick is None:
            for _ in range(len(free) + 1):
                if g == "男" and male:
                    pick = male[mi % len(male)]; mi += 1
                elif g == "女" and female:
                    pick = female[fi % len(female)]; fi += 1
                else:
                    pick = free[(mi + fi) % len(free)]
                if pick["voice"] not in used:
                    break
        if pick:
            used.add(pick["voice"])
            out[c["name"]] = {"voice": pick["voice"], "name": pick.get("name") or pick["voice"],
                              "gender": pick.get("gender") or "", "desc": desc}
    return out


def _is_male(v):
    """判断音色是不是男声。名字优先于 gender 字段（字段有标错的）。"""
    n = v.get("name") or ""
    if "男" in n and "女" not in n:
        return True
    if "女" in n and "男" not in n:
        return False
    return (v.get("gender") or "") == "男"
