"""朗读前的符号清理（tts._speakable / tts.safe_text）回归测试。

站长反馈：制作有声书时省略号、※、＃ 这些符号会被念成乱七八糟的声音，干扰语意。
修法在**送出去之前**那一层（tts.safe_text —— 批量制作、在线听书、角色音色重试
都绕不过它，四条线路一起生效）：

  ① 本身表示停顿的（……  ——  ～～  重复点）→ 换成逗号：停顿留着，但线路不会去
     念「省略号」三个字；
  ② 纯装饰 / 噪声符号（※ ＃ ＊ ☆ ★ ● ▲ § → emoji）→ 直接删掉；
  ③ 正常标点一律保留（，。、；：！？「」（）《》""''）—— 线路当停顿处理，不念出来；
  ④ 有明确读法的「数字 + 符号」换成词：50% → 百分之50、30℃ → 30摄氏度。

★ 不能返回空串：整句都是符号时（单独一行的「※※※※」）必须留个逗号，
  否则 _call_one 会以「这一段没有可合成的文本」抛错，整本书跟着失败。

本脚本不联网、不写库（只读一本来做「全书句子」不变式）。
"""
import sys
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
import tts  # noqa: E402

_pass, _fail = [0], [0]


def ck(name, ok, extra=''):
    if ok:
        _pass[0] += 1
        print('  [OK] %s%s' % (name, ('  ' + str(extra)) if extra != '' else ''))
    else:
        _fail[0] += 1
        print('  [FAIL] %s%s' % (name, ('  ' + str(extra)) if extra != '' else ''))


S = tts.safe_text

print('=' * 78)
print('A. 停顿类符号 → 逗号（不念符号，但语气停顿留着）')
print('=' * 78)
for src, want in [('他说……然后走了。', '他说，然后走了。'),
                  ('……', '，'),
                  ('等等…', '等等，'),
                  ('他等了很久......', '他等了很久，'),
                  ('等等。。。', '等等，'),
                  ('——破折号——', '，破折号，'),
                  ('～～～', '，'),
                  # 整句只有标点：没有任何可读内容 → 留一个逗号（合成一小段静音），
                  # 不能返回空串，否则 _call_one 会以为「没有可合成的文本」直接抛错
                  ('???', '，')]:
    got = S(src)
    ck('%r → %r' % (src, got), got == want, '' if got == want else '实际 %r' % got)

print()
print('=' * 78)
print('B. 装饰 / 噪声符号 → 删掉')
print('=' * 78)
for src, want in [('※', '，'),                     # 整句都是符号：留逗号，不能空
                  ('※※※', '，'),
                  ('＃标题＃', '标题'),
                  ('☆第一章★', '第一章'),
                  ('★★★★★ 五星好评 ★★★★★', '五星好评'),
                  ('a※b＊c＃d', 'abcd'),
                  ('→ 箭头 ←', '箭头'),
                  ('♥♠♣♦', '，'),
                  ('🙂emoji🎉', 'emoji'),
                  ('§1.1 概述', '1.1 概述')]:
    got = S(src).strip()
    ck('%r → %r' % (src, got), got == want, '' if got == want else '实际 %r' % got)

print()
print('=' * 78)
print('C. 有明确读法的「数字 + 符号」→ 换成词（顺序照中文）')
print('=' * 78)
for src, want in [('50%的人', '百分之50的人'),
                  ('12.5%', '百分之12.5'),
                  ('气温 30℃ 左右', '气温 30摄氏度 左右'),
                  ('角度 45°', '角度 45度'),
                  ('0°C', '0摄氏度'),
                  ('价格￥100', '价格100')]:
    got = S(src)
    ck('%r → %r' % (src, got), got == want, '' if got == want else '实际 %r' % got)

print()
print('=' * 78)
print('D. 正常标点 / 文字一个都不能动（别顺手删过头）')
print('=' * 78)
for src in ['中文，标点！', '「引号」与（括号）都留着；还有：分号、顿号、问号？',
            '1,234 与 3.14', '弗拉基米尔·普京', 'α β γ', '①②③ 有效',
            '中华人民共和國，你好！', '英文 U.S. Army 与 Wi-Fi']:
    got = S(src)
    ck('%r 原样保留' % src, got == src, '' if got == src else '实际 %r' % got)

print()
print('=' * 78)
print('E. 不变式：全书每一句清洗后都非空、GBK 安全、句数不变')
print('=' * 78)
BOOK_ID = 383692                       # 与 test_tts_safe_text.py 同一本《魔戒》
raw_sents = []
try:
    import db
    from audiobook import book as B
    _b = dict(db.q('SELECT * FROM books WHERE id=?', (BOOK_ID,), one=True))
    for _ch in B.chapters(_b):
        raw_sents.extend(tts.split_sentences(_ch['text']))
    print('  《%s》共 %d 句' % (_b['title'], len(raw_sents)))
except Exception as e:
    print('  [跳过] 取书失败：%s' % e)
if raw_sents:
    sents = raw_sents[:3000]
    ck('取到句子样本', len(sents) > 50, '%d 句' % len(sents))
    empt = [s for s in sents if not S(s).strip()]
    ck('★ 清洗后没有一句变空（变空会让整本书失败）', not empt, '%d 句变空' % len(empt))
    ck('★ 句数不变（在 _call_one 里按句清洗，不动断句）',
       len([S(s) for s in sents]) == len(sents))
    bad = []
    for s in sents:
        t = S(s)
        for v in (t, t.upper(), t.lower()):
            try:
                v.encode('gbk')
            except UnicodeEncodeError:
                bad.append(s)
                break
    ck('★ 清洗后没有一句再含线路编不出的字符', not bad, '剩 %d 句' % len(bad))
    noisy = [s for s in sents if S(s) != s]
    ck('确有句子被清理（说明样本里有这些符号，测试不是空的）', len(noisy) > 0, '%d 句被清理' % len(noisy))
    sample = [s for s in noisy if any(c in s for c in '……※＃＊★')][:3]
    for s in sample:
        print('      样本：%r → %r' % (s, S(s)))
else:
    print('  [跳过] 本书正文取不到，只跑纯函数断言')

print()
print('=' * 78)
print('F. 幂等：清洗两次结果一致（重复清洗不会越删越多）')
print('=' * 78)
for src in ['他说……然后走了。', '※※※', '50%的人 30℃', '★★★★★ 好评 ★★★★★', '中文，标点！']:
    once, twice = S(src), S(S(src))
    ck('%r 幂等' % src, once == twice, '' if once == twice else '%r ≠ %r' % (once, twice))

print()
print('=' * 78)
print('G. 端到端：两条真实调用链发出去的文本都已净化（打桩，不联网）')
print('=' * 78)
SENT = '他低声说：“嗯……那很重要。※※※ ＃重点＃”然后就走开了。'
EXPECT_NO = '……※＃＊★'

# G1 批量制作那条路：audiobook.speech.synth → tts.call_tts
try:
    from audiobook import speech as SP
    _real = tts.call_tts
    box = []

    def _fake(text, voice=None, cfg=None, line=None):
        box.append(text)
        return b'\x00' * 64, None, (line or 'stub')

    tts.call_tts = _fake
    try:
        SP.synth(SENT, 'pool_49', 'http://127.0.0.1:1', None)
        got = box[0] if box else ''
        ck('制作链（audiobook.speech.synth）发出的文本已无噪声符号',
           got and not any(c in got for c in EXPECT_NO), got)
        ck('制作链仍保留中文与正常标点', '那很重要' in got and '“' in got, got)
    except Exception as e:
        ck('制作链（audiobook.speech.synth）发出的文本已无噪声符号', False, repr(e))
    finally:
        tts.call_tts = _real
except Exception as e:
    ck('制作链可用', False, repr(e))

# G2 在线听书那条路：tts._call_one 直接发 HTTP（把 urlopen 换成桩）
try:
    import urllib.request
    import json as _json
    _real_open = urllib.request.urlopen
    seen = []

    class _Resp:
        headers = {'X-Gen-Seconds': '0.1'}

        def read(self):
            return b'OggS' + b'\x00' * 32

        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False

    def _fake_open(req, timeout=None):
        seen.append(_json.loads(req.data.decode('utf-8')))
        return _Resp()

    urllib.request.urlopen = _fake_open
    try:
        srv = {'name': 'stub', 'url': 'http://127.0.0.1:1', 'key': '', 'model': 'indextts-2'}
        cfg = {'model': 'indextts-2', 'timeout': 5}
        tts._call_one(srv, SENT, 'pool_49', cfg, 5)
        text = seen[0]['text'] if seen else ''
        ck('听书链（tts._call_one）发出的文本已无噪声符号',
           text and not any(c in text for c in EXPECT_NO), text)
        ck('听书链仍保留中文与正常标点', '那很重要' in text and '“' in text, text)
    except Exception as e:
        ck('听书链（tts._call_one）发出的文本已无噪声符号', False, repr(e))
    finally:
        urllib.request.urlopen = _real_open
except Exception as e:
    ck('听书链可用', False, repr(e))

print()
print('=' * 78)
print('通过 %d / 失败 %d' % (_pass[0], _fail[0]))
print('=' * 78)
sys.exit(1 if _fail[0] else 0)
