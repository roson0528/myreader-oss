# -*- coding: utf-8 -*-
"""听书管理：每条线路（=一台启用的 TTS 服务器）的音色与分组权限。

这一层是**叠加在各台服务器 /voices 之上的管理信息**，不改 TTS 服务端：

    服务器 /voices 给出「这台机器物理上有哪些音色」
    本模块叠加  →  重命名、启用/停用、删除（内置=隐藏，定制=真的删）
                   排序、以及「哪些分组可以用这条线路」

为什么要单独一层：/voices 是机器的事实，而「叫什么名字、开不开、给谁用」是站点的
运营策略。两者寿命不同 —— 换一台机器事实就变了，策略却应该留下来。

存储：system_config['tts_line_admin']，一个 JSON：

    {"lines": {"<url>": {
        "groups": [1, 2],            # 允许的分组 id；缺省/空 = 所有分组都能用
        "deleted": ["pool_07"],      # 已删除的内置音色（从可见清单里去掉）
        "order": ["pool_49", ...],   # 手工排序，未列出的排在后面
        "voices": {"<vid>": {"name": "沉稳定音", "on": 0, "custom": 1,
                             "text": "样板里念的那句话"}}
    }}}

以 url 为键（而不是线路显示名）：显示名随时能改，url 才是这台机器的身份。
"""
import json
import threading
import time

import db

KEY = "tts_line_admin"
_LOCK = threading.Lock()


# ------------------------------------------------------------------ 读写
def load():
    """读整份配置。坏数据一律当空，不能让管理页被一条坏 JSON 卡死。"""
    raw = db.get_config(KEY, "") or ""
    if not raw:
        return {"lines": {}}
    try:
        d = json.loads(raw)
        if not isinstance(d, dict):
            return {"lines": {}}
        d.setdefault("lines", {})
        if not isinstance(d["lines"], dict):
            d["lines"] = {}
        return d
    except Exception:
        return {"lines": {}}


def save(d):
    with _LOCK:
        db.set_config(KEY, json.dumps(d, ensure_ascii=False))


def line_cfg(d, url):
    """取某条线路的配置块（不存在就返回空块，不写库）"""
    c = (d.get("lines") or {}).get(url) or {}
    return {
        "groups": list(c.get("groups") or []),
        "deleted": list(c.get("deleted") or []),
        "order": list(c.get("order") or []),
        "voices": dict(c.get("voices") or {}),
    }


def _ensure(d, url):
    d.setdefault("lines", {})
    c = d["lines"].setdefault(url, {})
    c.setdefault("groups", [])
    c.setdefault("deleted", [])
    c.setdefault("order", [])
    c.setdefault("voices", {})
    return c


# ------------------------------------------------------------------ 音色视图
def _disambiguate(rows):
    """服务器标签重名时补上编号。

    GPT-SoVITS 的 60 个音色里 57 个标签都叫「男声」/「女声」，
    后台一屏下去没法管、播放页也没法选。补成「男声 17」至少能区分。
    后台显式改过名（renamed）的不动 —— 那是人的决定。
    """
    import re
    cnt = {}
    for r in rows:
        cnt[r["name"]] = cnt.get(r["name"], 0) + 1
    for r in rows:
        if r.get("renamed") or cnt.get(r["name"], 0) < 2:
            continue
        m = re.search(r"(\d+)\s*$", r.get("id") or "")
        if m:
            r["name"] = "%s %s" % (r["name"], m.group(1))
    return rows


def apply_overrides(url, voices, c=None, model=None):
    """把管理层的覆盖应用到一台机器的原始音色清单上。

    voices 是 /voices 的原始列表（每项含 id/label/gender/f0/source）。
    model 是这条线路的模型 —— 名字要靠它去挑对应的「流行音色样板」表。

    返回新列表，每项额外带上：
        name    —— 显示名（后台改名 > 样板表中文名 > 服务器标签）
        renamed —— 后台是否显式改过名
        on      —— 是否启用（0/1）
        custom  —— 是否是我们上传的定制音色

    ★ 显示名必须和播放页用同一个口径（tts.display_name）。以前这里直接用
    服务器标签，于是同一个音色后台叫「#01」「男声」、播放页叫「帝王音」
    「古风男声」，管理员根本对不上号。
    """
    import tts
    c = c if c is not None else line_cfg(load(), url)
    deleted = set(c["deleted"])
    ov = c["voices"]
    out = []
    for v in voices:
        vid = v.get("id")
        if not vid or vid in deleted:
            continue
        o = ov.get(vid) or {}
        rename = (o.get("name") or "").strip()
        out.append(dict(
            v,
            name=tts.display_name(model, vid, v.get("label"), rename),
            # 后台显式改过名 → 前端的「流行音色样板名」不许再盖掉它
            renamed=1 if rename else 0,
            on=0 if o.get("on") == 0 else 1,
            custom=1 if (o.get("custom") or v.get("source") == "custom") else 0,
            line=url,
        ))
    _disambiguate(out)
    # 手工排序：order 里列出的按顺序排前面，其余保持原序
    order = c["order"]
    if order:
        pos = {x: i for i, x in enumerate(order)}
        out.sort(key=lambda x: pos.get(x["id"], len(pos)))
    return out


def voices_for_lines(cfg=None, force=False, for_user=None, wait=True):
    """所有线路的音色，按线路分组。用于管理页和客户端的「选音色」列表。

    for_user 非空时只保留该用户所在分组**允许使用**的线路（见 groups_allowed）。

    ★ wait=False 是给**热路径**用的（/listen/seg 的音色合法性校验）：
    那时绝不能因为某台机器的音色清单过期就同步发 HTTP —— 见 tts.voices_of_server
    的说明，TTS 主机合成期间会把 /voices 挂起 20 秒以上。
    """
    import tts
    cfg = cfg or tts.settings()
    d = load()
    lines = []
    for srv in tts.active_servers(cfg):
        url = srv.get("url")
        c = line_cfg(d, url)
        if for_user is not None and not groups_allowed(c, for_user):
            continue
        raw = tts.voices_of_server(srv, cfg, force=force, wait=wait)
        # 白名单之外的本来就不该出现在这条线路上
        white = tts.white_of(srv, cfg)
        if white:
            keep = set(white)
            raw = [v for v in raw if v.get("id") in keep]
        vs = apply_overrides(url, raw, c, srv.get("model"))
        lines.append({
            "url": url,
            "name": srv.get("name") or url,
            "model": srv.get("model") or "",
            "groups": c["groups"],
            "custom_ok": supports_custom(srv),
            "voices": vs,
            "count": len(vs),
            "on_count": sum(1 for v in vs if v["on"]),
        })
    return lines


# ------------------------------------------------------------------ 分组权限
def ug(user, key, default=None):
    """从 user 里安全取一个字段。

    ★ user 是 sqlite3.Row，**没有 .get()**。以前这里写 user.get("group_id")，
    抛出的 AttributeError 又被 `except Exception: return True` 吞掉，
    于是分组权限永远「全放行」—— 界面上勾了也没用。这类「宽 except 把逻辑错误
    吃成默认值」的写法，正是权限功能最危险的失败模式，所以这里显式取值。
    """
    if user is None:
        return default
    try:
        v = user[key]
    except (KeyError, IndexError, TypeError):
        try:
            v = user.get(key, default)      # 普通 dict 也能传进来
        except Exception:
            return default
    return default if v is None else v


def groups_allowed(c, user):
    """这条线路对某用户是否开放。没配分组 = 所有登录用户都能用。"""
    gs = c.get("groups") or []
    if not gs:
        return True
    try:
        return int(ug(user, "group_id", 0) or 0) in {int(x) for x in gs}
    except (TypeError, ValueError):
        return True


def line_allowed(url, user, cfg=None):
    return groups_allowed(line_cfg(load(), url), user)


def line_of_user(name, user, cfg=None):
    """线路名/url → url，但必须对该用户开放；不可用返回空串（调用方退回自动）。"""
    import tts
    cfg = cfg or tts.settings()
    d = load()
    for srv in tts.active_servers(cfg):
        if (srv.get("url") == name) or (srv.get("name") == name):
            if groups_allowed(line_cfg(d, srv["url"]), user):
                return srv["url"]
            return ""
    return ""


# ------------------------------------------------------------------ 定制音色
def supports_custom(srv):
    """这台机器能不能定制音色。

    只有**零样本克隆**的模型才行：音色在它们那里就是一段参考音频，
    换一段音频就是一个新音色。
      · indextts-2   —— 参考 wav 直接当 spk_audio_prompt（.3 / .6:8500）
      · gpt-sovits-v2—— 参考音频 + 它的文本（.16）
    piper 是固定预训练的声学模型，换音色要重新训练，**不支持定制**。
    """
    m = (srv.get("model") or "").lower()
    return m in ("indextts-2", "gpt-sovits-v2", "gpt-sovits")


def needs_transcript(srv):
    """定制时是否必须填「样板里念的那句话」。GPT-SoVITS 带参考文本又快又准。"""
    return (srv.get("model") or "").lower().startswith("gpt-sovits")


# ------------------------------------------------------------------ 改动
def _mut(url, fn):
    d = load()
    c = _ensure(d, url)
    fn(c)
    save(d)
    return c


def rename(url, vid, name):
    name = (name or "").strip()
    return _mut(url, lambda c: c["voices"].setdefault(vid, {}).__setitem__("name", name))


def set_on(url, vid, on):
    return _mut(url, lambda c: c["voices"].setdefault(vid, {}).__setitem__("on", 1 if on else 0))


def hide(url, vid):
    """内置音色只能「删除即隐藏」——它在服务器上还在，我们不再列出来。"""
    def f(c):
        if vid not in c["deleted"]:
            c["deleted"].append(vid)
        c["voices"].pop(vid, None)
    return _mut(url, f)


def unhide(url, vid):
    return _mut(url, lambda c: (c["deleted"].remove(vid) if vid in c["deleted"] else None))


def forget(url, vid):
    """定制音色在服务器上删掉之后，把本地覆盖也清掉"""
    def f(c):
        c["voices"].pop(vid, None)
        if vid in c["order"]:
            c["order"].remove(vid)
        if vid in c["deleted"]:
            c["deleted"].remove(vid)
    return _mut(url, f)


def remember_custom(url, vid, name="", text=""):
    def f(c):
        o = c["voices"].setdefault(vid, {})
        o["custom"] = 1
        if name:
            o["name"] = name
        if text:
            o["text"] = text
        if vid not in c["order"]:
            c["order"].insert(0, vid)     # 新定制的排最前，方便马上试听
    return _mut(url, f)


def set_groups(url, ids):
    ids = sorted({int(x) for x in (ids or [])})
    return _mut(url, lambda c: c.__setitem__("groups", ids))
