// 「回到听书」悬浮按钮
// ---------------------------------------------------------------------------
// 场景：在播放页点「后台」后，APP 会跳到图书详情/书库等其它页面，而声音由
// 原生的 PlaybackService 继续在后台播。此时用户想回到播放页，得自己重新找到
// 那本书再点听书 —— 很绕。这个按钮在任何页面都能一键回去。
//
// 只在「确实有一本书挂在后台播放服务上」的时候出现：
//   · 必须装的是有原生播放的 APK（插件 status() 返回 version >= 2），旧版没有原生播放，
//     网页离开播放页就等于停了，显示这个按钮只会误导；
//   · 非 APP 环境（浏览器）没有 ListenService，直接不显示。
//
// ★ version 一律用 >= 判断，不要用 ==。
//   listen.js 里同一个判断也踩过这个坑：插件从 2 抬到 3 之后，
//   写成 == 2 的地方会把「装了新 APK 的用户」全判成旧版 —— 表现为按钮凭空消失，
//   而且不报错、不留日志，极难发现。加原生能力时版本号只会往上走，
//   判定条件必须跟着放宽，而不是跟着改数字。
//
// 播放页自己不显示（那边本来就在听书，不需要「回到」）。
// ---------------------------------------------------------------------------
(function () {
  'use strict';

  var EMOJI = '🎧';          // 听书 = 耳机
  var POLL_MS = 3000;        // 兜底轮询；原生状态变化会主动回调，通常更快

  var btn = null;
  var shown = false;
  var bookId = 0;

  function plugin() {
    try {
      var C = window.Capacitor;
      if (C && C.Plugins && C.Plugins.ListenService) return C.Plugins.ListenService;
    } catch (e) {}
    return null;
  }

  function build() {
    if (btn || !document.body) return btn;
    var css = document.createElement('style');
    css.textContent =
      '#bm-backtolisten{' +
      'position:fixed;right:14px;z-index:60;' +
      // 让开底部导航（APP 里有 tabbar，约 60px）与 iPhone 安全区
      'bottom:calc(74px + env(safe-area-inset-bottom,0px));' +
      'width:46px;height:46px;border-radius:50%;' +
      'display:none;align-items:center;justify-content:center;' +
      'font-size:22px;line-height:1;cursor:pointer;' +
      'background:linear-gradient(135deg,#4f46e5,#7c3aed);' +
      'box-shadow:0 6px 18px rgba(79,70,229,.42);' +
      'user-select:none;-webkit-user-select:none;-webkit-tap-highlight-color:transparent;' +
      'transition:transform .15s,opacity .2s;opacity:0;}' +
      '#bm-backtolisten.show{display:flex;opacity:1;}' +
      '#bm-backtolisten:active{transform:scale(.9);}';
    document.head.appendChild(css);

    btn = document.createElement('div');
    btn.id = 'bm-backtolisten';
    btn.textContent = EMOJI;
    btn.setAttribute('role', 'button');
    btn.setAttribute('aria-label', '回到听书');
    btn.title = '回到听书';
    btn.onclick = function () {
      if (!bookId) return;
      location.href = '/listen?id=' + bookId;
    };
    document.body.appendChild(btn);
    return btn;
  }

  function show(on) {
    if (on === shown) return;
    shown = on;
    var b = build();
    if (b) b.classList.toggle('show', on);
  }

  function apply(st) {
    // 有书挂在后台播放服务上就显示（暂停中也显示 —— 用户可能只是按了暂停，
    // 更可能想回去继续听，藏起来反而找不到入口）。
    // ★ 用 >= 而不是 ==：插件版本是会往上加的（2 = 原生播放，3 = 多了蓝牙联动开关），
    //   写死等于 2 会在升级 APK 后让这个按钮彻底消失。
    var ver = st ? Number(st.version) || 0 : 0;
    var ok = !!(ver >= 2 && st.active && st.bookId);
    if (ok) bookId = st.bookId;
    show(ok);
  }

  function tick() {
    if (/^\/listen(\.html)?$/.test(location.pathname)) { show(false); return; }
    var P = plugin();
    if (!P) { show(false); return; }
    try {
      Promise.resolve(P.status()).then(apply, function () { show(false); });
    } catch (e) { show(false); }
  }

  // 原生每次状态变化都会调这个全局函数（ListenPlugin.onState → evaluateJavascript），
  // 所以按钮的出现/消失基本是实时的，轮询只是断电兜底。
  window.__laoshuPlayerState = function (st) { apply(st); };

  function boot() {
    build();
    tick();
    setInterval(tick, POLL_MS);
    // 从后台切回前台时立刻对一次，避免显示过期状态
    document.addEventListener('visibilitychange', function () {
      if (!document.hidden) tick();
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
