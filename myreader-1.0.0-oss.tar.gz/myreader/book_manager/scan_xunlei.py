# -*- coding: utf-8 -*-
"""扫描 /迅雷/电子书 全部电子书文件（SFTP，防超时的大目录扫描），存结果 JSON。
用法: python3 scan_xunlei.py
输出: data/xunlei_files.json  {"files":[{path,size}...], "total_entries":n}
"""
import os, sys, json, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config, paramiko

HOST, PORT, USER, PWD = config.SFTP_HOST, config.SFTP_PORT, config.FTP_USER, config.FTP_PASS
BASE = "/迅雷/电子书"
OUT = os.path.join(config.DATA_DIR, "xunlei_files.json")

def main():
    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    c.connect(HOST, port=PORT, username=USER, password=PWD, timeout=30,
              allow_agent=False, look_for_keys=False)
    s = c.open_sftp()
    files, dirs, errors = [], 0, []
    t0 = time.time()

    def walk(path, rel, depth):
        nonlocal dirs
        if depth > 30:
            return
        try:
            entries = s.listdir_attr(path)
        except Exception as e:
            errors.append((rel, str(e)))
            return
        for e in entries:
            if e.filename in ('.', '..', '@eaDir', '#recycle', '.bt'):
                continue
            r = rel + '/' + e.filename if rel else e.filename
            isdir = bool(e.st_mode & 0o040000) if e.st_mode else False
            if isdir:
                dirs += 1
                walk(path + '/' + e.filename, r, depth + 1)
            else:
                files.append({'path': r, 'size': e.st_size})
        if len(files) % 5000 == 0 and files:
            print('  已发现 %d 个文件 耗时 %.0fs' % (len(files), time.time() - t0), flush=True)

    print('开始扫描 %s ...' % BASE, flush=True)
    walk(BASE, '', 1)
    c.close()
    with open(OUT, 'w', encoding='utf-8') as f:
        json.dump({'base': BASE, 'files': files, 'total_entries': len(files), 'dirs': dirs,
                   'errors': errors[:50], 'elapsed': round(time.time() - t0, 1)}, f,
                  ensure_ascii=False)
    print('完成: 文件=%d 目录=%d 耗时=%.1fs 错误=%d → %s'
          % (len(files), dirs, time.time() - t0, len(errors), OUT), flush=True)

if __name__ == '__main__':
    main()