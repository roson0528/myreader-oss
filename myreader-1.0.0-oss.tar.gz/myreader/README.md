# 云阅读 · myreader

自托管的电子书书库与在线阅读平台：把散落在 WebDAV / FTP / NAS 上的电子书收进一个统一书库，在浏览器、手机、平板上直接打开就能读，还能听、能分享、能做阅读统计。

后端是 **FastAPI + SQLite**，前端是 **原生 HTML/CSS/JS（零构建）**——没有 npm、没有打包、没有框架，改完刷新就是最新的。

> 本仓库是**开源脱敏版**：真实域名、内网 IP、账号口令、品牌名、服务器路径均已替换为占位值，存储凭据全部改为环境变量。详见 [docs/SANITIZE.md](docs/SANITIZE.md)。

---

## 一、功能概览

### 阅读

- **多格式在线阅读**：EPUB / MOBI / AZW / AZW3 / PDF / TXT / Markdown / DOCX / FB2 / CHM 等 40+ 后缀（EPUB 走解析管线、TXT/MD/DOCX 分章分页、PDF 用 pdf.js 渲染、MOBI/AZW3 自动转 EPUB）。
- **移动端优先**：目录抽屉、手势翻页、字号/行距/主题（日间·夜间·护眼·羊皮纸）、阅读进度云端同步；Markdown 表格在窄屏下可横向滑动，不撑破排版。
- **极简模式**：给 Kindle 等老设备准备的纯文本页（`/lite`），无脚本、体积小。
- **听书**：文本自动分句 → TTS 合成 → 串行队列 + 音频缓存，支持章节跳转、逐句高亮、后台播放；多 TTS 线路可按用户组授权。
- **沉浸式体验**：阅读时长统计、阅读目标、屏幕常亮、返回听书位置。

### 书库

- **存储后端抽象**：WebDAV 为主（连接可复用、原生 UTF-8），FTP / SFTP 兜底，一套接口到处用。
- **导入与同步**：定时同步书库目录的增删改；支持从下载目录批量分类入库；按内容哈希去重（size 预筛 → 全文件 MD5）。
- **元数据与封面**：EPUB 内嵌元数据解析、封面提取/刮削、简介生成、同名/相似书检索。
- **技术报告投放区**：本地一个文件夹（默认 `/srv/myreader/report`）就是真源——丢进去的 Markdown/TXT/DOCX 自动变成书架上的书，**改了立刻能读到最新内容，删了书也跟着消失**。

### 社区与运营

- 书单讨论（文章 + 内嵌图片）、站内消息、第三方推送（Server酱）。
- 分享：单本书生成分享页（可设提取码、有效期），受控下载。
- 会员与额度：用户组、配额、邀请码、推广奖励、签到积分。
- 统计：访问量、下载量、阅读时长按天聚合，落 WebDAV 保留三年。

### 运维

- 数据库自动备份、缓存清理、空书清理。
- 全站缓存策略：静态资源版本化，书籍内容接口 `no-store`，改完立刻生效。

---

## 二、技术栈

| 层 | 选型 |
| --- | --- |
| Web 框架 | FastAPI（同步路由 + 少量异步依赖） |
| 数据库 | SQLite（WAL，单文件，无 ORM） |
| 前端 | 原生 HTML/CSS/JS，无构建步骤 |
| 认证 | JWT（HS256）+ 口令散列 |
| 存储 | WebDAV / FTP / SFTP（可混用） |
| 文档解析 | zipfile + xml（EPUB）、pdf.js（PDF）、Markdown、docx、calibre `ebook-convert`（可选）、`catdoc`（可选） |
| 媒体 | ffmpeg（有声书混音/转码，可选） |

Python **3.10+**（开发与生产在 3.13 / 3.14 上跑过）。

---

## 三、目录结构

```
.
├── book_manager/                    # 主服务
│   ├── app.py                       # FastAPI 应用：路由、鉴权、中间件（约 4700 行，160 个接口）
│   ├── config.py                    # 配置（存储、目录、默认管理员、支持的格式）
│   ├── db.py                        # SQLite 数据访问层 + 建表 + 迁移
│   ├── auth.py                      # 口令散列、JWT 签发校验、角色与可见性
│   ├── ftp_service.py               # 存储后端封装（WebDAV 主 / FTP / SFTP 兜底）
│   ├── formats.py                   # EPUB 解析，供封面/简介/阅读共用
│   ├── reader.py                    # 在线阅读管线：章节切分、分段返回、正文渲染
│   ├── covers.py                    # 封面提取与本地缓存（含新鲜度判定）
│   ├── sync.py / seed.py            # 书库同步、种子导入
│   ├── dedup.py / similar.py        # 去重、相似书检索
│   ├── tts.py / listen_admin.py     # 听书合成、线路与音色授权
│   ├── reading_stats.py / stats.py  # 阅读统计、站点统计
│   ├── booklists.py / promote.py    # 书单讨论、推广邀请
│   ├── notify.py / activity.py      # 站内消息与推送、活动日志
│   ├── report_sync.py               # 技术报告投放区 → 书架（真源同步 + 回收）
│   ├── lite.py                      # 极简模式（Kindle）页面
│   ├── audiobook/                   # 有声书：数据层、接口、混音、播放进度
│   ├── static/                      # 前端：index/reader/listen/share/admin + style.css + vendor
│   ├── tests/                       # 回归测试（Python 断言式 + Node 断言式）
│   ├── tools/                       # 运维小工具（缓存清理、空书清理、看门狗）
│   └── requirements.txt / start.sh
├── ebook_task/                      # 书库扫描与分类（CLC 二十二大类）
│   ├── scan.py / classify.py        # SFTP 递归扫描、按中文分类法归类命名
│   ├── engine.py                    # 分类后 MOVE 进书库目录的执行器
│   └── report.py / retry_failed.py
└── docs/                            # 架构、部署、接口、脱敏说明
```

---

## 四、快速开始

### 1. 系统依赖（按需）

```bash
# 可选，缺了只是少部分能力（会优雅降级）
apt install -y ffmpeg catdoc          # 有声书混音、.doc 读取
# calibre（ebook-convert）用于 mobi/azw3 → epub 转换，可选
```

### 2. 装依赖

```bash
python3 -m venv venv
./venv/bin/pip install -r requirements.txt
```

### 3. 配置

```bash
cp .env.example .env
$EDITOR .env      # 至少填存储后端与 JWT 密钥（start.sh 会自动加载 .env）
```

关键环境变量：

| 变量 | 说明 | 默认 |
| --- | --- | --- |
| `BOOKMGR_SECRET` | JWT 签名密钥，**上线必改** | `dev-secret-please-change` |
| `BOOKMGR_FTP_HOST` / `_PORT` / `_USER` / `_PASS` / `_BASE` | 存储后端地址与凭据 | `127.0.0.1` / `21` / `bookadmin` / 空 / `/books` |
| `BOOKMGR_WEBDAV_HOST` / `_PORT` | WebDAV 后端（默认复用 FTP 主机） | 同 FTP / `5005` |
| `BOOKMGR_SFTP_HOST` / `_PORT` | SFTP 兜底 | 同 FTP / `22` |
| `BOOKMGR_ADMIN_USER` / `_PASS` | 首次启动创建的管理员 | `admin` / `admin123` |
| `BOOKMGR_LINK_BASE` | 下载通道域名（下载/App 用；留空=同源） | 空 |
| `BOOKMGR_REPORT_DIR` / `_OWNER` / `_COLLECTION` | 技术报告投放区 | `/srv/myreader/report` / `admin` / `技术报告` |
| `BOOKMGR_SAMPLE_BOOK_ID` | 游客试读的书 ID（0=关闭） | `0` |

### 4. 建库并启动

```bash
cd book_manager
../venv/bin/python -c "import db; db.init_db()"   # 建表
bash start.sh                                     # 默认 0.0.0.0:9000
```

浏览器打开 <http://127.0.0.1:9000>，用 `BOOKMGR_ADMIN_USER` / `BOOKMGR_ADMIN_PASS` 登录，**第一件事就是改掉默认口令**。

书库为空时，可以：

```bash
# 从存储后端的分类目录导入（幂等）
../venv/bin/python seed.py
# 或让投放区自动上架：把 md/txt/docx 丢进 $BOOKMGR_REPORT_DIR
../venv/bin/python report_sync.py --dry-run      # 预览
../venv/bin/python report_sync.py                # 正式同步
```

生产部署（systemd、反向代理、备份、cron）见 [docs/DEPLOY.md](docs/DEPLOY.md)。

---

## 五、设计要点

- **书源即真源**：书库目录/投放区里文件没了，书架上的书也跟着回收（连后端副本、进度、笔记一起清），不会出现「书架有、文件没了」的僵尸条目。
- **缓存新鲜度**：本地内容缓存不只比文件大小，还比 `books.updated_at` 与缓存 mtime——改几个字但字节数不变的文档也能读到最新版。
- **无构建前端**：静态资源用 `?v=` 版本号 + 中间件 `no-store`，避免「改了代码用户还是旧页面」。
- **权限模型**：角色（管理员/作家/普通）+ 用户组（分享、发表、听书线路等能力开关）+ 书籍可见性（私有/组内/公开）。

---

## 六、接口

160 个 HTTP 接口，按前缀分组：`/api/books/*`（书库与阅读，42 条）、`/api/audiobook/*`、`/api/booklist/*`、`/api/admin/*`、`/api/me/*`、`/api/share/*` 等。完整清单见 [docs/API.md](docs/API.md)。

鉴权：`Authorization: Bearer <JWT>`；`GET /api/login` 拿令牌，`GET /api/me` 验证。

---

## 七、回归测试

`book_manager/tests/` 下是断言式脚本（不依赖 pytest），Python 测试直接跑，前端测试用 Node + vm 模拟 DOM：

```bash
cd book_manager
../venv/bin/python tests/test_report_sync.py     # 报告同步 / 回收 / 新鲜度
../venv/bin/python tests/test_md_tables.py       # Markdown 表格排版
../venv/bin/python tests/test_reading_stats.py   # 阅读统计
../venv/bin/python tests/test_lite_preset.py     # 极简页设备预设
node tests/test_share_similar_ui.js              # 前端交互（需要 node）
```

部分测试需要预先准备数据（测试账号、样例书），文件头都写明了前置条件。

---

## 八、安全须知

1. **上线前必改**：`BOOKMGR_SECRET`、`BOOKMGR_ADMIN_PASS`、存储后端口令。
2. **不要提交凭据**：仓库只带 `.env.example`，真实 `.env` 已在 `.gitignore` 中。
3. **文件上传**：仅授权用户可上传，文件名会清洗，落地在存储后端的独立目录。
4. **分享链接**：走站内 `/share/<token>`，可设提取码与有效期。

发现安全问题请私信维护者，不要直接开公开 issue。

---

## 九、许可与第三方

- 本项目代码：**MIT**，见 [LICENSE](LICENSE)。
- 第三方组件：`static/vendor/` 下的 pdf.js（Apache-2.0），详见 [docs/THIRD-PARTY.md](docs/THIRD-PARTY.md)。
- 书库中的书籍版权归各自权利人所有，本项目只提供管理工具，请勿用于侵权分发。
