// 手机端「有声播放页」的文本区高度：加高、底框拉到最底。
//
// 需求（2026-10-11）：手机 Web 和 APP 端的有声播放页面，下面的文本显示区域加高，
// 把底框拉到最底。
//
// 改法（style.css ≤820px）：播放页做成一列定高布局（navbar + content 都是 flex 列），
// 文本区 `.ap-textwrap` 由固定 46vh/40vh 改成 flex:1 吃掉剩余高度；播放页本来就没有
// 底部导航（showView 对 audioplay 调 setTabbar(false)），所以去掉 .content 给 tabbar
// 预留的 90px 底部内边距。
//
// 本测试验的是**几何结果**，不是「CSS 里有没有那句话」：
//   1. 手机视口下文本区底边贴到屏幕底部（留 10px 内边距之内）；
//   2. 它比原来的 40vh 明显更高（真的加高了）；
//   3. 整页不再出现滚动（文本区自己内部滚）；
//   4. 底部导航此时是隐藏的（不然「拉到最底」会被导航盖住）；
//   5. 桌面视口下**保持不变**（仍是 ~46vh，没有被我改坏）；
//   6. 用 ID 选择器写 display:flex 不能把隐藏视图顶出来（.hidden 是 !important，
//      这里实测一遍，防止以后有人把 !important 去掉）。
//
// 只读：不造数据、不改配置，只用管理员账号打开一次播放页（会留一条 ab_session
// 单端锁，跑完按 user_id 删掉，和 test_audio_ui.js 的做法一致）。
// 运行：NODE_PATH=/tmp/pwtest/node_modules node tests/test_audio_text_height.js
const { chromium } = require('playwright-core');
const { execSync } = require('child_process');
const CHROME = '/srv/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome';
const ROOT = '/srv/myreader/book_manager';
const BASE = 'https://127.0.0.1:9000';

let pass = 0, fail = 0;
const ck = (n, ok, extra) => {
  if (ok) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (extra ? '  → ' + extra : '')); }
};
const py = (code) => execSync('venv/bin/python -', { cwd: ROOT, encoding: 'utf8', input: code }).trim();

// 取播放页几何：文本区矩形、视口、整页是否可滚、底部导航是否显示
const geom = (page) => page.evaluate(() => {
  const el = document.getElementById('aup-texts');
  const r = el ? el.getBoundingClientRect() : null;
  const tab = document.getElementById('tabbar');
  const tabVisible = !!tab && getComputedStyle(tab).display !== 'none';
  return {
    vw: window.innerWidth, vh: window.innerHeight,
    top: r ? Math.round(r.top) : null,
    bottom: r ? Math.round(r.bottom) : null,
    h: r ? Math.round(r.height) : null,
    scrollable: el ? (el.scrollHeight > el.clientHeight + 4) : false,
    pageScroll: document.documentElement.scrollHeight - window.innerHeight,
    tabVisible,
    // 隐藏视图守卫：这些都该是 display:none
    hiddenOk: ['view-main', 'view-detail', 'view-audio', 'view-intro', 'view-write']
      .every(id => {
        const e = document.getElementById(id);
        return !e || getComputedStyle(e).display === 'none';
      }),
    playVisible: getComputedStyle(document.getElementById('view-audioplay')).display !== 'none',
  };
});

(async () => {
  const info = JSON.parse(py(`
import sys, json
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
import db, auth
u = db.q("SELECT * FROM users WHERE role='admin' AND enabled=1 ORDER BY id LIMIT 1", one=True)
db.ex("DELETE FROM ab_session WHERE user_id=?", (u["id"],))
lib = db.q("SELECT l.id, l.title, l.total_chapters FROM ab_lib l WHERE l.hidden=0 AND l.cover IS NOT NULL AND l.cover <> '' AND (SELECT COUNT(*) FROM ab_lib_seg s WHERE s.lib_id=l.id AND s.chap_seq=1) > 20 ORDER BY l.sort, l.id DESC LIMIT 1", one=True)
print(json.dumps({"token": auth.create_token(u), "uid": u["id"], "lib": dict(lib) if lib else None}))
`));
  ck('库里有可用的有声电子书', !!info.lib, JSON.stringify(info.lib));
  if (!info.lib) { console.log('\n无数据，跳过'); process.exit(1); }
  const LIB = info.lib;

  const b = await chromium.launch({ executablePath: CHROME, args: ['--no-sandbox'] });
  let ctx = null;
  try {
    // ---------- 手机视口（390×844，典型安卓/iPhone 逻辑分辨率）----------
    console.log('== 1. 手机 390×844：文本区底边贴到屏幕底部 ==');
    ctx = await b.newContext({ ignoreHTTPSErrors: true, viewport: { width: 390, height: 844 } });
    await ctx.addInitScript(([tk, uid]) => {
      localStorage.setItem('bm_token', tk);
      localStorage.setItem('bm_user', JSON.stringify({ id: uid, role: 'admin', name: 'admin' }));
      try { sessionStorage.setItem('bm_audio_sid', 'fixtxth'); } catch (e) {}
    }, [info.token, info.uid]);
    let page = await ctx.newPage();
    const errs = [];
    page.on('pageerror', e => errs.push(String(e).slice(0, 140)));
    await page.goto(BASE + '/', { waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(2200);
    await page.evaluate(([id]) => audioPlay(id, 1, false), [LIB.id]);
    await page.waitForSelector('#aup-texts', { timeout: 20000 });
    await page.waitForTimeout(1500);      // 等分句渲染 + 首次定位

    let g = await geom(page);
    console.log(`    vh=${g.vh}  文本区 top=${g.top} bottom=${g.bottom} 高=${g.h}  整页可滚=${g.pageScroll}px  底导=${g.tabVisible}`);
    ck('播放页已打开', g.playVisible === true);
    ck('文本区在最底：底边距屏幕底部 ≤12px', g.bottom !== null && g.vh - g.bottom <= 12,
      'vh=' + g.vh + ' bottom=' + g.bottom + ' 差=' + (g.vh - g.bottom) + 'px');
    ck('文本区确实加高了（高于原来的 40vh=' + Math.round(g.vh * 0.4) + 'px，至少占屏 55%）',
      g.h >= g.vh * 0.55, '高=' + g.h + 'px (' + Math.round(g.h * 100 / g.vh) + '% 屏高)');
    ck('文本区内部可滚动（不是被拉长到整段正文都摊开）', g.scrollable === true);
    ck('整页不出现滚动条（该滚的是文本区，不是整页）', g.pageScroll <= 2, '多出 ' + g.pageScroll + 'px');
    ck('底部导航此时是隐藏的（否则会盖住底框）', g.tabVisible === false);
    ck('其他视图仍然隐藏（用 ID 写 display:flex 没把 .hidden 顶掉）', g.hiddenOk === true);

    // 「回到当前句」按钮仍在文本框内（绝对定位相对的是 .ap-textwrap-wrap）
    const follow = await page.evaluate(() => {
      const btn = document.getElementById('aup-follow');
      const wrap = document.querySelector('.ap-textwrap-wrap');
      if (!btn || !wrap) return null;
      const rb = btn.getBoundingClientRect(), rw = wrap.getBoundingClientRect();
      return { inside: rb.bottom <= rw.bottom + 2 && rb.right <= rw.right + 2, btnBottom: Math.round(rb.bottom), wrapBottom: Math.round(rw.bottom) };
    });
    ck('「回到当前句」按钮仍在文本区范围内', !!follow && follow.inside,
      JSON.stringify(follow));

    // ---------- 桌面视口：不能被改坏 ----------
    console.log('\n== 2. 桌面 1280×900：保持原样（约 46vh）==');
    const ctx2 = await b.newContext({ ignoreHTTPSErrors: true, viewport: { width: 1280, height: 900 } });
    await ctx2.addInitScript(([tk, uid]) => {
      localStorage.setItem('bm_token', tk);
      localStorage.setItem('bm_user', JSON.stringify({ id: uid, role: 'admin', name: 'admin' }));
      try { sessionStorage.setItem('bm_audio_sid', 'fixtxtd'); } catch (e) {}
    }, [info.token, info.uid]);
    const p2 = await ctx2.newPage();
    p2.on('pageerror', e => errs.push('desktop: ' + String(e).slice(0, 140)));
    await p2.goto(BASE + '/', { waitUntil: 'domcontentloaded' });
    await p2.waitForTimeout(2200);
    await p2.evaluate(([id]) => audioPlay(id, 1, false), [LIB.id]);
    await p2.waitForSelector('#aup-texts', { timeout: 20000 });
    await p2.waitForTimeout(1200);
    const g2 = await geom(p2);
    ck('桌面端文本区仍是 46vh（未被手机规则影响）',
      Math.abs(g2.h - g2.vh * 0.46) <= 24, '高=' + g2.h + 'px, 46vh=' + Math.round(g2.vh * 0.46) + 'px');
    ck('桌面端不该贴到屏幕最底', g2.vh - g2.bottom > 40, '差=' + (g2.vh - g2.bottom) + 'px');
    await ctx2.close();

    // ---------- 820px 断点边界 ----------
    console.log('\n== 3. 断点边界 ==');
    await page.setViewportSize({ width: 900, height: 800 });
    await page.waitForTimeout(600);
    const g3 = await geom(page);
    ck('900px 宽（>820）走桌面规则，文本区不再贴底',
      g3.vh - g3.bottom > 40 && Math.abs(g3.h - g3.vh * 0.46) <= 24,
      '高=' + g3.h + ' 距底=' + (g3.vh - g3.bottom));
    await page.setViewportSize({ width: 800, height: 800 });
    await page.waitForTimeout(600);
    const g4 = await geom(page);
    ck('800px 宽（≤820）生效，文本区贴底',
      g4.vh - g4.bottom <= 12, '距底=' + (g4.vh - g4.bottom) + 'px, 高=' + g4.h);

    ck('全程没有 JS 报错', errs.length === 0, errs.join(' | '));
  } finally {
    try { if (ctx) await ctx.close(); } catch (e) {}
    await b.close();
    py(`
import sys
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
import db
db.ex("DELETE FROM ab_session WHERE user_id=?", (${info.uid},))
print("")`);
  }
  console.log('\n通过 ' + pass + '，失败 ' + fail);
  process.exit(fail ? 1 : 0);
})();
