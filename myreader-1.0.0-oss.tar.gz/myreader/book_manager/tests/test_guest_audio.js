// 未登录（游客）状态下「有声阅读」的内容必须完全不可见。
//
// 背景（§14.74）：ablib_api.access_info 里原本写的是 `if user is None:`，
// 但 get_optional_user 对未登录返回的是 **GUEST_USER 字典**（不是 None），
// 所以那个分支从来没生效过 —— 游客能直接列出全部有声书。
// 改成按 uid 判定后才真正挡得住（顺带把 lib_need_login 那个配置项也绕开了）。
//
// 覆盖两层：服务端（列表为空 + 详情/歌词/取票 403）和前端（侧栏隐藏 + 登录提示）。
const { chromium } = require('playwright-core');
const { execSync } = require('child_process');
const CHROME = '/srv/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome';
const ROOT = '/srv/myreader/book_manager';
const BASE = 'https://127.0.0.1:9000';

let pass = 0, fail = 0;
const ck = (n, ok, extra) => {
  if (ok) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (extra ? '  → ' + extra : '')); }
};
const py = (c) => execSync('venv/bin/python -', { cwd: ROOT, encoding: 'utf8', input: c }).trim();
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

(async () => {
  // ---------------------------------------------------------------- 服务端
  const r = await fetch(BASE + '/api/audiobooks');
  const d = await r.json();
  ck('★ 游客拉有声列表：一本书都没有',
     (d.items || []).length === 0 && d.total === 0, JSON.stringify({ n: (d.items || []).length, t: d.total }));
  ck('游客拉有声列表：分类也是空的', (d.cats || []).length === 0, JSON.stringify(d.cats));

  for (const [name, url] of [
    ['详情', '/api/audiobooks/1'],
    ['逐句歌词', '/api/audiobooks/1/lyrics?chap=1'],
    ['取票', '/api/audiobooks/1/ticket?seq=1&chap=1'],
  ]) {
    const rr = await fetch(BASE + url);
    ck(`★ 游客访问有声${name}被拒（403）`, rr.status === 403, 'HTTP ' + rr.status);
  }
  const rb = await fetch(BASE + '/api/audiobooks/1');
  const db_ = await rb.json();
  ck('拒绝理由说清了是「要先登录」', /登录/.test(String(db_.detail)), JSON.stringify(db_.detail));

  // 登录用户不受影响
  const info = JSON.parse(py(`
import sys, json
sys.path.insert(0, '${ROOT}')
import db, auth
u = db.q("SELECT * FROM users WHERE username='test' AND enabled=1", one=True)
print(json.dumps({"tok": auth.create_token(u), "user": dict(u)}))`));
  const rl = await fetch(BASE + '/api/audiobooks',
                         { headers: { 'Authorization': 'Bearer ' + info.tok, 'X-BM-No-Push': '1' } });
  const dl = await rl.json();
  ck('★ 登录用户仍能正常看到有声书', (dl.items || []).length > 0,
     (dl.items || []).length + ' 本');

  // ---------------------------------------------------------------- 前端
  const b = await chromium.launch({ executablePath: CHROME, args: ['--no-sandbox'] });
  const ctx = await b.newContext({ ignoreHTTPSErrors: true, viewport: { width: 1280, height: 900 } });
  const page = await ctx.newPage();
  const errs = [];
  page.on('pageerror', e => errs.push(String(e).slice(0, 90)));
  await page.goto(BASE + '/', { waitUntil: 'domcontentloaded' });   // 不带任何登录信息 = 游客
  await page.waitForFunction(() => typeof switchPage === 'function', null, { timeout: 20000 });
  await page.waitForTimeout(1500);
  ck('确实是游客模式', await page.evaluate(() => GUEST === true));

  await page.evaluate(() => switchPage('shelf'));
  await page.waitForTimeout(1200);
  const shelf = await page.evaluate(() => {
    const a = document.getElementById('shelf-public');
    const m = document.querySelector('.shelf-main');
    return { aside: !!a && getComputedStyle(a).display !== 'none' && a.offsetHeight > 0,
             main: !!m && m.offsetWidth > 200 };
  });
  ck('★ 游客的书架页看不到「有声阅读」侧栏', shelf.aside === false);
  ck('书架收藏照常显示（布局补上，没留空档）', shelf.main === true);

  await page.evaluate(() => switchPage('audio'));
  await page.waitForTimeout(1500);
  const au = await page.evaluate(() => ({
    cards: document.querySelectorAll('#au-list .au-card').length,
    text: document.getElementById('au-list').textContent.trim(),
    toolbar: getComputedStyle(document.querySelector('#page-audio .au-toolbar')).display,
    btn: !!document.querySelector('#au-list button'),
  }));
  ck('★ 游客打开有声页：一本书都不显示', au.cards === 0, au.cards + ' 本');
  ck('★ 提示需要登录且给得出登录入口', /登录/.test(au.text) && au.btn, au.text.slice(0, 30));
  ck('搜索/分类工具条也隐藏了（不给无意义的空控件）', au.toolbar === 'none', au.toolbar);

  await page.evaluate(() => openAudio(1));
  await page.waitForTimeout(1500);
  const det = await page.evaluate(() => document.getElementById('au-detail-body').textContent.trim());
  ck('★ 游客直接打开有声详情：不给内容，只提示登录', /登录/.test(det), det.slice(0, 30));

  ck('页面没有 JS 报错', errs.length === 0, errs[0] || '');
  await b.close();
  console.log(`\n游客看不到有声内容：${pass} 通过 / ${fail} 失败`);
  process.exit(fail ? 1 : 0);
})();
