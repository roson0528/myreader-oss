"""极简阅读页（/lite）—— 给跑不了现代前端的老设备用（第七代 Kindle 等）。

## 为什么要有它

`/reader` 的 `reader.js` 用了箭头函数（83 处）、模板字符串（26 处）、
`async/await`（48 处）、`const/let`（298 处），还有 `fetch`、`URLSearchParams`、
`classList`；`reader.html` 里又有 flex（11 处）、CSS 变量（13 处）、多栏分页。
第七代 Kindle 的实验浏览器基于约 Safari 5 时代的老 WebKit：
箭头函数要 Safari 10、模板字符串要 Safari 9、CSS 变量要 9.1 ——
**它连脚本都解析不了**，一个语法错误就让整个 reader.js 不执行，
于是页面永远停在「加载中」。所以之前给阅读器加 `isKindle` 强制滚动模式没用：
问题根本不在滚动方式，而在代码压根跑不起来。

## 做法：不改造现代阅读器，另给一份服务端渲染的极简页

试图让老引擎跑现代前端是死路（等于把 ES6 语法、flex、CSS 变量、多栏分页
全部重写一遍，而且永远追不上）。这里换一条路：

* 纯 HTML + 纯 CSS1/2：不用 flex / grid / CSS 变量 / 多栏 / 过渡 / 圆角；
* **零 JavaScript**：登录是普通 `<form method="post">` + cookie，
  翻章、翻页、调字号全是 `<a href>`；没有 JS 也能从头读到尾；
* 正文由服务端渲染并做转义，老浏览器只负责显示文字和跟随链接；
* 阅读进度**在服务端写库**，字段与现代阅读器完全一致
  （`position = {kind, mode, idx, page, scroll, frac, dev}` + `percent`），
  所以「Kindle 上读到第三章，手机打开接着读」这条云端同步照样成立。

## 路由

    GET  /lite                        书架（最近在读 + 搜索 + 分页列表）
    GET  /lite/login                  登录表单（无 JS）
    POST /lite/login                  校验并种 cookie
    GET  /lite/logout                 退出
    GET  /lite/book/{bid}             目录 + 继续阅读
    GET  /lite/book/{bid}/ch/{idx}    正文（顺带记录进度）

## 安全取舍

* 登录态放 HttpOnly + SameSite=Lax 的 `bm_lite` cookie，一年有效；
  老浏览器没有 localStorage，这是唯一能「零 JS 登录」的办法。
* `next` 参数只允许站内 `/lite` 开头的相对路径，挡开放重定向。
* 正文里的 HTML（md 渲染结果、epub 章节）会过一遍 `_sanitize()`：
  掐掉 `<script>/<iframe>/<object>/<embed>/<form>` 与 `on*=` 事件属性、
  把 `javascript:` 协议换成 `#`。**这不是通用净化器**，只挡「在这个没有 JS 的
  页面上也会执行/会偷东西」的那几类；真正的边界仍是「书是站长自己放进来的」。
"""

import html as _html
import json
import math
import posixpath
import re
from urllib.parse import unquote as _unquote, urljoin as _urljoin

from fastapi import APIRouter, Form, HTTPException, Query, Request
from fastapi.responses import HTMLResponse, RedirectResponse

import auth
import db
import reader as reader_mod

router = APIRouter(prefix="/lite", tags=["lite"])

COOKIE = "bm_lite"
COOKIE_MAX_AGE = 3600 * 24 * 365      # 老设备上重新输密码很痛苦，给一年
PAGE_SIZE = 20
FS_MIN, FS_MAX, FS_DEF = 16, 40, 22   # 正文字号（像素），?fs= 临时覆盖用

# 极简页的排版设置（每账号单独存 settings.lite_fmt）。
# ★ 字体值、字号与行距的取值范围都与 APP 阅读器保持一致，但存的是**独立字段** ——
#   在 Kindle 上改格式不会影响手机 APP 里的阅读设置。
# ★ 默认字体用无衬线（黑体）：墨水屏上宋体的细横画最容易被渲染成一团灰。
#   注意这只影响「没设置过的账号」，改过格式的账号仍按各自存的来。
# ★ 每屏字数：先按站长的要求把基准从 500 提到 900，再按他的设备实测做了**重新标定**。
#   他给了一个很准的标定点：「特大 30px 的正文刚好占满一屏」。
#   物理关系是：每行字数 ∝ 1/字号，每屏行数也 ∝ 1/字号 → **每屏字数 ∝ 1/字号²**。
#   而第一版按 1/字号 线性缩放（在 30px 处刚好蒙对），字号一大就给多了 ——
#   这正是他看到的「超大超过一屏」。按标定点反推：30px 一屏 = 660 字 → 屏幕容量常数
#   594000 = 每屏字数 × 字号²，于是 22px 基准该是 1227 字（原 900）。
#   校准后的每屏字数：18px→1833、22px→1227、26px→878、30px→660（与他的观测一致）、
#   39px→390（原来的 507 少 23%，正好落回一屏）。
#   同时把「每屏字数」做成可调档位：服务器终究推算不出每台设备的确切容量
#   （分辨率、浏览器布局宽度、字号、行距都影响），留白多就往上调、要滚动就往下调。
CHARS_PER_SCREEN = 1230      # 字号 22px 时每屏的目标字数（实际按 字号² 反比缩放）

FMT_DEF = {"ff": "sans-serif", "lh": 1.75, "fs": 22, "cp": CHARS_PER_SCREEN, "preset": ""}
FMT_FF = [("sans-serif", "黑体"), ("serif", "宋体"),
          ("'Kaiti SC','KaiTi',serif", "楷体")]
FMT_LH = [(1.5, "紧凑"), (1.75, "标准"), (2.0, "宽松"), (2.3, "很宽")]
# ★ 「超大」= 特大 30 × 1.3 = 39（站长要求「比特大还大 30%」），仍在 FS_MAX=40 以内
FMT_FS = [(18, "小"), (22, "中"), (26, "大"), (30, "特大"), (39, "超大")]
# 每屏字数（字号 22px 时的基准，实际按 字号² 反比缩放）
FMT_CP = [(1000, "紧凑"), (1230, "标准"), (1500, "宽松"), (1900, "很宽")]
_TXT_KINDS = ("txt", "docx", "md")
_EPUB_KINDS = ("epub", "mobi")

# ---------------------------------------------------------------- 设备预设
# ★ 站长需求：把设置行里的「每屏字数」换成「预设」——预设是**一台具体机器的排版档**，
#   它同时管两件事：
#     1) 字体/行距/字号（选中预设时自动设好，例如 KPW4 = 黑体 + 紧凑 + 中）；
#     2) 这块屏**一屏正好显示多少行** —— 目标是「正文正好一屏、不用往下滑」。
#   ★ 行数不是写死的：写死的话用户一改字号就不准了。这里存的是这台机器**能放文字的
#     高度**（vh 减掉页边距和底部导航），行数实时按 `可用高度 ÷ (行距 × 字号)` 算出来，
#     所以「KPW4 + 中」是 17 行，「KPW4 + 特大」自动变成 12 行 —— 都还是刚好一屏。
#   ★ vw/vh 是**浏览器的 CSS 视口**，不是物理像素：Kindle 的浏览器按 CSS px 报尺寸。
#     KPW4（Paperwhite 4）物理 1072x1448 @300dpi → 基准 536x724 CSS px；宽取 536，
#     高取 621 —— 站长在真机上数出来「22px + 紧凑(1.5) 正好 17 行」：
#     17 × 22 × 1.5 = 561px 正文 + 上下页边距 16 + 底部导航约 44 = 621。
#   ★ `lines` 是站长数出来的那个数，留在这里当**交叉校验**：测试会验证按 vw/vh
#     算出来正好等于它 —— 谁把 vh 或公式改坏了，立刻红。
LITE_NAV_EM = 1.4        # 底部导航高度 ≈ 1.4 × 字号（.8em 字号 × 1.75 行高）
LITE_NAV_PAD = 13        # 底部导航的固定留白（padding + margin + 边框）
LITE_BODY_PAD_V = 16     # body 上下 padding 合计（6 + 10）
# ★ HTML（epub）比纯文本多占的高度没法从字数推出来：标题的字号是 1.35em 且上下有外边距、
#   正文里可能有 <br>、图片/表格更是没有字数可言。实测一本 epub 会正好多出约 1.5 行，
#   所以 HTML 页面预留 2 行安全余量 —— 宁可少排一行，也不能多一行要往下滑。
LITE_HTML_SAFETY_LINES = 2

#   ★ 预设 = 一台机器的排版档。加机型就往这张表里加一行（key 存进账号，改名字要连着数据一起改）。
#     vw/vh 是它的 CSS 视口，w 是正文列宽，lines 是在 (ff/lh/fs) 下的行数。
FMT_PRESET = [
    ("", "自定义", None),
    # KPW4 = Kindle Paperwhite 4：1072x1448 物理 → 536x724 CSS px，浏览器工具栏占 103px，
    # 可用高 621、正文列宽 516 —— 站长在真机上数出「黑体 22px 紧凑 正好 17 行」。
    ("kpw4", "KPW4", {"vw": 536, "vh": 621, "w": 516, "lines": 17,
                      "ff": "sans-serif", "lh": 1.5, "fs": 22}),
    # KV = 站长要求的机型：默认「黑体 紧凑 超大（39px）」一屏 20 行。
    #   视口高按 20 行反推：20 × 39 × 1.5 = 1170 + 页边距 16 + 导航 67.6 = 1253.6
    #   ≤ 1272，再多一行 1312 > 1272 —— 行数不是拍脑袋，是这台机器装得下的真实上限；
    #   正文列宽 990 → 一行 25 个全角字。真机视口有出入就调 vw/vh/w（见 _preset_cpl 注释）。
    ("kv", "KV", {"vw": 1010, "vh": 1272, "w": 990, "lines": 20,
                  "ff": "sans-serif", "lh": 1.5, "fs": 39}),
]
_PRESET_BY_KEY = {k: v for k, _, v in FMT_PRESET}


def _preset_of(fmt):
    """取这台机器对应的预设（没选预设 → None，走原来的「每屏字数」）。"""
    return _PRESET_BY_KEY.get((fmt or {}).get("preset") or "")


def _preset_lines(p, fs, lh):
    """这台机器在当前字号/行距下一屏能放几行（正文以外的东西全部扣掉）。"""
    nav = LITE_NAV_EM * max(1, int(fs)) + LITE_NAV_PAD
    avail = p["vh"] - LITE_BODY_PAD_V - nav
    return max(3, int(avail // max(1.0, float(lh or 1.75) * max(1, int(fs)))))


def _preset_cpl(p, fs):
    """一行能放几个全角字：正文列宽 ÷ 字号。

    ★ 这里假设汉字宽 = 1em（全角字的标准宽度）。若某台机器的中文字体不是 1em
      （例如落到 0.9em 的字体上，一行实际能放更多字），页面会**偏短**（底部留白）
      但绝不会溢出 —— 要顶满就把预设的 w 调大（实测每行能放 26 个就填 26×22≈572）。
    """
    return max(4, int(int(p.get("w") or (p["vw"] - 20)) // max(1, int(fs))))


_RE_TAG = re.compile(r"<[^>]*>")
_RE_LINE = re.compile(r"[^\n]*\n?")
_RE_HEAD = re.compile(r"<h[1-6]\b", re.I)
_RE_MEDIA = re.compile(r"<(?:img|video|table|figure)\b", re.I)
_RE_TOK = re.compile(r"(<[^>]*>)|([^<]+)")
_RE_BR = re.compile(r"^<br\b", re.I)


def _disp_width(s):
    """一串文字占几个「全角字宽」：汉字/全角 = 1，ASCII 按 0.6（保守取宽）。

    ★ 保守取宽 = 算出来的行数**偏多** = 每屏实际渲染的行数**少于**预算 = 不会溢出。
      宁可底部空半行，也不能多出一行要往下滑 —— 那是站长要解决的问题本身。
    """
    w = 0.0
    for ch in (s or ""):
        w += 0.6 if (ord(ch) < 0x2E80 and ch != "　") else 1.0
    return w


def _html_line_starts(text, cpl):
    """epub HTML 里每个「显示行」的起始偏移（按行分屏的底表）。

    ★ 一行 = 一屏行高（lh×fs）的正文行，页面按这个表每 N 行切一屏：
       · 文字按列宽折行（全角 1、ASCII 0.6，宁宽勿窄 —— 窄了会溢出）；
       · <br> 断当前行并开一个新（空）行（两个 <br> 中间就是空行）；
       · </p> 等块结束 = 上一段行结束（.read p 没有外边距，断行即可）；
       · <h1..6> 上下 .5em 边距 ≈ 多占 1 行，标题文字再开新行；
       · <img|table|figure> 高度无法从字数推导，inline 保底 +6 行。
       · html 空白折叠成一个空格、段首空白折叠成无 —— 这里按折叠后算。
    返回 [第0行起点, 第1行起点, …]，严格递增，第 0 行永远从 0 开始。
    """
    cpl = max(4, int(cpl))
    starts = [0]
    ln = 0                                  # 当前行号（starts 的下标）
    w = 0.0                                 # 当前行已占宽度
    brk = False                             # 当前行已结束，下个非空白字符开新行
    prev_ws = False
    for m in _RE_TOK.finditer(text or ""):
        tag = m.group(1)
        if tag is None:
            for i in range(m.start(), m.end()):
                ch = text[i]
                if brk:
                    if ch.isspace():
                        continue            # 段首空白：浏览器折叠成无
                    ln += 1
                    starts.append(i)
                    w = 0.0
                    brk = False
                if ch.isspace():
                    if prev_ws:
                        continue            # 折叠：连续空白只算一个空格
                    prev_ws = True
                else:
                    prev_ws = False
                cw = 0.6 if (ord(ch) < 0x2E80 and ch != "　") else 1.0
                if w > 0 and w + cw > cpl:  # 折行：这个字是下一行的第一个字
                    ln += 1
                    starts.append(i)
                    w = min(cw, cpl)
                else:
                    w += cw
        else:
            prev_ws = False
            T = tag.lower()
            if _RE_BR.search(T):
                ln += 1
                starts.append(m.end())
                w = 0.0
            elif _RE_BLOCK.fullmatch(T):
                if w > 0:                   # 上一段行结束（空行不额外占行）
                    brk = True
                    w = 0.0
            elif _RE_HEAD.search(T):
                if not brk and w > 0:       # 标题前的段落行先收尾
                    brk = True
                    w = 0.0
                ln += 1                     # 标题上下 .5em 边距 ≈ 1 行
                starts.append(m.start())
                brk = True                  # 标题文字从新行开始
            elif _RE_MEDIA.search(T):
                ln += 6                     # 图片/表格高度保底，文字照常续行
                starts.append(m.start())
    return starts


def _bounds_lines(text, max_lines, cpl, is_html=False):
    """按「一屏 max_lines 行」切屏，返回每屏起始偏移（预设模式专用）。

    ★ 为什么不能沿用按字数切（_bounds）：txt 走的是 <pre> + pre-wrap，
      **源文本里每个换行都真的占一行**。一行 16 个字的书和一行 40 个字的书，
      同样字数占的行数差一倍 —— 按字数切必然有的屏半屏空、有的屏溢出。
      站长要的是「一屏正好 N 行」，那就得**按行**数着切。
    ★ txt：源文本每个换行是一行（折行按 每行字数 折算，长行拆成多行）。
    ★ html（epub）也一样按显示行切（见 _html_line_starts）—— 页面排满 N 行
      **敢切在段落中间**（此前按 </p> 块边界切，短段落会把页面下半截空出来，
      站长原话：「一段 10 行，剩下的就是空的」）。每屏正好 max_lines 行。
    """
    n = len(text or "")
    if n <= 0:
        return [0]
    cpl = max(4, int(cpl))
    max_lines = max(1, int(max_lines))
    units = []                                  # [(start, end, 占几行)]
    if is_html:
        starts = _html_line_starts(text, cpl)
        return [starts[i] for i in range(0, len(starts), max_lines)]
    for m in _RE_LINE.finditer(text):
        seg = m.group(0)
        if not seg:
            break
        units.append((m.start(), m.end(),
                      max(1, int(math.ceil(_disp_width(seg.rstrip("\n")) / cpl)))))
    out = [0]
    cur = 0
    for st, _en, ln in units:
        if cur and cur + ln > max_lines:
            out.append(st)
            cur = ln
        else:
            cur += ln
    return out


def _block_lines(seg, cpl):
    """一个 HTML 块占几行（文字宽度算 + 标题/图片的保底）。"""
    t = _RE_TAG.sub("", seg)
    ln = max(1, int(math.ceil(_disp_width(t) / cpl)))
    if _RE_HEAD.search(seg):
        ln += 1                                 # 标题上下各 .5em 外边距 ≈ 多占一行
    m = len(_RE_MEDIA.findall(seg))
    if m:
        ln += 6 * m                             # 图片/表格高度无法从字数推导，给保底
    return ln


# ---------------------------------------------------------------- 基础工具

def _e(s):
    return _html.escape(str(s if s is not None else ""), quote=True)


def _site_name():
    for k in ("site_name", "site_title"):
        try:
            v = db.get_config(k, "")
        except Exception:
            v = ""
        if v:
            return v
    return "云阅读"


def _fs(v):
    try:
        v = int(v)
    except (TypeError, ValueError):
        return FS_DEF
    return max(FS_MIN, min(FS_MAX, v))


def _fmt_of(user):
    """取某账号的极简页排版设置。

    ★ 读要宽（沿用项目里友链那套相反容错的规矩）：坏 JSON、越界字号、未知字体
      一律**回落默认**而不是抛错 —— 排版设置坏掉就整页打不开，是最不能接受的。
    """
    d = dict(FMT_DEF)
    if not user or not user["id"]:
        return d
    r = db.q("SELECT lite_fmt FROM settings WHERE user_id=?", (user["id"],), one=True)
    raw = (r["lite_fmt"] if r else "") or ""
    if not raw:
        return d
    try:
        o = json.loads(raw)
    except Exception:
        return d
    if o.get("ff") in [k for k, _ in FMT_FF]:
        d["ff"] = o["ff"]
    try:
        lh = float(o.get("lh"))
        if any(abs(lh - v) < 0.01 for v, _ in FMT_LH):
            d["lh"] = lh
    except (TypeError, ValueError):
        pass
    try:
        fs = int(o.get("fs"))
        if any(fs == v for v, _ in FMT_FS):
            d["fs"] = fs
    except (TypeError, ValueError):
        pass
    try:
        cp = int(o.get("cp"))
        if any(cp == v for v, _ in FMT_CP):
            d["cp"] = cp
    except (TypeError, ValueError):
        pass
    # ★ 预设只认表里的 key；表里没有的（比如版本回退、手改过库）一律当「自定义」，
    #   而不是把整份设置判废 —— 排版设置坏掉就整页打不开，这是最不能接受的。
    # ★★ 取值必须用 o.get：判断用 .get 而取值用 o["..."] 是错的 —— 因为 ""（自定义）
    #    本身就是一个合法 key，老账号那份 JSON 里**根本没有 preset 键**时，
    #    `(o.get("preset") or "")` 得到 "" 也满足 `in _PRESET_BY_KEY`，于是走进分支
    #    再 o["preset"] 直接 KeyError → 整页 500。站长就是这样打不开 lite 的
    #    （线上日志 lite.py:_fmt_of → KeyError: 'preset'）。
    #    这一段的全部意义就是「坏设置不能弄坏页面」，自己却抛异常就本末倒置了。
    _pv = o.get("preset") or ""
    d["preset"] = _pv if _pv in _PRESET_BY_KEY else ""
    return d


def _fmt_css(fmt):
    """内联到 <body style>：老浏览器不认 CSS 变量，但认得这三个属性"""
    return "font-size:%dpx; line-height:%.2f; font-family:%s" % (
        int(fmt["fs"]), float(fmt["lh"]), fmt["ff"])


def _token_of(request):
    """登录态来源：优先 Authorization 头（正常前端），其次 bm_lite cookie（老浏览器）"""
    a = request.headers.get("authorization", "")
    if a.startswith("Bearer "):
        return a[7:]
    return (request.cookies.get(COOKIE) or "").strip()


def lite_user(request: Request):
    """cookie/头都认；没有或失效一律当游客，不抛 401 —— 老浏览器上直接跳登录比报错友好"""
    tok = _token_of(request)
    if not tok:
        return auth.GUEST_USER
    payload = auth.decode_token(tok)
    if not payload:
        return auth.GUEST_USER
    u = db.q("SELECT * FROM users WHERE id=?", (payload["uid"],), one=True)
    if not u or not u["enabled"]:
        return auth.GUEST_USER
    return u


def _book_or_404(bid, user):
    b = db.q("SELECT * FROM books WHERE id=?", (bid,), one=True)
    if not b or not auth.can_access_book(user, b):
        raise HTTPException(404, "书籍不存在")
    return b


def _safe_next(n):
    """只允许回到站内 /lite 路径，挡开放重定向"""
    n = (n or "").strip()
    if not n.startswith("/lite"):
        return "/lite"
    if any(c in n for c in ("\r", "\n", "\\")) or n.startswith("//"):
        return "/lite"
    return n


def _set_cookie(resp, token, request):
    resp.set_cookie(COOKIE, token, max_age=COOKIE_MAX_AGE, path="/",
                    httponly=True, samesite="lax",
                    secure=(request.url.scheme == "https"))
    return resp


# 掐掉在这个零 JS 页面上也能执行/能偷东西的标签与属性。
# ★ 刻意用正则而不是引第三方净化库：这是个只读阅读页，要挡的东西很有限，
#   多一个依赖就多一份升级负担；但也因此它挡不住「畸形 HTML 绕过正则」这类
#   花式攻击 —— 前提仍然是「书来自站长自己的书库」。
_RE_SCRIPT = re.compile(r"<\s*script\b.*?(?:<\s*/\s*script\s*>|$)", re.I | re.S)
_RE_BADTAG = re.compile(r"<\s*/?\s*(?:iframe|object|embed|form|input|button|select|textarea|base|meta|link)\b[^>]*>", re.I)
_RE_ONATTR = re.compile(r"\son\w+\s*=\s*(?:\"[^\"]*\"|'[^']*'|[^\s>]+)", re.I)
_RE_JSURL = re.compile(r"(?:href|src|xlink:href)\s*=\s*(?:\"|')?\s*javascript:[^\"'>\s]*", re.I)
_RE_A = re.compile(r"<\s*a\b([^>]*)>(.*?)<\s*/\s*a\s*>", re.I | re.S)
_RE_HREF = re.compile("href\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)')", re.I)


# ------------------------------------------------- 章内定位：按段落边界分屏
# 为什么不是「边划边记」：极简页没有 JS，浏览器**不会**告诉服务器「他滚到哪儿了」。
# 想边滚边记就必须上 JS，而老 Kindle 上跑 JS 恰好是我们要避开的东西。
# 换个思路：把章节按段落边界切成若干「屏」（每屏约一屏的量），翻屏就是一次普通链接
# 跳转 —— 于是**每一屏天然就是一个地址**，服务器在每次 GET 时都记下确切位置（零 JS）。
#
# ★ 地址存的是「本屏起始字符 ÷ 全章字符」这个比例，而不是「第几屏」：
#   字号一变大，屏的切分会变、屏号会整体错位；而比例指向的是**同一段文字**。
HTML_MARKUP_RATIO = 1.35     # HTML 里标签也算字符，目标放宽一点


def _page_target(fs, is_html, cp=CHARS_PER_SCREEN):
    """一屏放多少字符（**没选预设**时的老路子：站长按真机重标定过的平方反比模型）。

    ★ 选了设备预设时不走这里 —— 预设按「一屏几行」切（见 _bounds_lines），
      因为「行数」才是站长要的那个量，字符数只是它的近似。
    """
    # ★ 平方反比：分母是 (字号/22) 的平方。写成线性会让大字号每屏给太多字（超过一屏）、
    #   小字号给太少（屏幕下半截空着）。
    t = int(cp or CHARS_PER_SCREEN) * (22.0 / max(1, int(fs))) ** 2
    if is_html:
        t *= HTML_MARKUP_RATIO
    return max(120, int(t))


_RE_BLOCK = re.compile(r"</(?:p|div|section|article|h[1-6]|li|td|tr|blockquote)\s*>", re.I)


def _bounds(text, target, is_html=False):
    """按段落/块边界切屏，返回每屏的起始字符偏移（至少含一个 0）。"""
    n = len(text or "")
    if n <= target:
        return [0]                                  # 短章：一屏放完，不切
    if is_html:
        cuts = [m.end() for m in _RE_BLOCK.finditer(text)]
    else:
        cuts = [i + 1 for i, ch in enumerate(text) if ch == "\n"]
    out, last = [0], 0
    for c in cuts:
        if c - last >= target:                      # 攒够一屏就在下一个段落边界切
            out.append(c)
            last = c
    return out


def _pick(bounds, off):
    """给定字符偏移，问它落在第几屏（0 起）。二分，别线性扫（长章几千屏）。"""
    lo, hi = 0, len(bounds) - 1
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if bounds[mid] <= off:
            lo = mid
        else:
            hi = mid - 1
    return lo


def _link_ok(u):
    """这个链接在极简页上能不能直接用。

    只有「站内绝对路径 / 页内锚点 / http(s) / data:」能用。**相对链接一律算坏**：
    epub 正文里自带 `chap0.xhtml`、`part0004_split_000.html` 这类同书互链，
    浏览器会拿**当前地址**去解析 —— 当前是 `/lite/book/N/ch/M`，于是变成
    `/lite/book/N/ch/chap0.xhtml`，撞上 `idx: int` 直接 422，页面糊出一坨 JSON
    （站长报的 `{"detail":[{"type":"int_parsing",...}]}` 就是这个）。
    """
    u = (u or "").strip().lower()
    return (u.startswith("http://") or u.startswith("https://") or u.startswith("data:")
            or u.startswith("/") or u.startswith("#"))


def _norm_href(u):
    """href 归一化到同一坐标系再比对：去 `#片段`/查询串、折平 `./ ../`、解百分号编码。"""
    u = (u or "").strip().replace("\\", "/")
    u = u.split("#", 1)[0].split("?", 1)[0]
    if not u:
        return ""
    try:
        u = _unquote(u)
    except Exception:
        pass
    return posixpath.normpath(u).lstrip("/")


def _epub_link_rewriter(toc, base, bid, fs):
    """epub 正文里的**同书互链** → 极简页真正走得通的章链接。

    `toc` 是 `reader.epub_toc()` 的结果（每项有 href），`base` 是当前章的 href ——
    正文里的链接是相对**当前章所在目录**的，所以要先 urljoin 再归一化，才能和目录里的
    href 对上号。对不上（图片、脚注文件、缺失文件）返回 None，交给 `_sanitize` 退化成纯文字。
    """
    m = {}
    for i, t in enumerate(toc):
        k = _norm_href(t.get("href"))
        if k:
            m.setdefault(k, i)

    def rewrite(href):
        i = m.get(_norm_href(_urljoin(base or "", href)))
        return ("/lite/book/%d/ch/%d?fs=%d" % (bid, i, fs)) if i is not None else None

    return rewrite


def _sanitize(h, rewrite=None):
    h = _RE_SCRIPT.sub("", h or "")
    h = _RE_BADTAG.sub("", h)
    h = _RE_ONATTR.sub("", h)
    h = _RE_JSURL.sub('href="#"', h)

    def fix_a(m):
        attrs, inner = m.group(1), m.group(2)
        hm = _RE_HREF.search(attrs)
        if not hm:
            return m.group(0)                     # <a name="x"> 这类锚点原样保留
        href = hm.group(1) if hm.group(1) is not None else (hm.group(2) or "")
        if _link_ok(href):
            return m.group(0)
        # 相对链接：能对上本书某一章就改写成极简页真正走得通的章链接；
        # 对不上（图片、缺文件）就退化成纯文字 —— 总之不留一个点开就报错的链接。
        new = rewrite(href) if rewrite else None
        if new:
            return '<a href="%s">%s</a>' % (_e(new), inner)
        return "<span>%s</span>" % inner

    return _RE_A.sub(fix_a, h)


# ---------------------------------------------------------------- 页面外壳

_CSS = """
/* ★★ 这一页是给电子墨水屏（Kindle 等）看的，所以刻意**只用纯黑与纯白**。
   墨水屏只有「全黑/全白」两级，中间色（米色底、灰字、蓝链接、浅色虚线边框）都会被
   固件用**抖动网点**去凑 —— 远看发灰，近看全是噪点和残影，这就是「显示不清楚」的主因。
   层级改用字号 / 下划线 / 边框来表达，不靠颜色。任何新增样式都必须守住这条：
   颜色只允许 #000 与 #fff（测试里有静态扫描盯着）。 */
body { margin:0; padding:6px 10px 10px; background:#fff; color:#000;
       font-family:sans-serif; line-height:1.75;
       -webkit-text-size-adjust:100%; }
/* ★ 设备预设（一屏正好 N 行）要求「行数可数」：段间距不能是浏览器默认的上下各 1em
   —— 那是 2 行，而且服务端没法预估。改成中文书常规的「段间 0 间距 + 首行缩进 2 字」，
   于是正文高度 = 行数 × 行距 × 字号，服务端才算得准「刚好一屏」。
   .read 只包章节页正文，首页/目录页的段落排版不受影响。 */
.read { margin:0; }
.read p { margin:0; text-indent:2em; }
.read h1, .read h2, .read h3, .read h4 { margin:.5em 0; text-indent:0; }
.read ul, .read ol { margin:0; padding-left:2em; }
/* Markdown 表格（§14.118）：墨水屏窄、老引擎又没有横向滚动，撑出屏幕右边的列
   用户根本看不到。所以宽度钉死 100%、字号缩一档、单元格内边距收窄，
   超出的内容靠单元格换行消化，而不是靠左右拖动。 */
.read table { width:100%; border-collapse:collapse; margin:.6em 0; font-size:.9em; }
.read th, .read td { border:1px solid #000; padding:2px 4px; text-align:left;
                     vertical-align:top; word-wrap:break-word; }
.read th { font-weight:bold; }
a { color:#000; text-decoration:underline; }
h1 { font-size:1.35em; margin:0 0 6px; }
h2 { font-size:1.15em; margin:18px 0 6px; }
.meta { font-size:.85em; margin:0 0 10px; }
/* 章节页唯一那一行导航，摆在**正文之后（页面底部）**，左/中/右三列：
     上一屏 下一屏   |   首页 目录   |   上一屏 下一屏
   左边那组给右手拿机器的拇指、右边那组给左手（站长要求「左右手都方便翻页」）。
   ★ 用 <table> 做三列而不是 flex/grid：老 Kindle 的 WebKit 对 table 的支持最稳，
     而且 flex/grid 本来就在本页的禁用清单里（§14.99）。
   ★ 字号要比正文小：它继承正文 font-size（特大档 30px 时一行 52px），.8em 后约 40px。 */
.nav { width:100%; border-collapse:collapse; margin:8px 0 0; font-size:.8em; }
.nav td { border-top:1px solid #000; padding:4px 0 0; vertical-align:top;
          white-space:nowrap; }
.nav td.l { text-align:left; }
.nav td.c { text-align:center; }
.nav td.r { text-align:right; }
.nav a { padding:2px 6px; }
.t { white-space:pre-wrap; word-wrap:break-word; margin:0; font-family:inherit; }
ul.toc { list-style:none; margin:0; padding:0; }
ul.toc li { padding:7px 0; border-bottom:1px solid #000; }
ul.toc li .n { font-size:.8em; }
.hint { border:1px solid #000; padding:8px 10px; margin:10px 0; }
.err { border:1px solid #000; padding:8px 10px; margin:10px 0; }
input[type=text],input[type=password] { font-size:1em; padding:6px; width:70%; }
.btn { font-size:1em; padding:6px 14px; }
.pg { margin:14px 0; }
.who { font-size:.8em; }
.inl { display:inline; margin:0 2px; }
.lnk { border:0; background:none; color:#000; text-decoration:underline;
       font-size:1em; font-family:inherit; padding:2px 4px; cursor:pointer; }
.cur { padding:2px 6px; }
select { font-size:1em; padding:4px 6px; }
"""


def _page(title, body, user=None, fmt=None, status=200, head=None):
    """head=None → 默认页头（站名 · 用户名 · 退出）；head="" → 完全不要页头。

    ★ 章节页传 ""：站长要求那一页只留一行导航 + 正文，页头（以及页脚再重复一遍）
      在墨水屏上都是白占的行。首页/目录页仍用默认页头（那里必须有「退出」）。
    """
    if head is None:
        who = '<a href="/lite">%s</a>' % _e(_site_name())
        if user is not None and user["id"]:
            who += ' · %s · <a href="/lite/logout">退出</a>' % _e(user["name"] or user["username"])
        head = '<div class="who">%s</div>' % who
        foot = '<p class="who">%s</p>' % who
    else:
        foot = ""
    doc = ("<!DOCTYPE html>\n<html><head><meta charset=\"utf-8\">"
           "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"
           "<title>%s</title><style>%s</style></head>\n"
           "<body style=\"%s\">\n%s\n%s\n</body></html>"
           % (_e(title), _CSS, _fmt_css(fmt or FMT_DEF), (head + "\n" + body) if head else body, foot))
    # ★ 不用 HTMLResponse(status_code=...) 之外的任何现代特性；no-cache 让代理/浏览器
    #   每次都回源校验（老设备缓存行为古怪，读到过期内容比慢一点更糟）。
    return HTMLResponse(doc, status_code=status, headers={"Cache-Control": "no-cache"})


def _chapter_nav(bid, idx, total, fs, pg, npages, bounds):
    """章节页**唯一**那一行导航，摆在正文之后（页面底部），左/中/右三列：

        上一屏 下一屏   |   首页 目录   |   上一屏 下一屏

    ★ 站长要求：左右两边各放一组翻屏链接（左右手都够得着），中间放「首页 目录」。
      所以同一组链接出现两次 —— 这不是重复，是**够手**设计。
    ★ 翻页规则不变（先按屏翻、到头再按章翻）：第一屏没有「上一屏」就给「上一章」，
      最后一屏没有「下一屏」就给「下一章」；两边同步替换，左右手看到的一样。
    ★ 老 Kindle 兼容：三列用 <table> 对齐（`text-align` 左/中/右），不用 flex/grid。
    """
    def lk(i, off, label):
        return '<a href="/lite/book/%d/ch/%d?fs=%d&off=%d">%s</a>' % (bid, i, fs, off, label)
    if pg > 0:
        prev = lk(idx, bounds[pg - 1], "上一屏")
    elif idx > 0:
        prev = lk(idx - 1, 0, "上一章")
    else:
        prev = ""
    if pg + 1 < npages:
        nxt = lk(idx, bounds[pg + 1], "下一屏")
    elif idx + 1 < total:
        nxt = lk(idx + 1, 0, "下一章")
    else:
        nxt = ""
    pair = (prev + " " + nxt).strip()
    return ('<table class="nav"><tr>'
            '<td class="l">%s</td>'
            '<td class="c"><a href="/lite">首页</a> '
            '<a href="/lite/book/%d?fs=%d">目录</a></td>'
            '<td class="r">%s</td>'
            '</tr></table>' % (pair, bid, fs, pair))


def _settings_form(user, fmt, saved=False):
    """首页「格式设置」：纯 <form> + <select>，零 JS 也能改。"""
    if not user or not user["id"]:
        return ""
    def sel(name, opts, cur, is_float=False):
        out = ['<select name="%s">' % name]
        for v, label in opts:
            sv = ("%g" % v) if is_float else str(v)
            mark = ""
            same = (abs(float(v) - float(cur)) < 0.01) if is_float else (v == cur)
            if same:
                mark = " selected"
            out.append('<option value="%s"%s>%s</option>' % (_e(sv), mark, _e(label)))
        out.append("</select>")
        return "".join(out)
    # ★ 站长要求精简：**只留下拉框本身**，不要「字体」「行距」「字号」「每屏字数」这些
    #   行标签，也不要账号隔离 / 每屏字数的长篇说明（Kindle 上每多一行就要多翻一屏）。
    #   选中什么就是什么；四个框固定按 字体 / 行距 / 字号 / 每屏字数 的顺序排。
    tip = '<p class="who">已保存</p>' if saved else ""
    # ★ 第 4 个下拉由「每屏字数」换成「预设」（站长要求）：预设是一台机器的排版档，
    #   选中它会把字体/行距/字号一起设好，并让章节页按「一屏正好 N 行」分屏。
    #   不选（自定义）时仍走原来的「每屏字数」默认值，老账号的设置不受影响。
    return ('<form method="post" action="/lite/settings">'
            '<input type="hidden" name="next" value="/lite">'
            '<p>' + sel("ff", FMT_FF, fmt["ff"]) +
            ' ' + sel("lh", FMT_LH, fmt["lh"], True) +
            ' ' + sel("fs", FMT_FS, fmt["fs"]) +
            ' ' + sel("preset", [(k, lb) for k, lb, _ in FMT_PRESET],
                      fmt.get("preset") or "") + ' '
            '<input class="btn" type="submit" value="保存"></p>'
            '</form>' + tip)


def _save_progress(user, bid, kind, idx, total, request, frac=0.0, page=0, off=0):
    """把进度写进库，字段与现代阅读器一致 —— 这样两端可以互相接着读。

    现代阅读器存的是 position = {kind, mode, idx, page, scroll, frac, dev}：
    `idx` 是章序号（跨设备同步就看它），`frac` 是章内比例（这里始终从章首开始读，
    所以是 0）。percent 用「已读到第几章」估算，两端显示口径一致。
    """
    if not user or user["id"] == 0:
        return
    frac = max(0.0, min(1.0, float(frac or 0.0)))
    # 百分比按「章 + 章内比例」算 —— 与现代阅读器同一个口径，两边显示的数字才对得上
    # （老写法按「读到第几章」粗估，分屏之后就没必要再粗估了）。
    pct = int(round((idx + frac) * 100.0 / max(1, total)))
    # off 是本屏起始的**绝对字符偏移**：链接用它跳回同一屏，整数、零精度损失。
    # frac 是给别的设备（手机现代阅读器）看的设备无关比例；现代阅读器只读它认识的键，
    # 多一个 off 不会有任何影响。
    pos = {"kind": "epub" if kind in _EPUB_KINDS else "txt", "mode": "scroll",
           "idx": int(idx), "page": int(page), "scroll": frac, "frac": frac,
           "off": int(off), "dev": "lite"}
    try:
        db.ex("INSERT INTO progress (user_id,book_id,position,percent,updated_at) VALUES (?,?,?,?,?) "
              "ON CONFLICT(user_id,book_id) DO UPDATE SET position=excluded.position, "
              "percent=excluded.percent, updated_at=excluded.updated_at",
              (user["id"], bid, json.dumps(pos, ensure_ascii=False), pct, db.now()))
    except Exception:
        return
    # 阅读活动日志：与 /api/books/{id}/progress 走同一条路（内部 30 分钟去重）。
    # ★ 这里用函数内 import：app.py 反过来 import 本模块（include_router），
    #   模块级 import 会成环；调用时 app 早已加载完毕。
    try:
        from app import _log_activity_once
        _log_activity_once(user, "read", bid, request, "开始阅读（兼容模式）")
    except Exception:
        pass


def _progress_of(user, bid):
    if not user or user["id"] == 0:
        return None
    r = db.q("SELECT position, percent FROM progress WHERE user_id=? AND book_id=?",
             (user["id"], bid), one=True)
    if not r:
        return None
    try:
        pos = json.loads(r["position"]) if r["position"] else {}
    except Exception:
        pos = {}
    fr = pos.get("frac")
    of = pos.get("off")
    return {"idx": int(pos.get("idx") or 0), "percent": r["percent"] or 0,
            "frac": float(fr) if isinstance(fr, (int, float)) else 0.0,
            "off": int(of) if isinstance(of, (int, float)) else None}


# ---------------------------------------------------------------- 登录

def _login_body(next_url, err=""):
    e = ('<div class="err">%s</div>' % _e(err)) if err else ""
    return (e + '<form method="post" action="/lite/login">'
            '<input type="hidden" name="next" value="%s">'
            '<p>用户名<br><input type="text" name="username" autocapitalize="off" '
            'autocorrect="off" autocomplete="username"></p>'
            '<p>密码<br><input type="password" name="password" autocomplete="current-password"></p>'
            '<p><input class="btn" type="submit" value="登录"></p>'
            '</form>' % _e(next_url))


@router.get("/login")
def login_form(next: str = Query("")):
    return _page("登录", _login_body(_safe_next(next)))


@router.post("/login")
def login_submit(request: Request, username: str = Form(""), password: str = Form(""),
                 next: str = Form("")):
    nxt = _safe_next(next)
    u = db.q("SELECT * FROM users WHERE username=?", (username.strip(),), one=True)
    # 与 /api/login 同一套判定：密码错、账号不存在都只说「用户名或密码错误」，
    # 不区分（否则等于给人名枚举开了一扇窗）
    if not u or not auth.verify_password(password, u["password_hash"]):
        return _page("登录", _login_body(nxt, "用户名或密码错误"))
    if not u["enabled"]:
        return _page("登录", _login_body(nxt, "账号已禁用"))
    try:
        db.ex("UPDATE users SET last_login=? WHERE id=?", (db.now(), u["id"]))
        db.log_audit(u, "login", "user", u["id"], "登录（兼容模式）")
    except Exception:
        pass
    # 302 而不是 303：老浏览器对 302 转 GET 的处理最一致（303 个别旧引擎会重发 POST）
    resp = RedirectResponse(nxt, status_code=302)
    return _set_cookie(resp, auth.create_token(u), request)


@router.post("/settings")
async def settings_save(request: Request, ff: str = Form(""), lh: str = Form(""),
                        fs: str = Form(""), cp: str = Form(""), next: str = Form("")):
    """保存极简页排版设置（每账号一份）。

    ★ 写要严（与「读要宽」配套）：只接受选项表里的值 —— 表单只能产生这些值，
      出现别的说明被改过，直接 400 而不是悄悄存个页面认不出的东西。
    ★ 用 POST 而不是 GET：这是个会改状态的动作，GET 会被预取/爬虫误触发；
      登录 cookie 是 SameSite=Lax，跨站 POST 带不上它，等于自带 CSRF 防护。
    """
    user = lite_user(request)
    dest = _safe_next(next)
    if not user["id"]:
        return RedirectResponse("/lite/login?next=" + quote(dest), status_code=302)
    ffs = [k for k, _ in FMT_FF]
    try:
        lhv = float(lh)
        fsv = int(fs)
    except (TypeError, ValueError):
        raise HTTPException(400, "设置值不合法")
    if ff not in ffs or not any(abs(lhv - v) < 0.01 for v, _ in FMT_LH) or \
            not any(fsv == v for v, _ in FMT_FS):
        raise HTTPException(400, "设置值不合法")
    old = _fmt_of(user)
    old_preset = old.get("preset") or ""
    # ★ preset 要读**原始表单**判断，不能用 Form(None) 形参：实测（直接 POST preset=）
    #   空字符串送进形参就变成了 None，与「字段根本没提交」完全分不开 —— 而这两件事
    #   含义相反：空值 = 用户选了「自定义」要关掉预设，缺字段 = 老页面/缓存页的表单里
    #   没有这一项，必须保持原样。第一版就栽在这：选「自定义」保存后预设纹丝不动。
    _form = await request.form()
    if "preset" not in _form:
        new_preset = old_preset
    else:
        new_preset = str(_form.get("preset") or "").strip()
        if new_preset not in _PRESET_BY_KEY:
            raise HTTPException(400, "设置值不合法")
    # ★「启用预设时自动设置为黑体/紧凑/中」只在**这次换了预设**时生效：
    #   否则选好 KPW4 之后再想微调字号，一保存就被拽回 22px（那才叫难用）。
    #   预设没变时，字号/行距/字体按用户提交的走 —— 行数仍按新字号实时算，
    #   所以「改成大字」之后还是一屏正好装下。
    if new_preset and new_preset != old_preset:
        pr = _PRESET_BY_KEY[new_preset]
        ff, lhv, fsv = pr["ff"], pr["lh"], pr["fs"]
    # cp 允许留空 = 「本次不动每屏字数」：章节页那排字号快捷按钮只关心字号，
    # 不该顺手把字数档位也改掉（它会带上一份自己并不知道的 cp）。
    if (cp or "").strip() == "":
        cpv = int(old["cp"])
    else:
        try:
            cpv = int(cp)
        except (TypeError, ValueError):
            raise HTTPException(400, "设置值不合法")
        if not any(cpv == v for v, _ in FMT_CP):
            raise HTTPException(400, "设置值不合法")
    db.ex("INSERT INTO settings (user_id, lite_fmt) VALUES (?,?) "
          "ON CONFLICT(user_id) DO UPDATE SET lite_fmt=excluded.lite_fmt",
          (user["id"], json.dumps({"ff": ff, "lh": lhv, "fs": fsv, "cp": cpv,
                                   "preset": new_preset}, ensure_ascii=False)))
    # 回到原来的位置（章节页要保留 #pK 锚点，所以先把锚点拆出来再拼 saved 参数）
    path, _, frag = dest.partition("#")
    path += ("&" if "?" in path else "?") + "saved=1"
    if frag:
        path += "#" + frag
    return RedirectResponse(path, status_code=302)


@router.get("/logout")
def logout():
    resp = RedirectResponse("/lite", status_code=302)
    resp.delete_cookie(COOKIE, path="/")
    return resp


# ---------------------------------------------------------------- 书架

def _recent(user, limit=12):
    if not user or user["id"] == 0:
        return []
    rows = db.q("SELECT b.*, p.percent AS _pct, p.updated_at AS _upd FROM progress p "
                "JOIN books b ON b.id=p.book_id WHERE p.user_id=? "
                "ORDER BY p.updated_at DESC LIMIT ?", (user["id"], limit), one=False)
    out = []
    for r in rows:
        if auth.can_access_book(user, r):
            out.append(r)
    return out


SHELF_MAX = 60      # 首页「书架」最多列这么多本（实测全站最大的书架 31 本，留足余量）


def _shelf(user):
    """用户自己的书架（「收藏」）：按加入时间倒序，与 App 书架页一致。

    ★ 过滤掉现在看不到的书：书架里可能留着已经下架/取消分享/别人撤回授权的书，
      把它们列出来点进去只会得到「书籍不存在」—— 和「书库」用同一套可见性规则，
      书架里也不给死链。
    ★ 为什么封顶：首页是一张长列表，书架几百本会把「书库」顶到很远。
      超出时下面会写明「共 N 本、这里显示最近 M 本」，不让人以为书架丢了书。
    """
    vw, vargs = auth.visible_where(user, "b")
    cond, args = " WHERE s.user_id=?", [user["id"]]
    if vw:
        cond += " AND " + vw
        args += list(vargs)
    total = db.q("SELECT COUNT(*) c FROM shelves s JOIN books b ON b.id=s.book_id" + cond,
                 args, one=True)["c"]
    rows = db.q("SELECT b.id, b.title, b.author, c.name AS collection_name "
                "FROM shelves s JOIN books b ON b.id=s.book_id "
                "LEFT JOIN shelf_collections c ON c.id=s.collection_id" + cond +
                " ORDER BY s.added_at DESC, s.id DESC LIMIT ?", args + [SHELF_MAX], one=False)
    return {"total": total, "rows": rows}


@router.get("")
def home(request: Request, q: str = Query(""), p: int = Query(1), saved: int = Query(0)):
    user = lite_user(request)
    fmt = _fmt_of(user)
    q = (q or "").strip()
    page = max(1, int(p or 1))
    parts = []

    if not user["id"]:
        # ★ 老设备上「点一下登录」就是一次整页往返（Kindle 上要等好几秒），
        #   所以未登录时把表单直接放在首页，登录后原地回到书架，少跳一次。
        parts.append("<h2>登录</h2>")
        parts.append(_login_body("/lite"))
        parts.append('<div class="hint">还没有账号/不想登录也行：下面「书库」里是访客可见的范例图书。</div>')

    # ★ 格式设置就在「最近在读」上面（站长指定的位置），只给登录用户看
    if user["id"]:
        parts.append(_settings_form(user, fmt, saved=bool(saved)))

    rec = _recent(user)
    if rec:
        li = []
        for r in rec:
            prog = _progress_of(user, r["id"]) or {"idx": 0}
            li.append('<li><a href="/lite/book/%d">%s</a> '
                      '<span class="n">读到第 %d 章 · %d%%</span></li>'
                      % (r["id"], _e(r["title"]), prog["idx"] + 1, int(r["_pct"] or 0)))
        parts.append("<h2>最近在读</h2><ul class=\"toc\">" + "".join(li) + "</ul>")

    # ★ 站长要求：书架板块放在「最近在读」下面、「书库」上面
    if user["id"]:
        sh = _shelf(user)
        if sh["rows"]:
            li = []
            for r in sh["rows"]:
                # 小字里先给分组名再给作者（分组是书架自己的信息，书库里看不到）
                note = " · ".join([x for x in (r["collection_name"], r["author"]) if x])
                li.append('<li><a href="/lite/book/%d">%s</a>%s</li>'
                          % (r["id"], _e(r["title"]),
                             (' <span class="n">%s</span>' % _e(note)) if note else ""))
            more = ""
            if sh["total"] > len(sh["rows"]):
                more = ('<div class="who">共 %d 本，这里显示最近 %d 本</div>'
                        % (sh["total"], len(sh["rows"])))
            parts.append('<h2>书架</h2><ul class="toc">' + "".join(li) + "</ul>" + more)

    parts.append('<h2>书库</h2>'
                 '<form method="get" action="/lite">'
                 '<input type="text" name="q" value="%s" autocapitalize="off" autocorrect="off"> '
                 '<input class="btn" type="submit" value="搜索"></form>' % _e(q))

    vw, vargs = auth.visible_where(user, "b")
    cond, args = " WHERE 1=1", list(vargs)
    if vw:
        cond += " AND " + vw
    if q:
        cond += " AND (b.title LIKE ? OR b.author LIKE ?)"
        args += ["%" + q + "%", "%" + q + "%"]
    total = db.q("SELECT COUNT(*) c FROM books b" + cond, args, one=True)["c"]
    pages = max(1, int(math.ceil(total / float(PAGE_SIZE))))
    page = min(page, pages)
    rows = db.q("SELECT b.id, b.title, b.author FROM books b" + cond +
                " ORDER BY b.id DESC LIMIT ? OFFSET ?",
                args + [PAGE_SIZE, (page - 1) * PAGE_SIZE], one=False)
    if rows:
        li = []
        for r in rows:
            au = (' <span class="n">%s</span>' % _e(r["author"])) if r["author"] else ""
            li.append('<li><a href="/lite/book/%d">%s</a>%s</li>' % (r["id"], _e(r["title"]), au))
        parts.append('<ul class="toc">' + "".join(li) + "</ul>")
    else:
        parts.append('<p>没有找到书。</p>')

    qs = ("&q=" + _html.escape(q, quote=True)) if q else ""
    pg = []
    if page > 1:
        pg.append('<a href="/lite?p=%d%s">上一页</a>' % (page - 1, qs))
    pg.append('<span class="who">第 %d/%d 页 · 共 %d 本</span>' % (page, pages, total))
    if page < pages:
        pg.append('<a href="/lite?p=%d%s">下一页</a>' % (page + 1, qs))
    parts.append('<div class="pg">' + " ".join(pg) + "</div>")

    return _page("书架", '<a id="top"></a>' + "\n".join(parts), user, fmt)


# ---------------------------------------------------------------- 书与章节

@router.get("/book/{bid}")
def book_page(bid: int, request: Request, fs: int = Query(None), saved: int = Query(0)):
    user = lite_user(request)
    b = _book_or_404(bid, user)
    fmt_saved = _fmt_of(user)
    # 没带 ?fs= 就用账号存的字号；带了就临时覆盖（不改账号设置）
    fs = _fs(fs) if fs is not None else int(fmt_saved["fs"])
    fmt = dict(fmt_saved)
    fmt["fs"] = fs
    k = reader_mod.kind(b)
    parts = ['<a id="top"></a>',
             "<h1>%s</h1>" % _e(b["title"]),
             '<p class="meta">%s</p>' % _e(b["author"] or "")]

    if k not in _TXT_KINDS + _EPUB_KINDS:
        # pdf/html：老浏览器渲染不了（读器里靠 canvas/内置查看器，都要 JS），
        # 给原文件下载入口 —— Kindle 能存下来用系统阅读器打开。
        parts.append('<div class="hint">这种格式（%s）在极简模式下看不了，'
                     '可以下载原文件用设备自带阅读器打开：'
                     '<a href="/api/books/%d/file">下载原文件</a></div>'
                     % (_e(k), bid))
        return _page(b["title"], "\n".join(parts), user, fmt)

    chunks = None
    if k in _TXT_KINDS:
        chunks = reader_mod.chunks(b)
        toc = [{"idx": c["idx"], "title": c["title"]} for c in chunks]
    else:
        toc = reader_mod.epub_toc(b)

    prog = _progress_of(user, bid)
    if prog and 0 <= prog["idx"] < len(toc):
        # ★ 续读链接带上章内比例：章节页拿它换算出「第几屏」。
        #   这里**不必**预渲染那一章（老版本为了让 epub 算锚点号会渲染一次，现在省了）。
        where = ("全书 %d%% · 本章 %d%% 处" % (int(prog["percent"]), int(prog["frac"] * 100))
                 if prog["frac"] > 0.02 else "全书 %d%% · 本章开头" % int(prog["percent"]))
        # ★ 优先用绝对偏移 off 跳回（整数、零精度损失）；老数据只有 frac 时才退化成比例
        pos_arg = ("off=%d" % prog["off"]) if prog.get("off") is not None \
            else ("fr=%.6f" % prog["frac"])
        parts.append('<div class="hint">上次读到第 %d 章（%s）：'
                     '<a href="/lite/book/%d/ch/%d?fs=%d&%s">继续阅读</a></div>'
                     % (prog["idx"] + 1, where, bid, prog["idx"], fs, pos_arg))

    parts.append("<h2>目录（%d 章）</h2>" % len(toc))
    li = []
    for c in toc:
        li.append('<li><a href="/lite/book/%d/ch/%d?fs=%d">%s</a></li>'
                  % (bid, c["idx"], fs, _e(c["title"])))
    parts.append('<ul class="toc">' + "".join(li) + "</ul>")
    return _page(b["title"], "\n".join(parts), user, fmt)


@router.get("/book/{bid}/ch/{idx}")
def chapter_page(bid: int, idx: int, request: Request, off: int = Query(None),
                 fr: float = Query(None), fs: int = Query(None), saved: int = Query(0)):
    user = lite_user(request)
    b = _book_or_404(bid, user)
    fmt_saved = _fmt_of(user)
    fs = _fs(fs) if fs is not None else int(fmt_saved["fs"])
    fmt = dict(fmt_saved)
    fmt["fs"] = fs
    k = reader_mod.kind(b)

    if k in _TXT_KINDS:
        chs = reader_mod.chunks(b)
        total = len(chs)
        if idx < 0 or idx >= total:
            raise HTTPException(404, "章节不存在")
        c = chs[idx]
        title = c["title"]
        src, is_html = c["text"], (k == "md")     # md 的 text 已是渲染后的 HTML
        if is_html:
            src = _sanitize(src)
    elif k in _EPUB_KINDS:
        toc = reader_mod.epub_toc(b)
        total = len(toc)
        if idx < 0 or idx >= total:
            raise HTTPException(404, "章节不存在")
        c = toc[idx]
        title = c["title"]
        # 章节内图片/CSS 走 /api/books/{id}/resource，鉴权用同一个 cookie；
        # 正文里的同书互链由 _epub_link_rewriter 改写成极简页的章链接（原因见 _link_ok）
        src = _sanitize(reader_mod.epub_chapter(b, c["href"],
                                               "/api/books/%d/resource?p=" % bid,
                                               c.get("fragment", "")),
                        _epub_link_rewriter(toc, c.get("href"), bid, fs))
        is_html = True
    else:
        raise HTTPException(400, "这种格式请下载后用设备自带阅读器打开")

    n = len(src)
    # ★ 两条分屏路：选了设备预设 → 按「一屏几行」切（KPW4 = 17 行）；
    #   没选 → 沿用按字数切的老路子（cp 那套标定一个字没动）。
    pset = _preset_of(fmt)
    if pset:
        budget = _preset_lines(pset, fs, fmt["lh"])
        if is_html:
            budget -= LITE_HTML_SAFETY_LINES
        bounds = _bounds_lines(src, budget, _preset_cpl(pset, fs), is_html)
    else:
        bounds = _bounds(src, _page_target(fs, is_html, fmt_saved["cp"]), is_html)
    npages = len(bounds)
    # 定位顺序：绝对偏移 off（我们自己的链接，精确）→ 章内比例 fr（手机存的，四舍五入换算）
    # ★ 这里必须 round 而不是 int：比例是 504/40471 这种除不尽的小数，URL 里还要截到 6 位，
    #   截断下来差 1 个字符就会落到上一屏 —— 表现就是「翻屏翻不动、永远停在第一屏」。
    if off is not None:
        want = max(0, int(off))
    elif fr is not None:
        want = int(round(max(0.0, min(1.0, float(fr))) * n))
    else:
        want = 0
    pg = _pick(bounds, want)
    a = bounds[pg]
    z = bounds[pg + 1] if pg + 1 < npages else n
    body = src[a:z] if is_html else '<pre class="t">' + _e(src[a:z]) + "</pre>"

    # ★ 每翻一屏都会走到这里 —— 「服务器保存最后的阅读地址」就是这一行
    #   （原来是先读进度给「上次读到第 N 章 / 第 M 屏」的提示，站长要求把那些提示全删掉，
    #    所以这里不再读进度，只写。写进度是这一页的核心功能，绝不能一起删。）
    _save_progress(user, bid, k, idx, total, request,
                   frac=(a / float(n) if n else 0.0), page=pg, off=a)

    # ★ 页面只剩两样东西：这一屏正文 + 底部一行导航（没有书名/章名/页码/字号按钮/页脚）
    #   ★ 导航放在正文**之后**：站长要求挪到页面底部，左右手都够得着。
    nav = _chapter_nav(bid, idx, total, fs, pg, npages, bounds)
    # .read 只是给 CSS 一个抓手：预设模式要「行数可数」，段落之间的空白必须是我们
    # 自己定的（浏览器默认的 1em 上下段距 = 2 行，还没法预估），见 _CSS 里的 .read p。
    return _page(title, '<div class="read">' + body + '</div>' + nav, user, fmt, head="")
