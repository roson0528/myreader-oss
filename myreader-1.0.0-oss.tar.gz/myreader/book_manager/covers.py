# -*- coding: utf-8 -*-
"""封面提取/下载与简介生成"""
import os, re, subprocess, time, urllib.request, urllib.parse
from datetime import datetime
from PIL import Image, ImageDraw, ImageFont
import config, db, formats

def _book_ts(book):
    """books.updated_at → epoch 秒；取不到/解析不了就 None（调用方按"不知道"处理）"""
    try:
        v = book["updated_at"]
    except (IndexError, KeyError):
        return None
    s = str(v or "").strip()
    if not s:
        return None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S"):
        try:
            return datetime.strptime(s[:19], fmt).timestamp()
        except ValueError:
            continue
    return None


def ensure_local(book):
    """下载书籍到本地缓存（按 id+size+更新时间复用），返回本地路径"""
    safe = str(book["id"])
    ext = book["ext"] or ".bin"
    local = os.path.join(config.CACHE_DIR, f"b{book['id']}_{safe}{ext}")
    if os.path.exists(local) and os.path.getsize(local) == book["size"]:
        # 只比字节数不够：报告类文档常常"改了几句话、字节数没变"，那样会一直读旧缓存。
        # 书行的 updated_at 比缓存文件更新时间更晚 → 判定过期、重新下载。
        ts = _book_ts(book)
        if ts is None or os.path.getmtime(local) + 1 >= ts:
            return local
    import ftp_service
    ftp_service.download_to(book["path"], local)
    return local


def _run(cmd, timeout=60):
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout,
                           errors="replace")
        return p.stdout, p.returncode
    except Exception:
        return "", -1


def _fetch_url(url, timeout=8, referer=None):
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"}
    if referer:
        headers["Referer"] = referer
    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.read()
    except Exception:
        return None


def _cover_ftp_path(fname):
    """封面在 FTP 上的相对路径"""
    return f"{config.FTP_COVER_DIR}/{fname}"


def _save_cover_data(book_id, data):
    """把封面数据（jpg/png/任意）转成 jpg 后上传到 FTP，返回文件名（相对封面目录）"""
    if not data:
        return None
    fname = f"{book_id}.jpg"
    tmp = os.path.join(config.CACHE_DIR, f"cv_{book_id}_{int(time.time()*1000)}.jpg")
    raw = None
    try:
        if data[:4] in (b"\xff\xd8\xff\xe0", b"\xff\xd8\xff\xe1", b"\xff\xd8\xff\xdb"):
            with open(tmp, "wb") as fh:
                fh.write(data)
        else:  # 非 jpg → 转 jpg
            raw = os.path.join(config.CACHE_DIR, f"cv_{book_id}_raw.bin")
            with open(raw, "wb") as fh:
                fh.write(data)
            im = Image.open(raw).convert("RGB")
            im.thumbnail((500, 500))
            im.save(tmp, "JPEG", quality=85)
        import ftp_service
        ftp_service.upload_file(tmp, _cover_ftp_path(fname))
        # 上传/刮削新封面后清除本地缓存，确保 get_cover 重新从 FTP 拉取最新封面
        local_cache = os.path.join(config.COVER_DIR, fname)
        if os.path.exists(local_cache):
            try:
                os.remove(local_cache)
            except Exception:
                pass
        return fname
    except Exception:
        return None
    finally:
        for p in (tmp, raw):
            if p and os.path.exists(p):
                try:
                    os.remove(p)
                except Exception:
                    pass


def ensure_cover_local(fname):
    """封面本地缓存（源在 FTP），返回本地文件路径或 None"""
    if not fname:
        return None
    local = os.path.join(config.COVER_DIR, fname)
    if os.path.exists(local) and os.path.getsize(local) > 0:
        return local
    import ftp_service
    try:
        ftp_service.download_to(_cover_ftp_path(fname), local, timeout=120)
    except Exception:
        pass
    if os.path.exists(local) and os.path.getsize(local) > 0:
        return local
    return None


def _placeholder(title, author):
    """生成文字占位封面"""
    fname = None
    try:
        w, h = 500, 700
        import random
        seed = sum(ord(c) for c in (title or "书"))
        random.seed(seed)
        bg = (random.randint(30, 120), random.randint(30, 120), random.randint(30, 120))
        im = Image.new("RGB", (w, h), bg)
        d = ImageDraw.Draw(im)
        # 尝试中文字体
        font_big = font_small = None
        for fp in ("/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc",
                   "/usr/share/fonts/truetype/droid/DroidSansFallbackFull.ttf",
                   "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"):
            if os.path.exists(fp):
                try:
                    font_big = ImageFont.truetype(fp, 40)
                    font_small = ImageFont.truetype(fp, 22)
                except Exception:
                    font_big = font_small = None
                break
        def wrap(t, font, maxw):
            if not t:
                return []
            lines, cur = [], ""
            for ch in t:
                if d.textbbox((0, 0), cur + ch, font=font)[2] > maxw:
                    lines.append(cur)
                    cur = ch
                else:
                    cur += ch
            if cur:
                lines.append(cur)
            return lines
        y = 200
        for ln in wrap(title, font_big, w - 60)[:6]:
            d.text(((w - d.textbbox((0, 0), ln, font=font_big)[2]) // 2, y), ln,
                   font=font_big, fill=(255, 255, 255))
            y += 58
        if author:
            d.text(((w - d.textbbox((0, 0), author, font=font_small)[2]) // 2, h - 90),
                   author, font=font_small, fill=(230, 230, 230))
        path = os.path.join(config.CACHE_DIR, f"ph{int(time.time()*1000)}.jpg")
        im.save(path, "JPEG", quality=85)
        return path
    except Exception:
        return None


def extract_cover(book):
    """提取/下载封面，返回 cover 文件名（相对 COVER_DIR）或 None"""
    if book["cover"]:
        return book["cover"]
    ext = (book["ext"] or "").lower()
    data = None
    local = None
    try:
        if ext == ".epub":
            local = ensure_local(book)
            meta = formats.read_epub_meta(local)
            data = meta.get("cover_data")
        elif ext in (".mobi", ".azw3", ".azw", ".prc"):
            local = ensure_local(book)
            out_jpg = os.path.join(config.CACHE_DIR, f"cv{book['id']}.jpg")
            if os.path.exists(out_jpg):
                os.remove(out_jpg)
            _, rc = _run(["ebook-meta", "--get-cover", out_jpg, local], timeout=60)
            if rc == 0 and os.path.exists(out_jpg):
                with open(out_jpg, "rb") as fh:
                    data = fh.read()
                os.remove(out_jpg)
        elif ext == ".pdf":
            local = ensure_local(book)
            out_jpg = os.path.join(config.CACHE_DIR, f"cv{book['id']}.jpg")
            _run(["pdftoppm", "-f", "1", "-singlefile", "-jpeg", "-scale-to", "500",
                  local, os.path.join(config.CACHE_DIR, f"cv{book['id']}")], timeout=60)
            if os.path.exists(out_jpg):
                with open(out_jpg, "rb") as fh:
                    data = fh.read()
                os.remove(out_jpg)
        fname = _save_cover_data(book["id"], data)
        if fname:
            db.ex("UPDATE books SET cover=? WHERE id=?", (fname, book["id"]))
            return fname
    except Exception:
        pass
    # 在线兜底（按后台配置的接入资源顺序；含「电子书内图片」源 —— 它要用到 book）
    try:
        data = download_online_cover(book["title"], book["author"], book)
        if data:
            fname = _save_cover_data(book["id"], data)
            if fname:
                db.ex("UPDATE books SET cover=? WHERE id=?", (fname, book["id"]))
                return fname
    except Exception:
        pass
    # 占位图
    path = _placeholder(book["title"], book["author"])
    if path:
        try:
            with open(path, "rb") as fh:
                data = fh.read()
        finally:
            if os.path.exists(path):
                os.remove(path)
        fname = _save_cover_data(book["id"], data)
        if fname:
            db.ex("UPDATE books SET cover=? WHERE id=?", (fname, book["id"]))
            return fname
    return None


def _clean_title(title):
    """规整书名：去书名号/括号，取冒号前主标题"""
    q = (title or "").strip()
    q = re.sub(r"[《》〈〉「」『』\[\]()（）]", " ", q)
    q = re.split(r"[:：\-—]", q)[0].strip()
    return q


def _douban_suggest(title):
    """豆瓣读书 suggest 搜索，返回条目列表"""
    import json
    q = _clean_title(title)
    if not q:
        return []
    j = _fetch_url(f"https://book.douban.com/j/subject_suggest?q={urllib.parse.quote(q)}", 10)
    if not j:
        return []
    try:
        items = json.loads(j)
    except Exception:
        return []
    return items if isinstance(items, list) else []


def _douban_cover(title, author=""):
    """豆瓣读书刮削封面（中文书首选），返回图片字节或 None"""
    try:
        best = None
        for it in _douban_suggest(title):
            if not isinstance(it, dict):
                continue
            pic = (it.get("pic") or "").strip()
            if not pic.startswith("http"):
                continue
            t = (it.get("title") or "").strip()
            if best is None:
                best = pic
            # 优先标题精确/包含匹配
            if t and (t == title or title in t or t in title):
                best = pic
                break
        if not best:
            return None
        # 尝试大图（l），失败则用原图
        big = best.replace("/view/subject/s/public/", "/view/subject/l/public/")
        data = _fetch_url(big, 12, referer="https://book.douban.com/")
        if not data:
            data = _fetch_url(best, 12, referer="https://book.douban.com/")
        return data
    except Exception:
        return None


def douban_rating(title, author=""):
    """从豆瓣抓取评分（返回字符串如 '8.9'，失败返回 None）"""
    try:
        for it in _douban_suggest(title):
            url = (it.get("url") or "").strip() if isinstance(it, dict) else ""
            if "book.douban.com/subject/" not in url:
                continue
            html = _fetch_url(url, 12, referer="https://book.douban.com/")
            if not html:
                continue
            t = html.decode("utf-8", "replace")
            m = re.search(r'<strong class="ll rating_num"[^>]*>\s*([\d.]+)\s*</strong>', t)
            if m:
                return m.group(1).strip()
        return None
    except Exception:
        return None


def _bing_cover(title, author=""):
    """必应图片搜索刮封面，返回图片字节或 None"""
    try:
        import html as _html
        q = f"{title} {author} 封面".strip()
        raw = _fetch_url(f"https://www.bing.com/images/search?q={urllib.parse.quote(q)}", 10)
        if not raw:
            return None
        txt = _html.unescape(raw.decode("utf-8", "replace"))
        urls = re.findall(r'"murl":"(https?://[^"]+\.(?:jpg|jpeg|png))"', txt)
        if not urls:
            urls = re.findall(r'"murl":"(https?://[^"]+)"', txt)
        for u in urls[:5]:
            data = _fetch_url(u, 10, referer="https://www.bing.com/")
            if data and len(data) > 500 and (data[:2] == b"\xff\xd8" or data[:4] == b"\x89PN"):
                return data
        return None
    except Exception:
        return None


def _google_cover(title, author=""):
    """Google Books 刮封面，返回图片字节或 None"""
    import json
    q = f"{title} {author or ''}".strip()
    try:
        j = _fetch_url(f"https://www.googleapis.com/books/v1/volumes?q={urllib.parse.quote(q)}&maxResults=8", 5)
        if j:
            for item in json.loads(j).get("items") or []:
                il = item.get("volumeInfo", {}).get("imageLinks", {})
                thumb = il.get("thumbnail") or il.get("smallThumbnail")
                if thumb:
                    data = _fetch_url(thumb.replace("http://", "https://"), 8)
                    if data and data[:2] != b"PK":
                        return data
    except Exception:
        pass
    return None


def _openlibrary_cover(title, author=""):
    """Open Library 刮封面，返回图片字节或 None"""
    import json
    q = f"{title} {author or ''}".strip()
    try:
        j = _fetch_url(f"https://openlibrary.org/search.json?title={urllib.parse.quote(title)}&author={urllib.parse.quote(author or '')}&limit=5", 5)
        if j:
            for doc in json.loads(j).get("docs") or []:
                cid = doc.get("cover_i")
                if cid:
                    data = _fetch_url(f"https://covers.openlibrary.org/b/id/{cid}-L.jpg", 5)
                    if data:
                        return data
    except Exception:
        pass
    try:
        j = _fetch_url(f"https://openlibrary.org/search.json?q={urllib.parse.quote(q)}&limit=3", 5)
        if j:
            for doc in json.loads(j).get("docs") or []:
                cid = doc.get("cover_i")
                if cid:
                    data = _fetch_url(f"https://covers.openlibrary.org/b/id/{cid}-L.jpg", 5)
                    if data:
                        return data
    except Exception:
        pass
    return None


_SCRAPERS = {"douban": _douban_cover, "bing": _bing_cover,
             "google": _google_cover, "openlibrary": _openlibrary_cover}


def _source_list():
    """返回启用的刮削源（按 sort_order 排序）；无配置时用默认源"""
    try:
        rows = db.q("SELECT * FROM cover_sources WHERE enabled=1 ORDER BY sort_order, id")
        if rows:
            return [dict(r) for r in rows]
    except Exception:
        pass
    return [{"type": t} for t in ("douban", "bing", "google", "openlibrary", "ebook")]


def ebook_cover(book):
    """「电子书内图片」源：从电子书文件内部取一张封面图，返回图片字节或 None。

    ★ 存在的理由：很多电子书制作时把**纸质版封面的照片**放进了正文第一页/扉页，
      却没有写成 EPUB 的 cover 元数据 —— 「提取内嵌封面」拿不到，在线刮削又常常
      匹配到别的版本。封面其实就在文件里。
        · epub    → 按 spine 阅读顺序找第一张够大的图（formats.read_epub_inner_image）
        · pdf     → 渲染第 1 页（扫描版的第一页通常就是封面照片）
        · mobi/azw3/azw/prc → 先取内嵌封面；没有就转 epub 再按阅读顺序找
        · cbz     → 压缩包里按文件名排序的第一张图（漫画第一页就是封面）
        · txt/md/docx 等没有图的格式 → None（交给下一个源）
    """
    if not book:
        return None
    ext = (book["ext"] or "").lower()
    try:
        if ext == ".epub":
            return formats.read_epub_inner_image(ensure_local(book))[0]
        if ext == ".pdf":
            local = ensure_local(book)
            stem = os.path.join(config.CACHE_DIR, f"ecv{book['id']}")
            out_jpg = stem + ".jpg"
            for p in (out_jpg,):
                if os.path.exists(p):
                    os.remove(p)
            _run(["pdftoppm", "-f", "1", "-singlefile", "-jpeg", "-scale-to", "800",
                  local, stem], timeout=60)
            if os.path.exists(out_jpg):
                with open(out_jpg, "rb") as fh:
                    data = fh.read()
                os.remove(out_jpg)
                return data
            return None
        if ext in (".mobi", ".azw3", ".azw", ".prc"):
            local = ensure_local(book)
            out_jpg = os.path.join(config.CACHE_DIR, f"ecv{book['id']}.jpg")
            if os.path.exists(out_jpg):
                os.remove(out_jpg)
            _, rc = _run(["ebook-meta", "--get-cover", out_jpg, local], timeout=60)
            if rc == 0 and os.path.exists(out_jpg) and os.path.getsize(out_jpg) > 512:
                with open(out_jpg, "rb") as fh:
                    data = fh.read()
                os.remove(out_jpg)
                return data
            # 内嵌封面没有 → 转成 epub 再按阅读顺序找正文里的图（转换贵，只在这条路上走一次）
            conv = os.path.join(config.CACHE_DIR, f"ecv{book['id']}.epub")
            if not os.path.exists(conv):
                _run(["ebook-convert", local, conv], timeout=300)
            if os.path.exists(conv) and os.path.getsize(conv) > 0:
                data = formats.read_epub_inner_image(conv)[0]
                if data:
                    return data
            return None
        if ext == ".cbz":
            import zipfile
            with zipfile.ZipFile(ensure_local(book)) as z:
                names = sorted(n for n in z.namelist()
                               if n.lower().endswith((".jpg", ".jpeg", ".png", ".webp")) and not n.startswith("__MACOSX"))
                for n in names:
                    data = z.read(n)
                    if data and len(data) >= 512:
                        return data
            return None
    except Exception:
        return None
    return None


def download_online_cover(title, author, book=None):
    """刮削封面：按后台配置的接入资源顺序依次尝试，返回图片字节或 None。

    ★ book 是「电子书内图片」这个源必需的（要从文件里取图）；不传就跳过该源 ——
      所以调用方务必把书带进来，否则站长把该源排到第一位也不会生效。
    """
    for s in _source_list():
        stype = (s.get("type") or "").lower()
        try:
            if stype == "ebook":
                data = ebook_cover(book)
            else:
                fn = _SCRAPERS.get(stype)
                data = fn(title, author) if fn else None
            if data:
                return data
        except Exception:
            continue
    return None


def _ebook_meta_field(book, field_re):
    """从 ebook-meta 输出提取字段（标题/作者/评论）"""
    local = ensure_local(book)
    out, rc = _run(["ebook-meta", local], timeout=60)
    if rc != 0:
        return None
    m = re.search(field_re, out, re.I | re.M)
    return m.group(1).strip() if m else None


def generate_intro(book):
    """生成简介文本"""
    ext = (book["ext"] or "").lower()
    desc = None
    try:
        if ext == ".epub":
            local = ensure_local(book)
            desc = formats.read_epub_meta(local).get("description")
        elif ext in (".mobi", ".azw3", ".azw", ".prc"):
            desc = _ebook_meta_field(book, r"(?:Comments|评论|描述)\s*:\s*(.+)")
    except Exception:
        desc = None
    if not desc or len(desc.strip()) < 8:
        desc = make_intro(book)
    return desc.strip()


def make_intro(book):
    size_mb = (book["size"] or 0) / 1048576.0
    size_txt = f"{size_mb:.1f} MB" if size_mb >= 1 else f"{(book['size'] or 0)//1024} KB"
    parts = [f"《{book['title']}》"]
    if book["author"]:
        parts.append(f"作者：{book['author']}")
    if book["category"]:
        cat_name = book["category"].split("_", 1)[-1]
        parts.append(f"分类：{cat_name}")
    if book["clc"]:
        parts.append(f"中图法：{book['clc']}" + (f" / DDC {book['ddc']}" if book["ddc"] else ""))
    parts.append(f"格式：{(book['ext'] or '').lstrip('.').upper()}")
    parts.append(f"大小：{size_txt}")
    return "；".join(parts) + "。"


def enrich_metadata(book):
    """补录元数据：从文件内容读取真实书名/作者，返回 (title, author) 或 (None, None)"""
    ext = (book["ext"] or "").lower()
    title = author = None
    try:
        if ext == ".epub":
            local = ensure_local(book)
            meta = formats.read_epub_meta(local)
            title, author = meta.get("title"), meta.get("author")
        elif ext in (".mobi", ".azw3", ".azw", ".prc", ".pdf", ".fb2"):
            local = ensure_local(book)
            out, rc = _run(["ebook-meta", local], timeout=60)
            if rc == 0:
                m = re.search(r"Title\s*:\s*(.+)", out, re.I)
                if m:
                    title = m.group(1).strip()
                m = re.search(r"Author\(s\)\s*:\s*(.+)", out, re.I)
                if m:
                    author = m.group(1).strip()
    except Exception:
        title = author = None
    # 过滤无意义作者值
    if author and author.strip().lower() in ("unknown", "未知", "佚名", "无名", "none"):
        author = None
    return title, author


def normalize_filename(title, author, ext=""):
    """把书名/作者规整为安全文件名（去除非法字符），返回含扩展名的文件名"""
    def clean(s):
        if not s:
            return ""
        s = re.sub(r'[\\/:*?"<>|\r\n\t]+', " ", s)
        s = re.sub(r"\s+", " ", s).strip(" .")
        return s[:80]
    t = clean(title) or "未命名"
    a = clean(author)
    base = t + ("_" + a if a else "")
    return base + (ext or "")
