# -*- coding: utf-8 -*-
"""lite「设备预设」回归：一屏正好 N 行、不丢字、不溢出（纯函数，不联网不启浏览器）。

站长需求：lite 首页设置行的第 4 个下拉由「每屏字数」改成「预设」。预设是**一台机器的排版档**：
  · 选中时自动设好字体/行距/字号（KPW4 = 黑体 + 紧凑 + 中）；
  · 并让章节页按「一屏正好 N 行」分屏 —— 目标是阅读页正好一屏、不用往下滑。

为什么单开一个纯函数测试：行数是否「刚好一屏」是**算术问题**，可以精确判定；
浏览器里真渲染的结果受本机字体影响（本机中文字体是 0.9em，真机是 1em），
量出来会偏短 —— 那部分放在 test_lite_reader.js 里验「不溢出 + 不太空」。

本文件验四件事：
  1. 站长给的标定点：KPW4 + 22px + 紧凑 = 一屏 17 行、每行 23 字；
     KV + 39px(超大) + 紧凑 = 一屏 20 行、每行 25 字（站长要求）；
  2. 换字号仍然刚好一屏：行数 × 行距 × 字号 ≤ 可用高度，且再加一行就放不下；
  3. 分屏（_bounds_lines）不丢字、每屏不超过行数预算、每个字节都覆盖到；
     html 以行为准分页：页面排满预算行数，**敢切在段落中间**（不再按段落留白）；
  4. 读要宽：库里存了表里没有的 preset 时回落「自定义」，而不是让页面打不开。

运行：venv/bin/python tests/test_lite_preset.py
"""
import os
import re
import sys
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
os.chdir(_ROOT)
import lite  # noqa: E402

_pass = [0]
_fail = [0]


def ok(cond, msg):
    if cond:
        _pass[0] += 1
        print('  ✓ ' + msg)
    else:
        _fail[0] += 1
        print('  ✗ ' + msg)


def main():
    print('  ── 1. 站长给的标定点（KPW4）──')
    p = lite._PRESET_BY_KEY['kpw4']
    lines = lite._preset_lines(p, 22, 1.5)
    cpl = lite._preset_cpl(p, 22)
    ok(lines == 17, 'KPW4 + 22px + 紧凑 = 一屏 %d 行（站长在真机上数的是 17 行）' % lines)
    ok(cpl == 23, 'KPW4 一行放 %d 个全角字（列宽 %dpx ÷ 22px）' % (cpl, p['w']))
    ok(lines == p['lines'],
       '预设表里写的 lines=%d 是真实算得出来的（不是拍脑袋写死的数字）' % p['lines'])
    nav = lite.LITE_NAV_EM * 22 + lite.LITE_NAV_PAD
    need = lines * 1.5 * 22 + lite.LITE_BODY_PAD_V + nav
    ok(abs(need - p['vh']) <= 1,
       '正文 %dpx + 页边距 %d + 导航 %d = %dpx ≈ 预设屏高 %dpx（正好一屏的来源）'
       % (lines * 1.5 * 22, lite.LITE_BODY_PAD_V, int(nav), int(need), p['vh']))

    print('  ── 1b. KV：黑体 紧凑 超大 = 一屏 20 行 ──')
    pv = lite._PRESET_BY_KEY['kv']
    lines_v = lite._preset_lines(pv, 39, 1.5)
    cpl_v = lite._preset_cpl(pv, 39)
    ok(pv['ff'] == 'sans-serif' and abs(pv['lh'] - 1.5) < 0.01 and pv['fs'] == 39,
       'KV 预设 = 黑体 + 紧凑 + 超大（fs=%d, lh=%s）' % (pv['fs'], pv['lh']))
    ok(lines_v == 20 and cpl_v == 25,
       'KV + 39px + 紧凑 = 一屏 %d 行 × 每行 %d 字（站长要的 20 行）' % (lines_v, cpl_v))
    ok(lines_v == pv['lines'],
       'KV 表里写的 lines=%d 是算得出来的（不是拍脑袋写死的数字）' % pv['lines'])
    nav_v = lite.LITE_NAV_EM * 39 + lite.LITE_NAV_PAD
    need_v = lines_v * 1.5 * 39 + lite.LITE_BODY_PAD_V + nav_v
    ok(need_v <= pv['vh'] and need_v + 1.5 * 39 > pv['vh'],
       '20 行正文 %dpx + 页边距 %d + 导航 %d = %dpx：装得下屏高 %dpx、再多一行就装不下'
       % (lines_v * 1.5 * 39, lite.LITE_BODY_PAD_V, int(nav_v), int(need_v), pv['vh']))

    print('  ── 2. 换字号也还是一屏（行数按屏高实时算）──')
    for p, pname in ((lite._PRESET_BY_KEY['kpw4'], 'KPW4'),
                     (lite._PRESET_BY_KEY['kv'], 'KV')):
        for fs, _label in lite.FMT_FS:
            for lh, _lhn in lite.FMT_LH:
                nav = lite.LITE_NAV_EM * fs + lite.LITE_NAV_PAD
                avail = p['vh'] - lite.LITE_BODY_PAD_V - nav
                n = lite._preset_lines(p, fs, lh)
                fits = n * lh * fs <= avail
                tight = (n + 1) * lh * fs > avail
                ok(fits and tight,
                   '[%s] %2dpx/%.2f：%2d 行 × %dpx = %4dpx ≤ 可用 %4dpx，再多一行就装不下'
                   % (pname, fs, lh, n, int(lh * fs), int(n * lh * fs), int(avail)))
    for key, label, cfg in lite.FMT_PRESET:
        if cfg:
            ok(lite._preset_lines(cfg, cfg['fs'], cfg['lh']) == cfg['lines'],
               '预设「%s」表里的行数与算出来的一致（以后加机型时不会写错）' % label)

    print('  ── 3. 按行分屏：不丢字、不超预算 ──')
    src = ''.join('第%d行这是一段中文测试文字用来验证分屏不会丢字也不会溢出' % i + '\n'
                  for i in range(1, 121))
    b = lite._bounds_lines(src, 17, 23, False)
    pages = [src[b[i]:(b[i + 1] if i + 1 < len(b) else len(src))] for i in range(len(b))]
    ok(''.join(pages) == src, 'txt 文本分 %d 屏后拼回来与原文逐字一致（不丢字、不重复）' % len(b))
    ok(b[0] == 0 and len(b) > 1, '第一屏从 0 开始，长文本真的被分成了多屏')

    def est(txt):
        return sum(max(1, -(-int(lite._disp_width(x)) // 23))
                   for x in txt.rstrip('\n').split('\n')) if txt.strip() else 0

    worst = max(est(x) for x in pages)
    ok(worst <= 17, '每屏估计行数 ≤ 17（最多的一屏 %d 行）' % worst)
    ok(min(est(x) for x in pages[:-1]) >= 12,
       '除最后一屏外每屏都排得比较满（最少 %d 行 / 17）' % min(est(x) for x in pages[:-1]))

    h = '<p>' + '</p><p>'.join('第%d段这是一段中文测试文字' % i for i in range(1, 201)) + '</p>'
    bh = lite._bounds_lines(h, 17, 23, True)
    hp = [h[bh[i]:(bh[i + 1] if i + 1 < len(bh) else len(h))] for i in range(len(bh))]
    ok(''.join(hp) == h, 'epub 式 HTML 分 %d 屏后拼回来一致（不丢字、不切在标签中间）' % len(bh))
    hs = lite._html_line_starts(h, 23)
    lp_cnt = [sum(1 for s in hs if bh[i] <= s < (bh[i + 1] if i + 1 < len(bh) else len(h)))
              for i in range(len(bh))]
    ok(max(lp_cnt) <= 17, 'html 每屏不超过预算 17 行（最多的一屏 %d 行）' % max(lp_cnt))
    ok(all(x == 17 for x in lp_cnt[:-1]),
       '除最后一屏外每屏都排满 17 行 —— 按行分页，不再像按段分页那样下半屏空着')

    # 长段落（一段 ≈2 行）：页面要排满就必须切在段落中间，这正是站长要的「以行为准」
    longp = '<p>' + '</p><p>'.join(
        '第%d段' % i +
        '这里是一段比较长的中文测试文字内容用来验证页面需要切在段落中间才能排满十七行的宽度'
        for i in range(1, 41)) + '</p>'
    bl = lite._bounds_lines(longp, 17, 23, True)
    ok(''.join(longp[bl[i]:(bl[i + 1] if i + 1 < len(bl) else len(longp))]
               for i in range(len(bl))) == longp,
       '长段落文档分 %d 屏后拼回来一致（长段落也得能切）' % len(bl))
    pstarts = [m.start() for m in re.finditer(r'<p>', longp)]
    mid = sum(1 for x in bl[1:] if x not in pstarts)
    ok(mid > 0, '长段落下有 %d 个切点落在段落中间（以行为准分页的证据，页面才排得满）' % mid)
    ls = lite._html_line_starts(longp, 23)
    ok(max(sum(1 for s in ls if bl[i] <= s < (bl[i + 1] if i + 1 < len(bl) else len(longp)))
           for i in range(len(bl))) <= 17,
       '长段落每屏仍不超预算（切在中间也不失控）')

    print('  ── 4. 读要宽 + 宽度模型 ──')
    ok(abs(lite._disp_width('中文') - 2.0) < 1e-6, '汉字按 1 个全角字宽计')
    ok(abs(lite._disp_width('abcd') - 2.4) < 1e-6,
       'ASCII 按 0.6 计（保守取宽 → 行数算多 → 宁短不溢出）')
    ok(lite._disp_width('') == 0, '空串宽度为 0')

    # ★★ 血泪回归：老账号那份 lite_fmt 里**没有 preset 键**（本轮上线后就是这样把
    #    站长的 lite 打成 500 的：_fmt_of 判断用 o.get、取值用 o["preset"]，
    #    而 "" 本身是合法 key → 老数据走进分支 → KeyError: 'preset' → 整页打不开）。
    #    这里把四种「历史形态」全过一遍，任何一份都不能抛异常，preset 一律是 ""。
    import copy  # noqa: E402
    legacy = [
        ({"ff": "sans-serif", "lh": 1.5, "fs": 22, "cp": 1900}, "老账号：有 ff/lh/fs/cp、没 preset"),
        ({"ff": "serif", "lh": 1.75, "fs": 39, "cp": 1230}, "老账号：宋体/特大"),
        ({}, "空对象"),
        ({"preset": None}, "preset 显式是 null"),
        ({"preset": "没这个机型"}, "preset 是表里没有的机型"),
    ]
    real = lite._fmt_of
    for obj, label in legacy:
        try:
            out = None
            _saved = lite.db.q
            # 用「库里的值」替换掉这一份 JSON，不动真实数据
            def fake_q(sql, params=(), one=False, _j=obj):
                if "lite_fmt" in sql:
                    return {"lite_fmt": __import__("json").dumps(_j, ensure_ascii=False)}
                return _saved(sql, params, one=one)
            lite.db.q = fake_q
            try:
                out = real({"id": 999999})
            finally:
                lite.db.q = _saved
            ok(out["preset"] == "", "%s → preset=%r（不抛异常、当自定义）" % (label, out["preset"]))
            ok(out["fs"] in [v for v, _ in lite.FMT_FS],
               "%s → 其它项照常读出来（fs=%s）" % (label, out["fs"]))
        except Exception as e:
            ok(False, "%s → 抛异常了：%s: %s" % (label, type(e).__name__, e))

    import db  # noqa: E402
    u = db.q("SELECT id FROM users WHERE username='test' LIMIT 1", one=True)
    if not u:
        ok(False, '找不到测试账号 test（跳过读要宽检查）')
    else:
        row = db.q("SELECT lite_fmt FROM settings WHERE user_id=?", (u['id'],), one=True)
        before = (row['lite_fmt'] if row else '') or ''
        try:
            db.ex("INSERT INTO settings (user_id, lite_fmt) VALUES (?,?) "
                  "ON CONFLICT(user_id) DO UPDATE SET lite_fmt=excluded.lite_fmt",
                  (u['id'], '{"ff":"sans-serif","lh":1.5,"fs":22,"preset":"不存在的机型"}'))
            got = lite._fmt_of(u)
            ok(got['preset'] == '' and got['fs'] == 22,
               '库里存了表里没有的 preset → 回落「自定义」，字号等其它项照常读出来')
        finally:
            db.ex("INSERT INTO settings (user_id, lite_fmt) VALUES (?,?) "
                  "ON CONFLICT(user_id) DO UPDATE SET lite_fmt=excluded.lite_fmt",
                  (u['id'], before))
            after = db.q("SELECT lite_fmt FROM settings WHERE user_id=?", (u['id'],), one=True)
            ok(((after['lite_fmt'] if after else '') or '') == before,
               '测试账号的设置已还原（%s）' % (before or '(空)'))

    print("  ── 5. 真发一次 HTTP：老账号形态下页面必须 200 ──")
    import json as _json  # noqa: E402
    import ssl as _ssl  # noqa: E402
    import urllib.request as _url  # noqa: E402
    import auth  # noqa: E402
    u2 = db.q("SELECT * FROM users WHERE username='test' LIMIT 1", one=True)
    row2 = db.q("SELECT lite_fmt FROM settings WHERE user_id=?", (u2["id"],), one=True)
    before2 = (row2["lite_fmt"] if row2 else "") or ""
    try:
        # 「老账号」形态：存了设置但**没有 preset 键**
        db.ex("INSERT INTO settings (user_id, lite_fmt) VALUES (?,?) "
              "ON CONFLICT(user_id) DO UPDATE SET lite_fmt=excluded.lite_fmt",
              (u2["id"], '{"ff":"sans-serif","lh":1.5,"fs":22,"cp":1900}'))
        tok = auth.create_token(u2)
        for path in ["/lite", "/lite/book/6/ch/0"]:
            req = _url.Request("https://127.0.0.1:9000" + path,
                               headers={"Authorization": "Bearer " + tok})
            try:
                code = _url.urlopen(req, context=_ssl._create_unverified_context(), timeout=25).status
            except Exception as e:
                code = getattr(e, "code", type(e).__name__)
            ok(code == 200, "老账号（没有 preset 键）打开 %s → %s" % (path, code))
    finally:
        db.ex("INSERT INTO settings (user_id, lite_fmt) VALUES (?,?) "
              "ON CONFLICT(user_id) DO UPDATE SET lite_fmt=excluded.lite_fmt",
              (u2["id"], before2))
        ok(((db.q("SELECT lite_fmt FROM settings WHERE user_id=?", (u2["id"],), one=True) or {})
            .get("lite_fmt") if False else
            (db.q("SELECT lite_fmt FROM settings WHERE user_id=?", (u2["id"],), one=True)["lite_fmt"]
             or "")) == before2, "老账号形态测试后设置已还原")

    print('\n极简页设备预设：%d 通过 / %d 失败' % (_pass[0], _fail[0]))
    return 1 if _fail[0] else 0


if __name__ == '__main__':
    sys.exit(main())
