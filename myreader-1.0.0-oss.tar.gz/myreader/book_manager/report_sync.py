# -*- coding: utf-8 -*-
"""把本地“技术报告”投放文件夹（默认 /srv/myreader/report）里的文档，自动同步成
指定账号书架分类下的可读书籍（APP / 网页端可见可读）。

设计（面向“不影响业务正常进行”）：
- 源文件夹**只读**：文件原样留在投放区（那是真源），导入是把**副本**传到书库 FTP
  （upload/user_{id}/report/…），书本体走现成的 WebDAV/FTP 通道 —— 与会员上传书同一套
  机制（category=upload + owner_id 归属，不出现于公共书库），只在 owner 书架里可见。
- 格式：.md / .markdown / .txt 原样入库（阅读器原生读）；.docx 原样入库（原生读）；
  老式 .doc 用 catdoc 转成 UTF-8 的 .txt 入库（阅读器读不了 .doc 二进制）。
- 幂等：文件名 + 内容哈希（sha256，记在 data/report_manifest.json）去重；
  同名同内容 = 跳过；同名内容变了 = 新版：覆盖 FTP 副本、刷新 book 行（id 不变，
  阅读进度不动），并**清掉本地内容缓存**，保证打开就是新内容。
- 投放区是**唯一真源**（§14.119，站长 2026-10-30 反馈）：源文件删掉后，「技术报告」书架上
  那本书也要跟着消失 —— 以前只增不减，删掉一堆文件后书架里还挂着 26 本、实际只剩 8 份。
  回收（`purge_missing`）带两道安全阀：投放区不可读、或扫描结果为空但书架还有书时一律不动
  （后者要 --force 才清），避免挂载异常把整架清空。
- 删书联动（§14.111）：书被删除时 app.py 调 `forget_book()` —— 投放区源文件一并删掉，
  cron 才不会 5 分钟后把同一份报告重新导入；万一源文件删不掉（权限/占用），打**墓碑标记**，
  内容不变就永不复活，内容变了（用户主动改了）才重新导入。
- 隔离：只 INSERT/UPDATE 自己创建的记录（books.path 前缀 upload/user_{id}/report/），
  绝不碰其它书/分类/用户；单个文件失败只跳过并记日志，不中断后续文件。
- 每 5 分钟由 cron 跑一次（与 sync_mirror / sync_code 同节奏）；可手动跑，也可 --dry-run
  预览。代码本身会随 sync_code.sh 同步到另一台机器（没有 cron，不会跑，仅保持代码一致）。

用法：
    python3 report_sync.py                                   # 默认：admin + /srv/myreader/report
    python3 report_sync.py --owner 某人 --dir /tmp/x --collection 某分类
    python3 report_sync.py --dry-run                         # 只扫描报告，不写 FTP / 不写库
"""
import os, sys, json, hashlib, subprocess, argparse, fcntl
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config, db, ftp_service
try:
    import fcntl as _fcntl
except ImportError:                    # Windows 无 fcntl，仅影响并发锁
    _fcntl = None

DEFAULT_DIR = os.environ.get("BOOKMGR_REPORT_DIR", "/srv/myreader/report")
DEFAULT_OWNER = os.environ.get("BOOKMGR_REPORT_OWNER", "admin")
DEFAULT_COLLECTION = os.environ.get("BOOKMGR_REPORT_COLLECTION", "技术报告")
EXTS = (".md", ".markdown", ".txt", ".docx", ".doc")
LOG_FILE = os.path.join(config.DATA_DIR, "report_sync.log")
MANIFEST_FILE = os.path.join(config.DATA_DIR, "report_manifest.json")
CATDOC = "/usr/bin/catdoc"
# 删报告书时要一起清掉的关联表：与 app.py 删除端点同一套口径，另兜几张
# （报告书若被做过听书/格式转换，那些行也跟着走，不留孤儿）
_BOOK_TABLES = ("shelves", "progress", "shares", "notes", "book_reports",
                "share_requests", "book_grants", "download_logs", "convert_logs",
                "leaf_spend", "listen_progress", "listen_session", "listen_logs",
                "ab_job", "file_logs", "ab_lib")
# 跳过不动声色混进来的系统文件/临时文件
_SKIP_PREFIX = ("~$", ".", "#", ".")
_SKIP_SUFFIX = (".tmp", ".part", ".bak", ".swp", ".crdownload", ".download")


def log(msg):
    line = "[%s] %s" % (db.now(), msg)
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except Exception:
        pass
    print(line, flush=True)


def load_manifest():
    try:
        with open(MANIFEST_FILE, encoding="utf-8") as fh:
            m = json.load(fh)
        return m if isinstance(m, dict) else {}
    except Exception:
        return {}


def save_manifest(m):
    tmp = MANIFEST_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(m, fh, ensure_ascii=False, indent=1)
    os.replace(tmp, MANIFEST_FILE)


def owner_by_name(name):
    return db.q("SELECT * FROM users WHERE username=? AND enabled=1", (name,), one=True)


def ensure_collection(uid, name):
    """书架分类不存在就建一个（排到最后），返回分类 id"""
    r = db.q("SELECT id FROM shelf_collections WHERE user_id=? AND name=?",
             (uid, name), one=True)
    if r:
        return r["id"]
    mx = db.q("SELECT COALESCE(MAX(sort_order),0) m FROM shelf_collections WHERE user_id=?",
              (uid,), one=True)["m"]
    return db.ex("INSERT INTO shelf_collections (user_id,name,sort_order,created_at) "
                 "VALUES (?,?,?,?)", (uid, name, mx + 1, db.now()))


def conv_doc_to_txt(path):
    """老式 .doc → UTF-8 文本；失败返回 None（catdoc 缺失也给 None）"""
    try:
        p = subprocess.run([CATDOC, path], capture_output=True, timeout=120)
        if p.returncode != 0 or not p.stdout:
            return None
        return p.stdout.decode("utf-8", "replace").encode("utf-8")
    except Exception:
        return None


def ftp_rel(uid, name):
    return "%s/user_%s/report/%s" % (config.USER_UPLOAD_DIR, uid, name)

def drop_cache(book_id):
    """清掉这本书的本地内容缓存（data/cache/b<id>_*）。

    阅读器取正文走 covers.ensure_local()，命中缓存就不再下载。报告是边写边看的东西，
    改了内容必须让缓存失效，否则打开还是旧文字。返回清掉的文件数。"""
    n = 0
    try:
        pref = "b%d_" % int(book_id)
        for fn in os.listdir(config.CACHE_DIR):
            if fn.startswith(pref):
                try:
                    os.remove(os.path.join(config.CACHE_DIR, fn))
                    n += 1
                except OSError:
                    pass
    except Exception as e:
        log("清理本地缓存失败 book=%s：%s" % (book_id, e))
    return n


def live_rels(uid, files):
    """本次扫描到的文件对应的书路径集合（.doc 入库时副本名换成 .txt，要跟着变）"""
    out = set()
    for name, _p, ext in files:
        copy_name = os.path.splitext(name)[0] + ".txt" if ext == ".doc" else name
        out.add(ftp_rel(uid, copy_name))
    return out


def purge_missing(uid, live, dry_run=False, force=False):
    """投放区里已经没有源文件的报告书 → 从书架移除（连 FTP 副本/进度/笔记/划线一起清）。

    站长反馈（2026-10-30）：report 目录删掉一堆文件后，「技术报告」分类还显示 26 本，
    实际只剩 8 份 —— 根因是以前只导入不回收（「书架是自己的收藏」）。现在的规矩改成
    **投放区就是真源**：文件没了，书就没了。

    安全阀（宁可不动，也不能误删）：
      ① 只碰 owner 名下 upload/user_{id}/report/ 前缀的书，别的书一行都不动；
      ② live 为空（投放区被清空、或挂载丢了）而书架还有书 → 默认不清，要显式 force；
      ③ dry_run 只报不删。
    返回 {"purged": n, "purge_skipped": [标题…]}。"""
    prefix = "%s/user_%s/report/" % (config.USER_UPLOAD_DIR, uid)
    rows = db.q("SELECT id,path,title FROM books WHERE owner_id=? AND path LIKE ?",
                (uid, prefix + "%"), one=False) or []
    victims = [r for r in rows if r["path"] not in live]
    stat = {"purged": 0, "purge_skipped": []}
    if not victims:
        return stat
    if not live and not force:
        stat["purge_skipped"] = [r["title"] for r in victims]
        log("投放区里一份可导入文件都没有，但书架还挂着 %d 本报告书 —— 为防误删，本次不清理"
            "（确认要清空请加 --force）" % len(victims))
        return stat
    for r in victims:
        bid = r["id"]
        name = os.path.basename(r["path"] or "")
        if dry_run:
            log("[预览] 源文件已不存在，将移除报告书 %s（book=%s）" % (name, bid))
            stat["purged"] += 1
            continue
        for t in _BOOK_TABLES:
            try:
                db.ex("DELETE FROM %s WHERE book_id=?" % t, (bid,))
            except Exception as e:
                log("清理 %s（book=%s）失败：%s" % (t, bid, e))
        db.ex("DELETE FROM books WHERE id=?", (bid,))
        try:
            ftp_service.delete(r["path"])
        except Exception as e:
            log("删除 FTP 副本失败 %s：%s" % (name, e))
        drop_cache(bid)
        stat["purged"] += 1
        log("移除报告书 %s（book=%s，投放区源文件已不存在）" % (name, bid))
    return stat


def _skip(name):
    if name.startswith(_SKIP_PREFIX) or name.endswith(_SKIP_SUFFIX):
        return True
    _, ext = os.path.splitext(name)
    return ext.lower() not in EXTS


def scan(report_dir):
    """顶层文件清单（跳过隐藏/临时/不支持格式），返回 [(name, abs_path, ext)]"""
    out = []
    try:
        names = sorted(os.listdir(report_dir))
    except Exception as e:
        log("扫描 %s 失败：%s" % (report_dir, e))
        return out
    for n in names:
        if _skip(n):
            continue
        p = os.path.join(report_dir, n)
        if not os.path.isfile(p):
            continue                       # 子目录不递归（顶层投放区够用，以后要再扩）
        out.append((n, p, os.path.splitext(n)[1].lower()))
    return out


def run(report_dir=DEFAULT_DIR, owner_name=DEFAULT_OWNER,
        collection_name=DEFAULT_COLLECTION, dry_run=False, force=False):
    usr = owner_by_name(owner_name)
    if not usr:
        log("账号 %s 不存在或已停用，终止" % owner_name)
        return {"error": "账号不存在"}
    dir_ok = os.path.isdir(report_dir)
    files = scan(report_dir) if dir_ok else []
    if not dir_ok:
        log("投放区 %s 不存在或不可读 —— 本次跳过回收，不做任何删除" % report_dir)
    elif not files:
        log("投放区 %s 没有可导入的文件（支持 %s）" % (report_dir, "/".join(EXTS)))

    cid = ensure_collection(usr["id"], collection_name)
    prev = load_manifest()
    cur = {}
    stat = {"scanned": len(files), "new": 0, "updated": 0, "unchanged": 0,
            "failed": [], "dry_run": dry_run}
    now = db.now()

    for name, abspath, ext in files:
        stem = os.path.splitext(name)[0]
        src_name = name                     # 投放区源文件名（.doc 转换后副本名会变，源名不变）
        try:
            with open(abspath, "rb") as fh:
                data = fh.read()
        except Exception as e:
            stat["failed"].append("%s（读文件失败 %s）" % (name, e))
            continue
        if not data:
            continue                       # 空文件不导入

        # .doc：转成 UTF-8 文本，入库格式为 .txt
        book_ext = ext
        if ext == ".doc":
            text = conv_doc_to_txt(abspath)
            if text is None:
                stat["failed"].append("%s（.doc 转文本失败，安装 catdoc 或改用 .docx/.md）" % name)
                continue
            data = text
            book_ext = ".txt"
            name = stem + ".txt"           # 副本名与库内 ext 一致
        rel = ftp_rel(usr["id"], name)
        h = hashlib.sha256(data).hexdigest()

        # manifest：老格式 {rel: 哈希字符串} 兼容；新格式 {rel: {h, src[, deleted]}}
        ent = prev.get(rel)
        if isinstance(ent, dict):
            ent_h, ent_src = ent.get("h"), ent.get("src")
            if ent.get("deleted"):
                if ent_h == h:
                    stat["unchanged"] += 1
                    cur[rel] = ent          # 墓碑未变：继续保持跳过
                    continue
                log("重新导入 %s（删除标记后内容已变化）" % src_name)
        else:
            ent_h, ent_src = ent, None

        old = db.q("SELECT * FROM books WHERE owner_id=? AND path=?", (usr["id"], rel), one=True)
        if old is not None and old["size"] == len(data) and ent_h == h:
            stat["unchanged"] += 1
            cur[rel] = {"h": h, "src": src_name}
            continue

        # —— 落盘：先在 FTP 写副本（成功才碰库，避免书指向不存在的文件）——
        if not dry_run:
            try:
                if ftp_service.write_bytes(rel, data) != len(data):
                    raise ValueError("写入字节数不符")
            except Exception as e:
                stat["failed"].append("%s（FTP 写入失败 %s）" % (name, e))
                continue

        if old is None:
            if not dry_run:
                bid = db.ex("INSERT INTO books (path,title,author,category,clc,ddc,ext,size,"
                            "owner_id,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                            (rel, stem, "", "upload", "-", "-", book_ext, len(data),
                             usr["id"], now, now))
                db.ex("INSERT INTO shelves (user_id,book_id,collection_id,added_at) "
                      "VALUES (?,?,?,?)", (usr["id"], bid, cid, now))
            stat["new"] += 1
            log("入库 %s → 书架「%s」（%d 字节）" % (name, collection_name, len(data)))
        else:
            if not dry_run:
                db.ex("UPDATE books SET size=?, updated_at=? WHERE id=?",
                      (len(data), now, old["id"]))
                # 内容变了就把本地缓存扔掉：否则阅读器命中旧缓存，看不到最新内容
                drop_cache(old["id"])
            stat["updated"] += 1
            log("更新 %s（内容变了，旧 %d 字节 → 新 %d 字节）" % (name, old["size"], len(data)))
        cur[rel] = {"h": h, "src": src_name}

    save_manifest(prev if dry_run else cur)

    # 回收：投放区里已经没有源文件的报告书，从书架移除（投放区就是真源）
    if dir_ok:
        ps = purge_missing(usr["id"], live_rels(usr["id"], files),
                           dry_run=dry_run, force=force)
        stat["purged"] = ps["purged"]
        stat["purge_skipped"] = ps["purge_skipped"]
    else:
        stat["purged"] = 0
        stat["purge_skipped"] = []

    log("本次：新增 %d / 更新 %d / 未变 %d / 移除 %d / 失败 %d%s" %
        (stat["new"], stat["updated"], stat["unchanged"], stat["purged"],
         len(stat["failed"]), "（预览，未落盘）" if dry_run else ""))
    return stat


def forget_book(rel, drop_dir=DEFAULT_DIR):
    """报告书删除后的收尾（app.py 删除端点调用；也可手动跑）。

    目标：删书 = 删文件。书的 FTP 副本由删除端点负责删，这里补两件事：
      1) 把投放区里的**源文件**也删掉 —— 否则 cron 每 5 分钟又会把同一份报告重新导入
         （这正是“删了报告文件还在”的根因）；
      2) 若源文件删不掉（权限/占用等），在 manifest 里打**墓碑**（记当时的哈希）：
         内容不变就永不复活，内容变了（用户主动改了）再重新导入。
    源文件名以 manifest 里入库时记录的 src 为准（.doc 转 .txt 的书，副本名≠源名）；
    无记录时用副本文件名兜底。drop_dir 供测试传临时目录，生产用默认投放区。"""
    m = load_manifest()
    ent = m.get(rel)
    src = ent.get("src") if isinstance(ent, dict) else None
    if not src:
        src = os.path.basename(rel)
    if not src:
        return
    src = os.path.basename(src)             # 防目录穿越
    src_path = os.path.join(drop_dir, src)
    removed = False
    try:
        if os.path.isfile(src_path):
            os.remove(src_path)
            removed = True
    except Exception as e:
        log("源文件删除失败 %s：%s" % (src, e))
    if removed:
        m.pop(rel, None)
        log("已删除投放区源文件 %s" % src)
    else:
        cur_h = None
        try:
            if os.path.isfile(src_path):
                with open(src_path, "rb") as fh:
                    cur_h = hashlib.sha256(fh.read()).hexdigest()
        except Exception:
            pass
        m[rel] = {"deleted": True, "src": src, "h": cur_h}
        log("源文件 %s 删除失败，已墓碑标记（内容不变不会重新导入）" % src)
    save_manifest(m)


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="报告文件夹 → 书架分类 自动导入")
    ap.add_argument("--dir", default=DEFAULT_DIR)
    ap.add_argument("--owner", default=DEFAULT_OWNER)
    ap.add_argument("--collection", default=DEFAULT_COLLECTION)
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--force", action="store_true",
                    help="投放区被清空时也照样回收书架上的报告书（默认不动，防挂载异常误删）")
    a = ap.parse_args()
    # 并发锁：cron 每 5 分钟一次，导入大文件时上一个任务还没跑完的情况防重复
    if _fcntl:
        _lk = open(os.path.join(config.DATA_DIR, "report_sync.lock"), "w")
        try:
            _fcntl.flock(_lk, _fcntl.LOCK_EX | _fcntl.LOCK_NB)
        except OSError:
            print("上一次同步还在进行，跳过本次", flush=True)
            sys.exit(0)
    r = run(report_dir=a.dir, owner_name=a.owner,
            collection_name=a.collection, dry_run=a.dry_run, force=a.force)
    if r.get("error"):
        sys.exit(1)