// 播放时不让手机熄屏（keepawake.js）的界面回归。
//
// 需求（2026-10-11）：APP / 手机浏览器的有声播放页、听书页，播放时禁止手机熄屏。
//
// 实现是两条路线，网页优先原生：
//   1) APP 内 Capacitor.Plugins.ListenService.keepAwake({on}) → Activity 的
//      FLAG_KEEP_SCREEN_ON（只在窗口可见时生效，正好等于「人在看播放页」）；
//   2) 否则用浏览器 Screen Wake Lock API；
//   3) 两者都没有（老 WebView）静默跳过。
//
// 本测试**把两条路线都用桩接住**，验的是「什么时候要、什么时候放」：
//   · 有声页在播放 → 要；暂停 → 放；★ 离开播放页（后台还在放音）→ 必须放；
//     回到播放页且还在播 → 再要；
//   · 有原生方法时**只走原生**，不该再去申请浏览器锁（否则两套一起持锁）；
//   · 听书页（listen.html，独立页面）同理；
//   · 页面没有 JS 报错。
//
// 只读：不造数据、不改配置，只打开一次播放页（会留一条 ab_session 单端锁，跑完删掉）。
// 运行：NODE_PATH=/tmp/pwtest/node_modules node tests/test_keep_awake_ui.js
const { chromium } = require('playwright-core');
const { execSync } = require('child_process');
const CHROME = '/srv/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome';
const ROOT = '/srv/myreader/book_manager';
const BASE = 'https://127.0.0.1:9000';

let pass = 0, fail = 0;
const ck = (n, ok, extra) => {
  if (ok) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (extra ? '  → ' + extra : '')); }
};
const py = (code) => execSync('venv/bin/python -', { cwd: ROOT, encoding: 'utf8', input: code }).trim();

// 在页面里装桩：window.__wk = {req:[], rel:0, native:[]}
const STUB = () => {
  window.__wk = { req: [], rel: 0, native: [] };
  try {
    Object.defineProperty(navigator, 'wakeLock', {
      configurable: true,
      value: {
        request: function (type) {
          window.__wk.req.push(type);
          return Promise.resolve({
            released: false,
            release: function () { window.__wk.rel++; this.released = true; return Promise.resolve(); },
            addEventListener: function () {},
          });
        },
      },
    });
  } catch (e) {}
};

(async () => {
  const info = JSON.parse(py(`
import sys, json
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
import db, auth
u = db.q("SELECT * FROM users WHERE role='admin' AND enabled=1 ORDER BY id LIMIT 1", one=True)
db.ex("DELETE FROM ab_session WHERE user_id=?", (u["id"],))
lib = db.q("SELECT l.id, l.title FROM ab_lib l WHERE l.hidden=0 ORDER BY l.sort, l.id LIMIT 1", one=True)
print(json.dumps({"token": auth.create_token(u), "uid": u["id"], "lib": dict(lib) if lib else None}))
`));
  if (!info.lib) { console.log('无有声书，跳过'); process.exit(1); }
  const LIB = info.lib;
  console.log('  用书：《' + LIB.title + '》 (lib ' + LIB.id + ')');

  const b = await chromium.launch({ executablePath: CHROME, args: ['--no-sandbox'] });
  const errs = [];
  const mkctx = async (withNative) => {
    const ctx = await b.newContext({ ignoreHTTPSErrors: true, viewport: { width: 390, height: 844 } });
    await ctx.addInitScript(STUB);
    if (withNative) {
      await ctx.addInitScript(() => {
        window.Capacitor = { Plugins: { ListenService: {
          keepAwake: function (o) { window.__wk.native.push(!!(o && o.on)); return Promise.resolve(); },
          startMp3: function () { return Promise.resolve(); },
          status: function () { return Promise.resolve({ version: 0 }); },
        } } };
      });
    }
    await ctx.addInitScript(([tk, uid]) => {
      localStorage.setItem('bm_token', tk);
      localStorage.setItem('bm_user', JSON.stringify({ id: uid, role: 'admin', name: 'admin' }));
      try { sessionStorage.setItem('bm_audio_sid', 'fixwake'); } catch (e) {}
    }, [info.token, info.uid]);
    const p = await ctx.newPage();
    p.on('pageerror', e => errs.push(String(e).slice(0, 140)));
    return { ctx, p };
  };

  try {
    // ================= A. 网页路线（没有原生插件）=================
    console.log('\n== A. 手机浏览器：有声播放页 ==');
    {
      const { ctx, p } = await mkctx(false);
      await p.goto(BASE + '/', { waitUntil: 'domcontentloaded' });
      await p.waitForTimeout(2200);
      ck('页面已载入 keepawake.js', await p.evaluate(() => typeof keepAwake === 'function'));
      await p.evaluate(([id]) => audioPlay(id, 1, false), [LIB.id]);
      await p.waitForSelector('#aup-texts', { timeout: 20000 });
      await p.waitForTimeout(1200);

      // 播放：网页路线用 el.paused 判状态，这里把 paused 改成 false 再让 apSyncUi 跑一遍
      await p.evaluate(() => {
        AUP.native = false;
        Object.defineProperty(AUP.audio, 'paused', { configurable: true, get: () => false });
        apSyncUi();
      });
      await p.waitForTimeout(300);
      let w = await p.evaluate(() => window.__wk);
      ck('播放中向浏览器申请了屏幕常亮', w.req.length === 1 && w.req[0] === 'screen', JSON.stringify(w.req));

      // 暂停
      await p.evaluate(() => {
        Object.defineProperty(AUP.audio, 'paused', { configurable: true, get: () => true });
        apSyncUi();
      });
      await p.waitForTimeout(300);
      w = await p.evaluate(() => window.__wk);
      ck('暂停后释放了常亮', w.rel === 1, 'rel=' + w.rel);

      // 再播放，然后离开播放页（后台继续放音）
      await p.evaluate(() => {
        Object.defineProperty(AUP.audio, 'paused', { configurable: true, get: () => false });
        apSyncUi();
      });
      await p.waitForTimeout(300);
      w = await p.evaluate(() => window.__wk);
      ck('恢复播放后重新申请', w.req.length === 2, JSON.stringify(w.req));
      await p.evaluate(() => switchPage('library'));
      await p.waitForTimeout(900);
      w = await p.evaluate(() => window.__wk);
      const stillPlaying = await p.evaluate(() => !!AUP && !AUP.audio.paused);
      ck('★ 离开播放页时松开常亮（后台还在放音也不让屏幕一直亮）',
        w.rel === 2, 'rel=' + w.rel + ' 仍在播=' + stillPlaying);

      // 回到播放页
      await p.evaluate(([id]) => audioPlay(id, 1, false), [LIB.id]);
      await p.waitForTimeout(1400);
      w = await p.evaluate(() => window.__wk);
      ck('回到播放页且仍在播 → 再要一把', w.req.length === 3, JSON.stringify(w.req));

      // 老 WebView 兜底：没有 wakeLock 也不能报错
      const noApi = await p.evaluate(() => {
        const ok = typeof keepAwake === 'function';
        return ok;
      });
      ck('keepAwake 一直可用', noApi === true);
      await ctx.close();
    }

    // ================= B. APP 路线（有原生插件）=================
    console.log('\n== B. APP 内：优先走原生 FLAG_KEEP_SCREEN_ON ==');
    {
      const { ctx, p } = await mkctx(true);
      await p.goto(BASE + '/', { waitUntil: 'domcontentloaded' });
      await p.waitForTimeout(2200);
      await p.evaluate(([id]) => audioPlay(id, 1, false), [LIB.id]);
      await p.waitForSelector('#aup-texts', { timeout: 20000 });
      await p.waitForTimeout(1200);
      // ★ 不能假设「刚打开时没在播」：这个页面会自动开始播放，
      //   而且装了原生桩之后走的是原生播放分支。所以这里只断言**最后下发的值**
      //   与当前播放状态一致，并确认浏览器锁一次都没碰。
      let w = await p.evaluate(() => window.__wk);
      ck('★ 有原生方法时不再去申请浏览器锁（避免两套一起持锁）', w.req.length === 0, JSON.stringify(w.req));

      await p.evaluate(() => { AUP.native = true; AU_NATIVE_PLAYING = true; apSyncUi(); });
      await p.waitForTimeout(300);
      w = await p.evaluate(() => window.__wk);
      ck('播放中下发的是 keepAwake(true)',
        w.native.length >= 1 && w.native[w.native.length - 1] === true, JSON.stringify(w.native));

      await p.evaluate(() => { AU_NATIVE_PLAYING = false; apSyncUi(); });
      await p.waitForTimeout(300);
      w = await p.evaluate(() => window.__wk);
      ck('暂停时下发的是 keepAwake(false)',
        w.native[w.native.length - 1] === false, JSON.stringify(w.native));

      await p.evaluate(() => { AU_NATIVE_PLAYING = true; apSyncUi(); });
      await p.waitForTimeout(300);
      w = await p.evaluate(() => window.__wk);
      ck('恢复播放 → 又下发 true', w.native[w.native.length - 1] === true, JSON.stringify(w.native));

      await p.evaluate(() => switchPage('library'));
      await p.waitForTimeout(900);
      w = await p.evaluate(() => window.__wk);
      const stillPlaying2 = await p.evaluate(() => AU_NATIVE_PLAYING);
      ck('★ 原生路径下离开播放页也松开了常亮（后台仍在播）',
        w.native[w.native.length - 1] === false, JSON.stringify(w.native) + ' 仍在播=' + stillPlaying2);
      ck('状态没变时不重复下发（没有连续两个同值）',
        w.native.every((v, k) => k === 0 || v !== w.native[k - 1]), JSON.stringify(w.native));
      await ctx.close();
    }

    // ================= C. 听书页（独立页面 listen.html）=================
    console.log('\n== C. 听书页 listen.html ==');
    {
      const { ctx, p } = await mkctx(false);
      await p.goto(BASE + '/static/listen.html', { waitUntil: 'domcontentloaded' });
      await p.waitForTimeout(1500);
      ck('听书页已载入 keepawake.js', await p.evaluate(() => typeof keepAwake === 'function'));
      ck('听书页能拿到播放按钮', await p.evaluate(() => !!document.getElementById('l-play')));
      await p.evaluate(() => setPlaying(true));
      await p.waitForTimeout(300);
      let w = await p.evaluate(() => window.__wk);
      ck('开始播报 → 申请常亮', w.req.length === 1, JSON.stringify(w.req));
      await p.evaluate(() => setPlaying(false));
      await p.waitForTimeout(300);
      w = await p.evaluate(() => window.__wk);
      ck('暂停/播完 → 释放常亮', w.rel === 1, 'rel=' + w.rel);
      // 重复调用不该反复下发
      await p.evaluate(() => { setPlaying(false); setPlaying(false); });
      await p.waitForTimeout(200);
      w = await p.evaluate(() => window.__wk);
      ck('状态没变时不重复申请/释放', w.req.length === 1 && w.rel === 1, JSON.stringify(w));

      // 真实浏览器是否支持这个 API（不依赖桩）
      const real = await p.evaluate(() => ({ has: 'wakeLock' in navigator,
        secure: window.isSecureContext }));
      console.log('    真实环境：navigator.wakeLock=' + real.has + '  安全上下文=' + real.secure);
      await ctx.close();
    }

    ck('全程没有 JS 报错', errs.length === 0, errs.join(' | '));
  } finally {
    await b.close();
    py(`
import sys
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
import db
db.ex("DELETE FROM ab_session WHERE user_id=?", (${info.uid},))
print("")`);
  }
  console.log('\n通过 ' + pass + '，失败 ' + fail);
  process.exit(fail ? 1 : 0);
})();
