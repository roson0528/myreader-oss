// 一个文件装多章的书：点第 N 章必须**真的跳到该章在文件里的起点**。
//
// 背景（站长的报障）：「点开第六篇『寂静的春天』，播放的却是第五章的内容」。
// 三体恰好 2 章/文件，所以每个文件的第 2 章如果没跳过去、从头播，
// 听到的必然是同一个文件里的第 1 章 —— 全 186 章里有 93 章会中招，看着就是「普遍问题」。
//
// 这个脚本把**网页播放这条路径**钉死：
//   1. 票据接口真的支持 Range（206 + Content-Range），否则 #t=start,end 跳不动；
//   2. <audio> 的 src 里确实带了 #t=<chapStart>,<chapEnd>；
//   3. 播放起来之后 currentTime 落在该章区间内（≈ chapStart + 已播秒数）；
//   4. 高亮的句子属于**该章**（不是同文件里的前一章）。
// 只读服务端数据，不写任何库表。
const { chromium } = require('playwright-core');
const { execSync } = require('child_process');
const fs = require('fs');
const CHROME = '/srv/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome';
const ROOT = '/srv/myreader/book_manager';

let pass = 0, fail = 0;
const ck = (n, ok, extra) => {
  if (ok) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (extra ? '  → ' + extra : '')); }
};
const py = (code) => execSync('venv/bin/python -', { cwd: ROOT, encoding: 'utf8', input: code }).trim();

(async () => {
  const info = JSON.parse(py(`
import sys, json
sys.path.insert(0, '${ROOT}')
import db, auth
u = db.q("SELECT * FROM users WHERE role='admin' AND enabled=1 ORDER BY id LIMIT 1", one=True)
db.ex("DELETE FROM ab_session WHERE user_id=?", (u["id"],))   # 清掉上一轮测试遗留的有声单端锁
# 找一本「确认是一个文件装多章」的书，并取它每个文件里的第 2 章（start_sec > 0）
lib = db.q("""SELECT lib_id, file_seq, MIN(seq) seq, start_sec, dur_sec
               FROM ab_lib_chap WHERE start_sec > 1
               GROUP BY lib_id, file_seq
               ORDER BY lib_id, file_seq LIMIT 3""")
print(json.dumps({"tok": auth.create_token(u), "user": dict(u),
                  "targets": [dict(r) for r in lib]}))`));

  if (!info.targets.length) {
    console.log('  跳过：库里没有「一个文件装多章」的有声书');
    console.log(`\n多章跳转：${pass} 通过 / ${fail} 失败`);
    return;
  }

  const browser = await chromium.launch({
    executablePath: CHROME, args: ['--no-sandbox', '--autoplay-policy=no-user-gesture-required'] });
  // ★ 不注入 Capacitor：走**网页 <audio>** 这条路径（浏览器 / 老 APK 都走它）
  const ctx = await browser.newContext({ ignoreHTTPSErrors: true, viewport: { width: 1440, height: 900 } });
  await ctx.addInitScript(([t, u]) => {
    localStorage.setItem('bm_token', t); localStorage.setItem('bm_user', u);
    // ★ 固定有声会话号：本测试里多个上下文算「同一台设备」，不自己跟自己抢单端锁
    try { sessionStorage.setItem('bm_audio_sid', 'fixwebseek'); } catch (e) {}
  }, [info.tok, JSON.stringify(info.user)]);
  const page = await ctx.newPage();
  await page.goto('https://127.0.0.1:9000/', { waitUntil: 'domcontentloaded' });
  await page.waitForFunction(() => typeof audioPlay === 'function', null, { timeout: 20000 });
  await page.waitForTimeout(1000);

  for (const t of info.targets) {
    await page.evaluate(([lib, ch]) => {
      try { closeAudioPlay && closeAudioPlay(); } catch (e) {}
      audioPlay(lib, ch, false);
    }, [t.lib_id, t.seq]);
    await page.waitForTimeout(4000);
    const r = await page.evaluate(() => {
      const el = document.querySelector('#ap-slot audio') || document.querySelector('audio');
      const lines = Array.from(document.querySelectorAll('.ap-line'));
      const k = lines.findIndex(e => e.classList.contains('on'));
      return { native: AUP.native, chapStart: AUP.chapStart, chapEnd: AUP.chapEnd,
               src: el ? el.getAttribute('src') : '', ct: el ? el.currentTime : null,
               hl: k < 0 ? '' : lines[k].textContent.trim() };
    });
    const tag = `库${t.lib_id} 第${t.seq}章（文件 ${t.file_seq} 起点 ${t.start_sec.toFixed(2)}s）`;
    ck(`* ${tag}：走网页播放`, r.native === false, 'native=' + r.native);
    ck(`* ${tag}：src 带 #t= 区间`, /#t=\d+(\.\d+)?,\d+/.test(r.src), r.src.slice(-34));
    ck(`* ${tag}：真的跳到本章起点（currentTime ≥ chapStart）`,
       r.ct !== null && r.ct >= r.chapStart - 0.5,
       'currentTime=' + (r.ct === null ? '-' : r.ct.toFixed(2)) + ' chapStart=' + r.chapStart.toFixed(2));
    ck(`* ${tag}：没跳过本章终点`, r.ct !== null && r.ct <= r.chapEnd + 0.5, 'ct=' + r.ct);
    ck(`* ${tag}：高亮的是本章的句子`, !!r.hl, r.hl.slice(0, 24));
  }

  // 票据接口必须支持 Range，否则 #t=start,end 形同虚设
  // ★ 票据接口的 seq 是**文件号**、chap 才是章号，别把章号当文件号传
  const t0 = info.targets[info.targets.length - 1];
  const url = await page.evaluate(async ([lib, fseq, ch]) => {
    const d = await api('/api/audiobooks/' + lib + '/ticket?seq=' + fseq + '&chap=' + ch);
    return d.url;
  }, [t0.lib_id, t0.file_seq, t0.seq]);
  const hdr = py(`
import urllib.request, ssl, sys
ctx = ssl._create_unverified_context()
req = urllib.request.Request('https://127.0.0.1:9000${url}'.replace('\\\\', ''),
                             headers={'Range': 'bytes=1000-2000', 'X-BM-No-Push': '1'})
try:
    r = urllib.request.urlopen(req, context=ctx)
    print(r.status, r.headers.get('Content-Range') or '')
except Exception as e:
    print('ERR', e)`);
  ck('* 票据接口支持 Range（206 + Content-Range）',
     /^206/.test(hdr) && /bytes 1000-2000\//.test(hdr), hdr);
  // ★ 收尾：把自己留下的有声单端锁清掉。
  //   不清的话它会活 40 秒租约，紧接着打开 APP 会误报「正在另一台设备上收听」。
  try {
    py(`import sys; sys.path.insert(0, '${ROOT}')
import db
db.ex("DELETE FROM ab_session WHERE user_id=?", (1,))`);
  } catch (e) {}


  await browser.close();
  console.log(`\n多章跳转：${pass} 通过 / ${fail} 失败`);
  process.exit(fail ? 1 : 0);
})();
