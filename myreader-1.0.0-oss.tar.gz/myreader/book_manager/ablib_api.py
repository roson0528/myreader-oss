# -*- coding: utf-8 -*-
"""「有声」页面的接口：列表、详情、章节、逐句文字（歌词）、音频流与听读进度。

挂在 `/api/audiobooks` 下，与既有听书（`/api/books/{id}/listen/*`）互不影响：
* 听书 = 现场 TTS 把书的文字念出来（句子级、走 tts.py）；
* 有声 = 播放**制作模块已经合成好的 MP3**（文件级、走 WebDAV 流代理）。

★ 路由顺序有坑：`/cats` 这类固定路径必须声明在 `/{lib_id}` 之前，
  否则会被当成 lib_id=「cats」解析（§14.44 踩过同一个坑）。
★ 权限：分组权限决定「能不能进这个页面」，免费章节数与树叶决定「能听哪几章」。
  树叶与签到是**同一套货币**（`user_leaves.balance`），但记账走自己的
  `ab_lib_buy` 表 —— 不复用 `leaf_spend`，因为那张表的主键是
  (user_id, book_id, kind)，有声书的「章」没有对应的 book_id，混用会互相覆盖。
"""
import asyncio
import hashlib
import hmac
import json
import os
import re
import sys
import time
from typing import Optional

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)

from fastapi import APIRouter, Depends, HTTPException, Query, Request, Body, Response  # noqa: E402
from fastapi.responses import StreamingResponse  # noqa: E402

import db  # noqa: E402
import ablock  # noqa: E402
import activity  # noqa: E402
from auth import get_current_user, get_optional_user, require_admin  # noqa: E402
from audiobook import dav  # noqa: E402
from audiobook import library as L  # noqa: E402
from audiobook import store as ST  # noqa: E402

router = APIRouter(prefix="/api/audiobooks", tags=["audiobooks"])


def _uid_of(user):
    """取当前用户 id，游客/未登录一律 0。

    ★ 必须用 user["id"] 而不是 user.get("id")：`user` 是 **sqlite3.Row**，
      它没有 .get()，写 .get() 会直接 AttributeError → 500。
      （这个坑在本项目里踩过一次又一次，见 §14.x。）
    """
    if not user:
        return 0
    try:
        return int(user["id"] or 0)
    except (KeyError, IndexError, TypeError, ValueError):
        return 0


def _client_ip(request):
    """取客户端 IP，给后台「听书阅读」日志留痕。

    与 app._client_ip 同一口径（优先 X-Forwarded-For 的第一段）。
    ★ 不能 `from app import _client_ip`：app 会 import 本模块，形成循环导入。
    """
    try:
        fwd = request.headers.get("x-forwarded-for", "")
        if fwd:
            return fwd.split(",")[0].strip()
        return request.client.host if request.client else ""
    except Exception:
        return ""



# ------------------------------------------------------------------ 音频防盗链
# 音频是 <audio> 直接在拉的，**没法带 Authorization 头**，所以以前等于「知道 URL
# 就能下载」。这里改用「签名票据」：
#   * 票据绑定 (用户, 书, 文件, 章节, 到期时间)，换一本书、换一章、换个人都不认；
#   * 默认 6 小时过期（一章最长也就一小时上下，留足余量）；
#   * 只签名不落库，重启服务不失效，也不怕内存里堆票据；
#   * 流接口另外再查一次权限（分组/免费章节/树叶），票据本身不是通行证；
#   * 校验 Referer/Origin，别的站点把链接贴过去也放不出来；
#   * 响应 no-store，避免浏览器把音频缓存给别处复用。
_STREAM_TTL = 6 * 3600


def _stream_key():
    """从 JWT_SECRET 派生出专用签名密钥。

    不直接用 JWT_SECRET：派生出独立密钥，播放票据和登录令牌互不可复用。
    """
    import config
    base = (getattr(config, "JWT_SECRET", "") or "bookmgr-dev-secret").encode()
    return hmac.new(base, b"ablib-stream-v1", hashlib.sha256).digest()


def stream_sign(uid, lib_id, seq, chap, ttl=_STREAM_TTL):
    exp = int(time.time()) + int(ttl)
    sig = _stream_sig(uid, lib_id, seq, chap, exp)
    return exp, sig


def _stream_sig(uid, lib_id, seq, chap, exp):
    msg = "ab|%s|%s|%s|%s|%s" % (int(uid or 0), int(lib_id), int(seq), int(chap or 0), int(exp))
    return hmac.new(_stream_key(), msg.encode(), hashlib.sha256).hexdigest()[:24]


def stream_check(uid, lib_id, seq, chap, exp, sig):
    try:
        exp = int(exp)
    except (TypeError, ValueError):
        return False
    if exp < time.time():
        return False
    return hmac.compare_digest(str(sig or ""), _stream_sig(uid, lib_id, seq, chap, exp))


def _user_by_uid(uid):
    """按票据里的 uid 还原用户（游客=0）。过期/停用的账号不再放行。"""
    try:
        uid = int(uid or 0)
    except (TypeError, ValueError):
        return None
    if uid <= 0:
        return None
    u = db.q("SELECT * FROM users WHERE id=?", (uid,), one=True)
    if not u or not u["enabled"]:
        raise HTTPException(401, "登录状态已失效，请重新登录")
    return u


def _referer_ok(request):
    """防外站盗链：带了 Referer/Origin 且明显是别的站点就拒绝。

    ★ 没有 Referer 一律放行：App 的 WebView、播放器、直连下载都可能不带，
      一律当外链拒掉会把正常播放也拦死。只拦「明确来自其它站点」的情况。
    """
    ref = (request.headers.get("referer") or request.headers.get("origin") or "").strip()
    if not ref:
        return True
    from urllib.parse import urlparse
    try:
        p = urlparse(ref)
    except Exception:
        return False
    if not p.netloc:
        return True                       # file: / capacitor: / app: 这类本地来源
    host = (p.hostname or "").lower()
    if not host:
        return True
    mine = (request.headers.get("host") or "").split(":")[0].lower()
    if not mine:
        return True
    if host == mine or host == "localhost" or host == "127.0.0.1":
        return True
    return host.endswith("." + mine) if mine.count(".") >= 1 else False


# ------------------------------------------------------------------ 通用
def _lib_or_404(lib_id: int):
    lib = L.get_lib(lib_id)
    if not lib:
        raise HTTPException(404, "有声电子书不存在")
    return lib


def _balance(user_id):
    """树叶余额。与签到/听书共用同一个余额（user_leaves.balance）。"""
    r = db.q("SELECT balance FROM user_leaves WHERE user_id=?", (user_id,), one=True)
    return int(r["balance"]) if r else 0


def _bought_book(user_id, lib_id):
    return bool(db.q("SELECT 1 FROM ab_lib_buy WHERE user_id=? AND lib_id=? AND kind='book'",
                     (user_id, lib_id), one=True))


def _bought_chaps(user_id, lib_id):
    return {int(r["chap_seq"]) for r in db.q(
        "SELECT chap_seq FROM ab_lib_buy WHERE user_id=? AND lib_id=? AND kind='chapter'",
        (user_id, lib_id))}


def _spend(user, lib_id, kind, chap_seq, cost):
    """扣树叶并记账。余额不足抛 403；重复购买不重复扣。

    ★ 管理员**不扣树叶，但照样要记一条 leaves=0 的购买记录**：
      `chap_locked()` 判「这一章能不能听」看的是**有没有购买记录**，不是余额。
      早期版本在这里对管理员直接 return 0 就结束了，结果管理员点「兑换」→
      接口 200 → 界面刷新后那一章**依然是锁的**，而且永远解不开
      （余额本来就够，重试多少次都一样）。用户报的「兑换完整本或某章节后依然无法听，
      」就是这个：管理员账号 + 收费设置。
    """
    admin = (user["role"] == "admin")
    if kind == "book" and _bought_book(user["id"], lib_id):
        return 0
    if kind == "chapter" and chap_seq in _bought_chaps(user["id"], lib_id):
        return 0
    if not admin:
        bal = _balance(user["id"])
        if bal < cost:
            raise HTTPException(403, "树叶不足：本次需 %d 片，当前 %d 片。每日签到可获得树叶" % (cost, bal))
    db.ex("INSERT INTO ab_lib_buy (user_id,lib_id,kind,chap_seq,leaves,created_at) VALUES (?,?,?,?,?,?)",
          (user["id"], lib_id, kind, int(chap_seq or 0), 0 if admin else int(cost), db.now()))
    if not admin and cost > 0:
        db.ex("UPDATE user_leaves SET balance=balance-?, updated_at=? WHERE user_id=?",
              (int(cost), db.now(), user["id"]))
    return 0 if admin else int(cost)


def access_info(user, lib, chapters=None):
    """这本书当前用户能听什么。

    返回 {ok, reason, free, per_chapter, per_book, bought_book, bought_chaps, balance}
    ok=False 表示整本都进不去（分组权限或未登录要求）。
    """
    c = L.cfg()
    # ★ 按**这本书**的定价：字段为 -1 时自动回落到后台「有声听书」的全局设置，
    #   所以老数据（没单独设过）行为完全不变。
    pr = L.book_pricing(lib)
    free = pr["free"]
    per_ch = pr["per_chapter"]
    per_book = pr["per_book"]
    info = {"free": free, "per_chapter": per_ch, "per_book": per_book,
            "bought_book": False, "bought_chaps": [], "balance": 0, "ok": True, "reason": ""}

    gs = L.groups()
    if gs:
        mine = set(L.user_group_ids(user))
        if not (mine & set(gs)):
            info["ok"] = False
            info["reason"] = "你所在的用户组暂时没有有声听书权限"
            return info
    # ★ 未登录（游客）一律看不到任何有声内容 —— 列表里不出现、详情/取票/歌词全部 403。
    #   这里原来写的是 `if user is None:`，但 get_optional_user 对未登录返回的是
    #   GUEST_USER **字典**（不是 None），所以这个分支从来没生效过，游客能直接列出
    #   全部有声书。改成按 uid 判定才真正挡得住（§14.74）。
    #   注：admin 也走不到这里，因为 uid>0。
    if _uid_of(user) == 0:
        info["ok"] = False
        info["reason"] = "请先登录后再收听"
        return info

    if user["role"] == "admin":
        # 管理员不受树叶限制：直接当成「已买断」，所有章节都不上锁。
        # （早期版本这里只填了 balance 就 return，bought_book 仍是 False，
        #   于是 chap_locked() 走了「按价格判锁」的分支，管理员反而看到满屏 🔒。）
        info["balance"] = _balance(user["id"])
        info["bought_book"] = True
        return info
    info["balance"] = _balance(user["id"])
    info["bought_book"] = _bought_book(user["id"], lib["id"])
    info["bought_chaps"] = sorted(_bought_chaps(user["id"], lib["id"]))
    return info


def chap_locked(info, seq):
    """某一章是否还锁着（需要树叶）。"""
    if not info["ok"]:
        return True
    if info["bought_book"]:
        return False
    if int(seq) <= int(info["free"] or 0):
        return False
    if int(seq) in set(info["bought_chaps"]):
        return False
    # 不收费时就不锁（每章 0 片、整本 0 片 = 全部免费）
    return bool(info["per_chapter"] or info["per_book"])


def _book_bits(lib):
    """取有声书对应书籍的**评分**、**热度推荐标记**和**封面**。

    ★ 评分和推荐标记挂在 `books` 上，不在 `ab_lib` 上 —— 有声书是同一本书的「听」形态，
      首页「🔥 热度推荐」和「访客推荐」用的是 books 上的**同一个** `guest_featured`。
      所以管理页在有声电子书页面上的「加入热度推荐」，本质上就是给这本书打这个标记，
      和「书籍管理 → 访客热度推荐」完全是同一件事，两边看到的状态也一致。

    ★ 封面也在这里兜底。登记有声书时（`library.register`）会把书的封面抄进
      `ab_lib.cover`，但如果**书是在登记之后才补上封面的**（刮削/手动上传），
      `ab_lib.cover` 就永远是空的 —— 实测《文学回忆录+木心谈木心》正是如此：
      任务跑完登记时书还没封面，之后书有了封面，有声书却一直没封面。
      封面文件名本来就是 `{book_id}.jpg`、前端也走 `/api/books/{book_id}/cover`，
      所以这里直接用书上的封面兜底，从此不会再出现「书有封面、有声书没封面」。

    和 `_rating_of` 合成一次查询：这里每本书本来就要查一次 rating，顺手把标记和封面
    带出来，不额外增加查询次数。
    """
    if not lib.get("book_id"):
        return 0.0, 0, ""
    r = db.q("SELECT rating, COALESCE(guest_featured, 0) AS gf, COALESCE(cover, '') AS cover "
             "FROM books WHERE id=?", (lib["book_id"],), one=True)
    if not r:
        return 0.0, 0, ""
    try:
        rating = float(r["rating"] or 0)
    except (TypeError, ValueError):
        rating = 0.0
    return rating, int(r["gf"] or 0), (r["cover"] or "")


def _lib_brief(lib, user, prog=None, info=None):
    rating, featured, book_cover = _book_bits(lib)
    # 封面：优先用 ab_lib 上抄下来的，空了就用书上现成的（见 _book_bits 的说明）
    cover = (lib["cover"] or "") or book_cover
    d = {
        "id": lib["id"],
        "job_id": lib["job_id"],
        "book_id": lib["book_id"],
        "title": lib["title"],
        "author": lib["author"],
        "cover": cover,
        "cover_url": ("/api/books/%s/cover" % lib["book_id"]) if cover else "",
        "intro": lib["intro"] or "",
        "cat_id": lib["cat_id"] or 0,
        "cat_name": L.cat_name(lib["cat_id"]),
        "rating": rating,
        # 是否已加入首页「🔥 热度推荐」（同时也就是「访客推荐」，两者同一个标记）
        "guest_featured": featured,
        "total_chapters": lib["total_chapters"],
        "total_seconds": lib["total_seconds"],
        "hidden": lib["hidden"],
        "created_at": lib["created_at"],
    }
    if info is not None:
        # 首页也让人一眼看出「能听几章」：免费的都算可听
        n_ch = lib["total_chapters"] or 0
        d["free_chapters"] = min(int(info["free"] or 0), n_ch)
        d["pricing"] = {"free": int(info["free"] or 0),
                        "per_chapter": int(info["per_chapter"] or 0),
                        "per_book": int(info["per_book"] or 0)}
        d["locked"] = bool(info["ok"] and (info["per_chapter"] or info["per_book"])
                           and not info["bought_book"] and n_ch > int(info["free"] or 0))
        d["accessible"] = bool(info["ok"])
    if prog:
        d["progress"] = {
            "chap_seq": prog["chap_seq"],
            "offset": prog["offset"],
            "percent": prog["percent"],
            "seconds": prog["seconds"],
            "updated_at": prog["updated_at"],
        }
    else:
        d["progress"] = None
    return d


# ------------------------------------------------------------------ 分类（必须在 /{lib_id} 之前）
@router.get("/cats")
def cats(user=Depends(get_optional_user)):
    L.init()
    items = L.cats()
    cnt = L.cat_counts()
    return {"cats": [{"id": c["id"], "name": c["name"],
                      "count": cnt.get(int(c["id"]), 0)} for c in items],
            "uncat": cnt.get(0, 0)}


# ------------------------------------------------------------------ 最近收听
# ★ 必须声明在 /{lib_id} 之前：否则 "recent" 会被当成 lib_id 解析（§14.44 同一个坑）
@router.get("/recent")
def recent(user=Depends(get_current_user)):
    """首页「最近阅读」里的有声收听记录（按最后收听时间倒序）。

    只返回**当前用户仍有权限访问**的书：分组权限被改掉之后，历史记录不该
    还留在首页把人往 403 上引。音频本身与买断记录都不动，只读进度表。
    """
    L.init()
    rows = db.q("SELECT * FROM ab_lib_prog WHERE user_id=? ORDER BY updated_at DESC LIMIT 20",
                (user["id"],))
    out = []
    for r in rows:
        lib = L.get_lib(int(r["lib_id"]))
        if not lib or lib["hidden"]:
            continue
        info = access_info(user, lib)
        if not info["ok"]:
            continue
        d = _lib_brief(lib, user, r, info)
        d["listened_at"] = r["updated_at"]        # 首页按这个时间与阅读记录一起排序
        out.append(d)
    return {"items": out}


# ------------------------------------------------------------------ 列表
@router.get("")
def index(cat_id: int = 0, q: str = "", user=Depends(get_optional_user)):
    L.init()
    rows = L.list_libs(cat_id=cat_id or None, q=(q or "").strip() or None)
    prog = L.progress_all(user["id"]) if user else {}
    out = []
    for lib in rows:
        info = access_info(user, lib)
        if not info["ok"]:
            continue                      # 没权限的书不出现在列表里
        out.append(_lib_brief(lib, user, prog.get(int(lib["id"])), info))
    cnt = L.cat_counts()
    return {"items": out, "cats": [{"id": c["id"], "name": c["name"],
                                    "count": cnt.get(int(c["id"]), 0)} for c in L.cats()],
            "total": len(out)}


# ------------------------------------------------------------------ 详情
# ------------------------------------------------------------ 有声阅读单端锁
# ★ 这段必须声明在 `/{lib_id}` **之前**：`/watch` 只有一段路径，
#   放在后面会被 `/{lib_id}` 抢先匹配，把 "watch" 当成 lib_id 去解析（§14.44 同一个坑）。
# ------------------------------------------------------------ 有声阅读单端锁
# 与听书（app.py 的 _listen_*）是**两把独立的锁**，见 ablock.py 开头的说明。
@router.post("/session/hb")
def session_hb(body: dict = Body(default={}), user=Depends(get_current_user)):
    """心跳：刷新租约。被抢了就用 owned=false 让本机停下来。

    单独开一个轻量端点（而不是搭在 /progress 上）：progress 每写一次都要落库、
    还要记活动日志，5 秒一次太重；这里只 UPDATE 一下 ts。
    """
    sid = (body.get("sid") or "").strip()
    if not sid:
        raise HTTPException(400, "缺少会话标识")
    h = ablock.holder(user["id"], sid)
    if h:
        return {"ok": True, "owned": False,
                "reason": "该账号已在另一台设备上继续收听。\n同一账号同一时间只能听一本有声书。",
                "holder": h}
    lib_id = int(body.get("lib_id") or 0)
    ablock.touch(user, lib_id, sid)
    return {"ok": True, "owned": True}


@router.post("/session/take")
def session_take(body: dict = Body(default={}), request: Request = None,
                 user=Depends(get_current_user)):
    """用户确认「在这台设备上继续听」→ 抢过锁，对方会被长连接立刻踢停。"""
    sid = (body.get("sid") or "").strip()
    if not sid:
        raise HTTPException(400, "缺少会话标识")
    stolen = ablock.touch(user, int(body.get("lib_id") or 0), sid,
                          request=request, take=True)
    return {"ok": True, "stolen": bool(stolen)}


@router.post("/session/release")
def session_release(body: dict = Body(default={}), user=Depends(get_current_user)):
    """离开播放页 / 主动停止：立刻释放，别人不必等 40 秒租约到期。"""
    # 注意这里**故意不调 touch** —— 那正是会把会话重建回来的那一步。
    return {"ok": ablock.release(user, (body.get("sid") or "").strip() or None)}


@router.get("/session/holder")
def session_holder(sid: str = Query(""), user=Depends(get_current_user)):
    """当前占用者（排除自己），给前端提示用"""
    return {"holder": ablock.holder(user["id"], sid)}


@router.get("/watch")
async def watch(request: Request, sid: str = Query(""),
                user=Depends(get_current_user)):
    """有声阅读锁的长连接推送。锁被抢占时**立刻**推一条 kick 事件。

    客户端用 fetch 读取（而不是 EventSource），这样才能带上 Authorization 头。
    每 20 秒发一条注释行保活，避免中间代理把连接掐掉。
    """
    q = asyncio.Queue()
    ablock.MAIN_LOOP = asyncio.get_running_loop()
    ablock._watchers.setdefault(user["id"], set()).add(q)

    async def gen():
        try:
            yield ": connected\n\n"
            while True:
                try:
                    item = await asyncio.wait_for(q.get(), timeout=20)
                except asyncio.TimeoutError:
                    if await request.is_disconnected():
                        break
                    yield ": keep-alive\n\n"
                    continue
                yield "event: kick\ndata: %s\n\n" % json.dumps(item, ensure_ascii=False)
        except asyncio.CancelledError:
            raise
        finally:
            ablock._watchers.get(user["id"], set()).discard(q)

    return StreamingResponse(gen(), media_type="text/event-stream", headers={
        "Cache-Control": "no-cache, no-transform",
        "Connection": "keep-alive",
        "X-Accel-Buffering": "no",
    })



@router.get("/{lib_id}")
def detail(lib_id: int, user=Depends(get_optional_user)):
    lib = _lib_or_404(lib_id)
    if lib["hidden"] and not (user and user["role"] == "admin"):
        raise HTTPException(404, "有声电子书不存在")
    info = access_info(user, lib)
    if not info["ok"]:
        raise HTTPException(403, info["reason"])
    chs = L.chapters(lib_id, brief=True)
    for c in chs:
        c["locked"] = chap_locked(info, c["seq"])
    prog = L.progress_get(user["id"], lib_id) if user else None
    d = _lib_brief(lib, user, prog, info)
    d["chapters"] = chs
    d["has_text"] = bool(db.q("SELECT 1 FROM ab_lib_seg WHERE lib_id=? LIMIT 1", (lib_id,), one=True))
    d["access"] = info
    d["dest"] = lib["dest"]
    d["line"] = lib["line"]
    d["voice"] = lib["voice"]
    # ★ 有声书是同一本小说的「听」形态，不少人听完还想看文字版。
    #   电子书详情页本来就有进有声的入口（§14.33），这里补上**反方向**：
    #   首页「热度推荐」现在会把有有声版的书直接指向有声详情，
    #   要是不给一条回电子书的路，想读文字版的人就没入口了。
    bk = db.q("SELECT id, hidden FROM books WHERE id=?", (lib["book_id"],), one=True) if lib["book_id"] else None
    d["book_readable"] = bool(bk and not bk["hidden"])
    return d


# ------------------------------------------------------------------ 逐句文字（歌词）
@router.get("/{lib_id}/lyrics")
def lyrics(lib_id: int, chap: int = Query(1), user=Depends(get_optional_user)):
    lib = _lib_or_404(lib_id)
    info = access_info(user, lib)
    if not info["ok"]:
        raise HTTPException(403, info["reason"])
    if chap_locked(info, chap):
        raise HTTPException(403, "这一章需要树叶兑换后才能收听")
    segs = L.segs(lib_id, chap)
    return {"chap": chap, "segs": segs, "has_text": bool(segs)}


# ------------------------------------------------------------------ 音频流（Range 透传）
_RANGE_RE = re.compile(r"bytes=(\d*)-(\d*)")


@router.get("/{lib_id}/ticket")
def ticket(lib_id: int, seq: int = Query(...), chap: int = Query(0),
           sid: str = Query(""), take: int = Query(0), request: Request = None,
           user=Depends(get_optional_user)):
    """换一个**绑定到这次播放**的签名地址给 <audio> 用（防盗链）。

    ★ 这里同时是**有声阅读单端锁**的入口：一个账号同一时间只允许一个终端在放。
      取票是「开始/继续播放」的必经之路，放在这里挡人，
      前端能拿到干净的 409 去弹「在这台设备上继续听」；
      被抢的那一端则由 /watch 长连接**立刻**推一条 kick，不必等心跳。
      `take=1` 表示用户已确认抢占。游客（uid=0）不受这套约束。
    """
    lib = _lib_or_404(lib_id)
    info = access_info(user, lib)
    if not info["ok"]:
        raise HTTPException(403, info["reason"])
    if _uid_of(user) > 0 and sid:
        ablock.touch(user, lib_id, sid, request=request, take=bool(take))
    rows = [dict(r) for r in L.chapters(lib_id) if int(r["file_seq"]) == int(seq)]
    if not rows:
        raise HTTPException(404, "这个文件不在本书里")
    if chap:
        if not any(int(r["seq"]) == int(chap) for r in rows):
            raise HTTPException(404, "这一章不在该文件里")
        if chap_locked(info, chap):
            raise HTTPException(403, "这一章需要树叶兑换后才能收听")
    else:
        for r in rows:
            if chap_locked(info, r["seq"]):
                raise HTTPException(403, "该文件包含未解锁的章节，请先兑换")
    uid = int(user["id"]) if user else 0
    exp, sig = stream_sign(uid, lib_id, seq, chap)
    url = ("/api/audiobooks/%d/file/%d?chap=%d&u=%d&exp=%d&sig=%s"
           % (lib_id, seq, chap, uid, exp, sig))
    return {"url": url, "expires_in": _STREAM_TTL}


@router.get("/{lib_id}/file/{seq}")
def stream(lib_id: int, seq: int, request: Request, chap: int = Query(0),
           user=Depends(get_optional_user)):
    """把 NAS 上做好的 MP3 流给浏览器，支持 Range（否则拖不动进度条）。

    ★ 必须带签名票据（?u=&exp=&sig=）：<audio> 发不了 Authorization 头，
      只靠 URL 就等于谁拿到链接谁能下载。票据由 /ticket 按当前用户签发，
      绑定「用户+书+文件+章节」，过期或改一位都不认。
    ★ 票据之外仍然**再查一次权限**：分组、免费章节、树叶一个都不省。
    ★ Referer 只拦明确的外站来源，没带 Referer 的（App WebView、播放器）放行。
    """
    lib = _lib_or_404(lib_id)
    if not _referer_ok(request):
        raise HTTPException(403, "禁止外部站点引用该音频")
    uid = request.query_params.get("u")
    exp = request.query_params.get("exp")
    sig = request.query_params.get("sig")
    if not stream_check(uid, lib_id, seq, chap, exp, sig):
        raise HTTPException(403, "播放凭证无效或已过期，请刷新后重试")
    # 票据里的用户才是这次请求的身份（<audio> 不会带 Authorization 头）
    user = _user_by_uid(uid)
    info = access_info(user, lib)
    if not info["ok"]:
        raise HTTPException(403, info["reason"])

    rows = [dict(r) for r in L.chapters(lib_id) if int(r["file_seq"]) == int(seq)]
    if not rows:
        raise HTTPException(404, "这个文件不在本书里")
    if chap:
        if not any(int(r["seq"]) == int(chap) for r in rows):
            raise HTTPException(404, "这一章不在该文件里")
        if chap_locked(info, chap):
            raise HTTPException(403, "这一章需要树叶兑换后才能收听")
    else:
        for r in rows:
            if chap_locked(info, r["seq"]):
                raise HTTPException(403, "该文件包含未解锁的章节，请先兑换")

    f = db.q("SELECT * FROM ab_file WHERE job_id=? AND seq=?", (lib["job_id"], seq), one=True)
    if not f or f["status"] != "uploaded" or not (f["remote"] or "").strip():
        raise HTTPException(404, "音频文件不存在或未上传")

    headers = {}
    rng = request.headers.get("range")
    if rng:
        headers["Range"] = rng
    try:
        up = dav._req("GET", f["remote"], timeout=120, headers=headers or None)
    except Exception as e:
        code = getattr(e, "code", 0)
        if code == 416:
            return Response(status_code=416, headers={"Content-Range": "bytes */%s" % (f["bytes"] or 0)})
        raise HTTPException(502, "从存储读取音频失败：%s" % e)

    h = {k.lower(): v for k, v in up.headers.items()}
    out = {
        "Content-Type": h.get("content-type") or "audio/mpeg",
        "Accept-Ranges": h.get("accept-ranges") or "bytes",
        # 不缓存：避免音频被浏览器缓存后在别处复用，也让票据过期立刻失效
        "Cache-Control": "private, no-store",
        "X-Robots-Tag": "noindex",
    }
    for k in ("content-length", "content-range"):
        if h.get(k):
            out[k.title().replace("Content-Length", "Content-Length")] = h[k]
    status = 206 if getattr(up, "status", None) == 206 else 200

    def pump(chunk=64 * 1024):
        try:
            while True:
                b = up.read(chunk)
                if not b:
                    break
                yield b
        finally:
            try:
                up.close()
            except Exception:
                pass

    return StreamingResponse(pump(), status_code=status, headers=out,
                             media_type=out["Content-Type"])


# ------------------------------------------------------------------ 听读进度
@router.get("/{lib_id}/progress")
def progress_get(lib_id: int, user=Depends(get_current_user)):
    _lib_or_404(lib_id)
    p = L.progress_get(user["id"], lib_id)
    return {"progress": p}


@router.delete("/{lib_id}/progress")
def progress_del(lib_id: int, user=Depends(get_current_user)):
    """把一本有声书移出首页「最近阅读」：只删收听记录，音频与买断都不动。"""
    L.init()
    n = db.ex_count("DELETE FROM ab_lib_prog WHERE user_id=? AND lib_id=?", (user["id"], lib_id))
    return {"ok": True, "removed": n}


@router.post("/{lib_id}/progress")
def progress_put(lib_id: int, request: Request, body: dict = Body(...),
                 user=Depends(get_current_user)):
    lib = _lib_or_404(lib_id)
    info = access_info(user, lib)
    if not info["ok"]:
        raise HTTPException(403, info["reason"])
    # ★ 会话归属：这台终端还拿着锁吗？
    #   被抢之后**不能再写进度**，否则两台机器会互相覆盖对方的进度。
    #   这里刻意**不抛 409**：进度上报的响应体本来就会回到客户端，
    #   用 owned=false 让它安静地停下来，比在日志里刷一堆异常干净。
    #   不带 sid 的老调用（或游客）行为完全不变。
    owned, why = True, ""
    sid = (body.get("sid") or "").strip()
    if sid and _uid_of(user) > 0:
        h = ablock.holder(user["id"], sid)
        if h:
            owned = False
            why = "该账号正在另一台设备上收听《%s》。" % (h.get("title") or "未知有声书")
        else:
            ablock.touch(user, lib_id, sid, request=request)
    if not owned:
        return {"ok": False, "owned": False, "reason": why,
                "progress": L.progress_get(user["id"], lib_id)}
    # ★ 往后台「听书阅读」日志里记一条「有声」活动。
    #   开播约 2.5 秒后前端会强制上报一次进度，所以这里就是「开始听这本有声书」
    #   最可靠的那一个点（详情页点进去但没播、只是翻看，不会误记）。
    #   activity.record 内部按「同一用户 + 同一本书 + 30 分钟」去重，
    #   后续每 15 秒的滚动上报不会把日志刷屏；并且它自身绝不抛异常。
    try:
        activity.record(user, "audio", lib_id, lib["title"],
                        "开始听有声书（第 %s 章）" % (body.get("chap") or 1),
                        _client_ip(request))
    except Exception:
        pass
    try:
        chap = int(body.get("chap") or 1)
    except (TypeError, ValueError):
        chap = 1
    n = db.q("SELECT COUNT(*) c FROM ab_lib_chap WHERE lib_id=?", (lib_id,), one=True)["c"] or 1
    chap = max(1, min(int(n), chap))
    try:
        off = float(body.get("offset") or 0)
    except (TypeError, ValueError):
        off = 0.0
    # 听完这一章就往下一章推进；percent 按「第几章 + 章内进度」算，
    # 详情页的进度条要能反映「听到哪儿」，不能用章序号直接除。
    if body.get("done"):
        chap = min(int(n), chap + 1)
        off = 0.0
    c = L.chapter(lib_id, chap)
    dur = float(c["dur_sec"] or 0) if c else 0.0
    frac = min(0.999, max(0.0, off / dur)) if dur > 0 else 0.0
    pct = min(100.0, max(0.0, (float(chap) - 1.0 + frac) / float(n) * 100.0))
    secs = None
    if body.get("seconds") is not None:
        try:
            secs = max(0.0, float(body["seconds"]))
        except (TypeError, ValueError):
            secs = None
    L.progress_put(user["id"], lib_id, chap, off, pct, secs)
    return {"ok": True, "progress": L.progress_get(user["id"], lib_id)}


# ------------------------------------------------------------------ 树叶兑换
@router.post("/{lib_id}/unlock")
def unlock(lib_id: int, body: dict = Body(...), user=Depends(get_current_user)):
    lib = _lib_or_404(lib_id)
    info = access_info(user, lib)
    if not info["ok"]:
        raise HTTPException(403, info["reason"])
    kind = str(body.get("kind") or "book")
    # 价格必须与 access_info 完全同源，否则会出现「界面显示 5 片、实际按别的价扣」
    pr = L.book_pricing(lib)
    if kind == "book":
        cost = pr["per_book"]
        if cost <= 0:
            raise HTTPException(400, "这本书不需要兑换")
        spent = _spend(user, lib_id, "book", 0, cost)
        return {"ok": True, "spent": spent, "kind": "book",
                "balance": _balance(user["id"])}
    if kind == "chapter":
        try:
            chap = int(body.get("chap") or 0)
        except (TypeError, ValueError):
            chap = 0
        if chap <= 0 or not L.chapter(lib_id, chap):
            raise HTTPException(404, "章节不存在")
        cost = pr["per_chapter"]
        if cost <= 0:
            raise HTTPException(400, "这一章不需要兑换")
        spent = _spend(user, lib_id, "chapter", chap, cost)
        return {"ok": True, "spent": spent, "kind": "chapter", "chap": chap,
                "balance": _balance(user["id"])}
    raise HTTPException(400, "未知的兑换类型")


# ================================================================== 后台
admin = APIRouter(prefix="/api/admin/audiobooks", tags=["audiobooks-admin"])


@admin.get("/cats")
def admin_cats(user=Depends(require_admin)):
    L.init()
    cnt = L.cat_counts()
    return {"cats": [{"id": c["id"], "name": c["name"], "sort": c["sort"],
                      "count": cnt.get(int(c["id"]), 0)} for c in L.cats()],
            "uncat": cnt.get(0, 0)}


@admin.post("/cats")
def admin_cat_add(body: dict = Body(...), user=Depends(require_admin)):
    try:
        cid = L.cat_add((body.get("name") or "").strip(), body.get("sort") or 0)
    except RuntimeError as e:
        raise HTTPException(400, str(e))
    return {"ok": True, "id": cid}


@admin.post("/cats/{cid}")
def admin_cat_edit(cid: int, body: dict = Body(...), user=Depends(require_admin)):
    try:
        if body.get("name") is not None:
            L.cat_rename(cid, body.get("name"))
    except RuntimeError as e:
        raise HTTPException(400, str(e))
    return {"ok": True}


@admin.delete("/cats/{cid}")
def admin_cat_del(cid: int, user=Depends(require_admin)):
    L.cat_del(cid)
    return {"ok": True}


@admin.get("/cfg")
def admin_cfg(user=Depends(require_admin)):
    L.init()
    c = L.cfg()
    groups = []
    try:
        groups = [dict(r) for r in db.q("SELECT id, name FROM user_groups ORDER BY id")]
    except Exception:
        try:
            groups = [dict(r) for r in db.q("SELECT id, name FROM groups ORDER BY id")]
        except Exception:
            groups = []
    return {"cfg": c, "groups": groups}


@admin.post("/cfg")
def admin_cfg_set(body: dict = Body(...), user=Depends(require_admin)):
    c = L.cfg_set(body or {})
    return {"ok": True, "cfg": c}


# ★ 必须声明在 /{lib_id} 之前：FastAPI 按声明顺序匹配，
#   放到后面会被当成 lib_id="register" 解析，直接 422（§14.44 同类坑，实测踩过）。
@admin.post("/register")
def admin_register(body: dict = Body(...), user=Depends(require_admin)):
    """把某个已完成任务登记成有声电子书（制作完成时也会自动调它）。"""
    try:
        job_id = int(body.get("job_id") or 0)
    except (TypeError, ValueError):
        job_id = 0
    if not job_id:
        raise HTTPException(400, "缺少 job_id")
    try:
        lib_id, info = L.register(job_id, cat_id=body.get("cat_id") or 0,
                                  created_by=user["id"], hidden=1 if body.get("hidden") else 0)
    except RuntimeError as e:
        raise HTTPException(400, str(e))
    return {"ok": True, "lib_id": lib_id, **info}


@admin.get("")
def admin_list(user=Depends(require_admin)):
    L.init()
    rows = L.list_libs(include_hidden=True)
    cnt = L.cat_counts()
    g = L.cfg()
    items = []
    for r in rows:
        d = dict(r, cat_name=L.cat_name(r["cat_id"]))
        d["pricing"] = L.book_pricing(r)          # 实际生效（未单独设 = 全局）
        items.append(d)
    return {"items": items,
            "global": {"free": L.free_chapters(), "per_chapter": L.leaf_per_chapter(),
                       "per_book": L.leaf_per_book()},
            "cats": [{"id": c["id"], "name": c["name"], "count": cnt.get(int(c["id"]), 0)}
                     for c in L.cats()]}


@admin.post("/{lib_id}")
def admin_edit(lib_id: int, body: dict = Body(...), user=Depends(require_admin)):
    lib = _lib_or_404(lib_id)
    sets, args = [], []
    if body.get("cat_id") is not None:
        sets.append("cat_id=?")
        args.append(int(body["cat_id"] or 0))
    if body.get("hidden") is not None:
        sets.append("hidden=?")
        args.append(1 if body["hidden"] else 0)
    if body.get("sort") is not None:
        sets.append("sort=?")
        args.append(int(body["sort"] or 0))
    if body.get("title") is not None:
        sets.append("title=?")
        args.append(str(body["title"]).strip() or lib["title"])
    if not sets:
        return {"ok": True, "id": lib_id}
    sets.append("updated_at=?")
    args.append(db.now())
    args.append(lib_id)
    db.ex("UPDATE ab_lib SET %s WHERE id=?" % ",".join(sets), tuple(args))
    return {"ok": True, "id": lib_id}


@admin.post("/{lib_id}/pricing")
def admin_pricing(lib_id: int, body: dict = Body(...), user=Depends(require_admin)):
    """单独设置某本书的免费章节数与树叶价格。

    三个字段都是可选的：不传=保持原样；传 -1=恢复「跟随全局设置」。
    默认（-1）就是跟随后台「有声听书」里的集中设置，所以不动它行为不变。
    """
    L.init()
    if not L.get_lib(lib_id):
        raise HTTPException(404, "有声电子书不存在")
    def num(k):
        if k not in body or body.get(k) is None:
            return None
        try:
            v = int(body.get(k))
        except (TypeError, ValueError):
            raise HTTPException(400, "%s 必须是整数" % k)
        if v < -1:
            raise HTTPException(400, "%s 不能小于 -1（-1 表示跟随全局设置）" % k)
        return v
    L.pricing_set(lib_id, free=num("free_chapters"),
                  per_chapter=num("leaf_per_chapter"), per_book=num("leaf_per_book"))
    lib = L.get_lib(lib_id)
    return {"ok": True, "pricing": L.book_pricing(lib),
            "raw": {"free_chapters": lib["free_chapters"],
                    "leaf_per_chapter": lib["leaf_per_chapter"],
                    "leaf_per_book": lib["leaf_per_book"]}}


@admin.post("/{lib_id}/rebuild")
def admin_rebuild(lib_id: int, user=Depends(require_admin)):
    lib = _lib_or_404(lib_id)
    info = L.build_index(lib_id, lib["job_id"])
    return {"ok": True, **info}


@admin.delete("/{lib_id}")
def admin_unregister(lib_id: int, user=Depends(require_admin)):
    _lib_or_404(lib_id)
    L.unregister(lib_id)
    return {"ok": True}
