# -*- coding: utf-8 -*-
"""推广 / 邀请：两条**独立**的渠道，各有自己的权限开关、码和奖励树叶数。

为什么是两条渠道而不是一个功能
------------------------------
「推广」是把自己的链接撒出去拉陌生人（营销向），「邀请」是点名请人来（熟人向）。
站长的诉求是**分别授权、分别定价** —— 有人只该拿到邀请权，有人该拿推广权，
两者的单价也可以不一样。所以：

* 权限位分开：`user_groups.can_promote` / `can_invite`
* 奖励数分开：`user_groups.promote_reward` / `invite_reward`
* **码也分开**：`invite_codes` 的 UNIQUE 是 `(uid, kind)`，一个用户每条渠道一个码。
  码必须能区分渠道 —— 否则事后没法知道这次注册该按哪个单价发钱。
* 落地页都是 `/?invite=CODE`，靠码本身查回渠道，不靠链接形式区分。

共用的一套规则
--------------
* **有效注册**（防刷）：同一台设备指纹只算**一个**有效注册。
  被邀请人**照样能注册成功**，只是推荐人拿不到奖励 —— 防的是刷奖励，不是把人拦在门外。
* **奖励幂等**：`db.grant_leaves(kind=<渠道>, ref_type="user", ref_id=被邀请人)`，
  `leaf_gain` 上的 UNIQUE(kind,ref_type,ref_id) 保证「一个被邀请人 + 一条渠道只发一次」。
* **奖励时机**：只在被邀请人**账号可用**（enabled=1）时才发。
  开了注册审核的站要等管理员点通过 —— 否则攒一堆待审账号就能刷树叶。

审计动作
--------
`promote_gen` 生成/换码（正文写明哪条渠道） / `invite_register` 注册 /
`promote_reward` 推广奖励 / `invite_reward` 邀请奖励 / `invite_blocked` 码无效被拒
"""
import re
import secrets

from fastapi import APIRouter, Depends, HTTPException, Query
from webdeps import json_body

import db, auth

router = APIRouter(prefix="/api")

KINDS = ("promote", "invite")
KIND_CN = {"promote": "推广", "invite": "邀请"}

# 邀请码字母表：去掉 0/O/1/I/L 这些抄下来会认错的字符
_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"
# ★ 码长**按渠道分开**：
#   邀请码是给人**手抄口述**的，4 位就够（站长明确要求短）；
#   推广码从来不手输 —— 它只出现在推广链接里，所以留 8 位，抗猜。
#   代价：4 位只有 31^4 ≈ 92 万种，理论上能被穷举。这是站长要的取舍，
#   被拒的尝试都会写 invite_blocked 审计，真有异常能查到。
CODE_LEN = {"promote": 8, "invite": 4}
_CODE_RE = re.compile(r"^[A-Z0-9]{4,8}$")

# 注册页用的配置键：1 = 必须填邀请码；0 = 可选
CFG_KEY = "invite_register"


def _kind(k):
    k = str(k or "").strip().lower()
    if k not in KINDS:
        raise HTTPException(400, "渠道参数不对（只能是 promote 或 invite）")
    return k


# ------------------------------------------------------------------ 配置
def invite_required():
    """注册时邀请码是不是**必须**的（后台「注册审核」里的开关）"""
    return db.get_config(CFG_KEY, "0") == "1"


# ------------------------------------------------------------------ 码
def _new_code(kind):
    return "".join(secrets.choice(_ALPHABET) for _ in range(CODE_LEN[kind]))


def norm_code(raw):
    """统一成大写、去掉空格和连字符。用户手抄时容易带空格/小写。"""
    return re.sub(r"[\s\-_]", "", str(raw or "")).upper()


def code_of(uid, kind, create=True):
    """取这个用户在某条渠道上的码；没有就生成一个（一人每渠道一码）。"""
    kind = _kind(kind)
    r = db.q("SELECT code FROM invite_codes WHERE uid=? AND kind=?", (uid, kind), one=True)
    if r:
        return r["code"]
    if not create:
        return ""
    for _ in range(24):                      # 4 位的邀请码空间小得多，多留几次重试
        c = _new_code(kind)
        if db.q("SELECT 1 FROM invite_codes WHERE code=?", (c,), one=True):
            continue
        try:
            db.ex("INSERT INTO invite_codes (uid,kind,code,created_at,disabled) VALUES (?,?,?,?,0)",
                  (uid, kind, c, db.now()))
        except Exception:
            # 并发下可能刚好被另一次请求插进去了，重查一次拿现成的
            again = db.q("SELECT code FROM invite_codes WHERE uid=? AND kind=?", (uid, kind), one=True)
            if again:
                return again["code"]
            continue
        audit(uid, "promote_gen", uid, "生成%s码 %s" % (KIND_CN[kind], c))
        return c
    raise HTTPException(500, "邀请码生成失败，请重试")


def regenerate(uid, kind):
    """换一个码，旧的立刻失效。"""
    kind = _kind(kind)
    c = code_of(uid, kind, create=False)
    for _ in range(24):
        new = _new_code(kind)
        if db.q("SELECT 1 FROM invite_codes WHERE code=?", (new,), one=True):
            continue
        if c:
            # ★ WHERE 里必须带 kind：不带的话会把这个用户另一条渠道的码也换掉，
            #   等于「换推广码」顺手把邀请码作废了。
            db.ex("UPDATE invite_codes SET code=?, created_at=? WHERE uid=? AND kind=?",
                  (new, db.now(), uid, kind))
        else:
            db.ex("INSERT INTO invite_codes (uid,kind,code,created_at,disabled) VALUES (?,?,?,?,0)",
                  (uid, kind, new, db.now()))
        audit(uid, "promote_gen", uid,
              "更换%s码：%s → %s" % (KIND_CN[kind], c or "(无)", new))
        return new
    raise HTTPException(500, "邀请码生成失败，请重试")


def lookup(raw):
    """码 → (uid, kind)；无效/已停用返回 (0, "")"""
    c = norm_code(raw)
    if not c:
        return 0, ""
    r = db.q("SELECT uid,kind,disabled FROM invite_codes WHERE code=?", (c,), one=True)
    if not r or r["disabled"]:
        return 0, ""
    return int(r["uid"]), r["kind"]


def owner_of(code):
    return lookup(code)[0]


def check_code(raw):
    """校验邀请码，返回 (是否有效, 规范化后的码, 原因, uid, kind)"""
    c = norm_code(raw)
    if not c:
        return False, "", "未填写邀请码", 0, ""
    if not _CODE_RE.match(c):
        return False, c, "邀请码格式不正确", 0, ""
    r = db.q("SELECT uid,kind,disabled FROM invite_codes WHERE code=?", (c,), one=True)
    if not r:
        return False, c, "邀请码不存在", 0, ""
    if r["disabled"]:
        return False, c, "邀请码已停用", 0, ""
    return True, c, "", int(r["uid"]), r["kind"]


def link_for(code):
    """推广/邀请链接。用 /?invite=CODE —— 落地页把这个码自动填进注册框。"""
    return "/?invite=" + (code or "")


# ------------------------------------------------------------------ 防刷 / 有效注册
def fp_used_by_others(fp, uid):
    """这个设备指纹是不是已经被**别人**注册过了？

    空指纹一律算「无法判定」→ 调用方按无效处理（防刷口径从严：
    正式的注册页一定会带指纹，只有脚本/老客户端才会不带）。
    """
    fp = (fp or "").strip()
    if not fp:
        return True
    return bool(db.q("SELECT id FROM users WHERE signup_fp=? AND id<>? LIMIT 1",
                     (fp, uid), one=True))


def judge(inviter_id, invitee_id, fp):
    """判定这次注册算不算「有效注册」，返回 (valid, reason)。"""
    if not inviter_id:
        return False, "邀请码无效"
    if int(inviter_id) == int(invitee_id):
        return False, "不能邀请自己"
    if not (fp or "").strip():
        return False, "未取得设备指纹（无法判定是否同一台机器）"
    if fp_used_by_others(fp, invitee_id):
        return False, "同一台机器已有账号，只算一个有效注册"
    return True, ""


# ------------------------------------------------------------------ 注册时记录
def on_register(invitee_id, raw_code, fp):
    """注册成功后调用。**绝不抛异常打断注册** —— 邀请只影响奖励，不该影响注册。

    返回 {"ok":bool, "code":str, "kind":str, "valid":bool, "reason":str}
    """
    try:
        ok, code, why, inviter, kind = check_code(raw_code)
        if not ok:
            # 开关关着的时候允许不填；填了但错的就是错的
            if not norm_code(raw_code) and not invite_required():
                return {"ok": True, "code": "", "kind": "", "valid": False, "reason": "未使用邀请码"}
            audit(invitee_id, "invite_blocked", invitee_id,
                  "邀请码无效：%s（%s）" % (norm_code(raw_code) or "(空)", why))
            return {"ok": False, "code": norm_code(raw_code), "kind": "", "valid": False, "reason": why}

        valid, reason = judge(inviter, invitee_id, fp)
        db.ex("INSERT OR IGNORE INTO invites "
              "(code,kind,inviter_id,invitee_id,fp,valid,reason,rewarded,created_at) "
              "VALUES (?,?,?,?,?,?,?,0,?)",
              (code, kind, inviter, invitee_id, (fp or "").strip(), 1 if valid else 0, reason, db.now()))
        audit(invitee_id, "invite_register", invitee_id,
              "通过%s码 %s 注册（推荐人 #%s）%s"
              % (KIND_CN.get(kind, kind), code, inviter, "，有效" if valid else "，不计有效：" + reason))
        return {"ok": True, "code": code, "kind": kind, "valid": valid,
                "reason": reason, "inviter": inviter}
    except Exception as e:                       # noqa: BLE001
        try:
            audit(invitee_id, "invite_register", invitee_id,
                  "邀请记录失败（不影响注册）：%s" % e)
        except Exception:
            pass
        return {"ok": False, "code": "", "kind": "", "valid": False, "reason": "邀请记录失败"}


def reward_field(kind):
    """渠道 → 分组表里的奖励字段名"""
    return "promote_reward" if kind == "promote" else "invite_reward"


def reward_of(uid, kind):
    """这个用户在这个渠道上每拉到一个有效注册能拿多少树叶"""
    g = db.q("SELECT promote_reward, invite_reward FROM user_groups "
             "WHERE id=(SELECT group_id FROM users WHERE id=?)", (uid,), one=True)
    if not g:
        return 0
    return max(0, int(g[reward_field(kind)] or 0))


def grant_reward(invitee_id):
    """被邀请人账号可用后调用。返回实发树叶数（0 = 没发）。

    ★ 幂等：一是 invites.rewarded 标记，二是 grant_leaves 自己的 UNIQUE 约束。
      两道都要有 —— 单靠标记挡不住「两个请求同时进来」。
    """
    inv = db.q("SELECT * FROM invites WHERE invitee_id=?", (invitee_id,), one=True)
    if not inv or not inv["valid"]:
        return 0
    if inv["rewarded"]:
        return 0
    u = db.q("SELECT enabled FROM users WHERE id=?", (invitee_id,), one=True)
    if not u or not u["enabled"]:
        return 0                                  # 待审核的账号先不发
    kind = inv["kind"] or "promote"
    amount = reward_of(inv["inviter_id"], kind)
    got = db.grant_leaves(inv["inviter_id"], kind, amount,
                          ref_type="user", ref_id=invitee_id,
                          note="%s奖励（被邀请人 #%s）" % (KIND_CN.get(kind, kind), invitee_id))
    # 金额为 0 也算「处理过了」，否则每次登录都会重跑一遍
    db.ex("UPDATE invites SET rewarded=1, rewarded_at=? WHERE invitee_id=?",
          (db.now(), invitee_id))
    if got:
        audit(inv["inviter_id"], kind + "_reward", invitee_id,
              "%s奖励 +%d 树叶（被邀请人 #%s）" % (KIND_CN.get(kind, kind), got, invitee_id))
    return got


# ------------------------------------------------------------------ 统计
def stats(uid, kind):
    total = db.q("SELECT COUNT(*) c FROM invites WHERE inviter_id=? AND kind=?",
                 (uid, kind), one=True)["c"]
    valid = db.q("SELECT COUNT(*) c FROM invites WHERE inviter_id=? AND kind=? AND valid=1",
                 (uid, kind), one=True)["c"]
    leaves = db.q("SELECT COALESCE(SUM(leaves),0) s FROM leaf_gain WHERE user_id=? AND kind=?",
                  (uid, kind), one=True)["s"]
    return {"invited": int(total), "valid": int(valid), "leaves": int(leaves or 0)}


def totals(uid):
    """两条渠道合起来的汇总 —— 「我的」页那张统计卡片用。

    ★ 有意**不看权限**：权限被收回后，历史战绩仍然该看得见，
      不能让人以为「我没拉过人」。卡片整体是否显示由权限决定。
    """
    counts = {"promote": 0, "invite": 0}
    valids = 0
    for r in db.q("SELECT kind, COUNT(*) c, COALESCE(SUM(valid),0) v FROM invites "
                  "WHERE inviter_id=? GROUP BY kind", (uid,)):
        if r["kind"] in counts:
            counts[r["kind"]] = int(r["c"])
        valids += int(r["v"] or 0)
    leaves = db.q("SELECT COALESCE(SUM(leaves),0) s FROM leaf_gain "
                  "WHERE user_id=? AND kind IN ('promote','invite')", (uid,), one=True)["s"]
    return {"promote_count": counts["promote"], "invite_count": counts["invite"],
            "valid_count": valids, "reward_total": int(leaves or 0)}


def my_invites(uid, kind, limit=50):
    rows = db.q("SELECT i.*, u.username, u.name, u.enabled, u.created_at AS reg_at "
                "FROM invites i LEFT JOIN users u ON u.id=i.invitee_id "
                "WHERE i.inviter_id=? AND i.kind=? ORDER BY i.id DESC LIMIT ?",
                (uid, kind, int(limit)))
    return [dict(r) for r in rows]


def allowed(user, kind):
    """这个用户在这条渠道上有没有权限（看分组）"""
    col = "can_promote" if kind == "promote" else "can_invite"
    g = db.q("SELECT can_promote, can_invite FROM user_groups WHERE id=?",
             (user["group_id"],), one=True)
    return bool(g and g[col])


def channel(user, kind):
    """一条渠道的完整信息（无权限时不含码，也不生成）"""
    ok = allowed(user, kind)
    code = code_of(user["id"], kind, create=ok) if ok else ""
    s = stats(user["id"], kind) if ok else {"invited": 0, "valid": 0, "leaves": 0}
    return {"kind": kind, "label": KIND_CN[kind], "allowed": ok,
            "code": code, "link": link_for(code) if code else "",
            "reward": reward_of(user["id"], kind) if ok else 0,
            "invites": my_invites(user["id"], kind) if ok else [], **s}


def audit(user, action, target_id, detail):
    """user 可以传 uid（int），也可以传用户对象（dict / sqlite3.Row）。

    log_audit 要的是「id + username」两样都有的对象，只给 id 会 KeyError。
    """
    if isinstance(user, int):
        r = db.q("SELECT id,username FROM users WHERE id=?", (user,), one=True)
        user = dict(r) if r else {"id": user, "username": ""}
    db.log_audit(user, action, "user", target_id, detail)


# ------------------------------------------------------------------ 接口
@router.get("/promote/config")
def promote_config():
    """注册页用：邀请码是「必须」还是「可选」（不需要登录）"""
    return {"invite_required": invite_required()}


@router.get("/promote/me")
def promote_me(user=Depends(auth.get_current_user)):
    return {"invite_required": invite_required(),
            "totals": totals(user["id"]),
            "channels": {k: channel(user, k) for k in KINDS}}


@router.post("/promote/gen")
def promote_gen(kind: str = Query("promote"), user=Depends(auth.get_current_user)):
    k = _kind(kind)
    if not allowed(user, k):
        raise HTTPException(403, "你所在的分组没有%s权限" % KIND_CN[k])
    code = regenerate(user["id"], k)
    return {"ok": True, "kind": k, "label": KIND_CN[k], "code": code, "link": link_for(code)}


@router.get("/promote/check")
def promote_check(code: str = "", kind: str = Query("promote"),
                  user=Depends(auth.get_current_user)):
    """给推荐人自查：这个码现在能不能用（可选，方便排查）"""
    k = _kind(kind)
    if not allowed(user, k):
        raise HTTPException(403, "你所在的分组没有%s权限" % KIND_CN[k])
    ok, c, why, _uid, real_kind = check_code(code)
    # 码存在但属于另一条渠道时要说清楚，不然「我的码为什么查不到」很难自证
    if ok and real_kind != k:
        return {"ok": False, "code": c,
                "reason": "这是%s码，不是%s码" % (KIND_CN[real_kind], KIND_CN[k])}
    return {"ok": ok, "code": c, "reason": why}
