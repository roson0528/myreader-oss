# -*- coding: utf-8 -*-
"""图书管理与阅读系统 - FastAPI 主应用"""
import os, re, json, time, uuid, mimetypes, logging, threading, secrets, asyncio
from urllib.parse import quote
from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Query, Form, Request, Body
from webdeps import json_body, json_body_or_empty
from fastapi.responses import FileResponse, StreamingResponse, Response
from fastapi.staticfiles import StaticFiles
import config, db, auth, ftp_service, covers, reader, sync, import_xunlei, booklists, dedup, notify, stats, tts, activity, similar
import report_sync                              # 报告投放区（§14.110/§14.111）：删书时联动清投放区源文件
import reading_stats                            # 阅读统计沉淀（§14.112）：日/周/月时长 + 书籍维度，只存不展示
import promote
import lite                                    # 极简阅读页（老设备/无 JS 兼容）
from auth import get_current_user, require_admin, can_manage_book
import listen_admin
import sys as _sys
_sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "ebook_task"))
import classify as _classify

# 有声书制作：完全独立的模块，自带表/线程/临时目录（见 audiobook/ 包）。
# 这里只把它的路由挂上，不改动任何既有逻辑；import 失败也不能连累主应用。
try:
    from audiobook import api as _audiobook_api
except Exception as _ab_e:      # pragma: no cover
    _audiobook_api = None
    logging.getLogger("bookmgr").warning("有声书模块加载失败：%s", _ab_e)

app = FastAPI(title="图书管理系统")
app.include_router(booklists.router)
app.include_router(lite.router)             # /lite：给跑不了现代前端的老设备（第七代 Kindle 等）
app.include_router(promote.router)          # 推广邀请（邀请码 / 推广链接 / 奖励）
if _audiobook_api is not None:
    app.include_router(_audiobook_api.router)

# 「有声」页面（制作好的有声电子书的浏览、播放、进度、权限与后台设置）。
# 与制作模块一样独立成模块，加载失败不能连累主应用。
try:
    import ablib_api as _ablib_api
    app.include_router(_ablib_api.router)
    app.include_router(_ablib_api.admin)
except Exception as _abl_e:      # pragma: no cover
    logging.getLogger("bookmgr").warning("有声书库模块加载失败：%s", _abl_e)


def _setup_logging():
    """给根 logger 补一个带时间戳的 handler。

    uvicorn 只配置了自己的 logger（uvicorn / uvicorn.error / uvicorn.access），
    根 logger 没有任何 handler，也没有改过级别，所以应用侧
    logging.warning/error 只能落到 logging.lastResort —— 无时间戳、无级别、
    无 logger 名。server.log 里因此长期只有 uvicorn 自己的输出。
    这里只加 handler、不动级别（根 logger 保持默认 WARNING），
    既让应用日志可追溯，又不会把 paramiko 之类的 INFO 噪音引进来。
    """
    root = logging.getLogger()
    if any(getattr(h, "_bookmgr", False) for h in root.handlers):
        return
    h = logging.StreamHandler()      # 默认 stderr，已被 systemd 重定向进 server.log
    h.setFormatter(logging.Formatter(
        "%(asctime)s %(levelname)s [%(name)s] %(message)s", "%Y-%m-%d %H:%M:%S"))
    h._bookmgr = True
    root.addHandler(h)


_setup_logging()

# 站内分享：接收方书架中自动出现的系统分组名
SHARE_COLLECTION_NAME = "来自分享"


@app.on_event("startup")
def _startup():
    db.init_db()
    if not db.q("SELECT id FROM users WHERE username=?", (config.DEFAULT_ADMIN["username"],), one=True):
        db.ex("INSERT INTO users (username,password_hash,role,quota,enabled,created_at) VALUES (?,?,?,?,?,?)",
              (config.DEFAULT_ADMIN["username"], auth.hash_password(config.DEFAULT_ADMIN["password"]),
               "admin", 99999, 1, db.now()))
    if config.SYNC_INTERVAL > 0:
        sync.start_sync_loop(config.SYNC_INTERVAL)
    stats.start()          # 网站统计：后台落盘线程 + 昨天封盘
    activity.start()       # 阅读/听书日志：后台落盘线程（写 WebDAV，保留三年）
    reading_stats.start()  # 阅读统计沉淀：日/周/月时长 + 书籍维度（只存不展示，§14.112）
    # TTS 音色清单预热：冷启动那次必须真取一次，放在启动阶段做，
    # 就不会落到用户的 /listen/seg 请求上（见 tts.warm_voices 的说明）。
    try:
        tts.warm_voices()
    except Exception as _e:
        log.warning("音色清单预热失败（不影响启动）：%s", _e)


# ---------- 工具 ----------
def _book_or_404(book_id):
    b = db.q("SELECT * FROM books WHERE id=?", (book_id,), one=True)
    if not b:
        raise HTTPException(404, "书籍不存在")
    return b


def _accessible_book_or_404(book_id, user):
    """读取书籍：管理员见全部；普通用户仅能访问公共书与自己上传的私人书"""
    b = _book_or_404(book_id)
    if not auth.can_access_book(user, b):
        raise HTTPException(404, "书籍不存在")
    return b


def _user_from_request(request: Request):
    """支持 Authorization 头或 ?token= 查询参数（供 <img> 等无头请求）"""
    authz = request.headers.get("authorization", "")
    if authz.startswith("Bearer "):
        payload = auth.decode_token(authz[7:])
    else:
        tok = (request.query_params.get("token") or "").strip()
        # 兼容下载链接末尾的“原文件扩展名”后缀（如 ...?token=JWT.azw3），解码前先剥掉
        tok = re.sub(r"\.[A-Za-z0-9]{2,5}$", "", tok)
        payload = auth.decode_token(tok)
    if payload:
        u = db.q("SELECT * FROM users WHERE id=?", (payload["uid"],), one=True)
        if u and u["enabled"]:
            return u
    raise HTTPException(401, "未登录")


def get_user_flex(request: Request):
    return _user_from_request(request)


def _book_json(b, with_intro=False):
    d = dict(b)
    d["cover_url"] = f"/api/books/{b['id']}/cover" if b["cover"] else None
    d["size_mb"] = round((b["size"] or 0) / 1048576.0, 2)
    d["kind"] = reader.kind(b)
    d.pop("intro", None)
    if with_intro:
        d["intro"] = _ensure_intro(b)
    return d


def _ensure_intro(b):
    if not b["intro"] or not b["intro_done"]:
        intro = covers.generate_intro(b)
        db.ex("UPDATE books SET intro=?, intro_done=1 WHERE id=?", (intro, b["id"]))
        return intro
    return b["intro"]


def _ftp_parent(b):
    """书籍文件在 FTP 上的父目录：会员上传的书放在会员专属目录，系统书按分类目录"""
    if b["owner_id"]:
        return f"{config.USER_UPLOAD_DIR}/user_{b['owner_id']}"
    return b["category"]


MIME = {
    ".epub": "application/epub+zip", ".pdf": "application/pdf",
    ".txt": "text/plain; charset=utf-8", ".mobi": "application/x-mobipocket-ebook",
    ".azw3": "application/octet-stream", ".azw": "application/octet-stream",
    ".html": "text/html; charset=utf-8", ".htm": "text/html; charset=utf-8",
    ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png",
    ".gif": "image/gif", ".svg": "image/svg+xml", ".css": "text/css",
}


def _mime(name):
    ext = os.path.splitext(name)[1].lower()
    return MIME.get(ext, mimetypes.guess_type(name)[0] or "application/octet-stream")


def _file_response(request: Request, local_path, filename, download=False):
    """带 Range 支持的文件响应"""
    size = os.path.getsize(local_path)
    rng = request.headers.get("range")
    cd = "attachment" if download else "inline"
    _m = re.search(r"(\.[A-Za-z0-9]{1,10})$", filename)
    # 纯 ASCII 的 filename= 兜底：Kindle 等老浏览器不认 filename*=UTF-8'' 格式，
    # 只按 filename= 里的扩展名判断文件类型（azw/prc/mobi/txt 白名单）
    plain = "download" + (_m.group(1) if _m else "")
    common = {"Content-Disposition": f"{cd}; filename=\"{plain}\"; filename*=UTF-8''{quote(filename)}",
              "Accept-Ranges": "bytes"}
    if rng:
        m = re.match(r"bytes=(\d*)-(\d*)", rng)
        if m:
            start = int(m.group(1)) if m.group(1) else 0
            end = int(m.group(2)) if m.group(2) else size - 1
            end = min(end, size - 1)
            if start <= end:
                def gen():
                    with open(local_path, "rb") as f:
                        f.seek(start)
                        remain = end - start + 1
                        while remain > 0:
                            c = f.read(min(1 << 20, remain))
                            if not c:
                                break
                            remain -= len(c)
                            yield c
                return StreamingResponse(gen(), status_code=206,
                                         media_type=_mime(filename),
                                         headers={**common, "Content-Range": f"bytes {start}-{end}/{size}", "Content-Length": str(end - start + 1)})
    return FileResponse(local_path, media_type=_mime(filename), headers=common)


def _client_ip(request: Request):
    fwd = request.headers.get("x-forwarded-for", "")
    if fwd:
        return fwd.split(",")[0].strip()
    return request.client.host if request.client else ""


# ---------- 认证 ----------
import secrets as _secrets

AGREE_MSG = "请先阅读并勾选同意《用户须知与免责公告》"


@app.post("/api/register")
def register(username: str = Form(...), password: str = Form(...),
             name: str = Form(""), email: str = Form(""), phone: str = Form(""),
             agree: str = Form("0"), invite: str = Form(""), fp: str = Form("")):
    if len(username) < 2 or len(password) < 4:
        raise HTTPException(400, "用户名至少2位，密码至少4位")
    if db.q("SELECT id FROM users WHERE username=?", (username,), one=True):
        raise HTTPException(400, "用户名已存在")
    if not name.strip():
        raise HTTPException(400, "请填写昵称")
    if db.nickname_taken(name):
        raise HTTPException(400, "该昵称已被使用，请换一个")
    if not re.match(r"^[\w.+-]+@[\w-]+(\.[\w-]+)+$", email.strip()):
        raise HTTPException(400, "邮箱格式不正确")
    if not re.match(r"^1[3-9]\d{9}$", phone.strip()):
        raise HTTPException(400, "手机号格式不正确（需为大陆 11 位手机号）")
    if agree not in ("1", "true", "on"):
        raise HTTPException(400, AGREE_MSG)
    # ★ 邀请码**在建号之前**校验：码不对就根本不该产生这条「邀请注册」记录，
    #   否则后台的推广统计里会混进一堆垃圾（用户其实没注册成功）。
    inv_code = promote.norm_code(invite)
    if promote.invite_required() and not inv_code:
        # 被拒的邀请码尝试也要留痕（有人拿脚本猜码时，这是唯一的线索）
        db.log_audit(None, "invite_blocked", "user", None,
                     f"注册未填邀请码（本站已开启邀请注册），尝试的用户名 {username}")
        raise HTTPException(400, "本站已开启邀请注册，请填写邀请码")
    if inv_code:
        ok_code, _c, why, _inviter, _kind = promote.check_code(inv_code)
        if not ok_code:
            db.log_audit(None, "invite_blocked", "user", None,
                         f"邀请码无效被拒：{inv_code}（{why}），尝试的用户名 {username}")
            raise HTTPException(400, "邀请码无效：%s" % why)
    review = db.get_config("registration_review", "0") == "1"
    enabled = 0 if review else 1
    guest = db.group_by_code("guest")
    ts = db.now()
    # last_login：注册接口在非审核模式下会直接下发 token（注册即登录），所以这里就是首次登录；
    # 走审核的账号还没登录过，留空，等审核通过后由 /api/login 写入。
    uid = db.ex("INSERT INTO users (username,password_hash,role,quota,enabled,group_id,name,email,phone,created_at,last_login,signup_fp) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                (username, auth.hash_password(password), "user", db.quota_from_group(guest),
                 enabled, guest["id"], name.strip(), email.strip(), phone.strip(), ts,
                 None if review else ts, (fp or "").strip()[:128]))
    db.log_audit({"id": uid, "username": username}, "register", "user", uid,
                 f"注册新用户 {username}" + ("（待审核）" if review else "")
                 + (f"（邀请码 {inv_code}）" if inv_code else ""))
    # 邀请关系：记下来 + 判定是否「有效注册」。★ 绝不让它打断注册。
    inv_res = promote.on_register(uid, invite, fp)
    if not review:
        # 账号直接可用 → 该发的奖励现在发（审核模式下等到审核通过再发）
        promote.grant_reward(uid)
    # 仅对新注册用户发送欢迎消息，已注册的老用户不补发
    try:
        if send_welcome(uid):
            db.log_audit({"id": uid, "username": username}, "welcome_msg", "user", uid,
                         "新注册用户发送欢迎消息")
    except Exception:
        pass
    if review:
        return {"pending": True, "message": "注册成功，等待管理员审核后即可登录",
                "invite": inv_res}
    u = db.q("SELECT * FROM users WHERE id=?", (uid,), one=True)
    return {"token": auth.create_token(u), "user": _pub_user(u), "invite": inv_res}


@app.post("/api/forgot-password")
def forgot_password(username: str = Form(...), email: str = Form(""), phone: str = Form("")):
    """找回密码：核验注册时填写的邮箱与手机号一致后发放一次性重置令牌（15 分钟有效）"""
    u = db.q("SELECT * FROM users WHERE username=?", (username.strip(),), one=True)
    if not u or (u["email"] or "") != email.strip() or (u["phone"] or "") != phone.strip():
        raise HTTPException(400, "用户名与注册信息（邮箱/手机号）不匹配，无法重置密码")
    if not u["enabled"]:
        raise HTTPException(400, "账号已禁用，无法重置密码")
    token = _secrets.token_urlsafe(24)
    db.set_config("pwreset_" + token, json.dumps({"uid": u["id"], "exp": time.time() + 900}))
    db.log_audit(u, "forgot_password", "user", u["id"], "发起找回密码")
    return {"ok": True, "token": token, "message": "身份核验通过（演示环境：令牌直接返回，15 分钟内有效）"}


@app.post("/api/reset-password")
def reset_password(token: str = Form(...), password: str = Form(...)):
    if len(password) < 4:
        raise HTTPException(400, "密码至少4位")
    raw = db.get_config("pwreset_" + token, "")
    if not raw:
        raise HTTPException(400, "重置令牌无效或已被使用")
    try:
        data = json.loads(raw)
    except Exception:
        data = None
    if not data or data.get("exp", 0) < time.time():
        raise HTTPException(400, "重置令牌已过期，请重新发起找回")
    db.set_config("pwreset_" + token, "")   # 一次性使用
    db.ex("UPDATE users SET password_hash=? WHERE id=?", (auth.hash_password(password), data["uid"]))
    u2 = db.q("SELECT username FROM users WHERE id=?", (data["uid"],), one=True)
    db.log_audit({"id": data["uid"], "username": u2["username"] if u2 else ""},
                 "password_reset", "user", data["uid"], "找回并重置密码")
    return {"ok": True, "message": "密码已重置，请用新密码登录"}


def _pub_user(u):
    return auth.user_public(u)


@app.post("/api/login")
def login(username: str = Form(...), password: str = Form(...)):
    u = db.q("SELECT * FROM users WHERE username=?", (username,), one=True)
    if not u or not auth.verify_password(password, u["password_hash"]):
        raise HTTPException(401, "用户名或密码错误")
    if not u["enabled"]:
        raise HTTPException(403, "账号已禁用")
    # 记录最后登录时间（后台用户管理列表显示 + 可排序）。
    # 单独存一列而不是从 audit_logs 现算：审计日志只留 30 天，现算分不清
    # 「一个月没登录」和「从没登录」。注册接口的自动登录路径单独写（见 register）。
    db.ex("UPDATE users SET last_login=? WHERE id=?", (db.now(), u["id"]))
    db.log_audit(u, "login", "user", u["id"], "登录")
    return {"token": auth.create_token(u), "user": _pub_user(u)}


@app.get("/api/me")
def me(user=Depends(get_current_user)):
    return _pub_user(user)


@app.put("/api/me")
def update_me(name: str = Form(None), email: str = Form(None), phone: str = Form(None),
              user=Depends(get_current_user)):
    """更新个人资料（昵称/邮箱/手机号；邮箱与手机号用于找回密码时的身份核验）"""
    sets, args = [], []
    if name is not None:
        name = name.strip()
        if not name:
            raise HTTPException(400, "昵称不能为空")
        # 昵称不可重复；未改动自己的昵称时跳过校验（兼容历史同名数据）
        if name != (user["name"] or "") and db.nickname_taken(name, user["id"]):
            raise HTTPException(400, "该昵称已被使用，请换一个")
        sets.append("name=?"); args.append(name)
    if email is not None:
        if not re.match(r"^[\w.+-]+@[\w-]+(\.[\w-]+)+$", email.strip()):
            raise HTTPException(400, "邮箱格式不正确")
        sets.append("email=?"); args.append(email.strip())
    if phone is not None:
        if not re.match(r"^1[3-9]\d{9}$", phone.strip()):
            raise HTTPException(400, "手机号格式不正确")
        sets.append("phone=?"); args.append(phone.strip())
    if sets:
        args.append(user["id"])
        db.ex(f"UPDATE users SET {','.join(sets)} WHERE id=?", args)
    return _pub_user(db.q("SELECT * FROM users WHERE id=?", (user["id"],), one=True))


@app.put("/api/me/password")
def change_password(old: str = Form(...), new: str = Form(...), user=Depends(get_current_user)):
    if not auth.verify_password(old, user["password_hash"]):
        raise HTTPException(400, "原密码错误")
    if len(new) < 4:
        raise HTTPException(400, "新密码至少4位")
    db.ex("UPDATE users SET password_hash=? WHERE id=?", (auth.hash_password(new), user["id"]))
    db.log_audit(user, "password_change", "user", user["id"], "修改密码")
    return {"ok": True}


# ---------- 每日签到（树叶） ----------
# 树叶消耗：无对应权限的分组，可用树叶兑换该功能
LEAF_COST_CONVERT = 2     # 转换一本书消耗树叶数
LEAF_COST_DOWNLOAD = 1    # 下载一本书消耗树叶数


def _leaf_balance(user_id):
    r = db.q("SELECT balance FROM user_leaves WHERE user_id=?", (user_id,), one=True)
    return r["balance"] if r else 0


def _leaf_spent(user_id, book_id, kind):
    """该用户是否**当前仍然**为这本书的某类操作付过树叶。

    ★ listen 有有效期：只在 `db.LISTEN_VALID_DAYS`（30）天内算数，过期返回 False，
      于是用户再听会重新走一遍「免费额度 → 扣树叶」的放行顺序 —— 这就是业主要的
      「树叶买的听书权限过期后需重新购买」。
      convert / download 没这个要求，维持「一次付费永久有效」，不在这次改动范围内。
    """
    if kind == "listen":
        return bool(db.q(
            "SELECT 1 FROM leaf_spend WHERE user_id=? AND book_id=? AND kind=? AND created_at>=?",
            (user_id, book_id, kind, db.listen_cutoff()), one=True))
    return bool(db.q("SELECT 1 FROM leaf_spend WHERE user_id=? AND book_id=? AND kind=?",
                     (user_id, book_id, kind), one=True))


def _spend_leaves(user, book_id, kind, cost):
    """用树叶兑换一次操作：有效期内同一本书同一类型只扣一次；
    余额不足抛 403。返回实际扣除的树叶数（0=本次未扣，如重复操作）。

    ★ 必须用 UPSERT 而不是裸 INSERT：`leaf_spend` 的主键是
      (user_id, book_id, kind)，听书权限 30 天过期后再买会**撞主键**。
      用 DO UPDATE 把 created_at 刷成现在（重新计时），并把 leaves 累加，
      这样既完成「重新购买」，又保留了历史总消耗。
      （convert/download 因为永久有效，永远不会走到 UPDATE 分支。）
    """
    if user["role"] == "admin":
        return 0
    if _leaf_spent(user["id"], book_id, kind):
        return 0
    bal = _leaf_balance(user["id"])
    if bal < cost:
        raise HTTPException(403, f"树叶不足：本次需 {cost} 片，当前 {bal} 片。每日签到可获得树叶")
    db.ex("""INSERT INTO leaf_spend (user_id, book_id, kind, leaves, created_at)
             VALUES (?,?,?,?,?)
             ON CONFLICT(user_id, book_id, kind)
             DO UPDATE SET leaves = leaf_spend.leaves + excluded.leaves,
                           created_at = excluded.created_at""",
          (user["id"], book_id, kind, cost, db.now()))
    db.ex("UPDATE user_leaves SET balance=balance-?, updated_at=? WHERE user_id=?",
          (cost, db.now(), user["id"]))
    return cost


def _signin_status(user):
    """返回签到状态（连续天数、今日是否已签、树叶余额等）"""
    today = db.today()
    log = db.q("SELECT * FROM signin_log WHERE user_id=? ORDER BY signin_date DESC LIMIT 1",
               (user["id"],), one=True)
    signed_today = bool(log and log["signin_date"] == today)
    streak = 0
    if log and (log["signin_date"] == today or log["signin_date"] == db.yesterday()):
        streak = log["streak"]
    return {
        "signed_today": signed_today,
        "streak": streak,           # 连续天数（今日已签=含今天；未签=截至昨天）
        "balance": _leaf_balance(user["id"]),
        "bonus_every": 7,           # 每连续 7 天
        "bonus_amount": 7,          # 额外奖励树叶数
    }


@app.get("/api/signin/status")
def signin_status(user=Depends(get_current_user)):
    return _signin_status(user)


@app.post("/api/signin")
def signin(user=Depends(get_current_user)):
    today = db.today()
    if db.q("SELECT 1 FROM signin_log WHERE user_id=? AND signin_date=?",
            (user["id"], today), one=True):
        raise HTTPException(400, "今天已经签到过了")
    log = db.q("SELECT * FROM signin_log WHERE user_id=? ORDER BY signin_date DESC LIMIT 1",
               (user["id"],), one=True)
    streak = 1
    if log and log["signin_date"] == db.yesterday():
        streak = log["streak"] + 1
    bonus = 7 if streak % 7 == 0 else 0
    leaves = 1 + bonus
    db.ex("INSERT INTO signin_log (user_id, signin_date, leaves, bonus, streak, created_at) "
          "VALUES (?,?,?,?,?,?)",
          (user["id"], today, leaves, bonus, streak, db.now()))
    db.ex("INSERT INTO user_leaves (user_id, balance, updated_at) VALUES (?,?,?) "
          "ON CONFLICT(user_id) DO UPDATE SET balance=balance+excluded.balance, updated_at=excluded.updated_at",
          (user["id"], leaves, db.now()))
    db.log_audit(user, "signin", "user", user["id"],
                 f"每日签到 +{leaves} 树叶（连续 {streak} 天）")
    return {"ok": True, "leaves": 1, "bonus": bonus, "streak": streak,
            "balance": _leaf_balance(user["id"])}


# ---------- 分类 ----------
@app.get("/api/categories")
def categories(user=Depends(auth.get_optional_user)):
    vw, vargs = auth.visible_where(user, "b")
    cond = (" AND " + vw) if vw else ""
    # upload 分类是用户上传的私人书，不属于公共书库，分类列表不展示
    rows = db.q(f"SELECT category, COUNT(*) n, SUM(size) sz FROM books b WHERE 1=1{cond} AND b.category != 'upload' GROUP BY category ORDER BY category", vargs)
    return [{"name": r["category"], "count": r["n"], "size": r["sz"]} for r in rows]


@app.get("/api/cat-folders")
def cat_folders(user=Depends(get_current_user)):
    """返回全部分类目录（供上传/编辑选择目标分类）"""
    out = []
    for letter, folder in _classify.CAT_FOLDERS.items():
        label = folder.replace(f"{letter}_", "") if folder.startswith(f"{letter}_") else folder
        out.append({"letter": letter, "folder": folder, "label": label})
    return out


# ---------- 书籍 ----------
@app.get("/api/books")
def list_books(q: str = "", category: str = "", author: str = "", publisher: str = "",
               isbn: str = "", series: str = "", page: int = 1, size: int = 30,
               sort: str = "title", order: str = "asc", user=Depends(auth.get_optional_user)):
    page = max(1, page)
    size = min(100, max(1, size))
    where, args = [], []
    if q:
        where.append("(title LIKE ? OR author LIKE ? OR publisher LIKE ? OR isbn LIKE ?)")
        like = f"%{q}%"
        args += [like, like, like, like]
    if category:
        where.append("category=?")
        args.append(category)
    if author:
        where.append("author=?")
        args.append(author)
    if publisher:
        where.append("publisher LIKE ?")
        args.append(f"%{publisher}%")
    if isbn:
        where.append("isbn LIKE ?")
        args.append(f"%{isbn}%")
    if series:
        where.append("series LIKE ?")
        args.append(f"%{series}%")
    vw, vargs = auth.visible_where(user)
    if vw:
        where.append(vw)
        args += vargs
    wsql = (" WHERE " + " AND ".join(where)) if where else ""
    orderby = {"title": "title", "author": "author", "size": "size", "id": "id"}.get(sort, "title")
    orderby += " ASC" if order == "asc" else " DESC"
    total = db.q(f"SELECT COUNT(*) n FROM books b{wsql}", args, one=True)["n"]
    rows = db.q(f"SELECT b.* FROM books b{wsql} ORDER BY {orderby} LIMIT ? OFFSET ?",
                args + [size, (page - 1) * size])
    return {"total": total, "page": page, "size": size,
            "items": [_book_json(r) for r in rows]}


@app.get("/api/authors")
def authors(user=Depends(auth.get_optional_user)):
    vw, vargs = auth.visible_where(user, "b")
    cond = (" AND " + vw) if vw else ""
    rows = db.q(f"SELECT author, COUNT(*) n FROM books b WHERE author IS NOT NULL AND author != ''{cond} GROUP BY author ORDER BY n DESC", vargs)
    return [{"name": r["author"], "count": r["n"]} for r in rows]


@app.get("/api/me/recent")
def me_recent(user=Depends(get_current_user)):
    """最近阅读：按阅读进度更新时间排序的书籍列表"""
    vw, vargs = auth.visible_where(user, "b")
    extra = (" AND " + vw) if vw else ""
    rows = db.q(f"""SELECT b.*, p.position, p.percent, p.updated_at AS pat
                   FROM progress p JOIN books b ON b.id = p.book_id
                   WHERE p.user_id=?{extra} ORDER BY p.updated_at DESC LIMIT 20""",
                [user["id"]] + vargs)
    return {"items": [dict(_book_json(r), percent=r["percent"] or 0, position=r["position"], pat=r["pat"]) for r in rows]}


def _audio_of_book(book_id, user):
    """这本书有没有「这个用户能听」的有声版？返回 (lib_id, 章数)；没有就是 (0, 0)。

    ★ 首页「热度推荐」（决定卡片点开进哪）和图书详情页（决定显不显示「有声阅读」按钮）
      都要用它，所以抽成一个函数 —— 两处口径**必须一致**，
      否则会出现「首页点得进有声、详情页却没有入口」这种自相矛盾的状态。

    权限口径直接复用有声列表页的 `ablib_api.access_info`，不自己另判一套。
    访客一律拿不到（§14.74），所以游客的详情页不会出现这个按钮、首页也不会指向有声。
    有声模块没加载、或查库出任何问题都只是返回 (0, 0) —— **绝不能连累主流程**。
    """
    ab = globals().get("_ablib_api")
    if ab is None or not book_id:
        return 0, 0
    try:
        lib = db.q("""SELECT * FROM ab_lib
                      WHERE book_id=? AND COALESCE(hidden, 0)=0
                      ORDER BY id DESC LIMIT 1""", (int(book_id),), one=True)
        if lib and ab.access_info(user, lib)["ok"]:
            return int(lib["id"]), int(lib["total_chapters"] or 0)
    except Exception:
        logging.getLogger("bookmgr").warning("查有声版失败 book=%s", book_id, exc_info=True)
    return 0, 0


@app.get("/api/home/hot")
def home_hot(user=Depends(get_current_user)):
    """首页「热度推荐」：后台标记的「访客热度推荐」书籍，登录后复用同一批运营位。

    这批书原本只在**未登录**时作为试读样例出现在首页（游客可见范围就是
    guest_featured=1 的书），登录用户反而看不到 —— 运营位白设了。
    所以登录后单开一个板块把它们再展示一次（首页最多 6 本）。

    可见性仍按权限走：这些书都是公共书（owner_id 为空），没有「公共书库」权限
    的分组本来就打不开，给他们推只会点出 403 —— 那就干脆不给，板块自然隐藏。

    ★ 带 `audio_id`：这本书有**能听**的有声版时，前端卡片按有声书呈现、点开进有声详情。
      不加这个字段的话，从「有声电子书」页面加进来的推荐在首页会变成一本普通电子书 ——
      管理员明明加的是有声书，点开却是文字版，等于推荐错了东西（§14.81）。
    """
    if user["role"] != "admin" and not auth.can(user, "public_library"):
        return {"items": []}
    rows = db.q("""SELECT * FROM books
                   WHERE COALESCE(guest_featured, 0) = 1 AND COALESCE(hidden, 0) = 0
                   ORDER BY COALESCE(updated_at, '') DESC, id DESC LIMIT 6""")
    out = []
    for r in rows:
        d = _book_json(r)
        lib_id, n_ch = _audio_of_book(r["id"], user)
        if lib_id:
            d["audio_id"] = lib_id
            d["audio_chapters"] = n_ch
        out.append(d)
    return {"items": out}


@app.get("/api/me/reading-history")
def me_reading_history(user=Depends(get_current_user)):
    """我的阅读：最近 100 本阅读记录，按时间从晚到早排列"""
    vw, vargs = auth.visible_where(user, "b")
    extra = (" AND " + vw) if vw else ""
    rows = db.q(f"""SELECT b.*, p.percent AS percent, p.updated_at AS pat
                    FROM progress p JOIN books b ON b.id = p.book_id
                    WHERE p.user_id=?{extra}
                    ORDER BY p.updated_at DESC LIMIT 100""",
                [user["id"]] + vargs)
    return {"items": [dict(_book_json(r), percent=r["percent"] or 0, pat=r["pat"]) for r in rows]}


@app.post("/api/reading/heartbeat")
def reading_heartbeat(request: Request, body=Depends(json_body), user=Depends(get_current_user)):
    """阅读时长心跳：阅读器定时上报有效阅读秒数（单次 1~60 秒，累计到 reading_time）

    §14.112 起带上 book_id / kind：除了原来的累计秒数，还按「用户 × 天 × 书」沉淀
    明细（周/月汇总、书籍阅读人数/次数由后台汇总任务算），只存不展示。
    旧客户端不带 book_id 也能用，只是拿不到书籍维度。
    """
    sec = int(body.get("seconds", 30) or 30)
    sec = max(1, min(60, sec))
    db.ex("INSERT INTO reading_time (user_id, total_seconds, updated_at) VALUES (?, ?, ?) "
          "ON CONFLICT(user_id) DO UPDATE SET total_seconds = total_seconds + excluded.total_seconds, updated_at = excluded.updated_at",
          (user["id"], sec, db.now()))
    stats.record_reading(user["id"], sec)
    try:
        bid = int(body.get("book_id") or 0)
        kind = str(body.get("kind") or "")[:20]
        reading_stats.record(user["id"], bid, sec, kind,
                             reading_stats.book_title(bid) if bid else "")
    except Exception:
        pass                                   # 统计失败绝不影响心跳返回
    return {"ok": True, "seconds": sec}


@app.get("/api/books/{book_id}")
def get_book(book_id: int, user=Depends(auth.get_optional_user)):
    _book_row = _accessible_book_or_404(book_id, user)
    b = _book_json(_book_row, with_intro=True)
    p = db.q("SELECT position, percent FROM progress WHERE user_id=? AND book_id=?",
             (user["id"], book_id), one=True)
    b["progress"] = {"percent": p["percent"] or 0, "position": p["position"]} if p else None
    b["in_shelf"] = bool(db.q("SELECT id FROM shelves WHERE user_id=? AND book_id=?",
                              (user["id"], book_id), one=True))
    # 该格式是否允许申请共享（详情页据此决定「共享本书」按钮是否可用）
    b["share_allowed"] = share_format_ok(_book_row)
    # ★ 有声版：详情页要在「开始阅读」右边放一个「有声阅读」按钮，
    #   点了直接进这本有声书的章节目录（#/audio/<audio_id>）。
    #   ★ 注意它和下面那个「听书」**不是一回事**：听书是现场合成（TTS，要树叶），
    #     有声阅读是已经做好的成品音频，两套权限、两套进度，互不相干。
    _aid, _anch = _audio_of_book(book_id, user)
    if _aid:
        b["audio_id"] = _aid
        b["audio_chapters"] = _anch
    # 听书总开关（后台「听书设置 → 启用听书」）+ 听书价格。
    # ★ 开关必须下发给前端：关掉听书时详情页要**整个不给入口** ——
    #   否则按钮照样在，点进去只会到听书页再报「听书功能未开启」，属于把人骗进去。
    #   价格是详情页「听书（50🌿）」按钮上要显示的树叶数，不能写死。
    _tts_cfg = tts.settings()
    b["listen_enabled"] = _tts_cfg["enabled"]
    b["listen_cost"] = _tts_cfg["cost"]
    # 免费听书额度（近 N 本 / N 天）。详情页按钮本身不再显示它，
    # 但听书页要用它给出「已用完、本次开始扣树叶」这类准确提示。
    b["listen_quota"] = _listen_quota_info(user)
    # 是否为这本书花过树叶买听书权限。listen 有 30 天有效期，
    # 过期后这里会变回 False（_leaf_spent 内部判断），用户再听要重新走一遍放行顺序。
    paid_listen = _leaf_spent(user["id"], book_id, "listen")
    if auth.can(user, "listen") or paid_listen:
        b["listen_free"] = True                     # 本来就免费，与额度无关
    elif _listen_quota_ok(user, book_id):
        b["listen_free"] = True
        b["listen_by_quota"] = True                 # 这次免费是额度给的
    else:
        b["listen_free"] = False

    # ---- 「继续听书」按钮的两个判据（详情页阅读进度板块用）----    # 之一：真的听过这本书（有听书进度）
    # ★ 不能只看 listen_progress 有没有行：/listen/line（手动选线路）也会建行，
    #   那种情况用户一个字都还没听过。所以要求位置字段至少有一个非零。
    lp = db.q("SELECT seg_idx, offset, percent, updated_at FROM listen_progress "
              "WHERE user_id=? AND book_id=?", (user["id"], book_id), one=True)
    b["has_listen_progress"] = bool(
        lp and ((lp["percent"] or 0) > 0 or (lp["seg_idx"] or 0) > 0 or (lp["offset"] or 0) > 0))
    # 之二：花树叶买过听书权限（额度占下的名额不算「兑换」，那是每日免费额度）
    b["listen_paid"] = paid_listen
    # 管理员：若有待审的共享申请，详情页据此显示「通过申请 / 驳回申请」
    if user["role"] == "admin":
        r = db.q("""SELECT r.id, r.requester_id, r.created_at, u.name AS req_real, u.username AS req_username
                    FROM share_requests r LEFT JOIN users u ON u.id=r.requester_id
                    WHERE r.book_id=? AND r.status='pending' ORDER BY r.id DESC LIMIT 1""",
                 (book_id,), one=True)
        if r:
            b["share_request"] = {"id": r["id"], "requester_id": r["requester_id"],
                                  "requester_name": r["req_real"] or r["req_username"] or "会员",
                                  "created_at": r["created_at"]}
    return b


@app.put("/api/books/{book_id}")
def update_book(book_id: int, title: str = Form(None), author: str = Form(None),
                category: str = Form(None), intro: str = Form(None),
                publisher: str = Form(None), isbn: str = Form(None),
                pages: int = Form(None), series: str = Form(None),
                user=Depends(get_current_user)):
    b = _accessible_book_or_404(book_id, user)
    if not auth.can(user, "edit"):
        raise HTTPException(403, "无权限修改此书，请联系管理员开通编辑权限")
    new_title = title if title is not None else b["title"]
    new_author = author if author is not None else b["author"]
    new_cat = category if category is not None else b["category"]
    ext = b["ext"] or ""
    new_name = (new_title + "_" + new_author + ext) if new_author else (new_title + ext)
    new_path = new_cat + "/" + new_name
    if new_path != b["path"]:
        if not ftp_service.rename(b["path"], new_path):
            raise HTTPException(500, "FTP 重命名失败")
        db.ex("UPDATE books SET path=? WHERE id=?", (new_path, book_id))
    db.ex("UPDATE books SET title=?, author=?, category=?, publisher=?, isbn=?, pages=?, series=?, updated_at=? WHERE id=?",
          (new_title, new_author, new_cat,
           publisher if publisher is not None else b["publisher"],
           isbn if isbn is not None else b["isbn"],
           pages if pages is not None else (b["pages"] or 0),
           series if series is not None else b["series"],
           db.now(), book_id))
    if intro is not None:
        db.ex("UPDATE books SET intro=?, intro_done=1 WHERE id=?", (intro, book_id))
    db.log_audit(user, "book_edit", "book", book_id, f"编辑元数据 {new_title}")
    return _book_json(_book_or_404(book_id))


@app.delete("/api/books/{book_id}")
def delete_book(book_id: int, user=Depends(get_current_user)):
    b = _accessible_book_or_404(book_id, user)
    if not auth.can(user, "delete"):
        raise HTTPException(403, "无权限删除书籍，请联系管理员开通删除权限")
    if not ftp_service.delete(b["path"]):
        raise HTTPException(500, "FTP 删除失败")
    for t in ("shelves", "progress", "shares", "notes", "book_reports", "share_requests"):
        db.ex(f"DELETE FROM {t} WHERE book_id=?", (book_id,))
    db.ex("DELETE FROM books WHERE id=?", (book_id,))
    # 报告书（§14.111）：连投放区源文件一起删 + 墓碑防 cron 重新导入——
    # 只认 upload/user_*/report/ 前缀，绝不碰普通上传书或系统书
    try:
        p = b["path"] or ""
        if p.startswith(config.USER_UPLOAD_DIR + "/") and "/report/" in p:
            report_sync.forget_book(p)
    except Exception as _e:
        logging.getLogger("bookmgr").warning("报告源文件清理失败 book=%s：%s",
                                             book_id, _e, exc_info=True)
    db.log_audit(user, "book_delete", "book", book_id, f"删除书籍《{b['title']}》")
    return {"ok": True}


@app.post("/api/books/ftp-import")
def ftp_import(request: Request, path: str = Form(...), user=Depends(get_current_user)):
    if not auth.can(user, "private_shelf"):
        raise HTTPException(403, "无权限导入私人书籍，请联系管理员开通「私人书架」权限")
    rel = path
    if rel.startswith(config.FTP_BASE):
        rel = rel[len(config.FTP_BASE):].lstrip("/")
    rel = rel.lstrip("/")
    name = rel.rsplit("/", 1)[-1]
    ext = ("." + name.rsplit(".", 1)[-1].lower()) if "." in name else ""
    if ext not in config.BOOK_EXTS:
        raise HTTPException(400, "不支持的格式")
    import sys
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "ebook_task"))
    import classify
    cat = classify.classify(name, name)
    folder = classify.CAT_FOLDERS.get(cat, "00_待分类")
    fn, title, author = classify.final_name(name)
    dest = f"{config.USER_UPLOAD_DIR}/user_{user['id']}/{fn}"
    size = ftp_service.stat(rel)
    if not size:
        raise HTTPException(404, "FTP 源文件不存在")
    if db.q("SELECT id FROM books WHERE path=?", (dest,), one=True):
        raise HTTPException(400, "该书已在书库中")
    tmp = os.path.join(config.CACHE_DIR, "imp_" + str(time.time()) + ext)
    ftp_service.download_to(rel, tmp)
    ftp_service.upload_file(tmp, dest)
    os.remove(tmp)
    cls = classify.CLASSES.get(cat, {"ddc": "-"})
    bid = db.ex("INSERT INTO books (path,title,author,category,clc,ddc,ext,size,owner_id,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (dest, title, author, folder, cat, cls.get("ddc", "-"), ext, size, user["id"], db.now(), db.now()))
    db.log_audit(user, "ftp_import", "book", bid, f"从 FTP 导入《{title}》到私人书架")
    db.log_file(user, "upload", name, size=size, source="ftp", book_id=bid,
                book_title=title, ip=_client_ip(request), ext=ext)
    return _book_json(_book_or_404(bid))


@app.post("/api/upload")
def upload(request: Request, file: UploadFile = File(...), collection_id: int = Form(None), user=Depends(get_current_user)):
    if not auth.can(user, "private_shelf"):
        raise HTTPException(403, "无权限上传私人书籍，请联系管理员开通「私人书架」权限")
    # 书架分类：必须是当前用户自己的书架分类
    if collection_id is not None and not db.q("SELECT id FROM shelf_collections WHERE id=? AND user_id=?", (collection_id, user["id"]), one=True):
        raise HTTPException(404, "书架分类不存在")
    n = db.q("SELECT COUNT(*) n FROM shelves WHERE user_id=?", (user["id"],), one=True)["n"]
    if n >= user["quota"]:
        raise HTTPException(400, f"个人书库已达上限（{user['quota']} 本）")
    name = file.filename
    ext = ("." + name.rsplit(".", 1)[-1].lower()) if "." in name else ""
    if ext not in config.BOOK_EXTS:
        raise HTTPException(400, "不支持的格式")
    # ★ 分组可配的单本上传体积上限（0=不限）。
    #   必须**边写边判**：等文件落完盘再检查等于没限制 —— 一个 2GB 的文件
    #   照样会把 UPLOAD_DIR 写满。所以超限时立刻中断并删掉半截文件。
    max_mb = int(auth.limits_of(user).get("upload_max_mb") or 0)
    limit = max_mb * 1024 * 1024 if max_mb > 0 else 0
    if limit:
        # 先看 Content-Length 快速拒绝（省掉把整个请求体读进来的开销）。
        # 留 1MB 余量给 multipart 的边界和表单字段，避免正常文件被误杀。
        try:
            cl = int(request.headers.get("content-length") or 0)
        except (TypeError, ValueError):
            cl = 0
        if cl and cl > limit + (1 << 20):
            raise HTTPException(413, f"文件超过所在分组的上限（{max_mb} MB），请压缩后再上传")
    tmp = os.path.join(config.UPLOAD_DIR, f"up_{user['id']}_{int(time.time())}_{uuid.uuid4().hex[:6]}{ext}")
    size = 0
    try:
        with open(tmp, "wb") as fh:
            while True:
                chunk = file.file.read(1 << 20)
                if not chunk:
                    break
                size += len(chunk)
                if limit and size > limit:
                    raise HTTPException(
                        413, f"文件超过所在分组的上限（{max_mb} MB），请压缩后再上传")
                fh.write(chunk)
    except BaseException:
        # 任何失败（含上面的 413）都要把半截文件清掉，别在 UPLOAD_DIR 里留垃圾
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise
    fn, title, author = _classify.final_name(name)
    # 会员上传统一存放于 WebDAV 的 upload/{user_id}/ 目录，仅上传者可见
    dest = f"{config.USER_UPLOAD_DIR}/user_{user['id']}/{fn}"
    if db.q("SELECT id FROM books WHERE path=?", (dest,), one=True):
        dest = f"{config.USER_UPLOAD_DIR}/user_{user['id']}/" + os.path.splitext(fn)[0] + f"({user['id']}){ext}"
    ftp_service.upload_file(tmp, dest)
    os.remove(tmp)
    # 私人上传不按中图法分类：category 记为 upload，owner_id 标识归属
    bid = db.ex("INSERT INTO books (path,title,author,category,clc,ddc,ext,size,owner_id,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (dest, title, author, "upload", "-", "-", ext, size, user["id"], db.now(), db.now()))
    # 上传后自动加入上传者的书架（可指定书架分类）
    db.ex("INSERT INTO shelves (user_id,book_id,collection_id,added_at) VALUES (?,?,?,?)",
          (user["id"], bid, collection_id, db.now()))
    db.log_audit(user, "upload", "book", bid, f"上传书籍《{title}》")
    db.log_file(user, "upload", name, size=size, source="web", book_id=bid,
                book_title=title, ip=_client_ip(request), ext=ext)
    return _book_json(_book_or_404(bid))


# ---------- 封面/简介 ----------
@app.get("/api/books/{book_id}/cover")
def get_cover(book_id: int, request: Request):
    user = _user_from_media(request)
    b = _accessible_book_or_404(book_id, user)
    fname = b["cover"] or covers.extract_cover(b)
    if not fname:
        raise HTTPException(404, "无封面")
    path = covers.ensure_cover_local(fname)
    if not path:
        raise HTTPException(404, "封面文件缺失")
    return FileResponse(path, media_type="image/jpeg")


@app.post("/api/books/{book_id}/cover")
def upload_cover(request: Request, book_id: int, file: UploadFile = File(...),
                 user=Depends(get_current_user)):
    b = _accessible_book_or_404(book_id, user)
    if not auth.can(user, "cover"):
        raise HTTPException(403, "无权限上传封面，请联系管理员开通该权限")
    data = file.file.read()
    fname = covers._save_cover_data(book_id, data)
    if not fname:
        raise HTTPException(400, "封面图片无效")
    db.ex("UPDATE books SET cover=?, updated_at=? WHERE id=?", (fname, db.now(), book_id))
    db.log_audit(user, "cover_upload", "book", book_id, f"上传封面《{b['title']}》")
    # ext 交给 log_file 从文件名校验出来：fname 是保存后的名字（如 123.jpg），
    # 直接当 ext 传会写成「123.jpg」这种假扩展名。
    db.log_file(user, "upload", file.filename or fname, size=len(data), source="cover",
                book_id=book_id, book_title=b["title"], ip=_client_ip(request))
    return {"ok": True, "cover_url": f"/api/books/{book_id}/cover"}


@app.post("/api/books/{book_id}/cover/online")
def online_cover(book_id: int, user=Depends(get_current_user)):
    """在线刮削封面（豆瓣 / 必应 / Google Books / Open Library / 电子书内图片），并尝试抓取评分"""
    if not auth.can(user, "cover"):
        raise HTTPException(403, "无权限上传封面")
    b = _accessible_book_or_404(book_id, user)
    data = covers.download_online_cover(b["title"], b["author"], b)
    if not data:
        raise HTTPException(404, "未找到在线封面")
    fname = covers._save_cover_data(book_id, data)
    if not fname:
        raise HTTPException(400, "封面保存失败")
    # 尝试抓取评分（豆瓣）
    rating = covers.douban_rating(b["title"], b["author"])
    if rating is not None:
        db.ex("UPDATE books SET cover=?, rating=?, updated_at=? WHERE id=?", (fname, rating, db.now(), book_id))
    else:
        db.ex("UPDATE books SET cover=?, updated_at=? WHERE id=?", (fname, db.now(), book_id))
    db.log_audit(user, "cover_online", "book", book_id, f"在线刮削封面《{b['title']}》")
    return {"ok": True, "cover_url": f"/api/books/{book_id}/cover", "rating": rating}


@app.post("/api/books/{book_id}/enrich")
def enrich_book(book_id: int, user=Depends(get_current_user)):
    """补录元数据（从文件读取真实书名/作者）并自动重命名 FTP 文件"""
    if not auth.can(user, "edit"):
        raise HTTPException(403, "无权限")
    b = _accessible_book_or_404(book_id, user)
    title, author = covers.enrich_metadata(b)
    if not title:
        raise HTTPException(404, "未能从文件提取到书名")
    title = title or b["title"]
    author = author or ""
    new_name = covers.normalize_filename(title, author, b["ext"] or "")
    new_path = _ftp_parent(b) + "/" + new_name
    if db.q("SELECT id FROM books WHERE path=? AND id!=?", (new_path, book_id), one=True):
        new_name = covers.normalize_filename(title, author, "") + f"({book_id})" + (b["ext"] or "")
        new_path = _ftp_parent(b) + "/" + new_name
    if new_path != b["path"]:
        if not ftp_service.rename(b["path"], new_path):
            raise HTTPException(500, "FTP 重命名失败")
        db.ex("UPDATE books SET path=? WHERE id=?", (new_path, book_id))
    db.ex("UPDATE books SET title=?, author=?, updated_at=? WHERE id=?", (title, author, db.now(), book_id))
    db.log_audit(user, "book_enrich", "book", book_id, f"补录元数据《{title}》")
    return _book_json(_book_or_404(book_id))


@app.get("/api/books/{book_id}/intro")
def get_intro(book_id: int, user=Depends(auth.get_optional_user)):
    return {"intro": _ensure_intro(_accessible_book_or_404(book_id, user))}


# ---------- 阅读 ----------
@app.get("/api/books/{book_id}/read")
def read_meta(book_id: int, user=Depends(auth.get_optional_user)):
    b = _accessible_book_or_404(book_id, user)
    return {"kind": reader.kind(b), "title": b["title"], "author": b["author"], "ext": b["ext"]}


@app.get("/api/books/{book_id}/search")
def search_book(book_id: int, q: str = Query(""), user=Depends(auth.get_optional_user)):
    """书籍内容搜索"""
    if not q or not q.strip():
        return {"matches": []}
    b = _accessible_book_or_404(book_id, user)
    return {"matches": reader.search_book(b, q.strip())}


@app.get("/api/books/{book_id}/toc")
def toc(book_id: int, user=Depends(auth.get_optional_user)):
    b = _accessible_book_or_404(book_id, user)
    k = reader.kind(b)
    if k in ("txt", "docx", "md"):
        return {"kind": "txt", "chapters": [{"idx": c["idx"], "title": c["title"]} for c in reader.chunks(b)]}
    if k in ("epub", "mobi"):
        return {"kind": "epub", "chapters": [{"idx": c["idx"], "href": c["href"], "fragment": c.get("fragment", ""), "title": c["title"], "front": bool(c.get("front")), "level": c.get("level", 0)} for c in reader.epub_toc(b)]}
    if k == "pdf":
        return {"kind": "pdf"}
    if k == "html":
        return {"kind": "html"}
    raise HTTPException(400, "该格式暂不支持在线阅读")


@app.get("/api/books/{book_id}/chapter")
def chapter(book_id: int, request: Request, href: str = Query(""), idx: int = Query(-1)):
    user = _user_from_media(request)
    b = _accessible_book_or_404(book_id, user)
    k = reader.kind(b)
    if k in ("epub", "mobi"):
        chapters = reader.epub_toc(b)
        fragment = ""
        if idx >= 0 and idx < len(chapters):
            href = chapters[idx]["href"]
            fragment = chapters[idx].get("fragment", "")
        if not href:
            raise HTTPException(400, "缺少章节")
        mt = (request.query_params.get("t") or "").strip()
        # 章节内图片/CSS 等资源的 base URL：用媒体凭证而非登录令牌
        base = f"/api/books/{book_id}/resource?t={quote(mt)}&p="
        html = reader.epub_chapter(b, href, base, fragment)
        return Response(html, media_type="text/html")
    raise HTTPException(400, "请用 txt 接口读取")


@app.get("/api/books/{book_id}/txt")
def txt_chunk(book_id: int, idx: int = Query(0), user=Depends(auth.get_optional_user)):
    b = _accessible_book_or_404(book_id, user)
    k = reader.kind(b)
    if k not in ("txt", "docx", "md"):
        raise HTTPException(400, "非 txt/docx/md 书籍")
    chunks = reader.chunks(b)
    if idx < 0 or idx >= len(chunks):
        raise HTTPException(404, "段落不存在")
    return {"idx": idx, "total": len(chunks), "title": chunks[idx]["title"],
            "text": chunks[idx]["text"], "html": k == "md"}


@app.get("/api/books/{book_id}/txt-batch")
def txt_batch(book_id: int, user=Depends(auth.get_optional_user)):
    """一次返回全部分段（供客户端计算总页数/进度）"""
    b = _accessible_book_or_404(book_id, user)
    k = reader.kind(b)
    if k not in ("txt", "docx", "md"):
        raise HTTPException(400, "非 txt/docx/md 书籍")
    chunks = reader.chunks(b)
    return {"chunks": [{"idx": c["idx"], "title": c["title"], "text": c["text"]} for c in chunks],
            "html": k == "md"}


@app.get("/api/books/{book_id}/resource")
def resource(book_id: int, request: Request, p: str = Query("")):
    user = _user_from_media(request)
    b = _accessible_book_or_404(book_id, user)
    data = reader.epub_resource(b, p)
    if data is None:
        raise HTTPException(404, "资源不存在")
    return Response(data, media_type=_mime(p))


@app.get("/api/books/{book_id}/file")
def book_file(book_id: int, request: Request):
    user = _user_from_media(request)
    b = _accessible_book_or_404(book_id, user)
    local = covers.ensure_local(b)
    return _file_response(request, local, os.path.basename(b["path"]))


# ---------- 进度/设置 ----------
def _log_activity_once(user, kind, book_id, request, detail="", title=None):
    """记一条阅读/听书活动（后台「阅读日志」「听书日志」的数据来源）。

    实际落盘由 activity 模块在后台线程写 WebDAV，这里只是把事件交给它，
    不会产生网络等待。

    阅读进度是滚动上报的、听书 start 在续播时也会再打一次，所以
    activity.record 内部会按「同一用户 + 同一本书 + 30 分钟」去重。

    刻意吞掉所有异常：这是旁路日志，绝不能因为写日志失败而让
    「存进度」「开始听书」这两个核心动作报错。
    """
    try:
        if not user or not user["id"]:
            return
        if title is None:
            row = db.q("SELECT title FROM books WHERE id=?", (book_id,), one=True)
            if not row:
                return
            title = row["title"]
        activity.record(user, kind, book_id, title, detail, _client_ip(request))
    except Exception:
        pass


@app.get("/api/books/{book_id}/progress")
def get_progress(book_id: int, user=Depends(auth.get_optional_user)):
    r = db.q("SELECT * FROM progress WHERE user_id=? AND book_id=?", (user["id"], book_id), one=True)
    return {"progress": json.loads(r["position"]) if r and r["position"] else None,
            "percent": r["percent"] if r else 0}


@app.put("/api/books/{book_id}/progress")
def save_progress(book_id: int, request: Request, body=Depends(json_body), user=Depends(auth.get_optional_user)):
    if user["id"] == 0:   # 游客：进度不落库
        return {"ok": True}
    position = body.get("position")
    percent = body.get("percent", 0)
    db.ex("INSERT INTO progress (user_id,book_id,position,percent,updated_at) VALUES (?,?,?,?,?) "
          "ON CONFLICT(user_id,book_id) DO UPDATE SET position=excluded.position, percent=excluded.percent, updated_at=excluded.updated_at",
          (user["id"], book_id, json.dumps(position, ensure_ascii=False), percent, db.now()))
    # 阅读日志：这里就是「开始读某本书」的入口（阅读器滚动/翻页即上报）
    _log_activity_once(user, "read", book_id, request, "开始阅读")
    return {"ok": True}


@app.delete("/api/me/progress/{book_id}")
def delete_progress(book_id: int, user=Depends(get_current_user)):
    """移出最近阅读：删除该书的阅读进度记录"""
    db.ex("DELETE FROM progress WHERE user_id=? AND book_id=?", (user["id"], book_id))
    return {"ok": True}


# ---------- 听书 ----------
# 客户端流程：
#   1. GET  /listen/info            看能否听、要花多少树叶、有哪些音色、听到哪了
#   2. POST /listen/start           确认开始（无 listen 权限则扣树叶，同一本书只扣一次）
#   3. GET  /listen/seg/{n}?t=      逐句取音频（缓存命中立即返回，未命中现场合成）
#   4. PUT  /listen/progress        存听书进度（独立表，不碰阅读进度）
LISTEN_KINDS = ("txt", "docx", "md", "epub", "mobi")


def _listen_book(book_id, user):
    """听书通用前置检查：可访问 + 开关打开 + 格式支持 + 能提取到文字"""
    b = _accessible_book_or_404(book_id, user)
    cfg = tts.settings()
    if not cfg["enabled"]:
        raise HTTPException(403, "听书功能未开启")
    if reader.kind(b) not in LISTEN_KINDS:
        raise HTTPException(400, "该格式暂不支持听书")
    segs = tts.segments(b)
    if not segs:
        raise HTTPException(400, "未能从这本书里提取到文字")
    return b, segs, cfg


def _listen_voice_of(user, cfg, book_id=None):
    """用户上次听「这本书」用的音色；没有就用后台默认。

    必须按 book_id 过滤：音色是按书独立的（客户端存在 bm_listen_voice_<书号>），
    服务端这份是给换设备/清缓存后用的。不按书过滤就会把最近听过的「别的书」
    的音色套到这本书上。
    """
    if book_id is None:
        r = db.q("SELECT voice FROM listen_progress WHERE user_id=? AND COALESCE(voice,'')<>'' "
                 "ORDER BY updated_at DESC LIMIT 1", (user["id"],), one=True)
    else:
        r = db.q("SELECT voice FROM listen_progress WHERE user_id=? AND book_id=? "
                 "AND COALESCE(voice,'')<>'' ORDER BY updated_at DESC LIMIT 1",
                 (user["id"], book_id), one=True)
    return (r["voice"] if r and r["voice"] else tts.default_voice(cfg))


def _voice_allowed(cfg, voice, user=None):
    """音色必须在此前 /health 返回的白名单里，避免客户端传任意音色。

    但「清单里没有」不等于「非法」：allowed_voices() 是各服务器 /voices 的并集，
    冷启动或某台刚重启时，那台会返回空清单、不贡献任何音色，于是像
    piper_huayan 这种只在某几台上的音色会被误判为非法，然后被静默换成
    default_voice(pool_49) —— 用户听到的就是「这一句突然换了个音色」。

    所以清单不完整时不下结论：放行，让 TTS 端自己返回 400，
    而不是在服务端偷偷把用户的音色换掉。
    """
    # wait=False：这是 /listen/seg 的热路径，音色清单只读缓存、绝不在这里发 HTTP
    # （TTS 主机合成期间会把 /voices 挂起 20 秒以上，见 tts.voices_of_server）。
    # 冷启动时并集可能为空，但下面那句「清单不完整就不下结论」会放行。
    if user is not None:
        # 有用户上下文时按「他真正能用的音色」判断：已停用、已删除、
        # 或落在无权使用的线路上的音色都算不可用。
        # 同样 wait=False：这里在 /listen/seg 上，绝不能同步去取 /voices。
        vs = _listen_voices_for(user, cfg, wait=False)
        if vs:
            return any(v["id"] == voice for v in vs)
        # 冷启动时清单还没热，什么都筛不出来 —— 这时不下结论，走下面的兜底放行，
        # 否则会把用户本来合法的音色误换掉（就是上面那段注释说的音色跳变）。
    if any(v["id"] == voice for v in tts.allowed_voices(cfg, wait=False)):
        return True
    return any(not tts.voices_of_server(s, cfg, wait=False) for s in tts.active_servers(cfg))


LISTEN_LEASE = 40          # 秒。心跳断这么久就认为该终端已停止（关页面/断网）


def _listen_lock_row(user_id):
    return db.q("SELECT * FROM listen_session WHERE user_id=?", (user_id,), one=True)


# ---------------------------------------------------------------- 听书锁实时推送
# 抢占要「立刻」让对方停下来，不能靠客户端轮询：
#   1) 网页切到后台时浏览器会把 setInterval 限流到一分钟一次，轮询根本来不及；
#   2) 客户端手上还缓冲着几句音频，等它自己发现就已经overlap好几秒了。
# 所以改成长连接推送（SSE），网页和 APP 都挂一条，锁一被抢马上收到通知。
_listen_watchers = {}          # user_id -> set(asyncio.Queue)
_MAIN_LOOP = None              # 主事件循环，供线程池里的合成线程安全投递事件
_line_pushed = {}              # (user_id, sid) -> 已推送过的线路名，去重防刷屏
_line_pushed_lock = threading.Lock()

# (user_id, sid) -> 释放时刻。用来挡住「会话复活」：
# 客户端退出播放页时，stop 和进度/心跳是好几个并发请求，顺序没法保证。
# stop 先把会话删了，后到的进度 PUT 走 _listen_touch 又 INSERT 回去 ——
# 用户一走账号反而被自己锁住，下次进来提示「已在另一台设备上听书」。
# 这里记下刚释放的 sid，在宽限期内拒绝用**同一个 sid** 重新建会话。
_listen_released = {}
_LISTEN_RELEASE_GRACE = 15      # 秒
_listen_released_lock = threading.Lock()


def _listen_push(user_id, payload):
    """从任意线程把一条事件投给该账号的长连接。

    ★ 必须走叫 call_soon_threadsafe：合成是在 Starlette 线程池里跑的
    （listen_seg 是普通 def），直接往 asyncio.Queue 里 put_nowait 属于
    跨线程操作事件循环，轻则丢事件、重则写坏内部状态。
    """
    qs = _listen_watchers.get(user_id)
    if not qs:
        return
    for q in list(qs):
        try:
            if _MAIN_LOOP is not None:
                _MAIN_LOOP.call_soon_threadsafe(q.put_nowait, payload)
            else:
                q.put_nowait(payload)
        except Exception:
            pass


def _listen_notify_kick(user_id, keep_sid, reason):
    """通知该账号下除 keep_sid 之外的所有终端：锁已经不在你手上了"""
    _listen_push(user_id, {"sid": keep_sid, "reason": reason})


def _listen_line_now(user_id, sid):
    """这台终端最近一次实际用的线路（给刚连上的长连接补快照用）。

    ★ 为什么需要它：APP 的原生播放和 WebView 是**两条独立的 /listen/watch 连接**，
    而推送按 (user_id, sid) 去重「只在变化时推」。如果 WebView 的长连接是在
    第一次推送之后才建好的，它就永远收不到那条事件（线路不变就一直不再推），
    表现就是「APP 上始终不显示当前线路」。所以连上时主动补一条快照。
    """
    if not sid:
        return None
    with _line_pushed_lock:
        c = _line_pushed.get((user_id, sid))
    return dict(c) if c else None


def _listen_notify_line(user_id, sid, idx, name):
    """把「第 idx 句实际由哪台服务器合成」推给正在听的终端。

    为什么不能像网页那样用响应头：APP 用的是原生后台播放，取音频的是 Java 的
    PlaybackService，WebView 根本看不到那个响应头。播放页要在进度右边显示
    「当前线路」，就只能由服务端主动推。只在**线路变化**时推，避免每句刷屏；
    去重表同时留着 name/idx，供新连上来的长连接补快照（见 _listen_line_now）。
    """
    if not sid or not name:
        return
    with _line_pushed_lock:
        cur = _line_pushed.get((user_id, sid))
        if cur and cur.get("name") == name:
            return
        _line_pushed[(user_id, sid)] = {"name": name, "idx": idx}
    _listen_push(user_id, {"type": "line", "sid": sid, "idx": idx, "name": name})


def _listen_touch(user, book_id, sid, request=None, take=False):
    """听书互斥：一个账号同一时间只允许一个终端在听。

    多终端同时听会成倍占用合成资源（每句都要现场合成），所以要挡住。
    每次取音频/存进度/心跳都刷新一次，超过 LISTEN_LEASE 秒没心跳即自动释放，
    这样关掉页面或断网不会把账号永久锁死。
    take=True 表示用户已确认「在这台设备上继续听」，抢占对方。
    """
    sid = (sid or "").strip()
    if not sid:
        raise HTTPException(400, "缺少会话标识")
    now = time.time()
    row = _listen_lock_row(user["id"])
    # 刚被 stop 释放掉的会话，不许被在途的进度/心跳请求复活（见 _listen_released）
    if not row:
        with _listen_released_lock:
            rel = _listen_released.get((user["id"], sid))
        if rel and (now - rel) < _LISTEN_RELEASE_GRACE:
            return False
    stolen = False
    if row and row["sid"] and row["sid"] != sid and (now - float(row["ts"] or 0)) < LISTEN_LEASE:
        if not take:
            ob = db.q("SELECT title FROM books WHERE id=?", (row["book_id"],), one=True)
            raise HTTPException(409, "该账号正在另一台设备上听《%s》。\n"
                                     "同一账号同一时间只能听一本书，请先在那边停止，"
                                     "或选择在这台设备上继续听。" % ((ob["title"] if ob else "未知书籍")))
        stolen = True
        _listen_notify_kick(
            user["id"], sid,
            "该账号已在另一台设备上继续收听，本机已停止播放。\n"
            "同一账号同一时间只能听一本书。")
    ua = ip = ""
    if request is not None:
        ua = (request.headers.get("user-agent") or "")[:120]
        ip = (request.client.host if request.client else "")
    db.ex("INSERT INTO listen_session (user_id,book_id,sid,ua,ip,started_at,ts) "
          "VALUES (?,?,?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET "
          "book_id=excluded.book_id, sid=excluded.sid, ua=excluded.ua, ip=excluded.ip, ts=excluded.ts, "
          "started_at=CASE WHEN listen_session.sid=excluded.sid THEN listen_session.started_at "
          "ELSE excluded.started_at END",
          (user["id"], book_id, sid, ua, ip, db.now(), now))
    return stolen


def _listen_release(user, sid=None):
    """停止听书时主动释放，让别人能立刻在这台账号上听（不必等租约到期）

    同时把这个 sid 记进 _listen_released 宽限期表，防止在途的进度/心跳请求
    把刚删掉的会话又 INSERT 回来（否则用户一退出，账号就被自己锁死）。
    """
    row = _listen_lock_row(user["id"])
    if row and (not sid or not row["sid"] or row["sid"] == sid):
        db.ex("DELETE FROM listen_session WHERE user_id=?", (user["id"],))
        if sid:
            now = time.time()
            with _listen_released_lock:
                _listen_released[(user["id"], sid)] = now
                # 顺手清理过期条目，别让这张表无限长
                for k, v in list(_listen_released.items()):
                    if now - v > _LISTEN_RELEASE_GRACE:
                        _listen_released.pop(k, None)
        return True
    return False


def _listen_holder(user_id, sid=None):
    """当前占用者（排除自己），给前端提示用"""
    row = _listen_lock_row(user_id)
    if not row or not row["sid"] or row["sid"] == (sid or ""):
        return None
    if (time.time() - float(row["ts"] or 0)) >= LISTEN_LEASE:
        return None
    ob = db.q("SELECT title FROM books WHERE id=?", (row["book_id"],), one=True)
    return {"book_id": row["book_id"], "title": (ob["title"] if ob else ""),
            "ua": row["ua"] or "", "ip": row["ip"] or "", "started_at": row["started_at"]}


def _listen_quota(user):
    """免费听书额度（分组配置；管理员豁免）。0=没有额度"""
    if user["role"] == "admin":
        return 0
    return int(auth.limits_of(user).get("listen_monthly_limit") or 0)


def _listen_quota_ok(user, book_id, use=False):
    """本次听书能否走「免费额度」。

    额度按「不同的书各占一个名额」消耗，**名额有效期为 db.LISTEN_VALID_DAYS（30）天**：
    同一本书在占下之后的 30 天内接着听免费；超过 30 天，名额自动作废，
    再听会重新占一个名额，额度用完了就回到扣树叶。
    （业主 2026-10-04 定的规则：限制一个月内的听书量，避免 TTS 压力过大。）

    `db.listen_logged()` 与 `db.count_month_listens()` 共用同一个 `db.listen_cutoff()`，
    所以「本书还占不占名额」和「已用几本」永远一致。
    use=False 只查询（用于 info / 取音频时的放行判断），
    use=True 才真正记账——只有确认开始听才扣名额，光打开页面不算。
    """
    lim = _listen_quota(user)
    if lim <= 0:
        return False
    if db.listen_logged(user["id"], book_id):
        return True                      # 本书名额还在有效期内，免费
    if db.count_month_listens(user["id"]) >= lim:
        return False                     # 有效期内的额度用完了，回到原规则
    if use:
        db.log_listen(user["id"], book_id)
    return True


def _listen_voices_for(user, cfg=None, wait=True):
    """给客户端「选音色」的列表。

    三层过滤：① 只保留该用户分组可用的线路；② 去掉已停用/已删除的音色；
    ③ 用站点侧的重命名覆盖标签。每项带上它属于哪条线路，前端可以按线路分组展示。

    ★ wait=False 用于 /listen/seg 的合法性校验（热路径），只读缓存、不发 HTTP。
    """
    cfg = cfg or tts.settings()
    out, seen = [], set()
    for ln in listen_admin.voices_for_lines(cfg, for_user=user, wait=wait):
        for v in ln["voices"]:
            if not v.get("on"):
                continue
            vid = v.get("id")
            if not vid or vid in seen:
                continue
            seen.add(vid)
            item = dict(v)
            item["label"] = v.get("name") or vid
            item["line"] = ln["url"]
            item["line_name"] = ln["name"]
            out.append(item)
    return out


def _listen_default_voice(user, cfg=None, line=""):
    """该用户可用的默认音色，用来替换「被停用 / 被删除 / 无权使用」的音色。

    全局默认音色可能落在一条他无权使用的线路上、或者被停用了，那就沿着
    「可用线路」往下找第一条启用的音色，实在没有才退回全局默认。

    ★ line 非空时（用户手动选了线路）**必须从那条线路里挑**。
    否则会挑到一个这条线路上根本不存在的音色，调度器只能换一台机器去合成，
    用户看到的就是「我选了备用二，实际是主线一在响」—— 音色和线路一起被换掉。
    选线路是用户的明确意愿，替换音色不该把它一起推翻。
    """
    cfg = cfg or tts.settings()
    vs = _listen_voices_for(user, cfg, wait=False)
    ids = {v["id"] for v in vs}
    d = tts.default_voice(cfg)

    if line:
        srv = tts.line_of(cfg, line)
        if srv:
            dv = tts.default_voice_of(srv, cfg)
            if dv in ids:
                return dv
            for ln in listen_admin.voices_for_lines(cfg, for_user=user, wait=False):
                if ln["url"] != srv["url"]:
                    continue
                for v in ln["voices"]:
                    if v.get("on"):
                        return v["id"]

    if d in ids:
        return d
    if not vs:
        return d          # 清单没热，别猜，直接用全局默认
    for ln in listen_admin.voices_for_lines(cfg, for_user=user, wait=False):
        srv = tts.line_of(cfg, ln["url"])
        if not srv:
            continue
        dv = tts.default_voice_of(srv, cfg)
        if dv in ids:
            return dv
        for v in ln["voices"]:
            if v.get("on"):
                return v["id"]
    return d


def _listen_saved_line(user, book_id):
    """这本书上次选的线路。存在进度表里，原生后台播放不带 line 参数时靠它沿用。"""
    r = db.q("SELECT line FROM listen_progress WHERE user_id=? AND book_id=?",
             (user["id"], book_id), one=True)
    return ((r["line"] if r else "") or "").strip()


def _listen_line_of(user, cfg, book_id, req_line="", voice=None):
    """本次用哪条线路：请求显式指定 > 这本书上次选的 > 自动。

    显式指定要校验；线路被后台删掉、禁用，或**该用户的分组没有这条线路的权限**时
    静默退回自动 —— 用户不该因为一条线路下线或权限调整就彻底听不了书。

    ★ 「退回自动」不能真的交回给 tts 的自动挑线：`tts.candidates()` 是**在全部
      线路里**按健康度和负载轮询的，它根本不知道分组权限这回事。于是后台把一条
      线路只勾给管理员，普通用户虽然"选不了"，照样会在自动模式下被调度到那条线
      上跑 —— 权限就成了纯摆设（实测普通用户仍会被派到「主线一」）。
      所以对**受权限限制的用户**，这里必须把线路定死在有权限的范围里，
      而不是返回空串。未受限的用户仍返回空串，保留原来的轮询与故障转移。
    """
    for cand in ((req_line or "").strip(), _listen_saved_line(user, book_id)):
        if cand:
            srv = tts.line_of(cfg, cand)
            if srv and listen_admin.line_allowed(srv["url"], user, cfg):
                return srv["url"]
    allow = _listen_lines_for(user, cfg)
    allurls = set(s["url"] for s in tts.active_servers(cfg))
    if allow and allow != allurls:
        # 受限：按 tts 自己的优先级，在有权限的线路里挑第一条能出这个音色的
        for c in tts.candidates(cfg, voice):
            if c.get("url") in allow:
                return c["url"]
        return sorted(allow)[0]          # 兜底也必须是"有权限的"那条
    return ""


def _listen_lines_for(user, cfg=None):
    """该用户的分组能用的线路（url 集合）。没配任何分组权限时=全部线路。"""
    cfg = cfg or tts.settings()
    d = listen_admin.load()
    out = set()
    for srv in tts.active_servers(cfg):
        if listen_admin.groups_allowed(listen_admin.line_cfg(d, srv["url"]), user):
            out.add(srv["url"])
    return out


def _listen_lines_public(user, cfg=None):
    """播放页「选择线路」里**该用户看得见**的线路列表。

    ★ 原来这里直接把 `tts.line_info(cfg)` 原样返回 —— 那是**全部线路**，
      分组权限只在真正点播时才校验。结果：后台把「主线一」只勾给管理员，
      普通用户的播放页照样列出这条线路、还能选中，看起来就是"权限没生效"。
      列表这一层必须一起过滤，光在后端拦点播是"不能用但看得见"，与配置语义不符。
    """
    cfg = cfg or tts.settings()
    allow = _listen_lines_for(user, cfg)
    return [x for x in tts.line_info(cfg) if x.get("id") in allow]


def _listen_quota_info(user):
    """给前端看的额度提示。没有额度配置时返回 None。

    `valid_days` 一定要带上：前端要把「名额 30 天过期」讲清楚，
    否则用户过了一个月被重新扣名额时，会觉得是系统出了 bug。
    """
    lim = _listen_quota(user)
    if lim <= 0:
        return None
    used = db.count_month_listens(user["id"])
    return {"limit": lim, "used": used, "left": max(0, lim - used),
            "valid_days": db.LISTEN_VALID_DAYS}


@app.get("/api/books/{book_id}/listen/info")
def listen_info(book_id: int, request: Request, user=Depends(get_current_user)):
    """听书入口信息。游客不可听书（避免匿名流量占用 GPU）。"""
    b = _accessible_book_or_404(book_id, user)
    cfg = tts.settings()
    if not cfg["enabled"]:
        return {"enabled": False, "reason": "听书功能未开启"}
    if reader.kind(b) not in LISTEN_KINDS:
        return {"enabled": False, "reason": "该格式暂不支持听书"}
    segs = tts.segments(b)
    if not segs:
        return {"enabled": False, "reason": "未能从这本书里提取到文字"}
    can_free = auth.can(user, "listen")
    # 「这本书已经付过」= 扣过树叶，或者占过免费额度名额。
    # ★ 两者都**只在 db.LISTEN_VALID_DAYS（30）天内有有效**：超过 30 天，
    #   `_leaf_spent` 和 `db.listen_logged` 都会返回 False，于是 already=False，
    #   用户会重新走「免费额度 → 扣树叶」——这就是「过期后需重新购买」。
    paid = bool(_leaf_spent(user["id"], book_id, "listen"))
    quota_used = bool(db.listen_logged(user["id"], book_id))
    already = paid or quota_used
    quota = _listen_quota_info(user)                     # 免费额度（没配就是 None）
    # quota_ok 的含义是「本次会**新占**一个免费名额」，所以已付过的书一律 False ——
    # 前端靠它决定要不要弹「使用免费额度」的确认框。以前这里没排除「已占过名额」，
    # 于是同一本书每次进去都弹一次「共 5 本，已用 1 本，还剩 4 本」，
    # 用户以为又要扣一次。现在只在**真的会新占名额**时才弹。
    quota_ok = (not can_free) and (not already) and _listen_quota_ok(user, book_id)
    need_spend = (not can_free) and (not already) and (not quota_ok)
    balance = _leaf_balance(user["id"])
    if need_spend and balance < cfg["cost"]:
        why = "树叶不足：本次需 %d 片，当前 %d 片" % (cfg["cost"], balance)
        if quota and quota["left"] <= 0:
            why = ("免费听书额度已用完（%d 天内 %d 本），继续听需 %d 片树叶，当前仅 %d 片"
                   % (db.LISTEN_VALID_DAYS, quota["limit"], cfg["cost"], balance))
        return {"enabled": False, "need_spend": True, "cost": cfg["cost"], "balance": balance,
                "quota": quota, "reason": why}
    voices = _listen_voices_for(user, cfg)
    if not voices:
        return {"enabled": False, "reason": "TTS 服务不可用，请联系管理员"}
    # 听书和阅读共用同一个位置：两边都记，哪边更近用哪边。
    # 阅读进度只精确到章节，所以从阅读侧过来时按章内比例折算成句子。
    line = _listen_line_of(user, cfg, book_id, request.query_params.get("line"),
                           _listen_voice_of(user, cfg, book_id))
    holder = _listen_holder(user["id"], request.query_params.get("sid"))
    p = db.q("SELECT * FROM listen_progress WHERE user_id=? AND book_id=?",
             (user["id"], book_id), one=True)
    rp = db.q("SELECT * FROM progress WHERE user_id=? AND book_id=?",
              (user["id"], book_id), one=True)
    resume, resume_src = None, ""
    if p:
        resume = {"seg_idx": p["seg_idx"], "offset": p["offset"],
                  "voice": p["voice"], "line": p["line"], "percent": p["percent"]}
        resume_src = "listen"
    if rp and rp["position"]:
        try:
            rpos = json.loads(rp["position"])
        except Exception:
            rpos = None
        # ★ 听书自己折算写回的阅读进度带 dev="listen"，它只是「听到哪」的镜像；
        #   阅读进度只精确到章节，若反过来用它覆盖听书位置，每次重进听书都会退回
        #   到本章开头。只有用户在阅读器里真正读出来的位置（dev 为设备号）才允许覆盖，
        #   这样「在阅读里读到第 8 章再进听书接着第 8 章」的原有设计仍保留。
        if rpos and rpos.get("dev") != "listen":
            newer = (not p) or (str(rp["updated_at"] or "") > str(p["updated_at"] or ""))
            if newer:
                try:
                    si = tts.read_pos_to_seg(segs, rpos)
                except Exception:
                    si = None
                if si is not None:
                    resume = {"seg_idx": si, "offset": 0, "voice": (p["voice"] if p else ""),
                              "percent": rp["percent"] or 0}
                    resume_src = "read"
    return {"enabled": True, "book_id": book_id, "title": b["title"], "kind": reader.kind(b),
            "can_free": can_free, "need_spend": need_spend, "paid": paid,
            "quota_used": quota_used, "already": already,
            "quota": quota, "quota_ok": quota_ok,
            "line": line, "lines": _listen_lines_public(user, cfg),
            "cost": cfg["cost"], "balance": balance,
            "default_voice": _listen_voice_of(user, cfg, book_id),
            # 显示名由 tts.display_name 统一算好（后台改名 > 样板表中文名 > 服务器标签），
            # 后台「音色管理」用的是同一个口径 —— 两边必须一致，否则管理员对不上号。
            # 同时带上所属线路，前端可以按线路分组、并显示每个音色来自哪台机器。
            "voices": [{"id": v["id"],
                        "label": (v.get("name") or v.get("label") or v["id"]),
                        "gender": v.get("gender") or "", "f0": v.get("f0"),
                        "line": v.get("line") or "", "line_name": v.get("line_name") or ""}
                       for v in voices],
            "styles": tts.styles(cfg),
            "total": len(segs), "chars": sum(s["chars"] for s in segs),
            "chapters": tts.chapters_of(segs),
            "progress": resume, "progress_source": resume_src,
            "holder": holder,
            "cache": tts.cache_stats(book_id), "queue": tts.queue_stats()}


@app.post("/api/books/{book_id}/listen/start")
def listen_start(book_id: int, request: Request, body=Depends(json_body_or_empty), user=Depends(get_current_user)):
    """确认开始听书：先抢听书锁，无 listen 权限则扣树叶（同一用户同一本书只扣一次）"""
    b, segs, cfg = _listen_book(book_id, user)
    stolen = _listen_touch(user, book_id, body.get("sid"), request, take=bool(body.get("take")))
    # 听书日志：确认开始听之后才记（抢锁失败会抛异常，那时不该留痕）
    _log_activity_once(user, "listen", book_id, request, "开始听书",
                       title=b["title"] if b else None)
    # 放行顺序：分组免费听书 > 本书已付过树叶 > 本月免费额度 > 扣树叶
    if not auth.can(user, "listen") and not _leaf_spent(user["id"], book_id, "listen"):
        if not _listen_quota_ok(user, book_id, use=True):
            _spend_leaves(user, book_id, "listen", cfg["cost"])
    return {"ok": True, "total": len(segs), "balance": _leaf_balance(user["id"]),
            "stolen": stolen, "quota": _listen_quota_info(user)}


# 段间无缝：每取一段，就顺手把后面几段排进合成队列。
#
# 为什么放在服务端：APP 的原生后台播放一次只预取 1 段，而短句（6 个字≈2.5 秒音频）
# 合成就要 2 秒以上，第 2 段经常还没好，段间就会空 2 秒。放在服务端做滚动预取，
# 任何客户端（网页 / APP 原生）都自动受益，不必重新打 APK。
# 服务端滚动预取的句数。★ 这个数字直接决定「段间空档」：
# 合成速度是实时率的 0.6~1.4 倍且时有 2~3 倍抖动（实测同一句 2.54s / 6.50s 都出现过），
# 窗口越浅，抖动一来就把预取垫子耗光，下一句只能等现合成 —— 就是那 2 秒空档。
# 交错 A/B 实测（单听众、真实播放节奏、多轮交替抵消主机漂移）：
#   workers=1 ahead=3  → 平均空档 11.4s
#   workers=3 ahead=3  → 平均空档  6.9s
#   workers=3 ahead=10 → 平均空档  2.6s（中位数 0.00s）
# 窗口加深的代价只是「用户中途走掉时多合成几句」，会被 LRU 自然淘汰，很划算。
# 可用 BOOKMGR_LISTEN_AHEAD 覆盖，便于线上调整。
LISTEN_AHEAD = int(os.environ.get("BOOKMGR_LISTEN_AHEAD") or 10)


def _listen_prefetch_ahead(book_id, segs, idx, voice, cfg, line):
    """把 idx 之后的 LISTEN_AHEAD 段排进预取队列（不等待，失败也不影响本次播放）"""
    start = idx + 1
    if start >= len(segs):
        return 0
    try:
        return tts.QUEUE.prefetch(book_id, segs[start:start + LISTEN_AHEAD],
                                  voice, cfg, tts.serving_model(cfg, voice, line),
                                  line=line)
    except Exception:
        return 0


@app.get("/api/books/{book_id}/listen/seg/{idx}")
def listen_seg(book_id: int, idx: int, request: Request):
    """取第 idx 句的音频。<audio> 无法带 Authorization 头，走媒体凭证 ?t="""
    user = _user_from_media(request)
    if user["id"] == 0:
        raise HTTPException(403, "请先登录后再使用听书")
    b, segs, cfg = _listen_book(book_id, user)
    if (not auth.can(user, "listen") and not _leaf_spent(user["id"], book_id, "listen")
            and not _listen_quota_ok(user, book_id)):
        raise HTTPException(403, "请先确认听书（需消耗树叶）")
    if idx < 0 or idx >= len(segs):
        raise HTTPException(404, "段落不存在")
    _listen_touch(user, book_id, request.query_params.get("sid"), request)
    seg = segs[idx]
    # 先算出想用的音色，再定线路：受分组权限限制的用户要在"有权限的线路"里
    # 挑一条**能出这个音色**的，否则会为了迁就音色又调回没权限的机器，
    # 表现就是「音色和线路一起变了」。音色列表本身也已经按权限过滤过了。
    voice = (request.query_params.get("voice") or "").strip() or _listen_voice_of(user, cfg, book_id)
    line = _listen_line_of(user, cfg, book_id, request.query_params.get("line"), voice)
    if not _voice_allowed(cfg, voice, user):
        voice = _listen_default_voice(user, cfg, line)
    # 先把后面几段排上（优先级 1，不会插到本次点播前面），再去合成当前这段
    _listen_prefetch_ahead(book_id, segs, idx, voice, cfg, line)
    try:
        # 缓存键里的 model 必须是「实际产出模型」而不是全局 model：
        # 同音色在不同模型上是不同的声音，否则命中缓存会播出另一个音色。
        data, hit, src = tts.QUEUE.ensure(book_id, seg, voice, cfg,
                                          tts.serving_model(cfg, voice, line), line=line)
    except tts.TTSError as e:
        raise HTTPException(503, str(e))
    # 播放页要在进度右边显示「当前线路」。这里回报的必须是**实际产出**的那台：
    # 手动选线路时它就是选的那台；自动模式下是轮询/兜底真正落到的那台 ——
    # 两者都可能与配置里的默认不同，用配置去猜就会显示错。
    # src 为空只发生在「本次改动之前就缓存好的音频」上，那时才退回预测。
    used_name = tts.line_name(cfg, src)
    if not used_name:
        _srv = tts.serving_line(cfg, voice, line)
        used_name = (_srv.get("name") or "") if _srv else ""
    # 播放页的「当前线路」：网页靠下面的响应头，APP 的原生后台播放靠这条推送
    _listen_notify_line(user["id"], request.query_params.get("sid"), idx, used_name)
    # ★ HTTP 头只能装 latin-1，中文线路名（主线一/备用一）直接塞进去会当场
    #   UnicodeEncodeError → 整个请求 500。必须百分号编码，客户端 decodeURIComponent。
    return Response(content=data, media_type="audio/ogg",
                    headers={"Cache-Control": "private, max-age=604800, immutable",
                             "X-Seg-Index": str(idx), "X-Voice": voice,
                             "X-Line": line or "auto",
                             "X-Line-Used": quote(used_name),
                             "X-Cache": "hit" if hit else "miss",
                             "X-Seg-Chars": str(seg["chars"])})


@app.get("/api/books/{book_id}/listen/texts")
def listen_texts(book_id: int, user=Depends(get_current_user),
                 from_: int = Query(0, alias="from"), count: int = Query(20)):
    """按位置取句子文本：播放器显示上下文用，避免一次下发整本书几千句"""
    b, segs, cfg = _listen_book(book_id, user)
    total = len(segs)
    start = max(0, min(int(from_ or 0), total - 1))
    count = min(40, max(1, int(count or 20)))
    part = segs[start:start + count]
    return {"from": start, "total": total,
            "items": [{"idx": s["idx"], "text": s["text"], "chars": s["chars"],
                       "chapter": s["chapter"], "title": s["title"]} for s in part]}


@app.get("/api/books/{book_id}/listen/status")
def listen_status(book_id: int, user=Depends(get_current_user)):
    """合成进度：客户端用来显示「正在合成 x/y」"""
    _accessible_book_or_404(book_id, user)
    return {"queue": tts.queue_stats(), "cache": tts.cache_stats(book_id),
            "settings": {"cost": tts.settings()["cost"], "enabled": tts.settings()["enabled"]}}


@app.post("/api/books/{book_id}/listen/prefetch")
def listen_prefetch(book_id: int, request: Request, body=Depends(json_body), user=Depends(get_current_user)):
    """预取：把接下来几句排进合成队列但不等待，客户端播到时已缓存"""
    b, segs, cfg = _listen_book(book_id, user)
    if (not auth.can(user, "listen") and not _leaf_spent(user["id"], book_id, "listen")
            and not _listen_quota_ok(user, book_id)):
        raise HTTPException(403, "请先确认听书（需消耗树叶）")
    _listen_touch(user, book_id, body.get("sid"), request)
    start = max(0, int(body.get("from") or 0))
    count = min(20, max(1, int(body.get("count") or 5)))
    voice = (body.get("voice") or "").strip() or _listen_voice_of(user, cfg, book_id)
    line = _listen_line_of(user, cfg, book_id, body.get("line"), voice)
    if not _voice_allowed(cfg, voice, user):
        voice = _listen_default_voice(user, cfg, line)
    n = tts.QUEUE.prefetch(book_id, segs[start:start + count], voice, cfg,
                           tts.serving_model(cfg, voice, line), line=line)
    return {"ok": True, "queued": n, "line": line, "queue": tts.queue_stats()}


@app.post("/api/books/{book_id}/listen/heartbeat")
def listen_heartbeat(book_id: int, request: Request, body=Depends(json_body_or_empty), user=Depends(get_current_user)):
    """听书心跳。长句合成要几十秒，期间没有别的请求，靠它续租约。
    返回 owned=False 表示已被别的终端抢占，客户端应立即停止播放。"""
    sid = body.get("sid")
    try:
        _listen_touch(user, book_id, sid, request)
    except HTTPException as e:
        return {"ok": True, "owned": False, "reason": e.detail}
    # 兜底：长连接万一被中间代理缓冲/断开，心跳（5 秒一次）也能把当前线路带回来
    out = {"ok": True, "owned": True}
    snap = _listen_line_now(user["id"], sid)
    if snap:
        out["line"] = snap.get("name", "")
        out["line_idx"] = snap.get("idx", 0)
    return out


@app.get("/api/books/{book_id}/listen/watch")
async def listen_watch(book_id: int, request: Request, user=Depends(get_current_user)):
    """听书锁的长连接推送。锁被抢占时立刻推一条 kick 事件。

    客户端用 fetch 读取（而不是 EventSource），这样才能带上 Authorization 头。
    每 20 秒发一条注释行保活，避免中间代理把连接掐掉。
    """
    q = asyncio.Queue()
    globals()["_MAIN_LOOP"] = asyncio.get_running_loop()
    _listen_watchers.setdefault(user["id"], set()).add(q)

    async def gen():
        try:
            yield ": connected\n\n"          # 让客户端确认连上了
            # 补一条「当前线路」快照：本终端可能是第一条推送之后才连上来的
            # （APP 里原生播放和 WebView 各有一条连接），不补就永远看不到线路。
            snap = _listen_line_now(user["id"], request.query_params.get("sid"))
            if snap:
                yield "event: line\ndata: %s\n\n" % json.dumps(
                    {"type": "line", "sid": request.query_params.get("sid"),
                     "idx": snap.get("idx", 0), "name": snap.get("name", "")},
                    ensure_ascii=False)
            while True:
                try:
                    item = await asyncio.wait_for(q.get(), timeout=20)
                except asyncio.TimeoutError:
                    if await request.is_disconnected():
                        break
                    yield ": keep-alive\n\n"
                    continue
                yield "event: %s\ndata: %s\n\n" % (
                    "line" if item.get("type") == "line" else "kick",
                    json.dumps(item, ensure_ascii=False))
        except asyncio.CancelledError:
            raise
        finally:
            _listen_watchers.get(user["id"], set()).discard(q)

    return StreamingResponse(gen(), media_type="text/event-stream", headers={
        "Cache-Control": "no-cache, no-transform",
        "Connection": "keep-alive",
        "X-Accel-Buffering": "no",
    })


@app.post("/api/books/{book_id}/listen/stop")
def listen_stop(book_id: int, request: Request, body=Depends(json_body_or_empty), user=Depends(get_current_user)):
    """主动停止听书，立刻释放锁（不必等租约到期）。

    可选带上进度字段（save_progress + seg_idx/offset/voice/line/percent）：
    客户端退出播放页时**一次请求**同时「存进度 + 释放会话」，避免两个请求乱序 ——
    进度请求后到会把刚释放的会话又 INSERT 回去，账号就被自己锁住了。
    注意这里**故意不调 _listen_touch**，那正是会重新建会话的那一步。
    """
    sid = body.get("sid")
    if body.get("save_progress"):
        try:
            _listen_write_progress(user, book_id, body)
        except Exception as e:
            log.warning("停止听书时存进度失败 book=%s：%s", book_id, e)
    with _line_pushed_lock:
        _line_pushed.pop((user["id"], sid), None)     # 顺手回收去重表
    return {"ok": True, "released": _listen_release(user, sid)}


@app.post("/api/books/{book_id}/listen/line")
def listen_set_line(book_id: int, request: Request, body=Depends(json_body), user=Depends(get_current_user)):
    """手动选线路。

    单独一个接口、而不是复用存进度：用户可能在还没点播放时就换线路，
    而存进度在 seg_idx<0 时是空操作。线路只更新 line 列，绝不碰听书位置。
    """
    _accessible_book_or_404(book_id, user)
    _listen_touch(user, book_id, body.get("sid"), request)
    line = (body.get("line") or "").strip()
    if line:
        _cfg = tts.settings()
        _srv = tts.line_of(_cfg, line)
        if not _srv:
            raise HTTPException(400, "线路不存在或已下线")
        # ★ 原来只校验"线路存在"，**不校验分组权限** —— 分组里没这条线路的用户
        #   照样能把线路存进进度，播放页看起来就是"能用主线一"。
        if not listen_admin.line_allowed(_srv["url"], user, _cfg):
            raise HTTPException(403, "你的分组没有使用这条线路的权限")
    db.ex("INSERT INTO listen_progress (user_id,book_id,line,updated_at) VALUES (?,?,?,?) "
          "ON CONFLICT(user_id,book_id) DO UPDATE SET line=excluded.line",
          (user["id"], book_id, line, db.now()))
    return {"ok": True, "line": line}


@app.get("/api/books/{book_id}/listen/progress")
def listen_get_progress(book_id: int, user=Depends(get_current_user)):
    p = db.q("SELECT * FROM listen_progress WHERE user_id=? AND book_id=?",
             (user["id"], book_id), one=True)
    return {"progress": ({"seg_idx": p["seg_idx"], "offset": p["offset"],
                          "voice": p["voice"], "line": p["line"],
                          "percent": p["percent"]} if p else None)}


def _listen_write_progress(user, book_id, body):
    """把听书进度落库（**不含**会话续期）。

    /listen/progress 和 /listen/stop 共用它。退出播放页时「存进度」和「释放会话」
    必须在同一个请求里按顺序完成：拆成两个请求会乱序（实测 stop 先到、progress 后到），
    而后到的进度请求会走 _listen_touch 把刚释放的会话**又 INSERT 回去** ——
    用户一走，账号反而被自己锁住，下次进来就提示「已在另一台设备上听书」。
    """
    voice = (body.get("voice") or "").strip()
    # 线路：只接受当前确实启用的线路，别把脏值写进库里
    line = (body.get("line") or "").strip()
    if line and not tts.line_of(tts.settings(), line):
        line = ""
    seg_idx = max(0, int(body.get("seg_idx") or 0))
    pct = float(body.get("percent") or 0)
    # ★ 两个表必须用同一个时间戳。
    #   以前这里各调一次 db.now()（精度只到秒），跨秒时 progress 会比
    #   listen_progress 新，下次进听书就被判成「阅读进度更新」，退回到章节开头。
    #   听书每 8 秒自动存一次，累计很快就命中这个跨秒窗口。
    ts = db.now()
    db.ex("INSERT INTO listen_progress (user_id,book_id,seg_idx,offset,voice,line,percent,updated_at) "
          "VALUES (?,?,?,?,?,?,?,?) ON CONFLICT(user_id,book_id) DO UPDATE SET "
          "seg_idx=excluded.seg_idx, offset=excluded.offset, "
          "voice=CASE WHEN excluded.voice='' THEN listen_progress.voice ELSE excluded.voice END, "
          "line=CASE WHEN excluded.line='' THEN listen_progress.line ELSE excluded.line END, "
          "percent=excluded.percent, updated_at=excluded.updated_at",
          (user["id"], book_id, seg_idx,
           float(body.get("offset") or 0), voice, line, pct, ts))
    # 折算写回阅读进度。失败不影响听书本身（segs 一般已缓存，代价很低）。
    try:
        b = _book_or_404(book_id)
        if reader.kind(b) in LISTEN_KINDS:
            pos = tts.seg_to_read_pos(tts.segments(b), seg_idx, reader.kind(b))
            if pos:
                db.ex("INSERT INTO progress (user_id,book_id,position,percent,updated_at) "
                      "VALUES (?,?,?,?,?) ON CONFLICT(user_id,book_id) DO UPDATE SET "
                      "position=excluded.position, percent=excluded.percent, "
                      "updated_at=excluded.updated_at",
                      (user["id"], book_id, json.dumps(pos, ensure_ascii=False), pct, ts))
    except Exception:
        pass
    return {"ok": True}


@app.put("/api/books/{book_id}/listen/progress")
def listen_save_progress(book_id: int, request: Request, body=Depends(json_body), user=Depends(get_current_user)):
    """存听书进度。

    听书进度存 listen_progress（句子级精度，progress 表装不下）。
    同时折算成章节位置写回 progress，让「听到哪」和「读到哪」始终是同一个位置：
    听完第 5 章去阅读就停在第 5 章，反之在阅读里读到第 8 章再进听书也接着第 8 章。
    """
    _listen_touch(user, book_id, body.get("sid"), request)
    return _listen_write_progress(user, book_id, body)


@app.get("/api/settings")
def get_settings(user=Depends(auth.get_optional_user)):
    if user["id"] == 0:   # 游客：返回默认设置
        return {"theme": "sepia", "font_size": 18, "font_family": "serif", "line_height": 1.8, "page_width": "92%", "brightness": 1.0, "flip_effect": "flip", "flip_speed": 380}
    s = db.q("SELECT * FROM settings WHERE user_id=?", (user["id"],), one=True)
    if not s:
        return {"theme": "sepia", "font_size": 18, "font_family": "serif", "line_height": 1.8, "page_width": "92%", "brightness": 1.0, "flip_effect": "flip", "flip_speed": 380}
    return {"theme": s["theme"], "font_size": s["font_size"], "font_family": s["font_family"],
            "line_height": s["line_height"], "page_width": s["page_width"], "brightness": s["brightness"],
            "flip_effect": s["flip_effect"], "flip_speed": s["flip_speed"]}


@app.put("/api/settings")
def put_settings(theme: str = Form("sepia"), font_size: int = Form(18),
                 font_family: str = Form("serif"), line_height: float = Form(1.8),
                 page_width: str = Form("92%"), brightness: float = Form(1.0),
                 flip_effect: str = Form("flip"), flip_speed: int = Form(380),
                 user=Depends(auth.get_optional_user)):
    if user["id"] == 0:   # 游客：设置不落库
        return {"ok": True}
    brightness = max(0.2, min(1.0, brightness))
    if flip_effect not in ("none", "slide", "flip", "curl", "fade"):
        flip_effect = "flip"
    flip_speed = max(120, min(1000, flip_speed))
    db.ex("INSERT INTO settings (user_id,theme,font_size,font_family,line_height,page_width,brightness,flip_effect,flip_speed) VALUES (?,?,?,?,?,?,?,?,?) "
          "ON CONFLICT(user_id) DO UPDATE SET theme=excluded.theme, font_size=excluded.font_size, font_family=excluded.font_family, line_height=excluded.line_height, page_width=excluded.page_width, brightness=excluded.brightness, flip_effect=excluded.flip_effect, flip_speed=excluded.flip_speed",
          (user["id"], theme, font_size, font_family, line_height, page_width, brightness, flip_effect, flip_speed))
    return {"ok": True}


# ---------- 首页分类（每个会员自定义） ----------
@app.get("/api/home-categories")
def get_home_categories(user=Depends(get_current_user)):
    s = db.q("SELECT home_categories FROM settings WHERE user_id=?", (user["id"],), one=True)
    raw = s["home_categories"] if s else ""
    return {"home_categories": [c for c in (raw or "").split(",") if c.strip()]}


@app.put("/api/home-categories")
def set_home_categories(request: Request, body=Depends(json_body), user=Depends(get_current_user)):
    val = str(body.get("home_categories", "") or "")
    db.ex("INSERT INTO settings (user_id, home_categories) VALUES (?,?) "
          "ON CONFLICT(user_id) DO UPDATE SET home_categories=excluded.home_categories",
          (user["id"], val))
    return {"ok": True, "home_categories": [c for c in val.split(",") if c.strip()]}


# ---------- 个人书库 ----------
@app.get("/api/shelf")
def shelf(user=Depends(get_current_user)):
    rows = db.q("""SELECT b.*, s.added_at, s.collection_id, c.name AS collection_name
                   FROM shelves s JOIN books b ON b.id=s.book_id
                   LEFT JOIN shelf_collections c ON c.id=s.collection_id
                   WHERE s.user_id=? ORDER BY s.added_at DESC""", (user["id"],))
    cols = db.q("""SELECT c.id, c.name, c.created_at,
                   (SELECT COUNT(*) FROM shelves s JOIN books b ON b.id=s.book_id WHERE s.collection_id=c.id) n
                   FROM shelf_collections c WHERE c.user_id=? ORDER BY c.sort_order, c.id""", (user["id"],))
    uncat = db.q("""SELECT COUNT(*) n FROM shelves s JOIN books b ON b.id=s.book_id
                    WHERE s.user_id=? AND s.collection_id IS NULL""", (user["id"],), one=True)["n"]
    cols = [dict(r) for r in cols]
    # 「来自分享」为空时自动隐藏（系统分组）
    cols = [c for c in cols if not (c["name"] == SHARE_COLLECTION_NAME and c["n"] == 0)]
    out = {"quota": user["quota"], "count": len(rows),
           "collections": cols, "uncategorized": uncat,
           "items": [dict(_book_json(r), collection_id=r["collection_id"], collection_name=r["collection_name"]) for r in rows]}
    # 管理员专属：待审的电子书共享申请，作为「共享申请」分类出现在管理员书架里，
    # 管理员可直接点开阅读、判断是否通过。
    if user["role"] == "admin":
        reqs = db.q("""SELECT r.id AS share_req_id, r.created_at AS requested_at, r.requester_id,
                              b.*, u.name AS req_real, u.username AS req_username
                       FROM share_requests r JOIN books b ON b.id=r.book_id
                       LEFT JOIN users u ON u.id=r.requester_id
                       WHERE r.status='pending' ORDER BY r.created_at DESC, r.id DESC""")
        out["share_requests"] = [
            dict(_book_json(r), share_req_id=r["share_req_id"], requested_at=r["requested_at"],
                 requester_name=(r["req_real"] or r["req_username"] or "会员"))
            for r in reqs]
        out["share_request_n"] = len(out["share_requests"])
    return out


@app.post("/api/shelf/collections")
def shelf_collection_create(name: str = Form(...), user=Depends(get_current_user)):
    name = name.strip()
    if not name:
        raise HTTPException(400, "分类名不能为空")
    if len(name) > 30:
        raise HTTPException(400, "分类名过长")
    if db.q("SELECT id FROM shelf_collections WHERE user_id=? AND name=?", (user["id"], name), one=True):
        raise HTTPException(400, "分类已存在")
    mx = db.q("SELECT COALESCE(MAX(sort_order),0) m FROM shelf_collections WHERE user_id=?", (user["id"],), one=True)["m"]
    cid = db.ex("INSERT INTO shelf_collections (user_id,name,sort_order,created_at) VALUES (?,?,?,?)",
                (user["id"], name, mx + 1, db.now()))
    return {"id": cid, "name": name, "n": 0}


@app.put("/api/shelf/collections/reorder")
def shelf_collection_reorder(ids: str = Form(...), user=Depends(get_current_user)):
    """拖拽排序：ids 为逗号分隔的分类 id 顺序"""
    try:
        id_list = [int(x) for x in ids.split(",") if x.strip() != ""]
    except ValueError:
        raise HTTPException(400, "参数错误")
    for i, cid in enumerate(id_list):
        db.ex("UPDATE shelf_collections SET sort_order=? WHERE id=? AND user_id=?", (i, cid, user["id"]))
    return {"ok": True}


@app.put("/api/shelf/collections/{cid}")
def shelf_collection_rename(cid: int, name: str = Form(...), user=Depends(get_current_user)):
    name = name.strip()
    if not name:
        raise HTTPException(400, "分类名不能为空")
    c = db.q("SELECT * FROM shelf_collections WHERE id=? AND user_id=?", (cid, user["id"]), one=True)
    if not c:
        raise HTTPException(404, "分类不存在")
    if c["name"] == SHARE_COLLECTION_NAME:
        raise HTTPException(400, "「来自分享」为系统分组，不能重命名")
    if db.q("SELECT id FROM shelf_collections WHERE user_id=? AND name=? AND id!=?", (user["id"], name, cid), one=True):
        raise HTTPException(400, "分类已存在")
    db.ex("UPDATE shelf_collections SET name=? WHERE id=?", (name, cid))
    return {"ok": True}


@app.delete("/api/shelf/collections/{cid}")
def shelf_collection_delete(cid: int, user=Depends(get_current_user)):
    c = db.q("SELECT * FROM shelf_collections WHERE id=? AND user_id=?", (cid, user["id"]), one=True)
    if not c:
        raise HTTPException(404, "分类不存在")
    if c["name"] == SHARE_COLLECTION_NAME:
        raise HTTPException(400, "「来自分享」为系统分组，不能删除")
    db.ex("UPDATE shelves SET collection_id=NULL WHERE collection_id=?", (cid,))
    db.ex("DELETE FROM shelf_collections WHERE id=?", (cid,))
    return {"ok": True}


@app.post("/api/shelf/{book_id}")
def shelf_add(book_id: int, collection_id: int = Form(None), user=Depends(get_current_user)):
    _accessible_book_or_404(book_id, user)
    if collection_id is not None:
        if not db.q("SELECT id FROM shelf_collections WHERE id=? AND user_id=?", (collection_id, user["id"]), one=True):
            raise HTTPException(404, "分类不存在")
    if db.q("SELECT id FROM shelves WHERE user_id=? AND book_id=?", (user["id"], book_id), one=True):
        db.ex("UPDATE shelves SET collection_id=? WHERE user_id=? AND book_id=?", (collection_id, user["id"], book_id))
        return {"ok": True, "message": "已更新分类"}
    n = db.q("SELECT COUNT(*) n FROM shelves WHERE user_id=?", (user["id"],), one=True)["n"]
    if n >= user["quota"]:
        raise HTTPException(400, f"个人书库已达上限（{user['quota']} 本）")
    db.ex("INSERT INTO shelves (user_id,book_id,collection_id,added_at) VALUES (?,?,?,?)",
          (user["id"], book_id, collection_id, db.now()))
    return {"ok": True}


@app.put("/api/shelf/{book_id}")
def shelf_move(book_id: int, collection_id: int = Form(None), user=Depends(get_current_user)):
    if collection_id is not None and not db.q("SELECT id FROM shelf_collections WHERE id=? AND user_id=?", (collection_id, user["id"]), one=True):
        raise HTTPException(404, "分类不存在")
    if not db.q("SELECT id FROM shelves WHERE user_id=? AND book_id=?", (user["id"], book_id), one=True):
        raise HTTPException(404, "该书不在书库中")
    db.ex("UPDATE shelves SET collection_id=? WHERE user_id=? AND book_id=?", (collection_id, user["id"], book_id))
    return {"ok": True}


@app.delete("/api/shelf/{book_id}")
def shelf_remove(book_id: int, user=Depends(get_current_user)):
    db.ex("DELETE FROM shelves WHERE user_id=? AND book_id=?", (user["id"], book_id))
    # 移出书架时同步撤销该书的站内分享访问权（若存在）
    db.ex("DELETE FROM book_grants WHERE book_id=? AND to_user_id=?", (book_id, user["id"]))
    return {"ok": True}


@app.post("/api/shelf/{book_id}/share")
def shelf_share_to_user(book_id: int, target: str = Form(...), user=Depends(get_current_user)):
    """站内分享：把本书分享给指定账号（用户名或数字ID），对方书架自动出现「来自分享」分组"""
    _accessible_book_or_404(book_id, user)
    target = (target or "").strip()
    if not target:
        raise HTTPException(400, "请输入对方账号")
    to = None
    if target.isdigit():
        to = db.q("SELECT * FROM users WHERE id=?", (int(target),), one=True)
    if not to:
        to = db.q("SELECT * FROM users WHERE username=?", (target,), one=True)
    if not to:
        to = db.find_user_by_nickname(target)   # 兼容按「昵称」分享
    if not to:
        raise HTTPException(404, "账号不存在")
    if not to["enabled"]:
        raise HTTPException(400, "对方账号已被禁用")
    if to["id"] == user["id"]:
        raise HTTPException(400, "不能分享给自己")
    # 授予访问权（幂等）
    db.ex("INSERT OR IGNORE INTO book_grants (book_id, from_user_id, to_user_id, created_at) VALUES (?,?,?,?)",
          (book_id, user["id"], to["id"], db.now()))
    # 加入对方书架「来自分享」分组（自动创建该分组）
    c = db.q("SELECT id FROM shelf_collections WHERE user_id=? AND name=?",
             (to["id"], SHARE_COLLECTION_NAME), one=True)
    if c:
        cid = c["id"]
    else:
        mx = db.q("SELECT COALESCE(MAX(sort_order),0) m FROM shelf_collections WHERE user_id=?",
                  (to["id"],), one=True)["m"]
        cid = db.ex("INSERT INTO shelf_collections (user_id,name,sort_order,created_at) VALUES (?,?,?,?)",
                    (to["id"], SHARE_COLLECTION_NAME, mx + 1, db.now()))
    # 若对方书架尚无此书则加入「来自分享」，已有则不移动其原有分类
    if not db.q("SELECT id FROM shelves WHERE user_id=? AND book_id=?", (to["id"], book_id), one=True):
        db.ex("INSERT INTO shelves (user_id,book_id,collection_id,added_at) VALUES (?,?,?,?)",
              (to["id"], book_id, cid, db.now()))
    db.log_audit(user, "site_share", "book", book_id, f"分享给 {to['username']}(id={to['id']})")
    b = db.q("SELECT title FROM books WHERE id=?", (book_id,), one=True)
    _t = b["title"] if b else f"#{book_id}"
    notify.notify_user(to["id"], "收到新分享", f"{_nick(user)} 把《{_t}》分享给了你，已在书架「{SHARE_COLLECTION_NAME}」分组中。",
                       kind="share", from_id=user["id"], link="#/shelf", ref_type="book", ref_id=book_id,
                       extra=[("分享人", _nick(user)), ("书籍", _t)])
    return {"ok": True, "message": f"已分享给 {_nick(to)}"}


def _check_month_download(user, book_id):
    """每月下载本数限额（分组配置，0=不限；管理员不限）；已下载过的书可重复下载，不计新额度"""
    if user["role"] == "admin":
        return
    lim = auth.limits_of(user)["download_monthly_limit"]
    if lim <= 0:
        return
    month_start = db.now()[:8] + "01 00:00:00"
    if db.q("SELECT 1 FROM download_logs WHERE user_id=? AND book_id=? AND created_at>=?",
            (user["id"], book_id, month_start), one=True):
        return
    if db.count_month_downloads(user["id"]) >= lim:
        raise HTTPException(403, f"本月下载已达上限（{lim} 本），下月自动恢复，敬请期待")


def _check_daily_convert(user, book_id):
    """每天转换本数限额（分组配置，0=不限；管理员不限）；当天已转换过的书可重复转换，不计新额度"""
    if user["role"] == "admin":
        return
    lim = auth.limits_of(user)["convert_daily_limit"]
    if lim <= 0:
        return
    day_start = db.now()[:10] + " 00:00:00"
    if db.q("SELECT 1 FROM convert_logs WHERE user_id=? AND book_id=? AND created_at>=?",
            (user["id"], book_id, day_start), one=True):
        return
    if db.count_daily_converts(user["id"]) >= lim:
        raise HTTPException(403, f"今日转换已达上限（{lim} 本），明日自动恢复")


# ---------- 下载/分享 ----------
def _audit_download(user, book, ip, source, fmt=""):
    """下载审计留痕：记录谁在何时下载了哪本书（合规与追溯）"""
    db.log_audit(user, "download", "book", book["id"],
                 f"下载《{book['title']}》{('.' + fmt) if fmt else ''} via {source}", ip)


# ---------- 下载安全：一次性短时凭证 ----------
# 下载/转换直链不再携带登录令牌（?token=），而是先换取一次性短时 ticket：
# 5 分钟有效、只能用一次，转发他人立即失效，杜绝“把下载链接发给别人”的不可控分享。
_dl_tickets = {}
_dl_tickets_lock = threading.Lock()
_DL_TICKET_TTL = 300   # 秒：下载直链有效期


def _user_from_bearer(request: Request):
    """仅从 Authorization 头解析并校验登录用户（失败返回 None）"""
    authz = request.headers.get("authorization", "")
    if not authz.startswith("Bearer "):
        return None
    payload = auth.decode_token(authz[7:])
    if not payload:
        return None
    user = db.q("SELECT * FROM users WHERE id=?", (payload["uid"],), one=True)
    if not user or not user["enabled"]:
        return None
    return user


def _user_from_lite_cookie(request: Request):
    """极简阅读页（/lite）的 cookie 登录态：老浏览器没有 JS，拿不到令牌，
    也发不出 Authorization 头，只有 HttpOnly 的 bm_lite cookie 这一条路。

    为什么媒体/下载接口要认它：epub 章节里的 <img>、pdf 的「下载原文件」链接
    都是浏览器自己发的请求，加不了自定义头；不认 cookie 就会 401，图片全裂。
    """
    tok = (request.cookies.get(lite.COOKIE) or "").strip()
    if not tok:
        return None
    payload = auth.decode_token(tok)
    if not payload:
        return None
    user = db.q("SELECT * FROM users WHERE id=?", (payload["uid"],), one=True)
    if not user or not user["enabled"]:
        return None
    return user


def _user_from_download(request: Request, book_id: int):
    """下载类接口鉴权：接受短时 ticket（有效期内可多次请求，兼容浏览器/下载器分段与重试）或 Authorization 头（拒绝 ?token= 查询参数）"""
    ticket = (request.query_params.get("ticket") or "").strip()
    if ticket:
        ticket = re.sub(r"\.[A-Za-z0-9]{2,5}$", "", ticket)   # 兼容下载链接末尾的扩展名后缀
        with _dl_tickets_lock:
            t = _dl_tickets.get(ticket)
            if not t or t["exp"] < time.time():
                raise HTTPException(403, "下载链接已失效，请重新获取")
            if t["book_id"] != book_id:
                raise HTTPException(404, "书籍不存在")
            uid = t["user_id"]
        if uid == 0:   # 游客：下载访客推荐书籍
            return auth.GUEST_USER
        user = db.q("SELECT * FROM users WHERE id=?", (uid,), one=True)
        if not user or not user["enabled"]:
            raise HTTPException(401, "未登录")
        return user
    user = _user_from_bearer(request)
    if not user:
        user = _user_from_lite_cookie(request)      # 无 JS 的老设备（/lite）：只有 cookie 可用
    if not user:
        raise HTTPException(401, "未登录")
    return user


# ---------- 媒体访问安全：短时凭证（封面/阅读器文件 <img>/<iframe> 无法带请求头） ----------
# 封面图片与阅读器内嵌文件 URL 不再携带登录令牌（?token=），改为 24 小时有效的媒体凭证：
# 凭证只代表“该用户原本就有的媒体访问权限”，过期自动失效，泄露后无法冒充账号。
_media_tickets = {}
_media_tickets_lock = threading.Lock()
_MEDIA_TICKET_TTL = 86400   # 秒：24 小时


@app.post("/api/media-ticket")
def create_media_ticket(user=Depends(auth.get_optional_user)):
    """换取媒体访问凭证（封面图片 / 阅读器文件用），URL 不携带登录令牌"""
    ticket = secrets.token_urlsafe(32)
    now = time.time()
    with _media_tickets_lock:
        for k in [k for k, v in _media_tickets.items() if v["exp"] < now]:
            _media_tickets.pop(k, None)
        _sb = 0
        if isinstance(user, dict):
            _sb = int(user.get("_share_bid") or 0)
        _media_tickets[ticket] = {"user_id": user["id"], "exp": now + _MEDIA_TICKET_TTL,
                                  "share_bid": _sb}
    return {"ticket": ticket, "expires_in": _MEDIA_TICKET_TTL}


def _user_from_media(request: Request):
    """封面/文件类接口鉴权：接受 ?t= 媒体凭证或 Authorization 头（拒绝 ?token= 查询参数）"""
    t = (request.query_params.get("t") or "").strip()
    if t:
        with _media_tickets_lock:
            rec = _media_tickets.get(t)
            if not rec or rec["exp"] < time.time():
                raise HTTPException(403, "链接已失效，请刷新页面")
            uid = rec["user_id"]
        sb = int(rec.get("share_bid") or 0)
        if sb:          # 分享在线阅读券签发的媒体凭证：只读那一本
            return auth.share_guest(sb)
        if uid == 0:   # 游客媒体凭证：仅可读范例图书
            return auth.GUEST_USER
        user = db.q("SELECT * FROM users WHERE id=?", (uid,), one=True)
        if not user or not user["enabled"]:
            raise HTTPException(401, "未登录")
        return user
    user = _user_from_bearer(request)
    if not user:
        user = _user_from_lite_cookie(request)      # 无 JS 的老设备（/lite）：只有 cookie 可用
    if not user:
        raise HTTPException(401, "未登录")
    return user


def _dl_ticket_of(request: Request):
    """从下载 URL 上取 ticket（去掉 .epub 这类扩展名后缀），没有就是空串"""
    t = (request.query_params.get("ticket") or "").strip()
    if not t:
        return ""
    return re.sub(r"\.[A-Za-z0-9]{2,5}$", "", t)


# 没有 ticket 的直链（分享链接、老式 ?token= 调用）同样要防「浏览器发两次 GET」：
# 按 (用途, 标识, IP) 做一个 90 秒的一次性闸门。
_dl_recent = {}
_dl_recent_lock = threading.Lock()
_DL_RECENT_WIN = 90   # 秒


def _first_hit(key):
    """该 key 在窗口内是否第一次出现；第一次返回 True 并占用窗口"""
    now = time.time()
    with _dl_recent_lock:
        for k in [k for k, exp in _dl_recent.items() if exp < now]:
            _dl_recent.pop(k, None)
        if _dl_recent.get(key, 0) > now:
            return False
        _dl_recent[key] = now + _DL_RECENT_WIN
        return True


def _claim_dl_log(ticket):
    """★ 一个 ticket = 一次下载 = 一条日志。

    浏览器（和下载管理器）拿到直链后经常发**两次** GET：先普通 GET 探一下，
    再带 `Range: bytes=0-` 正式拉。原先的「首次」判定是「没有 Range，或 bytes=0-」，
    这两次**全都算首次**，于是每次下载被记成两条一模一样、同一秒的行
    （实测访问日志：9 个 ticket 全部被 GET 了 2 次，管理页一半是重复）。

    ticket 本身就是「一次下载意图」的凭据（见 create_download_ticket），
    所以按 ticket 认一次最准：同一 ticket 的第 2 次及以后一律不记。
    没有 ticket 的老式调用（Bearer 直连、脚本）才回落到 Range 判定。
    """
    if not ticket:
        return False
    with _dl_tickets_lock:
        t = _dl_tickets.get(ticket)
        if not t or t.get("logged"):
            return False
        t["logged"] = True
        return True


@app.post("/api/books/{book_id}/download-ticket")
def create_download_ticket(book_id: int, user=Depends(auth.get_optional_user)):
    """换取一次性短时下载凭证（5 分钟、单次有效）：下载/转换直链不再暴露登录令牌；游客可下载访客推荐书籍"""
    b = _book_or_404(book_id)
    guest_featured = user["id"] == 0 and bool(b["guest_featured"]) and not b["hidden"]
    # 游客：仅访客推荐书籍可换凭证；登录用户：无 download/convert 权限也放行，下载时按树叶兑换
    if user["id"] == 0 and not guest_featured:
        raise HTTPException(403, "游客仅可下载访客推荐书籍")
    if user["id"] != 0:
        _check_month_download(user, book_id)
    _accessible_book_or_404(book_id, user)
    ticket = secrets.token_urlsafe(32)
    now = time.time()
    with _dl_tickets_lock:
        for k in [k for k, v in _dl_tickets.items() if v["exp"] < now]:
            _dl_tickets.pop(k, None)
        _dl_tickets[ticket] = {"user_id": user["id"], "book_id": book_id,
                               "exp": now + _DL_TICKET_TTL, "used": False}
    return {"ticket": ticket, "expires_in": _DL_TICKET_TTL,
            "download_url": f"/api/books/{book_id}/download?ticket={ticket}"}


@app.get("/api/books/{book_id}/download")
@app.get("/api/books/{book_id}/download.{ext}")
def download(book_id: int, request: Request, ext: str = ""):
    # 支持 /download.mobi 形式的 URL：Kindle 等设备按 URL 末尾扩展名判断可下载类型
    user = _user_from_download(request, book_id)
    b0 = _book_or_404(book_id)
    guest_featured = user["id"] == 0 and bool(b0["guest_featured"]) and not b0["hidden"]
    # 游客：仅访客推荐书籍可下载；无下载权限的登录用户：用树叶兑换（每本 1 片，同一本书只扣一次）
    if user["id"] == 0 and not guest_featured:
        raise HTTPException(403, "游客仅可下载访客推荐书籍")
    if not (auth.can(user, "download") or guest_featured):
        _spend_leaves(user, book_id, "download", LEAF_COST_DOWNLOAD)
    if user["id"] != 0:
        _check_month_download(user, book_id)
    b = _accessible_book_or_404(book_id, user)
    local = covers.ensure_local(b)
    # ★ 只在「第一次请求」写日志。浏览器/下载器拉大文件时会发一串 Range 分段请求，
    #   每次请求都进来一遍；无条件记录的话一次下载会变成几十条
    #   （实测熊二藏书洞下 13MB 的 mobi 被记成 26 条）。
    #   判断口径：没有 Range 头 = 完整下载；bytes=0- = 分段的头一个。其余分段跳过。
    _rng = (request.headers.get("range") or "").strip().lower()
    _tk = _dl_ticket_of(request)
    # ★ 有 ticket 就按 ticket 认一次（这才是「一次下载」的准确口径）；
    #   没有 ticket 的老式调用才回落到 Range 判定。
    _first = _claim_dl_log(_tk) if _tk else ((not _rng) or _rng.startswith("bytes=0-"))
    if _first:
        db.log_download(user["id"], book_id)
        _audit_download(user, b, _client_ip(request), "direct")
        db.log_file(user, "download", os.path.basename(b["path"]), size=b["size"], source="web",
                    book_id=b["id"], book_title=b["title"], ip=_client_ip(request), ext=b["ext"])
    # TXT 下载水印：在文件头注入下载人/时间，便于追溯传播源头
    if (b["ext"] or "").lower() == ".txt":
        try:
            with open(local, "rb") as fh:
                raw = fh.read()
            for enc in ("utf-8", "gbk", "gb18030", "big5"):
                try:
                    text = raw.decode(enc)
                    break
                except Exception:
                    continue
            else:
                text = raw.decode("utf-8", "replace")
            mark = (f"【云阅读】本书仅供下载用户 {user['username']} 个人学习使用，"
                    f"下载时间 {db.now()}，请勿传播转载。\n\n")
            return Response(mark + text, media_type="text/plain; charset=utf-8",
                            headers={"Content-Disposition":
                                     f"attachment; filename*=UTF-8''{quote(os.path.basename(b['path']))}"})
        except Exception:
            pass
    return _file_response(request, local, os.path.basename(b["path"]), download=True)


# ---------- 格式转换（calibre） ----------
# 转换缓存自动清理：浏览器/下载器常用 Range 分段下载，若响应一结束就删文件，
# 后续分段会 404。改为：每次下载请求到达时重置 45 秒延迟清理定时器——
# 最后一次下载请求 45 秒后自动删除，不依赖响应状态/后台任务，任何请求结果都可靠。
_dl_state = {}
_dl_lock = threading.Lock()
_DL_SETTLE = 45   # 秒：最后一次下载请求后的延迟清理时间


def _dl_schedule(book_id, fmt):
    """重置该格式的延迟清理定时器"""
    with _dl_lock:
        st = _dl_state.setdefault((book_id, fmt), {"timer": None})
        if st["timer"]:
            st["timer"].cancel()
        st["timer"] = threading.Timer(_DL_SETTLE, _dl_cleanup, args=(book_id, fmt))
        st["timer"].daemon = True
        st["timer"].start()


def _dl_cleanup(book_id, fmt):
    with _dl_lock:
        st = _dl_state.get((book_id, fmt))
        if not st:
            return
        st["timer"] = None
        reader.remove_convert_file(book_id, fmt)


def _dl_cancel(book_id, fmt):
    """取消待执行的清理（新转换/手动清理前调用，避免删掉刚生成的新文件）"""
    with _dl_lock:
        st = _dl_state.get((book_id, fmt))
        if st and st["timer"]:
            st["timer"].cancel()
            st["timer"] = None


# ---------- 转换任务队列（异步：大书转换不阻塞请求） ----------
_convert_tasks = {}
_convert_lock = threading.Lock()


def _run_convert(task_id, book_id, to, user_id, username):
    """后台执行转换，写入 _convert_tasks 状态"""
    b = _book_or_404(book_id)
    _dl_cancel(book_id, to)
    try:
        out = reader.convert_book(b, to)
        with _convert_lock:
            if not out or not os.path.exists(out):
                _convert_tasks[task_id].update({"status": "error", "error": "转换失败，请重试或换一种格式"})
                return
            db.log_convert(user_id, book_id)
            _convert_tasks[task_id].update({
                "status": "done", "fmt": to,
                "size_mb": round(os.path.getsize(out) / 1048576.0, 2),
                "url": f"/api/books/{book_id}/convert/{to}"})
    except Exception as e:
        with _convert_lock:
            _convert_tasks[task_id].update({"status": "error", "error": f"转换失败：{e}"})
    finally:
        db.log_audit({"id": user_id, "username": username}, "convert", "book", book_id,
                     f"转换为 {to}", None)


@app.post("/api/books/{book_id}/convert")
def convert_book(book_id: int, to: str = Form(...), user=Depends(get_current_user)):
    """转换书籍为指定格式（异步），结果缓存到 data/converted/{id}.{fmt}；无转换权限的分组可用树叶兑换（每本 2 片）"""
    b = _accessible_book_or_404(book_id, user)
    to = to.lower().lstrip(".")
    if to not in reader.CONVERT_FORMATS:
        raise HTTPException(400, f"不支持的格式：{to}（支持 {', '.join(reader.CONVERT_FORMATS)}）")
    has_perm = auth.can(user, "convert")
    _check_daily_convert(user, book_id)
    out = os.path.join(config.CONVERT_DIR, f"{book_id}.{to}")
    if os.path.exists(out) and os.path.getsize(out) > 0:
        return {"ok": True, "done": True, "fmt": to,
                "size_mb": round(os.path.getsize(out) / 1048576.0, 2),
                "url": f"/api/books/{book_id}/convert/{to}"}
    # 已有同书同格式任务进行中 → 复用
    with _convert_lock:
        for tid, t in _convert_tasks.items():
            if t["book_id"] == book_id and t["fmt"] == to and t["status"] in ("running", "queued"):
                return {"ok": True, "done": False, "task_id": tid, "status": t["status"], "fmt": to}
        # 真正启动新转换：无 convert 权限者用树叶兑换（余额不足直接 403，不产生任务）
        if not has_perm:
            _spend_leaves(user, book_id, "convert", LEAF_COST_CONVERT)
        task_id = uuid.uuid4().hex[:12]
        _convert_tasks[task_id] = {"book_id": book_id, "fmt": to, "status": "running",
                                   "user_id": user["id"], "created_ts": time.time()}
    threading.Thread(target=_run_convert, args=(task_id, book_id, to, user["id"], user["username"]),
                     daemon=True).start()
    return {"ok": True, "done": False, "task_id": task_id, "status": "running", "fmt": to}


@app.get("/api/convert/status/{task_id}")
def convert_status(task_id: str, user=Depends(get_current_user)):
    with _convert_lock:
        t = _convert_tasks.get(task_id)
    if not t:
        raise HTTPException(404, "任务不存在")
    return dict(t)


@app.get("/api/convert/tasks")
def convert_tasks(user=Depends(get_current_user)):
    """当前用户最近的转换任务（清理已完成超 10 分钟的）"""
    with _convert_lock:
        cutoff = time.time() - 600
        for tid in [k for k, v in _convert_tasks.items()
                    if v.get("status") in ("done", "error") and v.get("created_ts", 0) < cutoff]:
            _convert_tasks.pop(tid, None)
        return {"tasks": [{**v, "task_id": k} for k, v in _convert_tasks.items() if v.get("user_id") == user["id"]]}


@app.get("/api/books/{book_id}/convert/{fmt}")
def convert_download(book_id: int, fmt: str, request: Request):
    """下载已转换的文件（需先 POST 转换）；最后一次下载请求 45 秒后自动清理缓存"""
    user = _user_from_download(request, book_id)
    b = _accessible_book_or_404(book_id, user)
    fmt = fmt.lower().lstrip(".")
    if fmt not in reader.CONVERT_FORMATS:
        raise HTTPException(400, "不支持的格式")
    if not auth.can(user, "convert"):
        if not _leaf_spent(user["id"], book_id, "convert"):
            raise HTTPException(403, "需先用树叶兑换本书的转换权限")
    _check_month_download(user, book_id)
    out = os.path.join(config.CONVERT_DIR, f"{book_id}.{fmt}")
    if not os.path.exists(out) or os.path.getsize(out) <= 0:
        raise HTTPException(404, "转换缓存不存在，请先转换")
    base = os.path.splitext(os.path.basename(b["path"]))[0]
    _dl_schedule(book_id, fmt)   # 重置延迟清理定时器（任何响应状态都可靠）
    # ★ 这里原来**完全没有守卫**，浏览器发几次 GET 就记几条。
    #   与普通下载同一套口径：有 ticket 按 ticket 认一次，没有就按短窗认一次。
    _tk = _dl_ticket_of(request)
    _first = (_claim_dl_log(_tk) if _tk
              else _first_hit(("convert", b["id"], fmt, _client_ip(request))))
    if _first:
        db.log_download(user["id"], book_id)
        _audit_download(user, b, _client_ip(request), "convert", fmt)
        try:
            _csz = os.path.getsize(out)
        except OSError:
            _csz = None
        db.log_file(user, "download", f"{base}.{fmt}", size=_csz, source="convert",
                    book_id=b["id"], book_title=b["title"], ip=_client_ip(request), ext=fmt)
    return _file_response(request, out, f"{base}.{fmt}", download=True)


@app.delete("/api/books/{book_id}/convert")
def convert_clean(book_id: int, user=Depends(get_current_user)):
    """清理该书的转换缓存文件"""
    _accessible_book_or_404(book_id, user)
    for fmt in reader.CONVERT_FORMATS:
        _dl_cancel(book_id, fmt)
    reader.clean_convert_cache(book_id)
    return {"ok": True}


@app.post("/api/books/{book_id}/share")
def create_share(book_id: int, password: str = Form(""), expire_days: int = Form(0),
                 download_limit: int = Form(0), online_read: int = Form(1),
                 user=Depends(get_current_user)):
    if not auth.can(user, "share"):
        raise HTTPException(403, "无权限分享，请联系管理员开通分享权限")
    b = _accessible_book_or_404(book_id, user)
    lim = auth.limits_of(user)
    # 分享链接数量上限
    max_links = lim["share_max_links"]
    if max_links > 0 and db.count_active_shares(user["id"]) >= max_links:
        raise HTTPException(400, f"您的分组最多同时创建 {max_links} 个分享链接，请先删除旧链接")
    # 单个分享时限上限（0=不限；超出或永久 → 收敛到上限）
    max_days = lim["share_max_days"]
    if max_days > 0:
        if expire_days <= 0 or expire_days > max_days:
            expire_days = max_days
    token = uuid.uuid4().hex[:16]
    expire = None
    if expire_days and expire_days > 0:
        expire = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time() + expire_days * 86400))
    dl = max(0, download_limit or 0)
    ph = auth.hash_password(password) if password else None
    ol = 1 if str(online_read) in ("1", "true", "True", "on") else 0
    db.ex("INSERT INTO shares (user_id,book_id,token,password_hash,expire_at,download_limit,download_count,online_read,created_at) "
          "VALUES (?,?,?,?,?,?,0,?,?)",
          (user["id"], book_id, token, ph, expire, dl, ol, db.now()))
    db.log_audit(user, "share_create", "book", book_id, f"创建分享《{b['title']}》")
    return {"token": token, "url": f"/s/{token}", "password": bool(password),
            "expire_at": expire, "download_limit": dl, "online_read": bool(ol),
            "group_max_days": max_days}


@app.get("/api/shares")
def my_shares(user=Depends(get_current_user)):
    rows = db.q("""SELECT s.*, b.title, b.author, b.cover FROM shares s JOIN books b ON b.id=s.book_id
                   WHERE s.user_id=? ORDER BY s.created_at DESC""", (user["id"],))
    out = []
    for r in rows:
        d = dict(r)
        d["has_password"] = bool(d["password_hash"])
        d["url"] = f"/s/{d['token']}"
        d["expired"] = bool(d["expire_at"] and d["expire_at"] < db.now())
        d["exhausted"] = bool(d["download_limit"] and (d["download_count"] or 0) >= d["download_limit"])
        out.append(d)
    return out


@app.delete("/api/shares/{token}")
def delete_share(token: str, user=Depends(get_current_user)):
    s = db.q("SELECT * FROM shares WHERE token=?", (token,), one=True)
    if not s or s["user_id"] != user["id"]:
        raise HTTPException(404, "分享不存在")
    db.ex("DELETE FROM shares WHERE token=?", (token,))
    db.log_audit(user, "share_revoke", "share", s["id"], "撤销分享链接")
    return {"ok": True}


def _share_state(s):
    """返回分享状态：ok / expired / exhausted / missing"""
    if not s:
        return "missing"
    if s["expire_at"] and s["expire_at"] < db.now():
        return "expired"
    if s["download_limit"] and (s["download_count"] or 0) >= s["download_limit"]:
        return "exhausted"
    return "ok"


@app.get("/api/share/{token}")
def share_info(token: str):
    s = db.q("""SELECT s.*, b.title, b.author, b.ext, b.id book_id, b.cover FROM shares s
                JOIN books b ON b.id=s.book_id WHERE s.token=?""", (token,), one=True)
    st = _share_state(s)
    if st == "missing":
        raise HTTPException(404, "分享不存在或已删除")
    if st == "expired":
        raise HTTPException(410, "分享已过期")
    if st == "exhausted":
        raise HTTPException(410, "分享下载次数已用完")
    db.ex("UPDATE shares SET access_count=access_count+1 WHERE token=?", (token,))
    return {"title": s["title"], "author": s["author"], "ext": s["ext"],
            "book_id": s["book_id"], "online_read": bool(s["online_read"] or 0),
            # 分享页据此把下载/在线阅读/App 安装包指向后台配置的链路域名
            "link_base": link_base(),
            "has_password": bool(s["password_hash"]), "expire_at": s["expire_at"],
            "download_limit": s["download_limit"], "download_count": s["download_count"],
            "access_count": (s["access_count"] or 0) + 1,
            "cover_url": f"/api/share/{token}/cover" if s["cover"] else None}


@app.get("/api/share/{token}/cover")
def share_cover(token: str):
    s = db.q("SELECT * FROM shares WHERE token=?", (token,), one=True)
    if not s or (s["expire_at"] and s["expire_at"] < db.now()):
        raise HTTPException(410, "分享已过期")
    b = _book_or_404(s["book_id"])
    if not b["cover"]:
        raise HTTPException(404, "无封面")
    path = covers.ensure_cover_local(b["cover"])
    if not path:
        raise HTTPException(404, "封面文件缺失")
    return FileResponse(path, media_type="image/jpeg")


@app.post("/api/share/{token}/verify")
def share_verify(token: str, password: str = Form("")):
    s = db.q("SELECT * FROM shares WHERE token=?", (token,), one=True)
    st = _share_state(s)
    if st == "expired":
        raise HTTPException(410, "分享已过期")
    if st == "exhausted":
        raise HTTPException(410, "分享下载次数已用完")
    if st != "ok":
        raise HTTPException(404, "分享不存在或已删除")
    if s["password_hash"] and not auth.verify_password(password, s["password_hash"]):
        raise HTTPException(403, "密码错误")
    return {"ok": True, "download_url": abs_link(f"/api/share/{token}/download")}


@app.post("/api/share/{token}/read-ticket")
def share_read_ticket(token: str, password: str = Form("")):
    """换取「在线阅读」凭证（§14.113）。

    只要分享没过期、创建时勾了在线阅读、密码正确，就发一张短期券；
    券只能读这一本书，进度/书签/笔记都不会落库（拿券的是游客身份）。
    下载次数用完不影响在线阅读 —— 那是两件事。
    """
    s = db.q("SELECT * FROM shares WHERE token=?", (token,), one=True)
    if not s:
        raise HTTPException(404, "分享不存在或已删除")
    if s["expire_at"] and s["expire_at"] < db.now():
        raise HTTPException(410, "分享已过期")
    if not (s["online_read"] or 0):
        raise HTTPException(403, "该分享未开启在线阅读")
    if s["password_hash"] and not auth.verify_password(password, s["password_hash"]):
        raise HTTPException(403, "密码错误")
    b = _book_or_404(s["book_id"])
    if b["hidden"]:
        raise HTTPException(404, "书籍不存在")
    kind = reader.kind(b)
    if kind not in ("txt", "docx", "md", "epub", "mobi", "pdf", "html"):
        raise HTTPException(400, "该格式暂不支持在线阅读，请下载后阅读")
    return {"ok": True, "book_id": s["book_id"], "title": b["title"], "kind": kind,
            "ticket": auth.create_share_ticket(s["id"], s["book_id"])}


@app.get("/api/share/{token}/download")
def share_download(token: str, request: Request):
    s = db.q("SELECT * FROM shares WHERE token=?", (token,), one=True)
    st = _share_state(s)
    if st == "expired":
        raise HTTPException(410, "分享已过期")
    if st == "exhausted":
        raise HTTPException(410, "分享下载次数已用完")
    if st != "ok":
        raise HTTPException(404, "分享不存在或已删除")
    b = _book_or_404(s["book_id"])
    local = covers.ensure_local(b)
    # ★ 一次下载只算一次。原来无条件 +1：浏览器发两次 GET，分享次数就被扣两次，
    #   分享链接会比设定值更早「已用完」；日志里同样是一模一样的两行。
    if _first_hit(("share", token, _client_ip(request))):
        db.ex("UPDATE shares SET download_count=download_count+1 WHERE token=?", (token,))
        db.log_audit(None, "share_download", "book", b["id"],
                     f"分享链接下载《{b['title']}》token={token[:8]}", _client_ip(request))
        db.log_file(None, "download", os.path.basename(b["path"]), size=b["size"], source="share",
                    book_id=b["id"], book_title=b["title"], ip=_client_ip(request), ext=b["ext"])
    return _file_response(request, local, os.path.basename(b["path"]), download=True)


# ---------- 批量操作 / 去重 / 举报 ----------
@app.post("/api/books/batch")
def batch_books(request: Request, body=Depends(json_body), user=Depends(get_current_user)):
    """批量操作：delete 删除 / move 移动分类 / scrape 刮削封面"""
    action = body.get("action", "")
    # ids 容错：前端一直传数组，但接口不该因为传了 "1,2,3" 这种字符串就 500
    raw = body.get("ids") or []
    if isinstance(raw, str):
        raw = [x for x in re.split(r"[,\s]+", raw.strip()) if x]
    ids = []
    for x in raw:
        try:
            ids.append(int(x))
        except (TypeError, ValueError):
            continue
    if not ids:
        raise HTTPException(400, "未选择书籍")
    if action == "delete":
        if not auth.can(user, "delete"):
            raise HTTPException(403, "无权限删除书籍")
        done = fail = 0
        for bid in ids:
            try:
                b = _accessible_book_or_404(bid, user)
                if not ftp_service.delete(b["path"]):
                    fail += 1; continue
                for t in ("shelves", "progress", "shares", "notes", "book_reports", "share_requests"):
                    db.ex(f"DELETE FROM {t} WHERE book_id=?", (bid,))
                db.ex("DELETE FROM books WHERE id=?", (bid,))
                done += 1
            except Exception:
                fail += 1
        db.log_audit(user, "book_batch_delete", "book", None, f"批量删除 {done} 本")
        return {"done": done, "fail": fail}
    if action == "move":
        if not auth.can(user, "edit"):
            raise HTTPException(403, "无权限编辑书籍")
        cat = (body.get("category") or "").strip()
        if not cat:
            raise HTTPException(400, "请指定目标分类")
        done = fail = 0
        for bid in ids:
            try:
                b = _accessible_book_or_404(bid, user)
                name = os.path.basename(b["path"])
                new_path = cat + "/" + name
                if new_path == b["path"]:
                    done += 1; continue
                if not ftp_service.rename(b["path"], new_path):
                    fail += 1; continue
                db.ex("UPDATE books SET path=?, category=?, updated_at=? WHERE id=?",
                      (new_path, cat, db.now(), bid))
                done += 1
            except Exception:
                fail += 1
        db.log_audit(user, "book_batch_move", "category", None, f"批量移动 {done} 本到 {cat}")
        return {"done": done, "fail": fail}
    if action == "scrape":
        if not auth.can(user, "cover"):
            raise HTTPException(403, "无权限上传封面")
        done = fail = 0
        for bid in ids:
            try:
                b = _accessible_book_or_404(bid, user)
                data = covers.download_online_cover(b["title"], b["author"], b)
                if not data:
                    fail += 1; continue
                fname = covers._save_cover_data(bid, data)
                if not fname:
                    fail += 1; continue
                db.ex("UPDATE books SET cover=?, updated_at=? WHERE id=?", (fname, db.now(), bid))
                done += 1
            except Exception:
                fail += 1
        db.log_audit(user, "book_batch_scrape", "book", None, f"批量刮削封面 {done} 本")
        return {"done": done, "fail": fail}
    raise HTTPException(400, "未知操作")


@app.get("/api/admin/duplicates")
def admin_duplicates(user=Depends(require_admin)):
    """重复书籍检测：按 书名+作者 与 ISBN 分组，返回每组具体书目"""
    groups = []
    for r in db.q("""SELECT title, author, COUNT(*) n, GROUP_CONCAT(id) ids,
                            MAX(size) maxsize, MIN(size) minsize
                     FROM books WHERE title IS NOT NULL AND title != ''
                     GROUP BY title, COALESCE(author,'') HAVING n > 1 ORDER BY n DESC LIMIT 100"""):
        ids = [int(x) for x in r["ids"].split(",")]
        books = [dict(x) for x in db.q(
            f"SELECT id,title,author,size,isbn,category,path,hidden FROM books WHERE id IN ({','.join('?' * len(ids))}) ORDER BY size DESC", ids)]
        for x in books:
            x["size_mb"] = round((x["size"] or 0) / 1048576.0, 2)
        groups.append({"key": f"{r['title']} / {r['author'] or '佚名'}", "kind": "title",
                       "count": r["n"], "ids": ids, "books": books,
                       "size_gap": round((r["maxsize"] or 0) - (r["minsize"] or 0) / 1.0, 2)})
    isbn = db.q("""SELECT isbn, COUNT(*) n, GROUP_CONCAT(id) ids FROM books
                   WHERE isbn IS NOT NULL AND isbn != '' GROUP BY isbn HAVING n > 1 ORDER BY n DESC LIMIT 100""")
    for r in isbn:
        ids = [int(x) for x in r["ids"].split(",")]
        books = [dict(x) for x in db.q(
            f"SELECT id,title,author,size,isbn,category,path,hidden FROM books WHERE id IN ({','.join('?' * len(ids))}) ORDER BY size DESC", ids)]
        for x in books:
            x["size_mb"] = round((x["size"] or 0) / 1048576.0, 2)
        groups.append({"key": f"ISBN {r['isbn']}", "kind": "isbn", "count": r["n"], "ids": ids, "books": books, "size_gap": 0})
    return {"groups": groups}


# ---------- 侵权举报 / 下架 ----------
@app.post("/api/books/{book_id}/report")
def report_book(book_id: int, reason: str = Form(...), detail: str = Form(""),
                user=Depends(get_current_user)):
    _accessible_book_or_404(book_id, user)
    rid = db.add_report(book_id, user["id"], reason, detail)
    db.log_audit(user, "book_report", "book", book_id, f"举报理由：{reason}")
    b = db.q("SELECT title FROM books WHERE id=?", (book_id,), one=True)
    title = b["title"] if b else f"#{book_id}"
    notify.notify_admins("新的举报待处理", f"{_nick(user)} 举报《{title}》：{reason}",
                         kind="report", ref_type="report", ref_id=rid,
                         extra=[("举报人", _nick(user)), ("被举报书籍", title), ("举报理由", reason),
                                ("补充说明", detail)])
    return {"id": rid, "ok": True}


@app.get("/api/admin/reports")
def admin_reports(user=Depends(require_admin)):
    return {"reports": [dict(r) for r in db.list_reports()],
            "pending": db.count_pending_reports()}


@app.post("/api/admin/reports/{rid}/handle")
def admin_report_handle(rid: int, action: str = Form(...), user=Depends(require_admin)):
    """处理举报：dismiss 忽略 / takedown 下架（书籍对普通用户隐藏）"""
    r = db.q("SELECT * FROM book_reports WHERE id=?", (rid,), one=True)
    if not r:
        raise HTTPException(404, "举报不存在")
    if action == "takedown":
        db.ex("UPDATE books SET hidden=1, updated_at=? WHERE id=?", (db.now(), r["book_id"]))
        db.log_audit(user, "book_takedown", "book", r["book_id"], "举报下架")
    db.set_report_status(rid, "handled", user["id"])
    # 通知举报人处理结果
    _b = db.q("SELECT title FROM books WHERE id=?", (r["book_id"],), one=True)
    _t = _b["title"] if _b else f"#{r['book_id']}"
    _res = "已核实并下架处理" if action == "takedown" else "经核实未作下架处理"
    notify.notify_user(r["user_id"], "举报处理结果", f"您举报的《{_t}》{_res}。",
                       kind="report", link="#/me", ref_type="book", ref_id=r["book_id"],
                       extra=[("被举报书籍", _t), ("处理结果", _res)])
    return {"ok": True}


# ---------- 共享申请（私人上传书申请转为公共书） ----------
# 可申请共享的电子书格式：后台「共享审核」里勾选。只限制共享，不限制上传。
SHARE_FORMAT_CHOICES = ("epub", "mobi", "azw3", "azw", "prc", "txt", "pdf",
                        "docx", "doc", "html", "htm", "md", "chm", "djvu", "uvz", "opf")


def share_allowed_formats():
    """允许申请共享的扩展名集合（小写、不带点）。
    从未设置过 → None 表示不限制；设置过但为空 → 空集合表示全都不允许。"""
    raw = db.get_config("share_formats", None)
    if raw is None:
        return None
    return {x.strip().lower().lstrip(".") for x in raw.split(",") if x.strip()}


def _book_ext(b):
    return (b["ext"] or "").lower().lstrip(".")


def share_format_ok(b):
    """该书的格式是否允许申请共享"""
    allow = share_allowed_formats()
    return True if allow is None else _book_ext(b) in allow


# 可被上传的格式全集（共享选项的合法取值上限，跟随上传支持的格式）
def _share_format_universe():
    return {e.lower().lstrip(".") for e in config.BOOK_EXTS if e.strip(".")}


def share_format_choices():
    """后台勾选列表：常用格式 + 书库里实际出现过的其它格式（保证库里有的格式都能勾到）"""
    base = list(SHARE_FORMAT_CHOICES)
    rows = db.q("SELECT DISTINCT LOWER(COALESCE(ext,'')) e FROM books WHERE COALESCE(ext,'')!=''")
    extra = sorted({(r["e"] or "").lstrip(".") for r in rows} - set(base) - {""})
    return base + extra


def share_formats_for_ui():
    """给后台用的列表：未设置过时返回全部（等价于不限制）"""
    choices = share_format_choices()
    allow = share_allowed_formats()
    return choices if allow is None else [x for x in choices if x in allow]


def _share_approve(rid, r, reviewer, auto=False):
    """把一条共享申请「通过」：书籍转为未分类公共书 + 发树叶奖励 + 通知申请人。

    ★ 抽出来的原因：管理员在后台点「通过」，和**免审批身份（管理员/总编）申请即通过**，
      必须走出**完全相同**的结果 —— 尤其是「移入 00_待分类 + owner_id=NULL」这一步，
      它决定这本书谁能看见。另写一份迟早会走偏（一处改了另一处忘改）。
    auto=True 表示申请人自己就是免审批身份，审计日志里标明，便于事后追溯。
    """
    b = _book_or_404(r["book_id"])
    # 转为公共书：移入未分类目录、所有人可见
    new_path = None
    name = os.path.basename(b["path"])
    target = f"00_待分类/{name}"
    if b["path"] != target and not db.q("SELECT id FROM books WHERE path=? AND id!=?", (target, b["id"]), one=True):
        if ftp_service.rename(b["path"], target):
            new_path = target
    db.ex("UPDATE books SET owner_id=NULL, category='00_待分类', hidden=0, path=COALESCE(?,path), updated_at=? WHERE id=?",
          (new_path, db.now(), b["id"]))
    db.set_share_request_status(rid, "approved", reviewer["id"])
    if auto:
        db.log_audit(reviewer, "book_share_approve", "book", b["id"],
                     f"《{b['title']}》免审批直接共享（管理员/总编）→ 未分类公共书")
    else:
        db.log_audit(reviewer, "book_share_approve", "book", b["id"], f"共享审核通过《{b['title']}》→ 未分类公共书")
    # 审核通过发放树叶奖励给共享者（leaf_gain 的 UNIQUE 保证同一本书只发一次）
    got = db.grant_leaves(r["requester_id"], "share_request", db.reward_amount("share_request"),
                          ref_type="book", ref_id=b["id"],
                          note=f"共享《{b['title']}》审核通过")
    if got:
        db.log_audit(reviewer, "leaf_reward", "book", b["id"],
                     f"共享《{b['title']}》通过，奖励 {got} 树叶给 {r['requester_id']} 号用户")
    _msg = f"您申请共享的《{b['title']}》已通过审核，现已转为公共书籍，所有会员均可阅读。"
    _extra = [("申请书籍", b["title"]), ("审核结果", "已通过，转为公共书籍")]
    if got:
        _msg += f"奖励 {got} 片树叶已到账。"
        _extra.append(("树叶奖励", f"+{got}"))
    notify.notify_user(r["requester_id"], "共享审核已通过", _msg,
                       kind="review", link="#/me", ref_type="book", ref_id=b["id"],
                       extra=_extra)
    return b


@app.post("/api/books/{book_id}/share-request")
def share_request(book_id: int, user=Depends(get_current_user)):
    b = _accessible_book_or_404(book_id, user)
    if b["owner_id"] is None:
        raise HTTPException(400, "该书已是公共书籍")
    if b["owner_id"] != user["id"]:
        raise HTTPException(403, "只有上传者本人可以申请共享")
    if not share_format_ok(b):
        _e = _book_ext(b).upper() or "未知"
        raise HTTPException(400, f"「{_e}」格式的电子书暂不支持申请共享（上传不受限制），如需开启请联系管理员")
    if db.pending_share_request(book_id):
        raise HTTPException(400, "已提交过共享申请，请等待管理员审核")
    rid = db.add_share_request(book_id, user["id"])
    db.log_audit(user, "book_share_request", "book", book_id, f"申请共享《{b['title']}》")
    # ★ 管理员与总编（writer 分组）免审批：提交即通过，不再走管理员审核。
    #   万一自动通过失败（比如改名失败），退回普通待审核流程而不是报错 ——
    #   申请本身已经建好了，且会通知管理员人工处理。
    if auth.is_trusted(user):
        try:
            _r = db.q("SELECT * FROM share_requests WHERE id=?", (rid,), one=True)
            _share_approve(rid, _r, user, auto=True)
            return {"id": rid, "ok": True, "status": "approved"}
        except Exception as e:
            db.log_audit(user, "book_share_auto_approve_fail", "book", book_id,
                         f"免审批自动通过失败，转人工：{type(e).__name__}: {e}")
            notify.notify_admins("共享免审批自动通过失败",
                                 f"{_nick(user)} 共享《{b['title']}》时自动通过失败，已转人工审核：{e}",
                                 kind="review", ref_type="share_request", ref_id=rid)
            return {"id": rid, "ok": True, "status": "pending"}
    # 通知管理员（站内消息 + Server酱）
    # ★ 附带「书库中已有同名/相似电子书」备注：管理员据此就能判断这是不是库里已有的书，
    #   不必再自己去搜一遍。相似检索失败绝不能挡住申请流程，所以整段包在 try 里。
    _body = f"{_nick(user)} 申请共享《{b['title']}》，等待审核。"
    _extra = [("申请会员", _nick(user)), ("申请书籍", b["title"])]
    try:
        _sim = similar.find_similar(b["title"], exclude_id=book_id)
        _note = similar.describe(_sim)
        if _note:
            _body += "\n\n" + _note
            _extra.append(("书库已有", similar.brief(_sim)))
    except Exception as e:
        db.log_audit(user, "share_similar_fail", "book", book_id,
                     f"共享申请的同名书检索失败（不影响申请）：{type(e).__name__}: {e}")
    notify.notify_admins("新的共享审核申请", _body,
                         kind="review", ref_type="share_request", ref_id=rid,
                         extra=_extra)
    return {"id": rid, "ok": True, "status": "pending"}


@app.get("/api/admin/share-requests")
def admin_share_requests(page: int = 1, size: int = 15, user=Depends(require_admin)):
    """共享申请列表：按提交时间倒序分页，每页默认 15 条。

    每条附带 `similar`（书库内同名/相似电子书检索结果），后台列表据此显示提示、
    并在有同名书时提供「书库中已存在同名电子书」这个现成的驳回理由。
    """
    d = db.list_share_requests(page=page, size=size or 15)
    for r in d.get("requests") or []:
        try:
            r["similar"] = similar.find_similar(r.get("title"), exclude_id=r.get("book_id"))
        except Exception:
            r["similar"] = None
    return d


@app.post("/api/admin/share-requests/handle")
def admin_share_requests_handle(request: Request, body=Depends(json_body), user=Depends(require_admin)):
    """批量审核共享申请：approve 通过（转为未分类公共书，所有人可见）/ reject 拒绝"""
    ids = [int(x) for x in (body.get("ids") or [])]
    action = body.get("action", "")
    reason = (body.get("reason") or "").strip()
    if len(reason) > 200:
        raise HTTPException(400, "驳回理由过长（最多 200 字）")
    if not ids:
        raise HTTPException(400, "未选择申请")
    if action not in ("approve", "reject"):
        raise HTTPException(400, "操作类型错误")
    done = fail = 0
    errs = []
    for rid in ids:
        try:
            r = db.q("SELECT * FROM share_requests WHERE id=?", (rid,), one=True)
            if not r or r["status"] != "pending":
                fail += 1; continue
            if action == "reject":
                db.set_share_request_status(rid, "rejected", user["id"])
                _bb = db.q("SELECT title FROM books WHERE id=?", (r["book_id"],), one=True)
                _bt = _bb["title"] if _bb else f"#{r['book_id']}"
                # 驳回理由：管理员填写后原文带给申请人（显示在「我的消息」里）
                _rj = f"您申请共享的《{_bt}》未通过审核。"
                _rex = [("申请书籍", _bt), ("审核结果", "未通过")]
                if reason:
                    _rj += f"\n\n驳回理由：{reason}"
                    _rex.append(("驳回理由", reason))
                notify.notify_user(r["requester_id"], "共享审核未通过", _rj,
                                   kind="review", link="#/me", ref_type="book", ref_id=r["book_id"],
                                   extra=_rex)
                if reason:
                    db.log_audit(user, "book_share_review", "share_request", rid,
                                 f"驳回共享申请《{_bt}》，理由：{reason}")
                done += 1; continue
            # 转换逻辑与「免审批身份提交即通过」共用同一个函数，避免两处走偏
            _share_approve(rid, r, user)
            done += 1
        except Exception as e:
            errs.append(f"#{rid}: {type(e).__name__}: {e}")
            fail += 1
    db.log_audit(user, "book_share_review", "share_request", None, f"批量{action}：通过/拒绝 {done} 项，失败 {fail} 项")
    return {"done": done, "fail": fail, "errors": errs}


# ---------- 审计日志（敏感操作留痕） ----------
@app.get("/api/admin/audit")
def admin_audit(action: str = "", user_id: int = 0, q: str = "", page: int = 1, size: int = 50,
                user=Depends(require_admin)):
    return db.list_audit(page=page, size=size, action=action or None, user_id=user_id or None, keyword=q or None)


# ---------- 上传下载日志 ----------
# 谁在什么时候上传/下载了什么文件。★ 带文件扩展名（独立一列，可按类型筛选与统计）。
@app.get("/api/admin/file-logs")
def admin_file_logs(action: str = "", ext: str = "", q: str = "", days: int = 30,
                    page: int = 1, size: int = 50, user=Depends(require_admin)):
    return db.list_file_logs(page=page, size=size, action=action or None,
                             ext=ext or None, keyword=q or None, days=days or 0)


# ---------- 听书日志 / 阅读日志 ----------
# 数据不在库里，而是按天存在 WebDAV：activity/<年>/<YYYY-MM-DD>.json（保留三年）。
# 见 activity.py。kind = listen 听书 / audio 有声 / read 阅读 / all 三类合并。
@app.get("/api/admin/activity")
def admin_activity(kind: str = "all", start: str = "", end: str = "", q: str = "",
                   page: int = 1, size: int = 50, user=Depends(require_admin)):
    """活动流水（听书 / 有声 / 阅读），按时间倒序。start/end 为空表示只看今天。"""
    # kind=all 是后台「听书阅读」合并页用的：听书 + 有声 + 阅读一起返回
    if kind not in activity.KINDS and kind != activity.ALL_KIND:
        raise HTTPException(400, "kind 只能是 read / listen / audio / all")
    return activity.query(kind, start=start or None, end=end or None,
                          keyword=q or None, page=page, size=size)


# ---------- 站内消息（我的消息 / 私信 / 未读红点） ----------
def _nick(u):
    return (u["name"] or u["username"] or "") if u else ""


@app.get("/api/messages")
def messages_list(page: int = Query(1, ge=1), page_size: int = Query(5, ge=1, le=50),
                  scope: str = Query("all"), user=Depends(get_current_user)):
    """我的消息：按时间倒序（由近到远）分页，默认每页 5 条。

    scope=user 只看用户消息（有发送人的私信/分享），scope=system 只看系统消息
    （审核结果、举报处理、群发、欢迎信等）。不传或传其他值 = 全部（行为与以前一致）。
    """
    return db.list_messages(user["id"], page=page, page_size=page_size, scope=scope)


@app.get("/api/messages/unread")
def messages_unread(user=Depends(get_current_user)):
    """未读数（轻量接口，供导航栏红点轮询）"""
    return {"unread": db.count_unread_messages(user["id"])}


@app.get("/api/messages/notify")
def messages_notify(user=Depends(get_current_user)):
    """轻量轮询接口：未读数 + 最新一条未读消息（供 APP 的系统通知/角标用）。

    和 `/unread` 的区别是多了 `max_id` 和 `latest`：
      * `max_id` = 当前**未读**消息里最大的 id，客户端拿它和上次通知过的对比，
        只认「出现了更新的未读」才弹，避免同一条消息反复响。
      * 未读为 0 时 `max_id` 为 0、`latest` 为 null —— 客户端据此撤通知、清角标。

    刻意不复用 `/api/messages`：那个接口一次要联表查整页消息，而这里每分钟
    都可能被后台服务调一次，只需要「有没有新的、最新的长什么样」。
    """
    uid = user["id"]
    unread = db.count_unread_messages(uid)
    max_id = 0
    latest = None
    if unread:
        r = db.q("""SELECT m.id, m.kind, m.title, m.from_id, m.created_at,
                           u.username AS u_name, u.name AS u_real
                    FROM messages m LEFT JOIN users u ON u.id=m.from_id
                    WHERE m.to_id=? AND m.is_read=0
                    ORDER BY m.id DESC LIMIT 1""", (uid,), one=True)
        if r:
            # 口径与消息列表一致：from_name 取真名/用户名，无发送人就是「系统」
            fn = (r["u_real"] or r["u_name"]) if r["from_id"] is not None else "系统"
            max_id = r["id"]
            latest = {"id": r["id"], "kind": r["kind"], "title": r["title"] or "",
                      "from_name": fn or "已注销", "created_at": r["created_at"]}
    return {"unread": unread, "max_id": max_id, "latest": latest}


@app.post("/api/messages/read")
def messages_read(request: Request, body=Depends(json_body_or_empty), user=Depends(get_current_user)):
    """标记已读：不传 ids 表示全部已读，传 ids 表示标记指定几条"""
    ids = body.get("ids") if isinstance(body, dict) else None
    return {"unread": db.mark_messages_read(user["id"], ids)}


@app.post("/api/messages")
def message_send(request: Request, body=Depends(json_body_or_empty), user=Depends(get_current_user)):
    """会员与管理员互发私信 / 回复：以「昵称」作为接收标识"""
    content = (body.get("content") or "").strip()
    reply_to = body.get("reply_to")
    if not content:
        raise HTTPException(400, "消息内容不能为空")
    if len(content) > 1000:
        raise HTTPException(400, "消息内容过长（最多 1000 字）")
    # ---------- 群发：仅管理员可用，一次发给全部启用中的会员 ----------
    if body.get("broadcast"):
        if user["role"] != "admin":
            raise HTTPException(403, "只有管理员可以群发消息")
        if reply_to:
            raise HTTPException(400, "回复不能群发")
        ids = [r["id"] for r in db.q(
            "SELECT id FROM users WHERE enabled=1 AND id!=? ORDER BY id", (user["id"],))]
        if not ids:
            raise HTTPException(400, "当前没有可接收的会员")
        # ★ 群发按「系统消息」投递：from_id 留空、kind=system、标题不带管理员昵称。
        #   收件人看到的是「系统消息」，而不是「来自 示例」——群发是站方通知，
        #   不该在会员收件箱里暴露是哪个管理员发的；谁发的记在审计日志里。
        for uid in ids:
            db.add_message(uid, "群发消息", content, kind="system")
        # 管理员自己留一条回执（同样按系统消息记，避免出现在「用户消息」筛选里）
        db.add_message(user["id"], f"已群发给全部会员（{len(ids)} 人）", content,
                       kind="system", is_read=1)
        db.log_audit(user, "message_broadcast", "user", None,
                     f"由 {_nick(user)} 群发站内消息给全部会员（{len(ids)} 人）")
        return {"ok": True, "count": len(ids), "message": f"已群发给全部会员（{len(ids)} 人）"}
    target = None
    replied = None
    if reply_to:
        replied = db.q("SELECT * FROM messages WHERE id=? AND to_id=?", (int(reply_to), user["id"]), one=True)
        if not replied:
            raise HTTPException(404, "要回复的消息不存在")
        target = db.q("SELECT * FROM users WHERE id=?", (replied["from_id"],), one=True) if replied["from_id"] else None
        if not target:
            raise HTTPException(400, "该消息来自系统，无法回复")
    if not target:
        to = (body.get("to") or "").strip()
        if not to:
            raise HTTPException(400, "请输入接收人昵称")
        target = db.find_user_by_nickname(to)
        if not target:
            raise HTTPException(404, f"没有找到昵称为「{to}」的用户")
    if not target["enabled"]:
        raise HTTPException(400, "对方账号已被禁用")
    if target["id"] == user["id"]:
        raise HTTPException(400, "不能给自己发消息")
    my_nick, to_nick = _nick(user), _nick(target)
    if replied:
        title = f"来自 {my_nick} 的回复"
        # 回复方也留一条记录，便于在「我的消息」里看到自己发出的内容
        db.add_message(target["id"], title, content, kind="pm", from_id=user["id"],
                       ref_type="message", ref_id=replied["id"])
    else:
        title = f"来自 {my_nick} 的私信"
        db.add_message(target["id"], title, content, kind="pm", from_id=user["id"])
    db.add_message(user["id"], f"已发送给 {to_nick}", content, kind="pm_sent",
                   from_id=target["id"], is_read=1)
    db.log_audit(user, "message_send", "user", target["id"], f"发送站内消息给 {to_nick}")
    return {"ok": True, "to": to_nick, "message": f"已发送给 {to_nick}"}


# ---------- 分组兑换（用树叶按月兑换更高权限分组） ----------
# 需求约定：有效期固定按 1 个月计算
GROUP_EXCHANGE_MONTHS = 1


def _upgrade_info(u):
    """当前生效中的兑换信息（含剩余天数），无则返回 None"""
    up = db.active_upgrade(u["id"])
    if not up:
        return None
    g = db.get_group(up["to_group_id"])
    left = 0
    try:
        from datetime import datetime as _dt, timezone as _tz, timedelta as _td
        exp = _dt.strptime(up["expires_at"], "%Y-%m-%d %H:%M:%S")
        now_bj = _dt.now(_tz.utc).replace(tzinfo=None) + _td(hours=8)   # 同为 naive，避免 aware/naive 相减报错
        secs = (exp - now_bj).total_seconds()
        left = max(0, -(-int(secs) // 86400))   # 向上取整：刚兑换的 1 个月显示 30 天
    except Exception:
        left = 0
    return {"id": up["id"], "group_id": up["to_group_id"],
            "group_name": g["name"] if g else "未知分组",
            "cost": up["cost"], "months": up["months"],
            "started_at": up["started_at"], "expires_at": up["expires_at"],
            "days_left": left}


@app.get("/api/group-exchange")
def group_exchange_info(user=Depends(get_current_user)):
    """可兑换的分组列表 + 我的树叶余额 + 当前兑换状态

    options 内附带该分组的完整权限位与限额（直接取后台分组设置，不写死），
    供前端「升级权限」弹窗逐项展示。
    """
    db.expire_group_upgrades()
    bal = _leaf_balance(user["id"])
    me = auth.group_of(user)
    opts = []
    for g in db.exchange_options():
        opts.append({"id": g["id"], "name": g["name"], "cost": g["exchange_cost"],
                     "months": GROUP_EXCHANGE_MONTHS,
                     "affordable": bal >= g["exchange_cost"],
                     "current": bool(me and me["id"] == g["id"]),
                     "perms": {p: int(bool(g["can_" + p])) for p in db.GROUP_PERMS},
                     "limits": {k: int(g[k] or 0) for k in db.GROUP_LIMITS}})
    return {"balance": bal, "months": GROUP_EXCHANGE_MONTHS,
            "options": opts, "upgrade": _upgrade_info(user),
            "my_perms": {p: int(bool(me and me["can_" + p])) for p in db.GROUP_PERMS}}


@app.post("/api/group-exchange")
def group_exchange(request: Request, body=Depends(json_body_or_empty), user=Depends(get_current_user)):
    """用树叶兑换分组权限（有效期 1 个月，到期自动回退）"""
    db.expire_group_upgrades()
    gid = body.get("group_id")
    if not gid:
        raise HTTPException(400, "请选择要兑换的分组")
    g = db.get_group(int(gid))
    if not g:
        raise HTTPException(404, "分组不存在")
    cost = int(g["exchange_cost"] or 0)
    if cost <= 0:
        raise HTTPException(400, "该分组不可兑换")
    me = auth.group_of(user)
    up = db.active_upgrade(user["id"])
    renew = bool(up and up["to_group_id"] == g["id"])   # 同一分组的续期
    if me and me["id"] == g["id"] and not renew:
        # 已是该分组（且不是自己兑换来的续期）→ 无需兑换
        raise HTTPException(400, f"您当前已是「{g['name']}」")
    if g["code"] == "admin":
        raise HTTPException(400, "管理员分组不可兑换")
    bal = _leaf_balance(user["id"])
    if bal < cost:
        raise HTTPException(400, f"树叶不足：需要 {cost}，当前 {bal}")
    months = GROUP_EXCHANGE_MONTHS
    if renew:
        # 同一分组续期：从原到期时间往后延 1 个月（叠加）
        base = None
        try:
            from datetime import datetime as _dt
            base = _dt.strptime(up["expires_at"], "%Y-%m-%d %H:%M:%S")
        except Exception:
            base = None
        expires = db.bj_add_months(months, base)
        db.update_upgrade(up["id"], g["id"], cost, expires)
        action = "续期"
    elif up:
        # 切换到另一个分组：保留原始回退分组，重新计时
        expires = db.bj_add_months(months)
        db.update_upgrade(up["id"], g["id"], cost, expires)
        action = "更换"
    else:
        from_group = me["id"] if me else None
        expires = db.bj_add_months(months)
        db.add_upgrade(user["id"], from_group, g["id"], cost, months, expires)
        action = "兑换"
    # 扣树叶 + 切分组 + 同步配额
    db.ex("UPDATE user_leaves SET balance=balance-?, updated_at=? WHERE user_id=?",
          (cost, db.now(), user["id"]))
    db.ex("UPDATE users SET group_id=?, quota=?, role=? WHERE id=?",
          (g["id"], db.quota_from_group(g), "admin" if g["code"] == "admin" else "user", user["id"]))
    db.log_audit(user, "group_exchange", "group", g["id"],
                 f"{action}分组「{g['name']}」消耗 {cost} 树叶，有效期至 {expires}")
    left = _leaf_balance(user["id"])
    notify.notify_user(user["id"], "权限升级成功",
                       f"您已{action}「{g['name']}」，本次消耗 {cost} 树叶，有效期至 {expires}（共 {months} 个月）。",
                       kind="system", link="#/me", ref_type="group", ref_id=g["id"],
                       extra=[("分组", g["name"]), ("消耗树叶", cost), ("到期时间", expires)])
    return {"ok": True, "balance": left, "expires_at": expires, "months": months,
            "group_name": g["name"], "action": action,
            "message": f"{action}成功：已升级为「{g['name']}」，有效期至 {expires}"}


# ---------- 笔记（正文存 WebDAV，索引存 SQLite） ----------
def _notes_relpath(user, book_id):
    return f"用户笔记/{user['username']}/{book_id}.json"


@app.get("/api/notes")
def notes_list(user=Depends(get_current_user)):
    return {"items": [dict(r) for r in db.list_notes(user["id"])]}


@app.get("/api/notes/{book_id}")
def notes_get(book_id: int, user=Depends(get_current_user)):
    rel = _notes_relpath(user, book_id)
    try:
        raw = ftp_service.read_bytes(rel)
        return json.loads(raw.decode("utf-8"))
    except Exception:
        return {"highlights": [], "notes": [], "bookmarks": [], "searches": []}


@app.put("/api/notes/{book_id}")
def notes_save(book_id: int, request: Request, body=Depends(json_body), user=Depends(get_current_user)):
    _accessible_book_or_404(book_id, user)
    data = json.dumps(body, ensure_ascii=False).encode("utf-8")
    ftp_service.write_bytes(_notes_relpath(user, book_id), data)
    db.note_touch(user["id"], book_id)
    return {"ok": True}


@app.delete("/api/notes/{book_id}")
def notes_clear(book_id: int, user=Depends(get_current_user)):
    ftp_service.delete(_notes_relpath(user, book_id))
    db.remove_note_index(user["id"], book_id)
    return {"ok": True}


@app.post("/api/notes/batch-delete")
def notes_batch_delete(request: Request, body=Depends(json_body), user=Depends(get_current_user)):
    """批量删除多本书的笔记（划线/批注/书签/搜索记录）"""
    ids = [int(x) for x in (body.get("ids") or [])]
    done = 0
    for bid in ids:
        ftp_service.delete(_notes_relpath(user, bid))
        db.remove_note_index(user["id"], bid)
        done += 1
    return {"done": done}


# ---------- 广告栏 ----------
@app.get("/api/ads")
def get_ads():
    return {"ad1": db.get_config("ad1_html", ""), "ad2": db.get_config("ad2_html", "")}


# ---------- 功能介绍（未登录首页「查看全部功能介绍」页面内容，管理员可在后台编辑） ----------
DEFAULT_INTRO = """<div class="intro-wrap">
  <p class="muted" style="margin:0 0 20px;font-size:14px">本站是一套私人藏书阅读工具，海量书库、云端同步、自由分享、支持全格式阅览和转换。</p>
  <div class="card">
    <h3 style="margin:0 0 10px">查找与阅读</h3>
    <ul class="intro-ul">
      <li>公共书库按中图分类号整理，可按分类浏览，也可按书名、作者、出版社、ISBN 搜索。</li>
      <li>打开图书进入内置阅读器，进度自动保存，下次打开接着读。</li>
      <li>阅读时选中文字可以划线、写批注，工具栏可加书签；书签和划线都记录位置，随时能跳回去。</li>
      <li>阅读器内支持按关键词搜索全书内容。</li>
      <li>针对 kindle 浏览器做适配优化，可流畅使用 kindle 网页版。</li>
    </ul>
  </div>
  <div class="card">
    <h3 style="margin:0 0 10px">书架与历史</h3>
    <ul class="intro-ul">
      <li>看到想读的书，点「加入书架」收藏，可自建分类整理，分类支持拖拽排序。</li>
      <li>「我的阅读」按时间倒序记录最近读过的书，分页查看。</li>
    </ul>
  </div>
  <div class="card">
    <h3 style="margin:0 0 10px">上传与导入</h3>
    <ul class="intro-ul">
      <li>会员可上传本地电子书到私人书库（epub、mobi、azw、azw3、txt 等），上传后自动加入书架。</li>
      <li>也可从 FTP 书库挑选文件，导入到自己的私人书架。</li>
    </ul>
  </div>
  <div class="card">
    <h3 style="margin:0 0 10px">下载与格式转换</h3>
    <ul class="intro-ul">
      <li>有下载权限的会员可把书下载到手机或电脑，txt 下载会自动注入水印。</li>
      <li>支持 mobi、azw、azw3、epub、txt 之间的全格式转换，转换完成后自动开始下载。</li>
    </ul>
  </div>
  <div class="card">
    <h3 style="margin:0 0 10px">分享与推送</h3>
    <ul class="intro-ul">
      <li>对外分享：可生成分享链接发给他人，链接支持设置访问密码、有效期、下载次数上限。</li>
      <li>站内共享：私人藏书可提交共享申请，管理员审核通过后转为公共书籍供所有会员阅读，共享者同时可获得树叶奖励。</li>
      <li>站内推送：可把个人书架中的藏书推送给站内会员，输入对方账号（用户名、ID 或昵称）即可，对方书架会自动出现「来自分享」分组。</li>
    </ul>
  </div>
  <div class="card">
    <h3 style="margin:0 0 10px">书单与笔记</h3>
    <ul class="intro-ul">
      <li>划线、批注、书签统一归入「笔记」，支持批量导出、批量删除。</li>
      <li>会员可发表文章，用「书单 / 讨论 / 分享」三种标签分类，正文支持插图。</li>
      <li>文章可回复交流，管理员可置顶重要内容，支持按标签和关键词筛选。</li>
      <li>发表的「书单」和「分享」文章经管理员审核通过后，作者可获得树叶奖励，两种标签的奖励数量各自单独设置；「讨论」不参与奖励。</li>
    </ul>
  </div>
  <div class="card">
    <h3 style="margin:0 0 10px">站内消息</h3>
    <ul class="intro-ul">
      <li>「我的」页面顶部的「我的消息」收所有通知，底部导航「我的」上有未读红点提示。</li>
      <li>共享审核、书单审核、回复审查、举报处理的结果，都会自动发消息通知本人。</li>
      <li>有人把藏书分享或推送给您、您的书单收到新回复时，同样会收到提醒。</li>
      <li>可与管理员互相发私信：点「发消息」输入对方昵称即可，对方回复会自动回到同一条消息下。</li>
      <li>管理员发消息时可勾选「群发」，把同一内容一次发给全部会员（发送前会二次确认，发出后无法撤回）。</li>
      <li>消息列表只显示主题和摘要，点开任意一条查看完整内容；历史消息按时间倒序分页保留，不会因为看过就消失。</li>
    </ul>
  </div>
  <div class="card">
    <h3 style="margin:0 0 10px">树叶与权限升级</h3>
    <ul class="intro-ul">
      <li>每日签到得 1 片树叶，每连续签到 7 天额外奖励 7 片。</li>
      <li>共享电子书通过审核、发表书单文章通过审核，都会按管理员设置的数量发放树叶奖励。</li>
      <li>树叶既可用于下载、格式转换等操作，也可用来兑换更高的权限分组。</li>
      <li>在「我的」→「我的权限」右上角点「升级权限」，可用树叶兑换「小编 / 主编 / 总编」分组。</li>
      <li>兑换的分组有效期按月计算（1 个月），到期自动回退到原分组；到期前再次兑换即为续期。</li>
      <li>弹窗里会列出每个分组的权限明细、使用限额和所需树叶数，兑换价格由管理员在后台分组管理中设置。</li>
    </ul>
  </div>
  <div class="card">
    <h3 style="margin:0 0 10px">账号与安全</h3>
    <ul class="intro-ul">
      <li>注册时填写昵称、邮箱和手机号；昵称是站内展示名，注册后不可修改。</li>
      <li>邮箱和手机号用于找回密码时的身份核验，请如实填写。</li>
      <li>登录后在「我的」页面可自行修改密码。</li>
      <li>支持安装手机 App，在「我的」页面可检查并安装新版本。</li>
    </ul>
  </div>
  <div class="card">
    <h3 style="margin:0 0 10px">举报与后台管理</h3>
    <ul class="intro-ul">
      <li>发现内容问题可提交举报，管理员在后台处理，处理结果通过站内消息告知举报人。</li>
      <li>管理员可在后台管理书籍、用户、分组权限与站点配置。</li>
      <li>后台的共享审核、书单审核列表均按提交时间倒序分页展示，每页 15 条。</li>
    </ul>
  </div>
</div>"""


@app.get("/api/intro")
def get_intro():
    return {"content": db.get_config("intro_html", "") or DEFAULT_INTRO}


# ---------- 下载 / 在线阅读链路域名（§14.114） ----------
# 为什么要这个：站点既能从反向代理域名（reader.example.com）访问，也能从服务器直达域名
# （localhost:9000）访问。前者多绕一层反代，下载和在线阅读明显更慢。
# 所以「分享链接、分享页的下载/在线阅读/App 安装包、网页端下载 App」这些**我们生成的
# 绝对地址**不再跟着访客的访问域名走，统一用后台这个变量拼；留空才回退成相对路径。
DEFAULT_LINK_BASE = os.environ.get("BOOKMGR_LINK_BASE", "")


def link_base():
    """后台配置的对外链路域名，统一成「协议://主机[:端口]/」形式；空字符串 = 跟随访问域名"""
    v = (db.get_config("link_base", DEFAULT_LINK_BASE) or "").strip()
    if not v:
        return ""
    if not re.match(r"^https?://", v, re.I):
        v = "https://" + v
    return v.rstrip("/") + "/"


def abs_link(path):
    """站内路径 → 对外绝对地址；没配域名就原样返回相对路径"""
    b = link_base()
    if not b:
        return path
    return b + str(path or "").lstrip("/")


@app.get("/api/site")
def site_config():
    """站点公开配置"""
    return {"app_name": "云阅读", "link_base": link_base()}


# ---------- 后台管理 ----------
@app.get("/api/admin/stats")
def admin_stats(user=Depends(require_admin)):
    books = db.q("SELECT COUNT(*) n, SUM(size) sz FROM books", one=True)
    users = db.q("SELECT COUNT(*) n FROM users", one=True)["n"]
    shelves = db.q("SELECT COUNT(*) n FROM shelves", one=True)["n"]
    shares = db.q("SELECT COUNT(*) n FROM shares", one=True)["n"]
    progress = db.q("SELECT COUNT(*) n FROM progress", one=True)["n"]
    cat = db.q("SELECT category, COUNT(*) n FROM books GROUP BY category ORDER BY n DESC")
    return {"books": books["n"], "books_size": books["sz"], "users": users,
            "shelves": shelves, "shares": shares, "progress": progress,
            "categories": [{"name": r["category"], "count": r["n"]} for r in cat]}


@app.get("/api/admin/site-stats")
def admin_site_stats(days: str = Query(str(stats.SITE_DEFAULT_DAYS)), user=Depends(require_admin)):
    """网站统计：图表/概览卡/每日明细共用同一个时间窗口（days 天），一律按天聚合。

    days 只接受 1/7/15/30/90。这里故意收 str 而不是 int：FastAPI 的 int 转换
    遇到非法值会直接 422，而统计页宁可退化成默认 7 天也不要弹报错。
    收敛逻辑见 stats.norm_site_days()。
    不再按小时：一整天切成 24 小时视图看下来只有几十根柱子，横向也没有可比性。
    """
    return stats.site_report(days)


@app.get("/api/admin/site-stats/flush")
def admin_site_stats_flush(user=Depends(require_admin)):
    """立刻把内存里的统计落盘到 WebDAV（排查用）"""
    n = stats.flush(force_db_snapshot=True)
    return {"ok": True, "saved": n, **stats.overview()}


@app.post("/api/admin/books/guest-feature")
def admin_guest_feature(payload: dict = Body(default={}), user=Depends(require_admin)):
    """批量设置/取消访客推荐书籍（未登录首页展示，可阅读/下载）

    ★ 同一个标记同时管两个地方：未登录访客的首页，以及登录用户首页的「🔥 热度推荐」板块。
      所以有声电子书页面上的「加入首页热度推荐」也是打这个标记（见 ablib_api 的 guest_featured）。
    """
    ids = (payload or {}).get("book_ids") or []
    featured = int((payload or {}).get("featured", 1))
    if not isinstance(ids, list) or not ids:
        raise HTTPException(400, "未选择书籍")
    ids = [int(i) for i in ids if str(i).isdigit()]
    if not ids:
        raise HTTPException(400, "未选择有效书籍")
    qs = ",".join("?" for _ in ids)
    if featured:
        # 首页「热度推荐」是 `ORDER BY books.updated_at DESC LIMIT 6`，而 6 个位置经常是满的。
        # 如果不动 updated_at，管理员刚加的那本很可能排在第 7 位、首页压根看不到 ——
        # 「明明加了却没出现」是必然会被当成 bug 的。所以设为推荐时顺手把它顶到最前。
        # books.updated_at 除了这一处排序，只被前端当封面缓存戳用（见 coverUrl），
        # 顶一次最坏就是封面重新取一遍，没有别的副作用。
        db.ex(f"UPDATE books SET guest_featured=1, updated_at=? WHERE id IN ({qs})",
              [db.now()] + ids)
    else:
        db.ex(f"UPDATE books SET guest_featured=0 WHERE id IN ({qs})", ids)
    db.log_audit(user, "guest_feature", "book", None, f"{'设置' if featured else '取消'}访客推荐 {len(ids)} 本")
    return {"ok": True, "featured": featured, "count": len(ids)}


@app.post("/api/admin/sync")
def admin_sync(user=Depends(require_admin)):
    """立即同步 FTP 书库（增量：新增/删除/大小更新）"""
    db.log_audit(user, "admin_sync", "system", None, "触发 FTP 书库同步")
    return sync.sync_once()


@app.get("/api/admin/sync/status")
def admin_sync_status(user=Depends(require_admin)):
    return sync.last_result()


@app.post("/api/admin/xunlei-import")
def admin_xunlei_import(payload: dict = Body(default={}), user=Depends(require_admin)):
    """后台扫描指定源目录（绝对路径）并按分类入库（文件名相同自动跳过）"""
    base = (payload or {}).get("base") if isinstance(payload, dict) else None
    db.log_audit(user, "xunlei_import", "system", None, f"迅雷导入源目录 {base or ''}")
    return import_xunlei.start_import(base)


@app.get("/api/admin/xunlei-import/status")
def admin_xunlei_import_status(user=Depends(require_admin)):
    return import_xunlei.xunlei_status()


@app.get("/api/admin/xunlei-import/log")
def admin_xunlei_import_log(user=Depends(require_admin)):
    """分类入库任务日志（每分类移动数/去重明细/未移动清单等）"""
    return {"logs": import_xunlei.get_log()}


# ---------- 文件去重（size 分组 + 全文件 MD5，仅系统书） ----------
@app.post("/api/admin/dedup/scan")
def admin_dedup_scan(user=Depends(require_admin)):
    db.log_audit(user, "dedup_scan", "system", None, "触发文件去重扫描")
    return dedup.start_scan()


@app.get("/api/admin/dedup/status")
def admin_dedup_status(user=Depends(require_admin)):
    return dedup.status()


@app.get("/api/admin/dedup/report")
def admin_dedup_report(user=Depends(require_admin)):
    return dedup.report()


@app.post("/api/admin/dedup/delete")
def admin_dedup_delete(payload: dict = Body(default={}), user=Depends(require_admin)):
    ids = (payload or {}).get("ids") if isinstance(payload, dict) else None
    if not isinstance(ids, list):
        raise HTTPException(400, "缺少 ids 列表")
    db.log_audit(user, "dedup_delete", "book", None, f"去重删除 {len(ids)} 本")
    return dedup.confirm_delete(ids)


# ---------- 批量补录元数据 ----------
_enrich_state = {"running": False, "result": None, "lock": threading.Lock()}


def _run_enrich(limit):
    with _enrich_state["lock"]:
        if _enrich_state["running"]:
            return
        _enrich_state["running"] = True
    done = fail = skipped = 0
    total = 0
    try:
        # 优先处理缺作者的书
        rows = db.q("SELECT * FROM books WHERE author IS NULL OR author='' ORDER BY id LIMIT ?",
                    (max(1, min(200, limit)),))
        total = len(rows)
        for b in rows:
            try:
                title, author = covers.enrich_metadata(b)
                if not title:
                    skipped += 1
                    continue
                title = title or b["title"]
                author = author or ""
                new_name = covers.normalize_filename(title, author, b["ext"] or "")
                new_path = _ftp_parent(b) + "/" + new_name
                if db.q("SELECT id FROM books WHERE path=? AND id!=?", (new_path, b["id"]), one=True):
                    new_name = covers.normalize_filename(title, author, "") + f"({b['id']})" + (b["ext"] or "")
                    new_path = _ftp_parent(b) + "/" + new_name
                if new_path != b["path"]:
                    if not ftp_service.rename(b["path"], new_path):
                        fail += 1
                        continue
                    db.ex("UPDATE books SET path=? WHERE id=?", (new_path, b["id"]))
                db.ex("UPDATE books SET title=?, author=?, updated_at=? WHERE id=?", (title, author, db.now(), b["id"]))
                done += 1
            except Exception:
                fail += 1
        _enrich_state["result"] = {"done": done, "fail": fail, "skipped": skipped,
                                   "total_scanned": total, "finished_at": db.now()}
    finally:
        with _enrich_state["lock"]:
            _enrich_state["running"] = False


@app.post("/api/admin/enrich")
def admin_enrich(limit: int = 50, user=Depends(require_admin)):
    """批量补录元数据并自动重命名（后台执行，优先缺作者的书）"""
    if _enrich_state["running"]:
        raise HTTPException(409, "正在补录中，请稍候")
    db.log_audit(user, "admin_enrich", "book", None, f"批量补录元数据（limit={limit}）")
    threading.Thread(target=_run_enrich, args=(limit,), daemon=True).start()
    return {"started": True}


@app.get("/api/admin/enrich/status")
def admin_enrich_status(user=Depends(require_admin)):
    return {"running": _enrich_state["running"], "result": _enrich_state["result"]}


# ---------- 系统配置（注册审核 / 消息推送） ----------
@app.get("/api/admin/config")
def admin_get_config(user=Depends(require_admin)):
    return {"registration_review": db.get_config("registration_review", "0"),
            "invite_register": db.get_config("invite_register", "0"),
            "serverchan_enabled": notify.serverchan_enabled(),
            "serverchan_key": notify.serverchan_key(),
            "reward_booklist": db.reward_amount("booklist"),
            "reward_share_article": db.reward_amount("share_article"),
            "reward_share_request": db.reward_amount("share_request"),
            # 可申请共享的电子书格式（只限制共享，不限制上传）
            "share_formats": share_formats_for_ui(),
            "share_format_choices": share_format_choices(),
            "share_format_limited": share_allowed_formats() is not None,
            # 友情链接（书单页右侧栏「浏览排行」下面那一块，最多 5 条）
            "links": booklists.site_links(),
            # 下载/在线阅读链路域名（空 = 跟随访客访问域名）
            "link_base": link_base(),
            # 听书设置（api_key 原样返回给管理员，便于核对）
            "tts": tts.settings()}


@app.post("/api/admin/config")
def admin_set_config(request: Request, body=Depends(json_body), user=Depends(require_admin)):
    if "registration_review" in body:
        val = "1" if str(body["registration_review"]) in ("1", "true", "on", "yes", "True") else "0"
        db.set_config("registration_review", val)
        db.log_audit(user, "admin_config", "system", None, f"注册审核 {'开启' if val == '1' else '关闭'}")
    if "invite_register" in body:
        val = "1" if str(body["invite_register"]) in ("1", "true", "on", "yes", "True") else "0"
        db.set_config("invite_register", val)
        db.log_audit(user, "admin_config", "system", None,
                     "邀请注册 " + ("开启（注册必须填邀请码）" if val == "1" else "关闭（邀请码可选）"))
    if "serverchan_enabled" in body:
        val = "1" if str(body["serverchan_enabled"]) in ("1", "true", "on", "yes", "True") else "0"
        db.set_config("serverchan_enabled", val)
        db.log_audit(user, "admin_config", "system", None, f"Server酱推送 {'开启' if val == '1' else '关闭'}")
    if "serverchan_key" in body:
        db.set_config("serverchan_key", str(body["serverchan_key"]).strip())
        db.log_audit(user, "admin_config", "system", None, "更新 Server酱 Key")
    # 树叶奖励数量（0 = 不发放）
    for key, label in (("reward_booklist", "「书单」文章通过"),
                       ("reward_share_article", "「分享」文章通过"),
                       ("reward_share_request", "电子书共享通过")):
        if key in body:
            try:
                val = max(0, int(str(body[key]).strip() or 0))
            except (TypeError, ValueError):
                raise HTTPException(400, "奖励数量需为 0 或正整数")
            if val > 100000:
                raise HTTPException(400, "奖励数量过大")
            db.set_config(key, val)
            db.log_audit(user, "admin_config", "system", None, f"{label}奖励设为 {val} 树叶")
    # 可申请共享的电子书格式：勾选哪些就只有哪些能申请共享（全不勾 = 都不允许）
    if "share_formats" in body:
        raw = body["share_formats"]
        if isinstance(raw, str):
            items = [x.strip().lower().lstrip(".") for x in raw.split(",")]
        else:
            items = [str(x).strip().lower().lstrip(".") for x in (raw or [])]
        items = [x for x in items if x]
        universe = _share_format_universe()
        bad = [x for x in items if x not in universe]
        if bad:
            raise HTTPException(400, "不支持的格式：" + "、".join(bad))
        seen, uniq = set(), []
        for x in items:
            if x not in seen:
                seen.add(x); uniq.append(x)
        db.set_config("share_formats", ",".join(uniq))
        db.log_audit(user, "admin_config", "system", None,
                     "可申请共享的格式设为：" + ("、".join(uniq) if uniq else "（全部不允许共享）"))
    # 下载/在线阅读链路域名：分享链接、下载、在线阅读、App 安装包都用它拼绝对地址
    if "link_base" in body:
        raw = str(body["link_base"] or "").strip()
        if len(raw) > 200:
            raise HTTPException(400, "域名地址过长")
        if raw:
            if not re.match(r"^https?://", raw, re.I):
                raise HTTPException(400, "域名要写成 https://主机[:端口]/ 的形式")
            if re.search(r"\s", raw):
                raise HTTPException(400, "域名里不能有空格")
        db.set_config("link_base", raw)
        db.log_audit(user, "admin_config", "system", None,
                     "下载/阅读链路域名设为 " + (raw or "（跟随访客访问域名）"))
    # 友情链接：书单页右侧栏「浏览排行」下面那一块（最多 5 条，地址限 http/https）
    if "links" in body:
        before = booklists.site_links()
        saved = booklists.site_links_save(body["links"])
        if saved != before:
            names = "、".join([(x["name"] or x["url"]) for x in saved]) or "（清空）"
            db.log_audit(user, "admin_config", "system", None,
                         "友情链接设为 %d 条：%s" % (len(saved), names))
    # 听书设置：主机地址/API Key/模型/默认音色/音色白名单/树叶价格/超时
    if "tts" in body and isinstance(body["tts"], dict):
        cur = tts.settings()
        new = tts.set_settings(body["tts"])
        changed = [k for k in new if str(new[k]) != str(cur.get(k))]
        if changed:
            labels = {"enabled": "开关", "base_url": "服务地址", "api_key": "API Key",
                      "model": "模型", "default_voice": "默认音色", "voices": "音色白名单",
                      "listen_cost": "树叶价格", "timeout": "超时", "emotion_vector": "情绪向量",
                      "emo_alpha": "情绪强度"}
            db.log_audit(user, "admin_config", "system", None,
                         "听书设置更新：" + "、".join(labels.get(k, k) for k in changed))
    return {"registration_review": db.get_config("registration_review", "0"),
            "invite_register": db.get_config("invite_register", "0"),
            "serverchan_enabled": notify.serverchan_enabled(),
            "serverchan_key": notify.serverchan_key(),
            "reward_booklist": db.reward_amount("booklist"),
            "reward_share_article": db.reward_amount("share_article"),
            "reward_share_request": db.reward_amount("share_request"),
            "share_formats": share_formats_for_ui(),
            "share_format_choices": share_format_choices(),
            "share_format_limited": share_allowed_formats() is not None,
            "link_base": link_base(),
            # 听书设置（api_key 原样返回给管理员，便于核对）
            "tts": tts.settings()}


@app.post("/api/admin/serverchan/test")
def admin_serverchan_test(user=Depends(require_admin)):
    """发送一条测试推送，便于确认 Server酱 Key 是否可用"""
    r = notify.push_now("【云阅读】推送测试",
                        f"这是一条测试消息，收到即表示 Server酱配置正常。\n\n操作人：{_nick(user)}")
    db.log_audit(user, "serverchan_test", "system", None, f"测试推送：{'成功' if r.get('ok') else r.get('error')}")
    return r


# ---------- 广告栏设置 ----------
@app.get("/api/admin/ads")
def admin_get_ads(user=Depends(require_admin)):
    return {"ad1": db.get_config("ad1_html", ""), "ad2": db.get_config("ad2_html", "")}


@app.put("/api/admin/ads")
def admin_set_ads(request: Request, body=Depends(json_body), user=Depends(require_admin)):
    db.set_config("ad1_html", body.get("ad1", ""))
    db.set_config("ad2_html", body.get("ad2", ""))
    db.log_audit(user, "admin_ads", "system", None, "修改广告设置")
    return {"ok": True}


# ---------- 新注册欢迎消息（后台可编辑） ----------
WELCOME_TITLE = "欢迎使用「云阅读」"
# 正文是纯文字，不用任何链接语法；「使用介绍」四个字在阅读时自动变成指向下面地址的链接
DEFAULT_WELCOME_MSG = (
    "欢迎使用“云阅读”，努力做一个纯粹的阅读APP，无广告，零收费；"
    "请查看使用介绍，以获得更好的阅读体验。"
    "本站地址：https://localhost:9000/ （kindle浏览器可用）。"
)
# 「使用介绍」点开后打开的页面
DEFAULT_WELCOME_LINK = os.environ.get("BOOKMGR_WELCOME_LINK", "")
# 正文里会被链接化的字词
WELCOME_LINK_TEXT = "使用介绍"


def _http_url(u):
    """只接受 http/https 链接，其它一律当空处理"""
    u = (u or "").strip()
    return u if re.match(r"^https?://", u, re.I) else ""


def welcome_message():
    """欢迎消息正文：后台配置优先，未配置时用内置默认文案"""
    txt = db.get_config("welcome_msg", "")
    return txt if (txt or "").strip() else DEFAULT_WELCOME_MSG


def welcome_link():
    """「使用介绍」的跳转地址"""
    return _http_url(db.get_config("welcome_link", "")) or DEFAULT_WELCOME_LINK


def send_welcome(uid):
    """给新注册用户发一条欢迎消息；开关关闭或正文为空时不发"""
    if db.get_config("welcome_enabled", "1") != "1":
        return 0
    body = welcome_message().strip()
    if not body or not uid:
        return 0
    db.add_message(uid, WELCOME_TITLE, body, kind="system", ref_type="welcome",
                   link=welcome_link())
    return 1


@app.get("/api/admin/welcome")
def admin_get_welcome(user=Depends(require_admin)):
    return {"enabled": db.get_config("welcome_enabled", "1") == "1",
            "content": welcome_message(),
            "link": welcome_link(),
            "link_text": WELCOME_LINK_TEXT,
            "title": WELCOME_TITLE,
            "is_default": not (db.get_config("welcome_msg", "") or "").strip(),
            "default_content": DEFAULT_WELCOME_MSG}


@app.put("/api/admin/welcome")
def admin_set_welcome(request: Request, body=Depends(json_body), user=Depends(require_admin)):
    content = str(body.get("content", "") or "")
    if len(content) > 2000:
        raise HTTPException(400, "消息内容过长（最多 2000 字）")
    db.set_config("welcome_msg", content)
    if "link" in body:
        link = str(body.get("link", "") or "").strip()
        if link and not _http_url(link):
            raise HTTPException(400, "链接地址需要以 http:// 或 https:// 开头")
        db.set_config("welcome_link", link)
    if "enabled" in body:
        db.set_config("welcome_enabled",
                      "1" if str(body["enabled"]) in ("1", "true", "on", "yes", "True") else "0")
    db.log_audit(user, "admin_welcome", "system", None,
                 f"修改新注册欢迎消息（{'开启' if db.get_config('welcome_enabled', '1') == '1' else '关闭'}）")
    return {"ok": True, "enabled": db.get_config("welcome_enabled", "1") == "1",
            "content": welcome_message(), "link": welcome_link()}


# ---------- 功能介绍内容编辑（仅管理员） ----------
@app.get("/api/admin/intro")
def admin_get_intro(user=Depends(require_admin)):
    return {"content": db.get_config("intro_html", "") or DEFAULT_INTRO}


@app.put("/api/admin/intro")
def admin_set_intro(request: Request, body=Depends(json_body), user=Depends(require_admin)):
    db.set_config("intro_html", body.get("content", ""))
    db.log_audit(user, "admin_intro", "system", None, "修改功能介绍页内容")
    return {"ok": True}


# ---------- 封面刮削接入资源管理 ----------
def _seed_cover_sources():
    # ★「电子书内图片」预置排在最后：它是**本地兜底** —— 只有在线源都没结果时才用，
    #   而且用它得先把电子书文件拉到本地（可能要从 NAS 下载），放最后最省钱。
    #   站长想优先用它，在后台点 ↑ 挪到第一位即可。
    defaults = [
        ("豆瓣读书", "douban", 1),
        ("必应图片", "bing", 2),
        ("Google Books", "google", 3),
        ("Open Library", "openlibrary", 4),
        ("电子书内图片", "ebook", 5),
    ]
    for name, stype, sort in defaults:
        if not db.q("SELECT id FROM cover_sources WHERE type=?", (stype,), one=True):
            db.ex("INSERT INTO cover_sources (name,type,enabled,sort_order) VALUES (?,?,1,?)", (name, stype, sort))


@app.get("/api/admin/sources")
def admin_sources(user=Depends(require_admin)):
    _seed_cover_sources()
    rows = db.q("SELECT * FROM cover_sources ORDER BY sort_order, id")
    return [dict(r) for r in rows]


@app.post("/api/admin/sources")
def admin_source_create(name: str = Form(...), stype: str = Form(...),
                        enabled: int = Form(1), sort_order: int = Form(0), user=Depends(require_admin)):
    sid = db.ex("INSERT INTO cover_sources (name,type,enabled,sort_order) VALUES (?,?,?,?)",
                (name, stype, enabled, sort_order))
    db.log_audit(user, "source_create", "cover_source", sid, f"新增封面刮削资源 {name}")
    return {"id": sid, "ok": True}


@app.put("/api/admin/sources/{sid}")
def admin_source_update(sid: int, name: str = Form(None), stype: str = Form(None),
                        enabled: int = Form(None), sort_order: int = Form(None),
                        user=Depends(require_admin)):
    s = db.q("SELECT * FROM cover_sources WHERE id=?", (sid,), one=True)
    if not s:
        raise HTTPException(404, "资源不存在")
    sets, args = [], []
    if name is not None:
        sets.append("name=?"); args.append(name)
    if stype is not None:
        sets.append("type=?"); args.append(stype)
    if enabled is not None:
        sets.append("enabled=?"); args.append(enabled)
    if sort_order is not None:
        sets.append("sort_order=?"); args.append(sort_order)
    if sets:
        args.append(sid)
        db.ex(f"UPDATE cover_sources SET {','.join(sets)} WHERE id=?", args)
    db.log_audit(user, "source_update", "cover_source", sid, f"修改封面刮削资源 {name or s['name']}")
    return {"ok": True}


@app.delete("/api/admin/sources/{sid}")
def admin_source_delete(sid: int, user=Depends(require_admin)):
    db.ex("DELETE FROM cover_sources WHERE id=?", (sid,))
    db.log_audit(user, "source_delete", "cover_source", sid, f"删除封面刮削资源 #{sid}")
    return {"ok": True}


@app.get("/api/admin/users")
def admin_users(group_id: int = Query(None), user=Depends(require_admin)):
    where, args = [], []
    if group_id is not None:
        where.append("u.group_id = ?")
        args.append(group_id)
    cond = (" WHERE " + " AND ".join(where)) if where else ""
    rows = db.q(f"""SELECT u.id, u.username, u.role, u.quota, u.enabled, u.created_at, u.last_login,
                   u.group_id, u.name, u.email, u.phone,
                   g.name AS group_name, g.code AS group_code, g.shelf_limit,
                   (SELECT COUNT(*) FROM shelves s WHERE s.user_id=u.id) shelf_count,
                   COALESCE(rt.total_seconds, 0) AS reading_seconds,
                   COALESCE(ul.balance, 0) AS leaves
                   FROM users u LEFT JOIN user_groups g ON g.id=u.group_id
                   LEFT JOIN reading_time rt ON rt.user_id=u.id
                   LEFT JOIN user_leaves ul ON ul.user_id=u.id
                   {cond} ORDER BY u.created_at DESC, u.id DESC""", args)
    return [dict(r) for r in rows]


@app.get("/api/admin/users/{uid}/shelf")
def admin_user_shelf(uid: int, user=Depends(require_admin)):
    """某个用户的书架收藏明细（后台「用户管理」点收藏数字弹窗用）。

    只读，不改任何状态；按加入时间从晚到早排列，和用户自己看到的书架顺序一致。
    """
    u = db.q("SELECT id, username, name FROM users WHERE id=?", (uid,), one=True)
    if not u:
        raise HTTPException(404, "用户不存在")
    rows = db.q("""SELECT b.id, b.title, b.author, b.category, b.cover, b.updated_at,
                          s.added_at, c.name AS collection_name
                   FROM shelves s JOIN books b ON b.id = s.book_id
                   LEFT JOIN shelf_collections c ON c.id = s.collection_id
                   WHERE s.user_id=? ORDER BY s.added_at DESC, b.id DESC""", (uid,))
    items = [{"id": r["id"], "title": r["title"], "author": r["author"] or "",
              "category": r["category"] or "",
              "cover_url": f"/api/books/{r['id']}/cover" if r["cover"] else None,
              "collection_name": r["collection_name"] or "", "added_at": r["added_at"]}
             for r in rows]
    return {"user_id": uid, "username": u["username"], "name": u["name"] or "",
            "count": len(items), "items": items}


@app.post("/api/admin/users")
def admin_create_user(username: str = Form(...), password: str = Form(...),
                      name: str = Form(""), email: str = Form(""), phone: str = Form(""),
                      group_id: int = Form(None),
                      user=Depends(require_admin)):
    if db.q("SELECT id FROM users WHERE username=?", (username,), one=True):
        raise HTTPException(400, "用户名已存在")
    name = (name or "").strip()
    if name and db.nickname_taken(name):
        raise HTTPException(400, "该昵称已被使用，请换一个")
    g = db.get_group(group_id) if group_id else db.group_by_code("guest")
    if not g:
        raise HTTPException(400, "分组不存在")
    uid = db.ex("INSERT INTO users (username,password_hash,role,quota,enabled,group_id,name,email,phone,created_at) "
                "VALUES (?,?,?,?,?,?,?,?,?,?)",
                (username, auth.hash_password(password), "admin" if g["code"] == "admin" else "user",
                 db.quota_from_group(g), 1, g["id"], name, email, phone, db.now()))
    db.log_audit(user, "user_create", "user", uid, f"后台创建用户 {username}")
    return {"id": uid, "ok": True}


@app.put("/api/admin/users/{uid}")
def admin_update_user(uid: int, group_id: int = Form(None), quota: int = Form(None),
                      enabled: int = Form(None), password: str = Form(None),
                      name: str = Form(None), email: str = Form(None), phone: str = Form(None),
                      leaves: int = Form(None), user=Depends(require_admin)):
    u = db.q("SELECT * FROM users WHERE id=?", (uid,), one=True)
    if not u:
        raise HTTPException(404, "用户不存在")
    sets, args = [], []
    if group_id is not None:
        g = db.get_group(group_id)
        if not g:
            raise HTTPException(400, "分组不存在")
        sets.append("group_id=?"); args.append(g["id"])
        sets.append("role=?"); args.append("admin" if g["code"] == "admin" else "user")
        sets.append("quota=?"); args.append(db.quota_from_group(g))   # 配额随分组书架上限同步
    elif quota is not None:
        sets.append("quota=?"); args.append(quota)
    if enabled is not None:
        sets.append("enabled=?"); args.append(enabled)
    if password:
        sets.append("password_hash=?"); args.append(auth.hash_password(password))
    if name is not None:
        name = name.strip()
        if name and name != (u["name"] or "") and db.nickname_taken(name, uid):
            raise HTTPException(400, "该昵称已被使用，请换一个")
        sets.append("name=?"); args.append(name)
    if email is not None:
        sets.append("email=?"); args.append(email)
    if phone is not None:
        sets.append("phone=?"); args.append(phone)
    if sets:
        args.append(uid)
        db.ex(f"UPDATE users SET {','.join(sets)} WHERE id=?", args)
    # 账号被管理员启用 → 邀请此时才算数，补发推广奖励（待审期间不发）
    if enabled == 1 and not u["enabled"]:
        try:
            promote.grant_reward(uid)
        except Exception:
            logging.getLogger("bookmgr").exception("推广奖励发放失败 uid=%s", uid)
    if leaves is not None:
        # 直接设定树叶余额（管理员手工调整），0 也可设为 0
        db.ex("INSERT INTO user_leaves (user_id, balance, updated_at) VALUES (?,?,?) "
              "ON CONFLICT(user_id) DO UPDATE SET balance=excluded.balance, updated_at=excluded.updated_at",
              (uid, max(0, int(leaves)), db.now()))
    db.log_audit(user, "user_update", "user", uid,
                 f"修改用户 {u['username']}" + (f"（树叶设为 {leaves}）" if leaves is not None else ""))
    return {"ok": True}


# 删除用户时要一并清掉的「用户自己的数据」：表名 → 归属列。
# 注意 book_grants 的归属列是 from_user_id / to_user_id、messages 是 to_id / from_id，
# 都不是 user_id，必须单独处理 —— 当成 user_id 写会直接抛 no such column 变成 500。
_USER_OWN_TABLES = (
    ("shelves", "user_id"), ("shelf_collections", "user_id"), ("progress", "user_id"),
    ("settings", "user_id"), ("notes", "user_id"), ("shares", "user_id"),
    ("download_logs", "user_id"), ("reading_time", "user_id"), ("convert_logs", "user_id"),
    ("user_leaves", "user_id"), ("leaf_gain", "user_id"), ("leaf_spend", "user_id"),
    ("signin_log", "user_id"), ("group_upgrades", "user_id"),
    ("share_requests", "requester_id"),
)


def purge_user_data(uid):
    """删掉该用户自己的数据。

    整个清理 + 删人走同一个事务：任何一步失败都回滚，绝不留下删一半的半残账号。
    保留：books（上传的书，别人可能还在读）、booklists / booklist_comments（已发表内容，
    列表用 LEFT JOIN，作者没了显示为空）、book_reports（对书的举报记录）、
    audit_logs（审计留痕，删了就查不到是谁删的）。
    """
    c = db.get_conn()
    if c.in_transaction:
        c.commit()
    try:
        c.execute("BEGIN")
        for t, col in _USER_OWN_TABLES:
            c.execute(f"DELETE FROM {t} WHERE {col}=?", (uid,))
        c.execute("DELETE FROM book_grants WHERE from_user_id=? OR to_user_id=?", (uid, uid))
        c.execute("DELETE FROM messages WHERE to_id=? OR from_id=?", (uid, uid))
        c.execute("DELETE FROM users WHERE id=?", (uid,))
        c.commit()
    except Exception:
        c.rollback()
        raise


@app.delete("/api/admin/users/{uid}")
def admin_delete_user(uid: int, user=Depends(require_admin)):
    if uid == user["id"]:
        raise HTTPException(400, "不能删除自己")
    du = db.q("SELECT username FROM users WHERE id=?", (uid,), one=True)
    if not du:
        raise HTTPException(404, "用户不存在")
    purge_user_data(uid)
    db.log_audit(user, "user_delete", "user", uid, f"删除用户 {du['username']}")
    return {"ok": True}


@app.post("/api/admin/users/batch")
def admin_users_batch(request: Request, body=Depends(json_body), user=Depends(require_admin)):
    """批量管理用户：delete 删除 / enable 启用 / disable 停用"""
    action = str(body.get("action") or "")
    ids = body.get("user_ids") or []
    if not isinstance(ids, list) or not ids:
        raise HTTPException(400, "未选择用户")
    ids = [int(i) for i in ids if str(i).isdigit()]
    if not ids:
        raise HTTPException(400, "未选择有效用户")
    if action == "delete":
        if user["id"] in ids:
            ids.remove(user["id"])
        if not ids:
            raise HTTPException(400, "不能删除自己")
        for uid in ids:
            purge_user_data(uid)
    elif action in ("enable", "disable"):
        val = 1 if action == "enable" else 0
        qs = ",".join("?" for _ in ids)
        # 只给「原本没启用」的那些补发，避免重复启用时反复触发
        fresh = [r["id"] for r in db.q(
            f"SELECT id FROM users WHERE enabled=0 AND id IN ({qs})", ids)]
        db.ex(f"UPDATE users SET enabled=? WHERE id IN ({qs})", [val] + ids)
        if val == 1:
            for uid in fresh:
                try:
                    promote.grant_reward(uid)
                except Exception:
                    logging.getLogger("bookmgr").exception("推广奖励发放失败 uid=%s", uid)
    else:
        raise HTTPException(400, "未知操作")
    db.log_audit(user, "user_batch", "user", None, f"批量{action}用户 {len(ids)} 个")
    return {"ok": True, "count": len(ids)}


# ---------------------------------------------------------------- 听书管理
# 试听默认文本：挑一句有起伏的，能听出音色的性格差异（纯平铺的句子听不出好坏）
PREVIEW_TEXT = "月色洒在青石板上，远处传来更夫的梆子声，一声，又一声。"

# 「听书管理」标签页用的接口：每条线路的音色与分组权限。
# 音色信息 = 各台服务器 /voices（事实） + listen_admin 的覆盖（策略）。

@app.get("/api/admin/listen/lines")
def admin_listen_lines(user=Depends(require_admin)):
    """所有线路 + 各自音色 + 分组权限。管理页主数据。"""
    cfg = tts.settings()
    lines = listen_admin.voices_for_lines(cfg, force=False)
    groups = [dict(r) for r in db.q("SELECT id, code, name, sort_order FROM user_groups ORDER BY sort_order, id")]
    return {"lines": lines, "groups": groups,
            "enabled": bool(cfg.get("enabled")), "cost": cfg.get("cost"),
            "timeout": cfg.get("timeout"), "model": cfg.get("model"),
            "default_voice": cfg.get("default_voice")}


def _listen_line_srv(url):
    """按 url 找回服务器配置（听书管理所有写操作都要先过这一关）"""
    cfg = tts.settings()
    for srv in tts.active_servers(cfg):
        if srv.get("url") == url:
            return srv, cfg
    raise HTTPException(404, "线路不存在或已停用：" + str(url))


@app.post("/api/admin/listen/groups")
def admin_listen_groups(body=Depends(json_body), user=Depends(require_admin)):
    """设置某条线路允许使用的分组。空数组 = 所有分组都能用。"""
    url = (body.get("url") or "").strip()
    srv, cfg = _listen_line_srv(url)
    ids = body.get("groups") or []
    if not isinstance(ids, (list, tuple)):
        raise HTTPException(400, "groups 必须是数组")
    valid = {r["id"] for r in db.q("SELECT id FROM user_groups")}
    bad = [x for x in ids if int(x) not in valid]
    if bad:
        raise HTTPException(400, "分组不存在：" + "、".join(str(x) for x in bad))
    listen_admin.set_groups(url, ids)
    names = [r["name"] for r in db.q("SELECT name FROM user_groups WHERE id IN (%s)"
             % ",".join("?" * len(ids)), tuple(int(x) for x in ids))] if ids else []
    db.log_audit(user, "admin_listen", "line", None,
                 "线路「%s」分组权限设为：%s" % (srv.get("name") or url, "、".join(names) if names else "所有分组"))
    return {"ok": True, "groups": sorted({int(x) for x in ids})}


@app.post("/api/admin/listen/voice/rename")
def admin_listen_voice_rename(body=Depends(json_body), user=Depends(require_admin)):
    url = (body.get("url") or "").strip()
    vid = (body.get("id") or "").strip()
    name = (body.get("name") or "").strip()
    srv, cfg = _listen_line_srv(url)
    if not vid:
        raise HTTPException(400, "缺少音色 id")
    if len(name) > 24:
        raise HTTPException(400, "音色名最长 24 个字")
    listen_admin.rename(url, vid, name)
    db.log_audit(user, "admin_listen", "voice", vid,
                 "音色重命名：%s → %s（线路 %s）" % (vid, name or "（恢复原名）", srv.get("name") or url))
    return {"ok": True}


@app.post("/api/admin/listen/voice/toggle")
def admin_listen_voice_toggle(body=Depends(json_body), user=Depends(require_admin)):
    """启用/停用某个音色。停用后客户端选音色列表里不再出现，但仍可直接播放。"""
    url = (body.get("url") or "").strip()
    vid = (body.get("id") or "").strip()
    srv, cfg = _listen_line_srv(url)
    on = 1 if str(body.get("on")) in ("1", "true", "True", "on") else 0
    listen_admin.set_on(url, vid, on)
    db.log_audit(user, "admin_listen", "voice", vid,
                 "音色%s：%s（线路 %s）" % ("启用" if on else "停用", vid, srv.get("name") or url))
    return {"ok": True, "on": on}


@app.post("/api/admin/listen/voice/delete")
def admin_listen_voice_delete(body=Depends(json_body), user=Depends(require_admin)):
    """删除音色。

    · 定制音色（我们上传的样板）→ 让 TTS 主机真的删掉文件
    · 内置音色 → 只在站点侧隐藏（机器上的文件不动，随时能恢复）
    """
    url = (body.get("url") or "").strip()
    vid = (body.get("id") or "").strip()
    srv, cfg = _listen_line_srv(url)
    if not vid:
        raise HTTPException(400, "缺少音色 id")
    c = listen_admin.line_cfg(listen_admin.load(), url)
    is_custom = bool((c["voices"].get(vid) or {}).get("custom")) \
        or any(v.get("id") == vid and v.get("source") == "custom"
               for v in tts.voices_of_server(srv, cfg, wait=False) if isinstance(v, dict))
    if is_custom:
        if not listen_admin.supports_custom(srv):
            raise HTTPException(400, "该线路不支持定制音色")
        ok = tts.host_voice_delete(srv, vid)
        if not ok:
            raise HTTPException(502, "TTS 主机删除失败（该音色可能已不存在）")
        listen_admin.forget(url, vid)
        how = "已从 TTS 主机删除"
    else:
        listen_admin.hide(url, vid)
        how = "已在站点隐藏（机器上的文件保留）"
    db.log_audit(user, "admin_listen", "voice", vid,
                 "删除音色：%s（线路 %s，%s）" % (vid, srv.get("name") or url, how))
    return {"ok": True, "custom": 1 if is_custom else 0, "how": how}


@app.post("/api/admin/listen/voice/preview")
def admin_listen_voice_preview(body=Depends(json_body), user=Depends(require_admin)):
    """试听某个音色：现场合成一小段，直接回 Opus 给浏览器播。"""
    url = (body.get("url") or "").strip()
    vid = (body.get("id") or "").strip()
    text = (body.get("text") or "").strip() or PREVIEW_TEXT
    srv, cfg = _listen_line_srv(url)
    if not vid:
        raise HTTPException(400, "缺少音色 id")
    if len(text) > 60:
        text = text[:60]
    try:
        data, gen = tts._call_one(srv, text, vid, cfg, max(60, int(cfg.get("timeout") or 120)))
    except tts.TTSError as e:
        raise HTTPException(502, "试听失败：" + str(e))
    return Response(content=data, media_type="audio/ogg", headers={
        "X-Gen-Seconds": str(gen if gen is not None else ""),
        "X-Voice": quote(vid),
        "Cache-Control": "no-store",
    })


@app.post("/api/admin/listen/voice/upload")
async def admin_listen_voice_upload(url: str = Form(...), name: str = Form(""), text: str = Form(""),
                                    file: UploadFile = File(...),
                                    user=Depends(require_admin)):
    """上传样板声音，在 TTS 主机上定制一个新音色。

    样板 = 一段干净的朗读音频（建议 5~15 秒、单人、无背景音）。
    零样本克隆的模型把这**段音频本身**当作音色，所以换一段样板就是一个新音色。
    GPT-SoVITS 还需要「样板里念的那句话」，带上它合成更快也更准。
    """
    srv, cfg = _listen_line_srv((url or "").strip())
    if not listen_admin.supports_custom(srv):
        raise HTTPException(400, "这条线路的音色是固定预训练的（piper），不支持上传样板定制")
    raw = await file.read()
    if not raw:
        raise HTTPException(400, "样板文件为空")
    if len(raw) > 12 * 1024 * 1024:
        raise HTTPException(400, "样板文件过大（上限 12 MB）")
    fn = (file.filename or "").lower()
    if not fn.endswith((".wav", ".mp3", ".m4a", ".ogg", ".flac")):
        raise HTTPException(400, "只支持 wav / mp3 / m4a / ogg / flac")
    if listen_admin.needs_transcript(srv) and not (text or "").strip():
        raise HTTPException(400, "这条线路是 GPT-SoVITS，需要填「样板里念的那句话」")
    if len((text or "").strip()) > 200:
        raise HTTPException(400, "样板文本过长（≤200 字）")
    vid, err = tts.host_voice_upload(srv, raw, file.filename or "sample.wav",
                                     (name or "").strip(), (text or "").strip())
    if err:
        raise HTTPException(502, "TTS 主机定制失败：" + err)
    listen_admin.remember_custom(srv["url"], vid, (name or "").strip(), (text or "").strip())
    db.log_audit(user, "admin_listen", "voice", vid,
                 "定制新音色：%s（线路 %s，样板 %s，%d 字节）"
                 % (name or vid, srv.get("name") or url, file.filename, len(raw)))
    return {"ok": True, "id": vid, "name": (name or "").strip() or vid}


@app.get("/api/admin/tts/test")
def admin_tts_test(user=Depends(require_admin)):
    """听书连通性测试：探测 TTS 服务状态并回报可用音色，供后台「测试连接」用"""
    cfg = tts.settings()
    servers = tts.health_all(cfg)                 # 逐台探测一次
    h = tts.health(cfg, allh=servers)             # 复用探测结果，不再探第二遍
    ok = any(x["ok"] for x in servers if x["enabled"])
    voices = tts.allowed_voices(cfg, force=True) if ok else []
    return {"ok": ok, "base_url": cfg["base_url"], "model": cfg["model"],
            "enabled": cfg["enabled"], "health": h, "servers": servers,
            "voice_count": len(voices),
            "voice_sample": [{"id": v["id"], "label": v.get("label") or v["id"],
                              "gender": v.get("gender") or ""} for v in voices[:16]],
            "queue": tts.queue_stats(), "cache": tts.cache_stats()}


@app.get("/api/admin/groups")
def admin_groups(user=Depends(require_admin)):
    rows = db.list_groups()
    out = []
    for r in rows:
        d = dict(r)
        d["members"] = db.q("SELECT COUNT(*) n FROM users WHERE group_id=?", (r["id"],), one=True)["n"]
        out.append(d)
    return out


@app.post("/api/admin/groups")
def admin_create_group(name: str = Form(...), sort_order: int = Form(0),
                       can_share: int = Form(0), can_edit: int = Form(0), can_cover: int = Form(0),
                       can_download: int = Form(0), can_delete: int = Form(0),
                       can_private_shelf: int = Form(0), can_convert: int = Form(0),
                       can_listen: int = Form(0),
                       can_public_library: int = Form(0), can_publish_booklist: int = Form(0),
                       can_promote: int = Form(0), can_invite: int = Form(0),
                       promote_reward: int = Form(0), invite_reward: int = Form(0),
                       share_max_days: int = Form(0), share_max_links: int = Form(0),
                       download_monthly_limit: int = Form(0), shelf_limit: int = Form(0),
                       listen_monthly_limit: int = Form(0),
                       convert_daily_limit: int = Form(0), upload_max_mb: int = Form(0),
                       exchange_cost: int = Form(0),
                       user=Depends(require_admin)):
    if not name.strip():
        raise HTTPException(400, "分组名称不能为空")
    gid = db.add_group(name.strip(), can={
        "share": can_share, "edit": can_edit, "cover": can_cover, "download": can_download,
        "delete": can_delete, "private_shelf": can_private_shelf, "convert": can_convert,
        "listen": can_listen,
        "public_library": can_public_library, "publish_booklist": can_publish_booklist,
        "promote": can_promote, "invite": can_invite},
        limits={"promote_reward": promote_reward, "invite_reward": invite_reward,
                "share_max_days": share_max_days, "share_max_links": share_max_links,
                "download_monthly_limit": download_monthly_limit, "shelf_limit": shelf_limit,
                "listen_monthly_limit": listen_monthly_limit,
                "convert_daily_limit": convert_daily_limit,
                "upload_max_mb": upload_max_mb, "exchange_cost": exchange_cost},
        sort_order=sort_order)
    db.log_audit(user, "group_create", "group", gid, f"新建分组 {name.strip()}")
    return {"id": gid, "ok": True}


@app.put("/api/admin/groups/{gid}")
def admin_update_group(gid: int, name: str = Form(None), sort_order: int = Form(None),
                       can_share: int = Form(None), can_edit: int = Form(None), can_cover: int = Form(None),
                       can_download: int = Form(None), can_delete: int = Form(None),
                       can_private_shelf: int = Form(None), can_convert: int = Form(None),
                       can_listen: int = Form(None),
                       can_public_library: int = Form(None), can_publish_booklist: int = Form(None),
                       can_promote: int = Form(None), can_invite: int = Form(None),
                       promote_reward: int = Form(None), invite_reward: int = Form(None),
                       share_max_days: int = Form(None), share_max_links: int = Form(None),
                       download_monthly_limit: int = Form(None), shelf_limit: int = Form(None),
                       listen_monthly_limit: int = Form(None),
                       convert_daily_limit: int = Form(None), upload_max_mb: int = Form(None),
                       exchange_cost: int = Form(None),
                       user=Depends(require_admin)):
    g = db.get_group(gid)
    if not g:
        raise HTTPException(404, "分组不存在")
    can = {k: v for k, v in {
        "share": can_share, "edit": can_edit, "cover": can_cover, "download": can_download,
        "delete": can_delete, "private_shelf": can_private_shelf, "convert": can_convert,
        "listen": can_listen,
        "public_library": can_public_library, "publish_booklist": can_publish_booklist,
        "promote": can_promote, "invite": can_invite}.items()
        if v is not None}
    limits = {k: v for k, v in {"share_max_days": share_max_days, "share_max_links": share_max_links,
                                "download_monthly_limit": download_monthly_limit,
                                "shelf_limit": shelf_limit,
                                "listen_monthly_limit": listen_monthly_limit,
                                "convert_daily_limit": convert_daily_limit,
                                "upload_max_mb": upload_max_mb}.items() if v is not None}
    db.update_group(gid, name=name, can=can, limits=limits, sort_order=sort_order,
                    exchange_cost=exchange_cost, promote_reward=promote_reward,
                    invite_reward=invite_reward)
    # 分组书架上限变化 → 同步成员配额
    if "shelf_limit" in limits:
        db.ex("UPDATE users SET quota=? WHERE group_id=?",
              (db.quota_from_group({**g, "shelf_limit": shelf_limit}), gid))
    db.log_audit(user, "group_update", "group", gid, f"修改分组 {g['name']}")
    return {"ok": True}


@app.delete("/api/admin/groups/{gid}")
def admin_delete_group(gid: int, user=Depends(require_admin)):
    g = db.get_group(gid)
    if not g:
        raise HTTPException(404, "分组不存在")
    if g["is_system"]:
        raise HTTPException(400, "系统分组不可删除")
    n = db.q("SELECT COUNT(*) n FROM users WHERE group_id=?", (gid,), one=True)["n"]
    if n:
        raise HTTPException(400, f"该分组还有 {n} 名用户，请先调整其分组再删除")
    db.delete_group(gid)
    db.log_audit(user, "group_delete", "group", gid, f"删除分组 {g['name']}")
    return {"ok": True}


# ---------- 用户须知与免责公告 ----------
DEFAULT_TERMS = (
    "《用户须知与免责公告》\n\n"
    "欢迎注册使用本站（以下简称“本平台”）。在注册并使用本平台提供的图书分享、在线阅读等服务前，请仔细阅读并充分理解以下内容。您勾选“我已阅读并同意”并完成注册，即视为您已阅读、理解并同意本须知的全部条款。\n\n"
    "一、平台性质\n"
    "本平台为面向注册用户的自建图书资料分享与在线阅读系统，仅用于学习、研究、交流等非商业目的。平台不向公众提供任何收费下载服务，不存储、不传播任何违法违规内容。\n\n"
    "二、账号与注册信息\n"
    "1. 注册时请如实填写昵称、邮箱、手机号等信息；昵称用于站内展示与消息接收，手机号与邮箱用于账号找回密码等身份核验。\n"
    "2. 请妥善保管账号密码，因您本人保管不善导致的账号被盗用、信息泄露等后果，由您自行承担。\n"
    "3. 如发现账号异常，请及时联系管理员处理。\n\n"
    "三、内容与版权责任\n"
    "1. 本平台内图书资源来源于系统管理员导入的公开资料及用户自行上传的内容。\n"
    "2. 用户上传任何图书资源前，应确保其拥有合法权利或已获得权利人授权，并保证所上传内容不侵犯任何第三方的著作权、商标权、名誉权等合法权益。因用户上传、分享内容引发的任何法律纠纷及后果，由该上传用户自行承担全部责任，与本平台无关。\n"
    "3. 用户通过本平台获得的图书资源，仅限于个人学习、研究使用，严禁用于任何商业用途、二次传播或大规模扩散。\n\n"
    "四、使用规范\n"
    "用户不得利用本平台从事任何违反法律法规的活动，包括但不限于：传播色情、暴力、恐怖、侵权盗版等内容；利用技术手段攻击、干扰平台运行；恶意批量下载或窃取数据等。\n\n"
    "五、侵权投诉与下架\n"
    "本平台尊重知识产权。如您认为平台内任何内容侵犯了您的合法权益，请提供权属证明、侵权内容链接及您的联系方式，联系平台管理员。经核实后，平台将在合理期限内删除或断开相关链接。\n\n"
    "六、免责声明\n"
    "1. 本平台提供的图书资源仅供个人学习研究参考，其内容的准确性、完整性、合法性不作任何明示或默示担保。\n"
    "2. 因网络故障、系统维护、第三方服务中断、不可抗力等因素导致的服务中断或数据丢失，本平台不承担责任。\n"
    "3. 用户在使用本平台过程中因个人操作、设备原因或违反本须知造成的任何直接或间接损失，本平台不承担赔偿责任。\n"
    "4. 本须知可能适时修订，修订后的条款将在本平台公布；继续使用即视为接受修订内容。\n\n"
    "如您不同意上述任何条款，请勿注册或使用本平台。"
)


@app.get("/api/terms")
def get_terms():
    return {"content": db.get_config("terms_content", DEFAULT_TERMS),
            "version": db.get_config("terms_version", "1")}


@app.put("/api/admin/terms")
def put_terms(content: str = Form(...), user=Depends(require_admin)):
    db.set_config("terms_content", content)
    db.set_config("terms_version", str(int(db.get_config("terms_version", "1")) + 1))
    db.log_audit(user, "admin_terms", "system", None, "修改用户须知与免责公告")
    return {"ok": True}


# ---------- 静态前端 ----------
STATIC = os.path.join(config.BASE_DIR, "static")
# 开源版不带安装包目录：目录不存在时自动建空目录，避免 StaticFiles 直接抛异常起不来
for _d in (STATIC, os.path.join(STATIC, "update")):
    os.makedirs(_d, exist_ok=True)
app.mount("/static", StaticFiles(directory=STATIC), name="static")
# /update：App“检查更新”目录（APK 新版本 + version.json 清单）
app.mount("/update", StaticFiles(directory=os.path.join(STATIC, "update")), name="update")
# /uploads：书单讨论文章内嵌图片
app.mount("/uploads", StaticFiles(directory=config.IMAGE_DIR), name="uploads")


@app.middleware("http")
async def site_stats(request, call_next):
    """网站统计埋点：页面访问、App 安装包下载、5xx 错误。
    只记页面级请求（不碰静态资源和 API 轮询），全部内存自增，不阻塞响应。"""
    p = request.url.path
    is_page = _stats_is_page(p)
    is_apk = p.lower().endswith(".apk")
    response = await call_next(request)
    try:
        if is_apk:
            stats.record_app_download(request)
        elif is_page:
            stats.record_page(request, _stats_page_key(p),
                              _stats_user_id(request.headers.get("authorization", "")))
        if response.status_code >= 500:
            stats.record_error(request, p, response.status_code)
    except Exception:
        pass
    return response


def _stats_is_page(path):
    """只有这些算一次「访问」（SPA 是单页，一次打开 = 一次访问）"""
    # 注：/listen 曾漏在名单外，导致听书页不计 PV；/booklist 是 SPA 内部
    # 路由、并不作为页面路由存在，保留它只是为了兼容历史统计数据。
    if path in ("/", "/admin", "/reader", "/listen", "/booklist", "/index.html"):
        return True
    if path.startswith("/s/") and len(path) > 3:
        return True
    return False


def _stats_page_key(path):
    """把路径归一化，便于按页面看排行"""
    if path.startswith("/s/"):
        return "/s/分享链接"
    if path == "/index.html":
        return "/"
    return path


_STATS_TOKENS = {}


def _stats_user_id(authorization):
    """从 token 反查用户 id（带小缓存）；失败一律当游客，绝不抛异常"""
    if not authorization.startswith("Bearer "):
        return 0
    tk = authorization[7:]
    now = time.time()
    hit = _STATS_TOKENS.get(tk)
    if hit and now - hit[1] < 600:
        return hit[0]
    uid = 0
    try:
        payload = auth.decode_token(tk)
        if payload:
            uid = int(payload.get("uid") or 0)
    except Exception:
        uid = 0
    if len(_STATS_TOKENS) > 2000:
        _STATS_TOKENS.clear()
    _STATS_TOKENS[tk] = (uid, now)
    return uid


@app.middleware("http")
async def no_push_marker(request, call_next):
    """带 `X-BM-No-Push: 1` 的请求，本次一律不发 Server酱。

    ★ 为什么必须有这一层（2026-10-09 事故）：
      回归测试会建**真的**测试账号、真的走 HTTP 发共享申请/书单，请求由**服务进程**
      处理，于是 notify.push_suppressed() 里按「入口是不是测试脚本」的判断根本不适用
      （服务入口永远是 uvicorn），管理员手机上就不断冒出「不相关的推送」。
      审计日志能查到：测试账号 zzam_pub_* 发表了 8 次书单、zzt_sim_* 申请了 16 次共享。

    ★ 为什么用请求头而不是「按用户名猜测试账号」：
      猜命名规则会在真实用户恰好叫类似名字时误伤（他就永远收不到通知）。
      请求头是显式的、只影响带着它的那一个请求，线上请求不带就是原样。
    """
    if (request.headers.get("x-bm-no-push") or "").strip() == "1":
        notify.set_no_push(True)
    return await call_next(request)


@app.middleware("http")
async def no_cache_web(request, call_next):
    """页面/JS/CSS 一律不缓存，根治 WebView 加载旧代码（检查更新误报、新功能不生效）。

    APK 另有一套处理（见下）：安装包绝不能走缓存，也一定要带 Content-Disposition，
    否则浏览器/下载器可能复用上一次的半截文件或自己猜文件名。
    """
    response = await call_next(request)
    p = request.url.path
    # /api/books/ 下都是"随书内容变化"的动态响应（正文分段、目录、封面、原文件……），
    # 一旦被浏览器缓存，文档改了用户还是看旧正文 —— 一律不许缓存（站长 2026-10-30 反馈）。
    if p.startswith("/api/books/"):
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
    elif p.endswith((".html", ".js", ".css")) or p == "/update/version.json":
        response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
    elif p.lower().endswith(".apk"):
        # 安装包：禁止缓存 + 明确附件名。
        # 起因：Downloads 里已存在同名文件时系统下载器会另存为 -1/-2，
        # 而客户端若按固定路径去装就会装到上一次的残包，报「解析包时出现问题」。
        # 这里把文件名明确给出（含版本号），客户端就不会再猜。
        response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
        fname = os.path.basename(p) or "myreader.apk"
        response.headers["Content-Disposition"] = f'attachment; filename="{fname}"'
    return response


@app.get("/api/health")
def health():
    """健康探针（供 tools/watchdog.sh 使用）。

    之前看门狗探的是这个不存在的路径，只能靠「404 也算活着」蒙混过关，
    实际只验证了 TLS 握手与 HTTP 栈在应答，探不到应用层故障。
    这里给它一个真实端点：返回 200 才算活着，同时顺带确认数据库可读。
    """
    try:
        db.q("SELECT 1", one=True)
        db_ok = True
    except Exception:
        db_ok = False
    return {"ok": db_ok, "time": db.now(), "db": db_ok}


@app.get("/")
def index():
    return FileResponse(os.path.join(STATIC, "index.html"))


@app.get("/admin")
def admin_page():
    return FileResponse(os.path.join(STATIC, "admin.html"))


@app.get("/reader")
def reader_page():
    return FileResponse(os.path.join(STATIC, "reader.html"))


@app.get("/listen")
def listen_page():
    """听书播放器页面"""
    return FileResponse(os.path.join(STATIC, "listen.html"))


@app.get("/s/{token}")
def share_page(token: str):
    return FileResponse(os.path.join(STATIC, "share.html"))