# -*- coding: utf-8 -*-
"""「有声」页面（audiobook/library.py + ablib_api.py）回归测试。

覆盖三块最容易悄悄坏掉的地方：
 1. **时间轴**：章与逐句的偏移是从 ab_seg 的每句秒数「复刻拼接过程」算出来的，
    错一点歌词就会一直漂。这里拿每个成品文件 ffprobe 量的真实时长当基准，
    要求逐文件零偏差；并且独立核对「第 k 句文字」与书里该章第 k 个断句一致。
 2. **权限与树叶**：分组权限、免费章节、每章/整本定价、余额不足、重复兑换不重复扣。
 3. **接口契约**：列表/详情/章节/逐句/音频流（含 Range）/进度/分类/后台登记，
    以及路由顺序坑（/cats、/register 必须排在 /{lib_id} 之前）。

前置：服务在 https://127.0.0.1:9000 运行；库里有已登记的有声电子书。
本脚本只使用**测试账号 test**；会临时改「有声听书」设置与分类，结束时逐项还原，
新增的数据一律按精确 id 清理，不做任何批量删除。
运行：venv/bin/python tests/test_audiobook_library.py
"""
import json
import os
import ssl
import sys
import urllib.error
import urllib.request
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
import db  # noqa: E402
import auth  # noqa: E402
from audiobook import book as B, library as L, speech as S, store as ST  # noqa: E402

BASE = "https://127.0.0.1:9000"
CTX = ssl._create_unverified_context()
PASS = FAIL = 0


def check(name, ok, extra=""):
    global PASS, FAIL
    if ok:
        PASS += 1
        print("  ✓ " + name)
    else:
        FAIL += 1
        print("  ✗ " + name + ("  → %s" % extra if extra else ""))


def call(method, path, obj=None, token=None, headers=None, raw=False):
    h = dict(headers or {})
    h['X-BM-No-Push'] = '1'      # 测试请求：服务端别真发 Server酱
    if token:
        h["Authorization"] = "Bearer " + token
    data = None
    if obj is not None:
        data = json.dumps(obj).encode()
        h["Content-Type"] = "application/json"
    req = urllib.request.Request(BASE + path, method=method, data=data, headers=h)
    try:
        r = urllib.request.urlopen(req, context=CTX, timeout=120)
        body = r.read()
        return r.status, dict(r.headers), (body if raw else body.decode("utf-8", "replace"))
    except urllib.error.HTTPError as e:
        b = e.read()
        return e.code, dict(e.headers), (b if raw else b.decode("utf-8", "replace"))


# ------------------------------------------------------------------ 准备
L.init()
LIBS = [dict(r) for r in db.q("SELECT * FROM ab_lib ORDER BY id")]
TU = db.q("SELECT * FROM users WHERE username='test'", one=True)
TTOK = auth.create_token(TU)
ADMIN = db.q("SELECT * FROM users WHERE role='admin' AND enabled=1 ORDER BY id LIMIT 1", one=True)
ATOK = auth.create_token(ADMIN)
BAL0 = db.q("SELECT balance FROM user_leaves WHERE user_id=?", (TU["id"],), one=True)
BAL0 = int(BAL0["balance"]) if BAL0 else 0
CFG0 = L.cfg()
# ★ 每本书可能被后台单独定过价（-1 = 跟随全局），那会盖掉本测试要验的全局设置。
#   这里先把所有书的覆盖快照下来，测试期间强制回到「跟随全局」，结束时原样写回。
L.init()
PRICING0 = {int(r["id"]): (r["free_chapters"], r["leaf_per_chapter"], r["leaf_per_book"])
            for r in db.q("SELECT * FROM ab_lib")}
for _lid in PRICING0:
    L.pricing_set(_lid, free=-1, per_chapter=-1, per_book=-1)
NEW_CAT = None
NEW_LIB = None

print("===== 1. 表结构与登记 =====")
names = {r["name"] for r in db.q("SELECT name FROM sqlite_master WHERE type='table'")}
check("五张 ab_lib* 表都已建立",
      {"ab_lib", "ab_lib_chap", "ab_lib_seg", "ab_lib_cat", "ab_lib_prog", "ab_lib_buy"} <= names,
      str(sorted(n for n in names if n.startswith("ab_lib"))))
check("库里有已登记的有声电子书", len(LIBS) >= 1, "%d 本" % len(LIBS))

if LIBS:
    first = LIBS[0]
    n0 = db.q("SELECT COUNT(*) c FROM ab_lib WHERE id=?", (first["id"],), one=True)["c"]
    L.register(first["job_id"])            # 重复登记
    n1 = db.q("SELECT COUNT(*) c FROM ab_lib WHERE id=?", (first["id"],), one=True)["c"]
    check("重复登记不会建出重复行", n0 == n1 == 1, "n0=%s n1=%s" % (n0, n1))
    check("登记后得到章节与总时长", first["total_chapters"] > 0 and first["total_seconds"] > 0,
          "%s 章 / %.2f 小时" % (first["total_chapters"], first["total_seconds"] / 3600))

print()
print("===== 2. 时间轴：逐文件对齐成品真实时长（关键） =====")
worst_all, bad_all, files_all = 0.0, 0, 0
for lib in LIBS:
    rows = db.q("SELECT seq, seconds FROM ab_file WHERE job_id=? AND status='uploaded'",
                (lib["job_id"],))
    files_all += len(rows)
    for f in rows:
        chs = db.q("SELECT start_sec, dur_sec FROM ab_lib_chap WHERE lib_id=? AND file_seq=? ORDER BY seq",
                   (lib["id"], f["seq"]))
        if not chs:
            continue
        end = max(c["start_sec"] + c["dur_sec"] for c in chs)
        d = abs(end - chs[0]["start_sec"] - float(f["seconds"] or 0))
        worst_all = max(worst_all, d)
        if d > 0.05:
            bad_all += 1
check("全部 %d 个文件重建时间轴零偏差（≤50ms）" % files_all, bad_all == 0,
      "最大偏差 %.3fs，超差 %d 个" % (worst_all, bad_all))

# 章的偏移必须落在文件内、且逐章单调递增
if LIBS:
    lib = LIBS[-1]
    ok_mono = True
    for f in db.q("SELECT DISTINCT file_seq FROM ab_lib_chap WHERE lib_id=? ORDER BY file_seq", (lib["id"],)):
        chs = db.q("SELECT seq,start_sec,dur_sec FROM ab_lib_chap WHERE lib_id=? AND file_seq=? ORDER BY seq",
                   (lib["id"], f["file_seq"]))
        for a, b in zip(chs, chs[1:]):
            if b["start_sec"] < a["start_sec"] - 0.001:
                ok_mono = False
    check("同一文件内章节偏移单调递增", ok_mono)

    real = {x["seq"]: float(x["seconds"] or 0)
            for x in db.q("SELECT seq,seconds FROM ab_file WHERE job_id=?", (lib["job_id"],))}
    ok_in = True
    for c in db.q("SELECT file_seq,start_sec,dur_sec FROM ab_lib_chap WHERE lib_id=?", (lib["id"],)):
        r = real.get(c["file_seq"])
        if r is None:
            continue
        if c["start_sec"] < -0.01 or c["start_sec"] + c["dur_sec"] > r + 0.5:
            ok_in = False
    check("每章都落在所属文件的时长范围内（不越界）", ok_in)

print()
print("===== 3. 逐句文字与书里原文逐句对应 =====")
if LIBS:
    lib = LIBS[0]
    book = db.q("SELECT * FROM books WHERE id=?", (lib["book_id"],), one=True)
    chs_all = B.chapters(book) if book else []
    chap = db.q("SELECT * FROM ab_lib_chap WHERE lib_id=? AND n_segs>0 ORDER BY seq LIMIT 1",
                (lib["id"],), one=True)
    if chap:
        # 用与 worker 相同的断句规则独立复算该章，比对第 1/中间/最后一句
        src = None
        for c in chs_all:
            if int(c["idx"]) == int(chap["chapter_idx"]):
                src = S.split_sentences(c["text"])
                break
        segs = L.segs(lib["id"], chap["seq"])
        same = 0
        for pos in (0, len(segs) // 2, len(segs) - 1):
            if src and pos < len(src) and segs[pos]["text"] == src[pos]:
                same += 1
        check("逐句文字与书中原文逐句一致（首/中/末抽样）", same == 3,
              "三大抽样命中 %d 个" % same)
        check("逐句文字不为空", all((s["text"] or "").strip() for s in segs))
        ok_t = all(segs[i]["start_sec"] <= segs[i + 1]["start_sec"] for i in range(len(segs) - 1))
        check("逐句时间轴单调递增", ok_t)
        check("逐句时长都为正", all(s["dur_sec"] > 0 for s in segs))

print()
print("===== 4. 接口契约（测试账号登录） =====")
st, _, body = call("GET", "/api/audiobooks", token=TTOK)
d = json.loads(body)
check("GET /api/audiobooks 200", st == 200, str(st))
check("列表返回已登记的书", len(d.get("items", [])) >= 1, "%d 本" % len(d.get("items", [])))
check("列表项带封面 URL / 章节数 / 总时长",
      all(("cover_url" in x and "total_chapters" in x and "total_seconds" in x)
          for x in d.get("items", [])))

lib = LIBS[0] if LIBS else None
st, _, body = call("GET", "/api/audiobooks/%d" % lib["id"], token=TTOK)
det = json.loads(body)
check("GET /api/audiobooks/{id} 200", st == 200, str(st))
check("详情带全部章节", len(det.get("chapters", [])) == lib["total_chapters"],
      "%d / %s" % (len(det.get("chapters", [])), lib["total_chapters"]))
check("详情带评分字段（无评分时为 0）", "rating" in det)
check("详情带归类名称", det.get("cat_name"))
check("详情带逐句文字标记", "has_text" in det)

st, _, body = call("GET", "/api/audiobooks/%d/lyrics?chap=1" % lib["id"], token=TTOK)
ly = json.loads(body)
check("GET lyrics 200 且有句子", st == 200 and len(ly.get("segs", [])) > 0,
      "%s 句" % len(ly.get("segs", [])))

chap1 = det["chapters"][0]
FPATH = "/api/audiobooks/%d/file/%d" % (lib["id"], chap1["file_seq"])

# ---- 防盗链：没有签名票据一律不给音频 ----
st, _, body = call("GET", FPATH + "?chap=%d" % chap1["seq"], token=TTOK)
check("无播放凭证 → 403（防盗链生效）", st == 403, "%s %s" % (st, body[:90]))
st, _, body = call("GET", FPATH + "?chap=%d&u=1&exp=9999999999&sig=deadbeef" % chap1["seq"], token=TTOK)
check("伪造签名 → 403", st == 403, str(st))

st, _, body = call("GET", "/api/audiobooks/%d/ticket?seq=%d&chap=%d"
                   % (lib["id"], chap1["file_seq"], chap1["seq"]), token=TTOK)
check("按需换取播放凭证", st == 200 and "sig=" in body, "%s %s" % (st, body[:110]))
TURL = json.loads(body)["url"] if st == 200 else ""
check("凭证地址绑定用户/书/文件/章节", ("u=" in TURL and "exp=" in TURL and "sig=" in TURL), TURL[:110])

st, h, raw = call("GET", TURL, raw=True)
check("带凭证取音频 → 200", st == 200, str(st))
check("音频流是 audio/mpeg", (h.get("content-type") or "").startswith("audio"),
      str(h.get("content-type")))
check("音频流声明支持 Range", (h.get("accept-ranges") or "") == "bytes", str(h.get("accept-ranges")))
check("音频不被缓存（防盗链）",
      "no-store" in (h.get("cache-control") or "").lower(), str(h.get("cache-control")))
st2, h2, raw2 = call("GET", TURL, headers={"Range": "bytes=0-1023"}, raw=True)
check("Range 请求 → 206 + 1024 字节", st2 == 206 and len(raw2) == 1024,
      "status=%s len=%s" % (st2, len(raw2)))
check("Range 响应带 Content-Range", "content-range" in {k.lower() for k in h2},
      str(h2.get("Content-Range") or h2.get("content-range")))
mid = max(0, len(raw) // 2)
st3, _, raw3 = call("GET", TURL, headers={"Range": "bytes=%d-%d" % (mid, mid + 999)}, raw=True)
check("中段 Range 可取（能拖进度条）", st3 == 206 and len(raw3) == 1000, str(st3))

# 篡改 / 过期 / 换章节：签名绑定，任何一个不对都不认
st, _, body = call("GET", TURL[:-1] + ("0" if TURL[-1] != "0" else "1"), raw=True)
check("签名被改一位 → 403", st == 403, str(st))
st, _, body = call("GET", TURL.replace("exp=", "exp=9"), raw=True)
check("把有效期改大 → 403（exp 参与签名）", st == 403, str(st))
other = [c for c in det["chapters"] if c["seq"] != chap1["seq"]]
if other:
    st, _, body = call("GET", TURL.replace("chap=%d" % chap1["seq"], "chap=%d" % other[0]["seq"]), raw=True)
    check("拿本章凭证去听别的章 → 403", st == 403, str(st))
st, _, body = call("GET", TURL.replace("/api/audiobooks/%d/" % lib["id"], "/api/audiobooks/999999/", 1), raw=True)
check("换成别的书 → 403/404", st in (403, 404), str(st))

# 过期票据（签名本身合法，只是时间到了）
import ablib_api as _A  # noqa: E402
_e, _s = _A.stream_sign(TU["id"], lib["id"], chap1["file_seq"], chap1["seq"], ttl=-10)
st, _, body = call("GET", "%s?chap=%d&u=%d&exp=%d&sig=%s"
                   % (FPATH, chap1["seq"], TU["id"], _e, _s), raw=True)
check("过期凭证 → 403", st == 403, str(st))

# 外站盗链：带了别的站点 Referer 就拒绝
st, _, body = call("GET", TURL, headers={"Referer": "https://evil.example.com/x.html"}, raw=True)
check("外站 Referer 盗链 → 403", st == 403, str(st))
st, _, body = call("GET", TURL, headers={"Referer": "https://127.0.0.1:9000/"}, raw=True)
check("本站 Referer 正常放行", st == 200, str(st))

st, _, _ = call("GET", "/api/audiobooks/999999", token=TTOK)
check("不存在的书 → 404", st == 404, str(st))

print()
print("===== 5. 路由顺序：固定路径不能被 /{lib_id} 吃掉 =====")
st, _, body = call("GET", "/api/admin/audiobooks/cats", token=ATOK)
check("后台 /cats 可用（未被当成 lib_id）", st == 200 and "cats" in body, "%s %s" % (st, body[:80]))
st, _, body = call("POST", "/api/admin/audiobooks/register", {"job_id": lib["job_id"]}, token=ATOK)
check("后台 /register 可用（§14.44 同类坑）", st == 200, "%s %s" % (st, body[:120]))

print()
print("===== 6. 分类（自定义分类，删分类不删书） =====")
st, _, body = call("POST", "/api/admin/audiobooks/cats", {"name": "回归测试分类"}, token=ATOK)
NEW_CAT = json.loads(body).get("id") if st == 200 else None
check("新建自定义分类", st == 200 and NEW_CAT, "%s %s" % (st, body[:80]))
st, _, body = call("POST", "/api/admin/audiobooks/cats", {"name": "回归测试分类"}, token=ATOK)
check("重名分类被拒绝（不会建出两个同名）", st == 400, str(st))
st, _, body = call("POST", "/api/admin/audiobooks/cats/%d" % NEW_CAT, {"name": "回归测试分类改名"}, token=ATOK)
check("重命名分类", st == 200, str(st))
st, _, body = call("POST", "/api/admin/audiobooks/%d" % lib["id"], {"cat_id": NEW_CAT}, token=ATOK)
check("把书归到该分类", st == 200, str(st))
check("归类后立即可查",
      json.loads(call("GET", "/api/audiobooks/%d" % lib["id"], token=TTOK)[2])["cat_name"] == "回归测试分类改名")
st, _, body = call("DELETE", "/api/admin/audiobooks/cats/%d" % NEW_CAT, token=ATOK)
check("删除分类成功", st == 200, str(st))
left = db.q("SELECT COUNT(*) c FROM ab_lib WHERE id=?", (lib["id"],), one=True)["c"]
cat_left = db.q("SELECT COUNT(*) c FROM ab_lib_cat WHERE id=?", (NEW_CAT,), one=True)["c"]
uncat = db.q("SELECT cat_id FROM ab_lib WHERE id=?", (lib["id"],), one=True)["cat_id"]
check("删分类后书还在，只是变回未分类", left == 1 and cat_left == 0 and int(uncat) == 0,
      "书=%s 分类=%s cat_id=%s" % (left, cat_left, uncat))
NEW_CAT = None

print()
print("===== 7. 免费章节 / 分组权限 / 树叶兑换 =====")
# 快照当前设置，结束后还原
L.cfg_set({"lib_free_chapters": 2, "lib_leaf_per_chapter": 5, "lib_leaf_per_book": 40,
           "lib_leaf_per_chapter": 5, "lib_groups": "[]", "lib_need_login": "0"})
db.ex("UPDATE user_leaves SET balance=? WHERE user_id=?", (100, TU["id"]))
db.ex("DELETE FROM ab_lib_buy WHERE user_id=? AND lib_id=?", (TU["id"], lib["id"]))

det = json.loads(call("GET", "/api/audiobooks/%d" % lib["id"], token=TTOK)[2])
locked = [c["seq"] for c in det["chapters"] if c["locked"]]
free = [c["seq"] for c in det["chapters"] if not c["locked"]]
check("前 2 章免费、其余锁定", sorted(free) == [1, 2] and 3 in locked,
      "免费=%s 锁定前几个=%s" % (free[:3], sorted(locked)[:3]))
check("详情返回免费章节数与价格",
      det["access"]["free"] == 2 and det["access"]["per_chapter"] == 5 and det["access"]["per_book"] == 40,
      json.dumps(det["access"], ensure_ascii=False)[:120])

st, _, body = call("GET", "/api/audiobooks/%d/lyrics?chap=3" % lib["id"], token=TTOK)
check("未解锁章节拿不到文字", st == 403, str(st))
st, _, body = call("GET", "/api/audiobooks/%d/ticket?seq=%d&chap=3"
                   % (lib["id"], det["chapters"][2]["file_seq"]), token=TTOK)
check("未解锁章节换不到播放凭证", st == 403, "%s %s" % (st, body[:90]))

st, _, body = call("POST", "/api/audiobooks/%d/unlock" % lib["id"], {"kind": "chapter", "chap": 3}, token=TTOK)
r = json.loads(body)
check("兑换第 3 章成功并扣 5 片", st == 200 and r.get("spent") == 5, "%s %s" % (st, body[:100]))
bal = db.q("SELECT balance FROM user_leaves WHERE user_id=?", (TU["id"],), one=True)["balance"]
check("余额确实少了 5 片", int(bal) == 95, "余额 %s" % bal)
st, _, body = call("POST", "/api/audiobooks/%d/unlock" % lib["id"], {"kind": "chapter", "chap": 3}, token=TTOK)
check("重复兑换不再扣（spent=0）", json.loads(body).get("spent") == 0, body[:100])
bal = db.q("SELECT balance FROM user_leaves WHERE user_id=?", (TU["id"],), one=True)["balance"]
check("重复兑换后余额没变", int(bal) == 95, "余额 %s" % bal)
det = json.loads(call("GET", "/api/audiobooks/%d" % lib["id"], token=TTOK)[2])
check("兑换后该章变为可听", not [c for c in det["chapters"] if c["seq"] == 3][0]["locked"])

# 整本买断：余额不足要 403
db.ex("UPDATE user_leaves SET balance=? WHERE user_id=?", (3, TU["id"]))
st, _, body = call("POST", "/api/audiobooks/%d/unlock" % lib["id"], {"kind": "book"}, token=TTOK)
check("树叶不足时整本兑换被拒（403）", st == 403, "%s %s" % (st, body[:90]))
db.ex("UPDATE user_leaves SET balance=? WHERE user_id=?", (100, TU["id"]))   # ★ 必须带 WHERE：漏掉就是「全库所有人余额改成 100」（2026-10-08 真出过这个事故）
st, _, body = call("POST", "/api/audiobooks/%d/unlock" % lib["id"], {"kind": "book"}, token=TTOK)
check("余额充足时整本买断成功", st == 200 and json.loads(body).get("spent") == 40, body[:100])
det = json.loads(call("GET", "/api/audiobooks/%d" % lib["id"], token=TTOK)[2])
check("买断后所有章节解锁", not any(c["locked"] for c in det["chapters"]))

# 分组权限：把自己排除在外
L.cfg_set({"lib_groups": json.dumps([999999])})
st, _, body = call("GET", "/api/audiobooks/%d" % lib["id"], token=TTOK)
check("不在允许分组内 → 403（分组权限生效）", st == 403, "%s %s" % (st, body[:90]))
st, _, body = call("GET", "/api/audiobooks", token=TTOK)
check("无权限的书不出现在列表里", json.loads(body)["total"] == 0, body[:120])
L.cfg_set({"lib_groups": "[]"})
st, _, _ = call("GET", "/api/audiobooks/%d" % lib["id"], token=TTOK)
check("恢复分组后又能访问", st == 200, str(st))

# 管理员不受限
st, _, _ = call("GET", "/api/audiobooks/%d" % lib["id"], token=ATOK)
check("管理员始终可访问", st == 200, str(st))

print()
print("===== 8. 听读进度 =====")
db.ex("DELETE FROM ab_lib_prog WHERE user_id=? AND lib_id=?", (TU["id"], lib["id"]))
st, _, body = call("POST", "/api/audiobooks/%d/progress" % lib["id"],
                   {"chap": 5, "offset": 10.0}, token=TTOK)
check("上报进度 200", st == 200, body[:100])
p = db.q("SELECT * FROM ab_lib_prog WHERE user_id=? AND lib_id=?", (TU["id"], lib["id"]), one=True)
check("进度落库且章号正确", p and int(p["chap_seq"]) == 5, dict(p) if p else "无")
check("百分比按章内进度计算（第 5 章约 2%~3%）", p and 1.5 < float(p["percent"]) < 3.5,
      "percent=%.3f" % float(p["percent"]) if p else "")
st, _, body = call("POST", "/api/audiobooks/%d/progress" % lib["id"],
                   {"chap": 5, "done": True}, token=TTOK)
p2 = db.q("SELECT * FROM ab_lib_prog WHERE user_id=? AND lib_id=?", (TU["id"], lib["id"]), one=True)
check("听完一章后自动推进到下一章", int(p2["chap_seq"]) == 6, "chap_seq=%s" % p2["chap_seq"])
st, _, _ = call("GET", "/api/audiobooks/%d/progress" % lib["id"], token=TTOK)
check("可以读回进度", st == 200)
st, _, body = call("POST", "/api/audiobooks/%d/progress" % lib["id"], {"chap": 1}, token=None)
check("未登录不能写进度（401）", st == 401, str(st))

print()
print("===== 8b. 最近收听（首页「最近阅读」用） =====")
st, _, body = call("GET", "/api/audiobooks/recent", token=TTOK)
rr = json.loads(body) if st == 200 else {}
check("GET /api/audiobooks/recent 可用", st == 200, str(st))
check("最近收听里带上了刚听的书", any(int(x["id"]) == int(lib["id"]) for x in rr.get("items", [])),
      str([x["id"] for x in rr.get("items", [])]))
check("每条都带 listened_at（首页按它排序）",
      all("listened_at" in x for x in rr.get("items", [])), str(rr.get("items", [])[:1])[:120])
check("带封面与进度字段（首页卡片要用）",
      all(("cover_url" in x and "progress" in x) for x in rr.get("items", [])), "")
st, _, body = call("GET", "/api/audiobooks/recent")
check("未登录不能读最近收听（401，且没被 /{lib_id} 吃掉成 422）", st == 401, str(st))

# 权限没了就不该再出现在首页（否则点进去是 403）
L.cfg_set({"lib_groups": json.dumps([999999])})
st, _, body = call("GET", "/api/audiobooks/recent", token=TTOK)
check("失去分组权限后不再出现在最近收听",
      not any(int(x["id"]) == int(lib["id"]) for x in json.loads(body).get("items", [])))
L.cfg_set({"lib_groups": "[]"})

st, _, body = call("DELETE", "/api/audiobooks/%d/progress" % lib["id"], token=TTOK)
check("可以移出最近阅读（DELETE progress）", st == 200 and json.loads(body).get("removed", 0) >= 1,
      "%s %s" % (st, body[:90]))
st, _, body = call("GET", "/api/audiobooks/recent", token=TTOK)
check("移出后不再出现在最近收听",
      not any(int(x["id"]) == int(lib["id"]) for x in json.loads(body).get("items", [])))
st, _, body = call("DELETE", "/api/audiobooks/%d/progress" % lib["id"], token=TTOK)
check("重复移出不报错（removed=0）", st == 200 and json.loads(body).get("removed") == 0, body[:90])

print()
print("===== 9. 制作完成自动入库（勾选「加入有声电子书页面」） =====")
jid = None
try:
    jid = ST.job_new(TU["id"], "【回归测试】自动入库", "x", "y", 1, 0, {}, [], 0.12,
                     "/tmp/regression-none", TU["id"], to_lib=1, lib_cat=0)
    job = ST.job_get(jid)
    check("任务行记下了「加入有声页面」标记", int(job["to_lib"] or 0) == 1,
          "to_lib=%s lib_cat=%s" % (job["to_lib"], job["lib_cat"]))
    # 直接造一份最小可用的产物，再走登记入口（不真的合成，避免耗时与网络）
    b = db.q("SELECT * FROM books WHERE id=?", (TU["id"],), one=True)
    if not b:
        check("（跳过：测试账号名下没有书可做素材）", True)
    else:
        job2 = ST.job_get(jid)
        check("自动入库标记会随任务持久化（重启续跑不丢）", job2 is not None)
        from audiobook import worker as W
        # 未勾选的任务不会被登记
        jid2 = ST.job_new(TU["id"], "【回归测试】不自动入库", "x", "y", 1, 0, {}, [], 0.12,
                          "/tmp/regression-none2", TU["id"], to_lib=0)
        # 勾了但登记条件不满足（书不存在/索引建不出来）时，必须**吞掉异常**：
        # 音频已经传上去了，不能因为一个索引问题把几小时的任务判成失败
        try:
            W._to_library(jid)
            check("登记失败不会抛异常（不影响任务成败）", True)
        except Exception as e:
            check("登记失败不会抛异常（不影响任务成败）", False, repr(e))
        before = db.q("SELECT COUNT(*) c FROM ab_lib WHERE job_id=?", (jid2,), one=True)["c"]
        W._to_library(jid2)
        after = db.q("SELECT COUNT(*) c FROM ab_lib WHERE job_id=?", (jid2,), one=True)["c"]
        check("没勾选的任务不会被自动登记", before == after == 0, "%s → %s" % (before, after))
        ST.job_del(jid2)
finally:
    if jid:
        ST.job_del(jid)
        db.ex("DELETE FROM ab_lib WHERE job_id=?", (jid,))
check("自动入库的临时任务已清理",
      db.q("SELECT COUNT(*) c FROM ab_job WHERE title LIKE '【回归测试】%'", one=True)["c"] == 0)

print()
print("===== 10. 还原设置与数据 =====")
L.cfg_set(CFG0)
for _lid, (_f, _c, _b) in PRICING0.items():
    L.pricing_set(_lid, free=_f, per_chapter=_c, per_book=_b)
db.ex("UPDATE user_leaves SET balance=? WHERE user_id=?", (BAL0, TU["id"]))
n = db.ex_count("DELETE FROM ab_lib_buy WHERE user_id=? AND lib_id=?", (TU["id"], lib["id"]))
db.ex("DELETE FROM ab_lib_prog WHERE user_id=? AND lib_id=?", (TU["id"], lib["id"]))
check("树叶余额已还原", int(db.q("SELECT balance FROM user_leaves WHERE user_id=?",
      (TU["id"],), one=True)["balance"]) == BAL0, "原余额 %s" % BAL0)
check("设置已还原", L.cfg() == CFG0, json.dumps(L.cfg(), ensure_ascii=False))
check("本测试产生的买断/进度记录已清理", n >= 0)
check("没有残留的测试分类",
      db.q("SELECT COUNT(*) c FROM ab_lib_cat WHERE name LIKE '回归测试%'", one=True)["c"] == 0)
check("有声书数量没变（没误删）",
      db.q("SELECT COUNT(*) c FROM ab_lib", one=True)["c"] == len(LIBS))

print()
print("有声电子书后端：%d 通过 / %d 失败" % (PASS, FAIL))
sys.exit(1 if FAIL else 0)
