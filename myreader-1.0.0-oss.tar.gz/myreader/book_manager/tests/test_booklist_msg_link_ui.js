// 书单回复消息的「前往查看」：界面路径。
//
// 需求（2026-10-11）：
//   · 「新的书单回复待审查」→ 消息弹窗底部「关闭」旁边要有「前往查看」，
//     点了直达那篇文章（如 https://localhost:9000/#/booklist/18）；
//   · 「您的书单收到新回复」→ 点「前往查看」也直达那篇文章，而不是书单讨论页。
//
// 后端产出的 link 由 tests/test_booklist_msg_link.py 验；这里验**界面**：
//   1. 两条书单消息的弹窗底部都有「前往查看」，且和「关闭」在同一排；
//   2. 点下去真的落在 #/booklist/<id>，并且文章视图打开了（不是列表页）；
//   3. ★ 老消息也要对：库里已经发出去的那些，
//      「待审查」那条 link 是**空的**、「收到新回复」那条是「#/booklists」，
//      前端按 ref_type/ref_id 兜底后两者都必须直达那一篇；
//   4. 不相干的消息（系统通知）不该冒出一个「前往查看」。
//
// 本测试**只读**：消息对象是在页面里注入的假数据（id 用负数），
// 不碰数据库里的任何一条真实消息，也不写库。
const { chromium } = require('playwright-core');
const { execSync } = require('child_process');
const CHROME = '/srv/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome';
const ROOT = '/srv/myreader/book_manager';
const BASE = 'https://127.0.0.1:9000';
const BLID = 18;      // 库里真实存在的一篇书单（需求里举的就是这一篇）

let pass = 0, fail = 0;
const ck = (n, ok, extra) => {
  if (ok) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (extra ? '  → ' + extra : '')); }
};
const py = (c) => execSync('venv/bin/python -', { cwd: ROOT, encoding: 'utf8', input: c }).trim();

(async () => {
  // 用管理员账号（这两类消息里的「待审查」本来就是发给管理员的）
  const info = JSON.parse(py(`
import sys, json
sys.path.insert(0, '${ROOT}')
import db, auth
u = db.q("SELECT * FROM users WHERE id=1 AND enabled=1", one=True)
print(json.dumps({"tok": auth.create_token(u), "user": dict(u)}))`));
  // 那篇书单的标题，用来确认打开的确实是文章
  const blTitle = py(`
import sys
sys.path.insert(0, '${ROOT}')
import db
print((db.q("SELECT title FROM booklists WHERE id=?", (${BLID},), one=True) or {"title": ""})["title"])`);

  const b = await chromium.launch({ executablePath: CHROME, args: ['--no-sandbox'] });
  const ctx = await b.newContext({ ignoreHTTPSErrors: true, viewport: { width: 420, height: 900 } });
  await ctx.addInitScript(([t, u]) => {
    localStorage.setItem('bm_token', t); localStorage.setItem('bm_user', u);
  }, [info.tok, JSON.stringify(info.user)]);
  const page = await ctx.newPage();
  const errs = [];
  page.on('pageerror', e => errs.push(String(e).slice(0, 140)));
  await page.goto(BASE + '/', { waitUntil: 'domcontentloaded' });
  await page.waitForFunction(() => typeof showMsgDetail === 'function', null, { timeout: 20000 });

  // 注入三条假消息：正是「库里已发出」的两种老形态 + 一条不相干的系统消息
  await page.evaluate((blid) => {
    const base = { from_id: 45, from_name: 'test', created_at: '2026-10-11 15:00:00', is_read: 0 };
    msgItems = [
      // 老形态①：管理员那条「待审查」——link 是**空的**（所以原来只有「关闭」）
      Object.assign({}, base, { id: -1, title: '新的书单回复待审查',
        body: 'test 回复了《某书单》：这是一条待审查的回复', kind: 'review',
        link: '', ref_type: 'booklist', ref_id: blid }),
      // 老形态②：作者那条「收到新回复」——link 是「#/booklists」（只到列表页）
      Object.assign({}, base, { id: -2, title: '您的书单收到新回复',
        body: 'test 回复了《某书单》：这是一条待审查的回复', kind: 'booklist',
        link: '#/booklists', ref_type: 'booklist', ref_id: blid }),
      // 不相干的系统消息：没有书单 ref，不该出现「前往查看」
      Object.assign({}, base, { id: -3, title: '系统维护通知', body: '今晚维护',
        kind: 'system', link: '', ref_type: null, ref_id: null }),
    ];
  }, [BLID].length ? BLID : 18);

  const probe = (i) => page.evaluate((idx) => {
    showMsgDetail(idx);
    const row = document.querySelector('.msg-detail-btns');
    const btns = row ? Array.from(row.querySelectorAll('.btn')) : [];
    return {
      n: btns.length,
      texts: btns.map(x => x.textContent.trim()),
      goIdx: btns.findIndex(x => x.textContent.trim() === '前往查看'),
      closeIdx: btns.findIndex(x => x.textContent.trim() === '关闭'),
      onclick: btns.map(x => x.getAttribute('onclick') || ''),
    };
  }, i);

  console.log('== 1. 「新的书单回复待审查」（老消息 link 为空）==');
  let s = await probe(0);
  ck('弹窗底部出现「前往查看」', s.goIdx >= 0, JSON.stringify(s.texts));
  ck('「关闭」还在，且两个按钮在同一排（前往查看在关闭左边）',
    s.closeIdx >= 0 && s.goIdx >= 0 && s.goIdx < s.closeIdx, JSON.stringify(s.texts));
  ck('前往查看的跳转目标是那一篇书单（不是空、不是列表）',
    /#\/booklist\/18/.test(s.onclick[s.goIdx] || ''), s.onclick[s.goIdx] || '');
  ck('底部那一排没有「回复」（这不是私信）', s.texts.indexOf('回复') < 0, JSON.stringify(s.texts));

  console.log('\n== 2. 点「前往查看」真的打开那篇文章 ==');
  await page.evaluate(() => {
    const row = document.querySelector('.msg-detail-btns');
    const btn = Array.from(row.querySelectorAll('.btn')).find(x => x.textContent.trim() === '前往查看');
    btn.click();
  });
  await page.waitForTimeout(2500);
  const r2 = await page.evaluate(() => ({
    hash: location.hash,
    booklistVisible: !document.getElementById('view-booklist').classList.contains('hidden'),
    modalHidden: document.getElementById('modal-mask').classList.contains('hidden'),
    title: (document.querySelector('#view-booklist') || {}).textContent || '',
  }));
  ck('地址栏落在 #/booklist/18（直达文章，不是 #/booklists 列表）',
    r2.hash === '#/booklist/18', r2.hash);
  ck('文章详情视图打开了', r2.booklistVisible === true);
  ck('弹窗已关闭', r2.modalHidden === true);
  ck('打开的确是那一篇（标题对得上）',
    !!blTitle && r2.title.indexOf(blTitle.slice(0, 8)) >= 0,
    '标题片段「' + blTitle.slice(0, 10) + '」' + (r2.title ? '' : ' 视图内没有文字'));

  console.log('\n== 3. 「您的书单收到新回复」（老消息 link 是 #/booklists）==');
  s = await probe(1);
  ck('弹窗底部出现「前往查看」', s.goIdx >= 0, JSON.stringify(s.texts));
  ck('★ 目标是那一篇书单，而不是老数据里的 #/booklists',
    /#\/booklist\/18/.test(s.onclick[s.goIdx] || '') && !/#\/booklists(['"]|$)/.test(s.onclick[s.goIdx] || ''),
    s.onclick[s.goIdx] || '');
  await page.evaluate(() => {
    const row = document.querySelector('.msg-detail-btns');
    const btn = Array.from(row.querySelectorAll('.btn')).find(x => x.textContent.trim() === '前往查看');
    btn.click();
  });
  await page.waitForTimeout(2500);
  const r3 = await page.evaluate(() => ({
    hash: location.hash,
    booklistVisible: !document.getElementById('view-booklist').classList.contains('hidden'),
  }));
  ck('点下去落在 #/booklist/18 并打开文章', r3.hash === '#/booklist/18' && r3.booklistVisible === true,
    r3.hash + ' / 可见=' + r3.booklistVisible);

  console.log('\n== 4. 不相干的消息不该冒出「前往查看」==');
  s = await probe(2);
  ck('系统消息底部只有「关闭」', s.goIdx < 0 && s.closeIdx >= 0, JSON.stringify(s.texts));

  ck('整页没有 JS 报错', errs.length === 0, errs.join(' | '));
  await ctx.close();
  await b.close();
  console.log('\n通过 ' + pass + '，失败 ' + fail);
  process.exit(fail ? 1 : 0);
})();
