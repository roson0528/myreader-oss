# -*- coding: utf-8 -*-
"""听书：文本分句、TTS 服务调用、内存级音频缓存、串行合成队列

设计要点
  1. 分段单位是「句」不是「段」。reader.chunks() 的 CHUNK_CHARS=200KB 是分页单位，
     一段约 20 万字 ≈ 10 小时音频，不能直接交给 TTS
  2. 音频只存在内存里，不落磁盘。用带上限的 LRU + TTL，播完自然淘汰，
     服务器不因为听书增长任何存储
  3. 合成并行化：曾担心并发请求把 TTS 主机显存打爆而刻意串行，实测该顾虑不成立
     —— 主线一 4 段并发总耗时 21.0s、依次 29.9s（加速比 1.42x），并发不炸且有收益。
     反过来，串行时所有听众共用一条流水线，两个人同时听就各分到一半算力，
     实时率跌破 1.0 后段间必空 2 秒。故改为 SYNTH_WORKERS 个 worker（见类定义处）
  4. 音频走 Opus（服务端 ffmpeg 转码，32kbps，比 WAV 小约 12 倍）
"""
import os
import re
import base64
import json
import time
import queue
import hashlib
import logging
import itertools
import threading
import collections

# 失败曾经只进 HTTP 响应体、日志里零痕迹，导致线上 5 次 503 只能从状态码侧写。
# 这里补上模块日志：单台失败 warning（换机重试属常态），全部失败 error。
log = logging.getLogger("tts")
import unicodedata
import urllib.request
import urllib.error

import db
import reader

# 内存缓存上限：既够预取和回看，又不会让服务器长胖
CACHE_MAX_BYTES = 12 * 1024 * 1024    # 12 MB，约 300 句（每句 40KB 左右）
CACHE_MAX_ITEMS = 400
CACHE_TTL = 1800                      # 30 分钟没被用到就淘汰

MAX_SEG_CHARS = 120        # 单句上限，超过在逗号处再切
MIN_SEG_CHARS = 6          # 过短的句子并入下一句


# ---------------------------------------------------------------- 设置
# 对外用短键（cfg["base_url"]），落库时统一加 tts_ 前缀（tts_base_url）
DEFAULTS = {
    "enabled": "0",
    "base_url": "http://198.51.100.3:8500",
    "api_key": "",
    "model": "indextts-2",
    "default_voice": "pool_49",
    "voices": "",                  # 逗号分隔的对外音色白名单，空=全部
    "servers": "",                 # 多台 TTS 服务器的 JSON 数组，空=用上面的单机 base_url
    "listen_cost": "30",           # 无权限用户每本书听书消耗树叶
    "emotion_vector": "",          # 逗号分隔 8 个数，空=不启用
    "emo_alpha": "0.6",
    "timeout": "120",
}
PREFIX = "tts_"


def settings():
    out = {k: db.get_config(PREFIX + k, d) for k, d in DEFAULTS.items()}
    out["enabled"] = str(out["enabled"]).strip() in ("1", "true", "on", "yes")
    try:
        out["cost"] = max(0, int(str(out["listen_cost"]).strip() or 0))
    except (TypeError, ValueError):
        out["cost"] = 30
    try:
        out["timeout"] = max(10, int(str(out["timeout"]).strip() or 120))
    except (TypeError, ValueError):
        out["timeout"] = 120
    raw = str(out.get("emotion_vector") or "").strip()
    vec = None
    if raw:
        try:
            parts = [float(x) for x in re.split(r"[,\s]+", raw) if x.strip()]
            if len(parts) == 8:
                vec = parts
        except ValueError:
            vec = None
    out["emotion_vector"] = vec
    out["servers"] = _norm_servers(out.get("servers"), out)
    # base_url 始终指向第一台启用的服务器，这样老的显示与调用都还有意义
    act = [x for x in out["servers"] if x["enabled"]]
    if act:
        out["base_url"] = act[0]["url"]
    return out


def _norm_servers(raw, cfg):
    """把 tts_servers 的 JSON 解析成规范列表；为空或坏数据时回落到单机配置。

    每项：{name, url, key, model, enabled}。enabled=0 的保留在列表里（后台还能看见），
    但不会被派发任务 —— 相当于「暂时停用」而不是删除。
    """
    out = []
    if raw:
        try:
            arr = json.loads(raw) if isinstance(raw, str) else raw
        except (ValueError, TypeError):
            arr = None
        if isinstance(arr, list):
            for i, x in enumerate(arr):
                if not isinstance(x, dict):
                    continue
                url = str(x.get("url") or x.get("base_url") or "").strip().rstrip("/")
                if not url:
                    continue
                out.append({
                    "name": str(x.get("name") or ("服务器 %d" % (i + 1))).strip(),
                    "url": url,
                    "key": str(x.get("key") or x.get("api_key") or "").strip(),
                    "model": str(x.get("model") or cfg.get("model") or "indextts-2").strip(),
                    "enabled": 1 if str(x.get("enabled", 1)) in ("1", "true", "True", "on", "yes") else 0,
                    # 每台机器可能装不同的模型、音色集也不一样，所以默认音色和白名单
                    # 跟着服务器走。None = 这台没单独配，沿用全局值（老配置靠这个兼容）；
                    # 空串 = 明确表示「不限制 / 全部音色」，两者含义不同，不能混。
                    "default_voice": None if x.get("default_voice") is None else str(x["default_voice"]).strip(),
                    "voices": None if x.get("voices") is None else str(x["voices"]).strip(),
                })
    if not out:
        # 只有当单机 base_url 真的填了才兜底；否则返回空列表，
        # 让 call_tts 报出「没有配置服务器」，而不是拿一个空地址去请求。
        legacy = str(cfg.get("base_url") or "").strip().rstrip("/")
        if legacy:
            out.append({"name": "默认", "url": legacy,
                        "key": str(cfg.get("api_key") or "").strip(),
                        "model": str(cfg.get("model") or "indextts-2").strip(), "enabled": 1,
                        "default_voice": None, "voices": None})
    return out


def set_settings(body):
    """保存设置，返回保存后的值。键名接受 base_url 或 tts_base_url 两种写法，未知键忽略。"""
    for k, d in DEFAULTS.items():
        if k in body:
            v = body[k]
        elif PREFIX + k in body:
            v = body[PREFIX + k]
        else:
            continue
        if k == "enabled":
            v = "1" if str(v) in ("1", "true", "on", "yes", "True") else "0"
        elif k == "servers":
            # 后台传数组或 JSON 字符串都接受；JSON 非法就忽略这次改动，别把配置写坏
            if isinstance(v, (list, tuple)):
                v = json.dumps(list(v), ensure_ascii=False)
            else:
                v = str(v).strip()
                if v:
                    try:
                        json.loads(v)
                    except ValueError:
                        continue
        else:
            v = str(v).strip()
        db.set_config(PREFIX + k, v)
    return settings()


# ---------------------------------------------------------------- 分句
END_PUNCT = "。！？!?…"
CLOSERS = "”’」』）)》〉"


def _split_long(s, limit=MAX_SEG_CHARS):
    """超长句在次级标点处再切，尽量切得均匀"""
    if len(s) <= limit:
        return [s]
    out, buf = [], ""
    for p in re.split(r"(?<=[，,；;：:、])", s):
        if len(buf) + len(p) <= limit:
            buf += p
        else:
            if buf:
                out.append(buf)
            while len(p) > limit:            # 单个次级片段还是太长：硬切
                out.append(p[:limit])
                p = p[limit:]
            buf = p
    if buf:
        out.append(buf)
    return [x for x in out if x.strip()]


def split_sentences(text):
    """把正文切成适合 TTS 的句子。

    句末标点 + 后引号要连在一起；省略号算一句；
    过短的碎片（如「他说。」）并入下一句，避免语气被切断。
    """
    if not text:
        return []
    text = text.replace("\r\n", "\n").replace("\r", "\n").replace("\u3000", " ")
    raw, buf = [], ""
    i, n = 0, len(text)
    while i < n:
        ch = text[i]
        if ch == "\n":
            if buf.strip():
                raw.append(buf.strip())
            buf = ""
            i += 1
            continue
        buf += ch
        if ch in END_PUNCT:
            # 连续的句末标点（如「？！」或「……」）一起吃进来
            while i + 1 < n and text[i + 1] in END_PUNCT:
                i += 1
                buf += text[i]
            # 收尾引号/括号跟着这一句
            while i + 1 < n and text[i + 1] in CLOSERS:
                i += 1
                buf += text[i]
            raw.append(buf.strip())
            buf = ""
        i += 1
    if buf.strip():
        raw.append(buf.strip())

    merged = []
    for s in raw:
        if not s:
            continue
        if merged and len(merged[-1]) < MIN_SEG_CHARS:
            merged[-1] += s
        else:
            merged.append(s)
    if len(merged) >= 2 and len(merged[-1]) < MIN_SEG_CHARS:
        merged[-2] += merged[-1]
        merged.pop()

    out = []
    for s in merged:
        out.extend(_split_long(s))
    return [x.strip() for x in out if x.strip()]


# ---------------------------------------------------------------- 取正文
def _html_text(html):
    """HTML → 纯文本，保留段落边界（reader._html_to_text 会把换行也压掉，不适合 TTS）"""
    t = re.sub(r"(?is)<(script|style)[^>]*>.*?</\1>", " ", html or "")
    t = re.sub(r"(?i)<br\s*/?>", "\n", t)
    t = re.sub(r"(?i)</(p|div|h[1-6]|li|tr|blockquote)\s*>", "\n", t)
    t = re.sub(r"<[^>]+>", "", t)
    for a, b in (("&nbsp;", " "), ("&amp;", "&"), ("&lt;", "<"), ("&gt;", ">"),
                 ("&quot;", '"'), ("&#39;", "'"), ("&ldquo;", "“"), ("&rdquo;", "”")):
        t = t.replace(a, b)
    t = re.sub(r"&[a-zA-Z#0-9]+;", " ", t)
    t = re.sub(r"[ \t]+", " ", t)
    t = re.sub(r"\n\s*\n+", "\n", t)
    return t.strip()


def book_chapters(book):
    """按章节返回 [(title, text)]。txt/docx/md 用 reader.chunks；
    epub/mobi 用 epub_toc + epub_chapter（它们不走 chunks）"""
    k = reader.kind(book)
    out = []
    if k in ("txt", "docx", "md"):
        for c in reader.chunks(book):
            txt = c["text"]
            if k == "md":
                txt = _html_text(txt)     # md 的 text 是渲染后的 HTML
            out.append((c["title"], txt))
    elif k in ("epub", "mobi"):
        try:
            toc = reader.epub_toc(book)
        except Exception:
            return []
        for c in toc:
            try:
                html = reader.epub_chapter(book, c["href"], "", c.get("fragment", ""))
            except Exception:
                continue
            out.append((c["title"], _html_text(html)))
    return out


_LIST_CACHE = {}
_LIST_LOCK = threading.Lock()
_LIST_TTL = 1800


def _book_stamp(book):
    """用本地缓存文件的 mtime 判断正文是否变了。
    注意 book["path"] 是 FTP 上的相对路径，不能直接 stat，要先 ensure_local。"""
    try:
        import covers
        return os.path.getmtime(covers.ensure_local(book))
    except Exception:
        return 0


def segments(book):
    """把整本书切成句子，返回 [{idx, chapter, title, text, chars}]。

    结果按书缓存（30 分钟），否则每次请求都要重新解析整本书。
    """
    bid = book["id"]
    stamp = _book_stamp(book)
    with _LIST_LOCK:
        hit = _LIST_CACHE.get(bid)
        if hit and hit[0] == stamp and time.time() - hit[1] < _LIST_TTL:
            return hit[2]
    segs = []
    for ci, (title, text) in enumerate(book_chapters(book)):
        for s in split_sentences(text):
            segs.append({"idx": len(segs), "chapter": ci, "title": title,
                         "text": s, "chars": len(s)})
    with _LIST_LOCK:
        _LIST_CACHE[bid] = (stamp, time.time(), segs)
    return segs


def chapter_map(segs):
    """章节号 -> [首句全局序号, 该章句数]。用于和阅读进度互转。"""
    m = {}
    for s in segs:
        c = s["chapter"]
        if c in m:
            m[c][1] += 1
        else:
            m[c] = [s["idx"], 1]
    return m


def seg_to_read_pos(segs, seg_idx, book_kind):
    """听书句号 -> 阅读器 position（章节号 + 章内比例）。
    阅读器跨设备时用 frac 定位，所以这里给 frac 而不是页码。"""
    seg = next((x for x in segs if x["idx"] == seg_idx), None)
    if not seg:
        return None
    span = chapter_map(segs).get(seg["chapter"])
    frac = 0.0
    if span and span[1] > 1:
        frac = max(0.0, min(1.0, (seg_idx - span[0]) / float(span[1] - 1)))
    return {"kind": "txt" if book_kind in ("txt", "docx", "md") else "epub",
            "mode": "paged", "idx": seg["chapter"], "page": 0, "scroll": 0,
            "frac": round(frac, 4), "dev": "listen"}


def read_pos_to_seg(segs, position):
    """阅读器 position -> 听书句号（该章按比例落到某一句）"""
    if not isinstance(position, dict):
        return None
    m = chapter_map(segs)
    ci = int(position.get("idx") or 0)
    span = m.get(ci)
    if not span:
        return None
    first, cnt = span
    frac = position.get("frac")
    if frac is None:
        frac = position.get("scroll")
    try:
        frac = float(frac or 0)
    except (TypeError, ValueError):
        frac = 0.0
    frac = max(0.0, min(1.0, frac))
    return first + int(round(frac * max(0, cnt - 1)))


def chapters_of(segs):
    """把句子清单折叠成章节 → 句子区间，客户端用它显示目录"""
    out = []
    for s in segs:
        if out and out[-1]["chapter"] == s["chapter"]:
            out[-1]["count"] += 1
            out[-1]["chars"] += s["chars"]
        else:
            out.append({"chapter": s["chapter"], "title": s["title"],
                        "start": s["idx"], "count": 1, "chars": s["chars"]})
    return out


# ---------------------------------------------------------------- 内存音频缓存
class MemAudioCache:
    """有上限的内存 LRU。听书是流式消费，播完的句子很快被后来的挤出去，
    服务器不会因为听书堆积任何文件。"""

    def __init__(self, max_bytes=CACHE_MAX_BYTES, max_items=CACHE_MAX_ITEMS, ttl=CACHE_TTL):
        self.max_bytes = max_bytes
        self.max_items = max_items
        self.ttl = ttl
        self.d = collections.OrderedDict()
        self.bytes = 0
        self.lock = threading.Lock()
        self.hits = 0
        self.misses = 0
        self.evicted = 0

    def get(self, key):
        with self.lock:
            self._expire()
            item = self.d.get(key)
            if not item:
                self.misses += 1
                return None
            self.d.move_to_end(key)
            item["ts"] = time.time()
            self.hits += 1
            return item["data"]

    def put(self, key, data, src=None):
        with self.lock:
            old = self.d.pop(key, None)
            if old:
                self.bytes -= len(old["data"])
            # src = 这段音频是哪台服务器产出的。播放页要显示「当前线路」，
            # 命中缓存时只有把它一起存下来才知道该显示谁（不能只看当前配置，
            # 因为音色/线路可能已经改过）。
            self.d[key] = {"data": data, "ts": time.time(), "src": src}
            self.bytes += len(data)
            self._expire()
            while self.d and (self.bytes > self.max_bytes or len(self.d) > self.max_items):
                _, victim = self.d.popitem(last=False)
                self.bytes -= len(victim["data"])
                self.evicted += 1

    def src_of(self, key):
        """这段缓存是哪台产出的（命中过才有值）。不动 LRU 顺序、不计命中数。"""
        with self.lock:
            item = self.d.get(key)
            return item.get("src") if item else None

    def _expire(self):
        cut = time.time() - self.ttl
        while self.d:
            k, v = next(iter(self.d.items()))
            if v["ts"] >= cut:
                break
            self.d.popitem(last=False)
            self.bytes -= len(v["data"])
            self.evicted += 1

    def clear(self):
        with self.lock:
            self.d.clear()
            self.bytes = 0

    def stats(self):
        with self.lock:
            return {"items": len(self.d), "bytes": self.bytes,
                    "max_bytes": self.max_bytes, "hits": self.hits,
                    "misses": self.misses, "evicted": self.evicted}


AUDIO = MemAudioCache()


def seg_key(book_id, seg_idx, text, voice, model, line=""):
    """一段音频的缓存键。必须带上线路：同音色在不同线路上的模型不同，
    成品音频不是同一个东西，混用缓存会出现「换了线路还是旧声音」。"""
    return hashlib.sha1(("%s|%s|%s|%s|%s|%s" % (book_id, seg_idx, text, voice, model, line or "")
                         ).encode("utf-8")).hexdigest()[:24]


# ---------------------------------------------------------------- TTS 调用
class TTSError(Exception):
    """TTS 调用失败。

    status 是 HTTP 状态码（连接层面的失败为 None）。区分它是必要的：
    **4xx 说明这台机器活着、只是拒绝了这个请求**（比如「这台没有这个音色」），
    不该把它标成「不可用」—— 否则客户端线路列表就会显示「当前不可用」，
    而这其实是请求本身的问题，不是机器的问题。
    """

    def __init__(self, msg, status=None):
        super().__init__(msg)
        self.status = status


def white_of(srv, cfg):
    """这台服务器的音色白名单。没单独配就沿用全局的（兼容老配置）。

    返回 [] 表示不限制（该机器的音色全部可选）。
    """
    raw = srv.get("voices")
    if raw is None:
        raw = cfg.get("voices") or ""
    return [x.strip() for x in str(raw).split(",") if x.strip()]


def default_voice_of(srv, cfg):
    """这台服务器的默认音色。没单独配就沿用全局的。"""
    v = str(srv.get("default_voice") or "").strip()
    return v or str(cfg.get("default_voice") or "").strip()


def default_voice(cfg=None):
    """全局默认音色 = 第一台启用服务器的默认音色。

    听书进度里没记音色时用它，所以必须跟着「实际会派到的那台」走。
    """
    cfg = cfg or settings()
    for srv in active_servers(cfg):
        v = default_voice_of(srv, cfg)
        if v:
            return v
    return str(cfg.get("default_voice") or "").strip()


def server_list(cfg=None):
    """当前配置里的全部 TTS 服务器（含停用的）"""
    return (cfg or settings())["servers"]


def active_servers(cfg=None):
    """参与派发的服务器。全被停用时退回全部，免得整个听书功能直接不可用。"""
    srvs = server_list(cfg)
    act = [x for x in srvs if x["enabled"]]
    return act or srvs


# 每台服务器的最近一次连通结果。热路径上不做主动探测（那会给每句合成加一次往返），
# 而是「失败就记下来、短时间内不再往那台派」，等 TTL 过了再给它机会自动恢复。
_SRV_HEALTH = {}
_SRV_TTL = 20
_SRV_LOCK = threading.Lock()
_RR = {"i": 0}


def _mark(url, ok):
    with _SRV_LOCK:
        _SRV_HEALTH[url] = (time.time(), bool(ok))


def _is_healthy(url):
    with _SRV_LOCK:
        h = _SRV_HEALTH.get(url)
    if not h:
        return True                     # 没探过就当好的，先试
    return h[1] or (time.time() - h[0]) >= _SRV_TTL


def _srv_by_url(cfg, url):
    """按 url 找回服务器配置（call_tts 返回的是 url，worker 需要据此判断实际模型）"""
    if not url:
        return None
    for x in active_servers(cfg):
        if x.get("url") == url:
            return x
    return None


def model_of(srv, cfg):
    """这台服务器实际使用的模型（服务器没单独配就沿用全局）"""
    return (srv.get("model") or cfg.get("model") or "").strip()


def _pick_base(cfg, voice):
    """候选集合：优先「确实有这音色」的那些机器。

    两种退化情况都退回全体：一台都没有（这音色没人提供，或所有机的音色清单
    都取不到），或者**每台都声称有**（清单取不到时 servers_with_voice 会把
    每台都算进来，见那里「先算它一个」的兜底）。

    ★ 无论哪种退化，调用方都必须再按模型分组 —— 以前这里直接对全体轮询，
    于是「冷启动时清单全取不到」就会跨模型轮询，音色又跳了。
    这正是用户说的「有时候」。服务运行久了清单有缓存，所以平时看不出来。
    """
    srvs = active_servers(cfg)
    pref = servers_with_voice(cfg, voice) if voice else []
    if pref and len(pref) < len(srvs):
        return srvs, pref
    return srvs, list(srvs)


def _ordered(cfg, voice, rotate=True):
    """候选顺序的**唯一出处**：candidates() 与缓存键都从这里取，避免两处口径不一致。

    ★ 只在「同模型」的机器之间轮询。
    音色由「模型 + 音色 id」共同决定，不同模型上的同名音色是**不同的声音**：
    实测 pool_49 在 indextts-2 与 gpt-sovits-v2 上音质与时长都不同。
    而 pool_49 恰好同时存在于这两台上，以前对候选整体轮询，于是相邻两段交替
    落到不同模型 —— 用户听到的就是「上一段是设置的音色，下一段变成另一个音色」。
    同音色但异模型的机器只排在后面做兜底，不参与轮询。
    """
    srvs, base = _pick_base(cfg, voice)
    if not srvs:
        return []
    m = model_of(base[0], cfg)
    head = [x for x in base if model_of(x, cfg) == m]
    tail = [x for x in base if model_of(x, cfg) != m]
    head = _rr_pick(head) if rotate else head
    return head + tail + [x for x in srvs if x not in base]


def candidates(cfg=None, voice=None):
    """挑服务器的顺序：轮询起点 + 跳过近期失败的，健康的排前面。

    轮询实现分流；失败的排后面实现故障转移；全失败时仍然全返回，
    这样任意一台恢复后都能自动被重新用起来。

    指定了 voice 时，先挑「确实有这音色」的机器：各机模型/音色集不同，
    派到没有这音色的机器上要么报错、要么悄悄换成别的音色。
    但只是「优先」不是「限定」—— 全都挂了的时候还得靠其余机器兜底。

    排序口径全部在 _ordered() 里，这里只额外套一层「健康优先」。
    """
    cfg = cfg or settings()
    ordered = _ordered(cfg, voice, rotate=True)
    if not ordered:
        return []
    good = [x for x in ordered if _is_healthy(x["url"])]
    return good if good else ordered


def serving_line(cfg=None, voice=None, line=None):
    """这段音频**将由哪台**服务器产出（与 _ordered() 同一口径）。

    只用于「实际产出线路未知时」的兜底显示 —— 例如音频是本次改动之前就
    缓存好的、那时还没记 src。正常路径一律用 worker 回报的实际 url。
    """
    cfg = cfg or settings()
    srv = line_of(cfg, line) if line else None
    if srv is None:
        srvs, base = _pick_base(cfg, voice)
        if not base:
            return None
        m = model_of(base[0], cfg)
        grp = [x for x in base if model_of(x, cfg) == m]
        srv = grp[0] if grp else base[0]
    return srv


def line_name(cfg=None, url=None):
    """线路 url → 后台里配的名字（主线一 / 备用一 …），给播放页显示用。

    名字找不到就退回主机名 —— 宁可显示 "198.51.100.3" 也不要空着，
    那至少能让用户看出「换线路了」。
    """
    cfg = cfg or settings()
    if not url:
        return ""
    u = str(url).rstrip("/")
    for s in server_list(cfg):
        if (s.get("url") or "").rstrip("/") == u:
            return s.get("name") or u
    m = re.match(r"^[a-zA-Z]+://([^/]+)", u)
    return m.group(1) if m else u


def serving_model(cfg=None, voice=None, line=None):
    """预测这段音频会由哪个**模型**产出 —— 缓存键必须用它，而不是全局 cfg["model"]。

    同音色在不同模型上不是同一个东西：用全局 model 做键，会把两个模型的成品
    混在同一把键下，命中缓存时就会播出另一个音色（音色忽左忽右的第二个来源）。

    与 _ordered() 共用 _pick_base()，所以取到的必定是 _ordered() 排在最前的
    那个模型组的模型 —— 组内每台模型都相同，轮询起点不影响结果。
    手动指定线路时直接用它那台的模型。
    """
    cfg = cfg or settings()
    srv = line_of(cfg, line) if line else None
    if srv is None:
        srvs, base = _pick_base(cfg, voice)
        if not srvs or not base:
            return str(cfg.get("model") or "").strip()
        m = model_of(base[0], cfg)
        grp = [x for x in base if model_of(x, cfg) == m]
        srv = grp[0] if grp else base[0]
    return model_of(srv, cfg)


def line_of(cfg=None, line=None):
    """把线路标识解析成服务器配置。线路 = 一台启用的 TTS 服务器，用 url 标识。

    解析不出来（后台删了这台、或改成了禁用）就返回 None ——
    调用方会退回「自动」，而不是报错卡住播放。
    """
    line = (line or "").strip()
    if not line:
        return None
    for srv in active_servers(cfg or settings()):
        if srv.get("url") == line:
            return srv
    return None


def _rr_pick(lst):
    """按轮询起点把列表转一下，实现多机分流"""
    if not lst:
        return []
    with _SRV_LOCK:
        start = _RR["i"] % len(lst)
        _RR["i"] += 1
    return lst[start:] + lst[:start]


# 线路侧把文本按 GBK 编码，GBK 编不出来的字符会让它直接 500 / 400。
#
# ★ 为什么这段放在 tts.py（而不是 audiobook/speech.py）：
#   在线听书走 SynthQueue -> call_tts -> _call_one，批量制作走 audiobook.speech.synth，
#   两条路最后都落到这里的 _call_one。净化只有放在**线路模块自己**这一层，
#   才能保证「任何入口都绕不过去」。原先只放在 audiobook/speech.py，
#   结果在线听书那条路完全没有净化 —— 用户在听书里遇到同样的字符会直接失败。
# ★ 实测（《魔戒三部曲》任务 #999906）：第 4 个文件第 200 句
#   「托尔金根据古英语的 máðm（意为“珍贵之物，财宝”）一词造出了该词……」
#   里的 ð(U+00F0) 让 .3 返回 500、.16 返回 400（.16 报错里的 position 11
#   与该字符在句中的位置完全一致），.6 又是「未知音色 pool_49」→ 三台全灭，
#   整本书在第 200 句失败。这是**文本**问题，不是线路宕机。
# 折的都是通行转写写法（ð→d、þ→th），比整句丢掉或整本失败好得多。
_TTS_CHAR_MAP = {
    "ð": "d", "Ð": "D",           # eth
    "þ": "th", "Þ": "Th",         # thorn
    "æ": "ae", "Æ": "Ae",         # ash
    "œ": "oe", "Œ": "Oe",
    "ø": "o", "Ø": "O",
    "ł": "l", "Ł": "L",
    "ß": "ss",
    "ı": "i", "İ": "I",
    "\u00a0": " ", "\u3000": " ",  # 不换行空格 / 全角空格
}


def _gbk_safe(ch):
    """这个字符能不能**安全地**交给线路？

    ★ 不能只判「原字符能不能编成 GBK」。线路在合成前会做大小写归一
      （实测是按大写处理），而 GBK 只收了**小写**的那些带音标拉丁字母：

          ú ü é è ê á à í ì ó ò   → 原样可以编码
          Ú Ü É È Ê Á À Í Ì Ó Ò   → 大写形态 GBK 里没有，编不出来

      只判原字符就会放过它们，到了线路上照样 500：

          'gbk' codec can't encode character '\xda' in position 2

      注意 \xda 正是 'ú'.upper() —— 报的是大写形态，不是原文里的那个小写字母，
      所以只看报错很容易找不到是哪个字（原文里根本没有 Ú）。

      《魔戒三部曲》就是栽在这里：第三个文件第 334 句是精灵语
      `laurië lantar lassi súrinen,`，ë 被判出来了，ú 却漏了过去
      （因为它小写形态能编 GBK），任务在合成这一句时反复 500 后失败。

      所以三种大小写形态都验一遍，任一编不出就交给 NFKD 折成 ASCII。
    """
    for v in (ch, ch.upper(), ch.lower()):
        try:
            v.encode("gbk")
        except UnicodeEncodeError:
            return False
    return True


# --------------------------------------------------------------- 朗读前的符号清理
# ★ 线路（IndexTTS-2 / Piper-zh / GPT-SoVITS）的文本前端会把「不认识的符号」当字念：
#   省略号念成「点点点」、※ 念成噪声、＃ 念成「井号」…… 用户听到一堆莫名其妙的声音，
#   还把语意打断。这些符号对**朗读**没有任何信息量，必须在送出去之前处理掉。
#
#   ★ 为什么放在这一层：所有出口（批量制作 audiobook.speech.synth、在线听书 SynthQueue、
#     角色音色重试分支）最后都落到 _call_one → safe_text，改这一处等于
#     四条线路（主线一 .3 / 主线二 .6 / 备用一 .16 / 备用二 .210）一起生效；
#     线路那两台是 Windows、跑的是模型自己的前端，本来也没法从这边改。
#
#   两类处理：
#     ① 本身表示「停顿」的（省略号 ………、破折号 ——、波浪号 ～～、重复点）→ 换成逗号：
#        语气停顿留着，线路也不会去念「省略号」三个字；
#     ② 纯装饰 / 噪声符号（※ ＃ ＊ ☆ ★ ● ◆ ■ ▲ § ♥ → ≤ 以及 emoji）→ 直接删掉。
#   ★ 正常标点一律保留（，。、；：！？「」（）《》""''）—— 它们是断句和语气的一部分，
#     线路本来就当停顿处理、不念出来（现有测试锁着这一点，别顺手删）。
_TTS_PAUSE_RE = re.compile(r"…+|\.{3,}|。{2,}|[—–―─━~～〜]+|[·•‧・]{2,}")
# 「数字 + 符号」这类有明确读法的：换成词，顺序也照中文习惯来（50% → 百分之50）
_TTS_PCT_RE = re.compile(r"(\d+(?:\.\d+)?)\s*[%％]")
_TTS_DEGREE_MAP = (("℃", "摄氏度"), ("°C", "摄氏度"), ("°c", "摄氏度"),
                   ("℉", "华氏度"), ("°F", "华氏度"), ("°f", "华氏度"))
# 保留的标点（不在这里的标点与符号，一律按噪声删掉）
_TTS_KEEP_PUNCT = set(
    "，。、；：！？,.;:!?-—"
    "\u201c\u201d\u2018\u2019"          # “ ” ‘ ’
    "\u300c\u300d\u300e\u300f"          # 「 」 『 』
    "\uff02'\u2018\u2019"               # ＂ '
    "()\uff08\uff09[]\uff3b\uff3d{}\uff5b\uff5d"
    "\u3010\u3011\u300a\u300b\u3008\u3009\u3014\u3015\u3016\u3017"   # 【】《》〈〉〔〕〖〗
    "\u00b7"                            # · 人名间隔号
)


def _speakable(text):
    """把「会被线路当字念出来」的符号清掉（规则与理由见上面那段注释）。

    ★ 这一步只动符号，不动汉字 / 字母 / 数字 / 空白；也不改断句（在 _call_one 里
      是**按句**调用的，句数、句序都不变，所以制作缓存键与字幕行号都不受影响）。
    """
    s = text or ""
    if not s:
        return s
    s = _TTS_PCT_RE.sub(r"百分之\1", s)
    for a, b in _TTS_DEGREE_MAP:
        s = s.replace(a, b)
    s = s.replace("°", "度")
    s = _TTS_PAUSE_RE.sub("，", s)
    out = []
    for ch in s:
        if ch.isspace() or ch.isalnum() or ch.isalpha():
            out.append(ch)
            continue
        cat = unicodedata.category(ch)
        # S*=装饰/数学/货币/emoji，C*=控制与不可见，P*=标点里不在白名单的噪声（※ ＃ ＊ §）
        if cat[0] in ("S", "C", "P") and ch not in _TTS_KEEP_PUNCT:
            continue
        out.append(ch)
    cleaned = "".join(out)
    # ★ 整句都是符号（例如单独一行的「※※※※」或「……」）时不能返回空串：
    #   _call_one 会因为「这一段没有可合成的文本」直接抛错，整本书跟着失败。
    #   留一个逗号，线路合出一小段静音 —— 比失败好，也比念一串噪声好。
    if not any(c.isalnum() or c.isalpha() for c in cleaned):
        return "，"
    return cleaned


def safe_text(text):
    """把线路编不出来的字符折成发音等价的写法，并清掉「会被念出来」的符号。

    ★ 为什么放在最靠近线路的**这一层**：这里之后就是网络调用，
      批量制作、在线听书、角色音色重试分支都绕不过它，
      修一处就全好了（放在离线解析里则会漏掉别的入口）。
    ★ 为什么是「折写」而不是「过滤掉」：máðm 读成 madm，
      远好过整本书因为一个古英语注音字母失败；也不是静默丢弃内容。
    ★ 符号清理（_speakable）走同一层：四条线路一起生效，不用改线路那头的模型前端。
    """
    s = _speakable(text)
    if not s:
        return s
    out = []
    for ch in s:
        rep = _TTS_CHAR_MAP.get(ch)
        if rep is not None:
            out.append(rep)
            continue
        if _gbk_safe(ch):
            out.append(ch)
            continue
        # 剩下的零散字符（带音标的拉丁字母、希腊字母、数学符号等）：
        # 先按 NFKD 拆出基本字母，只保留 ASCII 部分
        ascii_ish = "".join(c for c in unicodedata.normalize("NFKD", ch) if ord(c) < 128)
        out.append(ascii_ish or " ")
    return "".join(out)


def _call_one(srv, text, voice, cfg, timeout):
    """向单台服务器要一段音频，返回 (opus_bytes, gen_sec)"""
    # ★ 送出去之前的最后一道：所有入口（在线听书 / 批量制作）都经过这里
    text = safe_text(text)
    if not (text or "").strip():
        raise TTSError("这一段没有可合成的文本（全是线路不支持的字符）")
    payload = {"text": text, "voice": voice, "format": "opus", "bitrate": "32k",
               "model": srv.get("model") or cfg.get("model")}
    if cfg.get("emotion_vector"):
        payload["emotion_vector"] = cfg["emotion_vector"]
        payload["emo_alpha"] = float(cfg.get("emo_alpha") or 0.6)
    req = urllib.request.Request(srv["url"] + "/synth",
                                 data=json.dumps(payload).encode("utf-8"), method="POST")
    req.add_header("Content-Type", "application/json")
    if srv.get("key"):
        req.add_header("X-API-Key", srv["key"])
    try:
        with urllib.request.urlopen(req, timeout=timeout or cfg["timeout"]) as r:
            data = r.read()
            gen = r.headers.get("X-Gen-Seconds")
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", "ignore")[:200]
        raise TTSError("返回 %d：%s" % (e.code, body), status=e.code)
    except Exception as e:
        raise TTSError("无法连接：%s" % e)
    if not data or data[:4] != b"OggS":
        raise TTSError("返回的不是有效 Opus 数据（%d 字节）" % len(data))
    try:
        return data, (float(gen) if gen else None)
    except (TypeError, ValueError):
        return data, None


def call_tts(text, voice, cfg=None, timeout=None, line=None):
    """调用 TTS 合成，返回 (opus_bytes, gen_sec, 实际使用的线路)。

    按 candidates() 的顺序逐台尝试：一台连不上或报错就立刻换下一台，
    所以某台机器关机/服务挂了不会让听书中断，只是多花一次尝试的时间。

    指定了 line（用户手动选线路）时先只用那一台：用户的选择要算数。
    但它真挂了的话还是继续往下试 —— 听书中断比「线路没按选的走」更糟。
    """
    cfg = cfg or settings()
    pinned = line_of(cfg, line)
    cands = candidates(cfg, voice)
    if pinned:
        cands = [pinned] + [x for x in cands if x.get("url") != pinned.get("url")]
    if not cands:
        raise TTSError("没有配置 TTS 服务器，请在后台「听书设置」里添加")
    errs = []
    for srv in cands:
        try:
            data, gen = _call_one(srv, text, voice, cfg, timeout)
            _mark(srv["url"], True)
            return data, gen, srv.get("url")
        except Exception as e:
            # ★ 只有「连不上 / 服务端 5xx / 返回的不是音频」才算这台不可用。
            # 4xx 是**这台机器活着、但拒绝了这个请求**（最典型的是「这台没这个音色」）：
            # 把它标成不可用会污染健康标记，客户端随后显示「当前不可用」，
            # 而机器其实好得很 —— 一个用不了的音色不该让整条线路背锅。
            code = getattr(e, "status", None)
            if code is None or code >= 500:
                _mark(srv["url"], False)
            else:
                _mark(srv["url"], True)
            log.warning("TTS 线路失败 name=%s url=%s voice=%s code=%s：%s",
                        srv.get("name") or "", srv["url"], voice, code, e)
            errs.append("%s %s —— %s" % (srv.get("name") or "", srv["url"], e))
    log.error("TTS 全部线路不可用 voice=%s 尝试=%d：%s",
              voice, len(errs), "；".join(errs[:3]))
    raise TTSError("所有 TTS 服务器都不可用：" + "；".join(errs[:3]))


def probe(srv, timeout=6):
    """主动探测单台服务器（只给后台「测试连接」用，不走进合成热路径）"""
    req = urllib.request.Request(srv["url"] + "/health")
    if srv.get("key"):
        req.add_header("X-API-Key", srv["key"])
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            h = json.loads(r.read().decode("utf-8"))
        return h if isinstance(h, dict) else {"status": "bad"}
    except Exception as e:
        return {"status": "unreachable", "error": str(e)}


def health_all(cfg=None):
    """逐台探测，返回每台的状态（后台面板用）"""
    cfg = cfg or settings()
    out = []
    for s in cfg["servers"]:
        h = probe(s)
        ok = h.get("status") == "ok"
        _mark(s["url"], ok)
        out.append({"name": s["name"], "url": s["url"], "model": s.get("model"),
                    "enabled": s["enabled"], "ok": ok, "health": h})
    return out


def health(cfg=None, allh=None):
    """返回一台可用服务器的详细状态，并附上全部服务器的概览。

    挑「第一台启用且通的」，都不通时退回第一台启用的，让后台能看到具体错在哪。
    allh 可以传入已经探测好的结果，避免后台测试接口把每台机探测两遍。
    """
    cfg = cfg or settings()
    allh = allh if allh is not None else health_all(cfg)
    act = [x for x in allh if x["enabled"]] or allh
    first = next((x for x in act if x["ok"]), act[0] if act else None)
    h = dict(first["health"]) if first else {"status": "unreachable"}
    h["base_url"] = first["url"] if first else ""
    h["model"] = first["model"] if first else cfg.get("model")
    h["servers"] = [{"name": x["name"], "url": x["url"], "ok": x["ok"],
                     "model": x["model"], "enabled": x["enabled"],
                     "status": (x["health"] or {}).get("status"),
                     "vram_gb": (x["health"] or {}).get("vram_gb"),
                     "models": (x["health"] or {}).get("models"),
                     "queue": (x["health"] or {}).get("queue")} for x in allh]
    return h


def server_stats():
    """给后台看的每台服务器分流/健康情况"""
    with _SRV_LOCK:
        snap = dict(_SRV_HEALTH)
    out = []
    for s in server_list():
        h = snap.get(s["url"])
        out.append({"name": s["name"], "url": s["url"], "enabled": s["enabled"],
                    "ok": (h[1] if h else None),
                    "checked_ago": (round(time.time() - h[0], 1) if h else None)})
    return out


# 远端音色清单缓存。它会被每句音频请求间接调用（_voice_allowed），
# 不缓存的话每合成一句都要多绕一趟到 TTS 主机的网络往返。
_VOICES_CACHE = {"data": None, "ts": 0.0, "base": ""}
_VOICES_TTL = 300
_VOICES_LOCK = threading.Lock()


_SRV_VOICES = {}          # url -> {"data": [...], "ts": float}，每台各自的清单
_VOICES_REFRESH = set()   # 正在后台刷新清单的 url（去重，别每句都起一个线程）
_VOICES_TIMEOUT = 10      # 正常单次取清单的超时


def _voices_fetch(srv, cfg, timeout=_VOICES_TIMEOUT):
    """真正去某台取音色清单。**只允许在后台线程或显式 force 时调用。**

    ★ 绝不要把它放回请求热路径。TTS 主机在合成期间会把整个 HTTP 端堵住：
    实测主线一在合成一段 126 字时，`/health` 和 `/voices` 会**挂起 20 秒以上**
    （合成一结束立刻恢复到 0.01 秒）。而 `voices_of_server()` 被
    `serving_model → _pick_base → servers_with_voice` 调用，就在
    `/listen/seg` 的热路径上 —— 清单缓存（300 秒）一过期又正好撞上它在合成，
    这一段就会活活等上几秒，听感上就是「播完一句停 2 秒」。
    这条路径的耗时和 §14.9 的合成吞吐问题是**两个独立的空档来源**。
    """
    url = srv["url"]
    try:
        req = urllib.request.Request(url + "/voices")
        if srv.get("key"):
            req.add_header("X-API-Key", srv["key"])
        with urllib.request.urlopen(req, timeout=timeout) as r:
            data = json.loads(r.read().decode("utf-8")).get("voices", [])
        _mark(url, True)
        with _VOICES_LOCK:
            _SRV_VOICES[url] = {"data": data, "ts": time.time()}
        return data
    except Exception:
        # ★ 故意**不** _mark(url, False)：取不到清单只说明这台「正忙或被超时掐了」，
        #   不代表它不能合成。以前在这里标失败，会让一台好好的服务器被踢出派发
        #   20 秒（_SRV_TTL），流量全压到另一台上，反而更容易卡。
        #   真正的连通性由合成失败时在 call_tts 里标记。
        with _VOICES_LOCK:
            c = _SRV_VOICES.get(url)
            if c:
                return c["data"]
            # 从没取到过又失败了：记一条 ts=0（立刻算过期）的空记录。
            # 有了它，下一次调用走「过期 → 返回旧值 + 后台刷新」这条路，
            # 不会再同步等一遍，避免服务器一直坏着就每句都卡几秒。
            _SRV_VOICES[url] = {"data": [], "ts": 0.0}
        return []


def _voices_refresh_async(srv, cfg):
    """后台刷新某台的音色清单，调用方立刻返回，不等结果。"""
    url = srv.get("url")
    if not url:
        return
    with _VOICES_LOCK:
        if url in _VOICES_REFRESH:
            return
        _VOICES_REFRESH.add(url)

    def run():
        try:
            _voices_fetch(srv, cfg)
        finally:
            with _VOICES_LOCK:
                _VOICES_REFRESH.discard(url)

    threading.Thread(target=run, name="tts-voices", daemon=True).start()


def warm_voices(cfg=None):
    """启动时把所有服务器的音色清单预热一遍。

    冷启动那次必然要真取一次；放在启动阶段做，就不会落到某个用户的
    `/listen/seg` 请求上（那正是空档最容易被感知的地方）。
    """
    cfg = cfg or settings()
    for srv in active_servers(cfg):
        _voices_refresh_async(srv, cfg)


def voices_of_server(srv, cfg=None, force=False, wait=True):
    """取某台服务器自己的音色清单（按地址分别缓存）。

    每台机器可能装不同的模型、配不同的音色，所以清单必须按机器分开取，
    不能只问第一台就把结果当成全部。

    ★ 这里**永不长时间阻塞请求**：
      · 缓存新鲜        → 直接返回；
      · 缓存过期（有旧值）→ 返回旧值 + 后台刷新。这是热路径最常走的一条，
        绝不能在 listen_seg 上同步去取 —— TTS 主机合成期间会挂起 20 秒以上；
      · 冷（本进程从没取到过）→ `wait=True` 同步取一次（完整超时），
        `wait=False`（热路径）返回空表 + 后台刷新，绝不等。
        同步取失败会记一条空记录（ts=0，立刻算过期），保证只同步等这一次。
    返回空表是安全的：`servers_with_voice()` 对「清单取不到」的机器会先算它一个，
    `_pick_base()` 再按模型分组，不会退回跨模型轮询（见 §14.8 成因 3）；
    `_voice_allowed()` 也有「清单不完整就不下结论」的兜底（见 app.py）。
    `force=True` 是管理端的显式刷新，走同步取。
    """
    cfg = cfg or settings()
    url = srv["url"]
    now = time.time()
    with _VOICES_LOCK:
        c = _SRV_VOICES.get(url)
        if not force and c and (now - c["ts"]) < _VOICES_TTL:
            return c["data"]
    if force:
        return _voices_fetch(srv, cfg)
    if c:
        _voices_refresh_async(srv, cfg)
        return c["data"]
    # 冷（本进程还没取到过这台）。
    # wait=False 是**热路径**：返回空表 + 后台刷新，绝不在这里等。
    # 其它调用方（管理页、listen/info）走同步取，用完整超时保证拿到真数据。
    if not wait:
        _voices_refresh_async(srv, cfg)
        return []
    return _voices_fetch(srv, cfg)


# ---------------------------------------------------------------- 定制音色（主机侧代理）
# 零样本克隆的模型里，一个「音色」就是一段参考音频 —— 所以「定制音色」在实现上
# 就是把一段样板音频交给 TTS 主机，存在它的音色目录里，再重建音色表。
# 用 base64 + JSON 而不是 multipart：主机是 Windows 上跑的 FastAPI，
# 走 JSON 就不必要求它装 python-multipart，少一个线上依赖。
VOICE_SAMPLE_MAX = 12 * 1024 * 1024


def _host_post(srv, path, payload, timeout=180):
    """POST 一台 TTS 主机，返回 (json_dict, err_str)。"""
    req = urllib.request.Request(srv["url"] + path,
                                 data=json.dumps(payload).encode("utf-8"), method="POST")
    req.add_header("Content-Type", "application/json")
    if srv.get("key"):
        req.add_header("X-API-Key", srv["key"])
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8")), None
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", "ignore")[:200]
        try:
            body = json.loads(body).get("detail") or body
        except Exception:
            pass
        # 老版本主机没有这个接口 → 明确告诉管理员是主机不支持，不是操作错了
        if e.code == 404:
            return None, "该 TTS 主机还没有定制音色接口，需要先更新主机端"
        return None, "返回 %d：%s" % (e.code, body)
    except Exception as e:
        return None, "无法连接：%s" % e


def host_voice_upload(srv, raw, filename, name="", text="", timeout=240):
    """把样板音频交给主机定制成新音色。返回 (新音色 id, 错误信息)。"""
    if not raw:
        return None, "样板文件为空"
    if len(raw) > VOICE_SAMPLE_MAX:
        return None, "样板文件过大（上限 %d MB）" % (VOICE_SAMPLE_MAX // 1024 // 1024)
    d, err = _host_post(srv, "/voice/upload", {
        "filename": filename or "sample.wav",
        "name": name or "", "text": text or "",
        "audio_b64": base64.b64encode(raw).decode("ascii"),
    }, timeout=timeout)
    if err:
        return None, err
    vid = (d or {}).get("id")
    if not vid:
        return None, "主机没有返回音色 id"
    _SRV_VOICES.pop(srv["url"], None)      # 清单变了，缓存作废
    return vid, None


def host_voice_delete(srv, vid, timeout=60):
    """让主机删掉一个**定制**音色（内置音色主机侧会拒绝删除）。"""
    d, err = _host_post(srv, "/voice/delete", {"id": vid}, timeout=timeout)
    if err:
        return False
    _SRV_VOICES.pop(srv["url"], None)
    return bool((d or {}).get("ok"))


def remote_voices(cfg=None, force=False):
    """取远端音色清单：第一台能取到的服务器的清单（保留给老调用方）。"""
    cfg = cfg or settings()
    srvs = active_servers(cfg)
    if not srvs:
        return []
    ordered = [x for x in srvs if _is_healthy(x["url"])] or srvs
    for srv in ordered:
        vs = voices_of_server(srv, cfg, force=force)
        if vs:
            return vs
    return []


def servers_with_voice(cfg, voice):
    """哪几台服务器确实提供这个音色（白名单 + 该机 /voices 都要满足）。"""
    out = []
    for srv in active_servers(cfg):
        white = white_of(srv, cfg)
        if white:
            if voice in white:
                out.append(srv)
            continue
        ids = {v.get("id") for v in voices_of_server(srv, cfg, wait=False)}
        # /voices 取不到时无法判断，先算它一个，别把请求堵死在一台上
        if (not ids) or (voice in ids):
            out.append(srv)
    return out


def allowed_voices(cfg=None, force=False, wait=True):
    """对外可选的音色 = 各服务器可选音色的并集。

    每台先取自己的 /voices，再按自己的白名单过滤，最后合并去重
    （同一个 id 以先出现的为准，标签沿用主服务器的）。
    """
    cfg = cfg or settings()
    out, seen = [], set()
    for srv in active_servers(cfg):
        white = white_of(srv, cfg)
        vs = voices_of_server(srv, cfg, force=force, wait=wait)
        if white:
            order = {v: i for i, v in enumerate(white)}
            vs = [v for v in vs if v.get("id") in order]
            vs.sort(key=lambda v: order[v["id"]])
        for v in vs:
            vid = v.get("id")
            if vid and vid not in seen:
                seen.add(vid)
                out.append(v)
    return out


# ---------------------------------------------------------------- 并行合成队列
# 并行合成线程数。★ 这不是「多多益善」的调优项，而是听书能不能连上的关键：
#
# 单 worker 时，所有听众共用一条串行流水线。实测 indextts-2 的实时率
# （合成耗时/音频时长）在 0.63~1.05 之间 —— 本来就只有薄薄一层余量，
# 一旦同时有两个人在听，或者轮到短句（6 字固定开销就有 1.8s，实时率 1.05），
# 合成就跟不上播放，段间立刻空 2 秒（这与 §14 记录的「RTF 0.66~1.4」一致）。
#
# 实测主线一支持并发：4 段同时发总耗时 21.0s，依次发 29.9s，加速比 1.42x。
# 所以并发几条不是把负载翻倍，而是把该机本来就有的并发能力用起来。
#
# 取 3 是留余量的折中：并发的尾部延迟会变长（单段最长从 ~6s 涨到 ~21s），
# 但总吞吐上去了；再往上加收益递减，且会把 TTS 主机压出更多排队。
#
# 可用环境变量 BOOKMGR_TTS_WORKERS 覆盖，便于线上 A/B 对照与降级 ——
# 调大之前请先确认 TTS 主机扛得住（用并发加速比实测，别凭感觉）。
SYNTH_WORKERS = max(1, int(os.environ.get("BOOKMGR_TTS_WORKERS") or 3))


class SynthQueue:
    """并行合成队列。同一段被并发请求时复用同一个任务结果。

    音频只进内存缓存，不写磁盘；缓存有上限，播完自然被挤掉。"""

    def __init__(self, workers=SYNTH_WORKERS):
        # 优先级队列：0=用户正在等的点播，1=后台预取。
        # FIFO 会让「点下一句」排在预取任务后面 —— 实测能排到 45 秒，必须让点播插队。
        # queue.PriorityQueue 自带锁，多 worker 同时 get 是安全的。
        self.q = queue.PriorityQueue()
        self.lock = threading.Lock()
        self.pending = {}          # key -> {"event":..., "ok":..., "err":..., "running":...}
        self.seq = itertools.count(1)   # 同优先级内保持先进先出
        self.inflight = 0          # 正在合成的段数（多 worker 下 busy 不能再靠单个布尔量）
        self.workers = max(1, int(workers))
        self.stats = {"done": 0, "failed": 0, "busy": False, "current": "", "line": ""}
        self.threads = [threading.Thread(target=self._loop, daemon=True,
                                         name="tts-synth-%d" % i)
                        for i in range(self.workers)]
        for t in self.threads:
            t.start()

    def _loop(self):
        while True:
            item = self.q.get()
            if item is None:
                break
            job = item[2]
            key = job["key"]
            with self.lock:
                # 同一段可能被预取和点播各排过一次；点播那次会插到前面。
                # 先执行完的条目已经把结果放好，后到的重复条目在这里直接跳过。
                #
                # ★ 多 worker 下还必须判 running：单 worker 时「先到的处理完就
                #   pop 掉 pending」是天然去重，但多 worker 下两个线程会同时
                #   看到 key 还在 pending 里，从而把同一段合成两遍（白烧一次
                #   推理，还把 TTS 主机多压一份）。
                slot = self.pending.get(key)
                if slot is None or slot.get("running"):
                    continue
                slot["running"] = True
                self.inflight += 1
            self.stats["busy"] = True
            self.stats["current"] = job["text"][:30]
            err = None
            data = None
            src = None
            try:
                data, _, used = call_tts(job["text"], job["voice"], job["cfg"],
                                         line=job.get("line"))
                self.stats["line"] = used or ""
                # 只有「产出模型 == 缓存键里的模型」才写缓存。
                # 兜底到异模型时音色已经变了，若也写进这把键，这段就会长期
                # 驻留成另一个音色（缓存 30 分钟），比一次性的兜底更糟。
                srv_used = _srv_by_url(job["cfg"], used)
                actual = model_of(srv_used, job["cfg"]) if srv_used else job.get("model", "")
                if actual == job.get("model"):
                    AUDIO.put(key, data, used)
                else:
                    # 兜底到异模型：音色变了，所以不写缓存。但「这段是哪台出的」
                    # 仍要交给等待者，否则播放页显示的线路会与实际听到的对不上。
                    log.warning("TTS 兜底到异模型线路，本段不进缓存：期望=%s 实际=%s 线路=%s",
                                job.get("model"), actual, used)
                src = used
                with self.lock:
                    self.stats["done"] += 1
            except Exception as e:
                err = str(e)
                with self.lock:
                    self.stats["failed"] += 1
                log.error("TTS 合成失败 seg=%s voice=%s 字数=%s：%s",
                          job.get("seg", {}).get("idx"), job["voice"],
                          job.get("chars"), e)
            finally:
                with self.lock:
                    self.inflight -= 1
                    self.stats["busy"] = self.inflight > 0
                    self.stats["current"] = ""
            with self.lock:
                slot = self.pending.pop(key, None)
            if slot:
                slot["ok"] = err is None
                slot["err"] = err
                slot["data"] = data      # 未进缓存的成品也要能交给正在等的人
                slot["src"] = src
                slot["event"].set()

    def _put(self, pri, key, seg, voice, cfg, line, model=""):
        # itertools.count 的 next() 是原子的；原来的 self.seq += 1 在多请求线程下
        # 会撞出重复序号，而 PriorityQueue 在 (pri, seq) 相同时要去比较第三个元素
        # （dict），直接抛 TypeError。这个坑一直都在，只是请求少时碰不到。
        self.q.put((pri, next(self.seq),
                    {"key": key, "text": seg["text"], "voice": voice,
                     "cfg": cfg, "chars": seg["chars"], "line": line, "model": model}))

    def _enqueue(self, book_id, seg, voice, cfg, model, wait, line=""):
        """把一段排进队列。wait=False 时只排队不等待（预取）

        返回 (音频, 是否命中缓存, 产出线路的 url)。
        第三个值是给播放页显示「当前线路」用的 —— 必须是**实际产出的那台**，
        不能用配置里选的那台去猜（兜底时两者会不一样）。
        """
        key = seg_key(book_id, seg["idx"], seg["text"], voice, model, line)
        data = AUDIO.get(key)
        if data is not None:
            return data, True, AUDIO.src_of(key)
        with self.lock:
            slot = self.pending.get(key)
            if slot is None:
                slot = {"event": threading.Event(), "ok": False,
                        "err": None, "running": False, "data": None, "src": None}
                self.pending[key] = slot
                self._put(0 if wait else 1, key, seg, voice, cfg, line, model)
            elif wait and not slot["running"]:
                # 这段还排在预取后面，而用户正在等它 —— 补排一个高优先级条目插队
                self._put(0, key, seg, voice, cfg, line, model)
        if not wait:
            return None, False, None
        slot["event"].wait(timeout=cfg["timeout"])
        data = AUDIO.get(key)
        src = AUDIO.src_of(key)
        if data is None:
            data = slot.get("data")     # 兜底路径没有写缓存，从槽里取成品
            src = slot.get("src")
        if slot["err"]:
            raise TTSError(slot["err"])
        if data is None:
            raise TTSError("合成超时（%d 秒）" % cfg["timeout"])
        return data, False, src

    def ensure(self, book_id, seg, voice, cfg, model, line=""):
        """确保某段音频可用。缓存命中立即返回；否则排队并等待。

        返回 (bytes, from_cache, 产出线路的 url)"""
        return self._enqueue(book_id, seg, voice, cfg, model, wait=True, line=line)

    def prefetch(self, book_id, seg_list, voice, cfg, model, line=""):
        """把接下来几句排进队列（不等待），客户端播到时通常已就绪"""
        n = 0
        for seg in seg_list:
            key = seg_key(book_id, seg["idx"], seg["text"], voice, model, line)
            if AUDIO.get(key) is not None:
                continue
            with self.lock:
                if key in self.pending:
                    continue
            if self._enqueue(book_id, seg, voice, cfg, model, wait=False, line=line)[0] is None:
                n += 1
        return n


QUEUE = SynthQueue()


# ---------------------------------------------------------------- 流行音色样板
# 播放页的音色选择用这一套：给每种流行音色起个听得懂的名字，
# 而不是甩一个 pool_49 编号给用户。voice 是对应的音色 id。
# 顺序 = 展示顺序（女声在前，男声在后，中性收尾）。
STYLES = [
    {"name": "萝莉音", "slug": "loli", "voice": "pool_60", "text": "哥哥你终于回来啦，我等了你好久好久哦！"},
    {"name": "夹子音", "slug": "jiazi", "voice": "pool_58", "text": "哎呀，人家才没有生气呢，你别乱说嘛～"},
    {"name": "动漫音", "slug": "anime", "voice": "pool_57", "text": "喂！你怎么可以这样，实在是太不讲道理了！"},
    {"name": "猫女音", "slug": "catgirl", "voice": "pool_55", "text": "喵～主人今天想听什么故事呀？我陪你一起看。"},
    {"name": "甜妹音", "slug": "tianmei", "voice": "pool_54", "text": "今天的天气真好呀，我们出去走走吧！"},
    {"name": "清亮女声", "slug": "bright", "voice": "pool_53", "text": "你听，这是春天里第一声鸟叫，多清脆。"},
    {"name": "撒娇音", "slug": "sajiao", "voice": "pool_52", "text": "不要嘛，人家就想再听一会儿，就一小会儿。"},
    {"name": "林志玲音", "slug": "zhiling", "voice": "pool_51", "text": "不要紧张啦，慢慢来，我会一直陪着你的。"},
    {"name": "温柔女声", "slug": "wenrou", "voice": "pool_50", "text": "别怕，有我在呢，一切都会好起来的。"},
    {"name": "知性女声", "slug": "zhixing", "voice": "pool_49", "text": "这本书讲的是一段被时间掩埋的往事。"},
    {"name": "磁性女声", "slug": "cixing", "voice": "pool_46", "text": "夜色渐深，城市的灯一盏一盏亮了起来。"},
    {"name": "电台女声", "slug": "radiao", "voice": "pool_45", "text": "各位听众朋友，欢迎收听今晚的深夜电台。"},
    {"name": "夜听女声", "slug": "yeting", "voice": "pool_41", "text": "有些话，白天说不出口，只好留到夜里讲。"},
    {"name": "空灵女声", "slug": "kongling", "voice": "pool_39", "text": "风从山谷里吹过来，带着一点凉意和花香。"},
    {"name": "御姐音", "slug": "yujie", "voice": "pool_35", "text": "这件事交给我，你不用担心，我会处理好的。"},
    {"name": "女王音", "slug": "nvwang", "voice": "pool_33", "text": "记住，从今往后，没有人可以再命令你。"},
    {"name": "正太音", "slug": "zhengtai", "voice": "pool_28", "text": "我才不是小孩子呢，我已经长大了！"},
    {"name": "少年音", "slug": "shaonian", "voice": "pool_27", "text": "等我长大以后，一定要去很远很远的地方看看。"},
    {"name": "阳光少年", "slug": "yangguang", "voice": "pool_25", "text": "走啊，一起去打球，今天天气这么好！"},
    {"name": "青年音", "slug": "qingnian", "voice": "pool_24", "text": "其实我一直都想告诉你，只是没找到机会。"},
    {"name": "播音腔", "slug": "boyin", "voice": "pool_21", "text": "现在播报一条重要消息，请注意查收。"},
    {"name": "清朗男声", "slug": "qinglang", "voice": "pool_20", "text": "清晨的第一缕阳光，照进了老屋的窗棂。"},
    {"name": "书生音", "slug": "shusheng", "voice": "pool_19", "text": "书中自有黄金屋，读书这件事，急不得。"},
    {"name": "温润男声", "slug": "wenrun", "voice": "pool_17", "text": "你不必急着回答，我等你慢慢想清楚。"},
    {"name": "新闻播报", "slug": "xinwen", "voice": "pool_13", "text": "据最新消息，本次会议已于今日上午闭幕。"},
    {"name": "磁性男声", "slug": "nancixing", "voice": "pool_09", "text": "很多年以后，我才明白那句话真正的意思。"},
    {"name": "大叔音", "slug": "dashu", "voice": "pool_06", "text": "年轻人啊，做事要沉得住气，别急。"},
    {"name": "低音炮", "slug": "diyinpao", "voice": "pool_04", "text": "这条路很长，但只要走下去，总会到头的。"},
    {"name": "总裁音", "slug": "zongcai", "voice": "pool_02", "text": "这个项目，三天之内我要看到结果。"},
    {"name": "帝王音", "slug": "diwang", "voice": "pool_01", "text": "朕意已决，尔等不必再议。"},
    {"name": "中性音", "slug": "zhongxing", "voice": "pool_30", "text": "故事要从很多年前的那个冬天说起。"},
    # ---- IndexTTS-2 官方自带的音色（voice_XX，source=official）----
    # 这批是模型自带的参考音，和 pool_XX 不共用；官方没给名字，
    # 名字是按实测基频 + 频谱重心起的（voice_01~09、11、12，没有 voice_10）。
    # 实测：f0 114.8~338.0Hz；voice_02/05/08 源峰值会超 0dBFS，
    # 已在 tts_server.py 的 transcode 里按峰值整体降增益处理。
    {"name": "清越女声", "slug": "it2-01", "voice": "voice_01", "text": "山间的风穿过竹林，声音清脆又干净。"},
    {"name": "脆亮女声", "slug": "it2-02", "voice": "voice_02", "text": "你听，这是今年春天的第一声鸟鸣！"},
    {"name": "灵动女声", "slug": "it2-03", "voice": "voice_03", "text": "你看那边，好像有什么东西在动。"},
    {"name": "绵柔女声", "slug": "it2-04", "voice": "voice_04", "text": "别怕，我就在这儿，哪儿也不去。"},
    {"name": "豪爽男声", "slug": "it2-05", "voice": "voice_05", "text": "行！这事就这么定了，谁也别再磨叽。"},
    {"name": "暖调中性", "slug": "it2-06", "voice": "voice_06", "text": "炉子上的水开了，屋里慢慢暖和起来。"},
    {"name": "苍劲男声", "slug": "it2-07", "voice": "voice_07", "text": "他站在山顶上，看着云一层层地压过来。"},
    {"name": "甜脆女声", "slug": "it2-08", "voice": "voice_08", "text": "哇，这个好好看呀，我要拍下来！"},
    {"name": "暖阳女声", "slug": "it2-09", "voice": "voice_09", "text": "午后的阳光照进来，落在桌角那本书上。"},
    {"name": "飒爽女声", "slug": "it2-11", "voice": "voice_11", "text": "准备好了吗？我们出发，别回头。"},
    {"name": "深沉男声", "slug": "it2-12", "voice": "voice_12", "text": "很多事情，等你长大了自然就明白了。"},
]


# 备用线路（GPT-SoVITS v2）用「自己的一套」音色样板。
#
# .16 的 pool_XX 虽然和 .3/.6 是同一批参考音频，但两个模型出来的音色差别明显；
# 而且 GPT-SoVITS 对参考音频的咬字/音高更敏感，直接沿用主线的名字会让人以为
# 是同一个声音。所以这条线路单独给一套命名，选出来的音色也刻意错开主线的池子。
# 全部 16 个都实测过：峰值 -20.5~-3.0dB，无削顶、无爆音。
STYLES_GSV = [
    {"name": "古风男声", "slug": "gsv-gufeng",   "voice": "pool_03", "text": "江湖路远，山高水长，后会有期。"},
    {"name": "沧桑男声", "slug": "gsv-cangsang", "voice": "pool_05", "text": "这些年走过不少地方，见过不少人。"},
    {"name": "醇厚男声", "slug": "gsv-chunhou",  "voice": "pool_08", "text": "时间会把很多东西慢慢磨平，也会留下最真的。"},
    {"name": "儒雅男声", "slug": "gsv-ruya",     "voice": "pool_12", "text": "读书不必求快，一字一句地读下去就好。"},
    {"name": "沉稳男声", "slug": "gsv-chenwen",  "voice": "pool_14", "text": "遇事不要慌，先把最要紧的那一步做好。"},
    {"name": "爽朗男声", "slug": "gsv-shuanglang", "voice": "pool_16", "text": "走吧，今天天气这么好，别闷在屋里了。"},
    {"name": "质朴男声", "slug": "gsv-zhipu",    "voice": "pool_22", "text": "我这个人不太会说漂亮话，只讲实在的。"},
    {"name": "明亮男声", "slug": "gsv-mingliang", "voice": "pool_29", "text": "天亮了，窗外传来第一声鸟叫。"},
    {"name": "高音男声", "slug": "gsv-gaoyin",   "voice": "pool_31", "text": "这一场比赛，我们一定要赢下来！"},
    {"name": "柔美女声", "slug": "gsv-roumei",   "voice": "pool_34", "text": "夜色很好，我陪你坐一会儿吧。"},
    {"name": "温婉女声", "slug": "gsv-wenwan",   "voice": "pool_36", "text": "别急，慢慢说，我一直都在听。"},
    {"name": "醇美女声", "slug": "gsv-chunmei",  "voice": "pool_43", "text": "有些故事，要等到很多年以后才听得懂。"},
    {"name": "清甜女声", "slug": "gsv-qingtian", "voice": "pool_47", "text": "今天的风是甜的，你闻到了吗？"},
    {"name": "甜润女声", "slug": "gsv-tianrun",  "voice": "pool_48", "text": "给你留了一块蛋糕，在冰箱里呢。"},
    {"name": "悠远女声", "slug": "gsv-youyuan",  "voice": "pool_56", "text": "风从很远的地方吹来，带着旧日的味道。"},
    {"name": "高昂女声", "slug": "gsv-gaoang",   "voice": "pool_59", "text": "太好了！我们终于等到这一天了！"},
]


# 备用二线路（Piper，跑在NAS 192.0.2.210 上）用的一套。
#
# Piper 官方的中文模型一共只有 3 个说话人（huayan / chaowen / xiao_ya），
# 所以这里就只有 3 项 —— 和主线 42 项、备用一 16 项比是断崖式地少，
# 这是把备用二放在这台 4 核小机器上、换「真能实时」的代价。
#
# 名字按实测基频 + 频谱重心起（和主线/备用一都不重名）：
#   huayan  f0 214.1Hz centroid 1473Hz  女声偏暖
#   chaowen f0 150.0Hz centroid 1657Hz  男声
#   xiao_ya f0 265.7Hz centroid 2274Hz  女声偏亮
# 三个都实测无削顶（Piper 输出归一化到 0dBFS，已在 piper_server.py 里
# 按峰值整体降到 0.94 再编码，避免 opus 解码过冲）。
STYLES_PIPER = [
{"name": "舒缓女声", "slug": "pp-huayan",  "voice": "piper_huayan",  "text": "他站在山顶上，看着云一层层地压过来，心里忽然安静了下来。"},
{"name": "清醇男声", "slug": "pp-chaowen", "voice": "piper_chaowen", "text": "这些年走过不少地方，见过不少人，话也就慢慢少了。"},
{"name": "娇俏女声", "slug": "pp-xiaoya",  "voice": "piper_xiaoya",  "text": "哇，这个好好看呀，我要拍下来！"},
]


def _style_table(model=None):
    """按线路的模型挑样板表：GPT-SoVITS / Piper 各走自己那套，其余走流行音色样板。"""
    m = (model or "").lower()
    if "sovits" in m or "gpt" in m:
        return STYLES_GSV
    if "piper" in m:
        return STYLES_PIPER
    return STYLES


def style_name(model, vid):
    """「流行音色样板」为这个音色起的中文名（没收录就返回空串）。

    样板表是按**模型**分的：IndexTTS-2 用 STYLES，GPT-SoVITS 用 STYLES_GSV，
    Piper 用 STYLES_PIPER。
    """
    if not vid:
        return ""
    for st in _style_table(model):
        if st.get("voice") == vid:
            return st.get("name") or ""
    return ""


def display_name(model, vid, server_label="", renamed=""):
    """音色的统一显示名 —— 播放页和后台「音色管理」必须用同一个口径。

    优先级：后台显式改名 > 样板表的中文名 > 服务器标签 > 音色 ID。

    为什么不能直接用服务器标签：TTS 主机给的标签经常毫无信息量 ——
    IndexTTS-2 全是 `#01`/`#02`，GPT-SoVITS 60 个音色里 57 个都叫「男声」。
    而样板表里有「萝莉音」「古风男声」这种真正能认人的名字。
    以前只有播放页走样板表、后台走服务器标签，同一个音色两边名字对不上，
    管理员在后台根本不知道自己管的是哪个音色。
    """
    if (renamed or "").strip():
        return renamed.strip()
    return style_name(model, vid) or (server_label or "") or vid


def _admin_visible(url, voices, model=""):
    """套用「听书管理」的删除/停用/改名，返回这条线路**可见**的音色。

    `/voices` 是机器的事实，听书管理是站点的策略（谁被删了、谁被停用、叫什么名字）。
    播放页的音色列表必须走这一层 —— 否则后台删掉的音色照样出现在选音色里，
    用户选了它，服务端又按「已停用」把它换掉，最后听到的是另一个音色、
    甚至是另一条线路产出的音频（见 app._listen_default_voice）。

    这里刻意用惰性 import：tts 是被 listen_admin 反向依赖的，
    放在函数里可以彻底避免任何导入顺序的坑。
    """
    try:
        import listen_admin
        ov = listen_admin.apply_overrides(url, voices, model=model)
    except Exception:
        return list(voices)
    return [v for v in ov if v.get("on")]


def _visible_union(cfg=None, force=False):
    """所有线路可见音色的并集（已套用管理层的删除/停用/改名）。"""
    cfg = cfg or settings()
    out = {}
    for srv in active_servers(cfg):
        raw = voices_of_server(srv, cfg, force=force)
        white = white_of(srv, cfg)
        if white:
            keep = set(white)
            raw = [v for v in raw if v.get("id") in keep]
        for v in _admin_visible(srv["url"], raw, srv.get("model")):
            out.setdefault(v["id"], v)
    return out


def _by_sample_order(model, items):
    """按「流行音色样板」表的先后排序，**不做过滤** —— 表里没有的排在后面。

    ★ 样板表（STYLES / STYLES_GSV / STYLES_PIPER）只负责两件事：
      起中文名（display_name 用它）和决定这个顺序。
      它**不是、也不能当白名单** —— 见 styles() / line_info() 里的说明。

    表里的排列本来就有「更常见的音色放前面」这层意思，保留它能让播放页
    第一条仍然是大家熟悉的那几个，同时新放出来的音色不会插队。
    Python 的 sorted 是稳定排序，所以表外的音色保持原有先后。
    """
    order = {st["voice"]: i for i, st in enumerate(_style_table(model))}
    n = len(order)
    return sorted(items, key=lambda v: order.get(v.get("id"), n))


def styles(cfg=None, force=False):
    """播放页的音色清单（用户没指定线路时用它）：各线路可见音色的并集。

    ★ 这里以前是拿样板表和可见音色**取交集**的，于是样板表变成了第二道白名单
      ——而且是藏在代码里、后台看不见也管不着的那种。后果实测：后台「主线一」
      有 51 个音色，播放页只给 30 个；「备用一」有 22 个，播放页只给 10 个。
      而被挡掉的那些音色合成完全正常：服务端校验音色走的是
      listen_admin.voices_for_lines()，那条路径从来就没有样板表过滤。
      样板表的本职只是**起名**，apply_overrides 里已经通过 display_name 做好了
      （优先级：后台改名 > 样板表中文名 > 服务器标签 > id），不该再兼职过滤。

    过滤该由谁做：后台「听书管理」的启用/停用/删除 + 每台服务器的音色白名单。
    那两个开关用户看得见、改得动；样板表不行，所以它不能当白名单。
    """
    cfg = cfg or settings()
    items = _by_sample_order(cfg.get("model"), list(_visible_union(cfg, force=force).values()))
    return [{"name": v.get("name") or v.get("id") or "",
             "voice": v.get("id"),
             "gender": v.get("gender") or "",
             "f0": v.get("f0")} for v in items if v.get("id")]


def line_info(cfg=None, force=False):
    """线路清单：一台启用的 TTS 服务器 = 一条线路。

    每条线路带上这条线路**后台可见的全部音色** —— .3/.6 跑 IndexTTS-2，
    .16 跑 GPT-SoVITS v2，各机音色集不同，所以「选线路」和「选音色」必须联动，
    不能把某条线路没有的音色列给它。

    ★ 这里以前额外拿样板表取交集，导致「后台看得见、播放页选不到」：
      主线一 51 → 30、备用一 22 → 10。已去掉，现在播放页的条数与后台一致。
      仍然保留的两层过滤是必须的：
        · white_of()      —— 每台服务器配的音色白名单
        · _admin_visible()—— 听书管理里的删除/停用/改名
      这两层后台都能看见和修改，去掉哪一层都会让「用户选了却被服务端换掉」。
    """
    cfg = cfg or settings()
    out = []
    for srv in active_servers(cfg):
        vs = voices_of_server(srv, cfg, force=force)
        keep = set(v.get("id") for v in vs)
        white = white_of(srv, cfg)
        if white:
            keep &= set(white)          # 白名单之外的不算这条线路能给的
        # ★ 再套一层听书管理：后台在这条线路上删掉/停用的音色，这里也必须消失，
        # 否则用户选中它，服务端又会把它换掉，听起来就是「音色自己变了」。
        visible = [v for v in _admin_visible(srv["url"], vs, srv.get("model"))
                   if v.get("id") in keep]
        visible = _by_sample_order(srv.get("model") or cfg.get("model"), visible)
        items = [{"name": v.get("name") or v.get("id") or "",
                  "voice": v.get("id"),
                  "gender": v.get("gender") or "",
                  "f0": v.get("f0")} for v in visible if v.get("id")]
        out.append({"id": srv.get("url"), "name": srv.get("name") or srv.get("url"),
                    "url": srv.get("url"), "model": srv.get("model") or cfg.get("model") or "",
                    "voices": items, "count": len(items),
                    "health": _is_healthy(srv["url"])})
    return out


def queue_stats():
    return {"queued": QUEUE.q.qsize(), "busy": QUEUE.stats["busy"],
            "current": QUEUE.stats["current"], "done": QUEUE.stats["done"],
            "failed": QUEUE.stats["failed"],
            # 并行合成：workers=线程数，inflight=正在合成的段数。
            # 段间空档那类问题（合成跟不上播放）全靠这两个数看是否已经把
            # 并行度吃满。
            "workers": QUEUE.workers, "inflight": QUEUE.inflight,
            # 最近一段实际被派到哪台服务器。音色跳变那类问题（同一音色在不同
            # 模型上是不同声音）全靠它才看得见，所以要暴露出来。
            "line": QUEUE.stats.get("line") or ""}


def cache_stats(book_id=None):
    """内存音频缓存的现状（不含磁盘占用，听书不落盘）"""
    return AUDIO.stats()
