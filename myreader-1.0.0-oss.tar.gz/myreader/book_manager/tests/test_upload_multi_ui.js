// 一次上传多本 —— 界面路径。
//
// 需求：上传书籍时可以一次上传多本，但**每本**不要超过用户所在分组设定的上传权限大小。
//
// 这个测试盯的是弹窗里的行为（服务端「逐本判定」的权威性由
// tests/test_upload_multi.py 覆盖）：
//   1. 文件选择框是 multiple 的；
//   2. 选好后逐行列出文件名与体积，**一行一本**；
//   3. 分组上限（upload_max_mb）是逐本比的：超限那本当场标红、不进上传队列，
//      按钮上如实写出「上传 N 本（另 M 本超限，将跳过）」；
//   4. 点上传 → 一本一本传，只有合格的那些真的进了库（数量、名字都对得上）；
//   5. 有跳过/失败时**弹窗不关**（开关是 #modal-mask 上的 hidden 类，
//      不是 .modal 在不在 —— 那个元素一直在，拿它判断等于没判），每本的结果留在眼前，按钮变成「关闭」
//      —— 绝不能留个「再来一次」把已成功的重传一遍（那会凭空多出几本）；
//   6. 窄屏（390px）+ 超长书名：清单行必须省略号截断，弹窗不许被撑破
//      （§14.83 同款坑：flex 子项 min-width:auto 会把长文件名顶出去）。
//
// 用完的账号是测试账号 test（uid 45），造出来的书按**精确 id** 删掉、远端文件按
// 精确路径删掉，跑完不留痕。
const { chromium } = require('playwright-core');
const { execSync } = require('child_process');
const CHROME = '/srv/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome';
const ROOT = '/srv/myreader/book_manager';
const BASE = 'https://127.0.0.1:9000';
const PREFIX = 'zzupui_';       // 本测试造的书名前缀（清理时按它 + owner 精确定位）

let pass = 0, fail = 0;
const ck = (n, ok, extra) => {
  if (ok) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (extra ? '  → ' + extra : '')); }
};
const py = (c) => execSync('venv/bin/python -', { cwd: ROOT, encoding: 'utf8', input: c }).trim();
const jpy = (c) => JSON.parse(py(c));

// 造出来的书（精确 id）与远端文件，最后一起清
const made = new Set();

function clean() {
  if (!made.size) return;
  const ids = [...made];
  console.log('\n清理 ' + ids.length + ' 本测试书…');
  py(`
import sys
sys.path.insert(0, '${ROOT}')
import db, ftp_service
for bid in ${JSON.stringify(ids)}:
    b = db.q('SELECT path FROM books WHERE id=?', (bid,), one=True)
    if b and b['path']:
        try: ftp_service.delete(b['path'])
        except Exception: pass
    db.ex('DELETE FROM shelves WHERE book_id=?', (bid,))
    # ★ 日志表也要清：上传会写 audit_logs（「上传书籍《…》」）与 file_logs
    db.ex('DELETE FROM audit_logs WHERE target_id=? AND target_type=?', (bid, 'book'))
    db.ex('DELETE FROM file_logs WHERE book_id=?', (bid,))
    db.ex('DELETE FROM books WHERE id=?', (bid,))
print('done')`);
}

// 本测试书名前缀 + 该账号名下的书 id（只认前缀，别误伤真人数据）
const booksOf = () => jpy(`
import sys, json
sys.path.insert(0, '${ROOT}')
import db
print(json.dumps([b['id'] for b in db.q(
    "SELECT id FROM books WHERE owner_id=45 AND title LIKE '${PREFIX}%'")]))`);

(async () => {
  const info = jpy(`
import sys, json
sys.path.insert(0, '${ROOT}')
import db, auth
u = db.q("SELECT * FROM users WHERE id=45", one=True)
print(json.dumps({"tok": auth.create_token(u), "user": dict(u)}))`);

  const b = await chromium.launch({ executablePath: CHROME, args: ['--no-sandbox'] });

  // 一次性把弹窗打开、塞进文件、看清单状态
  const openWith = async (page, files) => {
    await page.evaluate(() => { closeModal(); showUpload(); });
    await page.waitForSelector('#up-file', { timeout: 10000 });
    await page.setInputFiles('#up-file', files);
    await page.waitForTimeout(400);
    return page.evaluate(() => {
      const rows = Array.from(document.querySelectorAll('#up-list .up-row'));
      const btn = document.getElementById('up-go');
      const modal = document.querySelector('.modal');
      return {
        multiple: document.getElementById('up-file').multiple === true,
        n: rows.length,
        names: rows.map(r => r.querySelector('.up-name').textContent.trim()),
        bad: rows.filter(r => r.classList.contains('bad')).length,
        ok: rows.filter(r => r.classList.contains('ok')).length,
        sizes: rows.map(r => r.querySelector('.up-size').textContent.trim()),
        btn: btn ? btn.textContent.trim() : '',
        btnDisabled: btn ? btn.disabled : null,
        modalW: modal ? Math.round(modal.getBoundingClientRect().width) : 0,
        rowW: rows.length ? Math.round(rows[0].getBoundingClientRect().width) : 0,
        docOver: document.documentElement.scrollWidth - document.documentElement.clientWidth,
      };
    });
  };

  try {
    const ctx = await b.newContext({ ignoreHTTPSErrors: true, viewport: { width: 390, height: 800 } });
    await ctx.addInitScript(([t, u]) => {
      localStorage.setItem('bm_token', t); localStorage.setItem('bm_user', u);
    }, [info.tok, JSON.stringify(info.user)]);
    const page = await ctx.newPage();
    const errs = [];
    page.on('pageerror', e => errs.push(String(e).slice(0, 120)));
    await page.goto(BASE + '/', { waitUntil: 'domcontentloaded' });
    await page.waitForFunction(() => typeof showUpload === 'function', null, { timeout: 20000 });
    // 分组的单本上限：这里从 10MB 临时改成 1MB，好用小文件就测到「逐本超限」
    // （服务端真正的上限判定在 test_upload_multi.py 里测；这里只验界面口径）
    await page.evaluate(() => { USER.limits = Object.assign({}, USER.limits, { upload_max_mb: 1 }); });

    const small = (n) => ({ name: n, mimeType: 'text/plain', buffer: Buffer.alloc(200 * 1024, 65) });
    const big = (n) => ({ name: n, mimeType: 'text/plain', buffer: Buffer.alloc(1536 * 1024, 66) });

    console.log('== 1. 选三个文件（两本合格 + 一本超限）==');
    const f1 = PREFIX + '甲 - 作者.txt', f2 = PREFIX + '乙 - 作者.txt', f3 = PREFIX + '超大 - 作者.txt';
    let s = await openWith(page, [small(f1), big(f3), small(f2)]);
    ck('文件选择框是 multiple（能一次选多本）', s.multiple);
    ck('选了三本就列出三行', s.n === 3, '实际 ' + s.n);
    ck('三行的文件名与选择顺序一致', JSON.stringify(s.names) === JSON.stringify([f1, f3, f2]), JSON.stringify(s.names));
    ck('体积逐行显示', s.sizes.length === 3 && s.sizes.every(x => /B|KB|MB/.test(x)), JSON.stringify(s.sizes));
    ck('超限的那本标红（只有一本）', s.bad === 1, '标红 ' + s.bad + ' 行');
    ck('按钮如实写出「上传 2 本」并说明会跳过 1 本',
      /上传 2 本/.test(s.btn) && /跳过/.test(s.btn), s.btn);
    ck('按钮可点', s.btnDisabled === false);
    ck('窄屏下没有横向溢出', s.docOver <= 0, '溢出 ' + s.docOver + 'px');
    ck('清单行没有撑破弹窗', s.rowW <= s.modalW, `行 ${s.rowW} vs 弹窗 ${s.modalW}`);

    console.log('\n== 2. 点上传：只传合格的两本 ==');
    const before = booksOf();
    await page.click('#up-go');
    // 等按钮变成「关闭」（说明这一批跑完了；成功+跳过时弹窗不关）
    await page.waitForFunction(
      () => { const b2 = document.getElementById('up-go'); return b2 && /关闭/.test(b2.textContent); },
      null, { timeout: 60000 });
    await page.waitForTimeout(600);
    const after = booksOf();
    after.forEach(id => made.add(id));
    const added = after.filter(id => !before.includes(id));
    ck('只新建了 2 本（超限那本没上传）', added.length === 2, '新建 ' + added.length + '：' + JSON.stringify(added));
    const st = await page.evaluate(() => {
      const rows = Array.from(document.querySelectorAll('#up-list .up-row'));
      const btn = document.getElementById('up-go');
      return {
        n: rows.length,
        okN: rows.filter(r => r.classList.contains('ok')).length,
        badN: rows.filter(r => r.classList.contains('bad')).length,
        texts: rows.map(r => r.querySelector('.up-size').textContent.trim()),
        btn: btn.textContent.trim(),
        btnOnclick: btn.getAttribute('onclick') || '',
        modalOpen: !!document.getElementById('modal-mask') &&
          !document.getElementById('modal-mask').classList.contains('hidden'),
        toast: (document.getElementById('toast') || {}).textContent || '',
      };
    });
    ck('有跳过时弹窗不关（结果留在眼前）', st.modalOpen === true);
    ck('三行结果都在：两行成功 + 一行跳过', st.n === 3 && st.okN === 2 && st.badN === 1,
      `共 ${st.n} 行，成功 ${st.okN}，失败/跳过 ${st.badN}`);
    ck('跳过那行写明原因（超过本组单本上限）', /超过本组单本上限/.test(st.texts[1]), st.texts[1]);
    ck('按钮变成「关闭」，不再能重传一遍（避免凭空多出几本）',
      st.btn === '关闭' && /closeModal/.test(st.btnOnclick), st.btn + ' / ' + st.btnOnclick);
    ck('提示写明成功与跳过', /成功 2 本/.test(st.toast) && /跳过 1 本/.test(st.toast), st.toast);

    console.log('\n== 3. 全部合格：传完自动关弹窗 ==');
    const f4 = PREFIX + '丙 - 作者.txt', f5 = PREFIX + '丁 - 作者.txt';
    s = await openWith(page, [small(f4), small(f5)]);
    ck('两本都合格时按钮写「上传 2 本」且不提示跳过', /^上传 2 本$/.test(s.btn), s.btn);
    const before2 = booksOf();
    await page.click('#up-go');
    await page.waitForFunction(
      () => document.getElementById('modal-mask').classList.contains('hidden'),
      null, { timeout: 60000 });
    await page.waitForTimeout(600);
    const after2 = booksOf();
    after2.forEach(id => made.add(id));
    const added2 = after2.filter(id => !before2.includes(id));
    ck('两本都进了库', added2.length === 2, '新建 ' + added2.length);
    ck('弹窗自动关闭', await page.evaluate(
      () => document.getElementById('modal-mask').classList.contains('hidden')));
    const toast2 = await page.evaluate(() => (document.getElementById('toast') || {}).textContent || '');
    ck('提示写明已上传 2 本', /已上传 2 本/.test(toast2), toast2);

    console.log('\n== 4. 超长书名 + 窄屏：清单行必须省略号截断 ==');
    const longName = PREFIX + '这是一个非常非常长的中文书名'.repeat(6) + ' - 作者.txt';
    s = await openWith(page, [small(longName)]);
    ck('长书名也只占一行（省略号截断，行宽不超弹窗）', s.rowW <= s.modalW, `行 ${s.rowW} vs 弹窗 ${s.modalW}`);
    ck('长书名的窄屏下页面仍无横向溢出', s.docOver <= 0, '溢出 ' + s.docOver + 'px');
    await page.evaluate(() => closeModal());

    ck('整页没有 JS 报错', errs.length === 0, errs.join(' | '));
    await ctx.close();
  } finally {
    await b.close();
    clean();
  }

  console.log('\n通过 ' + pass + '，失败 ' + fail);
  process.exit(fail ? 1 : 0);
})();
