#!/bin/bash
# 看门狗：服务进程还活着但已经无响应（表现为端口在监听、连接却一直挂着）时，
# systemd 的 Restart=always 不会触发，只能靠外部探测发现。连续两次探测失败才重启，
# 避免网络抖动导致误杀。
STATE=/tmp/bookmgr-watchdog.fail
URL=https://127.0.0.1:9000/api/health
LOG=/srv/myreader/book_manager/data/watchdog.log

code=$(curl -sk -m 10 -o /dev/null -w "%{http_code}" "$URL" 2>/dev/null)

if [ "$code" = "200" ] || [ "$code" = "404" ]; then
  # 404 也算活着（说明 HTTP 栈在正常应答，只是这个路径不存在）
  rm -f "$STATE"
  exit 0
fi

n=$(cat "$STATE" 2>/dev/null || echo 0)
n=$((n + 1))
echo "$n" > "$STATE"
echo "$(date '+%F %T') 探测失败 code=$code 连续第 $n 次" >> "$LOG"

if [ "$n" -ge 2 ]; then
  echo "$(date '+%F %T') 连续 $n 次无响应，重启 bookmgr.service" >> "$LOG"
  export XDG_RUNTIME_DIR=/run/user/1000 DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/1000/bus
  systemctl --user restart bookmgr.service
  rm -f "$STATE"
fi
exit 0
