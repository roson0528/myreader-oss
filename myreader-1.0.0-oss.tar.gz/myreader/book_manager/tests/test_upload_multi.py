# -*- coding: utf-8 -*-
"""一次上传多本 + 上限**逐本**判定（分组权限 upload_max_mb）后端回归。

需求：上传书籍时可以一次上传多本，但**每本**不要超过用户所在分组设定的上传权限大小。

这条需求最容易做错的地方是「拿这一批的总和去卡」—— 分组权限里根本没有
「总量」这个限制，`upload_max_mb` 说的是**一本**。所以本测试的核心断言是：
在「单本 1 MB」的分组下，三本各 0.4 MB（合计 1.2 MB）**三本都必须成功**。

覆盖：
  1. 逐本判定：三本各 0.4MB 合计超 1MB → 全部成功（不是按总和拒绝）；
  2. 超限被拒 413，两条路径都要拦：
       - Content-Length 快速拒绝（大文件，连请求体都不读）
       - 边写边判（1~2MB 的文件：Content-Length 过得了、写到一半必须中断）
  3. 被拒时 UPLOAD_DIR 不留半截文件、也不建书；
  4. 多本依次上传：各自成书、各自入书架、各自写审计；
  5. 精确等于上限通过、略超上限被拒（边界）；
  6. 书架配额满了再传 → 400，且不落盘、不建书；
  7. 没有「私人书架」权限的分组 → 403。

安全：只建**临时分组 + 临时账号**（自带 upload_max_mb=1），跑完按精确 id 删账号、
分组、书、书架行，并按精确远端路径删掉上传产生的文件；UPLOAD_DIR 里只清
本测试 uid 前缀的临时文件。不碰任何真实分组设置、不碰真实用户数据。
运行：venv/bin/python tests/test_upload_multi.py
"""
import json
import os
import ssl
import sys
import uuid
import urllib.request
import urllib.error
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
os.chdir(_ROOT)
import config, db, auth, ftp_service  # noqa: E402

BASE = 'https://127.0.0.1:9000'
CTX = ssl._create_unverified_context()

_pass = [0]
_fail = [0]
_books = []          # 本测试建出来的书 id
_remotes = []        # 本测试写上去的远端路径
_users = []
_groups = []


def check(name, ok, extra=''):
    if ok:
        _pass[0] += 1
        print('  [OK] %s' % name + ('  %s' % extra if extra else ''))
    else:
        _fail[0] += 1
        print('  [FAIL] %s' % name + ('  %s' % extra if extra else ''))


def req(path, token=None, method='POST', raw=None, ctype=None):
    h = {'X-BM-No-Push': '1'}     # 测试请求：服务端别真发 Server酱
    if token:
        h['Authorization'] = 'Bearer ' + token
    if ctype:
        h['Content-Type'] = ctype
    r = urllib.request.Request(BASE + path, data=raw, headers=h, method=method)
    try:
        with urllib.request.urlopen(r, context=CTX, timeout=180) as resp:
            return resp.status, resp.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read()


def multipart(field, filename, content, extra_fields=None):
    """手工拼 multipart/form-data：测试里不想引第三方依赖"""
    b = '----uploadMulti' + uuid.uuid4().hex
    out = []
    for k, v in (extra_fields or {}).items():
        out.append(('--%s\r\nContent-Disposition: form-data; name="%s"\r\n\r\n%s\r\n'
                    % (b, k, v)).encode())
    out.append(('--%s\r\nContent-Disposition: form-data; name="%s"; filename="%s"\r\n'
                'Content-Type: application/octet-stream\r\n\r\n' % (b, field, filename)).encode())
    out.append(content)
    out.append(('\r\n--%s--\r\n' % b).encode())
    return b''.join(out), 'multipart/form-data; boundary=' + b


def up(token, filename, body, extra=None):
    """上传一本，返回 (HTTP 状态, 响应文本)"""
    raw, ctype = multipart('file', filename, body, extra)
    st, resp = req('/api/upload', token=token, raw=raw, ctype=ctype)
    try:
        return st, resp.decode('utf-8', 'replace')
    except Exception:
        return st, ''


def up_rec(token, filename, body, extra=None):
    """上传一本并**记下书的 id** —— 清理要按精确 id 清。"""
    st, txt = up(token, filename, body, extra)
    if st == 200:
        try:
            bid = int(json.loads(txt)['id'])
            _books.append(bid)
        except Exception:
            pass
    return st, txt


def book_of(uid, title_like):
    return db.q("SELECT * FROM books WHERE owner_id=? AND title LIKE ? ORDER BY id DESC",
                (uid, '%' + title_like + '%'), one=True)


def tmp_files(uid):
    d = config.UPLOAD_DIR
    if not os.path.isdir(d):
        return []
    pre = 'up_%d_' % uid
    return [f for f in os.listdir(d) if f.startswith(pre)]


def cleanup():
    for bid in _books:
        try:
            b = db.q('SELECT path FROM books WHERE id=?', (bid,), one=True)
            if b and b['path']:
                ftp_service.delete(b['path'])
        except Exception as e:
            print('  (清理远端失败 %s: %s)' % (bid, e))
        db.ex('DELETE FROM shelves WHERE book_id=?', (bid,))
        # ★ 日志表也要清：上传会写 audit_logs（「上传书籍《…》」）和
        #   file_logs（source=web）。只删书的话，库里会留下一串指向已删书籍的记录。
        db.ex('DELETE FROM audit_logs WHERE target_id=? AND target_type=?', (bid, 'book'))
        db.ex('DELETE FROM file_logs WHERE book_id=?', (bid,))
        db.ex('DELETE FROM books WHERE id=?', (bid,))
    for uid in _users:
        for f in tmp_files(uid):
            try:
                os.remove(os.path.join(config.UPLOAD_DIR, f))
            except OSError:
                pass
        db.ex('DELETE FROM shelves WHERE user_id=?', (uid,))
        db.ex('DELETE FROM users WHERE id=?', (uid,))
    for gid in _groups:
        db.ex('DELETE FROM user_groups WHERE id=?', (gid,))


def main():
    gid = db.add_group('zzup_%s' % uuid.uuid4().hex[:6],
                       can={'private_shelf': True}, limits={'upload_max_mb': 1})
    _groups.append(gid)
    gid_noperm = db.add_group('zzup_np_%s' % uuid.uuid4().hex[:6], can={}, limits={})
    _groups.append(gid_noperm)

    def mk_user(group_id):
        uname = 'zzup_%s' % uuid.uuid4().hex[:8]
        uid = db.ex("INSERT INTO users (username,password_hash,role,enabled,group_id,quota,created_at) "
                    "VALUES (?,?,?,?,?,?,?)",
                    (uname, auth.hash_password('zz' + uuid.uuid4().hex), 'user', 1, group_id, 50, db.now()))
        _users.append(uid)
        return db.q('SELECT * FROM users WHERE id=?', (uid,), one=True)

    u = mk_user(gid)
    tok = auth.create_token(u)
    u2 = mk_user(gid_noperm)
    tok2 = auth.create_token(u2)

    print('== 0. 前置：分组上限 = 1 MB ==')
    lim = auth.limits_of(db.q('SELECT * FROM users WHERE id=?', (u['id'],), one=True))
    check('测试分组读到的 upload_max_mb 是 1', int(lim.get('upload_max_mb') or 0) == 1, str(lim.get('upload_max_mb')))

    print('\n== 1. 多本依次上传，各自成书、入书架、写审计 ==')
    names = ['zzup甲', 'zzup乙', 'zzup丙']
    body = b'A' * int(0.4 * 1024 * 1024)
    oks = 0
    bids = []
    for i, nm in enumerate(names):
        st, txt = up_rec(tok, '%s - 测试作者.txt' % nm, body)
        if st == 200:
            oks += 1
        else:
            print('     上传《%s》失败：%s %s' % (nm, st, txt[:120]))
    check('三本各 0.4MB 全部成功（合计 1.2MB > 单本 1MB，但**不是**按总和卡）',
          oks == 3, '成功 %d/3' % oks)
    for nm in names:
        b = book_of(u['id'], nm)
        if b:
            bids.append(b['id'])
    check('三本都真的建出来了', len(bids) == 3, '第 %s' % bids)
    check('三本都进了上传者的书架',
          db.q('SELECT COUNT(*) c FROM shelves WHERE user_id=? AND book_id IN (%s)'
               % ','.join('?' * len(bids)), (u['id'],) + tuple(bids), one=True)['c'] == 3 if bids else False)
    check('三本各自写了审计',
          db.q("SELECT COUNT(*) c FROM audit_logs WHERE user_id=? AND action='upload' AND target_id IN (%s)"
               % ','.join('?' * len(bids)), (u['id'],) + tuple(bids), one=True)['c'] == 3 if bids else False)
    check('库里书的 size 与上传字节数一致',
          all((db.q('SELECT size FROM books WHERE id=?', (b,), one=True)['size'] == len(body)) for b in bids) if bids else False)

    print('\n== 2. 超限必须拒（两种拦截路径）==')
    # 2a) 1.05MB：Content-Length（约 1.05MB）没超过「上限 + 1MB 余量」，
    #     所以走的是**边写边判**——写到 1MB 那一刻中断。这条最容易漏。
    n0 = db.q('SELECT COUNT(*) c FROM books WHERE owner_id=?', (u['id'],), one=True)['c']
    st, txt = up(tok, 'zzup超限甲.txt', b'B' * int(1.05 * 1024 * 1024))
    check('1.05MB 被拒（边写边判那条路）', st == 413, '%s %s' % (st, txt[:80]))
    # 2b) 3MB：Content-Length 就超了 → 连请求体都不读，直接快速拒绝
    st2, txt2 = up(tok, 'zzup超限乙.txt', b'C' * (3 * 1024 * 1024))
    check('3MB 被拒（Content-Length 快速拒绝）', st2 == 413, '%s %s' % (st2, txt2[:80]))
    check('被拒的两本都没建出书',
          db.q('SELECT COUNT(*) c FROM books WHERE owner_id=?', (u['id'],), one=True)['c'] == n0)
    check('被拒后 UPLOAD_DIR 没留半截文件', tmp_files(u['id']) == [], str(tmp_files(u['id'])))

    print('\n== 3. 边界：正好等于上限通过 ==')
    st, txt = up_rec(tok, 'zzup正好.txt', b'D' * (1 * 1024 * 1024))
    ok = st == 200
    check('正好 1.0MB 通过（判据是「大于」上限才拒）', ok, '%s %s' % (st, txt[:80]))

    print('\n== 4. 书架配额满了：拒绝且不落盘 ==')
    used = db.q('SELECT COUNT(*) c FROM shelves WHERE user_id=?', (u['id'],), one=True)['c']
    db.ex('UPDATE users SET quota=? WHERE id=?', (used, u['id']))
    n_before = db.q('SELECT COUNT(*) c FROM books WHERE owner_id=?', (u['id'],), one=True)['c']
    st, txt = up(tok, 'zzup超额.txt', b'E' * 1024)
    check('配额已满再传 → 400', st == 400, '%s %s' % (st, txt[:80]))
    check('配额拒绝时也没建书',
          db.q('SELECT COUNT(*) c FROM books WHERE owner_id=?', (u['id'],), one=True)['c'] == n_before)
    check('配额拒绝时不留临时文件', tmp_files(u['id']) == [], str(tmp_files(u['id'])))
    db.ex('UPDATE users SET quota=? WHERE id=?', (50, u['id']))

    print('\n== 5. 没有「私人书架」权限的分组 → 403 ==')
    st, txt = up(tok2, 'zzup无权限.txt', b'F' * 1024)
    check('无权限账号上传被拒 403', st == 403, '%s %s' % (st, txt[:80]))

    print('\n== 6. 上传者之间互相看不到（私人书）==')
    if bids:
        st, txt = req('/api/books/%d' % bids[0], token=tok2, method='GET')
        check('别的用户取不到这本私人书', st in (403, 404), str(st))


if __name__ == '__main__':
    print('=== 一次上传多本 / 逐本上限 后端回归 ===')
    try:
        main()
    finally:
        cleanup()
    print('\n通过 %d，失败 %d' % (_pass[0], _fail[0]))
    sys.exit(1 if _fail[0] else 0)
