/* 制作有声书籍 —— 后台「听书管理」里的独立面板。
 *
 * 依赖 admin.js 里的 api() / toast() / esc()（同一个页面、同一作用域，本文件后加载）。
 * 所有函数与变量统一 ab 前缀，避免和 admin.js 撞名。
 *
 * 这一块跟云阅读的阅读/听书功能没有关系：它只是调用 /api/admin/audiobook/* ，
 * 那块后端是独立的包（audiobook/），有自己的表、线程和临时目录。
 */
var AB = { books: [], lines: [], jobs: [], cfg: null, timer: null, picked: null,
           bgm: [], bgmDir: '', chaps: [] };

function abEl(id) { return document.getElementById(id); }

function abToggle() {
  var b = abEl('ab-body'), t = abEl('ab-toggle');
  var open = b.classList.toggle('hidden');
  t.textContent = open ? '展开' : '收起';
  if (!open) abInit();
}

var _abInited = false;
function abInit() {
  if (_abInited) return;
  _abInited = true;
  abSplitMode();          /* 面板可能是浏览器恢复的表单状态，先按当前选择对齐显隐 */
  abLoadCfg();
  abLoadLines();
  abLoadBgm();
  abSearchBooks();
  abLoadJobs();
  abLoadLibCats();
}

/* 有声电子书分类（做好的书归到哪一类；分类在「有声听书设置」里维护） */
function abLoadLibCats() {
  var sel = abEl('ab-lib-cat');
  if (!sel) return;
  api('/api/admin/audiobooks/cats').then(function (d) {
    var h = '<option value="0">未分类</option>';
    (d.cats || []).forEach(function (c) {
      h += '<option value="' + c.id + '">' + esc(c.name) + '</option>';
    });
    sel.innerHTML = h;
  }).catch(function () { /* 分类取不到不影响制作 */ });
}

/* ---------------------------------------------------------- 配置 / AI */
function abLoadCfg() {
  api('/api/admin/audiobook/cfg').then(function (c) {
    AB.cfg = c;
    abEl('ab-ai-proto').value = c.ai_protocol || 'openai-completions';
    abEl('ab-ai-base').value = c.ai_base_url || '';
    abEl('ab-ai-key').value = c.ai_key || '';
    abEl('ab-ai-model').value = c.ai_model || '';
    abEl('ab-ai-prompt').value = c.ai_prompt || '';
    if (!abEl('ab-dest').value) abEl('ab-dest').placeholder = (c.webdav_root || '') + '/书名';
    var w = c.worker || {};
    var n = AB.jobs.filter(function (j) { return j.status === 'running' || j.status === 'queued'; }).length;
    abEl('ab-summary').textContent = (c.ffmpeg ? '' : '⚠ ffmpeg 不可用；') +
      (n ? n + ' 个任务进行中' : '');
  }).catch(function (e) { toast(e.message); });
}

function abSaveCfg() {
  var d = {
    ai_protocol: abEl('ab-ai-proto').value,
    ai_base_url: abEl('ab-ai-base').value.trim(),
    ai_key: abEl('ab-ai-key').value.trim(),
    ai_model: abEl('ab-ai-model').value.trim(),
    ai_prompt: abEl('ab-ai-prompt').value.trim()
  };
  api('/api/admin/audiobook/cfg', {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(d)
  }).then(function () { toast('接口设置已保存'); AB.cfg = null; abLoadCfg(); })
    .catch(function (e) { toast(e.message); });
}

function abProbeAI() {
  var box = abEl('ab-ai-result');
  box.innerHTML = '<span class="muted">正在测试…</span>';
  abSaveCfgSilent().then(function () {
    return api('/api/admin/audiobook/ai/probe', { method: 'POST' });
  }).then(function (r) {
    if (r.how === 'models') {
      box.innerHTML = '<span style="color:#128a4b">✓ 连接成功</span>，可用模型 ' + r.count +
        ' 个（' + Number(r.elapsed) + 's）：<br><span class="muted">' +
        r.models.map(esc).join('、') + '</span>';
    } else {
      box.innerHTML = '<span style="color:#128a4b">✓ 连接成功</span>（对话测试返回：' +
        esc(r.reply) + '，' + Number(r.elapsed) + 's）';
    }
  }).catch(function (e) {
    box.innerHTML = '<span style="color:#c0392b">✗ ' + esc(e.message) + '</span>';
  });
}

function abSaveCfgSilent() {
  var d = {
    ai_protocol: abEl('ab-ai-proto').value,
    ai_base_url: abEl('ab-ai-base').value.trim(),
    ai_key: abEl('ab-ai-key').value.trim(),
    ai_model: abEl('ab-ai-model').value.trim(),
    ai_prompt: abEl('ab-ai-prompt').value.trim()
  };
  return api('/api/admin/audiobook/cfg', {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(d)
  });
}

/* ---------------------------------------------------------- 线路 / 音色 */
function abLoadLines() {
  api('/api/admin/audiobook/lines').then(function (d) {
    AB.lines = d.lines || [];
    var sel = abEl('ab-line');
    sel.innerHTML = AB.lines.map(function (l) {
      return '<option value="' + esc(l.id) + '">' + esc(l.name) + '（' + l.count + ' 个音色）</option>';
    }).join('');
    abFillVoices();
  }).catch(function (e) { toast(e.message); });
}

function abFillVoices() {
  var id = abEl('ab-line').value;
  var l = AB.lines.filter(function (x) { return x.id === id; })[0];
  var sel = abEl('ab-voice');
  if (!l) { sel.innerHTML = ''; return; }
  sel.innerHTML = l.voices.map(function (v) {
    var g = v.gender ? ' · ' + esc(v.gender) : '';
    return '<option value="' + esc(v.voice) + '">' + esc(v.name) + g + '</option>';
  }).join('');
}

/* ---------------------------------------------------------- 选书 */
function abSearchBooks() {
  var q = abEl('ab-book-q').value.trim();
  api('/api/admin/audiobook/books?q=' + encodeURIComponent(q)).then(function (d) {
    AB.books = d.books || [];
    var box = abEl('ab-book-list');
    if (!AB.books.length) { box.innerHTML = '<p class="muted" style="font-size:12.5px">没有找到可制作的书（PDF 暂不支持）</p>'; return; }
    box.innerHTML = AB.books.map(function (b) {
      var on = AB.picked === b.id;
      return '<div onclick="abPickBook(' + b.id + ')" style="cursor:pointer;padding:6px 10px;border-radius:8px;margin-bottom:3px;font-size:13px;' +
        (on ? 'background:#e8f0ff;border:1px solid #6b8cff' : 'background:#fff;border:1px solid #eceef4') + '">' +
        esc(b.title) + ' <span class="muted">' + esc(b.author || '') + ' · ' + esc(b.ext) + '</span></div>';
    }).join('');
  }).catch(function (e) { toast(e.message); });
}

function abPickBook(id) {
  // 换书必须把上一本的分析结果清掉：否则会把 A 书的角色表当成 B 书的配音色
  // 带进创建请求里，做出来的人物声音全是错的。
  if (AB.picked !== id) { AB_ANALYZE = null; abEl('ab-chars-edit').innerHTML = ''; }
  AB.picked = id;
  abSearchBooks();
  abLoadChaps();
}

/* ---------------------------------------------------------- 章节范围 */
// 「只分析某几章 / 只做某几章」共用一套选择器。idx 是后端章节列表的 1 起序号，
// 也就是成品文件名前面的那个号，和任务参数 chap_from/chap_to 同一个口径。
function abLoadChaps() {
  var ids = ['ab-chap-from', 'ab-chap-to', 'ab-ana-from', 'ab-ana-to'];
  var fill = function (id) {
    var s = abEl(id);
    if (!s) return;
    s.innerHTML = '<option value="">不限</option>' + AB.chaps.map(function (c) {
      var t = c.idx + '. ' + c.title;
      if (t.length > 34) t = t.slice(0, 33) + '…';
      return '<option value="' + c.idx + '">' + esc(t) + '</option>';
    }).join('');
  };
  var hint = abEl('ab-chap-hint');
  if (!AB.picked) {
    AB.chaps = [];
    ids.forEach(fill);
    if (hint) hint.textContent = '选书后可选';
    return;
  }
  if (hint) hint.textContent = '正在读取目录…';
  api('/api/admin/audiobook/books/' + AB.picked + '/chapters').then(function (d) {
    AB.chaps = d.chapters || [];
    ids.forEach(fill);
    if (hint) hint.textContent = '共 ' + AB.chaps.length + ' 章' +
      (AB.chaps.length ? '（长章会拆成 1/2、2/2 这样的分片，这里照原样列出）' : '');
  }).catch(function (e) {
    if (hint) hint.textContent = '读不到目录：' + e.message;
  });
}

// prefix 取 'ab-chap'（制作）或 'ab-ana'（分析）
function abChapRange(prefix) {
  var f = parseInt((abEl(prefix + '-from') || {}).value, 10) || 0;
  var t = parseInt((abEl(prefix + '-to') || {}).value, 10) || 0;
  if (!f && !t) return { from: 0, to: 0 };
  if (!f) f = 1;
  if (!t) t = AB.chaps.length || f;
  if (t < f) { var x = f; f = t; t = x; }   // 选反了就自动换过来，不让人对着报错发呆
  return { from: f, to: t };
}

function abChapDesc(list) {
  var a = (list || []).slice().sort(function (x, y) { return x - y; });
  if (!a.length) return '';
  var out = [], st = a[0], pv = a[0];
  for (var i = 1; i <= a.length; i++) {
    if (i < a.length && a[i] === pv + 1) { pv = a[i]; continue; }
    out.push(st === pv ? ('' + st) : (st + '-' + pv));
    st = pv = a[i];
  }
  var txt = out.join('、');
  return txt.length > 60 ? txt.slice(0, 59) + '…' : txt;
}

/* ---------------------------------------------------------- 背景音乐 */
function abLoadBgm() {
  api('/api/admin/audiobook/bgm').then(function (d) {
    AB.bgm = d.files || [];
    // 后端把 BGM 目录一起返回了，就用它；不再在前端写死绝对路径（应用搬家就会失效）
    if (d.dir) AB.bgmDir = d.dir;
    var box = abEl('ab-bgm-list');
    if (!AB.bgm.length) { box.innerHTML = '<span class="muted" style="font-size:12.5px">还没有背景音乐，导入后可以多选</span>'; return; }
    box.innerHTML = AB.bgm.map(function (f) {
      var s = f.seconds ? (f.seconds / 60).toFixed(1) + ' 分' : '';
      return '<label style="display:inline-flex;align-items:center;gap:5px;margin:0 12px 4px 0;font-size:12.5px">' +
        '<input type="checkbox" class="ab-bgm-pick" value="' + esc(f.name) + '"> ' + esc(f.name) +
        ' <span class="muted">' + s + '</span>' +
        ' <a href="/api/admin/audiobook/bgm/file/' + encodeURIComponent(f.name) + '" target="_blank" style="font-size:12px">试听</a>' +
        ' <a href="javascript:;" onclick="abDelBgm(\'' + esc(f.name).replace(/'/g, "\\'") + '\')" style="font-size:12px;color:#c0392b">删除</a></label>';
    }).join('');
  }).catch(function (e) { toast(e.message); });
}

function abUploadBgm() {
  var f = abEl('ab-bgm-file');
  if (!f.files || !f.files.length) { toast('先选音频文件'); return; }
  var fd = new FormData();
  // ★ 字段名必须是 files（复数）：后端是 List[UploadFile] = File(...)，按 FastAPI 官方约定
  //   列表上传用复数名。这里以前写成单数 'file'，FastAPI 直接 422，而 422 的 detail 是
  //   对象数组，被 api() 塞进 new Error 后字符串化成「[object Object]」——
  //   于是这个导入从上线起就没人能成功，还看不出原因（bgm 目录一直是空的）。
  for (var i = 0; i < f.files.length; i++) fd.append('files', f.files[i]);
  api('/api/admin/audiobook/bgm', { method: 'POST', body: fd })
    .then(function () { toast('已导入'); f.value = ''; abLoadBgm(); })
    .catch(function (e) { toast(e.message); });
}

function abDelBgm(n) {
  if (!confirm('删除背景音乐 ' + n + '？')) return;
  api('/api/admin/audiobook/bgm/' + encodeURIComponent(n), { method: 'DELETE' })
    .then(function () { abLoadBgm(); }).catch(function (e) { toast(e.message); });
}

function abPickedBgm() {
  // 任务里存的是 BGM 的绝对路径（worker 与接口同机，直接按路径读文件）。
  // 目录以后端 /bgm 返回的 dir 为准，取不到才退回默认位置。
  var dir = AB.bgmDir || '';
  if (dir.charAt(dir.length - 1) !== '/') dir += '/';
  return Array.prototype.slice.call(document.querySelectorAll('.ab-bgm-pick'))
    .filter(function (x) { return x.checked; })
    .map(function (x) { return dir + x.value; });
}

/* ---------------------------------------------------------- 创建任务 */
// 任务卡片上怎么描述分文件方式（老任务没有 split_mode 字段，按老行为显示）
function abSplitDesc(j) {
  if (j.split_mode === 'balanced') {
    return '按时长均衡分文件（目标 ' + (j.target_min || 40) + ' 分 / 上限 ' + (j.max_min || 60) + ' 分）';
  }
  return '每 ' + j.chapters_per_file + ' 章一个文件';
}

// 分文件方式的联动：选了"均衡划分"才显示目标时长/上限
function abSplitMode() {
  var m = abEl('ab-splitmode').value;
  var bal = m === 'balanced';
  abEl('ab-per-wrap').style.display = bal ? 'none' : '';
  abEl('ab-tgt-wrap').style.display = bal ? '' : 'none';
  abEl('ab-max-wrap').style.display = bal ? '' : 'none';
  var h = abEl('ab-split-hint');
  if (h) {
    h.innerHTML = bal
      ? '<strong>按预估时长均衡划分</strong>：按每章字数预估时长，用最小化"最大文件"的算法切分，' +
        '文件之间均匀得多（同一本《秋园》9 个文件、最长/最短 1.43 倍）。同样<strong>不切章</strong>，' +
        '只按章节边界分组；跳过的版权页算 0 时长。'
      : '<strong>每 N 章一个文件</strong>：简单可预期。但章节本身长短不一，文件时长会差得比较开' +
        '（实测《秋园》26.8～61.8 分钟，最长/最短 2.31 倍）。';
  }
}

function abCreate() {
  if (!AB.picked) { toast('先选一本电子书'); return; }
  var v = abEl('ab-voice').value;
  if (!v) { toast('先选旁白音色'); return; }
  var ai = abEl('ab-ai').checked;
  if (ai && !abEl('ab-ai-model').value.trim()) { toast('启用 AI 需要先填模型名'); return; }
  var msg = abEl('ab-create-msg');
  var go = function () {
    var d = {
      book_id: AB.picked,
      line: abEl('ab-line').value,
      voice: v,
      chapters_per_file: parseInt(abEl('ab-per').value, 10) || 1,
      split_mode: abEl('ab-splitmode').value,
      target_min: parseInt(abEl('ab-tgt').value, 10) || 40,
      max_min: parseInt(abEl('ab-max').value, 10) || 60,
      ai_enabled: ai,
      bgm: abPickedBgm(),
      bgm_volume: (parseInt(abEl('ab-bgm-vol').value, 10) || 0) / 100,
      dest: abEl('ab-dest').value.trim(),
      to_lib: abEl('ab-tolib') && abEl('ab-tolib').checked ? 1 : 0,
      lib_cat: parseInt((abEl('ab-lib-cat') || {}).value || '0', 10) || 0,
      gap_ms: parseInt(abEl('ab-gap').value, 10) || 0,
      chap_gap_ms: parseInt(abEl('ab-cgap').value, 10) || 0,
      skip_front: abEl('ab-skipfront').checked
    };
    var rgc = abChapRange('ab-chap');
    d.chap_from = rgc.from;
    d.chap_to = rgc.to;
    if (ai) {
      // 把角色→音色一起带上（人工改过的优先）。后台 worker 用的是
      // voices.setdefault(...)，所以这里预设的音色不会被逐章分析覆盖掉。
      d.ai_chars = { voices: abChosenVoices() };
    }
    msg.textContent = rgc.from ? ('正在创建（只做第 ' + rgc.from + '-' + rgc.to + ' 章）…') : '正在创建…';
    api('/api/admin/audiobook/jobs', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(d)
    }).then(function (r) {
      msg.textContent = '任务 #' + r.id + ' 已加入队列';
      abLoadJobs();
    }).catch(function (e) { msg.textContent = ''; toast(e.message); });
  };
  if (ai) {
    abSaveCfgSilent().then(go).catch(function (e) { toast(e.message); });
  } else { go(); }
}

/* ---------------------------------------------------------- 角色分析（制作前） */
// 先让 AI 分析出「有哪些角色、各多少句台词」，人看过再配音色（默认自动分配）。
// 正式制作时的分析是逐章按需做的，74 章要十几分钟；这里只采样前 N 章，
// 小说主要角色基本前几章就出场了。
var AB_ANALYZE = null;      // 上一次 /analyze 的结果

function abShowAnalyze(on) {
  abEl('ab-an-box').classList.toggle('hidden', !on);
  if (!on) { AB_ANALYZE = null; abEl('ab-chars-edit').innerHTML = ''; abEl('ab-analyze-msg').textContent = ''; }
}

function abAnalyze(reuse, more) {
  if (!AB.picked) { toast('先选一本电子书'); return; }
  var v = abEl('ab-voice').value;
  if (!v) { toast('先选旁白音色'); return; }
  var box = abEl('ab-analyze-msg');
  var btn = abEl('ab-analyze-btn');
  var body = {
    book_id: AB.picked,
    line: abEl('ab-line').value,
    voice: v,
    sample: parseInt(abEl('ab-sample').value, 10) || 3
  };
  var rga = abChapRange('ab-ana');
  if (more) {
    if (!rga.from) { toast('先在「只分析第…到第…」里选章节'); return; }
    body.chap_from = rga.from;
    body.chap_to = rga.to;
    // 累积：把之前分析过的角色与「每章账本」带上，后端会把这一章的账合并进去
    if (AB_ANALYZE) {
      body.characters = AB_ANALYZE.characters;
      body.chap_lines = AB_ANALYZE.chap_lines || {};
      body.sentences = AB_ANALYZE.sentences;
      body.sampled = AB_ANALYZE.sampled;
      body.chapters_total = AB_ANALYZE.chapters_total;
    }
  } else if (rga.from) {
    // 「分析角色」但选了范围：就按范围重新分析（不要上一次的累积）
    body.chap_from = rga.from;
    body.chap_to = rga.to;
  }
  if (reuse && AB_ANALYZE) {
    // 换线路/换旁白：只重配音色，不再调 AI（省时间也省钱）。
    // 带上人已经改过的音色，只要新线路上还有就保留，不白改。
    body.reuse = true;
    body.characters = AB_ANALYZE.characters;
    body.voices = abChosenVoices();
    body.chap_lines = AB_ANALYZE.chap_lines || {};
    body.sentences = AB_ANALYZE.sentences;
    body.sampled = AB_ANALYZE.sampled;
    body.chapters_total = AB_ANALYZE.chapters_total;
  }
  btn.disabled = true;
  var t0 = Date.now();
  var tick = setInterval(function () {
    var s = Math.round((Date.now() - t0) / 1000);
    box.textContent = (reuse ? '正在重新分配音色…'
      : (body.chap_from ? ('正在分析第 ' + body.chap_from + '-' + body.chap_to + ' 章… ')
                        : ('正在分析角色（采样 ' + body.sample + ' 章）… '))) + s + ' 秒';
  }, 1000);
  box.textContent = reuse ? '正在重新分配音色…'
    : (body.chap_from ? ('正在分析第 ' + body.chap_from + '-' + body.chap_to + ' 章… 0 秒')
                      : ('正在分析角色（采样 ' + body.sample + ' 章）… 0 秒'));
  abSaveCfgSilent()
    .then(function () {
      return api('/api/admin/audiobook/analyze', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
      });
    })
    .then(function (r) {
      AB_ANALYZE = r;
      abRenderChars(r);
      var done = r.chapters_done || [];
      var head = '已分析 ' + done.length + '/' + r.chapters_total + ' 章' +
        (done.length ? '（第 ' + abChapDesc(done) + ' 章）' : '') + ' · 共 ' + r.sentences + ' 句 · ';
      box.textContent = r.characters.length
        ? (head + '识别出 ' + r.characters.length + ' 个角色')
        : (head + '没有发现对话角色（这些章会用旁白音色）');
    })
    .catch(function (e) {
      // ★ 失败原因必须留在页面上。以前这里把文字清空了，用户等了几分钟
      //   只看到一个一闪而过的 toast，完全不知道发生了什么。
      //   AI 接口限流时后台自己会退避重试，所以最可能的失败就是重试也没成功，
      //   这时要明确告诉他"过一会儿再点一次"，而不是让他以为功能坏了。
      box.innerHTML = '<span style="color:#c0392b">分析失败：' + esc(e.message || e) + '</span>' +
        '<br><span class="muted">第三方 AI 接口限流或超时会自动重试几次，仍失败就是这个提示；' +
        '稍等一会儿再点一次「分析角色」通常就好了。</span>';
    })
    .then(function () { clearInterval(tick); btn.disabled = false; });
}

function abAnalyzeReset() {
  AB_ANALYZE = null;
  abEl('ab-chars-edit').innerHTML = '<p class="muted" style="font-size:12.5px">' +
    '已清空。可以重新点「分析角色」（采样前几章），或用「只分析这几章（累积）」逐章累加。</p>';
  abEl('ab-analyze-msg').textContent = '';
}

// 累积分析：只分析选定的章节，并把它并进已有结果（每章人物不同时逐章加）
function abAnalyzeMore() { abAnalyze(false, true); }

function abRenderChars(r) {
  var box = abEl('ab-chars-edit');
  var cs = r.characters || [];
  if (!cs.length) {
    box.innerHTML = '<p class="muted" style="font-size:12.5px">分析过的这些章里没有识别到对话角色，' +
      '会用旁白音色（可以换一章再点「只分析这几章（累积）」试试）。</p>';
    return;
  }
  var pool = abVoicesOf(r.line);
  var h = '<div style="border:1px solid #eceef4;border-radius:8px;background:#fff">';
  h += '<div style="display:flex;align-items:center;gap:8px;padding:7px 10px;border-bottom:1px solid #f4f6fa;font-size:12px;background:#f8faff">' +
    '<b style="flex:1">角色（按台词量排序）</b><span class="muted" style="width:44px">性别</span>' +
    '<span class="muted" style="width:60px">台词句数</span>' +
    '<span class="muted" style="width:120px">出现在</span>' +
    '<span class="muted" style="width:190px">音色（默认自动分配，可改）</span></div>';
  h += cs.map(function (c) {
    var opts = pool.map(function (v) {
      var g = v.gender ? ' · ' + v.gender : '';
      return '<option value="' + esc(v.voice) + '"' + (v.voice === c.voice ? ' selected' : '') + '>' +
        esc(v.name) + g + '</option>';
    }).join('');
    return '<div style="display:flex;align-items:center;gap:8px;padding:6px 10px;border-bottom:1px solid #f4f6fa;font-size:12.5px">' +
      '<div style="flex:1;min-width:0"><b>' + esc(c.name) + '</b>' +
      (c.desc ? '<div class="muted" style="font-size:11.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(c.desc) + '</div>' : '') +
      '</div>' +
      '<span class="muted" style="width:44px">' + esc(c.gender || '') + '</span>' +
      '<span style="width:60px">' + (c.lines || 0) + ' 句</span>' +
      '<span class="muted" style="width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' +
      ((c.chapters && c.chapters.length) ? ('第 ' + abChapDesc(c.chapters) + ' 章') : '—') + '</span>' +
      '<select class="ab-char-voice" data-name="' + esc(c.name) + '" style="width:190px">' + opts + '</select>' +
      '</div>';
  }).join('');
  h += '</div>';
  h += '<div style="margin-top:6px;font-size:12px" class="muted">旁白：<b>' + esc(r.narrator_name || r.narrator) +
    '</b>（其余未列出的句子都算旁白）。改完音色直接点下面的「开始制作」即可。</div>';
  box.innerHTML = h;
}

function abVoicesOf(lineId) {
  var l = AB.lines.filter(function (x) { return x.id === lineId; })[0];
  return l ? l.voices : [];
}

function abChosenVoices() {
  var out = {};
  Array.prototype.slice.call(document.querySelectorAll('.ab-char-voice')).forEach(function (s) {
    var n = s.getAttribute('data-name');
    if (!n) return;
    var v = s.value;
    var info = abVoicesOf(abEl('ab-line').value).filter(function (x) { return x.voice === v; })[0] || {};
    out[n] = { voice: v, name: info.name || v };
  });
  return out;
}

/* ---------------------------------------------------------- 任务列表 */
var AB_BADGE = {
  queued: ['排队中', '#8a8f9c'], running: ['制作中', '#1a6fd4'], paused: ['已暂停', '#c98a00'],
  done: ['已完成', '#128a4b'], failed: ['失败', '#c0392b'], canceled: ['已取消', '#8a8f9c']
};

function abLoadJobs() {
  api('/api/admin/audiobook/jobs').then(function (d) {
    AB.jobs = d.jobs || [];
    var box = abEl('ab-jobs');
    if (!AB.jobs.length) { box.innerHTML = '<p class="muted" style="font-size:12.5px">还没有制作任务</p>'; abAutoRefresh(); return; }
    box.innerHTML = AB.jobs.map(abJobCard).join('');
    abAutoRefresh();
  }).catch(function (e) { toast(e.message); });
}

function abJobCard(j) {
  var b = AB_BADGE[j.status] || ['未知', '#8a8f9c'];
  var pct = j.total_files ? Math.round(j.done_files * 100 / j.total_files) : 0;
  var h = '<div style="border:1px solid #eceef4;border-radius:10px;padding:10px 12px;margin-bottom:8px;background:#fff">';
  h += '<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">';
  h += '<b style="font-size:13px">' + esc(j.title || ('书 ' + j.book_id)) + '</b>';
  h += '<span style="font-size:11.5px;color:#fff;background:' + b[1] + ';padding:1px 7px;border-radius:9px">' + b[0] + '</span>';
  if (j.ai_enabled) h += '<span style="font-size:11.5px;color:#1a6fd4;border:1px solid #bcd3f7;padding:0 6px;border-radius:9px">AI 角色</span>';
  h += '<span class="muted" style="font-size:12px">#' + j.id + '</span>';
  h += '<span style="flex:1"></span>';
  h += '<a href="javascript:;" onclick="abJobDetail(' + j.id + ')" style="font-size:12.5px">详情</a>';
  if (j.status === 'running' || j.status === 'queued') {
    h += ' <a href="javascript:;" onclick="abJobAct(' + j.id + ',\'pause\')" style="font-size:12.5px">暂停</a>';
  }
  if (j.status === 'paused') {
    h += ' <a href="javascript:;" onclick="abJobAct(' + j.id + ',\'resume\')" style="font-size:12.5px;color:#128a4b">继续</a>';
  }
  if (j.status === 'failed' || j.status === 'canceled' || j.status === 'paused') {
    h += ' <a href="javascript:;" onclick="abJobAct(' + j.id + ',\'retry\')" style="font-size:12.5px">重跑</a>';
  }
  if (j.status === 'running' || j.status === 'queued' || j.status === 'paused') {
    h += ' <a href="javascript:;" onclick="abJobAct(' + j.id + ',\'cancel\')" style="font-size:12.5px;color:#c98a00">取消</a>';
  }
  h += ' <a href="javascript:;" onclick="abJobAct(' + j.id + ',\'delete\')" style="font-size:12.5px;color:#c0392b">删除</a>';
  if (j.status === 'done') {
    // 老任务（当时还没有这个勾选项）也能补登记进「有声」页面
    h += ' <a href="javascript:;" onclick="abJobToLib(' + j.id + ')" style="font-size:12.5px;color:#4f46e5">加入有声页</a>';
  }
  h += '</div>';
  // 进度条
  h += '<div style="height:6px;background:#eef1f7;border-radius:4px;margin:7px 0 5px;overflow:hidden">' +
    '<div style="height:100%;width:' + pct + '%;background:' + b[1] + ';transition:width .3s"></div></div>';
  h += '<div class="muted" style="font-size:12px">' +
    '文件 ' + j.done_files + '/' + j.total_files + '（' + pct + '%）· 已合成 ' + j.done_segs + ' 句' +
    (j.total_chapters ? ' · 全书 ' + j.total_chapters + ' 章' : '') +
    ' · ' + abSplitDesc(j) +
    ' · 句间 ' + (j.gap_ms || 0) + 'ms / 章间 ' + (j.chap_gap_ms || 0) + 'ms</div>';
  var sk = [];
  try { sk = JSON.parse(j.skipped || '[]') || []; } catch (e) { sk = []; }
  if (sk.length) {
    h += '<div style="font-size:12px;margin-top:3px;color:#8a6d00">已跳过 ' + sk.length +
      ' 个非正文章节：' + esc(sk.join('、')) + '</div>';
  } else if (j.skip_front) {
    h += '<div class="muted" style="font-size:11.5px;margin-top:3px">已开启跳过版权页/目录（还没遇到）</div>';
  }
  if (j.stage) h += '<div style="font-size:12px;margin-top:3px">' + esc(j.stage) + '</div>';
  if (j.error) h += '<div style="font-size:12px;margin-top:3px;color:#c0392b">' + esc(j.error) + '</div>';
  if (j.to_lib) h += '<div class="muted" style="font-size:11.5px;margin-top:3px">🎧 完成后加入有声电子书页面' +
    (parseInt(j.lib_cat || 0) ? '' : '（未分类）') + '</div>';
  if (j.dest) h += '<div class="muted" style="font-size:11.5px;margin-top:3px;word-break:break-all">→ ' + esc(j.dest) + '</div>';
  h += '</div>';
  return h;
}

/* 把已完成的任务登记进「有声」页面（重复点是更新，不会重复建行） */
function abJobToLib(id) {
  api('/api/admin/audiobooks/register', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ job_id: id })
  }).then(function (r) {
    toast('已加入有声页：' + r.chapters + ' 章 / ' + (r.seconds / 3600).toFixed(2) + ' 小时');
    abLoadJobs();
  }).catch(function (e) { toast(e.message); });
}

function abJobAct(id, act) {
  if (act === 'delete' && !confirm('删除任务 #' + id + '？已上传到 WebDAV 的文件不会被删除。')) return;
  api('/api/admin/audiobook/jobs/' + id + '/' + act, { method: 'POST' })
    .then(function () { toast('已' + ({ pause: '暂停', resume: '继续', cancel: '取消', retry: '重跑', delete: '删除' }[act] || act)); abLoadJobs(); })
    .catch(function (e) { toast(e.message); });
}

/* 有任务在跑时每 3 秒自己刷一次；没有就停掉，别一直打接口 */
function abAutoRefresh() {
  var busy = AB.jobs.some(function (j) { return j.status === 'running' || j.status === 'queued'; });
  if (AB.timer) { clearTimeout(AB.timer); AB.timer = null; }
  if (busy) AB.timer = setTimeout(abLoadJobs, 3000);
}

/* ---------------------------------------------------------- 任务详情 */
function abJobBgm(id) {
  var picks = Array.prototype.slice.call(document.querySelectorAll('.ab-jbgm'))
    .filter(function (x) { return x.checked; }).map(function (x) { return x.value; });
  var dir = AB.bgmDir || '';
  if (dir.charAt(dir.length - 1) !== '/') dir += '/';
  var bgm = picks.map(function (n) { return dir + n; });
  var vol = parseInt((abEl('ab-jbgm-vol') || {}).value, 10);
  if (isNaN(vol)) vol = 12;
  if (bgm.length && !confirm('把任务 #' + id + ' 的背景音乐改为 ' + picks.join('、') +
      '（音量 ' + vol + '%）并重做全部文件？\n\n已合成的配音会复用，只重做拼接、混音与上传。')) return;
  if (!bgm.length && !confirm('不挂背景音乐（清空）并重做全部文件？')) return;
  api('/api/admin/audiobook/jobs/' + id + '/bgm', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ bgm: bgm, bgm_volume: vol / 100 }),
  }).then(function (r) {
    toast('已排队重做' + (r.seg_kept ? '，复用配音 ' + r.seg_kept + ' 段' : ''));
    closeModal();
    abLoadJobs();
  }).catch(function (e) { toast(e.message); });
}

function abJobDetail(id) {
  openModal('<div style="padding:16px">正在加载…</div>', true);
  api('/api/admin/audiobook/jobs/' + id).then(function (j) {
    var h = '<h3 style="margin:0 0 10px">' + esc(j.title) + ' <span class="muted" style="font-size:13px">任务 #' + j.id + '</span></h3>';
    h += '<div style="font-size:13px;margin-bottom:10px">状态：' + esc(j.status) + ' · ' + esc(j.stage || '') +
      '<br><span class="muted">线路 ' + esc(j.line) + ' · 旁白音色 ' + esc(j.voice) +
      ' · ' + abSplitDesc(j) + '</span>' +
      (j.bgm && j.bgm.length ? '<br><span class="muted">背景音乐 ' + j.bgm.length + ' 首，音量 ' + Math.round(j.bgm_volume * 100) + '%</span>' : '') +
      '</div>';
    // 换背景音乐并重做：勾选列表直接放这里，不用关弹窗回面板去选。
    // 后端只重置文件状态、保留 ab_seg 配音缓存，所以是「重混」而不是「重配」。
    h += '<div style="font-weight:600;font-size:13px;margin:12px 0 6px">背景音乐' +
      '<span class="muted" style="font-weight:400">（改动后点右侧按钮重做，已合成的配音会复用）</span></div>';
    if (!AB.bgm.length) {
      h += '<div class="muted" style="font-size:12.5px">还没有背景音乐，先在上面的「3. 背景音乐」里导入或从 NAS 导入</div>';
    } else {
      var cur = j.bgm || [];
      h += '<div style="font-size:12.5px">' + AB.bgm.map(function (f) {
        var on = cur.indexOf((AB.bgmDir || '') + '/' + f.name) > -1;
        return '<label style="display:inline-flex;align-items:center;gap:5px;margin:0 12px 4px 0">' +
          '<input type="checkbox" class="ab-jbgm" value="' + esc(f.name) + '"' + (on ? ' checked' : '') + '> ' +
          esc(f.name) + '<span class="muted">' + (f.seconds ? ' ' + (f.seconds / 60).toFixed(1) + ' 分' : '') + '</span></label>';
      }).join('') + '</div>';
    }
    h += '<div style="margin-top:6px;display:flex;gap:8px;align-items:center;flex-wrap:wrap">' +
      '<span style="font-size:12.5px">音量 <input id="ab-jbgm-vol" type="number" min="0" max="100" value="' +
      Math.round((j.bgm_volume == null ? 0.12 : j.bgm_volume) * 100) + '" style="width:64px"> %</span>' +
      '<button class="btn" onclick="abJobBgm(' + j.id + ')">按以上设置重做</button></div>';
    if (j.files && j.files.length) {
      h += '<div style="font-weight:600;font-size:13px;margin:12px 0 6px">文件（' + j.files.length + '）</div>';
      h += '<div style="max-height:230px;overflow:auto;border:1px solid #eceef4;border-radius:8px">';
      h += j.files.map(function (f) {
        var ok = f.status === 'uploaded';
        return '<div style="display:flex;align-items:center;gap:8px;padding:6px 10px;border-bottom:1px solid #f4f6fa;font-size:12.5px">' +
          '<span style="color:' + (ok ? '#128a4b' : f.status === 'failed' ? '#c0392b' : '#8a8f9c') + '">' +
          (ok ? '✓' : f.status === 'failed' ? '✗' : '…') + '</span>' +
          '<span style="flex:1;word-break:break-all">' + esc(f.name) + '</span>' +
          '<span class="muted">' + (f.seconds ? (f.seconds / 60).toFixed(1) + '分' : '') +
          (f.bytes ? ' · ' + (f.bytes / 1048576).toFixed(1) + 'MB' : '') + '</span>' +
          '<a href="javascript:;" onclick="abFileRetry(' + j.id + ',' + f.seq + ')" style="font-size:12px">重做</a></div>';
      }).join('');
      h += '</div>';
    }
    h += '<div style="font-weight:600;font-size:13px;margin:14px 0 6px">角色与音色</div><div id="ab-chars">加载中…</div>';
    h += '<div style="margin-top:14px;text-align:right"><button class="btn" style="background:#f3f4f8;color:#333" onclick="closeModal()">关闭</button></div>';
    openModal('<div style="padding:16px">' + h + '</div>', true);
    AB.jobLine = j.line || '';       // 给角色表里的音色下拉提供该线路的音色池
    abLoadChars(j.id);
  }).catch(function (e) { openModal('<div style="padding:16px">' + esc(e.message) + '</div>'); });
}

function abLoadChars(id) {
  api('/api/admin/audiobook/jobs/' + id + '/chars').then(function (d) {
    var box = abEl('ab-chars');
    if (!box) return;
    var cs = d.characters || [], vs = d.voices || {};
    if (!cs.length) {
      box.innerHTML = '<p class="muted" style="font-size:12.5px">没有启用 AI 角色识别，全书使用旁白音色。</p>';
      return;
    }
    var pool = abVoicesOf(AB.jobLine || '');
    var h = '<div style="border:1px solid #eceef4;border-radius:8px;max-height:240px;overflow:auto">';
    h += cs.map(function (c) {
      var cur = (vs[c.name] || {}).voice || '';
      var opts = pool.map(function (v) {
        return '<option value="' + esc(v.voice) + '"' + (v.voice === cur ? ' selected' : '') + '>' +
          esc(v.name) + '</option>';
      }).join('');
      return '<div style="display:flex;align-items:center;gap:8px;padding:6px 10px;border-bottom:1px solid #f4f6fa;font-size:12.5px">' +
        '<b style="min-width:70px">' + esc(c.name) + '</b>' +
        '<span class="muted" style="min-width:34px">' + esc(c.gender || '') + '</span>' +
        '<span style="min-width:56px">' + (c.lines || 0) + ' 句</span>' +
        '<span style="flex:1;color:#666;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(c.desc || '') + '</span>' +
        (pool.length
          ? '<select class="ab-job-char-voice" data-name="' + esc(c.name) + '" style="width:150px">' + opts + '</select>'
          : '<span>' + esc((vs[c.name] || {}).name || '（未分配）') + '</span>') +
        '</div>';
    }).join('') + '</div>';
    h += '<div class="muted" style="font-size:12px;margin-top:5px">旁白 ' + (d.narrator_lines || 0) +
      ' 句 · 已合成共 ' + (d.total_segs || 0) + ' 句。' +
      (pool.length ? '改完点「保存音色」，再在文件列表里「重做」受影响的文件。' : '') + '</div>';
    if (pool.length) {
      h += '<div style="margin-top:6px"><button class="btn" style="padding:5px 12px;font-size:12.5px" onclick="abSaveJobChars(' + id + ')">保存音色</button></div>';
    }
    box.innerHTML = h;
  }).catch(function (e) { var b = abEl('ab-chars'); if (b) b.textContent = e.message; });
}

function abSaveJobChars(id) {
  var voices = {};
  Array.prototype.slice.call(document.querySelectorAll('.ab-job-char-voice')).forEach(function (s) {
    var n = s.getAttribute('data-name');
    if (n) voices[n] = { voice: s.value };
  });
  if (!Object.keys(voices).length) { toast('没有可保存的音色'); return; }
  api('/api/admin/audiobook/jobs/' + id + '/chars', {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ voices: voices })
  }).then(function () { toast('音色已保存，重做文件后生效'); })
    .catch(function (e) { toast(e.message); });
}

function abFileRetry(jid, seq) {
  if (!confirm('重做第 ' + seq + ' 个文件？（该文件和之后的文件会重新合成，已上传的会覆盖）')) return;
  api('/api/admin/audiobook/jobs/' + jid + '/file/' + seq + '/retry', { method: 'POST' })
    .then(function () { toast('已加入队列'); closeModal(); abLoadJobs(); })
    .catch(function (e) { toast(e.message); });
}

/* AI 开关：勾上才显示接口设置和「分析角色」 */
document.addEventListener('change', function (e) {
  var t = e.target;
  if (!t) return;
  if (t.id === 'ab-ai') {
    abEl('ab-ai-cfg').classList.toggle('hidden', !t.checked);
    abShowAnalyze(t.checked);
    return;
  }
  // 换线路 / 换旁白之后，已分析出的角色要重新配音色 —— 但不必再调一次 AI，
  // 传 reuse=true 让后端只做分配（快且不花钱）。音色池不同，不重配就会
  // 拿着旧线路的音色 id 去合成，那是必然失败的。
  if ((t.id === 'ab-line' || t.id === 'ab-voice') && AB_ANALYZE && abEl('ab-ai').checked) {
    if (t.id === 'ab-line') abFillVoices();
    setTimeout(function () { abAnalyze(true); }, 0);
  }
});
