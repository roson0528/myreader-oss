#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""网站统计：按天聚合，落到 WebDAV，保留三年。

存储结构
--------
WebDAV:  stats/<年>/<YYYY-MM-DD>.json

每个日文件是自洽的，单独拿走也能看懂当天情况，包含两部分：

  * 事件计数 —— 由运行期累计（访问量、独立IP、App下载、阅读时长、错误数）
  * 库表快照 —— 封盘时从库里数出来（新增会员、会员上传、书籍下载、书单投稿…）

当天文件会被反复覆盖（每次 flush），跨天时做一次封盘（补全库表快照），
并清理三年以前的老文件。

设计要点
--------
* 统计不能拖慢正常请求：所有记录都是内存自增，落盘交给后台线程。
* 进程重启不丢当天数据：当天第一次用到时会先把 WebDAV 上的当天文件读回来合并。
* 独立 IP 直接存列表（去重、封顶），所以「IP数量」在重启后依然准确。
"""
import json
import os
import threading
import time
from datetime import datetime, timedelta, timezone

import config
import db
import ftp_service

STATS_ROOT = "stats"
RETENTION_DAYS = 365 * 3          # 历史保留三年
FLUSH_SEC = 60                    # 落盘间隔
MAX_IPS = 5000                    # 单日最多记这么多 IP（防止文件无限膨胀）
MAX_USERS = 20000
MAX_PATHS = 60                    # 单日最多记这么多条路径

_lock = threading.RLock()
_days = {}                        # date -> bucket
_dirty = set()                    # 待落盘的日期
_loaded = set()                   # 已经和 WebDAV 合并过的日期
_started = False
_last_prune = 0.0
_last_error = ""

# 历史日文件缓存：WebDAV 读一次要一个来回，15 天就是 15 次，
# 不缓存的话每次打开统计页都要等好几秒
_day_cache = {}                   # date -> (doc|None, 取回时间)
DAY_CACHE_TTL = 300               # 秒


# ---------------------------------------------------------------- 基础工具
def _bj_now():
    return datetime.now(timezone.utc) + timedelta(hours=8)


def today():
    return _bj_now().strftime("%Y-%m-%d")


def _hour():
    return _bj_now().hour


def day_path(date):
    return f"{STATS_ROOT}/{date[:4]}/{date}.json"


def client_ip(request):
    """取真实客户端 IP：优先 X-Forwarded-For 的第一段（nginx 反代）"""
    try:
        xff = request.headers.get("x-forwarded-for") or request.headers.get("x-real-ip") or ""
        if xff:
            ip = xff.split(",")[0].strip()
            if ip:
                return ip[:64]
        return (request.client.host if request.client else "") or ""
    except Exception:
        return ""


HOURLY_KEYS = ("pv", "app_downloads", "reading_seconds", "errors")


def _norm_hourly(h):
    """v1 的 hourly 是一个 24 长度数组（访问量+App下载混在一起）；
    v2 拆成按指标分开的字典。老文件读进来时在此升级。"""
    if isinstance(h, dict):
        return {k: [int(x) for x in (list(h.get(k) or []) + [0] * 24)[:24]] for k in HOURLY_KEYS}
    if isinstance(h, list):
        return {"pv": [int(x) for x in (list(h) + [0] * 24)[:24]],
                "app_downloads": [0] * 24, "reading_seconds": [0] * 24, "errors": [0] * 24}
    return {k: [0] * 24 for k in HOURLY_KEYS}


def _norm_hourly_ips(v):
    if isinstance(v, list) and len(v) == 24:
        return [list(x or []) for x in v]
    return [[] for _ in range(24)]


def _blank(date):
    return {"v": 2, "date": date, "updated_at": db.now(),
            "pv": 0, "app_downloads": 0, "reading_seconds": 0, "errors": 0,
            "hourly": {k: [0] * 24 for k in HOURLY_KEYS}, "hourly_ips": [[] for _ in range(24)],
            "paths": {},
            "ips": [], "users": [], "readers": [],
            "db": {}}


def _bucket(date):
    """取当天桶；第一次用到时先把 WebDAV 上的旧数据合并回来（重启不丢数）"""
    with _lock:
        b = _days.get(date)
        if b is not None:
            return b
        b = _blank(date)
        if date not in _loaded:
            _loaded.add(date)
            remote = load_day(date)
            if remote:
                b = _merge(b, remote)
        _days[date] = b
        return b


def _merge(a, b):
    """把 b 合并进 a（数值相加，列表并集）"""
    out = dict(a)
    for k in ("pv", "app_downloads", "reading_seconds", "errors"):
        out[k] = int(a.get(k, 0)) + int(b.get(k, 0))
    ah, bh = _norm_hourly(a.get("hourly")), _norm_hourly(b.get("hourly"))
    out["hourly"] = {k: [ah[k][i] + bh[k][i] for i in range(24)] for k in HOURLY_KEYS}
    ai, bi = _norm_hourly_ips(a.get("hourly_ips")), _norm_hourly_ips(b.get("hourly_ips"))
    out["hourly_ips"] = [sorted(set(ai[i]) | set(bi[i]))[:MAX_IPS] for i in range(24)]
    paths = dict(a.get("paths") or {})
    for k, v in (b.get("paths") or {}).items():
        paths[k] = int(paths.get(k, 0)) + int(v)
    out["paths"] = paths
    out["ips"] = sorted(set(a.get("ips") or []) | set(b.get("ips") or []))[:MAX_IPS]
    out["users"] = sorted(set(int(x) for x in (a.get("users") or [])) |
                          set(int(x) for x in (b.get("users") or [])))[:MAX_USERS]
    out["readers"] = sorted(set(int(x) for x in (a.get("readers") or [])) |
                            set(int(x) for x in (b.get("readers") or [])))[:MAX_USERS]
    if b.get("db"):
        out["db"] = b["db"]
    return out


# ---------------------------------------------------------------- 记录入口
def record_page(request, path, user_id=0):
    """记一次页面访问"""
    try:
        date = today()
        ip = client_ip(request)
        with _lock:
            b = _bucket(date)
            h = _hour()
            b["pv"] += 1
            b["hourly"]["pv"][h] += 1
            if ip and len(b["ips"]) < MAX_IPS and ip not in b["ips"]:
                b["ips"].append(ip)
            if ip and len(b["hourly_ips"][h]) < MAX_IPS and ip not in b["hourly_ips"][h]:
                b["hourly_ips"][h].append(ip)
            if user_id and user_id not in b["users"] and len(b["users"]) < MAX_USERS:
                b["users"].append(user_id)
            if len(b["paths"]) < MAX_PATHS or path in b["paths"]:
                b["paths"][path] = int(b["paths"].get(path, 0)) + 1
            b["updated_at"] = db.now()
            _dirty.add(date)
    except Exception:
        pass


# 安装包下载去重：浏览器/下载器会用 Range 分段拉同一个包，
# 短时间内同一客户端只算一次，避免把一次下载数成好几次
_dl_seen = {}
DL_DEDUPE_SEC = 30


def record_app_download(request):
    """记一次 App 安装包下载（带 Range/短时去重）"""
    try:
        rng = (request.headers.get("range") or "").strip().lower()
        if rng and not rng.startswith("bytes=0-"):
            return                       # 续传/分段，不算新下载
        ip = client_ip(request)
        ua = (request.headers.get("user-agent") or "")[:120]
        key = (ip, ua)
        now = time.time()
        with _lock:
            last = _dl_seen.get(key)
            if last and now - last < DL_DEDUPE_SEC:
                return
            if len(_dl_seen) > 5000:
                _dl_seen.clear()
            _dl_seen[key] = now
        date = today()
        with _lock:
            b = _bucket(date)
            h = _hour()
            b["app_downloads"] += 1
            b["hourly"]["app_downloads"][h] += 1
            if ip and len(b["ips"]) < MAX_IPS and ip not in b["ips"]:
                b["ips"].append(ip)
            if ip and len(b["hourly_ips"][h]) < MAX_IPS and ip not in b["hourly_ips"][h]:
                b["hourly_ips"][h].append(ip)
            b["updated_at"] = db.now()
            _dirty.add(date)
    except Exception:
        pass


def record_reading(user_id, seconds):
    """记一次阅读时长心跳"""
    try:
        date = today()
        with _lock:
            b = _bucket(date)
            _sec = max(0, int(seconds))
            b["reading_seconds"] += _sec
            b["hourly"]["reading_seconds"][_hour()] += _sec
            if user_id and user_id not in b["readers"] and len(b["readers"]) < MAX_USERS:
                b["readers"].append(user_id)
            if user_id and user_id not in b["users"] and len(b["users"]) < MAX_USERS:
                b["users"].append(user_id)
            b["updated_at"] = db.now()
            _dirty.add(date)
    except Exception:
        pass


def record_error(request, path, status):
    """记一次服务端错误（5xx）"""
    try:
        date = today()
        with _lock:
            b = _bucket(date)
            b["errors"] += 1
            b["hourly"]["errors"][_hour()] += 1
            b["updated_at"] = db.now()
            _dirty.add(date)
    except Exception:
        pass


# ---------------------------------------------------------------- 库表快照
_DB_METRICS = (
    # key, 表, 额外条件
    ("new_users", "users", ""),
    ("uploads", "books", "AND owner_id IS NOT NULL"),
    ("book_downloads", "download_logs", ""),
    ("booklists", "booklists", ""),
    ("share_requests", "share_requests", ""),
)


def db_metrics(start, end):
    """统计 [start, end] 每天由库表直接数出来的指标，返回 {date: {key: n}}"""
    out = {}
    for key, table, extra in _DB_METRICS:
        try:
            rows = db.q(f"""SELECT substr(created_at,1,10) d, COUNT(*) n FROM {table}
                            WHERE created_at>=? AND created_at<? {extra} GROUP BY d""",
                        (start, end + " 99"))
        except Exception:
            continue
        for r in rows:
            out.setdefault(r["d"], {})[key] = r["n"]
    return out


def _today_db_metrics(date):
    return db_metrics(date, date).get(date, {})


def db_metrics_hourly(date):
    """从库表按小时数出来的指标，返回 {小时: {key: n}}"""
    out = {}
    for key, table, extra in _DB_METRICS:
        try:
            rows = db.q(f"""SELECT CAST(substr(created_at,12,2) AS INTEGER) h, COUNT(*) n
                            FROM {table} WHERE substr(created_at,1,10)=? {extra} GROUP BY h""", (date,))
        except Exception:
            continue
        for r in rows:
            if r["h"] is None:
                continue
            out.setdefault(int(r["h"]), {})[key] = r["n"]
    return out


def hour_now():
    """当前北京时间的小时（1 天视图只画到当前小时）"""
    return _bj_now().hour


def hourly_series(date):
    """某天 24 小时的分时数据（「1天」视图用）"""
    with _lock:
        b = _days.get(date)
    if b is None:
        b = load_day(date) or _blank(date)
    hh = _norm_hourly(b.get("hourly"))
    hips = _norm_hourly_ips(b.get("hourly_ips"))
    dbh = db_metrics_hourly(date)
    out = []
    for i in range(24):
        m = dbh.get(i, {})
        _pv, _app = int(hh["pv"][i]), int(hh["app_downloads"][i])
        out.append({
            "hour": "%02d" % i,
            "pv": _pv,
            # 老文件的 hourly 是「访问量+App下载」混在一起、且没有分时 IP 的，
            # 那种情况下这个小时的独立 IP 是「不知道」，不是 0
            "ip_count": len(hips[i]) if (hips[i] or (_pv + _app) == 0) else None,
            "app_downloads": int(hh["app_downloads"][i]),
            "reading_seconds": int(hh["reading_seconds"][i]),
            "errors": int(hh["errors"][i]),
            "new_users": int(m.get("new_users", 0)),
            "uploads": int(m.get("uploads", 0)),
            "book_downloads": int(m.get("book_downloads", 0)),
            "booklists": int(m.get("booklists", 0)),
            "share_requests": int(m.get("share_requests", 0)),
        })
    return out


# ---------------------------------------------------------------- WebDAV 读写
def _load_day_uncached(date):
    try:
        raw = ftp_service.read_bytes(day_path(date))
        if not raw:
            return None
        d = json.loads(raw.decode("utf-8"))
        if not isinstance(d, dict):
            return None
        d["hourly"] = _norm_hourly(d.get("hourly"))          # 老文件就地升级
        d["hourly_ips"] = _norm_hourly_ips(d.get("hourly_ips"))
        return d
    except Exception:
        return None


def _cache_fresh(date):
    """历史日文件封盘后就不再变了，可以一直缓存；只有今天需要短 TTL"""
    with _lock:
        hit = _day_cache.get(date)
    if not hit:
        return False
    if date < today():
        return True                      # 已封盘，永不失效
    return time.time() - hit[1] < DAY_CACHE_TTL


def load_day(date, use_cache=True):
    """从 WebDAV 读某天的文件（带缓存），失败/不存在返回 None"""
    if use_cache:
        with _lock:
            hit = _day_cache.get(date)
        if hit and _cache_fresh(date):
            return hit[0]
    doc = _load_day_uncached(date)
    with _lock:
        _day_cache[date] = (doc, time.time())
    return doc


def _invalidate(date):
    with _lock:
        _day_cache.pop(date, None)


def save_day(bucket):
    """把某天写回 WebDAV"""
    global _last_error
    date = bucket.get("date")
    doc = dict(bucket)
    doc["ips"] = list(doc.get("ips") or [])[:MAX_IPS]
    doc["users"] = list(doc.get("users") or [])[:MAX_USERS]
    doc["readers"] = list(doc.get("readers") or [])[:MAX_USERS]
    doc["updated_at"] = db.now()
    try:
        ftp_service.write_bytes(day_path(date), json.dumps(doc, ensure_ascii=False).encode("utf-8"))
        _last_error = ""
        with _lock:
            _day_cache[date] = (doc, time.time())
        return True
    except Exception as e:
        _last_error = str(e)[:200]
        return False


def flush(force_db_snapshot=False):
    """把脏数据写回 WebDAV。返回成功落盘的日期数。"""
    with _lock:
        dates = sorted(_dirty)
        _dirty.clear()
        snapshot = {}
        for d in dates:
            b = _days.get(d)
            if b is None:
                continue
            if force_db_snapshot or not b.get("db"):
                b["db"] = _today_db_metrics(d)
            snapshot[d] = dict(b)
    ok = 0
    for d, b in snapshot.items():
        if save_day(b):
            ok += 1
        else:
            with _lock:
                _dirty.add(d)          # 落盘失败，下次再试
    return ok


def prune(days=RETENTION_DAYS):
    """删掉超过保留期的老文件，返回删除数量"""
    global _last_prune
    _last_prune = time.time()
    cutoff = (_bj_now() - timedelta(days=days)).strftime("%Y-%m-%d")
    removed = 0
    try:
        years = ftp_service.list_dir(STATS_ROOT) or []
    except Exception:
        return 0
    for item in years:
        name = item.get("name") or ""
        if not (len(name) == 4 and name.isdigit()):
            continue
        try:
            files = ftp_service.list_dir(f"{STATS_ROOT}/{name}") or []
        except Exception:
            continue
        left = []
        for f in files:
            fn = f.get("name") or ""
            if not fn.endswith(".json") or len(fn) != 15:
                left.append(fn)
                continue
            if fn[:10] < cutoff:
                try:
                    ftp_service.delete(f"{STATS_ROOT}/{name}/{fn}")
                    removed += 1
                except Exception:
                    pass
            else:
                left.append(fn)
        if not left:                     # 该年已经空了，把空目录也收掉
            try:
                ftp_service.delete(f"{STATS_ROOT}/{name}")
            except Exception:
                pass
    return removed


# ---------------------------------------------------------------- 后台线程
def _loop():
    # 启动后先补一次封盘与清理，再进入常规循环
    try:
        _seal_yesterday()
    except Exception:
        pass
    try:
        prune()
    except Exception:
        pass
    try:
        warm_cache()
    except Exception:
        pass
    while True:
        time.sleep(FLUSH_SEC)
        try:
            flush()
        except Exception:
            pass
        try:
            # 每 6 小时清理一次三年以前的老文件
            if time.time() - _last_prune > 6 * 3600:
                prune()
        except Exception:
            pass


WARM_DAYS = 200   # 覆盖「最近 90 天 + 前 90 天 + 1 天环比基线」，否则切到 90 天还要现读 180+ 个文件


def warm_cache(days=WARM_DAYS):
    """预热历史日文件缓存：不预热的冷缓存下，切到 90 天要读 180 个远端文件"""
    end = _bj_now().date()
    dates = [(end - timedelta(days=i)).strftime("%Y-%m-%d") for i in range(days)]
    dates = [d for d in dates if not _cache_fresh(d)]
    if not dates:
        return 0
    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=12) as ex:
        list(ex.map(load_day, dates))
    return len(dates)


def _seal_yesterday():
    """把昨天封盘：补全库表快照后写回（重启补漏）"""
    yesterday = (_bj_now() - timedelta(days=1)).strftime("%Y-%m-%d")
    b = _bucket(yesterday)
    b["db"] = _today_db_metrics(yesterday)
    save_day(b)
    with _lock:
        _dirty.discard(yesterday)


def start():
    """启动后台落盘线程（幂等）。全部动作都在后台线程里做，不拖慢服务启动。"""
    global _started
    with _lock:
        if _started:
            return
        _started = True
    threading.Thread(target=_loop, daemon=True, name="stats-flusher").start()


def shutdown():
    try:
        flush(force_db_snapshot=True)
    except Exception:
        pass


# ---------------------------------------------------------------- 对外查询
def day_summary(date, bucket=None, dbm=None):
    """把某天整理成前端要的扁平结构"""
    b = bucket if bucket is not None else (load_day(date) or _blank(date))
    m = dict(b.get("db") or {})
    if dbm is not None:
        m.update(dbm.get(date) or {})
    return {
        "date": date,
        "pv": int(b.get("pv", 0)),
        "ip_count": len(b.get("ips") or []),
        "app_downloads": int(b.get("app_downloads", 0)),
        "reading_seconds": int(b.get("reading_seconds", 0)),
        "reader_count": len(b.get("readers") or []),
        "active_users": len(b.get("users") or []),
        "errors": int(b.get("errors", 0)),
        "hourly": b.get("hourly") or [0] * 24,
        "paths": b.get("paths") or {},
        "new_users": int(m.get("new_users", 0)),
        "uploads": int(m.get("uploads", 0)),
        "book_downloads": int(m.get("book_downloads", 0)),
        "booklists": int(m.get("booklists", 0)),
        "share_requests": int(m.get("share_requests", 0)),
    }


# 「网站统计」页的时间范围档位。图表/概览卡/每日明细共用同一个窗口，
# 同比基线自动取前一个等长窗口，所以换档位不需要前端再发请求。
# 取数天数 = days*2 + 1（本窗口 + 前一窗口 + 最早那行算环比要多一天）。
SITE_RANGES = (1, 7, 15, 30, 90)
SITE_DEFAULT_DAYS = 7


def norm_site_days(days):
    """把前端传来的天数收敛到允许的档位，非法值一律回默认 7 天"""
    try:
        n = int(days)
    except Exception:
        return SITE_DEFAULT_DAYS
    return n if n in SITE_RANGES else SITE_DEFAULT_DAYS

# 明细表里带环比高亮的指标（访问量/阅读时长/书籍下载最能反映冷热）
TREND_KEYS = ("pv", "reading_seconds", "book_downloads")

_SUM_KEYS = ("pv", "ip_count", "app_downloads", "reading_seconds", "reader_count",
             "active_users", "errors", "new_users", "uploads", "book_downloads",
             "booklists", "share_requests")
_TREND_KEYS_ALL = ("pv", "ip_count", "app_downloads", "reading_seconds", "reader_count",
                   "active_users", "errors", "new_users", "uploads", "book_downloads",
                   "booklists", "share_requests")


def _sum(items, keys=_SUM_KEYS):
    return {k: sum(int(d.get(k, 0) or 0) for d in items) for k in keys}


def site_report(days=SITE_DEFAULT_DAYS):
    """「网站统计」页要的一整包数据。

    图表、概览卡、每日明细都用同一个时间窗口（days 天），
    同时取前一个等长窗口做同比基线：需要 2*days 天，
    再多取 1 天是为了让窗口里最早那行也有「前一天」可以算环比。
    """
    days = norm_site_days(days)
    items = recent(days * 2 + 1)           # 升序，最后一个是今天
    win = items[-days:]
    prev = items[-2 * days:-days] if len(items) >= 2 * days else items[:max(0, len(items) - days)]

    # 每行相对前一天的变化（环比）。
    rows = []
    for i, d in enumerate(win):
        j = len(items) - days - 1 + i      # 正好是这行的前一天
        p = items[j] if 0 <= j < len(items) else None
        r = dict(d)
        r["trend"] = {k: _trend(d.get(k), (p or {}).get(k)) for k in TREND_KEYS}
        r["prev_date"] = (p or {}).get("date")
        rows.append(r)

    return {
        "chart": win,
        "table": rows,
        "table_prev_totals": _sum(prev),
        "totals": _sum(win),
        "prev_totals": _sum(prev),
        "days": days,
        "chart_days": days,                # 兼容旧前端字段
        "table_days": days,
        "trend_keys": list(TREND_KEYS),
        "overview": overview(),
        "today": items[-1] if items else None,
    }


def _trend(cur, prev):
    """环比：返回 {pct, dir}。没有可比基线时 pct 为 None。"""
    try:
        cur = int(cur or 0)
        if prev is None:
            return {"pct": None, "dir": "flat"}
        prev = int(prev or 0)
        if prev == 0:
            return {"pct": None, "dir": "up" if cur > 0 else "flat"}
        pct = (cur - prev) / prev * 100
        if abs(pct) < 0.5:
            return {"pct": 0.0, "dir": "flat"}
        return {"pct": round(pct, 1), "dir": "up" if pct > 0 else "down"}
    except Exception:
        return {"pct": None, "dir": "flat"}


def recent(days=15):
    """最近 N 天（含今天），按日期升序"""
    end = _bj_now().date()
    start = end - timedelta(days=days - 1)
    dates = [(start + timedelta(days=i)).strftime("%Y-%m-%d") for i in range(days)]
    dbm = db_metrics(dates[0], dates[-1])
    with _lock:
        live = {d: _days.get(d) for d in dates}

    # 历史文件并发取，冷缓存时也就一个来回的时间
    need = [d for d in dates if live.get(d) is None and not _cache_fresh(d)]
    if need:
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=12) as ex:
            list(ex.map(load_day, need))

    out = []
    for d in dates:
        with _lock:
            b = _days.get(d)
        out.append(day_summary(d, bucket=b, dbm=dbm))
    return out


def before(days=15):
    """紧邻的前一个等长周期（用于同比）"""
    end = _bj_now().date() - timedelta(days=days)
    start = end - timedelta(days=days - 1)
    dates = [(start + timedelta(days=i)).strftime("%Y-%m-%d") for i in range(days)]
    dbm = db_metrics(dates[0], dates[-1])
    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=12) as ex:
        list(ex.map(load_day, dates))
    return [day_summary(d, bucket=None, dbm=dbm) for d in dates]


def overview():
    """总量与运行状态，给页面顶部的概览卡用"""
    with _lock:
        pending = len(_dirty)
        days_cached = len(_days)
    total_day = None
    try:
        total_day = db.q("SELECT COUNT(*) n FROM books WHERE owner_id IS NOT NULL", one=True)["n"]
    except Exception:
        pass
    return {"today": today(), "retention_days": RETENTION_DAYS,
            "pending_writes": pending, "days_in_memory": days_cached,
            "stats_root": STATS_ROOT, "last_error": _last_error,
            "member_uploads_total": total_day}
