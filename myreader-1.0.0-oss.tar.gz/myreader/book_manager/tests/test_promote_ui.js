// 推广 / 邀请（两条独立渠道）的界面回归：
//   1. 「我的」页有「推广邀请」板块，且必须在「我的分享」**之上**
//   2. 「推广」「邀请」是两个**各自独立**的板块：权限、码、奖励都分开
//      —— 只开推广权限的用户，不该看到「邀请」板块
//   3. 注册页有「邀请码」输入框；后台开「邀请注册」→ 提示「（必须）」，关 → 「（可选）」
//   4. 带 ?invite=XXXX 的链接打开时，注册框自动填上码（两条渠道共用这个入口）
//   5. 后台「分组管理」的编辑弹窗有两个权限勾选 + 两个奖励输入框
//
// 前置：服务在 https://127.0.0.1:9000 运行。
// 本脚本临时建两个测试分组 + 两个测试用户（随机 TAG），结束后按精确 id 删除并还原配置。
// 运行：NODE_PATH=/tmp/pwtest/node_modules node tests/test_promote_ui.js
const { chromium } = require('playwright-core');
const { execSync } = require('child_process');
const CHROME = '/srv/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome';
const ROOT = '/srv/myreader/book_manager';
const BASE = 'https://127.0.0.1:9000';

let pass = 0, fail = 0;
const ck = (n, ok, extra) => {
  if (ok) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (extra ? '  → ' + extra : '')); }
};
const py = (code) => execSync('venv/bin/python -', { cwd: ROOT, encoding: 'utf8', input: code }).trim();

(async () => {
  const info = JSON.parse(py(`
import sys, json, uuid
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
import db, auth, promote
tag = 'zzui_pm_' + uuid.uuid4().hex[:6]
# 两条渠道都开：推广 7 叶 / 邀请 11 叶
gid = db.ex("INSERT INTO user_groups (code,name,can_promote,can_invite,promote_reward,invite_reward,created_at) "
            "VALUES (?,?,1,1,7,11,?)", (tag, tag, db.now()))
uid = db.ex("INSERT INTO users (username,password_hash,role,quota,enabled,group_id,name,created_at) "
            "VALUES (?,?,?,0,1,?,?,?)",
            (tag, auth.hash_password('x'*10), 'user', gid, tag, db.now()))
u = db.q("SELECT * FROM users WHERE id=?", (uid,), one=True)
# 只开推广：用来验「没权限的渠道不显示」
gid2 = db.ex("INSERT INTO user_groups (code,name,can_promote,can_invite,promote_reward,invite_reward,created_at) "
             "VALUES (?,?,1,0,9,0,?)", (tag + 'b', tag + 'b', db.now()))
uid2 = db.ex("INSERT INTO users (username,password_hash,role,quota,enabled,group_id,name,created_at) "
             "VALUES (?,?,?,0,1,?,?,?)",
             (tag + 'b', auth.hash_password('x'*10), 'user', gid2, tag + 'b', db.now()))
u2 = db.q("SELECT * FROM users WHERE id=?", (uid2,), one=True)
admin = db.q("SELECT * FROM users WHERE role='admin' AND enabled=1 ORDER BY id LIMIT 1", one=True)
print(json.dumps({"tag": tag, "gid": gid, "uid": uid, "gid2": gid2, "uid2": uid2,
                  "pcode": promote.code_of(uid, 'promote'),
                  "icode": promote.code_of(uid, 'invite'),
                  "token": auth.create_token(u), "user": dict(u),
                  "token2": auth.create_token(u2), "user2": dict(u2),
                  "atoken": auth.create_token(admin),
                  "cfg": db.get_config("invite_register", "0")}))
`));
  const setCfg = (v) => py(`
import sys
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
import db
db.set_config('invite_register', '${v}')
print(db.get_config('invite_register', '0'))
`);

  const browser = await chromium.launch({ executablePath: CHROME, args: ['--no-sandbox'] });
  const errs = [];
  const ctxFor = async (token, user, viewport) => {
    const c = await browser.newContext({ ignoreHTTPSErrors: true, viewport: viewport || { width: 420, height: 900 } });
    if (token) {
      await c.addInitScript(([t, u]) => {
        localStorage.setItem('bm_token', t); localStorage.setItem('bm_user', u);
      }, [token, JSON.stringify(user)]);
    }
    return c;
  };
  // 打开「我的」页并等推广板块渲染完
  const openMe = async (token, user) => {
    const p = await (await ctxFor(token, user)).newPage();
    p.on('pageerror', e => errs.push(String(e)));
    await p.goto(BASE + '/', { waitUntil: 'domcontentloaded' });
    await p.waitForFunction(() => typeof switchPage === 'function', null, { timeout: 15000 });
    await p.evaluate(() => switchPage('me'));
    await p.waitForFunction(() => {
      const c = document.getElementById('me-promote-card');
      if (!c || c.style.display === 'none') return false;
      const l = document.getElementById('me-promote-link');
      return !!l && l.value.indexOf('?invite=') >= 0;
    }, null, { timeout: 15000 }).catch(() => {});
    return p;
  };
  const readMe = (p) => p.evaluate(() => {
    const vis = (id) => {
      const el = document.getElementById(id);
      return !!el && getComputedStyle(el).display !== 'none';
    };
    const card = document.getElementById('me-promote-card');
    const stats = document.getElementById('me-promote-stats');
    const boxes = Array.from(stats.querySelectorAll('.me-stat'));
    // 「做到一行」不能靠肉眼：比较四格的 top，必须完全相同才算同一行
    const tops = boxes.map(b => Math.round(b.getBoundingClientRect().top));
    return {
      cardVisible: vis('me-promote-card'),
      pBlock: vis('me-promote-block-promote'),
      iBlock: vis('me-promote-block-invite'),
      pLink: document.getElementById('me-promote-link').value,
      pHasCode: !!document.getElementById('me-promote-code'),
      iCode: document.getElementById('me-invite-code').textContent.trim(),
      iHasLink: !!document.getElementById('me-invite-link'),
      pReward: document.getElementById('me-promote-reward').textContent,
      iReward: document.getElementById('me-invite-reward').textContent,
      statLabels: boxes.map(b => (b.querySelector('span') || {}).textContent || ''),
      statVals: ['me-st-promote', 'me-st-invite', 'me-st-valid', 'me-st-reward']
        .map(id => document.getElementById(id).textContent.trim()),
      statCount: boxes.length,
      oneRow: tops.length === 4 && new Set(tops).size === 1,
      cardTop: card ? card.getBoundingClientRect().top + window.scrollY : -1,
      shareTop: (() => {
        const s = document.getElementById('my-shares');
        return s ? s.closest('.card').getBoundingClientRect().top + window.scrollY : -1;
      })(),
    };
  });

  try {
    // ================= A. 两条渠道都有权限 =================
    const pa = await openMe(info.token, info.user);
    const a = await readMe(pa);
    ck('A1 板块显示出来了', a.cardVisible);
    ck('A2 ★「推广」「邀请」是两个独立板块', a.pBlock && a.iBlock, JSON.stringify([a.pBlock, a.iBlock]));
    ck('A3 推广给的是链接，带自己的码', a.pLink.indexOf('?invite=' + info.pcode) >= 0, a.pLink);
    ck('A4 ★推广**不再显示推广码**', a.pHasCode === false);
    ck('A5 邀请给的是码，且是 4 位', a.iCode === info.icode && a.iCode.length === 4,
       a.iCode + ' vs ' + info.icode);
    ck('A6 ★邀请**不再显示邀请链接**', a.iHasLink === false);
    // 两处排版收紧了 —— 链接框里不能再塞邀请码那套
    ck('A7 推广奖励显示 7', a.pReward.indexOf('7') >= 0, a.pReward);
    ck('A8 邀请奖励显示 11（各自独立）', a.iReward.indexOf('11') >= 0, a.iReward);

    // 统计：一行四项
    ck('A9 ★统计是四项（不再分成两块）', a.statCount === 4, String(a.statCount));
    ck('A10 ★四项排列在同一行', a.oneRow, JSON.stringify(a.statLabels));
    ck('A11 四项标题正确',
       a.statLabels.join(',') === '推广注册,邀请注册,有效注册,累计奖励', a.statLabels.join(','));
    ck('A12 ★「累计奖励树叶」已改名为「累计奖励」',
       a.statLabels.indexOf('累计奖励') >= 0 && a.statLabels.indexOf('累计奖励树叶') < 0);
    ck('A13 统计有数值', a.statVals.every(v => v !== ''), a.statVals.join('/'));
    ck('A14 板块在「我的分享」之上', a.cardTop >= 0 && a.shareTop >= 0 && a.cardTop < a.shareTop,
       a.cardTop + ' vs ' + a.shareTop);

    // ================= B. 只开推广权限 =================
    const pb = await openMe(info.token2, info.user2);
    const b = await readMe(pb);
    ck('B1 只开推广时板块整体显示', b.cardVisible);
    ck('B2 推广板块显示', b.pBlock);
    ck('B3 ★没开邀请权限 → 邀请板块**不显示**', !b.iBlock);
    ck('B4 推广链接正常', b.pLink.indexOf('?invite=') >= 0, b.pLink);
    ck('B5 只推广的分组显示它自己的单价 9', b.pReward.indexOf('9') >= 0, b.pReward);
    ck('B6 ★统计仍然是一行四项（不因只剩一条渠道而变）',
       b.statCount === 4 && b.oneRow, JSON.stringify(b.statLabels));

    // 无权限用户
    const pc0 = await (await ctxFor(null, null)).newPage();
    await pc0.goto(BASE + '/', { waitUntil: 'domcontentloaded' });
    await pc0.evaluate(() => switchPage('me'));
    await pc0.waitForTimeout(600);
    const g = await pc0.evaluate(() => {
      const el = document.getElementById('me-promote-card');
      return { exists: !!el, visible: !!el && getComputedStyle(el).display !== 'none' };
    });
    ck('B7 未登录/无权限时板块不显示', g.exists && !g.visible, JSON.stringify(g));

    // ================= C. 注册页 =================
    await setCfg('0');
    const p2 = await (await ctxFor(null, null)).newPage();
    p2.on('pageerror', e => errs.push(String(e)));
    await p2.goto(BASE + '/', { waitUntil: 'domcontentloaded' });
    await p2.waitForFunction(() => typeof showAuth === 'function', null, { timeout: 15000 });
    await p2.evaluate(() => { showAuth(); switchAuth('register'); });
    await p2.waitForTimeout(500);
    let c = await p2.evaluate(() => {
      const i = document.getElementById('reg-invite');
      return { exists: !!i, hint: document.getElementById('reg-invite-hint').textContent };
    });
    ck('C1 注册页有邀请码输入框', c.exists);
    ck('C2 关闭时提示「可选」', c.hint.indexOf('可选') >= 0, c.hint);

    await setCfg('1');
    await p2.reload({ waitUntil: 'domcontentloaded' });
    await p2.waitForFunction(() => typeof showAuth === 'function', null, { timeout: 15000 });
    await p2.evaluate(() => { showAuth(); switchAuth('register'); });
    await p2.waitForTimeout(500);
    c = await p2.evaluate(() => ({
      hint: document.getElementById('reg-invite-hint').textContent,
      ph: document.getElementById('reg-invite').placeholder,
    }));
    ck('C3 开启时提示「必须」', c.hint.indexOf('必须') >= 0, c.hint);
    ck('C4 开启时占位文案跟着变', c.ph.indexOf('邀请注册') >= 0, c.ph);

    // ?invite= 自动填码（推广码、邀请码两种都要认）
    for (const [label, code] of [['推广码', info.pcode], ['邀请码', info.icode]]) {
      const px = await (await ctxFor(null, null)).newPage();
      await px.goto(BASE + '/?invite=' + code, { waitUntil: 'domcontentloaded' });
      await px.waitForFunction(() => typeof showAuth === 'function', null, { timeout: 15000 });
      await px.evaluate(() => { showAuth(); switchAuth('register'); });
      await px.waitForTimeout(400);
      const v = await px.evaluate(() => document.getElementById('reg-invite').value);
      ck('C5 ?invite=' + label + ' 打开时自动填码', v === code, v + ' vs ' + code);
      const auto = await px.evaluate(() => {
        const el = document.getElementById('reg-invite-auto');
        return { exists: !!el, visible: !!el && getComputedStyle(el).display !== 'none',
                 text: el ? el.textContent : '' };
      });
      ck('C6 ?invite=' + label + ' 时提示「已自动填入，无需修改」',
         auto.exists && auto.visible && auto.text.indexOf('自动填入') >= 0, JSON.stringify(auto));
    }
    // 没有带码进来时不该出现那句提示（否则用户会以为系统替他填了什么）
    const pn = await (await ctxFor(null, null)).newPage();
    await pn.goto(BASE + '/', { waitUntil: 'domcontentloaded' });
    await pn.waitForFunction(() => typeof showAuth === 'function', null, { timeout: 15000 });
    await pn.evaluate(() => { showAuth(); switchAuth('register'); });
    await pn.waitForTimeout(400);
    const noAuto = await pn.evaluate(() => {
      const el = document.getElementById('reg-invite-auto');
      return { visible: !!el && getComputedStyle(el).display !== 'none',
               val: document.getElementById('reg-invite').value };
    });
    ck('C7 没带码进来时不显示自动填入提示', !noAuto.visible && noAuto.val === '',
       JSON.stringify(noAuto));
    await setCfg(info.cfg || '0');

    // ================= D. 后台 =================
    const pd = await (await ctxFor(info.atoken, { id: 1, role: 'admin', username: 'admin' })).newPage();
    pd.on('pageerror', e => errs.push(String(e)));
    await pd.goto(BASE + '/admin', { waitUntil: 'domcontentloaded' });
    await pd.waitForFunction(() => typeof loadConfig === 'function', null, { timeout: 20000 });
    await pd.waitForTimeout(1200);
    const d1 = await pd.evaluate(() => {
      const el = document.getElementById('reg-invite');
      return { exists: !!el, checked: el ? el.checked : null,
               text: el ? el.closest('.card').textContent : '' };
    });
    ck('D1 后台有「邀请注册」开关', d1.exists);
    ck('D2 开关状态与配置一致', d1.checked === (info.cfg === '1'), String(d1.checked));
    ck('D3 开关旁说明了必须/可选', d1.text.indexOf('必须') >= 0 && d1.text.indexOf('可选') >= 0);

    const d2 = await pd.evaluate((gid) => {
      editGroup(gid);
      const r = {
        pPerm: !!document.getElementById('eg-promote'),
        iPerm: !!document.getElementById('eg-invite'),
        pChecked: (document.getElementById('eg-promote') || {}).checked,
        iChecked: (document.getElementById('eg-invite') || {}).checked,
        pReward: !!document.getElementById('eg-promote_reward'),
        iReward: !!document.getElementById('eg-invite_reward'),
        pVal: (document.getElementById('eg-promote_reward') || {}).value,
        iVal: (document.getElementById('eg-invite_reward') || {}).value,
      };
      closeModal();
      return r;
    }, info.gid);
    ck('D4 分组弹窗有「推广」权限勾选', d2.pPerm && d2.pChecked === true, JSON.stringify(d2));
    ck('D5 ★分组弹窗有「邀请」权限勾选（独立）', d2.iPerm && d2.iChecked === true, JSON.stringify(d2));
    ck('D6 分组弹窗有推广奖励输入框且值 7', d2.pReward && String(d2.pVal) === '7', JSON.stringify(d2));
    ck('D7 ★分组弹窗有邀请奖励输入框且值 11', d2.iReward && String(d2.iVal) === '11', JSON.stringify(d2));

    const d3 = await pd.evaluate((gid) => {
      editGroup(gid);
      const r = {
        pChecked: (document.getElementById('eg-promote') || {}).checked,
        iChecked: (document.getElementById('eg-invite') || {}).checked,
        iVal: (document.getElementById('eg-invite_reward') || {}).value,
      };
      closeModal();
      return r;
    }, info.gid2);
    ck('D8 ★只开推广的分组：邀请勾选是关的', d3.pChecked === true && d3.iChecked === false,
       JSON.stringify(d3));
    ck('D9 只开推广的分组：邀请奖励是 0', String(d3.iVal) === '0', JSON.stringify(d3));
    ck('D10 两个测试分组的邀请码都是 4 位',
       info.icode.length === 4 && info.pcode.length === 8, info.icode + '/' + info.pcode);

    // ================= E. 审计日志 =================
    const d4 = await pd.evaluate(async () => {
      if (typeof switchSec === 'function') switchSec('audit');
      await new Promise(r => setTimeout(r, 1200));
      const wrap = document.getElementById('audit-list');
      return {
        hasMap: typeof AUDIT_LABELS === 'object' && !!AUDIT_LABELS.promote_gen,
        tags: Array.from(wrap.querySelectorAll('.tag')).map(t => t.textContent.trim()),
        titles: Array.from(wrap.querySelectorAll('.tag')).map(t => t.getAttribute('title') || ''),
      };
    });
    ck('E1 审计动作有中文名映射', d4.hasMap === true);
    ck('E2 审计列表渲染出中文操作名',
       d4.tags.some(t => t.indexOf('邀请') >= 0 || t.indexOf('推广') >= 0),
       d4.tags.slice(0, 6).join(' / '));
    ck('E3 原始动作码保留在 title 里备查',
       d4.titles.some(t => t.indexOf('invite') >= 0 || t.indexOf('promote') >= 0),
       d4.titles.slice(0, 6).join(' / '));
    ck('E4 ★推广奖励与邀请奖励是两个不同的中文名',
       d4.tags.indexOf('发放推广奖励') >= 0 || d4.tags.indexOf('发放邀请奖励') >= 0,
       d4.tags.slice(0, 8).join(' / '));
    ck('E5 全程没有 JS 报错', errs.length === 0, errs.slice(0, 2).join(' | '));
  } finally {
    await browser.close();
    py(`
import sys
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
import db
uids = [${info.uid}, ${info.uid2}]
gids = [${info.gid}, ${info.gid2}]
for uid in uids:
    for sql, a in (("DELETE FROM invite_codes WHERE uid=?", (uid,)),
                   ("DELETE FROM invites WHERE inviter_id=? OR invitee_id=?", (uid, uid)),
                   ("DELETE FROM leaf_gain WHERE user_id=?", (uid,)),
                   ("DELETE FROM user_leaves WHERE user_id=?", (uid,)),
                   ("DELETE FROM messages WHERE to_id=? OR from_id=?", (uid, uid)),
                   ("DELETE FROM users WHERE id=?", (uid,))):
        try: db.ex(sql, a)
        except Exception: pass
for gid in gids:
    try: db.ex("DELETE FROM user_groups WHERE id=?", (gid,))
    except Exception: pass
db.set_config('invite_register', '${info.cfg || '0'}')
print('cleaned')
`);
    console.log('');
    console.log('推广/邀请（双渠道）界面：' + pass + ' 通过 / ' + fail + ' 失败');
  }
})();
