// 「有声」页面的界面回归（导航位置、列表、详情、播放与文字同步只能靠浏览器实测）。
//
// 前置：服务在 https://127.0.0.1:9000 运行，库里已有登记过的有声电子书（本脚本用 #1 三体全集）。
// 本脚本**只读**，不造数据、不改配置，结束后无需清理。
// 运行：NODE_PATH=/tmp/pwtest/node_modules node tests/test_audio_ui.js
const { chromium } = require('playwright-core');
const { execSync } = require('child_process');
const CHROME = '/srv/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome';
const ROOT = '/srv/myreader/book_manager';
const BASE = 'https://127.0.0.1:9000';

let pass = 0, fail = 0;
const ck = (n, ok, extra) => {
  if (ok) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (extra ? '  → ' + extra : '')); }
};
const py = (code) => execSync('venv/bin/python -', { cwd: ROOT, encoding: 'utf8', input: code }).trim();

(async () => {
  // 取一个管理员令牌和一个已登记的有声书 id（都从库里现查，不写死）
  const info = JSON.parse(py(`
import sys, json
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
import db, auth
u = db.q("SELECT * FROM users WHERE role='admin' AND enabled=1 ORDER BY id LIMIT 1", one=True)
db.ex("DELETE FROM ab_session WHERE user_id=?", (u["id"],))   # 清掉上一轮测试遗留的有声单端锁
# ★ 不能简单取「最新一本」。新入库的书可能 (a) 第 1 章是**扉页**（书名/作者/译者，
#   只有十几秒三四行字），(b) 压根没有封面（books.cover 为 NULL）。本测试要断言
#   「第 1 章歌词 >5 行」和「卡片封面真的加载出来」，两样缺一不可；拿到扉页还会
#   因为章节太短播到 ended，把后面的悬浮条断言一起带崩。
lib = db.q("SELECT l.id, l.title, l.total_chapters, l.author, b.rating, l.cover FROM ab_lib l LEFT JOIN books b ON b.id=l.book_id WHERE l.hidden=0 AND l.cover IS NOT NULL AND l.cover <> '' AND (SELECT COUNT(*) FROM ab_lib_seg s WHERE s.lib_id=l.id AND s.chap_seq=1) > 20 ORDER BY l.sort, l.id DESC LIMIT 1", one=True)
print(json.dumps({"token": auth.create_token(u), "lib": dict(lib) if lib else None}))
`));
  ck('库里有已登记的有声电子书', !!info.lib, JSON.stringify(info.lib));
  if (!info.lib) { console.log('\n无数据，跳过'); process.exit(1); }
  const LIB = info.lib;

  const browser = await chromium.launch({
    executablePath: CHROME,
    args: ['--autoplay-policy=no-user-gesture-required', '--no-sandbox'],
  });
  const ctx = await browser.newContext({
    ignoreHTTPSErrors: true, viewport: { width: 420, height: 860 },
  });
  await ctx.addInitScript(([tk, lib]) => {
    localStorage.setItem('bm_token', tk);
    localStorage.setItem('bm_user', JSON.stringify({ id: 1, role: 'admin', name: 'admin' }));
    try { sessionStorage.setItem('bm_audio_sid', 'fixaudioui'); } catch (e) {}
  }, [info.token, LIB]);
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  await page.goto(BASE + '/', { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(2500);

  // ---------- 1. 导航：不该再有「有声」（入口已挪进书架） ----------
  const tabs = await page.$$eval('#tabbar .tab', els => els.map(e => e.textContent.trim()));
  ck('底部导航不再有「有声」', !tabs.some(t => t.includes('有声')), tabs.join(' | '));
  const links = await page.$$eval('.nav-links a', els => els.map(e => e.textContent.trim()));
  ck('顶部导航不再有「有声」', !links.some(t => t.includes('有声')), links.join(' | '));
  ck('顶部导航仍有 首页/书架/书单/我的',
     ['首页', '书架', '书单', '我的'].every(n => links.some(t => t.includes(n))), links.join(' | '));

  // ---------- 2a. 书架页的「有声阅读」板块（替代原「公共书库」） ----------
  await page.click('#tabbar .tab[data-page="shelf"]');
  await page.waitForTimeout(1800);
  // 本套件跑在手机视口：那边 #shelf-public 本来就是整行，所以 1/3 只在桌面宽度下断言
  const lp = { desktop: (page.viewportSize() || { width: 420 }).width >= 1024 };
  const sh = await page.evaluate(() => {
    const panel = document.getElementById('shelf-public');
    const src = document.getElementById('cat-list');            // 旧「公共书库」的容器
    const head = panel ? panel.textContent : '';
    const cards = Array.from(document.querySelectorAll('#au-shelf-list .au-shelf-card'));
    const cols = cards.length ? getComputedStyle(document.getElementById('au-shelf-list')).gridTemplateColumns.split(' ').length : 0;
    const cs = getComputedStyle(document.getElementById('au-shelf-list'));
    const cv = document.querySelector('#au-shelf-list .au-cover');
    const hint = document.getElementById('au-shelf-hint');
    const layout = document.querySelector('.shelf-layout');
    const aw = panel ? panel.getBoundingClientRect().width : 0;
    const lw = layout ? layout.getBoundingClientRect().width : 0;
    return { vis: panel && !panel.classList.contains('hidden'),
             hasOld: !!src, head: head.replace(/\s+/g, ' ').slice(0, 40),
             n: cards.length, cols: cs.gridTemplateColumns.split(' ').length,
             first: cards.length ? cards[0].textContent.replace(/\s+/g, ' ').slice(0, 30) : '',
             cats: document.querySelectorAll('#au-shelf-cats .au-cat').length,
             rows: cards.length ? new Set(cards.map(x => Math.round(x.getBoundingClientRect().top))).size : 0,
             coverW: cv ? Math.round(cv.getBoundingClientRect().width) : 0,
             hint: hint ? hint.textContent.trim() : '(无)',
             hintVis: !!hint && getComputedStyle(hint).display !== 'none',
             asidePct: lw ? Math.round(aw / lw * 1000) / 10 : 0,
             overflow: document.getElementById('au-shelf-list').scrollWidth
                       > document.getElementById('au-shelf-list').clientWidth + 1,
             // 提示行字号必须与「书架收藏」那行「已收藏 N / M 本」完全一致
             hintFont: hint ? getComputedStyle(hint).fontSize : '',
             quotaFont: (() => { const q = document.getElementById('shelf-quota');
                                 return q ? getComputedStyle(q).fontSize : ''; })(),
             // 「查看全部」要在分类上方
             moreAboveCats: (() => {
               const m = panel && panel.querySelector('.au-shelf-more');
               const c = document.getElementById('au-shelf-cats');
               return !!(m && c) && m.getBoundingClientRect().top < c.getBoundingClientRect().top;
             })(),
             moreInHead: !!(panel && panel.querySelector('.page-head .au-shelf-more')) };
  });
  ck('书架页出现「有声阅读」板块', sh.vis && /有声阅读/.test(sh.head), sh.head);
  ck('原「公共书库」容器已移除', !sh.hasOld);
  ck('有声阅读显示分类', sh.cats >= 1, '分类数=' + sh.cats);
  ck('有声阅读显示书籍名称', sh.n >= 1, sh.first);
  ck('★每行 3 本', sh.cols === 3, '列数=' + sh.cols);
  ck('★最多 4 行（不超过 12 本）', sh.n <= 12 && sh.rows <= 4, '卡片=' + sh.n + ' 行=' + sh.rows);
  ck('★封面缩到窄卡片里（<160px）', sh.coverW > 0 && sh.coverW < 160, sh.coverW + 'px');
  ck('★卡片没横向溢出', !sh.overflow);
  // 1/3 是**桌面端**的版面约束；本套件跑在手机视口，那边 #shelf-public
  // 本来就是整行（width:100%），所以只在桌面宽度下断言。
  ck('★「有声阅读」板块宽度桌面端仍是 1/3（手机端整行，见下条）',
     lp.desktop ? Math.abs(sh.asidePct - 33.3) < 1.5 : sh.asidePct > 99,
     sh.asidePct + '% ' + (lp.desktop ? '(桌面)' : '(手机整行)'));
  ck('★「有声阅读」下有「有声电子书 N 本」提示',
     sh.hintVis && /有声电子书\s*\d+\s*本/.test(sh.hint), sh.hint);
  ck('★提示行字号与「已收藏 N / M 本」一致',
     !!sh.hintFont && sh.hintFont === sh.quotaFont, sh.hintFont + ' vs ' + sh.quotaFont);
  ck('★「查看全部 →」在分类上方（不再和标题挤一行）',
     sh.moreAboveCats && !sh.moreInHead, 'above=' + sh.moreAboveCats + ' inHead=' + sh.moreInHead);

  // ---------- 2b. 有声列表页（仍可用「查看全部」进入） ----------
  await page.click('#shelf-public .au-shelf-more button');
  await page.waitForTimeout(1500);
  ck('「查看全部」能进有声列表页', await page.$eval('#page-audio', e => !e.classList.contains('hidden')));
  // ★ 列表按「最新」排序，而 fixture 还要求「有封面 + 第 1 章不是扉页」，
  //   所以测试选中的那本**不一定排第一** —— 按书名把卡片找出来，
  //   不能想当然点 .au-card 第一张（否则新入库一本没有封面的书就会误判）。
  const cardTotal = await page.$$eval('.au-card', e => e.length);
  const cardIdx = await page.evaluate(t => [...document.querySelectorAll('.au-card')]
    .findIndex(c => { const el = c.querySelector('.au-title'); return el && el.textContent.includes(t); }),
    LIB.title.slice(0, 6));
  ck('列表里能找到测试选中的那本有声书', cardIdx >= 0, `下标=${cardIdx} 共 ${cardTotal} 张`);
  const card = '.au-card >> nth=' + Math.max(0, cardIdx);
  const cardTitle = await page.textContent(card + ' >> .au-title').catch(() => '');
  ck('列表出现有声书卡片', cardTitle.includes(LIB.title.slice(0, 6)), cardTitle);
  const cardSub = await page.textContent(card).catch(() => '');
  ck('卡片显示章节数与总时长', /\d+\s*章/.test(cardSub) && /(小时|分钟)/.test(cardSub),
     cardSub.replace(/\s+/g, ' ').slice(0, 90));
  const cov = await page.$eval(card + ' >> .au-cover', e => e.tagName === 'IMG'
     ? { src: e.getAttribute('src'), w: e.naturalWidth } : { src: 'ph', w: 0 });
  ck('卡片封面真的加载出来（带媒体票据）', cov.w > 0, JSON.stringify(cov));

  // ---------- 2.5 手机端最要紧的一条：整页**不许横向溢出** ----------
  // ★★ 这条是被真实的业主反馈补上的：有声页面在手机上「宽度过大」，
  //   390px 的手机整页横向滚 47px（卡片 423px 撑破屏幕）。
  //   根因：.au-sub 是 white-space: nowrap（长作者名要一行截断），它的**最小宽度**
  //   等于整行文字的实际宽度；这个宽度经 .au-meta 顶到 .au-card，而卡片是 .au-grid 的
  //   grid item、min-width 默认 auto → 那一列被硬撑到 400 多 px。
  //   桌面端容器本来就宽，一点都看不出来，**只有窄视口才现形**。
  //   本测试一直是 420px 手机视口，却从没量过页面宽度，所以这个 bug 一直躲过去 ——
  //   加这条之前，"卡片能点开、能播放"全都是绿的。
  const pw = await page.evaluate(() => {
    const de = document.documentElement;
    const over = [...document.querySelectorAll('#page-audio *')]
      .filter(e => { const b = e.getBoundingClientRect();
        return b.width > 0 && b.right > de.clientWidth + 1 && getComputedStyle(e).position !== 'fixed'; })
      .map(e => (e.className || '').toString().slice(0, 30));
    return { vw: de.clientWidth, sw: de.scrollWidth, over: over.slice(0, 5), n: over.length };
  });
  ck('★★ 手机端整页没有横向溢出（有声页曾经比屏幕宽 47px）', pw.sw <= pw.vw,
     `scrollWidth=${pw.sw} 视口=${pw.vw}`);
  ck('★★ 有声页里没有元素超出屏幕右边界', pw.n === 0, pw.n + ' 个: ' + JSON.stringify(pw.over));
  const cardW = await page.$eval(card, e => Math.round(e.getBoundingClientRect().width));
  ck('★ 卡片宽度不超过格子容器（没被内容的最小宽度顶开）', cardW <= pw.vw - 28, cardW + 'px');

  // ---------- 3. 详情页 ----------
  await page.click(card);
  await page.waitForTimeout(2000);
  ck('进入详情视图', await page.$eval('#view-audio', e => !e.classList.contains('hidden')));
  const dt = await page.textContent('#au-detail-body');
  ck('详情显示书名', dt.includes(LIB.title.slice(0, 6)));
  if (Number(LIB.rating) > 0) {
    ck('详情显示评分', /★\s*[\d.]+\s*分/.test(dt), (dt.match(/★[^·\n]{0,12}/) || [''])[0]);
  } else {
    // ★ 断言必须**只针对评分那一行**，不能对整个详情做 !/★/。
    //   详情页里还有管理员专用的「加入/取消首页热度推荐」按钮，它本身就可能带星号字符；
    //   一旦那本书被设成推荐，宽断言就会误报（2026-10-11 就是被这本《妖楼》触发的）。
    ck('这本书没有评分时不显示评分（不显示空星）',
       !/★\s*[\d.]+\s*分/.test(dt), (dt.match(/★[^·\n]{0,12}/) || [''])[0]);
  }
  ck('详情显示作者', !LIB.author || dt.includes(LIB.author), '作者=' + LIB.author);
  ck('详情显示归类', /归类：/.test(dt));
  ck('详情显示章节总数', dt.includes(String(LIB.total_chapters) + ' 章'), String(LIB.total_chapters));
  const chapCount = await page.$$eval('.ad-chap', els => els.length);
  ck('章节列表逐条列出', chapCount === LIB.total_chapters, `${chapCount} / ${LIB.total_chapters}`);
  const firstChap = await page.textContent('.ad-chap');
  ck('每章带时长', /\d+:\d\d/.test(firstChap), firstChap.replace(/\s+/g, ' ').slice(0, 60));
  // 主按钮文案：无进度是「▶ 有声听书」，有进度是「▶ 继续听读（第 N 章）」。
  // 两种都对 —— 这里守的是**旧文案「开始听读」已经被改掉**，以及按钮始终是这两个之一。
  const mainBtn = (dt.match(/▶[^<]{0,16}/) || [''])[0];
  ck('详情主按钮是「▶ 有声听书 / ▶ 继续听读」（已无旧文案「开始听读」）',
     /有声听书|继续听读/.test(mainBtn) && !/开始听读/.test(dt), mainBtn);
  ck('详情有「继续听读/开始听读」按钮', /继续听读|有声听书/.test(dt));
  ck('播放页此时未打开', await page.$eval('#view-audioplay', e => e.classList.contains('hidden')));

  // ---------- 4. 播放与文字同步 ----------
  await page.click('.ad-chap');            // 点第一章
  await page.waitForTimeout(3500);
  ck('进入播放页', await page.$eval('#view-audioplay', e => !e.classList.contains('hidden')));
  ck('播放页有无障碍隐藏导航（避免误触）', await page.$eval('#tabbar', e => getComputedStyle(e).display === 'none'));
  const src = await page.$eval('#aup-audio', e => e.getAttribute('src')).catch(() => '');
  ck('音频走服务端代理（支持 Range）', src.includes('/api/audiobooks/' + LIB.id + '/file/'), src);
  ck('播放地址带签名票据（防盗链）', /sig=[0-9a-f]{24}/.test(src), src.slice(0, 110));
  ck('不使用原生控件（没有「…/下载/播放速度」）',
     await page.$eval('#aup-audio', e => e.controls === false));
  ck('自绘进度条与时间显示在',
     await page.$$eval('#ap-seek, #ap-cur, #ap-total', els => els.length >= 3));
  const total = await page.textContent('#ap-total');
  ck('总时长显示为本章时长', /\d+:\d\d/.test(total), total);
  const playBtn = await page.textContent('#ap-play');
  ck('自绘播放/暂停键在', (playBtn === '▶' || playBtn === '⏸'), playBtn);
  const lines = await page.$$eval('.ap-line', els => els.length);
  ck('显示逐句文字（歌词）', lines > 5, String(lines));
  const meta = await page.evaluate(() => {
    const m = navigator.mediaSession && navigator.mediaSession.metadata;
    return m ? { title: m.title, artist: m.artist, album: m.album } : null;
  });
  ck('注册了系统媒体会话（蓝牙/车机可控制）', !!meta && (meta.title || '').length > 0, JSON.stringify(meta));
  const handlers = await page.evaluate(() => {
    try { navigator.mediaSession.setActionHandler('nexttrack', () => {}); return true; }
    catch (e) { return false; }
  });
  ck('媒体会话支持切章等动作', handlers);

  // 等播放真的推进，并确认高亮句会往前移
  let t0 = 0, moved = false, hl = -1;
  for (let i = 0; i < 20; i++) {
    const st = await page.evaluate(() => {
      const a = document.getElementById('aup-audio');
      const on = document.querySelector('.ap-line.on');
      const idx = on ? Array.from(document.querySelectorAll('.ap-line')).indexOf(on) : -1;
      return { t: a ? a.currentTime : 0, idx: idx, paused: a ? a.paused : true };
    });
    if (i === 0) { t0 = st.t; hl = st.idx; }
    if (st.t > t0 + 1.5 && st.idx > hl) { moved = true; break; }
    await page.waitForTimeout(700);
  }
  ck('音频真的在播放（进度推进）', t0 > 0, 't0=' + t0.toFixed(2));
  ck('文字高亮随播放前进（歌词同步）', moved);

  // ---------- 5. 进度记录 ----------
  const prog = JSON.parse(py(`
import sys, json
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
import db
r = db.q("SELECT chap_seq, offset, percent, updated_at FROM ab_lib_prog WHERE lib_id=?", (${LIB.id},), one=True)
print(json.dumps(dict(r) if r else {}))
`));
  ck('听读进度已落库（自动记录）', !!prog.chap_seq,
     `第 ${prog.chap_seq} 章 偏移 ${prog.offset} 百分比 ${prog.percent}`);

  // ---------- 5b. 「继续听读」闭环 ----------
  // 播放页 → 详情页（这一步本身也验证了「返回详情」），此时才会出现「继续听读」；
  // 详情页再返回才是列表（列表在 view-main 里，隐藏状态下点不到卡片）
  await page.click('#view-audioplay .back');
  await page.waitForTimeout(1600);
  await page.click('#view-audio .back');
  await page.waitForTimeout(1400);
  // ★ 这里必须点**同一本**（测试选中的那张卡），不能点 .au-card 第一张：
  //   列表按「最新」排，第一张可能是别的书。点错了会切到另一本的详情、
  //   也就看不到本轮的「继续听读」，而且播放源被换掉，后面悬浮条/高亮几条会连环挂。
  await page.click(card);
  await page.waitForTimeout(1800);
  const dt2 = await page.textContent('#au-detail-body');
  ck('再次进入详情显示「继续听读」', /继续听读/.test(dt2), (dt2.match(/继续听读[^<]{0,14}/) || [''])[0]);
  await page.click('.ad-acts .btn');
  await page.waitForTimeout(4000);
  const resumed = await page.evaluate(() => {
    const a = document.getElementById('aup-audio');
    return a ? +a.currentTime.toFixed(1) : -1;
  });
  ck('继续听读从上次位置续播（不是从 0 开始）', resumed > 1.0, 'currentTime=' + resumed);

  // ---------- 6. 返回详情 ----------
  await page.click('#view-audioplay .back');
  await page.waitForTimeout(1500);
  ck('返回后回到详情页', await page.$eval('#view-audio', e => !e.classList.contains('hidden')));

  // ---------- 7. 后台播放 + 悬浮条 ----------
  // 此时停在详情页、音频仍在播（返回播放页=后台播放，不再暂停）
  const f1 = await page.evaluate(() => {
    const el = document.getElementById('au-float');
    const a = document.getElementById('aup-audio');
    return { vis: el && !el.classList.contains('hidden'),
             txt: el ? el.textContent.replace(/\s+/g, ' ').trim().slice(0, 40) : '',
             paused: a ? a.paused : null, t: a ? a.currentTime : -1 };
  });
  ck('离开播放页后出现悬浮播放条', f1.vis, JSON.stringify(f1));
  ck('悬浮条显示章节与进度', /第\s*\d+\/\d+\s*章/.test(f1.txt), f1.txt);
  ck('离开播放页后音频继续播（后台播放）', f1.paused === false, 'paused=' + f1.paused);
  await page.waitForTimeout(2500);
  const f2 = await page.evaluate(() => {
    const a = document.getElementById('aup-audio');
    return { t: a ? a.currentTime : -1, paused: a ? a.paused : null };
  });
  ck('后台播放确实在推进', f2.t > f1.t + 1, `${f1.t.toFixed(1)} → ${f2.t.toFixed(1)}`);

  // 悬浮条上的暂停/继续
  await page.click('#au-float-play');
  await page.waitForTimeout(900);
  const f3 = await page.evaluate(() => document.getElementById('aup-audio').paused);
  ck('悬浮条可以暂停', f3 === true);
  await page.click('#au-float-play');
  await page.waitForTimeout(900);
  const f4 = await page.evaluate(() => document.getElementById('aup-audio').paused);
  ck('悬浮条可以继续（恢复播放）', f4 === false);

  // 切到别的页面（首页）也还在：这才是「后台播放」
  await page.click('#tabbar .tab[data-page="library"]');
  await page.waitForTimeout(1600);
  const f5 = await page.evaluate(() => {
    const el = document.getElementById('au-float');
    const a = document.getElementById('aup-audio');
    return { vis: el && !el.classList.contains('hidden'), paused: a ? a.paused : null };
  });
  ck('切到首页后悬浮条还在且继续播', f5.vis && f5.paused === false, JSON.stringify(f5));

  // 点悬浮条 → 回到播放页，且从原位置继续（不从头开始）
  const before = await page.evaluate(() => document.getElementById('aup-audio').currentTime);
  await page.click('#au-float');
  await page.waitForTimeout(2500);
  const f6 = await page.evaluate(() => {
    const a = document.getElementById('aup-audio');
    const v = document.getElementById('view-audioplay');
    return { t: a ? a.currentTime : -1, inView: v && !v.classList.contains('hidden'),
             paused: a ? a.paused : null };
  });
  ck('点悬浮条回到播放页', f6.inView);
  ck('回到播放页后从原位置继续（未重新开始）', f6.t >= before - 0.5, `${before.toFixed(1)} → ${f6.t.toFixed(1)}`);

  // ---------- 8. 文字实时跟进 + 已读/当前句高亮 ----------
  await page.waitForTimeout(3000);
  const hlNow = await page.evaluate(() => {
    const on = document.querySelectorAll('.ap-line.on').length;
    const done = document.querySelectorAll('.ap-line.done').length;
    const cur = document.querySelector('.ap-line.on');
    const wrap = document.getElementById('aup-texts');
    return { on: on, done: done, curText: cur ? cur.textContent.slice(0, 20) : '',
             scrolled: wrap ? wrap.scrollTop : -1,
             // 诊断用：滚动是否该发生，取决于当前句有没有越过半屏
             t: (AUP && AUP.audio) ? AUP.audio.currentTime : -1,
             idx: AUP ? AUP.idx : -1, offsetTop: cur ? cur.offsetTop : -1,
             clientH: wrap ? wrap.clientHeight : -1, scrollH: wrap ? wrap.scrollHeight : -1 };
  });
  ck('当前朗读句被高亮（唯一）', hlNow.on === 1, JSON.stringify(hlNow));
  ck('已读句子被标记', hlNow.done >= 1, 'done=' + hlNow.done);
  // ★ 这条原来写成「等 3 秒后 scrollTop 必须 > 0」——依赖「当前句已经越过半屏」，
  //   而文本区高度在 §14.88 从 40vh 抬到约 62vh 后，半屏线也往下移了，
  //   26 秒时当前句只到第 5 行（offsetTop 230 < 半屏 268），本来就不该滚动 →
  //   于是变成一条随时会红的假红。改成**确定性**验证：
  //   主动跳到本章中后段的一句（auSeekTo 就是用户点文字走的那条路），
  //   再断言「滚下去了」且「当前句完整可见」。
  const follow = await page.evaluate(() => {
    const n = (AUP.segs || []).length;
    const i = Math.max(3, Math.min(n - 2, Math.floor(n * 0.7)));
    auSeekTo(AUP.segs[i].start_sec, i);
    return { i: i, text: AUP.segs[i].text.slice(0, 16) };
  });
  await page.waitForTimeout(1500);
  const followRes = await page.evaluate((i) => {
    const wrap = document.getElementById('aup-texts');
    const cur = document.querySelector('.ap-line.on');
    const top = cur ? cur.offsetTop - wrap.scrollTop : -1;
    return { id: cur ? cur.id : '', txt: cur ? cur.textContent.slice(0, 16) : '',
             scrollTop: wrap.scrollTop, clientH: wrap.clientHeight,
             visible: !!cur && top >= -4 && (top + cur.clientHeight) <= wrap.clientHeight + 4 };
  }, follow.i);
  ck('★ 跳到中后段某句后，文字区自动跟随滚动',
     followRes.id === 'aup-l' + follow.i && followRes.scrollTop > 0, JSON.stringify(followRes));
  ck('★ 跟随滚动后当前句完整可见（没被滚出视野）', followRes.visible === true, JSON.stringify(followRes));

  // 换章后高亮从新章第一句重新开始
  await page.click('#ap-next');   // 下一章
  await page.waitForTimeout(3500);
  const hl2 = await page.evaluate(() => {
    const on = document.querySelectorAll('.ap-line.on').length;
    const idx = Array.from(document.querySelectorAll('.ap-line')).indexOf(document.querySelector('.ap-line.on'));
    const a = document.getElementById('aup-audio');
    return { on: on, idx: idx, chap: AUP ? AUP.chap : -1, t: a ? a.currentTime : -1 };
  });
  ck('下一章后仍在高亮（切章不失效）', hl2.on === 1, JSON.stringify(hl2));
  ck('切到第 2 章后从头开始', hl2.chap === 2 && hl2.idx >= 0 && hl2.idx <= 3, JSON.stringify(hl2));

  // ---------- 8b. 自绘进度条拖动 ----------
  // ★ AUP 是页面里的全局变量，只能在 evaluate 里读，Node 侧引用会 ReferenceError
  const seekInfo = await page.evaluate(() => {
    const a = document.getElementById('aup-audio');
    return { cur0: a ? a.currentTime : -1, start: AUP.chapStart, dur: AUP.chapEnd - AUP.chapStart };
  });
  await page.evaluate(() => {
    const bar = document.getElementById('ap-seek');
    bar.value = '500';
    bar.dispatchEvent(new Event('input', { bubbles: true }));
    bar.dispatchEvent(new Event('change', { bubbles: true }));
  });
  await page.waitForTimeout(1200);
  const cur1 = await page.evaluate(() => document.getElementById('aup-audio').currentTime);
  ck('拖动进度条能跳转（约一半处）',
     Math.abs(cur1 - (seekInfo.start + seekInfo.dur * 0.5)) < 3,
     `${seekInfo.cur0.toFixed(1)} → ${cur1.toFixed(1)}`);

  // ---------- 9. ✕ 结束收听 ----------
  await page.click('#view-audioplay .back');
  await page.waitForTimeout(1500);
  await page.click('#au-float .au-float-btn:nth-of-type(2)');
  await page.waitForTimeout(900);
  const f7 = await page.evaluate(() => {
    const el = document.getElementById('au-float');
    const a = document.getElementById('aup-audio');
    return { vis: el && !el.classList.contains('hidden'), paused: a ? a.paused : null };
  });
  ck('点 ✕ 后悬浮条消失且停止播放', !f7.vis && f7.paused === true, JSON.stringify(f7));

  // ---------- 10. 首页：最近阅读里有声带耳机标识；书架收藏最多 6 本 ----------
  await page.click('#tabbar .tab[data-page="library"]');
  await page.waitForTimeout(2500);
  const home = await page.evaluate(() => {
    const au = document.querySelectorAll('#recent-list .book-card.au-recent');
    const badge = document.querySelectorAll('#recent-list .au-recent .au-badge').length;
    const shelf = document.querySelectorAll('#home-shelf-list .book-card').length;
    const first = au.length ? au[0].textContent.replace(/\s+/g, ' ').slice(0, 30) : '';
    return { au: au.length, badge: badge, shelf: shelf, first: first };
  });
  ck('首页「最近阅读」列出最近收听的有声电子书', home.au >= 1, home.first);
  ck('有声条目右上角有耳机标识', home.badge >= 1 && home.badge === home.au,
     `有声=${home.au} 标识=${home.badge}`);
  ck('首页「书架收藏」最多 6 本', home.shelf <= 6, '收藏=' + home.shelf);

  // ------------------------------------------------ 文字高亮必须跟着进度走（含第 2 章）
  // ★ 这一条是真实缺陷的回归：ab_lib_seg.start_sec 是**文件内绝对时间**，
  //   一个 mp3 装两章时第 2 章的句子从 167.65 起。播放器以前拿它当章内相对时间用，
  //   结果只有第 1 章（起点 0）是对的，**第 2 章起整章都停在第 1 句**。
  //   必须实测「章首」和「第 2 章」，只测第 1 章是测不出来的。
  for (const chap of [1, 2]) {
    await page.evaluate(c => {
      location.hash = '#/audio/1';
      setTimeout(() => audioPlay(1, c, false), 250);
    }, chap);
    await page.waitForTimeout(1200);

    // 进章后立刻就该有高亮（不用等音频走起来）
    const atStart = await page.evaluate(() => !!(document.querySelector('.ap-line.on')));
    ck(`第 ${chap} 章：刚进章就高亮第 1 句`, atStart);

    const seen = [];
    for (let i = 0; i < 5; i++) {
      await page.waitForTimeout(2400);
      seen.push(await page.evaluate(() => {
        const on = document.querySelector('.ap-line.on');
        return Array.from(document.querySelectorAll('.ap-line')).indexOf(on);
      }));
    }
    const uniq = new Set(seen).size;
    ck(`第 ${chap} 章：高亮随播放前进（不是卡在第 1 句）`, uniq > 1,
       '高亮句序号=' + JSON.stringify(seen));

    // 高亮句必须与当前播放时间对得上（允许一句的误差）
    // AUP 是 audio.js 里的模块级变量，page.evaluate 里访问不到；
    // 每句的起点已经写在 DOM 的 data-t 上，直接读它即可。
    const match = await page.evaluate(() => {
      const el = document.getElementById('aup-audio');
      const on = document.querySelector('.ap-line.on');
      if (!el || !on) return null;
      const lines = Array.from(document.querySelectorAll('.ap-line'));
      const i = lines.indexOf(on);
      if (i < 0) return null;
      // data-t 是**章内相对**时间；currentTime 是**文件内绝对**时间。
      // 本章起点写在 src 的媒体片段里（...#t=167.65,227.54），从那儿取。
      const m = /#t=([\d.]+)/.exec(el.getAttribute('src') || '');
      if (!m) return null;
      const chapStart = Number(m[1]);
      return { t: +(el.currentTime - chapStart).toFixed(1), want: Number(on.dataset.t) };
    });
    ck(`第 ${chap} 章：高亮句与播放时间对得上`, !!match && Math.abs(match.t - match.want) < 12,
       match ? `t=${match.t} 该句起点=${match.want}` : '取不到状态');
  }

  // ------------------------------------------------ 树叶图标文案
  const buyTxt = await page.evaluate(() => {
    const d = document.querySelector('.ad-acts, .ad-chaps');
    return d ? d.innerHTML : '';
  });
  ck('兑换按钮用 🌿（整本兑换（N 🌿））', !/兑换（\d+\s*片/.test(buyTxt),
     (buyTxt.match(/整本兑换（[^）]*）/) || ['(免费，无兑换按钮)'])[0]);
  ck('需兑换的章用 N🌿 而不是「需 N 片」', !/需\s*\d+\s*片/.test(buyTxt),
     (buyTxt.match(/需\s*\d+\s*片/) || ['(没有锁定章)'])[0]);

  ck('页面无 JS 报错', errors.length === 0, errors.slice(0, 2).join(' | '));

  // ★ 上面播放过第 1、2 章，会在 ab_lib_prog 里留下真实的收听进度。
  //   测试不能污染真实账号：把本次造出来的进度记下来，收尾时删掉。
  const dirt = JSON.parse(py(`
import sys, json
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
import db
u = db.q("SELECT id FROM users WHERE role='admin' AND enabled=1 ORDER BY id LIMIT 1", one=True)
rows = db.q("SELECT lib_id, chap_seq FROM ab_lib_prog WHERE user_id=?", (u['id'],))
print(json.dumps([dict(r) for r in rows]))
`));
  for (const r of dirt) {
    py(`
import sys
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
import db
u = db.q("SELECT id FROM users WHERE role='admin' AND enabled=1 ORDER BY id LIMIT 1", one=True)
db.ex("DELETE FROM ab_lib_prog WHERE user_id=? AND lib_id=? AND chap_seq=?", (u['id'], ${r.lib_id}, ${r.chap_seq}))
`);
  }
  const left = JSON.parse(py(`
import sys, json
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
import db
u = db.q("SELECT id FROM users WHERE role='admin' AND enabled=1 ORDER BY id LIMIT 1", one=True)
print(json.dumps(db.q("SELECT COUNT(*) c FROM ab_lib_prog WHERE user_id=?", (u['id'],), one=True)['c']))
`));
  ck('测试未在真实账号留下收听进度', left === 0, '剩余=' + left);
  // ★ 收尾：把自己留下的有声单端锁清掉。
  //   不清的话它会活 40 秒租约，紧接着打开 APP 会误报「正在另一台设备上收听」。
  try {
    py(`import sys; sys.path.insert(0, '${ROOT}')
import db
db.ex("DELETE FROM ab_session WHERE user_id=?", (1,))`);
  } catch (e) {}


  await browser.close();
  console.log(`\n有声界面：${pass} 通过 / ${fail} 失败`);
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error('测试异常：', e); process.exit(2); });
