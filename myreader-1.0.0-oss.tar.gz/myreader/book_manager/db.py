# -*- coding: utf-8 -*-
"""SQLite 数据访问层"""
import sqlite3, os, json, time, threading
from datetime import datetime, timedelta, timezone
from uuid import uuid4
import config

_conn = threading.local()

# 进程内写锁：SQLite 在任何时刻只允许一个写事务。本项目是多线程并发写，
# 抢不到锁的一方只能走 SQLite 的 busy handler（nanosleep 退避），最坏要等满
# busy_timeout —— 而 async 路由若在事件循环线程上撞上这个等待，整个服务
# （含静态文件）都会失去响应。与其让内核层去退避，不如在进程内先排好队：
# 单条写入本身是微秒级，串行化的代价极小，却彻底消除了 SQLITE_BUSY 与长阻塞。
# 用 RLock 以便 init_db 这类内部还会再调用 ex() 的场景可以重入。
_write_lock = threading.RLock()

SCHEMA = """
-- 注意 users 上这组 can_*（can_share..can_publish_booklist，共 8 列）是【历史遗留】：
-- 早期权限直接挂在用户行上，后来改成了「权限挂在 user_groups 上、用户只引用
-- group_id」。现在全项目没有任何一处读取 users.can_*（判权一律走 auth.can() →
-- group_of() → user_groups），只有建表默认值与下面那条 WHERE role='admin' 的
-- 迁移语句还在写它。保留列是为了兼容老库与避免不可逆的 DROP COLUMN，但**不要**
-- 再基于它写任何新逻辑 —— 真正的权限在 user_groups 表。
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user',
  quota INTEGER NOT NULL DEFAULT 100,
  enabled INTEGER NOT NULL DEFAULT 1,
  can_share INTEGER NOT NULL DEFAULT 0,
  can_edit INTEGER NOT NULL DEFAULT 0,
  can_cover INTEGER NOT NULL DEFAULT 0,
  can_download INTEGER NOT NULL DEFAULT 0,
  can_delete INTEGER NOT NULL DEFAULT 0,
  can_private_shelf INTEGER NOT NULL DEFAULT 0,
  can_convert INTEGER NOT NULL DEFAULT 0,
  group_id INTEGER,
  name TEXT,
  email TEXT,
  phone TEXT,
  created_at TEXT
);
CREATE TABLE IF NOT EXISTS user_groups (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  sort_order INTEGER DEFAULT 0,
  can_share INTEGER NOT NULL DEFAULT 0,
  can_edit INTEGER NOT NULL DEFAULT 0,
  can_cover INTEGER NOT NULL DEFAULT 0,
  can_download INTEGER NOT NULL DEFAULT 0,
  can_delete INTEGER NOT NULL DEFAULT 0,
  can_private_shelf INTEGER NOT NULL DEFAULT 0,
  can_convert INTEGER NOT NULL DEFAULT 0,
  can_listen INTEGER NOT NULL DEFAULT 0,          -- 是否可直接听书（不消耗树叶）
  can_public_library INTEGER NOT NULL DEFAULT 1, -- 是否可见公共书库（分类下的书籍）与搜索
  can_promote INTEGER NOT NULL DEFAULT 0,         -- 是否可以「推广」（生成自己的推广链接/推广码）
  can_invite INTEGER NOT NULL DEFAULT 0,          -- 是否可以「邀请」（生成自己的邀请链接/邀请码）
  promote_reward INTEGER NOT NULL DEFAULT 0,      -- 每个「有效注册」给推广人的树叶数（0=不奖励）
  invite_reward INTEGER NOT NULL DEFAULT 0,       -- 每个「有效注册」给邀请人的树叶数（0=不奖励）
  share_max_days INTEGER NOT NULL DEFAULT 0,      -- 单个分享最长天数（0=不限）
  share_max_links INTEGER NOT NULL DEFAULT 0,     -- 最多同时存在的分享链接数（0=不限）
  download_monthly_limit INTEGER NOT NULL DEFAULT 0, -- 每月可下载本数（0=不限）
  listen_monthly_limit INTEGER NOT NULL DEFAULT 0,   -- 每月免费听书本数（0=不限；超出后按原规则扣树叶）
  shelf_limit INTEGER NOT NULL DEFAULT 0,         -- 私人书架最多藏书数（0=不限）
  convert_daily_limit INTEGER NOT NULL DEFAULT 0, -- 每天可转换本数（0=不限）
  upload_max_mb INTEGER NOT NULL DEFAULT 0,       -- 单本上传最大 MB（0=不限）
  is_system INTEGER NOT NULL DEFAULT 0,
  created_at TEXT
);
-- 推广 / 邀请：两条独立渠道，各自一个码（一个用户每渠道一个）。
-- ★ 为什么必须分渠道存码：两条渠道的奖励数不一样，码本身必须能区分出
--   「这次注册该按哪个渠道算钱」，否则事后没法判定发多少。
CREATE TABLE IF NOT EXISTS invite_codes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  uid INTEGER NOT NULL,             -- 归属用户
  kind TEXT NOT NULL,               -- 'promote' 推广 / 'invite' 邀请
  code TEXT NOT NULL UNIQUE,        -- 码本体（注册时填的就是它）
  created_at TEXT,
  disabled INTEGER NOT NULL DEFAULT 0, -- 后台可停用（1=不再可用）
  UNIQUE(uid, kind)                 -- 一人每渠道一码
);
-- 推广邀请：一次注册对应一条记录。valid=0 的仍会留痕（便于查刷），但不发奖励。
CREATE TABLE IF NOT EXISTS invites (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'promote',  -- 走的哪条渠道（决定按哪个奖励字段发）
  inviter_id INTEGER NOT NULL,
  invitee_id INTEGER NOT NULL UNIQUE,   -- 一个被邀请人只可能有一条
  fp TEXT,                              -- 注册时的设备指纹（防刷依据）
  valid INTEGER NOT NULL DEFAULT 0,     -- 是否算「有效注册」
  reason TEXT,                          -- valid=0 的原因
  rewarded INTEGER NOT NULL DEFAULT 0,  -- 是否已给推广人发过奖励
  created_at TEXT,
  rewarded_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_invites_inviter ON invites(inviter_id);
CREATE INDEX IF NOT EXISTS idx_invites_fp ON invites(fp);
CREATE TABLE IF NOT EXISTS download_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  book_id INTEGER NOT NULL,
  created_at TEXT
);
CREATE TABLE IF NOT EXISTS convert_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  book_id INTEGER NOT NULL,
  created_at TEXT
);
CREATE TABLE IF NOT EXISTS listen_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  book_id INTEGER NOT NULL,
  created_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_lst_user ON listen_logs(user_id, created_at);
CREATE INDEX IF NOT EXISTS idx_cvt_user ON convert_logs(user_id, created_at);
CREATE INDEX IF NOT EXISTS idx_dl_user ON download_logs(user_id, created_at);
CREATE TABLE IF NOT EXISTS books (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  path TEXT UNIQUE NOT NULL,          -- 相对 FTP_BASE 的路径（分类目录内）
  title TEXT NOT NULL,
  author TEXT,
  category TEXT,                      -- 如 I_文学
  clc TEXT,                           -- 如 I
  ddc TEXT,
  ext TEXT,                           -- 小写后缀，如 .epub
  size INTEGER DEFAULT 0,
  cover TEXT,                         -- 相对 COVER_DIR 的文件名
  intro TEXT,
  intro_done INTEGER DEFAULT 0,
  rating REAL,                        -- 评分（豆瓣等刮削）
  publisher TEXT,                     -- 出版社
  isbn TEXT,                          -- ISBN
  pages INTEGER DEFAULT 0,            -- 页数
  series TEXT,                        -- 丛书
  hidden INTEGER DEFAULT 0,           -- 1=已下架（侵权投诉等，管理员可见）
  owner_id INTEGER,                   -- NULL=系统书；否则为上传用户
  created_at TEXT,
  updated_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_books_title ON books(title);
CREATE INDEX IF NOT EXISTS idx_books_category ON books(category);
CREATE INDEX IF NOT EXISTS idx_books_author ON books(author);
CREATE TABLE IF NOT EXISTS shelves (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  book_id INTEGER NOT NULL,
  collection_id INTEGER,
  added_at TEXT,
  UNIQUE(user_id, book_id)
);
CREATE TABLE IF NOT EXISTS shelf_collections (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  sort_order INTEGER DEFAULT 0,
  created_at TEXT
);
CREATE TABLE IF NOT EXISTS progress (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  book_id INTEGER NOT NULL,
  position TEXT,                      -- JSON {kind, href, offset, percent, page}
  percent REAL DEFAULT 0,
  updated_at TEXT,
  UNIQUE(user_id, book_id)
);
CREATE TABLE IF NOT EXISTS settings (
  user_id INTEGER PRIMARY KEY,
  theme TEXT DEFAULT 'sepia',
  font_size INTEGER DEFAULT 18,
  font_family TEXT DEFAULT 'serif',
  line_height REAL DEFAULT 1.8,
  page_width TEXT DEFAULT '92%',
  brightness REAL DEFAULT 1.0,
  flip_effect TEXT DEFAULT 'flip',
  flip_speed INTEGER DEFAULT 380,
  home_categories TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS shares (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  book_id INTEGER NOT NULL,
  token TEXT UNIQUE NOT NULL,
  password_hash TEXT,
  expire_at TEXT,
  download_limit INTEGER DEFAULT 0,
  download_count INTEGER DEFAULT 0,
  access_count INTEGER DEFAULT 0,
  online_read INTEGER DEFAULT 0,
  created_at TEXT
);
CREATE TABLE IF NOT EXISTS audit_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  username TEXT,
  action TEXT NOT NULL,
  target_type TEXT,
  target_id INTEGER,
  detail TEXT,
  ip TEXT,
  created_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at);
CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_logs(user_id);
-- 上传下载日志：谁在什么时候上传/下载了什么文件。
-- ★ 单独一张表而不是塞进 audit_logs：审计日志是「敏感操作」流水，
--   这里要按**文件扩展名**统计与筛选（epub / pdf / mobi / mp3…），
--   扩展名必须是独立可索引的列，不能从 detail 那句人话里正则抠。
CREATE TABLE IF NOT EXISTS file_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,                 -- 0 / NULL = 游客或匿名分享
  username TEXT,
  action TEXT NOT NULL,            -- upload / download
  filename TEXT,                   -- 原始文件名（含扩展名）
  ext TEXT,                        -- 小写扩展名，如 epub、pdf（不带点）
  bytes INTEGER,                   -- 文件大小
  source TEXT,                     -- 入口：web / ftp / cover / convert / share ...
  book_id INTEGER,
  book_title TEXT,
  ip TEXT,
  created_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_filelog_created ON file_logs(created_at);
CREATE INDEX IF NOT EXISTS idx_filelog_ext ON file_logs(ext);
CREATE INDEX IF NOT EXISTS idx_filelog_action ON file_logs(action);
CREATE TABLE IF NOT EXISTS book_reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  book_id INTEGER NOT NULL,
  user_id INTEGER,
  reason TEXT,
  detail TEXT,
  status TEXT DEFAULT 'pending',      -- pending / handled
  created_at TEXT,
  handled_at TEXT,
  handled_by INTEGER
);
CREATE INDEX IF NOT EXISTS idx_reports_status ON book_reports(status);
CREATE TABLE IF NOT EXISTS share_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  book_id INTEGER NOT NULL,
  requester_id INTEGER NOT NULL,
  status TEXT DEFAULT 'pending',      -- pending / approved / rejected
  created_at TEXT,
  reviewed_at TEXT,
  reviewed_by INTEGER
);
CREATE INDEX IF NOT EXISTS idx_share_req_status ON share_requests(status);
CREATE TABLE IF NOT EXISTS book_grants (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  book_id INTEGER NOT NULL,
  from_user_id INTEGER NOT NULL,
  to_user_id INTEGER NOT NULL,
  created_at TEXT,
  UNIQUE(book_id, to_user_id)
);
CREATE INDEX IF NOT EXISTS idx_book_grants_to ON book_grants(to_user_id);
CREATE TABLE IF NOT EXISTS notes (
  user_id INTEGER NOT NULL,
  book_id INTEGER NOT NULL,
  updated_at TEXT,
  PRIMARY KEY (user_id, book_id)
);
CREATE TABLE IF NOT EXISTS system_config (
  key TEXT PRIMARY KEY,
  value TEXT
);
CREATE TABLE IF NOT EXISTS reading_time (
  user_id INTEGER PRIMARY KEY,
  total_seconds INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT
);
CREATE TABLE IF NOT EXISTS user_leaves (
  user_id INTEGER PRIMARY KEY,
  balance INTEGER NOT NULL DEFAULT 0,     -- 当前树叶余额
  updated_at TEXT
);
CREATE TABLE IF NOT EXISTS signin_log (
  user_id INTEGER NOT NULL,
  signin_date TEXT NOT NULL,              -- 签到日期 YYYY-MM-DD（北京时间）
  leaves INTEGER NOT NULL DEFAULT 0,      -- 当日获得（含奖励）
  bonus INTEGER NOT NULL DEFAULT 0,       -- 其中连续签到奖励
  streak INTEGER NOT NULL DEFAULT 1,      -- 截至当日的连续天数
  created_at TEXT,
  PRIMARY KEY (user_id, signin_date)
);
CREATE INDEX IF NOT EXISTS idx_signin_user ON signin_log(user_id, signin_date DESC);
CREATE TABLE IF NOT EXISTS leaf_spend (
  user_id INTEGER NOT NULL,
  book_id INTEGER NOT NULL,
  kind TEXT NOT NULL,                     -- convert=格式转换 / download=下载原文件
  leaves INTEGER NOT NULL DEFAULT 0,      -- 本次消耗的树叶数
  created_at TEXT,
  PRIMARY KEY (user_id, book_id, kind)    -- 同一用户同一本书同一类型只扣一次
);
CREATE TABLE IF NOT EXISTS leaf_gain (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  kind TEXT NOT NULL,                     -- booklist=书单文章通过 / share_request=电子书共享通过
  ref_type TEXT,                          -- booklist / book / share_request
  ref_id INTEGER,
  leaves INTEGER NOT NULL DEFAULT 0,      -- 本次发放的树叶数
  note TEXT,
  created_at TEXT,
  UNIQUE (kind, ref_type, ref_id)         -- 同一来源只发一次，天然防止重复发放
);
CREATE INDEX IF NOT EXISTS idx_leaf_gain_user ON leaf_gain(user_id, id DESC);
-- 听书进度：独立于 progress 表，否则 PUT 整条覆盖会冲掉阅读进度。
-- 注意：听书音频不做持久化存储（内存 LRU，播完即淘汰），所以这里只存进度，不存音频索引
CREATE TABLE IF NOT EXISTS listen_progress (
  user_id INTEGER NOT NULL,
  book_id INTEGER NOT NULL,
  seg_idx INTEGER DEFAULT 0,             -- 听到第几句
  offset REAL DEFAULT 0,                 -- 句内秒数
  voice TEXT DEFAULT '',                 -- 上次用的音色
  line  TEXT DEFAULT '',                 -- 上次选的线路（TTS 服务器 url，空=自动）
  percent REAL DEFAULT 0,
  updated_at TEXT,
  PRIMARY KEY (user_id, book_id)
);
CREATE TABLE IF NOT EXISTS listen_session (
  user_id INTEGER PRIMARY KEY,           -- 一个账号同一时间只允许一个终端听书
  book_id INTEGER,
  sid TEXT DEFAULT '',                   -- 终端/标签页标识
  ua TEXT DEFAULT '',
  ip TEXT DEFAULT '',
  started_at TEXT,
  ts REAL DEFAULT 0                      -- 最近心跳（epoch 秒），超时即视为已停止
);
-- 有声阅读的单端互斥：一个账号同一时间只允许**一个终端**放有声书。
-- 与听书（listen_session）是**两把独立的锁**，互不干扰：
--   听书贵在服务端逐句合成，有声书只是取现成文件，两件事没必要互相锁。
-- 租约式：ablib_api 每次取票/心跳刷新 ts，超过 ablock.LEASE 秒没动静即视为已停止，
-- 这样关页面或断网不会把账号永久锁死。
CREATE TABLE IF NOT EXISTS ab_session (
  user_id INTEGER PRIMARY KEY,           -- 一个账号同一时间只允许一个终端放有声书
  lib_id INTEGER,
  sid TEXT DEFAULT '',                   -- 终端/标签页标识
  ua TEXT DEFAULT '',
  ip TEXT DEFAULT '',
  started_at TEXT,
  ts REAL DEFAULT 0                      -- 最近心跳（epoch 秒），超时即视为已停止
);
CREATE TABLE IF NOT EXISTS cover_sources (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  enabled INTEGER NOT NULL DEFAULT 1,
  sort_order INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS booklists (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  content TEXT NOT NULL DEFAULT '',
  author_id INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',   -- pending / approved / rejected
  tag TEXT NOT NULL DEFAULT '',             -- 标签：share 分享 / discuss 讨论 / find 找书，空=无
  pinned INTEGER NOT NULL DEFAULT 0,        -- 管理员置顶
  view_count INTEGER NOT NULL DEFAULT 0,
  created_at TEXT,
  updated_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_bl_status ON booklists(status, created_at);
CREATE TABLE IF NOT EXISTS booklist_comments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  booklist_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  content TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',   -- pending / approved / rejected
  created_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_blc_list ON booklist_comments(booklist_id, status);
CREATE TABLE IF NOT EXISTS booklist_views (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  booklist_id INTEGER NOT NULL,
  visitor TEXT NOT NULL,                    -- 登录用户 "u{id}"，游客 "ip{ip}"
  day TEXT NOT NULL,                        -- 浏览日期 YYYY-MM-DD
  created_at TEXT
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_bl_views ON booklist_views(booklist_id, visitor, day);

CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  from_id INTEGER,                          -- 发送者用户ID；NULL = 系统消息
  to_id INTEGER NOT NULL,                   -- 接收者用户ID
  kind TEXT NOT NULL DEFAULT 'system',      -- pm 私信 / share 站内分享 / booklist 书单 / review 审核结果 / report 举报处理 / system 系统
  title TEXT,
  body TEXT,
  link TEXT,                                -- 可选跳转地址
  ref_type TEXT, ref_id INTEGER,            -- 关联对象（book / booklist / report ...）
  is_read INTEGER NOT NULL DEFAULT 0,
  created_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_messages_to ON messages(to_id, id DESC);
CREATE INDEX IF NOT EXISTS idx_messages_unread ON messages(to_id, is_read);

-- 分组兑换（用树叶按月兑换更高权限分组，到期自动回退）
CREATE TABLE IF NOT EXISTS group_upgrades (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  from_group_id INTEGER,                    -- 升级前的分组（到期回退目标）
  to_group_id INTEGER NOT NULL,             -- 兑换得到的分组
  cost INTEGER NOT NULL DEFAULT 0,          -- 本次消耗的树叶数
  months INTEGER NOT NULL DEFAULT 1,        -- 购买月数
  started_at TEXT,
  expires_at TEXT,
  status TEXT NOT NULL DEFAULT 'active',    -- active 生效中 / expired 已到期
  created_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_group_upgrades_user ON group_upgrades(user_id, status);
CREATE INDEX IF NOT EXISTS idx_group_upgrades_due ON group_upgrades(status, expires_at);
"""

def get_conn():
    c = getattr(_conn, "c", None)
    if c is None:
        c = sqlite3.connect(config.DB_PATH, check_same_thread=False, timeout=8)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA journal_mode=WAL")
        # 抢不到锁时的等待上限。原来 60 秒太致命：本项目的 async 路由
        # （reading_heartbeat / save_progress 等）是在事件循环线程上做同步写，
        # 一旦撞锁，SQLite 的 busy handler 会用 nanosleep 退避等待，期间整个服务
        # （含静态文件）全部无响应，表现就是「网站打不开」。
        # 压到 8 秒：宁可让这一个请求失败，也不让全站跟着冻住。
        c.execute("PRAGMA busy_timeout=8000")
        # WAL 模式下 NORMAL 是 SQLite 官方推荐值：应用崩溃不丢数据，只有断电
        # 才可能回滚最后几个事务（不会损坏库）。省掉每次 commit 的 fsync，
        # 写锁持有时间大幅缩短，直接缓解锁竞争。
        c.execute("PRAGMA synchronous=NORMAL")
        c.execute("PRAGMA foreign_keys=ON")
        _conn.c = c
    return c

def init_db():
    with _write_lock:          # 建表/迁移期间的写也要排队（RLock，可重入）
        c = get_conn()
        c.executescript(SCHEMA)
        _migrate(c)
        c.commit()
    clean_audit()   # 启动时清理 30 天前的审计日志


def _migrate(c):
    """给旧库补齐新增列（权限位等）"""
    cols = {r[1] for r in c.execute("PRAGMA table_info(users)")}
    adds = {
        "can_share": "INTEGER NOT NULL DEFAULT 0",
        "can_edit": "INTEGER NOT NULL DEFAULT 0",
        "can_cover": "INTEGER NOT NULL DEFAULT 0",
        "can_download": "INTEGER NOT NULL DEFAULT 0",
        "can_delete": "INTEGER NOT NULL DEFAULT 0",
        "can_private_shelf": "INTEGER NOT NULL DEFAULT 0",
        "can_convert": "INTEGER NOT NULL DEFAULT 0",
        "can_publish_booklist": "INTEGER NOT NULL DEFAULT 0",
    }
    for name, ddl in adds.items():
        if name not in cols:
            c.execute(f"ALTER TABLE users ADD COLUMN {name} {ddl}")
    # 管理员默认拥有全部权限
    c.execute("UPDATE users SET can_share=1, can_edit=1, can_cover=1, can_download=1, can_delete=1, can_private_shelf=1, can_convert=1, can_publish_booklist=1 WHERE role='admin'")
    # 分组新增：推广 / 邀请 两套权限位与奖励树叶数
    gcols = {r[1] for r in c.execute("PRAGMA table_info(user_groups)")}
    for name, ddl in (("can_promote", "INTEGER NOT NULL DEFAULT 0"),
                      ("can_invite", "INTEGER NOT NULL DEFAULT 0"),
                      ("promote_reward", "INTEGER NOT NULL DEFAULT 0"),
                      ("invite_reward", "INTEGER NOT NULL DEFAULT 0")):
        if name not in gcols:
            c.execute(f"ALTER TABLE user_groups ADD COLUMN {name} {ddl}")
    # 邀请码表升级成「一人每渠道一码」：原来的 UNIQUE(uid) 在 SQLite 里改不掉，
    # 只能重建表把数据搬过去。老库里的码一律归到「推广」渠道（当时只有这一条）。
    ccols = {r[1] for r in c.execute("PRAGMA table_info(invite_codes)")}
    if ccols and "kind" not in ccols:
        c.execute("ALTER TABLE invite_codes RENAME TO invite_codes_old")
        c.execute("""CREATE TABLE invite_codes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  uid INTEGER NOT NULL,
  kind TEXT NOT NULL,
  code TEXT NOT NULL UNIQUE,
  created_at TEXT,
  disabled INTEGER NOT NULL DEFAULT 0,
  UNIQUE(uid, kind)
)""")
        c.execute("INSERT INTO invite_codes (id,uid,kind,code,created_at,disabled) "
                  "SELECT id,uid,'promote',code,created_at,disabled FROM invite_codes_old")
        c.execute("DROP TABLE invite_codes_old")
    icols = {r[1] for r in c.execute("PRAGMA table_info(invites)")}
    if icols and "kind" not in icols:
        c.execute("ALTER TABLE invites ADD COLUMN kind TEXT NOT NULL DEFAULT 'promote'")
    # 注册时的设备指纹（防刷：同一台机器只算一个有效注册）
    if "signup_fp" not in cols:
        c.execute("ALTER TABLE users ADD COLUMN signup_fp TEXT")
    # 书架自定义分类列
    scols = {r[1] for r in c.execute("PRAGMA table_info(shelves)")}
    if "collection_id" not in scols:
        c.execute("ALTER TABLE shelves ADD COLUMN collection_id INTEGER")
    ccols = {r[1] for r in c.execute("PRAGMA table_info(shelf_collections)")}
    if "sort_order" not in ccols:
        c.execute("ALTER TABLE shelf_collections ADD COLUMN sort_order INTEGER DEFAULT 0")
    scol2 = {r[1] for r in c.execute("PRAGMA table_info(settings)")}
    if "brightness" not in scol2:
        c.execute("ALTER TABLE settings ADD COLUMN brightness REAL DEFAULT 1.0")
    if "flip_effect" not in scol2:
        c.execute("ALTER TABLE settings ADD COLUMN flip_effect TEXT DEFAULT 'flip'")
    if "flip_speed" not in scol2:
        c.execute("ALTER TABLE settings ADD COLUMN flip_speed INTEGER DEFAULT 380")
    if "home_categories" not in scol2:
        c.execute("ALTER TABLE settings ADD COLUMN home_categories TEXT DEFAULT ''")
    if "lite_fmt" not in scol2:
        # 极简阅读页（/lite，老设备/无 JS）每账号的排版设置，存 JSON {ff,lh,fs}。
        # ★ 刻意**不复用**上面那三个 APP 阅读器字段：在 Kindle 上选楷体/大字号
        #   不应该悄悄改掉手机 APP 里的阅读设置（用户没要求这种联动）。
        #   两边互不干扰：/api/settings 的 SELECT 与 UPDATE 都只点名自己的列。
        c.execute("ALTER TABLE settings ADD COLUMN lite_fmt TEXT DEFAULT ''")
    # 分享：是否允许「在线阅读」（§14.113）。1=允许，0=只给下载。
    # 老分享一律按 0 处理：当时创建时没有这个选项，不该突然多出一个在线阅读入口
    shcols = {r[1] for r in c.execute("PRAGMA table_info(shares)")}
    if shcols and "online_read" not in shcols:
        c.execute("ALTER TABLE shares ADD COLUMN online_read INTEGER DEFAULT 0")
    # 书籍评分
    bcols = {r[1] for r in c.execute("PRAGMA table_info(books)")}
    if "rating" not in bcols:
        c.execute("ALTER TABLE books ADD COLUMN rating REAL")
    # 元数据增强：出版社/ISBN/页数/丛书
    for col, ddl in (("publisher", "TEXT"), ("isbn", "TEXT"), ("pages", "INTEGER DEFAULT 0"), ("series", "TEXT")):
        if col not in bcols:
            c.execute(f"ALTER TABLE books ADD COLUMN {col} {ddl}")
    if "hidden" not in bcols:
        c.execute("ALTER TABLE books ADD COLUMN hidden INTEGER DEFAULT 0")
    if "guest_featured" not in bcols:
        c.execute("ALTER TABLE books ADD COLUMN guest_featured INTEGER DEFAULT 0")
    # 保留原有范例图书（《林徽因全集》）作为初始访客推荐
    c.execute("UPDATE books SET guest_featured=1 WHERE id=? AND COALESCE(guest_featured,0)=0",
              (config.PUBLIC_SAMPLE_BOOK_ID,))
    c.execute("CREATE INDEX IF NOT EXISTS idx_books_isbn ON books(isbn)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_books_publisher ON books(publisher)")
    # 分组新增「听书」权限位
    gcols = {r[1] for r in c.execute("PRAGMA table_info(user_groups)")}
    if "can_listen" not in gcols:
        c.execute("ALTER TABLE user_groups ADD COLUMN can_listen INTEGER NOT NULL DEFAULT 0")
    # 听书进度记录所选线路，原生后台播放不带 line 参数时靠它沿用
    lpcols = {r[1] for r in c.execute("PRAGMA table_info(listen_progress)")}
    if "line" not in lpcols:
        c.execute("ALTER TABLE listen_progress ADD COLUMN line TEXT DEFAULT ''")
    # 分组新增「每月免费听书本数」限额（0=不限，超出后按原规则扣树叶）
    if "listen_monthly_limit" not in gcols:
        c.execute("ALTER TABLE user_groups ADD COLUMN listen_monthly_limit INTEGER NOT NULL DEFAULT 0")
    # 分享下载次数限制
    shcols = {r[1] for r in c.execute("PRAGMA table_info(shares)")}
    if "download_limit" not in shcols:
        c.execute("ALTER TABLE shares ADD COLUMN download_limit INTEGER DEFAULT 0")
    if "download_count" not in shcols:
        c.execute("ALTER TABLE shares ADD COLUMN download_count INTEGER DEFAULT 0")
    if "access_count" not in shcols:
        c.execute("ALTER TABLE shares ADD COLUMN access_count INTEGER DEFAULT 0")
    # 封面刮削接入资源默认值
    if c.execute("SELECT COUNT(*) FROM cover_sources").fetchone()[0] == 0:
        for name, stype, sort in (("豆瓣读书", "douban", 1), ("必应图片", "bing", 2),
                                   ("Google Books", "google", 3), ("Open Library", "openlibrary", 4)):
            c.execute("INSERT INTO cover_sources (name,type,enabled,sort_order) VALUES (?,?,1,?)",
                      (name, stype, sort))
    # ---- 用户分组（会员体系） ----
    ucols = {r[1] for r in c.execute("PRAGMA table_info(users)")}
    if "group_id" not in ucols:
        c.execute("ALTER TABLE users ADD COLUMN group_id INTEGER")
    if "name" not in ucols:
        c.execute("ALTER TABLE users ADD COLUMN name TEXT")
    if "email" not in ucols:
        c.execute("ALTER TABLE users ADD COLUMN email TEXT")
    if "phone" not in ucols:
        c.execute("ALTER TABLE users ADD COLUMN phone TEXT")
    # 「最后登录」（后台用户管理列表用，可点表头排序）
    # 为什么单独存一列而不是每次从 audit_logs 现算：审计日志只保留 30 天
    # （clean_audit），现算会让「一个月没登录」和「从没登录」显示成同一个样子。
    # 首次加列时用审计日志回填一次，此后由登录/注册接口持续写入，不再随时间丢失。
    # 口径含 register：注册接口直接返回 token（注册即登录），所以它也是一次真实登录。
    if "last_login" not in ucols:
        c.execute("ALTER TABLE users ADD COLUMN last_login TEXT")
        c.execute("""UPDATE users SET last_login=(
                       SELECT MAX(a.created_at) FROM audit_logs a
                       WHERE a.user_id=users.id AND a.action IN ('login','register'))""")
    # 昵称（原「姓名」）：站内消息以昵称作为接收标识，历史空昵称回填为用户名，保证可被寻址
    c.execute("UPDATE users SET name=username WHERE name IS NULL OR TRIM(name)=''")
    gcols = {r[1] for r in c.execute("PRAGMA table_info(user_groups)")}
    if "convert_daily_limit" not in gcols:
        c.execute("ALTER TABLE user_groups ADD COLUMN convert_daily_limit INTEGER NOT NULL DEFAULT 0")
    if "can_public_library" not in gcols:
        c.execute("ALTER TABLE user_groups ADD COLUMN can_public_library INTEGER NOT NULL DEFAULT 1")
        # 首次引入「公共书库」可见性权限：会员（guest）组默认关闭
        c.execute("UPDATE user_groups SET can_public_library=0 WHERE code='guest'")
    if "can_publish_booklist" not in gcols:
        c.execute("ALTER TABLE user_groups ADD COLUMN can_publish_booklist INTEGER NOT NULL DEFAULT 0")
        # 书单发表权限：管理员组与作家组默认开通
        c.execute("UPDATE user_groups SET can_publish_booklist=1 WHERE code IN ('admin','writer')")
    if "upload_max_mb" not in gcols:
        # 分组「单本上传最大 MB」：0=不限。老库补 0，行为与改动前完全一致。
        c.execute("ALTER TABLE user_groups ADD COLUMN upload_max_mb INTEGER NOT NULL DEFAULT 0")
    if "exchange_cost" not in gcols:
        # 分组兑换（树叶 → 分组，有效期 1 个月）：0=不可兑换
        c.execute("ALTER TABLE user_groups ADD COLUMN exchange_cost INTEGER NOT NULL DEFAULT 0")
        # 首次引入时按需求示例给出默认价：小编 100 / 主编 200 / 总编 500
        c.execute("UPDATE user_groups SET exchange_cost=100 WHERE code='reader'")
        c.execute("UPDATE user_groups SET exchange_cost=200 WHERE code='member'")
        c.execute("UPDATE user_groups SET exchange_cost=500 WHERE code='writer'")
    if c.execute("SELECT COUNT(*) FROM user_groups").fetchone()[0] == 0:
        # 内置五个分组（code 固定，权限与限额可按规范调整）
        # (code, name, sort, can_share, can_edit, can_cover, can_download, can_delete,
        #  can_private_shelf, can_convert, can_listen, can_public_library, can_publish_booklist,
        #  share_max_days, share_max_links, download_monthly_limit, shelf_limit, convert_daily_limit, is_system)
        default_groups = [
            ("admin", "管理员", 1, 1,1,1,1,1,1,1,1,1,1, 0, 0, 0, 0, 0, 1),     # 完整管理权限，不限
            ("writer", "总编", 2, 1,1,1,1,0,1,0,1,1,1, 30, 100, 200, 500, 0, 1),
            ("member", "主编", 3, 1,0,0,1,0,1,0,1,1,0, 15, 30, 50, 100, 0, 1),
            ("reader", "小编", 4, 1,0,0,0,0,1,0,0,1,0, 7, 10, 0, 50, 0, 1),
            ("guest", "读者", 5, 0,0,0,0,0,0,0,0,0,0, 0, 0, 0, 0, 0, 1),
        ]
        for g in default_groups:
            (code, name, sort, sh, ed, cv, dl, de, ps, cv2, lst, pl, bl, days, links, mdown, shelf, cvt, sysf) = g
            c.execute("INSERT INTO user_groups (code,name,sort_order,can_share,can_edit,can_cover,can_download,can_delete,can_private_shelf,can_convert,can_listen,can_public_library,can_publish_booklist,share_max_days,share_max_links,download_monthly_limit,shelf_limit,convert_daily_limit,is_system,created_at) "
                      "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                      (code, name, sort, sh, ed, cv, dl, de, ps, cv2, lst, pl, bl, days, links, mdown, shelf, cvt, sysf, now()))
    # 分组显示名称更名（历史库兼容）：code 固定，旧名称迁移到新名称
    _group_renames = [
        ("writer", "总编", ("作家",)),
        ("member", "主编", ("贵宾",)),
        ("reader", "小编", ("读者",)),
        ("guest", "读者", ("会员", "访客")),
    ]
    for code, new_name, old_names in _group_renames:
        ph = ",".join("?" for _ in old_names)
        c.execute(f"UPDATE user_groups SET name=? WHERE code=? AND name IN ({ph})",
                  (new_name, code, *old_names))
    # 老用户归组：管理员→管理员组，其余→会员（guest）组
    c.execute("UPDATE users SET group_id=(SELECT id FROM user_groups WHERE code='admin') "
              "WHERE role='admin' AND (group_id IS NULL OR group_id=0)")
    c.execute("UPDATE users SET group_id=(SELECT id FROM user_groups WHERE code='guest') "
              "WHERE group_id IS NULL OR group_id=0")
    # 配额与分组书架上限同步（0=不限 → 999999 哨兵，兼容旧配额判断）
    c.execute("""UPDATE users SET quota = CASE WHEN (SELECT shelf_limit FROM user_groups WHERE id=users.group_id) > 0
                     THEN (SELECT shelf_limit FROM user_groups WHERE id=users.group_id) ELSE 999999 END
                 WHERE group_id IS NOT NULL""")
    # 清理孤儿引用：书籍被直接删除后，残留的书架/进度/分享/笔记/举报/共享申请/站内分享
    for t in ("shelves", "progress", "shares", "notes", "book_reports", "share_requests", "book_grants"):
        c.execute(f"DELETE FROM {t} WHERE book_id NOT IN (SELECT id FROM books)")
    c.execute("DELETE FROM book_grants WHERE to_user_id NOT IN (SELECT id FROM users)")
    # 书单讨论：标签（分享/讨论/找书）+ 管理员置顶
    blcols = {r[1] for r in c.execute("PRAGMA table_info(booklists)")}
    if "tag" not in blcols:
        c.execute("ALTER TABLE booklists ADD COLUMN tag TEXT NOT NULL DEFAULT ''")
    if "pinned" not in blcols:
        c.execute("ALTER TABLE booklists ADD COLUMN pinned INTEGER NOT NULL DEFAULT 0")
    c.execute("CREATE INDEX IF NOT EXISTS idx_bl_pinned ON booklists(pinned, created_at)")

def now():
    # 统一返回北京时间（UTC+8），不依赖服务器系统时区
    return (datetime.now(timezone.utc) + timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")


def today():
    # 北京时间当天日期（YYYY-MM-DD），签到按此判定
    return (datetime.now(timezone.utc) + timedelta(hours=8)).strftime("%Y-%m-%d")


def yesterday():
    return (datetime.now(timezone.utc) + timedelta(hours=8) - timedelta(days=1)).strftime("%Y-%m-%d")

def get_config(key, default=None):
    r = q("SELECT value FROM system_config WHERE key=?", (key,), one=True)
    return r["value"] if r else default

def set_config(key, value):
    ex("INSERT INTO system_config (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
       (key, str(value)))

def q(sql, args=(), one=False):
    c = get_conn()
    cur = c.execute(sql, args)
    try:
        rows = cur.fetchall()
    finally:
        # 必须关掉游标：留着未读完的游标会让这条连接一直占着旧读快照，
        # 既是 database is locked 的常见来源，也会让 WAL 无法回收。
        cur.close()
    return (rows[0] if rows else None) if one else rows

def _guard_full_table_write(sql):
    """拦住「全表 UPDATE / DELETE」—— 没有 WHERE 的写语句几乎一定是漏写了条件。

    ★ 为什么要有这道闸（真实事故，2026-10-08）：
      测试脚本里写了 `UPDATE user_leaves SET balance=100`（漏掉 WHERE user_id=?），
      一句话把**全库 172 个用户**的树叶余额都改成了 100。
      这类语句在 SQL 层面完全合法，跑起来也不报错，只有事后对账才发现，
      所以必须在执行前就拒绝，而不是等出事再回滚。
      确实需要整表更新时（极少），显式传 allow_full=True 表明「我知道我在干什么」。
    """
    if not sql:
        return
    head = sql.lstrip().split(None, 1)
    if len(head) < 2:
        return
    verb = head[0].upper()
    if verb not in ("UPDATE", "DELETE", "INSERT", "REPLACE"):
        return
    body = " ".join(sql.upper().split())
    if verb in ("UPDATE", "DELETE") and " WHERE " not in " " + body + " ":
        raise ValueError(
            "拒绝执行没有 WHERE 的全表 %s：%s" % (verb, sql.strip()[:120]))


def ex(sql, args=(), allow_full=False):
    if not allow_full:
        _guard_full_table_write(sql)
    with _write_lock:          # 进程内排队，杜绝多线程抢写锁
        c = get_conn()
        cur = c.execute(sql, args)
        c.commit()
        return cur.lastrowid


def ex_count(sql, args=(), allow_full=False):
    """执行写语句并返回受影响行数。

    ex() 返回的是 lastrowid，对 UPDATE/DELETE 没有意义；需要「条件更新 +
    判断是否真的改到了」的场景（如审核的并发抢占）必须看 rowcount。
    """
    if not allow_full:
        _guard_full_table_write(sql)
    with _write_lock:
        c = get_conn()
        cur = c.execute(sql, args)
        n = cur.rowcount
        c.commit()
        return n


# ---------- 用户分组 ----------
GROUP_PERMS = ("share", "edit", "cover", "download", "delete", "private_shelf", "convert",
               "listen", "public_library", "publish_booklist", "promote", "invite")
GROUP_LIMITS = ("share_max_days", "share_max_links", "download_monthly_limit",
                "listen_monthly_limit", "shelf_limit", "convert_daily_limit",
                "upload_max_mb")


def list_groups():
    return q("SELECT * FROM user_groups ORDER BY sort_order, id")


def get_group(gid):
    return q("SELECT * FROM user_groups WHERE id=?", (gid,), one=True)


def group_by_code(code):
    return q("SELECT * FROM user_groups WHERE code=?", (code,), one=True)


def add_group(name, can=None, limits=None, sort_order=0):
    can = can or {}
    limits = limits or {}
    code = "g" + uuid4().hex[:6]
    return ex(
        "INSERT INTO user_groups (code,name,sort_order,can_share,can_edit,can_cover,can_download,can_delete,can_private_shelf,can_convert,can_listen,can_public_library,can_publish_booklist,can_promote,can_invite,promote_reward,invite_reward,share_max_days,share_max_links,download_monthly_limit,listen_monthly_limit,shelf_limit,convert_daily_limit,upload_max_mb,exchange_cost,is_system,created_at) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,0,?)",
        (code, name, sort_order,
         int(bool(can.get("share"))), int(bool(can.get("edit"))), int(bool(can.get("cover"))),
         int(bool(can.get("download"))), int(bool(can.get("delete"))), int(bool(can.get("private_shelf"))),
         int(bool(can.get("convert"))), int(bool(can.get("listen"))),
         int(bool(can.get("public_library"))),
         int(bool(can.get("publish_booklist"))),
         int(bool(can.get("promote"))),
         int(bool(can.get("invite"))),
         max(0, int(limits.get("promote_reward", 0) or 0)),
         max(0, int(limits.get("invite_reward", 0) or 0)),
         int(limits.get("share_max_days", 0) or 0), int(limits.get("share_max_links", 0) or 0),
         int(limits.get("download_monthly_limit", 0) or 0),
         int(limits.get("listen_monthly_limit", 0) or 0),
         int(limits.get("shelf_limit", 0) or 0),
         int(limits.get("convert_daily_limit", 0) or 0),
         max(0, int(limits.get("upload_max_mb", 0) or 0)),
         int(limits.get("exchange_cost", 0) or 0),
         now()))


def update_group(gid, name=None, can=None, limits=None, sort_order=None, exchange_cost=None,
                 promote_reward=None, invite_reward=None):
    sets, args = [], []
    if name is not None:
        sets.append("name=?"); args.append(name)
    if sort_order is not None:
        sets.append("sort_order=?"); args.append(int(sort_order))
    if exchange_cost is not None:
        sets.append("exchange_cost=?"); args.append(max(0, int(exchange_cost or 0)))
    if promote_reward is not None:
        # 0 = 不奖励，负数没有意义
        sets.append("promote_reward=?"); args.append(max(0, int(promote_reward or 0)))
    if invite_reward is not None:
        sets.append("invite_reward=?"); args.append(max(0, int(invite_reward or 0)))
    for p in GROUP_PERMS:
        if can is not None and p in can:
            sets.append(f"can_{p}=?"); args.append(int(bool(can[p])))
    for k in GROUP_LIMITS:
        if limits is not None and k in limits:
            # 限额都是「≥0 的数值，0=不限/不启用」，负数没有意义 —— 夹到 0，
            # 免得后台传个 -1 变成谁也没定义过的「负限额」状态。
            sets.append(f"{k}=?"); args.append(max(0, int(limits[k] or 0)))
    if sets:
        args.append(gid)
        ex(f"UPDATE user_groups SET {','.join(sets)} WHERE id=?", args)


def delete_group(gid):
    ex("DELETE FROM user_groups WHERE id=?", (gid,))


def quota_from_group(g):
    """分组书架上限 → 用户配额（0=不限 → 999999 哨兵）"""
    n = int(g["shelf_limit"] or 0) if g else 0
    return n if n > 0 else 999999


def assign_group(user_id, gid):
    """给用户分配分组：同步 role（管理员分组→admin）与配额"""
    g = get_group(gid) if gid else None
    if not g:
        g = group_by_code("guest")
    role = "admin" if g["code"] == "admin" else "user"
    ex("UPDATE users SET group_id=?, role=?, quota=? WHERE id=?",
       (g["id"], role, quota_from_group(g), user_id))
    return g


def count_active_shares(user_id):
    r = q("SELECT COUNT(*) n FROM shares WHERE user_id=? AND (expire_at IS NULL OR expire_at > ?)",
          (user_id, now()), one=True)
    return r["n"] if r else 0


def count_month_downloads(user_id):
    month_start = now()[:8] + "01 00:00:00"
    r = q("SELECT COUNT(DISTINCT book_id) n FROM download_logs WHERE user_id=? AND created_at>=?",
          (user_id, month_start), one=True)
    return r["n"] if r else 0


def log_download(user_id, book_id):
    ex("INSERT INTO download_logs (user_id,book_id,created_at) VALUES (?,?,?)",
       (user_id, book_id, now()))


LISTEN_VALID_DAYS = 30       # 听书权限有效期（天）


def listen_cutoff():
    """听书权限的**有效起点**：此刻往前推 LISTEN_VALID_DAYS 天。

    ★ 业主 2026-10-04 定的规则（推翻了之前的「永久有效」）：
      · 用树叶买的听书权限，**只在 30 天内有效**，过期后要重新购买；
      · 分组自带的免费听书额度，占下的名额**也只在 30 天内有效**，
        超过 30 天再听要重新占一个名额。
      目的：限制会员一个月内的听书量，避免 TTS 被打爆。

    实现上是**滚动 30 天窗口**（从取得那一刻起算），不是自然月：
    「超过一个月后再听还会消耗」这句话本身就是「取得后满一个月作废」的意思，
    自然月会在月初/月末产生「刚占的名额马上就过期」的怪现象。

    ★ 注意历史：这里以前是「永久」。当时改成永久，是因为按自然月算会
      出现「同一本书下个月又扣一次」，用户抱怨「怎么又扣了」。现在业主
      明确要求按月限制，所以**那个抱怨变成了预期行为** —— 前端必须把
      「30 天有效、到期需重新购买」写清楚，否则同样的投诉会再来一遍。
    """
    return (datetime.now(timezone.utc) + timedelta(hours=8)
            - timedelta(days=LISTEN_VALID_DAYS)).strftime("%Y-%m-%d %H:%M:%S")


def count_month_listens(user_id):
    """近 LISTEN_VALID_DAYS 天占用免费听书额度的本数（同一本书只算一本）。

    函数名沿用历史的 `month`（调用点很多），语义已经是滚动 30 天窗口，
    与 `listen_logged()` 用同一个 `listen_cutoff()`，两者口径必须一致 ——
    否则会出现「额度显示还有剩，但放行判断说没有」这种自相矛盾。
    """
    r = q("SELECT COUNT(DISTINCT book_id) n FROM listen_logs WHERE user_id=? AND created_at>=?",
          (user_id, listen_cutoff()), one=True)
    return r["n"] if r else 0


def listen_logged(user_id, book_id):
    """这本书**当前**是否还占着免费额度（占下之后 LISTEN_VALID_DAYS 天内有效）。

    过期后返回 False，于是：
      · `count_month_listens()` 也不再把它算进「已用本数」；
      · 用户再听这本书会**重新占一个名额**，额度用完就回到扣树叶。
    这正是业主要的「限制一个月内的听书量」。
    """
    return bool(q("SELECT 1 FROM listen_logs WHERE user_id=? AND book_id=? AND created_at>=?",
                  (user_id, book_id, listen_cutoff()), one=True))


def log_listen(user_id, book_id):
    ex("INSERT INTO listen_logs (user_id,book_id,created_at) VALUES (?,?,?)",
       (user_id, book_id, now()))


def count_daily_converts(user_id):
    day_start = now()[:10] + " 00:00:00"
    r = q("SELECT COUNT(DISTINCT book_id) n FROM convert_logs WHERE user_id=? AND created_at>=?",
          (user_id, day_start), one=True)
    return r["n"] if r else 0


def log_convert(user_id, book_id):
    ex("INSERT INTO convert_logs (user_id,book_id,created_at) VALUES (?,?,?)",
       (user_id, book_id, now()))


# ---------- 敏感操作审计 ----------
def log_audit(user, action, target_type=None, target_id=None, detail=None, ip=None):
    """记录敏感操作留痕（user 可为 None，如匿名分享访问）"""
    global _audit_clean_counter
    uid = user["id"] if user else None
    uname = user["username"] if user else None
    ex("INSERT INTO audit_logs (user_id,username,action,target_type,target_id,detail,ip,created_at) "
       "VALUES (?,?,?,?,?,?,?,?)",
       (uid, uname, action, target_type, target_id, detail, ip, now()))
    # 节流清理：每 100 条记录顺带清理一次 30 天前的日志，避免日志无限膨胀
    _audit_clean_counter += 1
    if _audit_clean_counter % 100 == 0:
        clean_audit()


_audit_clean_counter = 0


def log_file(user, action, filename, size=None, source="web", book_id=None,
             book_title=None, ip=None, ext=None):
    """记录一次文件上传/下载（后台「上传下载」板块的数据来源）。

    ★ 扩展名单独存一列（而不是从文件名里现抠）：用户明确要求日志「带文件扩展名」，
      而且报表要能按类型筛（「这周下载了多少 pdf」），所以它得是可索引的列。
      没传 ext 就从文件名推；连文件名都没有就留空。
    """
    name = (filename or "").strip()
    e = (ext or "").lower().lstrip(".")
    if not e and "." in name:
        e = name.rsplit(".", 1)[-1].lower()
    try:
        n = int(size) if size is not None else None
    except (TypeError, ValueError):
        n = None
    ex("INSERT INTO file_logs (user_id,username,action,filename,ext,bytes,source,"
       "book_id,book_title,ip,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
       (user["id"] if user else None, user["username"] if user else None,
        action, name, e, n, source, book_id, book_title, ip, now()))


def clean_file_logs(days=365):
    """删除 days 天之前的上传下载日志（比审计日志留得久：这是合规追溯的主要依据）"""
    cutoff = (datetime.now(timezone.utc) + timedelta(hours=8)
              - timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")
    ex("DELETE FROM file_logs WHERE created_at < ?", (cutoff,))


def clean_audit(days=30):
    """删除 days 天之前的审计日志（默认仅保留最近 30 天）"""
    # 口径修正(2026-10-01)：与 log_audit 写入的 created_at 保持一致（北京时间 UTC+8）。
    # 原写法用裸 datetime.now()，其结果随系统时区（本机为 UTC），cutoff 会比
    # 实际时间早 8 小时，导致审计日志只保留 days-8h 天。
    cutoff = (datetime.now(timezone.utc) + timedelta(hours=8)
              - timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")
    ex("DELETE FROM audit_logs WHERE created_at < ?", (cutoff,))


def list_audit(page=1, size=50, action=None, user_id=None, keyword=None):
    """分页查询审计日志：可按 action、user_id 过滤，keyword 对详情(detail)模糊搜索"""
    w, args = [], []
    if action:
        w.append("action=?"); args.append(action)
    if user_id:
        w.append("user_id=?"); args.append(user_id)
    if keyword:
        w.append("detail LIKE ?"); args.append(f"%{keyword}%")
    wsql = (" WHERE " + " AND ".join(w)) if w else ""
    total = q(f"SELECT COUNT(*) n FROM audit_logs{wsql}", args, one=True)["n"]
    page = max(1, page)
    size = min(200, max(1, size))
    rows = q(f"SELECT * FROM audit_logs{wsql} ORDER BY id DESC LIMIT ? OFFSET ?",
             args + [size, (page - 1) * size])
    return {"items": [dict(r) for r in rows], "total": total}


def list_file_logs(page=1, size=50, action=None, ext=None, keyword=None, days=0):
    """分页查询上传下载日志：可按动作（upload/download）、扩展名、关键词、天数过滤。

    ★ 额外返回按扩展名的汇总（不受分页影响）——用户要这个板块的初衷就是
      「看清楚大家都在传什么格式」，所以汇总和列表一起给。
    """
    w, args = [], []
    if action in ("upload", "download"):
        w.append("action=?"); args.append(action)
    if ext:
        w.append("LOWER(ext)=?"); args.append(ext.lower().lstrip("."))
    if keyword:
        w.append("(username LIKE ? OR filename LIKE ? OR book_title LIKE ? OR ip LIKE ?)")
        args += ["%%%s%%" % keyword] * 4
    if days and int(days) > 0:
        cutoff = (datetime.now(timezone.utc) + timedelta(hours=8)
                  - timedelta(days=int(days))).strftime("%Y-%m-%d %H:%M:%S")
        w.append("created_at >= ?"); args.append(cutoff)
    wsql = (" WHERE " + " AND ".join(w)) if w else ""
    total = q("SELECT COUNT(*) n FROM file_logs" + wsql, args, one=True)["n"]
    page = max(1, page)
    size = min(200, max(1, size))
    rows = q("SELECT * FROM file_logs" + wsql + " ORDER BY id DESC LIMIT ? OFFSET ?",
             args + [size, (page - 1) * size])
    exts = q("SELECT LOWER(ext) e, COUNT(*) n, COALESCE(SUM(bytes),0) b FROM file_logs"
             + wsql + " GROUP BY LOWER(ext) ORDER BY n DESC, e", args)
    by_action = q("SELECT action, COUNT(*) n FROM file_logs" + wsql + " GROUP BY action", args)
    return {"items": [dict(r) for r in rows], "total": total,
            "exts": [{"ext": r["e"] or "", "n": r["n"], "bytes": r["b"]} for r in exts],
            "by_action": {r["action"]: r["n"] for r in by_action}}


# ---------- 侵权举报 ----------def add_report(book_id, user_id, reason, detail=""):
    rid = ex("INSERT INTO book_reports (book_id,user_id,reason,detail,status,created_at) VALUES (?,?,?,?,?,?)",
             (book_id, user_id, reason, detail, "pending", now()))
    return rid


def list_reports(status=None):
    wsql = " WHERE r.status=?" if status else ""
    args = [status] if status else []
    return q(f"""SELECT r.*, b.title, b.author, u.username FROM book_reports r
                 LEFT JOIN books b ON b.id=r.book_id
                 LEFT JOIN users u ON u.id=r.user_id{wsql}
                 ORDER BY r.id DESC""", args)


def set_report_status(report_id, status, handled_by=None):
    ex("UPDATE book_reports SET status=?, handled_at=?, handled_by=? WHERE id=?",
       (status, now(), handled_by, report_id))


def count_pending_reports():
    r = q("SELECT COUNT(*) n FROM book_reports WHERE status='pending'", one=True)
    return r["n"] if r else 0


# ---------- 共享申请（私人上传书申请转为公共书） ----------
def add_share_request(book_id, requester_id):
    rid = ex("INSERT INTO share_requests (book_id,requester_id,status,created_at) VALUES (?,?,?,?)",
             (book_id, requester_id, "pending", now()))
    return rid


def pending_share_request(book_id):
    return q("SELECT * FROM share_requests WHERE book_id=? AND status='pending' ORDER BY id DESC LIMIT 1",
             (book_id,), one=True)


def list_share_requests(page=1, size=15):
    """共享申请列表：一律按提交时间倒序（最新的在最前），分页返回"""
    size = max(1, int(size or 15))
    page = max(1, int(page or 1))
    total = q("SELECT COUNT(*) n FROM share_requests", one=True)["n"]
    pages = max(1, (total + size - 1) // size)
    page = min(page, pages)
    rows = q("""SELECT r.*, b.title, b.author, b.ext, b.size, u.username AS requester
                FROM share_requests r
                LEFT JOIN books b ON b.id=r.book_id
                LEFT JOIN users u ON u.id=r.requester_id
                ORDER BY r.created_at DESC, r.id DESC
                LIMIT ? OFFSET ?""", (size, (page - 1) * size))
    return {"requests": [dict(r) for r in rows], "total": total,
            "page": page, "pages": pages, "size": size,
            "pending": count_pending_share_requests()}


def count_pending_share_requests():
    r = q("SELECT COUNT(*) n FROM share_requests WHERE status='pending'", one=True)
    return r["n"] if r else 0


def set_share_request_status(req_id, status, reviewed_by=None):
    ex("UPDATE share_requests SET status=?, reviewed_at=?, reviewed_by=? WHERE id=?",
       (status, now(), reviewed_by, req_id))


# ---------- 笔记索引（正文存 WebDAV，这里仅做快速列表索引） ----------
def note_touch(user_id, book_id):
    ex("INSERT INTO notes (user_id,book_id,updated_at) VALUES (?,?,?) "
       "ON CONFLICT(user_id,book_id) DO UPDATE SET updated_at=excluded.updated_at",
       (user_id, book_id, now()))


def list_notes(user_id):
    return q("""SELECT n.book_id, n.updated_at, b.title, b.author, b.cover, b.ext
                FROM notes n JOIN books b ON b.id=n.book_id
                WHERE n.user_id=? ORDER BY n.updated_at DESC""", (user_id,))


def remove_note_index(user_id, book_id):
    ex("DELETE FROM notes WHERE user_id=? AND book_id=?", (user_id, book_id))


# ---------- 站内消息 ----------
def add_message(to_id, title, body="", kind="system", from_id=None, link="",
                ref_type=None, ref_id=None, is_read=0):
    """写入一条站内消息；收件人为 0/None 时忽略（例如对方账号已注销）"""
    if not to_id:
        return None
    return ex("INSERT INTO messages (from_id,to_id,kind,title,body,link,ref_type,ref_id,is_read,created_at) "
              "VALUES (?,?,?,?,?,?,?,?,?,?)",
              (from_id or None, to_id, kind, title or "", body or "", link or "",
               ref_type, ref_id, 1 if is_read else 0, now()))


def admin_ids():
    """启用的管理员用户ID（审核类通知的接收方）"""
    return [r["id"] for r in q("SELECT id FROM users WHERE role='admin' AND enabled=1")]


def count_unread_messages(uid):
    r = q("SELECT COUNT(*) n FROM messages WHERE to_id=? AND is_read=0", (uid,), one=True)
    return r["n"] if r else 0


def list_messages(uid, page=1, page_size=5, scope="all"):
    """站内消息分页。

    scope 用来筛「用户消息 / 系统消息」，口径就是 `from_id` 有没有值：
      * user   = 用户消息：有具体发送人（私信、站内分享、书单回复通知…）
      * system = 系统消息：没有发送人（审核结果、举报处理、群发、欢迎信、升级通知…）
      * all    = 全部（默认，行为与加 scope 之前完全一致）
    注意：这里**只加筛选条件**，不改任何既有数据的归类 —— from_id 为空的本来就
    显示成「系统消息」，有值的本来就显示「来自 xxx」，所以筛选结果与界面上看到的一致。
    """
    scope = scope if scope in ("user", "system") else "all"
    cond = ""
    if scope == "user":
        cond = " AND m.from_id IS NOT NULL"
    elif scope == "system":
        cond = " AND m.from_id IS NULL"
    total = q("SELECT COUNT(*) n FROM messages m WHERE m.to_id=?" + cond, (uid,), one=True)["n"]
    pages = max(1, (total + page_size - 1) // page_size)
    page = max(1, min(int(page or 1), pages))
    rows = q("""SELECT m.*, u.username AS u_name, u.name AS u_real
                FROM messages m LEFT JOIN users u ON u.id=m.from_id
                WHERE m.to_id=?""" + cond + """ ORDER BY m.id DESC LIMIT ? OFFSET ?""",
             (uid, page_size, (page - 1) * page_size))
    items = []
    for r in rows:
        d = dict(r)
        d["from_name"] = (r["u_real"] or r["u_name"]) if r["from_id"] else "系统"
        d["from_name"] = d["from_name"] or "已注销"
        d.pop("u_real", None); d.pop("u_name", None)
        items.append(d)
    return {"items": items, "total": total, "page": page, "pages": pages,
            "unread": count_unread_messages(uid)}


def mark_messages_read(uid, ids=None):
    if ids:
        ids = [int(i) for i in ids]
        ph = ",".join("?" * len(ids))
        ex(f"UPDATE messages SET is_read=1 WHERE to_id=? AND id IN ({ph})", [uid] + ids)
    else:
        ex("UPDATE messages SET is_read=1 WHERE to_id=? AND is_read=0", (uid,))
    return count_unread_messages(uid)


def find_user_by_nickname(nick):
    """按昵称查找接收者（昵称优先，其次用户名）；同名历史数据取最早注册的那个"""
    nick = (nick or "").strip()
    if not nick:
        return None
    r = q("SELECT * FROM users WHERE name=? ORDER BY id LIMIT 1", (nick,), one=True)
    if not r:
        r = q("SELECT * FROM users WHERE username=? ORDER BY id LIMIT 1", (nick,), one=True)
    return r


def nickname_taken(name, exclude_id=None):
    """昵称是否已被他人占用（昵称不可重复）"""
    name = (name or "").strip()
    if not name:
        return False
    if exclude_id:
        r = q("SELECT id FROM users WHERE name=? AND id!=?", (name, exclude_id), one=True)
    else:
        r = q("SELECT id FROM users WHERE name=?", (name,), one=True)
    return bool(r)


# ---------- 分组兑换（树叶 → 分组，有效期按月） ----------
def _bj_now():
    """当前北京时间（不依赖服务器时区）"""
    return datetime.now(timezone.utc) + timedelta(hours=8)


def bj_add_months(months=1, base=None):
    """北京时间 + N 个自然月（按目标月天数收敛，如 1/31 + 1 月 → 2/28）"""
    d = base or _bj_now()
    y, m = d.year, d.month + int(months or 1)
    y += (m - 1) // 12
    m = (m - 1) % 12 + 1
    day = min(d.day, _month_days(y, m))
    return d.replace(year=y, month=m, day=day).strftime("%Y-%m-%d %H:%M:%S")


def _month_days(y, m):
    if m == 12:
        nxt = datetime(y + 1, 1, 1)
    else:
        nxt = datetime(y, m + 1, 1)
    return (nxt - timedelta(days=1)).day


def exchange_options():
    """可兑换的分组（兑换数量 > 0），按价格从低到高"""
    return q("SELECT * FROM user_groups WHERE exchange_cost>0 ORDER BY exchange_cost, sort_order, id")


def active_upgrade(user_id):
    return q("SELECT * FROM group_upgrades WHERE user_id=? AND status='active' "
             "ORDER BY id DESC LIMIT 1", (user_id,), one=True)


def upgrade_history(user_id, limit=10):
    return q("SELECT * FROM group_upgrades WHERE user_id=? ORDER BY id DESC LIMIT ?",
             (user_id, limit))


def add_upgrade(user_id, from_group_id, to_group_id, cost, months, expires_at):
    return ex("INSERT INTO group_upgrades (user_id,from_group_id,to_group_id,cost,months,"
              "started_at,expires_at,status,created_at) VALUES (?,?,?,?,?,?,?,'active',?)",
              (user_id, from_group_id, to_group_id, cost, months, now(), expires_at, now()))


def update_upgrade(upgrade_id, to_group_id, cost, expires_at):
    ex("UPDATE group_upgrades SET to_group_id=?, cost=?, expires_at=? WHERE id=?",
       (to_group_id, cost, expires_at, upgrade_id))


def close_upgrade(upgrade_id, status="expired"):
    ex("UPDATE group_upgrades SET status=? WHERE id=?", (status, upgrade_id))


def expire_group_upgrades():
    """把已到期的兑换回退到升级前的分组，返回处理条数。

    在每个请求入口做节流扫描，保证过期后权限不会被长期占用。
    若期间管理员已手动调整过该用户的分组，则以管理员设置为准，只关单不回退。
    """
    due = q("SELECT * FROM group_upgrades WHERE status='active' AND expires_at IS NOT NULL "
            "AND expires_at<=? ORDER BY id", (now(),))
    n = 0
    for u in due:
        cur = q("SELECT group_id FROM users WHERE id=?", (u["user_id"],), one=True)
        if cur and cur["group_id"] != u["to_group_id"]:
            # 分组已被管理员改动 → 不回退，仅结束兑换
            close_upgrade(u["id"], "expired")
            log_audit(None, "group_upgrade_expire", "user", u["user_id"],
                      "分组兑换到期；期间分组已被管理员调整，保留当前分组不回退")
            n += 1
            continue
        back = get_group(u["from_group_id"]) if u["from_group_id"] else None
        if not back:
            back = group_by_code("guest")
        if back:
            ex("UPDATE users SET group_id=?, quota=?, role=? WHERE id=?",
               (back["id"], quota_from_group(back),
                "admin" if back["code"] == "admin" else "user", u["user_id"]))
        close_upgrade(u["id"], "expired")
        log_audit(None, "group_upgrade_expire", "user", u["user_id"],
                  f"分组兑换到期，已回退到「{back['name'] if back else '读者'}」")
        n += 1
    return n


# ---------- 树叶奖励（书单文章通过 / 电子书共享通过） ----------
REWARD_KEYS = {
    "booklist": ("reward_booklist", 20),            # 「书单」文章审核通过奖励
    "share_article": ("reward_share_article", 10),  # 「分享」文章审核通过奖励
    "share_request": ("reward_share_request", 10),  # 电子书共享审核通过奖励
}


def reward_amount(kind):
    """读取后台设置的单次奖励树叶数；非法值回落到默认值，0 表示不发放"""
    key, dft = REWARD_KEYS.get(kind, (None, 0))
    if not key:
        return 0
    raw = get_config(key, None)
    if raw is None or str(raw).strip() == "":
        return dft
    try:
        return max(0, int(str(raw).strip()))
    except (TypeError, ValueError):
        return dft


def grant_leaves(user_id, kind, leaves, ref_type=None, ref_id=None, note=None):
    """发放树叶奖励，返回实际发出的树叶数（0 = 未发放）。

    leaf_gain 上的 UNIQUE(kind, ref_type, ref_id) 保证同一来源只发一次：
    审核接口即使被重复调用，也不会重复发奖励。
    """
    try:
        leaves = int(leaves)
    except (TypeError, ValueError):
        return 0
    if not user_id or leaves <= 0:
        return 0
    c = get_conn()
    try:
        c.execute("INSERT INTO leaf_gain (user_id,kind,ref_type,ref_id,leaves,note,created_at) "
                  "VALUES (?,?,?,?,?,?,?)",
                  (user_id, kind, ref_type, ref_id, leaves, note, now()))
    except sqlite3.IntegrityError:
        return 0        # 这条来源已经发过奖励
    c.execute("INSERT INTO user_leaves (user_id,balance,updated_at) VALUES (?,?,?) "
              "ON CONFLICT(user_id) DO UPDATE SET balance=balance+excluded.balance, "
              "updated_at=excluded.updated_at", (user_id, leaves, now()))
    c.commit()
    return leaves


def leaf_gain_history(user_id, limit=20):
    return q("SELECT * FROM leaf_gain WHERE user_id=? ORDER BY id DESC LIMIT ?", (user_id, limit))


def granted_before(kind, ref_type, ref_id):
    """该来源是否已发过奖励"""
    return bool(q("SELECT 1 FROM leaf_gain WHERE kind=? AND ref_type=? AND ref_id=?",
                  (kind, ref_type, ref_id), one=True))
