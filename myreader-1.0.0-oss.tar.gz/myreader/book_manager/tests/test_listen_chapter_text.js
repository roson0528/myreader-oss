// 听书页（/listen?id=N）「文字/高亮有没有跟着跳转走」的回归。
//
// 背景：用户报有声播放页切章文字不跟着换、点击文字无法定位（见 test_audio_chapter_text.js），
// 并怀疑「听书页面可能也存在问题」。
//
// 听书页与有声播放页的结构**根本不同**，所以那条 bug 不可能同样发生：
//   · 有声：分章时间轴，`章内相对秒 + chapStart` 定位 → 切章必须重新取本章句子；
//   · 听书：整本一个**扁平句子列表**（TOTAL 句），章节只是列表里的下标
//     （chapters[].start），切章 = jumpTo(句子下标)，文字按 30 句一窗懒加载
//     （renderWindow 发现 CUR 出窗会自动重新取）。
// 本脚本就是来验证这个结论：跳远句、跳章之后，高亮的那句与「服务端返回的第 N 句」
// 必须一致，章标题、进度也要跟上。
//
// 用原生桩（status 报 version 5）是为了让 listen.js 走 USE_NATIVE 分支：
// 否则 playIdx 会去调 ensureBlob() 触发**真实 TTS 合成**，既慢又白烧站长的额度。
//
// 只读服务端数据，不写任何库表（只清自己留下的单端锁）。
const { chromium } = require('playwright-core');
const { execSync } = require('child_process');
const CHROME = '/srv/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome';
const ROOT = '/srv/myreader/book_manager';

let pass = 0, fail = 0;
const ck = (n, ok, extra) => {
  if (ok) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (extra ? '  → ' + extra : '')); }
};
const py = (code) => execSync('venv/bin/python -', { cwd: ROOT, encoding: 'utf8', input: code }).trim();

const BRIDGE = `
window.__nc = { start: [], gotoIndex: [], seek: [], pause: 0, play: 0 };
(function () {
  let cur = 0, playing = true;
  const plug = {
    status: function () { return Promise.resolve({ version: 5, btLink: true, active: false,
      playing: playing, index: cur, total: window.__total || 0, bookId: 0, voice: '', rate: 1 }); },
    start: function (a) { window.__nc.start.push(a); if (a && typeof a.index === 'number') cur = a.index; window.__total = (a && a.total) || window.__total; return Promise.resolve({ ok: true }); },
    startMp3: function () { return Promise.resolve({ ok: true }); },
    gotoIndex: function (a) { window.__nc.gotoIndex.push(a); if (a && typeof a.index === 'number') cur = a.index; return Promise.resolve({ ok: true }); },
    seek: function (a) { window.__nc.seek.push(a); return Promise.resolve({ ok: true }); },
    play: function () { window.__nc.play++; playing = true; return Promise.resolve({ ok: true }); },
    pause: function () { window.__nc.pause++; playing = false; return Promise.resolve({ ok: true }); },
    next: function () { cur++; return Promise.resolve({ ok: true }); },
    prev: function () { cur--; return Promise.resolve({ ok: true }); },
    setVoice: function () { return Promise.resolve({ ok: true }); },
    setRate: function () { return Promise.resolve({ ok: true }); },
    stop: function () { return Promise.resolve({ ok: true }); },
  };
  window.Capacitor = { Plugins: { ListenService: plug } };
})();
`;

(async () => {
  const info = JSON.parse(py(`
import sys, json
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
import db, auth
u = db.q("SELECT * FROM users WHERE role='admin' AND enabled=1 ORDER BY id LIMIT 1", one=True)
# 听书单端锁与有声是两把独立的锁
try: db.ex("DELETE FROM listen_session WHERE user_id=?", (u["id"],))
except Exception: pass
# ★ 挑书要**零成本**：ext 是带点的（.txt/.epub/.mobi），
#   .txt 走 reader.chunks 直读、不触发 calibre 转换；.mobi/.azw3 会转格式（很重）。
#   候选只取 5 本，避免像上次那样一次问 400 本、把整本书都解析一遍。
rows = db.q("""SELECT id, title FROM books
  WHERE hidden=0 AND ext IN ('.txt','.epub') AND size BETWEEN 80000 AND 4000000
  ORDER BY id LIMIT 5""")
print(json.dumps({"token": auth.create_token(u), "uid": u["id"], "books": [dict(r) for r in rows]}))
`));
  const browser = await chromium.launch({ executablePath: CHROME, args: ['--no-sandbox'] });
  const ctx = await browser.newContext({ ignoreHTTPSErrors: true, viewport: { width: 420, height: 900 } });
  await ctx.addInitScript(tk => { localStorage.setItem('bm_token', tk);
    localStorage.setItem('bm_user', '{"id":1,"role":"admin"}'); }, info.token);
  await ctx.addInitScript(BRIDGE);
  const page = await ctx.newPage();
  const errs = [];
  page.on('pageerror', e => errs.push(String(e).slice(0, 160)));

  try {
    // ★ 必须先打开一个真实页面：探测用的是相对地址 fetch('/api/...')，
    //   在 about:blank 上会直接失败（上一次就是栽在这里，误报「没找到样本」）。
    await page.goto('https://127.0.0.1:9000/', { waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(1500);

    // 找一本可听、句子够多的书
    const probe = await page.evaluate(async (books) => {
      for (const b of books) {
        try {
          const r = await fetch('/api/books/' + b.id + '/listen/info',
            { headers: { Authorization: 'Bearer ' + (localStorage.getItem('bm_token') || '') } });
          if (!r.ok) continue;
          const j = await r.json();
          if (j && j.enabled && j.total >= 45) return { id: b.id, title: j.title, total: j.total };
        } catch (e) {}
      }
      return null;
    }, info.books);
    if (!probe) { console.log('  没找到合适的听书样本，跳过'); await browser.close(); process.exit(0); }
    console.log('  用《' + probe.title + '》（共 ' + probe.total + ' 句）');

    await page.goto('https://127.0.0.1:9000/listen?id=' + probe.id, { waitUntil: 'domcontentloaded' });
    // ★ 别用固定等待：这本书 2780 句，首次 listen/texts 要把整本切句，慢的时候好几秒。
    ck('听书页已初始化（句数 > 0）', await page.evaluate(() => TOTAL > 0));
    let rendered = true;
    try { await page.waitForSelector('#l-texts .l-seg', { timeout: 45000 }); }
    catch (e) { rendered = false; }
    ck('第一窗文字已渲染', rendered &&
       (await page.evaluate(() => document.querySelectorAll('#l-texts .l-seg').length > 0)));

    // ------------------------------------------------ A. 跳到一个「窗口外」的远句
    const far = Math.min(probe.total - 1, 38);
    const apiText = async (idx) => page.evaluate(async ([id, i]) => {
      const r = await fetch('/api/books/' + id + '/listen/texts?from=' + Math.max(0, i - 5) + '&count=30',
        { headers: { Authorization: 'Bearer ' + (localStorage.getItem('bm_token') || '') } });
      const j = await r.json();
      const it = (j.items || []).find(x => x.idx === i);
      return it ? { text: it.text, title: it.title || '' } : null;
    }, [probe.id, idx]);

    const wantFar = await apiText(far);
    await page.evaluate(i => jumpTo(i), far);
    await page.waitForTimeout(2000);
    const gotFar = await page.evaluate(i => {
      const el = document.querySelector('#l-texts .l-seg.cur');
      return { i: el ? Number(el.getAttribute('data-i')) : -1, t: el ? el.textContent : null,
               cur: CUR, pos: (document.getElementById('l-pos') || {}).textContent || '' };
    }, far);
    ck('★ 跳远句后高亮落在那一句（文字窗口会自动重取）', gotFar.i === far && gotFar.cur === far,
      'data-i=' + gotFar.i + ' CUR=' + gotFar.cur + ' 期望=' + far);
    ck('★ 高亮那句的文字与服务端第 ' + far + ' 句一致', !!wantFar && gotFar.t === wantFar.text,
      JSON.stringify(String(gotFar.t).slice(0, 24)) + ' vs ' + JSON.stringify(String(wantFar && wantFar.text).slice(0, 24)));
    ck('位置显示跟上（第 ' + (far + 1) + ' 句）', gotFar.pos.indexOf(String(far + 1) + ' /') === 0, gotFar.pos);

    // ------------------------------------------------ B. 跳章（章节只是句子下标）
    const chap = await page.evaluate(() => {
      const cs = (INFO.chapters || []).slice().sort((a, b) => a.start - b.start);
      return cs.length >= 2 ? cs[1] : null;
    });
    if (chap) {
      const wantChap = await apiText(chap.start);
      await page.evaluate(i => jumpTo(i), chap.start);
      await page.waitForTimeout(2000);
      const gotChap = await page.evaluate(i => {
        const el = document.querySelector('#l-texts .l-seg.cur');
        return { i: el ? Number(el.getAttribute('data-i')) : -1, t: el ? el.textContent : null,
                 title: (document.getElementById('l-chapter') || {}).textContent || '', cur: CUR };
      }, chap.start);
      ck('★ 跳章后高亮落在该章第一句', gotChap.i === chap.start && gotChap.cur === chap.start,
        'data-i=' + gotChap.i + ' 期望=' + chap.start);
      ck('★ 跳章后那一句的文字与服务端一致', !!wantChap && gotChap.t === wantChap.text,
        JSON.stringify(String(gotChap.t).slice(0, 24)));
      ck('章标题跟上了', !!gotChap.title && (wantChap.title ? gotChap.title === wantChap.title : true),
        JSON.stringify(gotChap.title));
    } else {
      console.log('    （这本书分不出第二章，跳过跳章断言）');
    }

    // ------------------------------------------------ C. 原生桩确实接管了播放（没有触发真实 TTS）
    const nat = await page.evaluate(() => ({ use: typeof USE_NATIVE !== 'undefined' ? USE_NATIVE : null,
      start: window.__nc.start.length, goto: window.__nc.gotoIndex.length }));
    ck('★ 走的是原生分支（没触发真实 TTS 合成）', nat.use === true && nat.start > 0,
      'USE_NATIVE=' + nat.use + ' start=' + nat.start + ' gotoIndex=' + nat.goto);

    ck('过程中页面无 JS 报错', errs.length === 0, errs.slice(0, 2).join(' | '));
  } finally {
    try {
      py(`import sys; sys.path.insert(0, '${ROOT}')
import db
for t in ('listen_session', 'ab_session'):
    try: db.ex("DELETE FROM " + t + " WHERE user_id=?", (${info.uid},))
    except Exception: pass`);
    } catch (e) {}
    await browser.close();
  }
  console.log('');
  console.log('听书页跳句/跳章文字同步：' + pass + ' 通过 / ' + fail + ' 失败');
  process.exit(fail ? 1 : 0);
})();
