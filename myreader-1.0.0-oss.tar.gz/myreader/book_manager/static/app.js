// 云阅读 - 前端主逻辑
let TOKEN = localStorage.getItem('bm_token') || '';
let USER = JSON.parse(localStorage.getItem('bm_user') || 'null');
let GUEST = false;   // 游客模式：未登录直接浏览首页，仅可试读范例图书
let curCategory = '';
let curPage = 1, curQ = '', curAuthor = '';
let curPages = 1;
let cats = [];
let detailBook = null;
let lastPage = 'library';
let lastHash = '#/library';
let SIGNIN = null;   // 签到状态缓存：{signed_today, streak, balance, ...}

// 封面 URL：追加媒体凭证与版本号（封面更新后刷新浏览器缓存）
// 不再携带登录令牌：凭证 24 小时有效，泄露也无法冒充账号
let mediaTicket = '', mediaTicketExp = 0;
async function ensureMediaTicket() {
  if (mediaTicket && Date.now() < mediaTicketExp - 60000) return mediaTicket;
  try {
    const r = await api('/api/media-ticket', { method: 'POST' });
    mediaTicket = r.ticket; mediaTicketExp = Date.now() + (r.expires_in || 86400) * 1000;
  } catch (e) {}
  return mediaTicket;
}
function coverUrl(u, v) {
  if (!u) return '';
  let s = u + (u.includes('?') ? '&' : '?') + 't=' + encodeURIComponent(mediaTicket);
  if (v) s += '&v=' + encodeURIComponent(v);
  return s;
}

// 后端错误体 → 人能看懂的一句话。
// ★ 坑：FastAPI 的校验错误（422）detail 是【对象数组】，直接拼进 new Error/字符串
//   会渲染成「[object Object]」，用户看不出哪里错了（背景音乐导入就踩过）。
function apiErrText(d, status) {
  const det = d && (d.detail != null ? d.detail : d.message);
  if (typeof det === 'string' && det) return det;
  if (Array.isArray(det)) {
    const parts = det.map(x => {
      if (typeof x === 'string') return x;
      if (x && typeof x === 'object') {
        const loc = Array.isArray(x.loc) ? x.loc.filter(k => k !== 'body' && k !== 'query').join('.') : '';
        return (loc ? loc + '：' : '') + (x.msg || JSON.stringify(x));
      }
      return String(x);
    }).filter(Boolean);
    if (parts.length) return parts.join('；');
  } else if (det && typeof det === 'object') {
    return det.message || det.msg || JSON.stringify(det);
  }
  // 后端什么都没给：返回空串，由调用方给各自合适的兜底文案
  // （登录 401 要说「用户名或密码错误」，别的接口说 HTTP 状态码）
  return '';
}
function api(path, opts = {}) {
  const headers = opts.headers || {};
  if (TOKEN) headers['Authorization'] = 'Bearer ' + TOKEN;
  return fetch(path, { ...opts, headers }).then(async r => {
    const ct = r.headers.get('content-type') || '';
    const data = ct.includes('json') ? await r.json() : await r.text();
    // ★ 抛出的 Error 一律带上 HTTP 状态码。
    //   调用方经常要按状态分流 —— 例如有声阅读取票拿到 409（该账号正在另一台设备上收听）
    //   要弹「在这台设备上继续听」的抢占框，而不是只 toast 一下就完。
    //   原来只有 message、没有 status，前端只能靠文案猜（听书那边是自己另写了
    //   一个 lapi 才拿到 status 的，属于同一个坑绕开走）。
    const fail = (msg) => { const e = new Error(msg); e.status = r.status; return e; };
    if (r.status === 401) {
      // 登录/注册的 401 是“凭证错误”，直接显示服务器原因；其余接口的 401 才是会话失效
      if (path === '/api/login' || path === '/api/register') {
        throw fail(apiErrText(data, r.status) || '用户名或密码错误');
      }
      if (GUEST) { throw fail('请注册账号后使用此功能'); }
      logout(false);
      throw fail('未登录');
    }
    if (!r.ok) throw fail(apiErrText(data, r.status) || ('请求失败 ' + r.status));
    return data;
  });
}

// ---------- 下载 / 阅读链路域名（后台「设置 → 下载与阅读链路域名」） ----------
// 分享链接、App 安装包这些「我们生成的绝对地址」统一用后台配的域名拼，不再跟着
// 访客的访问域名走（反向代理域名比服务器直达域名慢一截）。后台留空才回退到当前域名。
let _lbP = null;
function getLinkBase() {
  if (!_lbP) {
    _lbP = fetch('/api/site').then(r => r.json()).then(d => {
      const v = (d && d.link_base) ? String(d.link_base) : '';
      return (v || location.origin).replace(/\/+$/, '') + '/';   // 统一带尾斜杠，方便拼站内路径
    }).catch(() => location.origin.replace(/\/+$/, '') + '/');
  }
  return _lbP;
}
/** 站内路径 → 对外绝对地址（下载、App 安装包这类「交给别人的地址」一律用它） */
async function absLink(path) {
  const b = await getLinkBase();
  return b + String(path || '').replace(/^\/+/, '');
}

function toast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg; t.classList.add('show');
  clearTimeout(t._tm); t._tm = setTimeout(() => t.classList.remove('show'), 2200);
}
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

// ---------- 推广邀请 ----------
// 设备指纹：给「同一台机器只算一个有效注册」的防刷判定用。
// 只用浏览器自身的稳定特征做哈希，**不落 localStorage** ——
// 落了 localStorage 的话，清一下缓存就换了新指纹，防刷等于没有。
// 注意这是「提高刷号成本」，不是密码学意义上的身份 —— 服务端还会做其它校验。
async function bmFingerprint() {
  try {
    const parts = [
      navigator.userAgent, navigator.platform, navigator.language,
      (navigator.languages || []).join(','),
      screen.width + 'x' + screen.height + 'x' + (screen.colorDepth || 0),
      new Date().getTimezoneOffset(),
      navigator.hardwareConcurrency || 0, navigator.deviceMemory || 0,
      navigator.maxTouchPoints || 0,
    ];
    try {   // canvas 绘制差异：不同显卡/字体栈画出来不一样
      const c = document.createElement('canvas');
      c.width = 220; c.height = 40;
      const g = c.getContext('2d');
      g.textBaseline = 'top'; g.font = '14px Arial';
      g.fillStyle = '#f60'; g.fillRect(0, 0, 100, 20);
      g.fillStyle = '#069'; g.fillText('laoshu-fp', 2, 2);
      parts.push(c.toDataURL().slice(-96));
    } catch (e) { /* 画不出来就少一个维度，不影响注册 */ }
    const raw = parts.join('|');
    if (window.crypto && crypto.subtle && window.TextEncoder) {
      const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(raw));
      return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
    }
    let h = 0;                                  // http（非安全上下文）没有 subtle
    for (let i = 0; i < raw.length; i++) { h = (h * 31 + raw.charCodeAt(i)) | 0; }
    return 'f' + (h >>> 0).toString(16) + raw.length.toString(16);
  } catch (e) { return ''; }
}
// 推广链接带过来的邀请码（/?invite=XXXX）：先记着，等注册框打开再填进去
let PENDING_INVITE = '';
function pickInviteFromUrl() {
  const m = location.search.match(/[?&]invite=([A-Za-z0-9]{4,16})/);
  if (m) PENDING_INVITE = m[1].toUpperCase();
}
// 注册页的邀请码提示：后台开了「邀请注册」就显示「必须」，否则「可选」
async function loadRegisterConfig() {
  const hint = document.getElementById('reg-invite-hint');
  const inp = document.getElementById('reg-invite');
  if (!hint || !inp) return;
  try {
    const c = await api('/api/promote/config');
    const req = !!c.invite_required;
    hint.textContent = req ? '（必须）' : '（可选）';
    inp.placeholder = req ? '本站已开启邀请注册，请填写邀请码' : '选填，没有可留空';
  } catch (e) { hint.textContent = ''; }
  if (PENDING_INVITE && !inp.value) inp.value = PENDING_INVITE;
  // 从推广/邀请链接进来的：码已经填好了，明确告诉用户不用管，
  // 否则他看见一个陌生输入框会以为是必填项、跑去问「我该填什么」。
  const auto = document.getElementById('reg-invite-auto');
  if (auto) auto.style.display = (PENDING_INVITE && inp.value) ? '' : 'none';
}
// 推广 / 邀请两条渠道各自独立：权限与奖励分开。
// 但**统计只做一行四项**（推广注册/邀请注册/有效注册/累计奖励），
// 分成两块各显示各的反而看不出「一共拉了多少人」。
const PROMOTE_KINDS = ['promote', 'invite'];
async function loadPromote() {
  const card = document.getElementById('me-promote-card');
  if (!card) return;
  if (GUEST) { card.style.display = 'none'; return; }
  let any = false;
  try {
    const r = await api('/api/promote/me');
    const chs = r.channels || {};
    const t = r.totals || {};
    PROMOTE_KINDS.forEach(k => {
      const box = document.getElementById('me-promote-block-' + k);
      const btn = document.getElementById('me-regen-' + k);
      const c = chs[k];
      if (!box) return;
      if (!c || !c.allowed) { box.style.display = 'none'; if (btn) btn.style.display = 'none'; return; }
      any = true;
      box.style.display = '';
      if (btn) btn.style.display = '';
      if (k === 'promote') {
        // 推广只给链接：码就藏在链接里，从来不用手输，没必要单独露出来
        const code = c.code || '';
        document.getElementById('me-promote-link').value = code ? (location.origin + c.link) : '';
      } else {
        // 邀请只给码：四位，好念好抄
        document.getElementById('me-invite-code').textContent = c.code || '----';
      }
      document.getElementById('me-' + k + '-reward').textContent =
        c.reward > 0 ? ('有效注册 ' + c.reward + ' 树叶 / 人') : '当前分组未设奖励';
    });
    document.getElementById('me-st-promote').textContent = t.promote_count || 0;
    document.getElementById('me-st-invite').textContent = t.invite_count || 0;
    document.getElementById('me-st-valid').textContent = t.valid_count || 0;
    document.getElementById('me-st-reward').textContent = t.reward_total || 0;
    // 明细按渠道合并展示，每条都标出是哪条渠道来的
    const all = [];
    PROMOTE_KINDS.forEach(k => {
      const c = chs[k];
      if (!c || !c.allowed) return;
      (c.invites || []).forEach(i => all.push({ ...i, _label: c.label }));
    });
    all.sort((a, b) => (b.id || 0) - (a.id || 0));
    document.getElementById('me-promote-list').innerHTML = all.length
      ? '<div class="promote-sub">推广记录</div>' + all.slice(0, 30).map(i => `<div class="promote-item">
          <span class="pi-name">${esc(i.name || i.username || ('#' + i.invitee_id))}</span>
          <span class="pi-tag kind">${esc(i._label)}</span>
          <span class="pi-time">${esc((i.reg_at || i.created_at || '').slice(0, 16))}</span>
          <span class="pi-tag ${i.valid ? 'ok' : 'no'}">${i.valid ? '有效' : '不计有效'}</span>
        </div>`).join('')
      : '<p class="muted" style="font-size:13px;margin:12px 0 0">还没有人通过你的推广或邀请注册</p>';
    card.style.display = any ? '' : 'none';
  } catch (e) { card.style.display = 'none'; }
}
// kind 决定复制哪一条渠道 —— 两条渠道的码不同、展示形式也不同
function copyPromote(kind, what) {
  const el = document.getElementById(what === 'code' ? ('me-' + kind + '-code') : ('me-' + kind + '-link'));
  const txt = what === 'code' ? el.textContent.trim() : el.value.trim();
  const label = kind === 'invite' ? '邀请' : '推广';
  if (!txt || txt === '----' || txt === '—') { toast('还没有' + label + (what === 'code' ? '码' : '链接')); return; }
  const done = () => toast(label + (what === 'code' ? '码已复制' : '链接已复制'));
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(txt).then(done).catch(() => fallbackCopy(txt, done));
  } else { fallbackCopy(txt, done); }
}
function fallbackCopy(txt, done) {
  // 老 WebView / 非安全上下文没有 clipboard API，用 textarea + execCommand 兜底
  const ta = document.createElement('textarea');
  ta.value = txt; ta.style.position = 'fixed'; ta.style.opacity = '0';
  document.body.appendChild(ta); ta.select();
  try { document.execCommand('copy'); done(); } catch (e) { toast('复制失败，请长按手动复制'); }
  document.body.removeChild(ta);
}
async function regenPromote(kind) {
  const isInv = kind === 'invite';
  const label = isInv ? '邀请码' : '推广链接';
  if (!confirm('更换后，旧' + label + '立即失效，已经发出去的就作废了。继续？')) return;
  try {
    const r = await api('/api/promote/gen?kind=' + kind, { method: 'POST' });
    toast('已生成新' + label + (isInv ? ' ' + r.code : ''));
    loadPromote();
  } catch (e) { toast(e.message); }
}

// ---------- 认证 ----------
let authMode = 'login';
function switchAuth(m) {
  authMode = m;
  document.querySelectorAll('#view-auth .tabs .t').forEach(x => x.classList.toggle('active', x.dataset.mode === m));
  document.getElementById('auth-btn').textContent = m === 'login' ? '登录' : '注册';
  document.getElementById('reg-fields').style.display = m === 'register' ? '' : 'none';
  document.getElementById('forgot-link').style.display = m === 'login' ? '' : 'none';
  if (m === 'register') loadRegisterConfig();
}
async function doAuth() {
  const u = document.getElementById('auth-user').value.trim();
  const p = document.getElementById('auth-pass').value;
  const fd = new FormData(); fd.append('username', u); fd.append('password', p);
  if (authMode === 'register') {
    const p2 = document.getElementById('reg-pass2').value;
    const name = document.getElementById('reg-name').value.trim();
    const email = document.getElementById('reg-email').value.trim();
    const phone = document.getElementById('reg-phone').value.trim();
    if (p !== p2) { toast('两次输入的密码不一致'); return; }
    if (!name) { toast('请填写昵称'); return; }
    if (!document.getElementById('reg-terms').checked) { toast('请先阅读并勾选同意《用户须知与免责公告》'); return; }
    fd.append('name', name); fd.append('email', email); fd.append('phone', phone);
    fd.append('agree', '1');
    const inv = (document.getElementById('reg-invite').value || '').trim();
    if (inv) fd.append('invite', inv);
    // 指纹算出来是空的也要提交：服务端拿不到指纹会判「不计有效」，
    // 这是防刷口径要求的，不能因为算不出来就假装没这回事。
    fd.append('fp', await bmFingerprint());
  }
  try {
    const r = await api('/api/' + authMode, { method: 'POST', body: fd });
    if (r.pending) { toast(r.message || '注册成功，等待审核'); switchAuth('login'); return; }
    TOKEN = r.token; USER = r.user; GUEST = false;
    localStorage.setItem('bm_token', TOKEN); localStorage.setItem('bm_user', JSON.stringify(USER));
    enterMain();
  } catch (e) { toast(e.message); }
}
async function showTerms() {
  try {
    const r = await api('/api/terms');
    openModal(`<button class="close" onclick="closeModal()">✕</button><h3>用户须知与免责公告</h3>
      <div style="max-height:60vh;overflow-y:auto;white-space:pre-wrap;font-size:13px;line-height:1.8;color:#444;margin:10px 0">${esc(r.content)}</div>
      <button class="btn block" onclick="document.getElementById('reg-terms').checked=true;closeModal();toast('已同意，请继续注册')">我已阅读并同意</button>`);
  } catch (e) { toast(e.message); }
}
function showForgot() {
  openModal(`<button class="close" onclick="closeModal()">✕</button><h3>找回密码</h3>
    <p class="muted" style="font-size:13px">请输入注册时填写的用户名、邮箱与手机号，核验通过后可设置新密码。</p>
    <div class="form-group"><label>用户名</label><input id="fp-user"></div>
    <div class="form-group"><label>邮箱</label><input id="fp-email"></div>
    <div class="form-group"><label>手机号</label><input id="fp-phone"></div>
    <button class="btn block" onclick="doForgot()">下一步</button>`);
}
async function doForgot() {
  const fd = new FormData();
  fd.append('username', document.getElementById('fp-user').value.trim());
  fd.append('email', document.getElementById('fp-email').value.trim());
  fd.append('phone', document.getElementById('fp-phone').value.trim());
  try {
    const r = await api('/api/forgot-password', { method: 'POST', body: fd });
    openModal(`<button class="close" onclick="closeModal()">✕</button><h3>设置新密码</h3>
      <p class="muted" style="font-size:13px">身份核验通过，请设置新密码（${r.message || ''}）。</p>
      <div class="form-group"><label>新密码</label><input id="fp-new" type="password"></div>
      <button class="btn block" onclick="doReset('${esc(r.token)}')">重置密码</button>`);
  } catch (e) { toast(e.message); }
}
async function doReset(token) {
  const fd = new FormData();
  fd.append('token', token); fd.append('password', document.getElementById('fp-new').value);
  try {
    const r = await api('/api/reset-password', { method: 'POST', body: fd });
    toast(r.message || '密码已重置'); closeModal(); switchAuth('login');
  } catch (e) { toast(e.message); }
}
function logout(redirect = true) {
  if (GUEST) { requireLogin(); return; }
  msgNotifyStop();   // APP 里：撤掉通知和角标、停掉后台轮询，别再用旧令牌去查
  TOKEN = ''; USER = null;
  localStorage.removeItem('bm_token'); localStorage.removeItem('bm_user');
  if (redirect) location.reload();
}

// ---------- 游客模式 ----------
// 需要登录的功能：游客点击 → 提示注册并打开注册页
function requireLogin() {
  if (!GUEST) return true;
  toast('请注册账号后使用此功能');
  switchAuth('register');
  showAuthPage();
  document.getElementById('auth-guest-back').style.display = '';
  return false;
}
function showAuth() {   // 顶栏“登录 / 注册”按钮
  switchAuth('login');
  showAuthPage();
  document.getElementById('auth-guest-back').style.display = GUEST ? '' : 'none';
}
function guestBack() {  // 游客从登录页返回继续浏览
  document.getElementById('view-auth').classList.add('hidden');
  showView('main');
}

// ---------- 检查更新（仅 App 端显示）----------
// 注意：此版本号需与安卓工程 android/app/build.gradle 的 versionName 保持一致
const APP_VERSION = 'V3.0';

// 版本号比较：原来是字符串全等，格式差异（'2.3' vs 'V2.3'）会误判成有新版本。
// 归一化掉前导 v/V 后按数字段逐位比较；任一侧解析不出纯数字版本就返回 NaN，
// 由调用方退回字符串比较 —— 保持对 'V2.3-beta' 这类格式的旧行为。
function verNum(s) {
  const m = String(s == null ? '' : s).trim().replace(/^[vV]/, '').match(/^\d+(\.\d+)*$/);
  return m ? m[0].split('.').map(Number) : null;
}
function verCmp(a, b) {
  const x = verNum(a), y = verNum(b);
  if (!x || !y) return NaN;
  const n = Math.max(x.length, y.length);
  for (let i = 0; i < n; i++) {
    const d = (x[i] || 0) - (y[i] || 0);
    if (d) return d > 0 ? 1 : -1;
  }
  return 0;
}
async function downloadApp() {
  // 网页端：直接下载 APK 安装包。文件名取自 /update/version.json（带版本号），
  // 取不到时退回旧路径（服务端始终保留这个别名，老客户端才不会 404）
  const base = await getLinkBase();
  let url = new URL('/update/myreader.apk', base).href;
  try {
    const v = await (await fetch('/update/version.json', { cache: 'no-store' })).json();
    if (v && v.apk) url = new URL(v.apk, base).href;
  } catch (e) { /* 取清单失败就用别名路径 */ }
  toast('开始下载云阅读 App…');
  location.href = url;
}
function openSky() {
  // “我的”页「示例天空」入口：新标签打开外部站点（App 内由 WebView 交给系统处理）
  window.open('http://example.com', '_blank');
}
async function checkUpdate() {
  try {
    const r = await fetch('/update/version.json', { cache: 'no-store' });
    if (!r.ok) { toast('未检测到更新服务器（/update）'); return; }
    const v = await r.json().catch(() => null);
    if (!v || !v.version || !v.apk) { toast('更新信息格式异常'); return; }
    // App 端必须用 APK 自身的原生版本号判断（WebView 加载的页面代码始终是最新的，
    // 写死的前端常量会导致旧版 APK 误报"已是最新"）；网页端回退到前端常量
    let cur = APP_VERSION;
    try {
      const AppP = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App;
      if (AppP && AppP.getInfo) {
        const info = await AppP.getInfo();
        if (info && info.version) cur = info.version;
      }
    } catch (e) {}
    const cmp = verCmp(v.version, cur);
    // cmp === 0：一致；NaN：格式无法比较，退回字符串比较
    if (cmp === 0 || (Number.isNaN(cmp) && String(v.version) === String(cur))) {
      toast('已是最新版本 ' + cur); return;
    }
    // 当前装的比服务器上的还新（例如内测包），不要提示「降级」
    if (cmp === -1) { toast('已是最新版本 ' + cur); return; }
    const note = v.note ? '\n\n更新内容：\n' + v.note : '';
    if (!confirm('发现新版本 ' + v.version + note + '\n\n是否立即下载安装？')) return;
    const url = new URL(v.apk, await getLinkBase()).href;
    const fname = url.split('/').pop().split('?')[0] || 'myreader.apk';
    const AppU = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.AppUpdate;
    // ★ 为什么必须先问插件版本：V3.0 及更早的 AppUpdate 插件把下载目标写死成了
    //   Downloads/myreader-update.apk。而系统下载器遇到同名文件会另存为 -1/-2，
    //   插件却仍按那个固定路径去装，结果装到上一次留下的残包 → 安装器报
    //   「解析包时出现问题」，且每次重试都这样，永远升不上来。
    //   协议号 >= 2 的插件才会先删旧文件、装真正的下载结果。老插件拿不到版本号，
    //   直接走浏览器下载（点通知安装的一定是刚下好的这个包），绕开这个坑。
    let nativeOk = false;
    if (AppU && AppU.version) {
      try {
        const r = await AppU.version();
        nativeOk = !!(r && Number(r.version) >= 2);
      } catch (e) { nativeOk = false; }
    }
    if (nativeOk) {
      toast('开始下载更新…');
      try { await AppU.downloadAndInstall({ url: url, filename: fname }); }
      catch (e) { toast('下载失败：' + (e.message || e)); }
    } else {
      // 网页端 / 旧插件：交给浏览器（App 内由 WebView 的 DownloadListener 交给系统下载器）
      toast('开始下载 ' + fname + '，下载完成后点通知安装');
      location.href = url;
    }
  } catch (e) { toast('检查更新失败：' + (e.message || e)); }
}

// ---------- 视图切换 ----------
function can(perm) { return USER.role === 'admin' || (USER.permissions && USER.permissions[perm]); }
// 免审批身份：管理员 / 总编。发布书单、共享书籍等对这些人直接通过，
// 所以相关提示文案不能再写死「需管理员审核」。判据以后端 auth.is_trusted 为准。
function isTrusted() { return !!(USER && USER.trusted); }
async function enterMain() {
  // 游客模式：不需要登录凭证也能浏览（书库只会返回范例图书）；媒体凭证游客也可换取
  await ensureMediaTicket();   // 先换媒体凭证，保证封面 URL 不带登录令牌
  if (!GUEST) {
    // 刷新用户信息：localStorage 里的缓存可能过期（如后来才补充的昵称），
    // 不刷新会导致 App 端与网页端显示的昵称不一致（App 长期不重登时尤甚）
    try {
      USER = await api('/api/me');
      localStorage.setItem('bm_user', JSON.stringify(USER));
    } catch (e) {}
  }
  document.getElementById('view-auth').classList.add('hidden');
  showView('main');
  const navAuth = document.getElementById('nav-auth');
  const navSignin = document.getElementById('nav-signin');
  if (GUEST) {
    navAuth.style.display = '';
    if (navSignin) navSignin.style.display = 'none';   // 游客不显示签到
    document.getElementById('guest-banner').style.display = '';
  } else {
    navAuth.style.display = 'none';
    if (navSignin) navSignin.style.display = '';       // 登录用户：右上角显示「签到」
    document.getElementById('guest-banner').style.display = 'none';
  }
  const ini = (GUEST ? '游' : (USER.username || 'U')[0].toUpperCase());
  document.getElementById('me-avatar').textContent = ini;
  document.getElementById('me-avatar').style.backgroundImage = '';
  document.getElementById('me-name').textContent = USER.username;
  const g = USER.group || {};
  renderMeRole();
  const _contact = [USER.email, USER.phone].filter(Boolean).join(' · ');
  const _contactEl = document.getElementById('me-contact');
  _contactEl.textContent = _contact;
  _contactEl.style.display = _contact ? '' : 'none';   // 昵称已并入树叶行，无邮箱/手机号时隐藏该行
  renderMeLimits();
  document.getElementById('nav-upload').style.display = (GUEST || can('private_shelf')) ? '' : 'none';
  renderPerms();
  loadCategories(); loadAds();
  loadSigninStatus();
  startMsgPoll();   // 未读消息红点（登录用户）
  msgNotifyStart();  // APP 里：把令牌交给原生，之后新消息弹系统通知 + 桌面角标
  loadGroupExchange();   // 升级权限（树叶兑换分组）
  route();
}
function loadAds() {
  const row = document.getElementById('ad-row');
  if (!row) return;
  api('/api/ads').then(r => {
    const a1 = (r.ad1 || '').trim(), a2 = (r.ad2 || '').trim();
    document.getElementById('ad-slot-1').innerHTML = a1;
    document.getElementById('ad-slot-2').innerHTML = a2;
    row.style.display = (a1 || a2) ? '' : 'none';
  }).catch(() => {});
}
function renderPerms() {
  const names = { share: '分享图书', edit: '编辑信息', cover: '上传封面', download: '下载图书', delete: '删除书籍', private_shelf: '私人书架（上传书籍）', convert: '格式转换' };
  document.getElementById('me-perms').innerHTML = Object.keys(names).map(p => {
    const on = can(p);
    return `<div class="perm-item ${on ? 'on' : 'off'}">${on ? '✓' : '✕'} ${names[p]}</div>`;
  }).join('');
}
function renderMeRole() {
  const g = (USER && USER.group) || {};
  const el = document.getElementById('me-role');
  if (el) el.textContent = '身份：' + (g.name || (USER.role === 'admin' ? '管理员' : '普通用户'));
  const ad = document.getElementById('me-admin');
  if (ad) ad.style.display = USER.role === 'admin' ? '' : 'none';
  const up = document.getElementById('nav-upload');
  if (up) up.style.display = (GUEST || can('private_shelf')) ? '' : 'none';
}

function renderMeLimits() {
  const lim = (USER && USER.limits) || {};
  const perm = (USER && USER.permissions) || {};
  const limParts = [];
  if (perm.share && lim.share_max_days > 0) limParts.push('分享时限 ' + lim.share_max_days + ' 天');
  if (perm.share && lim.share_max_links > 0) limParts.push('分享链接 ' + lim.share_max_links + ' 个');
  if (perm.download && lim.download_monthly_limit > 0) limParts.push('下载 ' + lim.download_monthly_limit + ' 本/月');
  if (perm.private_shelf && lim.shelf_limit > 0) limParts.push('私人书架 ' + lim.shelf_limit + ' 本');
  if (perm.convert && lim.convert_daily_limit > 0) limParts.push('转换 ' + lim.convert_daily_limit + ' 本/天');
  if (perm.private_shelf && lim.upload_max_mb > 0) limParts.push('单本上传 ≤ ' + lim.upload_max_mb + ' MB');
  // 免费听书额度：只在**没有** listen 权限时才有意义（勾了就是不限量不扣树叶），
  // 而且这个额度是「30 天内 N 本」，不是自然月 —— 必须写明天数，否则用户会按自然月理解。
  if (!perm.listen && lim.listen_monthly_limit > 0) {
    limParts.push('免费听书 ' + lim.listen_monthly_limit + ' 本/30 天');
  }
  const el = document.getElementById('me-limits');
  if (el) el.textContent = limParts.length ? '分组限额：' + limParts.join(' · ') : '';
}

// ---------- 升级权限（树叶兑换分组，有效期 1 个月） ----------
// 权限/限额标签（仅用于展示文案，取值全部来自后台分组设置）
const PERM_LABELS = [
  ['share', '分享图书'], ['edit', '编辑信息'], ['cover', '上传封面'],
  ['download', '下载图书'], ['delete', '删除书籍'], ['private_shelf', '私人书架'],
  ['convert', '格式转换'], ['public_library', '公共书库'], ['publish_booklist', '书单发表'],
];
const LIMIT_LABELS = [
  ['share_max_days', '分享时限', ' 天'], ['share_max_links', '分享链接', ' 个'],
  ['download_monthly_limit', '下载', ' 本/月'], ['shelf_limit', '私人书架', ' 本'],
  ['convert_daily_limit', '转换', ' 本/天'],
];
let upgradeData = null, _upgradeOpen = false;
async function loadGroupExchange() {
  const bal = document.getElementById('me-upgrade-bal');
  if (!bal) return;
  if (GUEST) {
    bal.textContent = '';
    document.getElementById('me-upgrade-status').innerHTML = '';
    document.getElementById('me-upgrade-btn').style.display = 'none';
    return;
  }
  try {
    upgradeData = await api('/api/group-exchange');
    renderUpgrade();
  } catch (e) {
    bal.textContent = '';
    document.getElementById('me-upgrade-btn').style.display = 'none';
  }
}
function upgradeOptionsHtml() {
  const d = upgradeData || { options: [], balance: 0, my_perms: {} };
  const up = d.upgrade, opts = d.options || [];
  if (!opts.length) return '<p class="muted" style="margin:0">管理员暂未开放可兑换的分组</p>';
  const mine = d.my_perms || {};
  return opts.map(o => {
    const same = up && up.group_id === o.id;
    const canBuy = o.affordable && (!o.current || same);
    const label = same ? '续期 1 个月' : (o.current ? '当前分组' : '兑换');
    // 权限说明：按后台该分组的实际设置逐项渲染
    const perms = o.perms || {};
    const chips = PERM_LABELS.map(([k, name]) => {
      const on = !!perms[k];
      const gained = on && !mine[k];
      return `<span class="ug-perm ${on ? 'on' : 'off'}${gained ? ' gained' : ''}">${on ? '✓' : '✕'} ${name}${gained ? '<i>新增</i>' : ''}</span>`;
    }).join('');
    // 限额说明：0 表示不限
    const lim = o.limits || {};
    const limParts = LIMIT_LABELS.map(([k, name, unit]) => `${name} ${lim[k] > 0 ? lim[k] + unit : '不限'}`);
    return `<div class="upgrade-item${o.current ? ' current' : ''}">
      <div class="ug-top">
        <div class="ug-info">
          <div class="ug-name">${esc(o.name)}${o.current ? ' <span class="badge ok">当前</span>' : ''}</div>
          <div class="ug-cost">${o.cost} 树叶 / ${o.months || 1} 个月${same ? '，续期可叠加' : ''}</div>
        </div>
        <button class="btn sm" ${canBuy ? '' : 'disabled'}
          onclick="doExchange(${o.id}, '${esc(o.name)}', ${o.cost})">${esc(label)}</button>
      </div>
      <div class="ug-perms">${chips}</div>
      <div class="ug-limits">限额：${limParts.join(' · ')}</div>
    </div>`;
  }).join('');
}
function renderUpgrade() {
  const d = upgradeData || { options: [], balance: 0 };
  const bal = document.getElementById('me-upgrade-bal');
  const btn = document.getElementById('me-upgrade-btn');
  const up = d.upgrade;
  const opts = d.options || [];
  if (bal) bal.textContent = '树叶 ' + (d.balance || 0);
  // 无可兑换分组时隐藏入口
  if (btn) btn.style.display = opts.length ? '' : 'none';
  const status = document.getElementById('me-upgrade-status');
  if (status) {
    status.innerHTML = up
      ? `<div class="upgrade-active">已升级为「<b>${esc(up.group_name)}</b>」，有效期至 <b>${esc((up.expires_at || '').slice(0, 16))}</b>（剩余 ${up.days_left} 天），到期后自动回退原分组。</div>`
      : '';
  }
  if (_upgradeOpen) {
    const list = document.getElementById('upgrade-modal-list');
    if (list) list.innerHTML = upgradeOptionsHtml();
  }
}
function showUpgradePanel() {
  _upgradeOpen = true;
  const bal = (upgradeData && upgradeData.balance) || 0;
  openModal(`<button class="close" onclick="closeUpgradePanel()">✕</button>
    <h3>升级权限</h3>
    <p class="muted" style="margin:-10px 0 14px;font-size:13px">
      用树叶兑换更高权限分组，有效期 1 个月，到期后自动回退到原分组。当前树叶：<b>${bal}</b></p>
    <div id="upgrade-modal-list">${upgradeOptionsHtml()}</div>`);
}
function closeUpgradePanel() { _upgradeOpen = false; closeModal(); }
// 注：这里曾经存在两份逐字节相同的 doExchange（缓冲式重构的残留），
// 后一份覆盖前一份。已删除重复定义，只保留下面这一份。
async function doExchange(groupId, name, cost) {
  if (!confirm(`确认用 ${cost} 树叶兑换「${name}」权限？有效期 1 个月，到期后自动回退原分组。`)) return;
  try {
    const r = await api('/api/group-exchange', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ group_id: groupId }) });
    toast(r.message || '兑换成功');
    upgradeData = await api('/api/group-exchange');
    renderUpgrade();
    loadSigninStatus();          // 树叶余额已变化
    try { USER = await api('/api/me'); localStorage.setItem('bm_user', JSON.stringify(USER)); } catch (e) {}
    renderPerms(); renderMeRole(); renderMeLimits(); renderMeLeaves();
  } catch (e) { toast(e.message); }
}
// ---------- 视图切换统一收口 ----------
// 以前每个 openXxxView 各自手写一串 classList.add/remove，漏掉一处就会出现
// 「两个视图同时可见」——而 .main-shell 有 min-height:100vh，会把排在后面的
// 详情/文章视图整个挤出首屏（用户看到的就是白屏）。所以统一走 showView()。
const MAIN_VIEWS = ['main', 'detail', 'booklist', 'write', 'intro', 'audio', 'audioplay'];
function showView(name) {
  MAIN_VIEWS.forEach(v => {
    const el = document.getElementById('view-' + v);
    if (el) el.classList.toggle('hidden', v !== name);
  });
  // 底部导航：主页面和图书/文章详情都显示；发表文章、功能介绍属任务页，隐藏避免误触。
  setTabbar(name === 'main' || name === 'detail' || name === 'booklist' || name === 'audio');
  // 离开有声播放页就松开「屏幕常亮」（keepawake.js）—— 后台继续放着音时，
  // 屏幕不该一直亮着。原生那个标志必须主动清，浏览器那一把会自动释放。
  if (name !== 'audioplay' && typeof keepAwake === 'function') keepAwake(false);
}
function setTabbar(on) {
  const t = document.getElementById('tabbar');
  if (!t) return;
  // 置空串是为了恢复样式表规则：桌面端媒体查询本身把 .tabbar 设为 display:none，
  // 只有窄屏才 flex。这里写死 display:flex 会让桌面端也冒出来。
  t.style.display = on ? '' : 'none';
}
function showAuthPage() {
  setTabbar(false);   // 登录页是 fixed 全屏覆盖，底部导航压在下面容易误触
  document.getElementById('view-auth').classList.remove('hidden');
}
// 显式导航标记：点 Tab/链接进入（应重置搜索）；返回/关闭详情（保留搜索状态）
let _explicitNav = false, _prevSeg = '', _prevHash = '';
// 有声详情页「← 返回」该回哪儿：从「图书详情」点「有声阅读」进来就回那本书，
// 从有声列表点卡片进来就回列表。由 route() 判定（见那里的说明），closeAudio() 消费。
let audioBackTo = '';
function switchPage(p) {
  const target = '#/' + p;
  if (location.hash !== target) { _explicitNav = true; location.hash = target; }
  else if (p === 'library') goHome();
  else switchPageView(p);
}
function switchPageView(p) {
  if (!['library', 'shelf', 'booklists', 'me', 'notes', 'audio'].includes(p)) p = 'library';
  lastPage = p;
  lastHash = '#/' + p;
  document.querySelectorAll('.tabbar .tab, .nav-links a').forEach(x => x.classList.toggle('active', x.dataset.page === p));
  ['library', 'shelf', 'booklists', 'me', 'notes', 'audio'].forEach(x => document.getElementById('page-' + x).classList.toggle('hidden', x !== p));
  showView('main');
  if (p === 'library') document.getElementById('library-title').textContent = GUEST ? '访客模式' : '我的阅览';
  if (p === 'shelf') { loadShelf(); auShelfLoad(); }
  if (p === 'me') { renderMeCats(); loadMessages(1); loadMyShares(); loadMyReading(); loadMyArticles(); loadSigninStatus(); loadGroupExchange(); loadPromote(); }
  if (p === 'notes') loadNotes();
  if (p === 'booklists') loadBooklists();
  if (p === 'audio') loadAudio();
}
// ---------- 每日签到（树叶） ----------
async function loadSigninStatus() {
  if (GUEST) { SIGNIN = null; renderMeLeaves(); return; }
  try { SIGNIN = await api('/api/signin/status'); } catch (e) { SIGNIN = null; }
  renderMeLeaves();
}
function renderMeLeaves() {
  const el = document.getElementById('me-leaves');
  if (!el) return;
  const nm = (USER && USER.name) ? USER.name : (USER ? USER.username : '');
  el.textContent = nm + '\u00A0\u00A0树叶：' + (SIGNIN ? SIGNIN.balance : 0) + '🌿';
}
// 签到提示文案：今天可得多少、还差几天拿连续奖励
function signinTip() {
  const s = SIGNIN;
  if (!s) return '';
  const every = s.bonus_every || 7, amt = s.bonus_amount || 7;
  if (s.signed_today) {
    const left = every - (s.streak % every);
    return left === every
      ? '已连续签到 ' + s.streak + ' 天，再签 ' + every + ' 天可得 +' + amt + '🌿'
      : '已连续签到 ' + s.streak + ' 天，再签 ' + left + ' 天可得 +' + amt + '🌿';
  }
  const will = (s.streak || 0) + 1;
  if (will % every === 0) return '今天签到可得 +1🌿，并达成连续 ' + will + ' 天额外 +' + amt + '🌿';
  return s.streak > 0
    ? '今天签到可得 +1🌿，已连续 ' + s.streak + ' 天'
    : '今天签到可得 +1🌿';
}
async function showSignin() {
  if (!requireLogin()) return;
  try { SIGNIN = await api('/api/signin/status'); } catch (e) {}
  renderMeLeaves();
  const s = SIGNIN || { signed_today: false, streak: 0, balance: 0 };
  const btn = s.signed_today
    ? '<button class="btn block" id="signin-btn" disabled style="opacity:.55">今日已签到</button>'
    : '<button class="btn block" id="signin-btn" onclick="doSignin()">立即签到</button>';
  openModal(`
    <button class="close" onclick="closeModal()">✕</button>
    <h3>每日签到</h3>
    <div class="signin-box">
      <div class="signin-leaves" id="signin-leaves">${s.balance}<span>🌿</span></div>
      <p class="signin-streak">连续签到 <b>${s.streak}</b> 天</p>
      <p class="signin-tip">${signinTip()}</p>
    </div>
    <div id="signin-status" class="signin-status"></div>
    ${btn}`);
}
async function doSignin() {
  const st = document.getElementById('signin-status');
  const btn = document.getElementById('signin-btn');
  if (btn) { btn.disabled = true; btn.textContent = '签到中…'; }
  try {
    const r = await api('/api/signin', { method: 'POST' });
    const total = r.leaves + r.bonus;
    const extra = r.bonus ? '（连续 ' + r.streak + ' 天额外 +' + r.bonus + '🌿）' : '';
    if (st) st.innerHTML = '<span class="signin-ok">签到成功，获得 +' + total + '🌿' + extra + '</span>';
    if (btn) { btn.textContent = '今日已签到'; btn.disabled = true; btn.style.opacity = '.55'; }
    SIGNIN = await api('/api/signin/status');
    renderMeLeaves();
    const lv = document.getElementById('signin-leaves');
    if (lv) lv.innerHTML = SIGNIN.balance + '<span>🌿</span>';
    const tip = document.querySelector('.signin-tip');
    if (tip) tip.textContent = signinTip();
    const streakEl = document.querySelector('.signin-streak');
    if (streakEl) streakEl.innerHTML = '连续签到 <b>' + SIGNIN.streak + '</b> 天';
    toast('签到成功 +' + total + '🌿');
  } catch (e) {
    if (st) st.textContent = e.message;
    if (btn) { btn.disabled = false; btn.textContent = '立即签到'; }
  }
}

// ---------- 我的阅读（最近100本 · 按时间从晚到早 · 每页16本 = 2行×8本） ----------
let meReadingBooks = [], meReadingPage = 1;
async function loadMyReading() {
  if (GUEST) {
    meReadingBooks = []; meReadingPage = 1;
    renderMyReading();
    return;
  }
  try {
    const r = await api('/api/me/reading-history');
    meReadingBooks = r.items || [];
    meReadingPage = 1;
    renderMyReading();
  } catch (e) {}
}
function renderMyReading() {
  const grid = document.getElementById('me-reading-grid');
  const total = meReadingBooks.length;
  // 桌面端每页 16 本，移动端 / App 每页 9 本
  const pageSize = window.innerWidth >= 901 ? 16 : 9;
  const pages = Math.max(1, Math.min(10, Math.ceil(total / pageSize)));
  if (meReadingPage > pages) meReadingPage = pages;
  if (!total) { grid.innerHTML = '<div class="empty" style="grid-column:1/-1">暂无阅读记录</div>'; document.getElementById('me-reading-pager').innerHTML = ''; return; }
  const slice = meReadingBooks.slice((meReadingPage - 1) * pageSize, meReadingPage * pageSize);
  grid.innerHTML = slice.map(b => {
    const cover = b.cover_url ? `<img class="cover" src="${esc(coverUrl(b.cover_url, b.updated_at))}" loading="lazy" onerror="this.replaceWith(placeholderCover(this))">` : placeholderCoverHTML(b);
    return `<div class="book-card" onclick="openDetail(${b.id})">${cover}<div class="info"><div class="t">${esc(b.title)}</div><div class="a">${esc(b.author || '')}</div></div></div>`;
  }).join('');
  const pager = document.getElementById('me-reading-pager');
  if (pages <= 1) { pager.innerHTML = ''; return; }
  pager.innerHTML = `<button onclick="goMyReading(${meReadingPage - 1})" ${meReadingPage <= 1 ? 'disabled' : ''}>‹</button>
    <span style="display:inline-flex;align-items:center;gap:6px;font-size:14px;color:var(--muted)">第
      <input id="mr-pager-input" type="number" min="1" max="${pages}" value="${meReadingPage}" style="width:40px;padding:6px 4px;border:1.5px solid var(--line);border-radius:8px;text-align:center;font-size:14px" onkeydown="if(event.key==='Enter')jumpMyReading()">
      / ${pages} 页</span>
    <button class="btn sm" onclick="jumpMyReading()">跳转</button>
    <button onclick="goMyReading(${meReadingPage + 1})" ${meReadingPage >= pages ? 'disabled' : ''}>›</button>`;
}
function goMyReading(p) { meReadingPage = Math.max(1, Math.min(10, p)); renderMyReading(); }
function jumpMyReading() {
  const inp = document.getElementById('mr-pager-input');
  let n = parseInt(inp && inp.value, 10);
  if (!n || n < 1) n = 1;
  goMyReading(n);
}
// 回到首页：清空筛选状态并重载默认（最近阅读 + 书架收藏）
function goHome() {
  curCategory = ''; curQ = ''; curAuthor = ''; curPage = 1;
  const sq = document.getElementById('search-q'); if (sq) sq.value = '';
  const sc = document.getElementById('search-clear'); if (sc) sc.style.display = 'none';
  document.getElementById('category-banner').style.display = 'none';
  document.getElementById('author-banner').style.display = 'none';
  switchPageView('library');
  loadBooks();
}

// ---------- 系统返回键：返回上一级（层级返回） ----------
// 与浏览器「后退」的区别：后退会回到上一个访问过的 URL，可能是完全不相干的页面
// （比如从详情进了阅读器，后退可能落到更早看过的某本书详情）。
// 这里改成沿着「首页 → 列表 → 详情 → 阅读/听书」这条层级往上走，
// 和界面上那些「← 返回」按钮走的是同一套逻辑。
function currentMainPage() {
  for (const p of ['library', 'shelf', 'booklists', 'me', 'notes']) {
    const el = document.getElementById('page-' + p);
    if (el && !el.classList.contains('hidden')) return p;
  }
  return 'library';
}

// 返回 true 表示已处理；false 表示已在最外层（由调用方决定退出）
function appBack() {
  if (typeof closeModal === 'function') {                       // 1) 弹窗优先关闭
    const mask = document.getElementById('modal-mask');
    if (mask && !mask.classList.contains('hidden')) { closeModal(); return true; }
  }
  if (typeof closeSheets === 'function' &&
      document.querySelector('.l-sheet.show, .l-mask.show')) {   // 听书面板
    closeSheets(); return true;
  }
  const vis = id => {                                           // 2) 登录页 → 回上一页
    const el = document.getElementById(id);
    return el && !el.classList.contains('hidden');
  };
  if (vis('view-auth')) { guestBack(); return true; }
  // ★ 有声播放页 / 有声详情页：以前这里**没有**这两个分支，按硬件返回键会因为
  //   currentMainPage() 仍看到 page-library 而一路走到最后 return false —— 直接退出 App。
  //   有声页面自带导航栏「← 返回」，但手机上大家习惯按返回键，按一下就退出应用太糙了。
  //   顺序上先播放页（它叠在详情之上），且这两个视图由 showView 互斥，不会同时可见。
  if (vis('view-audioplay')) { closeAudioPlay(); return true; }
  if (vis('view-audio')) { closeAudio(); return true; }        // 会按 audioBackTo 回到来处
  if (vis('view-detail')) { closeDetail(); return true; }        // 3) 子视图 → 上一级
  if (vis('view-booklist')) { closeBooklist(); return true; }
  if (vis('view-write')) { closeWrite(); return true; }
  if (vis('view-intro')) { closeIntro(); return true; }
  // 4) 首页里的下钻（分类 / 搜索 / 作者）→ 回到全部图书。
  //    必须先清筛选再改 hash：route() 里 fromDetail 为真时只会切视图不会清条件，
  //    直接改 hash 会把刚离开的分类又加载回来。
  if (curCategory || curQ || curAuthor) {
    curCategory = ''; curQ = ''; curAuthor = ''; curPage = 1;
    const sq = document.getElementById('search-q'); if (sq) sq.value = '';
    const sc = document.getElementById('search-clear'); if (sc) sc.style.display = 'none';
    document.getElementById('category-banner').style.display = 'none';
    document.getElementById('author-banner').style.display = 'none';
    if (location.hash !== '#/library') { _explicitNav = true; location.hash = '#/library'; }
    else { switchPageView('library'); loadBooks(); }
    return true;
  }
  // 5) 其它 Tab → 回首页
  if (currentMainPage() !== 'library') { switchPage('library'); return true; }
  return false;                                                 // 6) 已在首页根
}

// ---------- 路由（刷新/前进后退保持当前页） ----------
function route() {
  const raw = decodeURIComponent((location.hash || '').replace(/^#\/?/, ''));
  const parts = raw.split('/');
  const seg = parts[0], val = parts.slice(1).join('/');
  const prev = _prevSeg;   // ★ 先留一份：下面几处判断用的都是「上一跳」而不是当前段
  const prevHash = _prevHash;   // 上一跳的**完整**哈希（判断「从哪本书进来」要用到 id）
  // 从详情/作者/分类/搜索视图返回 → 保留书库当前的搜索结果与页码，不重置
  const fromDetail = (prev === 'book' || prev === 'author' || prev === 'category' || prev === 'search');
  const explicit = _explicitNav;
  _explicitNav = false;
  _prevSeg = seg;
  _prevHash = location.hash;
  if (seg === 'book' && val) { openDetailView(parseInt(val)); return; }
  if (seg === 'booklist' && val) { openBooklistView(parseInt(val)); return; }
  if (seg === 'audio' && val) {
    // ★ 有声详情页的「← 返回」回哪儿：从「图书详情」点「有声阅读」进来就回那本书的详情，
    //   从有声列表点卡片进来就回列表。按「上一跳是不是 #/book/N」判定。
    //   放在路由里而不是按钮里，是因为这样**直接打开链接、浏览器前进后退**也都对。
    //   （原来有个 AU_FROM 变量声明了却从没被读过，返回永远跳有声列表 ——
    //     从某本书点进来的人会莫名其妙：我明明是从那本书进来的。）
    audioBackTo = /^#\/book\/\d+$/.test(prevHash || '') ? prevHash : '#/audio';
    openAudioView(parseInt(val)); return;
  }
  if (seg === 'write') { openWriteView(); return; }
  if (seg === 'edit' && val) { openEditView(parseInt(val)); return; }
  if (seg === 'intro') { openIntroView(); return; }
  if (seg === 'author' && val) { showAuthorView(val); return; }
  if (seg === 'category') { pickCategoryView(val || ''); return; }
  if (seg === 'search') { searchView(val); return; }   // 搜索结果的固定链接
  if (seg === 'categories') { location.hash = '#/shelf'; return; }   // 旧书库入口已并入书架
  if (seg === 'library' || !seg) {
    // 从搜索页直接回书库 = 用户清空了搜索，要真的回到默认首页（否则 curQ 还在，
    // loadBooks 又把搜索结果画回来，地址栏和内容对不上）
    if (explicit || !fromDetail || prev === 'search') goHome();
    else { switchPageView('library'); loadBooks(); }   // 返回搜索结果页：保留筛选并重载数据（防止页面重载后首页空白）
    return;
  }
  switchPageView(seg);
}
window.addEventListener('hashchange', route);

// 从浏览器 bfcache（后退/前进缓存）恢复页面时，视图与数据停在旧快照，
// 可能导致"从阅读器/详情页返回主页显示空白"。这里重新同步视图并刷新数据。
window.addEventListener('pageshow', (e) => {
  if (!e.persisted) return;   // 仅处理 bfcache 恢复；正常加载由 enterMain 负责
  // 这里绝不能先把 view-main 显示出来：App 里从阅读器返回详情页时，
  // 路由指向的是 #/book/N，而 .main-shell(min-height:100vh) 一旦显示
  // 就会把详情视图整个推到首屏之外 —— 看起来就是「返回详情页一片空白」。
  // 该显示哪个视图交给下面的 switchPageView()/route() 决定。
  document.getElementById('view-auth').classList.add('hidden');
  const _raw = decodeURIComponent((location.hash || '').replace(/^#\/?/, ''));
  const seg = _raw.split('/')[0];
  if (seg === 'search') {
    searchView(_raw.split('/').slice(1).join('/'));   // bfcache 回到搜索结果页
  } else if (seg === 'library' || !seg) {
    switchPageView('library');
    loadBooks();   // 保留 curQ/curCategory/curAuthor 筛选状态重载首页
  } else if (seg === 'shelf') switchPageView('shelf');
  else if (seg === 'me') switchPageView('me');
  else if (seg === 'notes') switchPageView('notes');
  else if (seg === 'booklists') switchPageView('booklists');
  else route();   // book/author/category 等详情视图走正常路由
});

// ---------- 分类 ----------
const CAT_STYLE = [
  { icon: '📖', color: '#4f46e5' }, { icon: '🕊️', color: '#0ea5e9' }, { icon: '🧠', color: '#8b5cf6' },
  { icon: '⚖️', color: '#16a34a' }, { icon: '🎖️', color: '#dc2626' }, { icon: '💰', color: '#f59e0b' },
  { icon: '🎓', color: '#06b6d4' }, { icon: '🗣️', color: '#ec4899' }, { icon: '🎨', color: '#f43f5e' },
  { icon: '⚔️', color: '#64748b' }, { icon: '🗺️', color: '#14b8a6' }, { icon: '🔬', color: '#3b82f6' },
  { icon: '🌿', color: '#22c55e' }, { icon: '📐', color: '#a855f7' }, { icon: '🚀', color: '#eab308' },
  { icon: '⚕️', color: '#ef4444' }, { icon: '🌾', color: '#84cc16' }, { icon: '🛠️', color: '#78716c' },
  { icon: '✈️', color: '#0ea5e9' }, { icon: '🔭', color: '#6366f1' }, { icon: '📚', color: '#b45309' },
  { icon: '🗃️', color: '#9ca3af' }
];
function catLabel(name) { return (name || '').replace(/^[A-Z0-9]+_/, ''); }
function catLetter(name) { return (name || '').split('_')[0]; }
function catStyle(name) {
  const code = (catLetter(name) || '').charCodeAt(0) || 0;
  return CAT_STYLE[code % CAT_STYLE.length];
}
async function loadCategories() {
  cats = await api('/api/categories');
  renderMeCats();   // ★ 「我的」页里的书库分类（文本链接）跟这里共用同一份数据
  // 分类页（彩色卡片）
  // ★ 侧栏已由「公共书库」换成「有声阅读」，#cat-list 不再存在；
  //   不判空的话每次启动都会在 null.innerHTML 上抛异常，把后面的初始化全带停。
  const cw = document.getElementById('cat-list');
  if (!cw) return;
  cw.innerHTML = cats.map(c => {
    const st = catStyle(c.name);
    const gb = ((c.size || 0) / 1e9).toFixed(1);
    const code = catLetter(c.name) === '00' ? '待分类' : 'CLC ' + catLetter(c.name);
    return `<div class="cat-card" onclick="pickCategoryFromCard('${esc(c.name)}')">
      <div class="bar" style="background:${st.color}"></div>
      <div class="cname">${esc(catLabel(c.name))}</div>
      <div class="ccode">${esc(code)}</div>
      <div class="ccount">${c.count} 本 · ${gb} GB</div>
    </div>`;
  }).join('');
}
// 「我的」→「书库分类」：纯文本链接，只显示分类名与书籍数量。
// ★ 点击传**下标**而不是把分类名拼进 onclick：分类名里有「·」之类的字符，
//   拼引号一旦遇到单引号就会把 onclick 拼坏。下标再由 cats 取名字最稳。
function renderMeCats() {
  const el = document.getElementById('me-cats-list');
  if (!el) return;
  const list = cats || [];
  const total = list.reduce((a, c) => a + (Number(c.count) || 0), 0);
  let h = '<a class="me-cat-link" onclick="pickMeCat(-1)">全部' +
          '<span class="me-cat-n">' + total + '</span></a>';
  h += list.map((c, i) =>
    '<a class="me-cat-link" onclick="pickMeCat(' + i + ')">' + esc(catLabel(c.name)) +
    '<span class="me-cat-n">' + (Number(c.count) || 0) + '</span></a>').join('');
  el.innerHTML = h || '<span class="muted">暂无分类</span>';
}
function pickMeCat(i) {
  if (i < 0) { pickCategory(''); return; }
  const c = (cats || [])[i];
  if (c) pickCategory(c.name);
}
function pickCategory(c) {
  const target = c ? '#/category/' + encodeURIComponent(c) : '#/library';
  if (location.hash !== target) location.hash = target;
  else pickCategoryView(c);
}
function pickCategoryView(c) {
  curCategory = c; curQ = ''; curAuthor = ''; curPage = 1;
  document.getElementById('search-q').value = '';
  document.getElementById('author-banner').style.display = 'none';
  const cb = document.getElementById('category-banner');
  if (cb) { cb.style.display = c ? '' : 'none'; if (c) document.getElementById('category-banner-name').textContent = catLabel(c); }
  switchPageView('library');
  if (c) {
    lastHash = '#/category/' + encodeURIComponent(c);
    document.getElementById('library-title').textContent = '公共书库';
  }
  loadCategories(); loadBooks();
}
function clearCategory() {
  if (location.hash.startsWith('#/category')) location.hash = '#/shelf';
  else pickCategoryView('');
}
function pickCategoryFromCard(c) { pickCategory(c); }

// ---------- 书籍列表 ----------
// ★ 搜索结果配了固定链接（#/search/关键字）。两个好处：
//   1) 从结果里点进详情、再点「返回」，能**精确**回到这次搜索 ——
//      closeDetail() 走的就是 lastHash，而 lastHash 现在指向 #/search/...；
//   2) 链接可以直接分享/收藏，刷新或从别处跳回来都不丢搜索条件。
//   原来 search() 只改内存里的 curQ、不动 hash，返回时全靠全局状态碰运气：
//   同一会话内凑合能用，一刷新或走 bfcache 回来搜索条件就没了。
function search() {
  if (!requireLogin()) return;
  const q = document.getElementById('search-q').value.trim();
  if (!q) { clearSearch(); return; }
  const target = '#/search/' + encodeURIComponent(q);
  if (location.hash !== target) location.hash = target;
  else searchView(q);
}
function searchView(q) {
  q = (q || '').trim();
  if (!q) { goHome(); return; }
  curQ = q; curAuthor = ''; curPage = 1;
  const sq = document.getElementById('search-q'); if (sq) sq.value = q;
  const sc = document.getElementById('search-clear'); if (sc) sc.style.display = '';
  document.getElementById('author-banner').style.display = 'none';
  switchPageView('library');
  // ★ 必须在 switchPageView 之后赋值：它内部会把 lastHash 重置成 #/library
  lastHash = '#/search/' + encodeURIComponent(q);
  document.getElementById('library-title').textContent = '公共书库';
  loadCategories(); loadBooks();
}
function onSearchInput(v) {
  document.getElementById('search-clear').style.display = v ? '' : 'none';
  if (!v) clearSearch();   // 删除关键字即退出搜索模式
}
function clearSearch() {
  const sq = document.getElementById('search-q'); if (sq) sq.value = '';
  const sc = document.getElementById('search-clear'); if (sc) sc.style.display = 'none';
  curQ = ''; curAuthor = ''; curPage = 1;
  if (location.hash.startsWith('#/search')) { _explicitNav = true; location.hash = '#/library'; }
  else loadBooks();
}
// 作者页
function showAuthor(name) {
  const target = '#/author/' + encodeURIComponent(name);
  if (location.hash !== target) location.hash = target;
  else showAuthorView(name);
}
function showAuthorView(name) {
  curAuthor = name; curQ = ''; curCategory = ''; curPage = 1;
  document.getElementById('search-q').value = '';
  document.getElementById('category-banner').style.display = 'none';
  switchPageView('library');
  lastHash = '#/author/' + encodeURIComponent(name);
  loadCategories();
  loadBooks();
  document.getElementById('author-banner').style.display = '';
  document.getElementById('author-banner-name').textContent = name;
}
function clearAuthor() {
  curAuthor = '';
  document.getElementById('author-banner').style.display = 'none';
  loadBooks();
  if (location.hash.startsWith('#/author')) location.hash = '#/library';
}
async function loadBooks() {
  const isDefault = !curQ && !curCategory && !curAuthor;
  const grid = document.getElementById('book-grid');
  const pager = document.getElementById('pager');
  const recentRow = document.getElementById('recent-row');
  const homeShelf = document.getElementById('home-shelf-row');
  const homeHot = document.getElementById('home-hot-row');
  if (isDefault && !GUEST) {
    // 首页默认：展示最近阅读 + 书架收藏 + 热度推荐，不展示馆藏网格
    grid.style.display = 'none';
    pager.style.display = 'none';
    pager.innerHTML = '';
    document.getElementById('book-count').textContent = '最近阅读 · 书架收藏 · 热度推荐';
    await loadRecent();
    await loadRecentAudio();
    await loadHomeShelf();
    await loadHot();
    return;
  }
  // 有筛选（搜索/分类/作者）：展示馆藏网格
  grid.style.display = '';
  pager.style.display = '';
  recentRow.style.display = 'none';
  homeShelf.style.display = 'none';
  if (homeHot) homeHot.style.display = 'none';
  grid.innerHTML = '<div class="empty">加载中…</div>';
  const params = new URLSearchParams({ page: curPage, size: 30, sort: 'id', order: 'desc' });
  if (curQ) params.set('q', curQ);
  if (curCategory) params.set('category', curCategory);
  if (curAuthor) params.set('author', curAuthor);
  const r = await api('/api/books?' + params);
  document.getElementById('book-count').textContent = (GUEST && isDefault)
    ? ''
    : ((curCategory ? '分类「' + catLabel(curCategory) + '」 · ' : (curAuthor ? '作者「' + curAuthor + '」 · ' : '共 ')) + r.total + ' 本馆藏');
  if (!r.items.length) { grid.innerHTML = '<div class="empty">暂无图书</div>'; document.getElementById('pager').innerHTML = ''; return; }
  grid.innerHTML = '';
  r.items.forEach(b => {
    const d = document.createElement('div');
    d.className = 'book-card';
    const cover = b.cover_url ? `<img class="cover" src="${esc(coverUrl(b.cover_url, b.updated_at))}" loading="lazy" onerror="this.replaceWith(placeholderCover(this))">` : placeholderCoverHTML(b);
    d.innerHTML = `${cover}<div class="info"><div class="t">${esc(b.title)}</div><div class="a">${esc(b.author || b.category || '')}</div></div>`;
    d.onclick = () => openDetail(b.id);
    grid.appendChild(d);
  });
  renderPager(r.total, r.size, r.page);
}
// 首页书架
async function loadHomeShelf() {
  try {
    const r = await api('/api/shelf');
    const row = document.getElementById('home-shelf-row');
    const list = document.getElementById('home-shelf-list');
    if (!r.items.length) { row.style.display = 'none'; return; }
    row.style.display = '';
    list.innerHTML = r.items.slice(0, 6).map(b => {
      const cover = b.cover_url ? `<img class="cover" src="${esc(coverUrl(b.cover_url, b.updated_at))}" loading="lazy">` : placeholderCoverHTML(b);
      return `<div class="book-card" onclick="openDetail(${b.id})">${cover}<div class="info"><div class="t">${esc(b.title)}</div><div class="a">${esc(b.author || '')}</div></div></div>`;
    }).join('');
  } catch (e) {}
}
// 热度推荐：后台「访客热度推荐」标记的书，登录后在首页复用（最多 6 本）。
// 没有「公共书库」权限的分组接口会返回空列表，板块自己隐藏。
async function loadHot() {
  const row = document.getElementById('home-hot-row');
  const list = document.getElementById('home-hot-list');
  if (!row || !list) return;
  try {
    const r = await api('/api/home/hot').catch(() => null);
    const items = (r && r.items) || [];
    if (!items.length) { row.style.display = 'none'; return; }
    row.style.display = '';
    list.innerHTML = items.slice(0, 6).map(b => {
      const cover = b.cover_url ? `<img class="cover" src="${esc(coverUrl(b.cover_url, b.updated_at))}" loading="lazy" onerror="this.replaceWith(placeholderCover(this))">` : placeholderCoverHTML(b);
      // ★ 有可听有声版的书：卡片带「🎧 有声」角标，点开直接进**有声详情**。
      //   从「有声电子书」页面加进来的推荐本来就是有声书，之前点开走 openDetail 变成一本
      //   普通电子书（要再点一次「听有声」才听得到），等于推荐错了形态。
      //   服务端只在**确实有权限听**的时候才给 audio_id（访客/无权限分组不给），
      //   所以这里的兜底就是普通电子书卡片，不会点出 403。
      const isAudio = !!b.audio_id;
      const badge = isAudio ? `<span class="hot-audio">🎧 有声${b.audio_chapters ? ' · ' + b.audio_chapters + ' 章' : ''}</span>` : '';
      const click = isAudio ? `openAudio(${b.audio_id})` : `openDetail(${b.id})`;
      return `<div class="book-card" onclick="${click}">${badge}${cover}<div class="info"><div class="t">${esc(b.title)}</div><div class="a">${esc(b.author || b.category || '')}</div></div></div>`;
    }).join('');
  } catch (e) {
    row.style.display = 'none';
  }
}
// 最近阅读（以书籍封面方式展示）
const RECENT_MAX = 6;      // 首页「最近阅读」只显示最近 6 条（电子书 + 有声混排）
async function loadRecent() {
  try {
    const r = await api('/api/me/recent');
    const row = document.getElementById('recent-row');
    const list = document.getElementById('recent-list');
    recentBooks = r.items.slice(0, RECENT_MAX);
  } catch (e) { recentBooks = []; }
  // ★ 无论阅读记录有没有/接口成不成功，都要重画一次：
  //   有声最近收听是另一半数据，不能因为这边空就整行不显示。
  renderRecentRow();
}
// 最近阅读：长按（App/移动端）或右键（桌面）弹出操作菜单
let recentBooks = [];
let _lpTimer = null, _lpFired = false;
function _recentLongPressStart(e) {
  const card = e.target.closest ? e.target.closest('#recent-list .book-card') : null;
  if (!card) return;
  _lpFired = false;
  clearTimeout(_lpTimer);
  // 有声卡片用 data-au，电子书用 data-id —— 两者菜单不同
  const au = card.dataset.au ? +card.dataset.au : null;
  const bid = card.dataset.id ? +card.dataset.id : null;
  _lpTimer = setTimeout(() => {
    _lpFired = true;
    if (au) showRecentAudioMenu(au); else if (bid) showRecentMenu(bid);
  }, 550);
}
function _recentLongPressEnd() { clearTimeout(_lpTimer); }
(function () {
  const list = document.getElementById('recent-list');
  if (!list) return;
  // Pointer Events（WebView 支持好）为主，touchstart 双保险；一次手势只触发一个定时器
  list.addEventListener('pointerdown', e => {
    if (e.pointerType === 'touch' || e.pointerType === 'pen' || typeof e.pointerType === 'undefined') _recentLongPressStart(e);
  }, { passive: true });
  list.addEventListener('touchstart', _recentLongPressStart, { passive: true });
  ['pointermove', 'pointerup', 'pointercancel', 'pointerleave',
   'touchmove', 'touchend', 'touchcancel'].forEach(ev =>
    document.addEventListener(ev, _recentLongPressEnd, { passive: true }));
  list.addEventListener('contextmenu', e => {
    const card = e.target.closest ? e.target.closest('#recent-list .book-card') : null;
    if (!card) return;
    e.preventDefault();
    _lpFired = true;
    if (card.dataset.au) showRecentAudioMenu(+card.dataset.au); else showRecentMenu(+card.dataset.id);
  });
  // 长按结束后屏蔽随后触发的一次点击（避免误进详情）
  list.addEventListener('click', e => {
    if (_lpFired) { e.stopImmediatePropagation(); e.preventDefault(); _lpFired = false; }
  }, true);
})();
// ---------------------------------------------------------------- 最近收听（有声）
// 首页「最近阅读」里也要出现最近收听的有声电子书，右上角带耳机标识。
// ★ 与阅读记录**合并展示**而不是各开一行：用户要的是「我最近在看的/在听的东西」，
//   而且两边的条目本来就都按时间倒序，拼起来再排一次就是真实次序。
// ★ 有声条目单独存在 AU_RECENT 里，点击/长按走有声自己的逻辑（openAudio / 收听菜单），
//   不去碰 recentBooks 那套（那是电子书 id，混进去会点出 404）。
let AU_RECENT = [];
async function loadRecentAudio() {
  const list = document.getElementById('recent-list');
  if (!list || GUEST) return;
  let items = [];
  try {
    const r = await api('/api/audiobooks/recent');
    items = (r && r.items) || [];
  } catch (e) { items = []; }
  AU_RECENT = items.slice(0, RECENT_MAX);
  if (!AU_RECENT.length) { renderRecentRow(); return; }
  renderRecentRow();
}
// 把「电子书最近阅读」与「有声最近收听」按时间合并后重画首页这一行
function renderRecentRow() {
  const row = document.getElementById('recent-row');
  const list = document.getElementById('recent-list');
  if (!row || !list) return;
  const books = (typeof recentBooks !== 'undefined' ? recentBooks : []) || [];
  if (!books.length && !AU_RECENT.length) { row.style.display = 'none'; return; }
  row.style.display = '';
  const merged = books.map(b => ({ kind: 'book', t: b.pat || b.updated_at || '', b: b }))
    .concat(AU_RECENT.map(a => ({ kind: 'audio', t: a.listened_at || '', b: a })));
  // 时间字段都是 "YYYY-MM-DD HH:MM:SS"，字符串倒序即时间倒序；没有时间的排后面
  merged.sort((x, y) => String(y.t).localeCompare(String(x.t)));
  // ★ 只显示最近 6 条。电子书与有声各自最多取 6 条进来（见 loadRecent / loadRecentAudio），
  //   合并排序后再截 6 —— 这样「最近 6 条」是两种记录混在一起排出来的真前 6 名，
  //   而不是「各显示 6 条」变成 12 条。
  list.innerHTML = merged.slice(0, RECENT_MAX)
    .map(m => (m.kind === 'audio' ? auRecentCard(m.b) : recentBookCard(m.b))).join('');
}
function recentBookCard(b) {
  const cover = b.cover_url ? `<img class="cover" src="${esc(coverUrl(b.cover_url, b.updated_at))}" loading="lazy" onerror="this.replaceWith(placeholderCover(this))">` : placeholderCoverHTML(b);
  const pct = Math.round(b.percent || 0);
  return `<div class="book-card" data-id="${b.id}" onclick="openDetail(${b.id})">
    ${cover}
    <div class="info"><div class="t">${esc(b.title)}</div><div class="a">${esc(b.author || '')}</div>
    <div class="prog-track"><div class="prog-fill" style="width:${pct}%"></div></div></div>
  </div>`;
}
// 有声卡片：右上角耳机标识；进度条按「听到第几章 / 共几章」折算
function auRecentCard(a) {
  const cover = a.cover_url
    ? `<img class="cover" src="${esc(coverUrl(a.cover_url, a.created_at))}" loading="lazy" onerror="this.replaceWith(placeholderCover(this))">`
    : placeholderCoverHTML({ id: a.id, title: a.title });
  const pr = a.progress && a.progress.percent ? a.progress.percent : 0;
  const sub = a.progress
    ? '听到第 ' + (a.progress.chap_seq || 1) + ' 章'
    : (a.author || '有声电子书');
  return `<div class="book-card au-recent" data-au="${a.id}" onclick="openAudio(${a.id})">
    ${cover}<span class="au-badge" title="有声电子书">有声</span>
    <div class="info"><div class="t">${esc(a.title)}</div><div class="a">${esc(sub)}</div>
    <div class="prog-track"><div class="prog-fill" style="width:${Math.min(100, pr)}%"></div></div></div>
  </div>`;
}
function showRecentMenu(bid) {
  const b = recentBooks.find(x => x.id === bid) || {};
  openModal(`<button class="close" onclick="closeModal()">✕</button>
    <h3>${esc(b.title || ('#' + bid))}</h3>
    <p class="muted" style="margin:4px 0 14px">长按操作</p>
    <div style="display:flex;gap:10px;flex-wrap:wrap">
      <button class="btn ghost" onclick="closeModal();openDetail(${bid})">📖 打开阅读</button>
      <button class="btn danger" onclick="removeRecent(${bid})">🗑 移出首页</button>
    </div>`);
}
function showRecentAudioMenu(lid) {
  const a = AU_RECENT.find(x => x.id === lid) || {};
  openModal(`<button class="close" onclick="closeModal()">✕</button>
    <h3>${esc(a.title || ('#' + lid))}</h3>
    <p class="muted" style="margin:4px 0 14px">有声电子书 · 长按操作</p>
    <div style="display:flex;gap:10px;flex-wrap:wrap">
      <button class="btn ghost" onclick="closeModal();openAudio(${lid})">继续收听</button>
      <button class="btn danger" onclick="removeRecentAudio(${lid})">🗑 移出首页</button>
    </div>`);
}
async function removeRecentAudio(lid) {
  try {
    await api('/api/audiobooks/' + lid + '/progress', { method: 'DELETE' });
    closeModal();
    toast('已移出最近阅读');
    AU_RECENT = AU_RECENT.filter(x => x.id !== lid);
    renderRecentRow();
  } catch (e) { toast(e.message); }
}
async function removeRecent(bid) {
  try {
    await api('/api/me/progress/' + bid, { method: 'DELETE' });
    closeModal();
    toast('已移出最近阅读');
    loadRecent();
  } catch (e) { toast(e.message); }
}
function placeholderCoverHTML(b) {
  const c = ['#5b8def','#7c5cf0','#2f9e44','#e8590c','#c2255c','#0ca678','#7048e8','#e67700'];
  const i = (b.id || 0) % c.length;
  return `<div class="cover placeholder" style="background:${c[i]}">${esc(b.title.slice(0,10))}</div>`;
}
function placeholderCover(img) { return Object.assign(document.createElement('div'), { className: 'cover placeholder' }); }
function renderPager(total, size, page) {
  const pages = Math.ceil(total / size);
  curPages = pages;
  const p = document.getElementById('pager');
  if (pages <= 1) { p.innerHTML = ''; return; }
  p.innerHTML = `<button onclick="goPage(${page-1})" ${page<=1?'disabled':''}>‹</button>
    <span style="display:inline-flex;align-items:center;gap:6px;font-size:14px;color:var(--muted)">第
      <input id="pager-input" type="number" min="1" max="${pages}" value="${page}" style="width:64px;padding:6px 8px;border:1.5px solid var(--line);border-radius:8px;text-align:center;font-size:14px" onkeydown="if(event.key==='Enter')jumpPage()">
      / ${pages} 页</span>
    <button class="btn sm" onclick="jumpPage()">跳转</button>
    <button onclick="goPage(${page+1})" ${page>=pages?'disabled':''}>›</button>`;
}
function goPage(p) { curPage = p; loadBooks(); window.scrollTo(0,0); }
function jumpPage() {
  const inp = document.getElementById('pager-input');
  let n = parseInt(inp && inp.value, 10);
  if (!n || n < 1) n = 1;
  if (n > curPages) n = curPages;
  goPage(n);
}

// ---------- 详情 ----------
function openDetail(id) {
  const target = '#/book/' + id;
  if (location.hash !== target) location.hash = target;
  else openDetailView(id);
}
async function openDetailView(id) {
  // 同一本书且详情已经可见：不再请求一次，但要把视图状态纠正过来 ——
  // bfcache 恢复（App 里从阅读器返回）时其它视图可能被重新显示出来，
  // 只 return 不纠正就会两个视图叠着显示，详情被顶到首屏之外。
  if (detailBook && detailBook.id === id && !document.getElementById('view-detail').classList.contains('hidden')) {
    showView('detail');
    return;
  }
  detailBook = await api('/api/books/' + id);
  showView('detail');
  renderDetail();
}
function closeDetail() {
  location.hash = lastHash;
}
function renderDetail() {
  const b = detailBook;
  const cover = b.cover_url ? `<img class="cover" src="${esc(coverUrl(b.cover_url, b.updated_at))}" onerror="this.style.display='none'">` : '';
  const el = document.getElementById('detail-body');
  // 下载按钮：游客（下载推荐书）与所有登录用户可见；无下载权限的分组用树叶兑换（1 片/本）
  const dlLeaf = (!GUEST && !can('download')) ? '（1🌿）' : '';
  const dlBtn = `<button class="btn ghost" onclick="doDownload()">⬇ 下载${dlLeaf}</button>`;
  // 听书按钮：在「下载」右边。游客不可听书（服务端也拒绝匿名流量）；无 listen 权限的分组按本收树叶
  const listenExts = ['.txt', '.docx', '.md', '.markdown', '.epub', '.mobi', '.azw3', '.azw', '.prc'];
  const listenOk = listenExts.indexOf((b.ext || '').toLowerCase()) >= 0;
  // 费用取后台配置（/api/books/{id} 返回 listen_cost），不能写死。
  // 万一字段缺失（旧缓存等），退回「需树叶」，绝不显示成「0🌿」让人误以为免费。
  // ★ 免费的书（有听书权限，或落在免费额度内）按钮就只写「听书」，不挂任何后缀。
  //   曾经在这里显示「（30天内免费剩3本）」，是多余的打扰：用户点之前不需要被
  //   反复提醒还剩几本，何况额度够不够点下去服务端一样会算。只有真要花树叶时才标价格。
  // 天数取服务端下发的 valid_days（默认 30），这样改规则时不用再动前端。
  const lqDays = (b.listen_quota && b.listen_quota.valid_days) || 30;
  const listenLeaf = b.listen_free
    ? ''
    : (typeof b.listen_cost === 'number' ? `（${b.listen_cost}🌿 / ${lqDays}天）` : '（需树叶）');
  // ★ 后台「听书设置」的总开关：关掉听书时详情页**整个不给入口**（按钮藏起来）。
  //   以前这里只看扩展名，于是后台停了听书、按钮还在，点进去才报「听书功能未开启」——
  //   把人骗进去再拒绝是最差的交互；启用后按钮自动回来（服务端每次下发实时值）。
  //   ★ 只有服务端**明确说 false** 才藏：字段缺失（旧缓存/旧后端）按「开」处理，
  //     免得升级过程中把按钮误藏掉（读要宽的同一套道理）。
  const ttsOn = b.listen_enabled !== false;
  const listenBtn = (GUEST || !ttsOn) ? '' : (listenOk
    ? `<button class="btn ghost" onclick="goListen()">听书${listenLeaf}</button>`
    : '<button class="btn ghost" disabled title="该格式暂不支持听书">听书</button>');
  // 管理员：这本书有待审的共享申请 → 「下载」右边给出「通过申请 / 驳回申请」
  const sr = (USER && USER.role === 'admin') ? b.share_request : null;
  const srBtns = sr ? `
    <button class="btn" onclick="reviewShareRequest(${sr.id}, 'approve')">通过申请</button>
    <button class="btn danger" onclick="reviewShareRequest(${sr.id}, 'reject')">驳回申请</button>` : '';
  const srHint = sr ? `<div class="line muted" style="margin-top:10px;font-size:13px">
      这条共享申请由 <b>${esc(sr.requester_name || '会员')}</b> 于 ${blTime(sr.created_at)} 提交，可先点「开始阅读」看完再决定是否通过。</div>` : '';
  // 私人上传书：上传者可申请共享（管理员审核通过后转为公共书）
  const isOwner = b.owner_id != null && b.owner_id === (USER && USER.id);
  const shareReqBtn = isOwner ? (b.share_allowed === false
    ? '<button class="btn ghost sm" disabled title="该格式暂不支持申请共享，上传不受影响">共享本书（格式不支持）</button>'
    : '<button class="btn ghost sm" onclick="shareBookRequest()">共享本书</button>') : '';
  // 已在书架则不再显示「＋书架」
  const shelfBtn = b.in_shelf ? '' : '<button class="btn ghost" onclick="showShelfPicker()">＋书架</button>';
  // 阅读进度条
  const pct = b.progress ? Math.round(b.progress.percent || 0) : 0;
  const hasProgress = b.progress && (b.progress.percent > 0 || b.progress.position);
  const readLabel = hasProgress ? '▶ 继续阅读' : '📖 开始阅读';
  // 有阅读进度时，顶部不再放「继续阅读」——「阅读进度」板块里已有一个，避免重复；
  // 没有阅读进度、但听过这本书时「阅读进度」板块仍然渲染，顶部同样不用重复放入口
  const topReadBtn = hasProgress ? '' : `<button class="btn" onclick="readBook()">${readLabel}</button>`;
  // 「有声阅读」：这本书有能听的有声版时，紧挨着「开始阅读」右边给一个入口，
  // 点了直接进这本有声书的**章节目录**（#/audio/<audio_id>）。
  // ★ 与下面那个「听书」是两码事，别混：听书是**现场合成**（TTS，按本/天数收树叶），
  //   有声阅读是**已经做好的成品音频**（自己的章节、自己的兑换/权限）。
  //   所以判断依据也不同：这里看的是服务端给的 audio_id（已按有声权限过滤过）。
  // 没有阅读进度时顶部本来就不放「开始阅读」（继续阅读在下面的进度板块里），
  // 这时「有声阅读」会排到第一个 —— 不能因为少了个按钮就把有声入口也藏掉。
  const topAudioBtn = b.audio_id
    ? `<button class="btn" onclick="openAudio(${b.audio_id})">有声阅读</button>` : '';
  // 「继续听书」：听过这本书（有听书进度），或者花树叶买过它的听书权限。
  // 两种情况都表示用户在这本书上投入过，需要一个一键回去继续听的入口。
  // 格式不支持听书时不显示（那种书不可能有听书进度，防御性判断）。
  // ★ 总开关关掉时「继续听书」也一并藏：听书都停了，继续的入口点下去只会报错
  const canListenBack = ttsOn && listenOk && (b.has_listen_progress || b.listen_paid);
  const listenBackBtn = canListenBack
    ? '<button class="btn sm" onclick="goListen()">🎧 继续听书</button>' : '';
  const readBackBtn = hasProgress
    ? '<button class="btn sm" onclick="continueRead()">▶ 继续阅读</button>' : '';
  // 板块在「有阅读进度」或「可继续听书」时都渲染 ——
  // 只听没读的书如果这里不显示，那个按钮就永远没地方放。
  // 没有阅读进度时左侧留空：写「已读 0%」既不准也没意义。
  const progBar = (hasProgress || canListenBack) ? `
    <div class="card">
      <h3 style="margin:0 0 8px">阅读进度</h3>
      ${hasProgress ? `<div class="prog-track"><div class="prog-fill" style="width:${pct}%"></div></div>` : ''}
      <div class="row between" style="margin-top:10px">
        <span class="muted">${hasProgress ? '已读 ' + pct + '%' : ''}</span>
        <span style="display:inline-flex;gap:8px;flex-wrap:wrap;justify-content:flex-end">${listenBackBtn}${readBackBtn}</span>
      </div>
    </div>` : '';
  const mgrBtns = [
    '<button class="btn ghost sm" onclick="showReport()">举报</button>',
    (GUEST || can('share')) ? '<button class="btn ghost sm" onclick="showShare()">分享</button>' : '',
    can('edit') ? '<button class="btn ghost sm" onclick="showEdit()">编辑</button>' : '',
    can('edit') ? '<button class="btn ghost sm" onclick="enrichBook()">补录元数据</button>' : '',
    can('cover') ? '<button class="btn ghost sm" onclick="showCoverUpload()">传封面</button>' : '',
    can('cover') ? '<button class="btn ghost sm" onclick="onlineCover()">刮削封面</button>' : '',
    // 转换按钮：无转换权限的分组用树叶兑换（2 片/本）
    `<button class="btn ghost sm" onclick="showConvert()">转换格式${(!GUEST && !can('convert')) ? '（2🌿）' : ''}</button>`,
    can('delete') ? '<button class="btn danger sm" onclick="delBook()">删除</button>' : ''
  ].join('');
  el.innerHTML = `
    <div class="detail-head">
      ${cover}
      <div class="meta">
        <h2>${esc(b.title)}</h2>
        ${b.rating ? '<div class="line" style="color:#f59e0b;font-weight:700">★ ' + esc(b.rating) + ' 分</div>' : ''}
        <div class="line">${b.author ? '作者：<a class="author-link" onclick="showAuthor(\'' + esc(b.author) + '\')">' + esc(b.author) + '</a>' : ''}</div>
        <div class="line">${b.category ? '<span class="tag">' + esc(catLabel(b.category)) + '</span>' : ''}${b.clc ? '<span class="tag">CLC ' + esc(b.clc) + '</span>' : ''}</div>
        ${b.publisher ? '<div class="line muted">出版社：' + esc(b.publisher) + '</div>' : ''}
        ${b.isbn ? '<div class="line muted">ISBN：' + esc(b.isbn) + '</div>' : ''}
        ${b.pages ? '<div class="line muted">页数：' + esc(b.pages) + '</div>' : ''}
        ${b.series ? '<div class="line muted">丛书：' + esc(b.series) + '</div>' : ''}
        <div class="line muted">${esc((b.ext||'').toUpperCase().replace('.',''))} · ${b.size_mb} MB</div>
      </div>
    </div>
    <div class="card actions">
      ${topReadBtn}
      ${topAudioBtn}
      ${shelfBtn}
      ${shareReqBtn}
      ${dlBtn}${listenBtn}${srBtns}
    </div>
    ${srHint}
    ${progBar}
    <div class="card actions">${mgrBtns}</div>
    <div class="card">
      <h3 style="margin:0 0 8px">简介</h3>
      <div id="detail-intro" style="color:#444;white-space:pre-wrap;font-size:14px">加载中…</div>
    </div>`;
  api('/api/books/' + b.id + '/intro').then(r => {
    document.getElementById('detail-intro').textContent = r.intro;
  }).catch(() => { document.getElementById('detail-intro').textContent = ''; });
}
function readBook() {
  const has = detailBook.progress && (detailBook.progress.percent > 0 || detailBook.progress.position);
  location.href = '/reader?id=' + detailBook.id + (has ? '' : '&fresh=1');
}
function continueRead() { location.href = '/reader?id=' + detailBook.id; }
function goListen() { location.href = '/listen?id=' + detailBook.id; }
async function enrichBook() {
  if (!confirm('将从文件重新读取书名/作者并自动重命名 FTP 文件，是否继续？')) return;
  toast('正在补录元数据…');
  try { await api('/api/books/' + detailBook.id + '/enrich', { method: 'POST' }); toast('元数据已更新并重命名'); detailBook = await api('/api/books/' + detailBook.id); renderDetail(); loadBooks(); }
  catch (e) { toast(e.message); }
}
async function addShelf() {
  try { await api('/api/shelf/' + detailBook.id, { method: 'POST' }); toast('已加入书架'); }
  catch (e) { toast(e.message); }
}
// 管理员在图书详情页直接审批共享申请（与后台「共享审核」同一条处理逻辑）
async function reviewShareRequest(rid, action) {
  if (action === 'reject') {
    return askRejectReason({
      title: '驳回共享申请',
      hint: '驳回后该书仍为申请人的私人书籍。下面填写的理由会原文显示在申请人的「我的消息」里。',
      onSubmit: reason => doReviewShareRequest(rid, 'reject', reason)
    });
  }
  if (!confirm('确定通过这条共享申请？\n\n通过后该书转为公共书籍，所有会员均可阅读，并按后台设置为申请人发放树叶奖励。')) return;
  doReviewShareRequest(rid, 'approve', '');
}
async function doReviewShareRequest(rid, action, reason) {
  try {
    const r = await api('/api/admin/share-requests/handle', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ids: [rid], action: action, reason: reason || '' })
    });
    if (r.done) toast(action === 'approve' ? '已通过申请，该书已转为公共书籍' : '已驳回申请，理由已通知申请人');
    else toast((r.errors && r.errors[0]) || '操作未生效，可能已被处理');
    const id = detailBook.id;
    detailBook = await api('/api/books/' + id);
    renderDetail();
    loadShelf();
  } catch (e) { toast(e.message); }
}
// 驳回理由输入弹窗（共享申请 / 书单文章通用）
let rejectReasonCb = null;
function askRejectReason(opts) {
  openModal(`<button class="close" onclick="closeModal()">✕</button>
    <h3>${esc(opts.title)}</h3>
    <p class="muted" style="font-size:13px;line-height:1.7;margin:6px 0 12px">${esc(opts.hint || '')}</p>
    <div class="form-group">
      <label>驳回理由（可不填）</label>
      <textarea id="rj-reason" rows="4" maxlength="200"
        placeholder="例如：文件内容不完整 / 与本站收录范围不符 / 正文缺少推荐理由"></textarea>
    </div>
    <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:4px">
      <button class="btn ghost" onclick="closeModal()">取消</button>
      <button class="btn danger" onclick="submitRejectReason()">确定驳回</button>
    </div>`);
  rejectReasonCb = opts.onSubmit;
  setTimeout(() => { const t = document.getElementById('rj-reason'); if (t) t.focus(); }, 60);
}
function submitRejectReason() {
  const el = document.getElementById('rj-reason');
  const reason = (el ? el.value : '').trim();
  if (reason.length > 200) { toast('驳回理由最多 200 字'); return; }
  const cb = rejectReasonCb; rejectReasonCb = null;
  closeModal();
  if (cb) cb(reason);
}
// 共享本书：私人上传书申请转为公共书（管理员/总编免审批，提交即生效）
async function shareBookRequest() {
  if (!confirm(isTrusted()
    ? '将本书转为公共书籍（列入未分类），对所有会员可见。您的身份无需审核，确认后立即生效。是否继续？'
    : '将本书提交管理员审核，审核通过后该书将转为公共书籍（列入未分类），对所有会员可见。是否提交？')) return;
  try {
    const r = await api('/api/books/' + detailBook.id + '/share-request', { method: 'POST' });
    toast(r && r.status === 'approved' ? '已转为公共书籍' : '已提交共享申请，等待管理员审核');
  } catch (e) { toast(e.message); }
}
// ＋书架：选择书架分类（或新建分类）加入
async function showShelfPicker() {
  if (!requireLogin()) return;
  const s = await api('/api/shelf').catch(() => null);
  const cols = (s && s.collections) || [];
  const opts = '<option value="">未分类</option>' + cols.map(c =>
    `<option value="${c.id}">${esc(c.name)}（${c.n}本）</option>`).join('');
  openModal(`
    <button class="close" onclick="closeModal()">✕</button>
    <h3>加入书架</h3>
    <p class="muted" style="font-size:13px">选择《${esc(detailBook.title)}》要放入的书架分类</p>
    <div class="form-group"><label>选择分类</label>
      <select id="sf-cat" style="flex:1;padding:10px;border:1px solid #e6e8ee;border-radius:8px">${opts}</select></div>
    <div class="form-group"><label>或新建分类</label>
      <input id="sf-new" placeholder="输入新分类名（留空则用上方选择）" style="flex:1;padding:10px;border:1px solid #e6e8ee;border-radius:8px"></div>
    <button class="btn block" onclick="addShelfToCat()">确认加入</button>`);
}
async function addShelfToCat() {
  const sel = document.getElementById('sf-cat');
  const newName = (document.getElementById('sf-new').value || '').trim();
  let cid = sel && sel.value ? parseInt(sel.value) : null;
  if (newName) {
    const fd = new FormData(); fd.append('name', newName);
    const r = await api('/api/shelf/collections', { method: 'POST', body: fd }).catch(e => { toast(e.message); return null; });
    if (!r) return;
    cid = r.id;
  }
  const fd = new FormData();
  if (cid) fd.append('collection_id', cid);
  try {
    const r = await api('/api/shelf/' + detailBook.id, { method: 'POST', body: fd });
    toast(r.message || '已加入书架'); closeModal();
    detailBook.in_shelf = true; renderDetail();
  } catch (e) { toast(e.message); }
}
async function doDownload() {
  if (!requireLogin()) return;
  const m = (detailBook.path || detailBook.file || '').match(/\.([A-Za-z0-9]{2,5})$/);
  const ext = m ? m[1] : '';
  try {
    const r = await api('/api/books/' + detailBook.id + '/download-ticket', { method: 'POST' });
    // URL 以真实扩展名结尾（/download.mobi），兼容 Kindle 等按 URL 扩展名判断文件类型的设备
    location.href = await absLink('/api/books/' + detailBook.id + '/download' + (ext ? '.' + ext : '') + '?ticket=' + r.ticket);
  } catch (e) { toast(e.message); }
}
// ---------- 格式转换（calibre） ----------
function showConvert() {
  if (!requireLogin()) return;
  const src = (detailBook.ext || '').replace('.', '').toLowerCase() || '原格式';
  const fmts = ['mobi', 'azw', 'azw3', 'epub', 'txt', 'md'].filter(f => f !== src);
  const opts = fmts.map(f => `<option value="${f}">.${f}</option>`).join('');
  const leafNote = (!GUEST && !can('convert'))
    ? '<p style="font-size:13px;line-height:1.7;color:#b45309;margin:8px 0 0">本次转换将消耗 2 片树叶（同一本书重复转换不重复扣）。</p>' : '';
  openModal(`
    <button class="close" onclick="closeModal()">✕</button>
    <h3>转换格式</h3>
    <p class="muted" style="font-size:13px;line-height:1.7">把《${esc(detailBook.title)}》转换为目标格式（原格式 .${esc(src)}），下载到本地后服务器缓存自动清理。</p>
    ${leafNote}
    <div class="form-group"><label>目标格式</label>
      <select id="cv-to" style="flex:1;padding:10px;border:1px solid #e6e8ee;border-radius:8px">${opts}</select></div>
    <div style="display:flex;gap:8px;margin-top:14px">
      <button class="btn block" onclick="doConvert()">转换并下载</button>
    </div>
    <div id="cv-status" style="margin-top:10px;font-size:13px;color:#666"></div>`);
}
async function gotoFileDl(url) {
  // 用一次性短时凭证跳转下载，URL 不携带登录令牌
  try {
    const tk = await api('/api/books/' + detailBook.id + '/download-ticket', { method: 'POST' });
    location.href = await absLink(url + '?ticket=' + tk.ticket);
  } catch (e) { toast(e.message); }
}
async function doConvert() {
  const to = document.getElementById('cv-to').value;
  const st = document.getElementById('cv-status');
  st.textContent = '正在提交转换任务…';
  try {
    const r = await api('/api/books/' + detailBook.id + '/convert', { method: 'POST', body: new URLSearchParams({ to: to }) });
    if (r.done) {
      st.textContent = `✓ 转换完成（${r.size_mb} MB），已开始下载，服务器缓存将自动清理。`;
      gotoFileDl(r.url);
      return;
    }
    // 异步任务：轮询进度
    st.textContent = '转换任务已提交，正在后台转换（大文件可能需要一两分钟），请稍候…';
    const poll = async () => {
      const s = await api('/api/convert/status/' + r.task_id);
      if (s.status === 'done') {
        st.textContent = `✓ 转换完成（${s.size_mb} MB），已开始下载。`;
        gotoFileDl(s.url);
      } else if (s.status === 'error') {
        st.textContent = '';
        toast(s.error || '转换失败');
      } else {
        st.textContent = '正在后台转换…（已提交，请勿关闭页面）';
        setTimeout(poll, 2000);
      }
    };
    setTimeout(poll, 1500);
  } catch (e) { st.textContent = ''; toast(e.message); }
}
async function delBook() {
  if (!confirm('确认删除《' + detailBook.title + '》？此操作会删除 FTP 上的文件')) return;
  try { await api('/api/books/' + detailBook.id, { method: 'DELETE' }); toast('已删除'); closeDetail(); loadBooks(); }
  catch (e) { toast(e.message); }
}

// ---------- 编辑 ----------
async function showEdit() {
  const b = detailBook;
  const folders = await api('/api/cat-folders').catch(() => []);
  let opts = folders.map(f => `<option value="${esc(f.folder)}" ${f.folder === b.category ? 'selected' : ''}>${esc(f.letter === '00' ? '待分类' : f.letter + ' · ' + f.label)}</option>`).join('');
  if (b.category && !folders.some(f => f.folder === b.category)) {
    opts = `<option value="${esc(b.category)}" selected>${esc(catLabel(b.category))}</option>` + opts;
  }
  openModal(`
    <button class="close" onclick="closeModal()">✕</button><h3>编辑信息</h3>
    <div class="form-group"><label>书名</label><input id="ed-title" value="${esc(b.title)}"></div>
    <div class="form-group"><label>作者</label><input id="ed-author" value="${esc(b.author||'')}"></div>
    <div class="form-group"><label>分类（改分类会将文件移动到对应目录）</label><select id="ed-cat">${opts}</select></div>
    <div class="form-group"><label>出版社</label><input id="ed-publisher" value="${esc(b.publisher||'')}"></div>
    <div class="form-group"><label>ISBN</label><input id="ed-isbn" value="${esc(b.isbn||'')}"></div>
    <div class="form-group"><label>页数</label><input id="ed-pages" type="number" value="${esc(b.pages||0)}"></div>
    <div class="form-group"><label>丛书</label><input id="ed-series" value="${esc(b.series||'')}"></div>
    <div class="form-group"><label>简介</label><textarea id="ed-intro">${esc(b.intro||'')}</textarea></div>
    <button class="btn block" onclick="saveEdit()">保存</button>`);
}
async function saveEdit() {
  const fd = new FormData();
  fd.append('title', document.getElementById('ed-title').value);
  fd.append('author', document.getElementById('ed-author').value);
  fd.append('category', document.getElementById('ed-cat').value);
  fd.append('publisher', document.getElementById('ed-publisher').value);
  fd.append('isbn', document.getElementById('ed-isbn').value);
  fd.append('pages', document.getElementById('ed-pages').value);
  fd.append('series', document.getElementById('ed-series').value);
  fd.append('intro', document.getElementById('ed-intro').value);
  try { detailBook = await api('/api/books/' + detailBook.id, { method: 'PUT', body: fd }); closeModal(); renderDetail(); toast('已保存'); }
  catch (e) { toast(e.message); }
}

// ---------- 侵权举报 ----------
function showReport() {
  if (!requireLogin()) return;
  openModal(`<button class="close" onclick="closeModal()">✕</button><h3>举报《${esc(detailBook.title)}》</h3>
    <p class="muted" style="font-size:13px;line-height:1.7">如认为本书侵犯您的著作权或含违规内容，请提交举报，管理员核实后将下架处理。</p>
    <div class="form-group"><label>举报原因</label>
      <select id="rp-reason" style="flex:1;padding:10px;border:1px solid #e6e8ee;border-radius:8px">
        <option>涉嫌侵权（著作权）</option><option>内容违规</option><option>质量问题（缺页/乱码）</option><option>其他</option></select></div>
    <div class="form-group"><label>补充说明（选填）</label><textarea id="rp-detail" rows="4"></textarea></div>
    <button class="btn block" onclick="doReport()">提交举报</button>`);
}
async function doReport() {
  const fd = new FormData();
  fd.append('reason', document.getElementById('rp-reason').value);
  fd.append('detail', document.getElementById('rp-detail').value);
  try { await api('/api/books/' + detailBook.id + '/report', { method: 'POST', body: fd }); closeModal(); toast('举报已提交，感谢您的反馈'); }
  catch (e) { toast(e.message); }
}

// ---------- 封面上传 ----------
function showCoverUpload() {
  openModal(`<button class="close" onclick="closeModal()">✕</button><h3>上传封面</h3>
    <input type="file" id="cv-file" accept="image/*">
    <button class="btn block" style="margin-top:12px" onclick="saveCover()">上传</button>`);
}
async function saveCover() {
  const f = document.getElementById('cv-file').files[0];
  if (!f) return toast('请选择图片');
  const fd = new FormData(); fd.append('file', f);
  try {
    await api('/api/books/' + detailBook.id + '/cover', { method: 'POST', body: fd });
    detailBook = await api('/api/books/' + detailBook.id);
    closeModal(); toast('封面已更新'); renderDetail(); loadBooks();
  }
  catch (e) { toast(e.message); }
}
async function onlineCover() {
  toast('正在从网络刮削封面…');
  try {
    const r = await api('/api/books/' + detailBook.id + '/cover/online', { method: 'POST' });
    detailBook = await api('/api/books/' + detailBook.id);
    toast(r.rating ? '封面已更新 · 评分 ' + r.rating : '刮削封面已更新');
    renderDetail(); loadBooks();
  }
  catch (e) { toast(e.message); }
}

// ---------- 上传 ----------
// 一次可以选**多本**，但上限是**逐本**判定的：分组权限里的
// `upload_max_mb`（本组单个文件最大 MB）说的是一本，不是这一批的总和。
// 所以：客户端一个一个比、超限的当场标红并跳过；服务端仍然是权威
// （`/api/upload` 边写边判，超限立刻中断并删掉半截文件），这里只是别让
// 几十兆的文件传了半天才被拒。
async function showUpload() {
  if (!requireLogin()) return;
  if (!can('private_shelf')) { toast('无权限上传私人书籍，请联系管理员开通「私人书架」权限'); return; }
  const s = await api('/api/shelf').catch(() => null);
  const cols = (s && s.collections) || [];
  const opts = '<option value="">默认书架（未分类）</option>' + cols.map(c =>
    `<option value="${c.id}">${esc(c.name)}（${c.n}本）</option>`).join('');
  // 书架还能放几本：服务端在**读文件之前**就会拒绝超配额的上传（不浪费流量），
  // 但一次选十本、传到第四本才知道放不下太难受，先写在提示里。
  const left = (s && s.quota) ? Math.max(0, s.quota - (s.count || 0)) : null;
  openModal(`<button class="close" onclick="closeModal()">✕</button><h3>上传电子书</h3>
    <input type="file" id="up-file" multiple onchange="upPick()" accept=".epub,.mobi,.azw,.azw1,.azw3,.azw4,.kf8,.kfx,.kpf,.tpz,.prc,.pdb,.txt,.rtf,.md,.markdown,.doc,.docx,.odt,.pml,.tcr,.pdf,.djvu,.djv,.chm,.xps,.oxps,.uvz,.fb2,.fbz,.lit,.lrf,.lrx,.lrs,.snb,.umd,.ibooks,.cbz,.cbr,.cb7,.cbt,.html,.htm,.xhtml,.oeb,.opf">
    <div class="up-list" id="up-list"></div>
    <div class="form-group" style="margin-top:12px"><label>选择书架分类</label><select id="up-cat">${opts}</select></div>
    <div class="form-group"><label>或新建书架分类</label><input id="up-newcat" placeholder="输入新分类名（留空则用上方选择）"></div>
    <p class="muted" style="font-size:13px">可一次选多本；上传后仅自己可见，文件存放于 WebDAV 的 upload 目录${upLimitTip()}${left === null ? '' : `　书架还能放 <b>${left}</b> 本`}</p>
    <button class="btn block" style="margin-top:12px" id="up-go" onclick="doUpload(this)">上传</button>`);
  upPick();
}
// 本分组的**单本**上传上限（0=不限）。服务端是权威，这里只为了先给出明确提示。
function upLimitMB() {
  const n = parseInt(((USER && USER.limits) || {}).upload_max_mb || 0, 10);
  return n > 0 ? n : 0;
}
function upLimitTip() {
  const n = upLimitMB();
  return n ? `　本组单个文件最大 <b>${n} MB</b>` : '';
}
// 选好文件后逐行列出：体积、是否超限、以及上传完的结果。
// ★ 一行一本、一本一比 —— 绝不能用「这批加起来超没超」来判（那是另一回事，
//   分组权限里压根没有「总量」这个限制）。
function upListHTML(files, res) {
  const maxMB = upLimitMB();
  return files.map((f, i) => {
    const r = res && res[i];
    const over = maxMB && f.size > maxMB * 1048576;
    const cls = r && r.state === 'ok' ? ' ok' : ((r && r.state) || (over ? 'bad' : ''));
    const tail = r ? esc(r.text) : ((over ? '超过上限 ' : '') + fmtSize(f.size));
    return `<div class="up-row${cls ? ' ' + cls : ''}">
      <span class="up-name" title="${esc(f.name)}">${esc(f.name)}</span>
      <span class="up-size">${tail}</span></div>`;
  }).join('');
}
function upPick() {
  const inp = document.getElementById('up-file');
  const box = document.getElementById('up-list');
  const btn = document.getElementById('up-go');
  if (!inp || !box || !btn) return;
  const fs = Array.from(inp.files || []);
  const maxMB = upLimitMB();
  const over = fs.filter(f => maxMB && f.size > maxMB * 1048576).length;
  box.className = 'up-list';
  box.innerHTML = upListHTML(fs);
  const ok = fs.length - over;
  btn.disabled = !ok;
  btn.textContent = !fs.length ? '上传'
    : (ok ? `上传 ${ok} 本` + (over ? `（另 ${over} 本超限，将跳过）` : '')
          : `选中的 ${fs.length} 本都超过本组单本上限`);
}
async function doUpload(btn) {
  const inp = document.getElementById('up-file');
  const files = Array.from((inp && inp.files) || []);
  if (!files.length) return toast('请选择文件');
  const maxMB = upLimitMB();
  const todo = [], res = [];
  files.forEach((f, i) => {
    // ★ 逐本判定
    if (maxMB && f.size > maxMB * 1048576) {
      res[i] = { state: 'bad', text: `跳过 · 超过本组单本上限（${maxMB} MB）` };
    } else { todo.push(f); }
  });
  if (!todo.length) return toast(`选中的 ${files.length} 本都超过本组单本上限（${maxMB} MB）`);
  let cid = document.getElementById('up-cat').value || null;
  const newName = (document.getElementById('up-newcat').value || '').trim();
  if (newName) {
    const fd = new FormData(); fd.append('name', newName);
    const r = await api('/api/shelf/collections', { method: 'POST', body: fd }).catch(e => { toast(e.message); return null; });
    if (!r) return;
    cid = r.id;
  }
  // 一本一本传（**不并发**）：服务端是一条流一条流地落盘，串行才有干净的顺序和
  // 准确的逐本进度；而且每本的 Content-Length 就是那一本的大小，
  // 服务端「先按 Content-Length 快速拒绝」的优化才依然成立。
  let okN = 0, badN = 0, skipN = 0;
  for (let i = 0; i < files.length; i++) {
    const f = files[i];
    if (res[i]) { skipN++; continue; }
    btn.disabled = true;
    btn.textContent = `上传中 ${okN + badN + 1}/${todo.length}　` +
      (f.name.length > 16 ? f.name.slice(0, 16) + '…' : f.name);
    const fd = new FormData(); fd.append('file', f);
    if (cid) fd.append('collection_id', cid);
    try {
      await api('/api/upload', { method: 'POST', body: fd });
      res[i] = { state: 'ok', text: '已上传，已加入书架' }; okN++;
    } catch (e) {
      res[i] = { state: 'bad', text: e.message || '上传失败' }; badN++;
    }
    // 边传边回显，长批次不用干等
    const box = document.getElementById('up-list');
    if (box) box.innerHTML = upListHTML(files, res);
  }
  loadBooks(); loadShelf();
  // 全部成功才关弹窗；有失败/跳过的**留着名单和原因**，别让人以为都成了
  if (!badN && !skipN) {
    closeModal();
    toast(okN > 1 ? `已上传 ${okN} 本，已加入书架` : '上传成功，已加入书架');
    return;
  }
  const box = document.getElementById('up-list');
  if (box) { box.className = 'up-list stay'; box.innerHTML = upListHTML(files, res); }
  // 这里**不能**让按钮还能点「再来一次」—— 成功的那些已经进库了，再点一遍
  // 会变成同名重传（服务端会给新书加 (uid) 后缀另存一本），等于凭空多出几本。
  btn.disabled = false;
  btn.textContent = '关闭';
  btn.setAttribute('onclick', 'closeModal()');
  const parts = [`成功 ${okN} 本`];
  if (badN) parts.push(`失败 ${badN} 本`);
  if (skipN) parts.push(`跳过 ${skipN} 本`);
  toast(parts.join('，'));
}

// ---------- 分享 ----------
function showShare() {
  if (!requireLogin()) return;
  const lim = USER.limits || {};
  const maxDays = lim.share_max_days || 0;
  const maxLinks = lim.share_max_links || 0;
  let expOpts;
  if (maxDays > 0) {
    const cand = [1, 7, 15, 30, 90, 365, maxDays].filter(d => d <= maxDays);
    const uniq = cand.filter((d, i) => cand.indexOf(d) === i).sort((a, b) => a - b);
    expOpts = uniq.map(d => `<option value="${d}">${d} 天${d === maxDays ? '（上限）' : ''}</option>`).join('')
      + `<option value="custom">自定义…（≤${maxDays}天）</option>`;
  } else {
    expOpts = `<option value="0">永久有效</option><option value="1">1 天</option><option value="7">7 天</option><option value="30">30 天</option><option value="90">90 天</option><option value="custom">自定义…</option>`;
  }
  const hint = maxDays > 0 ? `<p class="muted" style="font-size:12px;margin:0 0 10px">本组分享限制：单个链接最长 ${maxDays} 天${maxLinks > 0 ? '，最多同时创建 ' + maxLinks + ' 个链接' : ''}</p>` : '';
  openModal(`<button class="close" onclick="closeModal()">✕</button><h3>分享《${esc(detailBook.title)}》</h3>
    ${hint}
    <div class="form-group"><label>访问密码（可留空）</label><input id="sh-pw" placeholder="留空则无需密码"></div>
    <div class="form-group"><label>有效期</label><select id="sh-exp" onchange="document.getElementById('sh-exp-custom').style.display = (this.value === 'custom') ? '' : 'none'">
      ${expOpts}</select>
      <input id="sh-exp-custom" type="number" min="1" max="${maxDays > 0 ? maxDays : 3650}" placeholder="自定义天数（≤${maxDays > 0 ? maxDays : 3650}）" style="display:none;margin-top:8px;width:100%;padding:10px;border:1px solid #e6e8ee;border-radius:8px"></div>
    <div class="form-group"><label>下载次数限制（0=不限，如 10 次后失效）</label><input id="sh-limit" type="number" min="0" max="99999" value="0"></div>
    <div class="form-group">
      <label style="display:flex;align-items:flex-start;gap:9px;cursor:pointer;font-weight:400;line-height:1.55">
        <input id="sh-online" type="checkbox" checked style="margin:3px 0 0;flex:0 0 auto;width:16px;height:16px;cursor:pointer">
        <span>允许在线阅读<span class="muted" style="display:block;font-size:12px;margin-top:3px">勾选后分享页会多一个「在线阅读」按钮，对方可直接在浏览器里看书；在线阅读不计下载次数</span></span>
      </label>
    </div>
    <button class="btn block" onclick="createShare()">生成分享链接</button>`);
}
async function createShare() {
  const fd = new FormData();
  fd.append('password', document.getElementById('sh-pw').value);
  let exp = document.getElementById('sh-exp').value;
  if (exp === 'custom') exp = document.getElementById('sh-exp-custom').value || '0';
  fd.append('expire_days', exp);
  fd.append('download_limit', document.getElementById('sh-limit').value || '0');
  fd.append('online_read', document.getElementById('sh-online').checked ? '1' : '0');
  try {
    const r = await api('/api/books/' + detailBook.id + '/share', { method: 'POST', body: fd });
    const url = location.origin + r.url;      // 分享链接按访问域名生成，不跟后台链路走
    openModal(`<button class="close" onclick="closeModal()">✕</button><h3>分享链接</h3>
      <input style="width:100%;padding:10px;border:1px solid #e6e8ee;border-radius:8px" value="${esc(url)}" readonly onclick="this.select()">
      <p class="muted">${r.password ? '访问密码：' + esc(document.getElementById('sh-pw').value) : '无需密码'} · ${r.expire_at ? '有效期至 ' + esc(r.expire_at) : '永久有效'}${r.download_limit > 0 ? ' · 限下载 ' + r.download_limit + ' 次' : ''}${r.online_read ? ' · 允许在线阅读' : ' · 仅下载'}</p>
      <button class="btn block" onclick="copyShare('${esc(url)}')">复制链接</button>`);
  } catch (e) { toast(e.message); }
}
function copyShare(url) {
  const done = () => toast('已复制');
  const fallback = () => {
    const ta = document.createElement('textarea');
    ta.value = url;
    ta.style.position = 'fixed'; ta.style.left = '-9999px'; ta.style.top = '0';
    document.body.appendChild(ta);
    ta.focus(); ta.select();
    let ok = false;
    try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
    document.body.removeChild(ta);
    if (ok) done(); else toast('复制失败，请手动复制');
  };
  if (navigator.clipboard && window.isSecureContext) {
    navigator.clipboard.writeText(url).then(done, fallback);
  } else {
    fallback();
  }
}

async function loadMyShares() {
  const wrap = document.getElementById('my-shares');
  if (GUEST) { wrap.innerHTML = '<p class="muted">注册账号后即可生成分享链接</p>'; return; }
  try {
    const list = await api('/api/shares');
    if (!list.length) { wrap.innerHTML = '<p class="muted">暂无分享</p>'; return; }
    wrap.innerHTML = list.map(s => {
      const status = s.expired ? '<span style="color:#e5484d">已过期</span>'
                   : s.exhausted ? '<span style="color:#e5484d">已失效（次数用完）</span>'
                   : '<span style="color:#1a9e54">有效</span>';
      const exp = s.expire_at ? ' · ' + esc(s.expire_at.slice(0, 10)) + ' 到期' : ' · 永久有效';
      const stat = ` · 浏览 ${s.access_count || 0} 次` + (s.download_limit > 0 ? ` · 下载 ${s.download_count}/${s.download_limit} 次` : ` · 下载 ${s.download_count} 次`);
      const full = location.origin + s.url;
      return `<div class="list-item" style="cursor:default">
        <div class="txt"><div class="tt">${esc(s.title)}</div>
        <div class="aa">${status}${exp}${stat} · ${s.has_password ? '🔒' : '🔓'} ${esc(s.url)}</div></div>
        <div style="display:flex;gap:6px">
          <button class="btn ghost sm" onclick="copyShare('${esc(full)}')">复制</button>
          <button class="btn ghost sm" onclick="openShare('${esc(full)}')">打开</button>
          <button class="btn danger sm" onclick="delShare('${s.token}')">撤销</button>
        </div></div>`;
    }).join('');
  } catch (e) {}
}
async function delShare(t) { await api('/api/shares/' + t, { method: 'DELETE' }); loadMyShares(); }
function openShare(url) { window.open(url, '_blank'); }

// ---------- 我的消息（站内通知 / 私信 / 未读红点） ----------
const MSG_PAGE_SIZE = 5;
const MSG_KINDS = {
  pm: ['私信', 'pm'], pm_sent: ['已发送', 'sent'], share: ['分享', 'share'],
  booklist: ['书单', 'bl'], review: ['审核', 'review'], report: ['举报', 'report'],
  system: ['系统', 'sys'],
};
let msgItems = [], msgPage = 1, msgPages = 1, msgUnread = 0, msgReplyTo = null, msgDotTimer = null;
// 消息筛选：all 全部 / user 用户消息（有发送人的私信、分享）/ system 系统消息（审核结果、群发等）
let msgScope = 'all';

// 切换「用户消息 / 系统消息」筛选：回到第 1 页重新拉取（分页数会随筛选变化）
function setMsgScope(s) {
  msgScope = (s === 'user' || s === 'system') ? s : 'all';
  document.querySelectorAll('#me-msg-filter .chip').forEach(b => {
    b.classList.toggle('active', (b.dataset.scope || '') === msgScope);
  });
  loadMessages(1);
}

function setMsgDot(n) {
  msgUnread = n || 0;
  ['nav-me-dot', 'tab-me-dot'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.style.display = msgUnread > 0 ? '' : 'none';
  });
}
async function refreshMsgDot() {
  if (GUEST || !TOKEN) { setMsgDot(0); return; }
  try {
    const d = await api('/api/messages/unread');
    setMsgDot(d.unread || 0);
    msgNotifyCheck();   // APP 里：顺手让原生判一次要不要弹系统通知/更新角标
  } catch (e) { /* 静默 */ }
}
function startMsgPoll() {
  if (msgDotTimer) return;
  refreshMsgDot();
  msgDotTimer = setInterval(refreshMsgDot, 60000);   // 每分钟刷新「我的」红点
}

// ---------- APP：新消息的系统通知 + 桌面角标 ----------
// 只在「云阅读」APP（Capacitor 壳）里生效，浏览器里这些都空转。
// 判断「有没有新消息、要不要弹」的逻辑全在原生（MessageNotifier.java），
// 网页这边只做三件事：登录后把令牌交出去、轮询红点时顺手催一次、退出登录收干净。
// 之所以不在网页里判断：App 被划掉后网页就死了，而角标是系统层的东西，
// 后台那份轮询（AlarmManager）走的是与这里同一套原生代码，同一条消息不会响两遍。
function msgNotifyPlugin() {
  try {
    const C = window.Capacitor;
    return (C && C.Plugins && C.Plugins.MessageNotify) || null;
  } catch (e) { return null; }
}
// ★ 每次调用都带 .catch()：V3.6 及更早的 APK **没有**这个插件（网页代码却是最新的），
//   插件调用失败是**异步 reject**，try/catch 抓不住，会变成 unhandledrejection 噪声。
//   老 APK 上这些调用必须静默失败，功能降级但不报错。
function msgNotifyStart() {
  const p = msgNotifyPlugin();
  if (!p || GUEST || !TOKEN) return;
  try { Promise.resolve(p.start({ baseUrl: location.origin, token: TOKEN })).catch(() => {}); }
  catch (e) { /* 静默 */ }
}
function msgNotifyStop() {
  const p = msgNotifyPlugin();
  if (!p) return;
  try { Promise.resolve(p.stop()).catch(() => {}); } catch (e) { /* 静默 */ }
}
function msgNotifyCheck() {
  const p = msgNotifyPlugin();
  if (!p) return;
  try { Promise.resolve(p.check()).catch(() => {}); } catch (e) { /* 静默 */ }
}
// 点系统通知进来时由原生调用（MainActivity → window.__openMsgPage）。
// ★ 必须返回 'ok'：原生靠它判断「网页准备好了没有」，返回别的会每 500ms 重试一次。
window.__openMsgPage = function () {
  try {
    if (GUEST) { showAuth(); return 'ok'; }   // 没登录：先让它登录
    switchPage('me');
    loadMessages(1);
    const card = document.getElementById('me-msg-card');
    if (card) setTimeout(() => card.scrollIntoView({ behavior: 'smooth', block: 'start' }), 320);
  } catch (e) { /* 静默 */ }
  return 'ok';
};
async function loadMessages(page) {
  const wrap = document.getElementById('me-msg-list');
  if (!wrap) return;
  if (GUEST) {
    wrap.innerHTML = '<p class="muted" style="padding:16px 0;text-align:center">登录后可查看站内消息</p>';
    const pg = document.getElementById('me-msg-pager'); if (pg) pg.innerHTML = '';
    setMsgDot(0); return;
  }
  msgPage = Math.max(1, page || 1);
  try {
    const d = await api('/api/messages?page=' + msgPage + '&page_size=' + MSG_PAGE_SIZE
                        + '&scope=' + encodeURIComponent(msgScope));
    msgItems = d.items || []; msgPages = d.pages || 1;
    setMsgDot(d.unread || 0);
    renderMessages();
  } catch (e) {
    wrap.innerHTML = '<p class="muted" style="padding:16px 0;text-align:center">消息加载失败</p>';
  }
}
function renderMessages() {
  const wrap = document.getElementById('me-msg-list');
  const pager = document.getElementById('me-msg-pager');
  const badge = document.getElementById('me-msg-unread');
  const readAll = document.getElementById('me-msg-readall');
  if (badge) { badge.style.display = msgUnread ? '' : 'none'; badge.textContent = msgUnread ? '未读 ' + msgUnread : ''; }
  if (readAll) readAll.style.display = msgUnread ? '' : 'none';
  if (!msgItems.length) {
    wrap.innerHTML = '<p class="muted" style="padding:16px 0;text-align:center">暂无消息</p>';
    if (pager) pager.innerHTML = '';
    return;
  }
  // ★ 每条消息**一行**：未读点 + 类型 + 标题 + 发送人 + 时间（+ 回复）。
  //   原来一条占三行（标题/时间、正文摘要、来自谁+回复按钮），一屏看不了几条。
  //   正文摘要去掉 —— 点标题就会弹出完整内容，列表里没必要先剧透一行。
  //
  //   ★ 发送人只在「标题里没有提到他」时才单独显示：私信/回复的标题本来就写成
  //     「来自 IE6261 的回复」，同一行里再放一遍昵称纯属浪费手机上那点宽度。
  //     信息没丢 —— 昵称就在标题里。
  wrap.innerHTML = msgItems.map((m, i) => {
    const k = MSG_KINDS[m.kind] || MSG_KINDS.system;
    const canReply = (m.kind === 'pm' && m.from_id);
    const title = String(m.title || '');
    const fn = String(m.from_name || '');
    // pm_sent 的 from_id 其实是**收件人**，别写成「来自」
    const fromTxt = (m.kind === 'pm_sent' ? '发给 ' : '来自 ') + fn;
    const showFrom = !!(m.from_id && fn) && title.indexOf(fn) < 0;
    return `<div class="msg-item${m.is_read ? '' : ' unread'}" onclick="openMsg(${i})">
      ${m.is_read ? '' : '<i class="msg-new"></i>'}
      <span class="msg-kind ${k[1]}">${k[0]}</span>
      <span class="msg-title" title="${esc(title)}">${esc(title)}</span>
      ${showFrom ? `<span class="msg-from">${esc(fromTxt)}</span>` : ''}
      <span class="msg-time">${esc((m.created_at || '').slice(5, 16))}</span>
      ${canReply ? `<a class="msg-reply" onclick="event.stopPropagation();replyMsg(${i})">回复</a>` : ''}
    </div>`;
  }).join('');
  if (!pager) return;
  if (msgPages <= 1) { pager.innerHTML = ''; return; }
  pager.innerHTML = `<button onclick="loadMessages(${msgPage - 1})" ${msgPage <= 1 ? 'disabled' : ''}>‹</button>
    <span style="display:inline-flex;align-items:center;gap:6px;font-size:14px;color:var(--muted)">第
      <input id="msg-pager-input" type="number" min="1" max="${msgPages}" value="${msgPage}" style="width:40px;padding:6px 4px;border:1.5px solid var(--line);border-radius:8px;text-align:center;font-size:14px" onkeydown="if(event.key==='Enter')jumpMsgPage()">
      / ${msgPages} 页</span>
    <button class="btn sm" onclick="jumpMsgPage()">跳转</button>
    <button onclick="loadMessages(${msgPage + 1})" ${msgPage >= msgPages ? 'disabled' : ''}>›</button>`;
}
function jumpMsgPage() {
  const inp = document.getElementById('msg-pager-input');
  let n = parseInt(inp && inp.value, 10);
  if (!n || n < 1) n = 1;
  if (n > msgPages) n = msgPages;
  loadMessages(n);
}
async function openMsg(i) {
  const m = msgItems[i];
  if (!m) return;
  if (!m.is_read) {
    try {
      const r = await api('/api/messages/read', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ids: [m.id] }) });
      m.is_read = 1;
      setMsgDot(r.unread || 0);   // 立即刷新「我的」红点，不必等下一次轮询
      renderMessages();           // 去掉未读高亮
    } catch (e) { /* 静默 */ }
  }
  showMsgDetail(i);
}
// 消息正文渲染：整体转义（防 XSS）→ 指定词语变链接 → 裸网址变链接 → 换行转 <br>
// linkUrl/linkText：把正文里的 linkText（如「使用介绍」）指向 linkUrl，正文本身写纯文字即可
function msgBodyHtml(body, linkUrl, linkText) {
  let h = esc(String(body == null ? '' : body));
  const A = (u, t) => `<a href="${esc(u)}" target="_blank" rel="noopener noreferrer">${t}</a>`;
  const url = String(linkUrl || ''), word = String(linkText || '');
  // 1) 「使用介绍」这四个字直接变成链接（用 split/join，避免词语里的正则特殊字符）
  if (word && /^https?:\/\//i.test(url)) {
    const w = esc(word);
    if (h.indexOf(w) >= 0) h = h.split(w).join(A(url, w));
  }
  // 2) 兼容 [文字](链接) 写法，链接只允许 http/https
  h = h.replace(/\[([^\]\n]+)\]\(([^)\s]+)\)/g, (m, text, u) => {
    const uu = u.replace(/&amp;/g, '&');
    return /^https?:\/\//i.test(uu) ? A(uu, text) : m;
  });
  // 3) 裸网址自动变链接（已在 href="..." 里的会因前一个字符是引号而被跳过）
  h = h.replace(/(^|[^"'=>])(https?:\/\/[^\s<>"）)]+)/g, (m, pre, u) => pre + A(u, u));
  return h.replace(/\n/g, '<br>');
}
function showMsgDetail(i) {
  const m = msgItems[i];
  if (!m) return;
  const k = MSG_KINDS[m.kind] || MSG_KINDS.system;
  const canReply = (m.kind === 'pm' && m.from_id);
  // ★ 书单相关的两条消息（「您的书单收到新回复」/「新的书单回复待审查」）统一
  //   直达**那一篇**书单 `#/booklist/<id>`：
  //   · 后端现在发的 link 就是这个；
  //   · 但**已经发出去的老消息**里，作者那条写的是 "#/booklists"（只到列表，
  //     还得自己翻出是哪一篇），管理员那条压根没有 link（弹窗底部只有一个
  //     「关闭」，收到「待审查」提醒却点不进去）。
  //   这两类消息都带 ref_type/ref_id，所以这里按 ref 兜一层 ——
  //   老消息也照样点得对，不必去改历史数据。
  let link = String(m.link || '');
  if (m.ref_type === 'booklist' && m.ref_id) link = '#/booklist/' + m.ref_id;
  openModal(`<button class="close" onclick="closeModal()">✕</button>
    <h3 style="margin-bottom:8px">${esc(m.title || '消息详情')}</h3>
    <div class="msg-detail-meta">
      <span class="msg-kind ${k[1]}">${k[0]}</span>
      <span class="muted">${m.from_id ? '来自 ' + esc(m.from_name || '') : '系统消息'}</span>
      <span class="muted">${esc(m.created_at || '')}</span>
    </div>
    <div class="msg-detail-body">${m.body ? msgBodyHtml(m.body, m.ref_type === 'welcome' ? m.link : '', '使用介绍') : '（无正文）'}</div>
    <div class="msg-detail-btns">
      ${link ? `<button class="btn" onclick="closeModal();gotoMsgLink('${esc(link)}')">前往查看</button>` : ''}
      ${canReply ? `<button class="btn ${link ? 'ghost' : ''}" onclick="replyMsg(${i})">回复</button>` : ''}
      <button class="btn ghost" onclick="closeModal()">关闭</button>
    </div>`);
}
// 消息里带的跳转地址（如 #/shelf、#/booklist/18、外链 http(s)://…）
function gotoMsgLink(link) {
  let h = String(link || '').trim();
  if (!h) return;
  // 完整网址（消息里也可能带外链）→ 按站内一贯做法开新标签
  if (/^https?:\/\//i.test(h)) { window.open(h, '_blank', 'noopener'); return; }
  if (h[0] !== '#') h = '#/' + h.replace(/^\/+/, '');
  _explicitNav = true;      // 与 switchPage() 一致：点链接算「显式导航」
  if (location.hash === h) {
    // ★ 已经就在这个地址上：不能走 switchPage() —— 它在「hash 相等」时只调
    //   switchPageView()，而那只认 6 个主页面，`#/booklist/18` 这种详情路由
    //   会被打回书库（点「前往查看」反而跳到了书库）。直接让路由重跑一遍。
    route();
    return;
  }
  location.hash = h;
}
async function markAllMsgsRead() {
  try {
    await api('/api/messages/read', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
    loadMessages(1); toast('已全部标记为已读');
  } catch (e) { toast(e.message); }
}
function replyMsg(i) {
  const m = msgItems[i];
  if (m) showComposeMsg(m.from_name, m.id);
}
function showComposeMsg(to, replyTo) {
  const nick = USER ? (USER.name || USER.username || '') : '';
  msgReplyTo = replyTo || null;
  // 群发只对管理员开放，回复时不允许群发
  const canBroadcast = !!(USER && USER.role === 'admin') && !msgReplyTo;
  openModal(`<button class="close" onclick="closeModal()">✕</button>
    <h3>${msgReplyTo ? '回复消息' : '发送站内消息'}</h3>
    <div class="form-group">
      <label>接收人昵称</label>
      <div class="msg-to-row">
        <input id="msg-to" value="${esc(to || '')}" ${msgReplyTo ? 'readonly' : ''} placeholder="输入对方昵称">
        ${canBroadcast ? `<label class="bc-check"><input type="checkbox" id="msg-broadcast" onchange="toggleBroadcast()"><span>群发</span></label>` : ''}
      </div>
    </div>
    <div class="form-group"><label>内容</label>
      <textarea id="msg-content" rows="4" placeholder="请输入消息内容（最多 1000 字）"
        style="width:100%;box-sizing:border-box;padding:10px 12px;border:1.5px solid var(--line);border-radius:10px;font-size:15px;font-family:inherit;resize:vertical"></textarea></div>
    <p class="muted" style="margin:-6px 0 12px;font-size:12px" id="msg-tip">将以昵称「${esc(nick)}」发送给对方，对方会在「我的消息」中收到。</p>
    <button class="btn block" onclick="sendMsg()">发送</button>`);
}
// 勾选「群发」：昵称输入框置灰，并说明将发给全部会员
function toggleBroadcast() {
  const el = document.getElementById('msg-broadcast');
  const on = !!(el && el.checked);
  const to = document.getElementById('msg-to');
  const tip = document.getElementById('msg-tip');
  const box = document.querySelector('.bc-check');
  if (to) {
    to.disabled = on;
    if (on) to.value = '';
    to.placeholder = on ? '群发时不需填写' : '输入对方昵称';
  }
  if (box) box.classList.toggle('on', on);
  if (tip) tip.textContent = on
    ? '将发送给全部启用中的会员（不含你自己），发出后无法撤回，请确认内容无误。'
    : `将以昵称「${USER ? (USER.name || USER.username || '') : ''}」发送给对方，对方会在「我的消息」中收到。`;
}
async function sendMsg() {
  const bcEl = document.getElementById('msg-broadcast');
  const broadcast = !!(bcEl && bcEl.checked);
  const to = ((document.getElementById('msg-to') || {}).value || '').trim();
  const content = (document.getElementById('msg-content').value || '').trim();
  if (!content) { toast('请输入消息内容'); return; }
  if (!broadcast && !to) { toast('请输入接收人昵称'); return; }
  if (broadcast && !confirm('确定群发？\n\n这条消息会发给全部启用中的会员，发出后无法撤回。')) return;
  const body = { content };
  if (broadcast) body.broadcast = true; else body.to = to;
  if (msgReplyTo) body.reply_to = msgReplyTo;
  try {
    const r = await api('/api/messages', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    closeModal(); toast(r.message || '已发送');
    msgReplyTo = null;
    if (document.getElementById('page-me') && !document.getElementById('page-me').classList.contains('hidden')) loadMessages(1);
  } catch (e) { toast(e.message); }
}

// ---------- 笔记（划线/批注/书签/书内搜索，云端同步到 WebDAV） ----------
let notesBooks = [];
let notesSel = {};
let curNoteBookId = null, curNoteData = null, curNoteTitle = '';
function selectedNoteIds() {
  return (notesBooks.items || []).filter(n => notesSel[n.book_id]).map(n => n.book_id);
}
function updNotesBar() {
  const sel = selectedNoteIds().length;
  const all = (notesBooks.items || []).length;
  const sa = document.getElementById('notes-sel-all');
  if (sa) sa.checked = all > 0 && sel === all;
  const c = document.getElementById('notes-sel-count');
  if (c) c.textContent = sel ? '已选 ' + sel + ' 本' : '';
}
function toggleNoteSel(bookId, checked) { notesSel[bookId] = checked; updNotesBar(); }
function toggleAllNotes(checked) {
  (notesBooks.items || []).forEach(n => notesSel[n.book_id] = checked);
  document.querySelectorAll('#notes-list .note-sel').forEach(cb => { cb.checked = checked; });
  updNotesBar();
}
async function loadNotes() {
  const wrap = document.getElementById('notes-list');
  const detail = document.getElementById('notes-detail');
  if (detail) detail.classList.add('hidden');
  curNoteBookId = null; curNoteData = null;
  notesSel = {};
  if (GUEST) {
    wrap.innerHTML = '<p class="muted" style="padding:20px 0">暂无笔记。注册账号后，阅读时选中文字即可划线、写批注，点工具栏「签」添加书签。</p>';
    return;
  }
  try {
    notesBooks = await api('/api/notes');
    const list = notesBooks.items || [];
    if (!list.length) {
      wrap.innerHTML = '<p class="muted" style="padding:20px 0">暂无笔记。阅读时选中文字即可划线/写批注，点工具栏「签」添加书签。</p>';
      return;
    }
    wrap.innerHTML = `
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:10px;flex-wrap:wrap">
        <label style="display:inline-flex;align-items:center;gap:6px;font-size:13px;cursor:pointer">
          <input type="checkbox" id="notes-sel-all" onchange="toggleAllNotes(this.checked)"> 全选
        </label>
        <span id="notes-sel-count" class="muted" style="font-size:13px"></span>
        <span style="flex:1"></span>
        <button class="btn sm" onclick="batchExportNotes()">⬇ 批量导出</button>
        <button class="btn danger sm" onclick="batchDeleteNotes()">🗑 批量删除</button>
      </div>
      ${list.map(n => `<div class="list-item">
        <input type="checkbox" class="note-sel" onchange="toggleNoteSel(${n.book_id}, this.checked)">
        <div class="txt" style="cursor:pointer" onclick="showNoteBook(${n.book_id})">
          <div class="tt">📝 ${esc(n.title)}</div>
          <div class="aa">${esc(n.author || '')} · 最近更新 ${esc((n.updated_at||'').slice(0,16))}</div>
        </div>
        <div style="color:#999">→</div>
      </div>`).join('')}`;
  } catch (e) { wrap.innerHTML = '<p class="muted">加载失败</p>'; }
}
async function showNoteBook(bookId) {
  const wrap = document.getElementById('notes-list');
  const detail = document.getElementById('notes-detail');
  wrap.classList.add('hidden');
  detail.classList.remove('hidden');
  detail.innerHTML = '<p class="muted">加载中…</p>';
  try {
    const d = await api('/api/notes/' + bookId);
    const bk = (notesBooks.items || []).find(n => n.book_id === bookId) || {};
    curNoteBookId = bookId;
    curNoteData = d;
    curNoteTitle = bk.title || '';
    renderNoteBook();
  } catch (e) { detail.innerHTML = '<p class="muted">' + esc(e.message) + '</p>'; }
}
function renderNoteBook() {
  const detail = document.getElementById('notes-detail');
  const d = curNoteData || {};
  const bookId = curNoteBookId;
  const loc = (t) => encodeURIComponent(String(t || '').slice(0, 60));
  const num = (v) => (typeof v === 'number' && isFinite(v)) ? Math.max(0, Math.min(1, v)) : 'null';   // 章内比例 → JS 字面量
  const hls = (d.highlights || []).map((h, i) => `
    <div class="note-item" style="display:flex;align-items:flex-start;gap:10px">
      <div style="flex:1;min-width:0;cursor:pointer" onclick="jumpToNote(${bookId}, ${h.idx||0}, '${loc(h.text)}', ${num(h.frac)})">
        <div class="ni-type">🖍️ 划线</div>
        <div class="ni-text">${esc(h.text || '')}</div>
        ${h.note ? '<div class="ni-note">💬 ' + esc(h.note) + '</div>' : ''}
        <div class="ni-meta">${esc(h.chapter || '')} · ${esc((h.created_at||'').slice(0,16))}</div>
      </div>
      <button class="btn danger sm" style="flex-shrink:0" onclick="delNoteItem('highlights', ${i})">删除</button>
    </div>`).join('');
  const nts = (d.notes || []).map((n, i) => `
    <div class="note-item" style="display:flex;align-items:flex-start;gap:10px">
      <div style="flex:1;min-width:0;cursor:pointer" onclick="jumpToNote(${bookId}, ${n.idx||0}, '${loc(n.text)}', ${num(n.frac)})">
        <div class="ni-type">📝 批注</div>
        <div class="ni-text">${esc(n.text || '')}</div>
        <div class="ni-meta">${esc(n.chapter || '')} · ${esc((n.created_at||'').slice(0,16))}</div>
      </div>
      <button class="btn danger sm" style="flex-shrink:0" onclick="delNoteItem('notes', ${i})">删除</button>
    </div>`).join('');
  const bms = (d.bookmarks || []).map((m, i) => {
    return `
    <div class="note-item" style="display:flex;align-items:flex-start;gap:10px">
      <div style="flex:1;min-width:0;cursor:pointer" onclick="jumpToNote(${bookId}, ${m.idx||0}, null, ${num(m.frac)})">
        <div class="ni-type">🔖 书签</div>
        <div class="ni-text">${esc(m.label || m.chapter || '书签')}</div>
        <div class="ni-meta">${esc(m.chapter || '')} · ${esc((m.created_at||'').slice(0,16))}</div>
      </div>
      <button class="btn danger sm" style="flex-shrink:0" onclick="delNoteItem('bookmarks', ${i})">删除</button>
    </div>`;
  }).join('');
  const sqs = (d.searches || []).slice(0, 20).map(s => `<span class="tag" style="margin:3px">🔍 ${esc(s.q)}</span>`).join('');
  const total = (d.highlights || []).length + (d.notes || []).length + (d.bookmarks || []).length;
  detail.innerHTML = `
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px;flex-wrap:wrap">
      <button class="btn ghost sm" onclick="backToNotes()">← 返回</button>
      <h3 style="margin:0">${esc(curNoteTitle)}</h3>
      <span style="flex:1"></span>
      <button class="btn sm" onclick="exportNotes()">⬇ 导出</button>
      <button class="btn ghost sm" onclick="clearBookNotes(${bookId})">清空</button>
    </div>
    ${total ? `<div class="card" style="padding:12px">${hls}${nts}${bms}</div>` : '<p class="muted">暂无划线/批注/书签</p>'}
    ${sqs ? `<div class="card" style="padding:12px;margin-top:10px"><h4 style="margin:0 0 8px">书内搜索记录</h4>${sqs}</div>` : ''}`;
}
async function delNoteItem(type, index) {
  const arr = (curNoteData && curNoteData[type]) || [];
  if (!arr[index]) return;
  arr.splice(index, 1);
  try {
    await api('/api/notes/' + curNoteBookId, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(curNoteData) });
    renderNoteBook(); toast('已删除');
  } catch (e) { toast(e.message); }
}
function backToNotes() {
  document.getElementById('notes-list').classList.remove('hidden');
  document.getElementById('notes-detail').classList.add('hidden');
}
function jumpToNote(bookId, idx, locate, pos) {
  let url = '/reader?id=' + bookId + '&idx=' + (idx || 0);
  if (locate) url += '&locate=' + locate;
  // 书签没有可检索的文字，必须带上章内比例 pos 才能在章内精确定位；
  // 划线/批注也带一份，作为文字定位失败时的兜底
  if (typeof pos === 'number' && isFinite(pos)) url += '&pos=' + Math.max(0, Math.min(1, pos));
  location.href = url;
}
// 导出笔记为 Markdown（通用、可读性好、便于归档与二次编辑）
function noteMarkdown(title, d) {
  const L = [];
  L.push('# 笔记导出：《' + title + '》');
  L.push('');
  L.push('导出时间：' + new Date().toLocaleString());
  L.push('');
  const hls = d.highlights || [], nts = d.notes || [], bms = d.bookmarks || [], sqs = d.searches || [];
  if (hls.length) {
    L.push('## 划线'); L.push('');
    hls.forEach(h => {
      L.push('- ' + (h.text || ''));
      if (h.note) L.push('  > 批注：' + h.note);
      L.push('  （' + (h.chapter || '') + ' · ' + (h.created_at || '') + '）');
      L.push('');
    });
  }
  if (nts.length) {
    L.push('## 批注'); L.push('');
    nts.forEach(n => { L.push('- ' + (n.text || '') + '  （' + (n.chapter || '') + ' · ' + (n.created_at || '') + '）'); L.push(''); });
  }
  if (bms.length) {
    L.push('## 书签'); L.push('');
    bms.forEach(m => { L.push('- ' + (m.label || m.chapter || '书签') + '  （' + (m.chapter || '') + ' · ' + (m.created_at || '') + '）'); L.push(''); });
  }
  if (sqs.length) {
    L.push('## 书内搜索记录'); L.push('');
    sqs.forEach(s => { L.push('- ' + (s.q || '') + '  （' + (s.created_at || '') + '）'); });
    L.push('');
  }
  return L.join('\n');
}
function downloadText(filename, text) {
  const blob = new Blob([text], { type: 'text/markdown;charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  document.body.appendChild(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 600);
}
function exportNotes() {
  downloadText((curNoteTitle || '笔记') + '-笔记.md', noteMarkdown(curNoteTitle, curNoteData || {}));
  toast('已导出 Markdown');
}
// 批量导出：所选多本书的笔记合并为一个 Markdown
// 北京时间当天日期（后端时间戳统一为 UTC+8，toISOString() 是 UTC，凌晨会差一天）
function bjToday() { return new Date(Date.now() + 8 * 3600 * 1000).toISOString().slice(0, 10); }
async function batchExportNotes() {
  const ids = selectedNoteIds();
  if (!ids.length) { toast('请先勾选要导出的书籍'); return; }
  const parts = [];
  for (const bid of ids) {
    const bk = (notesBooks.items || []).find(n => n.book_id === bid) || {};
    try {
      const d = await api('/api/notes/' + bid);
      parts.push(noteMarkdown(bk.title || ('书籍#' + bid), d));
    } catch (e) { /* 单本失败跳过 */ }
  }
  if (!parts.length) { toast('所选书籍没有可导出的笔记'); return; }
  downloadText('笔记导出-' + parts.length + '本-' + bjToday() + '.md', parts.join('\n\n---\n\n'));
  toast('已导出 ' + parts.length + ' 本书的笔记');
}
// 批量删除：所选多本书的笔记一并清除
async function batchDeleteNotes() {
  const ids = selectedNoteIds();
  if (!ids.length) { toast('请先勾选要删除的书籍'); return; }
  if (!confirm('确认删除所选 ' + ids.length + ' 本书的全部笔记、划线与书签？此操作不可恢复。')) return;
  try {
    const r = await api('/api/notes/batch-delete', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ids }) });
    toast('已删除 ' + r.done + ' 本书的笔记');
    loadNotes();
  } catch (e) { toast(e.message); }
}
async function clearBookNotes(bookId) {
  if (!confirm('确认清空这本书的全部笔记、划线与书签？')) return;
  try { await api('/api/notes/' + bookId, { method: 'DELETE' }); loadNotes(); }
  catch (e) { toast(e.message); }
}

// ---------- 书架 ----------
let shelfData = null;
let shelfCat = '';  // '' 全部 | 'uncat' 未分类 | 数字字符串 = collection id
let shelfPage = 1;  // 书架收藏分页（桌面端每页 12 本）
function setShelfCat(c) { shelfCat = c; shelfPage = 1; loadShelf(); }
// 分类拖拽排序
let dragCatId = null;
function dragCat(e, id) { dragCatId = id; e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', String(id)); }
function allowDrop(e) { e.preventDefault(); }
async function dropCat(e, targetId) {
  e.preventDefault();
  if (dragCatId == null || dragCatId === targetId) { dragCatId = null; return; }
  const cols = ((shelfData || {}).collections || []).slice();
  const from = cols.findIndex(c => c.id === dragCatId);
  const to = cols.findIndex(c => c.id === targetId);
  if (from < 0 || to < 0) { dragCatId = null; return; }
  const [moved] = cols.splice(from, 1);
  cols.splice(to, 0, moved);
  const ids = cols.map(c => c.id).join(',');
  const fd = new FormData(); fd.append('ids', ids);
  try { await api('/api/shelf/collections/reorder', { method: 'PUT', body: fd }); toast('已排序'); }
  catch (err) { toast(err.message); }
  dragCatId = null;
  loadShelf();
}
async function loadShelf() {
  const wrap = document.getElementById('shelf-list');
  const cats = document.getElementById('shelf-cats');
  const pager = document.getElementById('shelf-pager');
  if (GUEST) {
    document.getElementById('shelf-quota').textContent = '注册后即可收藏图书';
    cats.innerHTML = '';
    pager.innerHTML = '';
    wrap.innerHTML = '<div class="empty">书架是空的。注册账号后，看中的书点击「＋书架」即可收藏 📚</div>';
    return;
  }
  shelfData = await api('/api/shelf');
  const r = shelfData;
  document.getElementById('shelf-quota').textContent = `已收藏 ${r.count} / ${r.quota} 本`;
  // 自定义分类 chips
  let chips = `<div class="chip${shelfCat === '' ? ' active' : ''}" onclick="setShelfCat('')">全部 (${r.count})</div>`;
  chips += `<div class="chip${shelfCat === 'uncat' ? ' active' : ''}" onclick="setShelfCat('uncat')">未分类 (${r.uncategorized})</div>`;
  // 管理员专属：待审的电子书共享申请（系统分类，不能拖拽排序/重命名）
  if (r.share_request_n > 0)
    chips += `<div class="chip chip-req${shelfCat === 'share_req' ? ' active' : ''}" onclick="setShelfCat('share_req')" title="会员申请转为公共书，可直接点开阅读后决定是否通过">共享申请 (${r.share_request_n})</div>`;
  (r.collections || []).forEach(c => {
    chips += `<div class="chip${shelfCat === String(c.id) ? ' active' : ''}" draggable="true"
      ondragstart="dragCat(event, ${c.id})" ondragover="allowDrop(event)" ondrop="dropCat(event, ${c.id})"
      onclick="setShelfCat('${c.id}')" title="拖拽可排序">${esc(c.name)} (${c.n})</div>`;
  });
  chips += `<div class="chip chip-add" onclick="manageCollections()">＋ 分类</div>`;
  document.getElementById('shelf-cats').innerHTML = chips;
  const isReq = shelfCat === 'share_req';
  if (!isReq && !r.items.length) { wrap.innerHTML = '<div class="empty">书架还是空的，去书库挑选喜欢的书吧 📚</div>'; pager.innerHTML = ''; return; }
  let items = r.items;
  if (isReq) items = r.share_requests || [];
  else if (shelfCat === 'uncat') items = r.items.filter(b => b.collection_id == null);
  else if (shelfCat !== '') items = r.items.filter(b => String(b.collection_id) === String(shelfCat));
  if (!items.length) {
    wrap.innerHTML = isReq ? '<div class="empty">当前没有待审核的共享申请</div>' : '<div class="empty">该分类下暂无藏书</div>';
    pager.innerHTML = ''; return;
  }
  // 分页：桌面端与移动端（App/移动 web）统一每页最多 12 本
  const pageSize = 12;
  const pages = Math.max(1, Math.ceil(items.length / pageSize));
  if (shelfPage > pages) shelfPage = pages;
  const slice = items.slice((shelfPage - 1) * pageSize, shelfPage * pageSize);
  wrap.innerHTML = slice.map(b => {
    const cover = b.cover_url ? `<img class="cover" src="${esc(coverUrl(b.cover_url, b.updated_at))}" loading="lazy">` : placeholderCoverHTML(b);
    if (isReq) {
      // 共享申请：不显示「编辑分类」按钮，改为标注申请人，点开即可阅读判断
      return `<div class="shelf-item" onclick="openDetail(${b.id})">${cover}
        <div class="sinfo"><div class="t">${esc(b.title)}</div><div class="a">${esc(b.author || '')}</div>
          <div style="margin-top:6px"><span class="tag tag-req">共享申请</span></div>
          <div class="a" style="margin-top:4px">由 ${esc(b.requester_name || '会员')} 申请于 ${blTime(b.requested_at)}</div>
        </div></div>`;
    }
    const colTag = b.collection_name ? `<div style="margin-top:6px"><span class="tag">${esc(b.collection_name)}</span></div>` : '';
    return `<div class="shelf-item" onclick="openDetail(${b.id})">${cover}
      <button class="shelf-edit" title="编辑" onclick="event.stopPropagation();editShelfBook(${b.id})">✏️</button>
      <div class="sinfo"><div class="t">${esc(b.title)}</div><div class="a">${esc(b.author || '')}</div>${colTag}</div></div>`;
  }).join('');
  pager.innerHTML = pages > 1
    ? `<button ${shelfPage <= 1 ? 'disabled' : ''} onclick="goShelfPage(${shelfPage - 1})">上一页</button><span>${shelfPage} / ${pages}</span><button ${shelfPage >= pages ? 'disabled' : ''} onclick="goShelfPage(${shelfPage + 1})">下一页</button>`
    : '';
}
function goShelfPage(p) { shelfPage = p; loadShelf(); }
function manageCollections() {
  const r = shelfData || { collections: [] };
  const list = (r.collections || []).filter(c => c.name !== '来自分享').map(c => `
    <div class="row between" style="margin:10px 0;padding-bottom:10px;border-bottom:1px solid #f0f0f0">
      <span>${esc(c.name)} <span class="muted">(${c.n} 本)</span></span>
      <div style="display:flex;gap:8px">
        <button class="btn ghost sm" onclick="renameCollection(${c.id}, '${esc(c.name)}')">重命名</button>
        <button class="btn danger sm" onclick="delCollection(${c.id}, '${esc(c.name)}')">删除</button>
      </div></div>`).join('');
  openModal(`<button class="close" onclick="closeModal()">✕</button><h3>书架分类管理</h3>
    <div style="display:flex;gap:8px;margin:12px 0">
      <input id="nc-name" placeholder="新分类名（如：在读 / 想读 / 已读）" style="flex:1">
      <button class="btn" onclick="createCollection()">＋ 新建</button>
    </div>
    ${list || '<p class="muted">还没有自定义分类</p>'}`);
}
async function createCollection() {
  const name = document.getElementById('nc-name').value.trim();
  if (!name) return toast('请输入分类名');
  const fd = new FormData(); fd.append('name', name);
  try { await api('/api/shelf/collections', { method: 'POST', body: fd }); closeModal(); loadShelf(); toast('已创建分类'); }
  catch (e) { toast(e.message); }
}
async function renameCollection(id, old) {
  const name = prompt('重命名分类：', old);
  if (!name || name.trim() === old) return;
  const fd = new FormData(); fd.append('name', name.trim());
  try { await api('/api/shelf/collections/' + id, { method: 'PUT', body: fd }); loadShelf(); toast('已重命名'); }
  catch (e) { toast(e.message); }
}
async function delCollection(id, name) {
  if (!confirm(`删除分类「${name}」？其中的书将变为“未分类”`)) return;
  try { await api('/api/shelf/collections/' + id, { method: 'DELETE' }); loadShelf(); toast('已删除'); }
  catch (e) { toast(e.message); }
}
function editShelfBook(id) {
  const r = shelfData || { collections: [] };
  const b = (r.items || []).find(x => x.id === id);
  const title = b ? b.title : '';
  const opts = '<option value="">未分类</option>' + (r.collections || []).map(c => `<option value="${c.id}">${esc(c.name)}</option>`).join('');
  openModal(`<button class="close" onclick="closeModal()">✕</button><h3>编辑 · ${esc(title)}</h3>
    <div class="form-group"><label>移动分类</label>
      <div style="display:flex;gap:8px">
        <select id="edit-cat" style="flex:1">${opts}</select>
        <button class="btn" onclick="doMoveBook(${id})">移动</button>
      </div>
    </div>
    <div class="form-group"><label>站内分享</label>
      <div style="display:flex;gap:8px">
        <input id="share-target" style="flex:1" placeholder="输入对方账号（用户名或ID）">
        <button class="btn" onclick="doSiteShare(${id})">分享</button>
      </div>
      <p class="muted" style="margin:6px 0 0;font-size:12px">对方「书架收藏」将自动出现「来自分享」分组</p>
    </div>
    <button class="btn danger block" style="margin-top:18px" onclick="doRemoveFromShelf(${id})">移出书架</button>`);
}
async function doMoveBook(id) {
  const v = document.getElementById('edit-cat').value;
  const fd = new FormData();
  if (v) fd.append('collection_id', v);
  try { await api('/api/shelf/' + id, { method: 'PUT', body: fd }); closeModal(); loadShelf(); toast('已移动'); }
  catch (e) { toast(e.message); }
}
async function doRemoveFromShelf(id) {
  if (!confirm('确定将此书移出书架？\n（仅从书架移除，不删除文件）')) return;
  try { await api('/api/shelf/' + id, { method: 'DELETE' }); closeModal(); loadShelf(); toast('已移出书架'); }
  catch (e) { toast(e.message); }
}
async function doSiteShare(id) {
  const target = document.getElementById('share-target').value.trim();
  if (!target) return toast('请输入对方账号');
  const fd = new FormData(); fd.append('target', target);
  try {
    const r = await api('/api/shelf/' + id + '/share', { method: 'POST', body: fd });
    toast(r.message || '已分享');
    document.getElementById('share-target').value = '';
  } catch (e) { toast(e.message); }
}

// ---------- 修改密码 ----------
function showChangePwd() {
  if (!requireLogin()) return;
  openModal(`<button class="close" onclick="closeModal()">✕</button><h3>修改密码</h3>
    <div class="form-group"><label>原密码</label><input type="password" id="cp-old"></div>
    <div class="form-group"><label>新密码</label><input type="password" id="cp-new"></div>
    <button class="btn block" onclick="savePwd()">保存</button>`);
}
async function savePwd() {
  const fd = new FormData();
  fd.append('old', document.getElementById('cp-old').value);
  fd.append('new', document.getElementById('cp-new').value);
  try { await api('/api/me/password', { method: 'PUT', body: fd }); closeModal(); toast('密码已修改'); }
  catch (e) { toast(e.message); }
}

// ---------- modal ----------
function openModal(html, wide) {
  document.getElementById('modal-mask').innerHTML = '<div class="modal' + (wide ? ' wide' : '') + '">' + html + '</div>';
  document.getElementById('modal-mask').classList.remove('hidden');
}
function closeModal() { document.getElementById('modal-mask').classList.add('hidden'); }

// ---------- 初始化 ----------
// 推广链接 /?invite=XXXX 带过来的邀请码：先记下，注册框一打开就填上
pickInviteFromUrl();
// 注册页的「必须 / 可选」提示要在用户点开注册之前就准备好
loadRegisterConfig();
// 已登录 → 正常进入；未登录 → 游客模式直接浏览首页（书库仅返回范例图书，可试读）
if (TOKEN && USER) { GUEST = false; enterMain(); }
else {
  GUEST = true;
  USER = { id: 0, role: 'guest', username: '游客', name: '', email: '', phone: '',
           group: { name: '游客' }, permissions: {}, limits: {} };
  enterMain();
}

// “我的”页按钮：App 内显示“检查更新”，网页端显示“下载APP”；App 另有“⟳ 刷新”强刷按钮
(function () {
  try {
    const isApp = !!(window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App);
    const bU = document.getElementById('btn-update-app');
    const bD = document.getElementById('btn-download-app');
    const bR = document.getElementById('btn-refresh');
    const bND = document.getElementById('nav-download-app');
    if (bU) bU.style.display = isApp ? '' : 'none';
    if (bD) bD.style.display = isApp ? 'none' : '';
    if (bR) bR.style.display = isApp ? '' : 'none';
    if (bND) bND.style.display = isApp ? 'none' : '';
    if (isApp) {
      // 监听原生“检查更新”结果（下载失败 / 无法自动安装等），用网页提示条告知用户
      const AppU = window.Capacitor.Plugins.AppUpdate;
      if (AppU && AppU.addListener) {
        AppU.addListener('updateResult', (d) => {
          hideUpdateProgress();
          if (d && d.ok === false) toast((d.message) || '更新失败，请重试');
          else if (d && d.message) toast(d.message);
        });
        AppU.addListener('updateProgress', (d) => showUpdateProgress(d));
      }
    }
  } catch (e) {}
})();

// App 强刷：给当前地址加时间戳重新加载，避开 WebView 缓存
function forceRefresh() {
  if (!(window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App)) return;
  toast('正在刷新…');
  const sep = location.search ? '&' : '?';
  location.href = location.pathname + location.search + sep + 'fs=' + Date.now() + location.hash;
}

// ---------- 更新下载进度条 ----------
function showUpdateProgress(d) {
  const el = document.getElementById('update-progress');
  if (!el) return;
  const p = Math.max(0, Math.min(100, Math.round((d && d.percent) || 0)));
  el.classList.remove('hidden');
  const bar = el.querySelector('.up-bar');
  const txt = el.querySelector('.up-text');
  if (bar) bar.style.width = p + '%';
  if (txt) txt.textContent = '正在下载更新包… ' + p + '%' + (d && d.downloaded ? '（' + fmtSize(d.downloaded) + '）' : '');
}
function hideUpdateProgress() {
  const el = document.getElementById('update-progress');
  if (el) el.classList.add('hidden');
}
function fmtSize(n) {
  if (!n) return '0B';
  if (n > 1048576) return (n / 1048576).toFixed(1) + 'MB';
  if (n > 1024) return (n / 1024).toFixed(0) + 'KB';
  return n + 'B';
}

// 安卓 App（Capacitor WebView）系统返回键：关弹窗 → 后退一页 → 退出 App
(function () {
  try {
    const App = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App;
    if (!App) return;
    App.addListener('backButton', () => {
      // 返回上一级（层级返回），不是浏览器式的「后退到上一个访问过的页面」。
      // 层级：首页 → 列表 → 详情 → 阅读/听书；退回时沿这条链往上走。
      if (appBack()) return;
      App.exitApp();        // 已在首页根，再按返回才退出 App
    });
  } catch (e) {}
})();

// ============================================================
// ---------- 书单讨论 ----------
// ============================================================
let blPage = 1, blPages = 1, blDetail = null, blQ = '', blTag = '';

// 文章标签：key → [中文名, 颜色类]
const BL_TAGS = { share: ['书单', 'share'], discuss: ['讨论', 'discuss'], find: ['分享', 'find'] };
function blTagBadge(t) {
  if (!t || !BL_TAGS[t]) return '';
  return `<span class="badge ${BL_TAGS[t][1]}">${BL_TAGS[t][0]}</span>`;
}
function blTagOptions(sel) {
  return Object.entries(BL_TAGS).map(([k, v]) =>
    `<label class="bl-tag-opt${k === sel ? ' on' : ''}" onclick="blTagPick(this)">
       <input type="radio" name="blf-tag" value="${k}" ${k === sel ? 'checked' : ''}><span>${v[0]}</span>
     </label>`).join('');
}
function blTagPick(label) {
  const r = label.querySelector('input');
  if (r) r.checked = true;
  document.querySelectorAll('.bl-tag-opt').forEach(x => x.classList.toggle('on', x === label));
}

// 极简 Markdown 渲染（书单正文：标题/列表/粗斜体/链接/图片/段落）
// 文章里的内嵌媒体：图片用 ![](url)，视频用同一个语法写视频地址即可（按扩展名判断）。
// 视频只认浏览器能直接播的容器，和后端 _VIDEO_EXTS 保持一致。
const BL_VIDEO_RE = /\.(mp4|webm|ogv|mov|m4v)(\?|#|$)/i;
function isVideoUrl(u) { return BL_VIDEO_RE.test(String(u || '')); }

function md(t) {
  if (!t) return '';
  let s = esc(t);
  s = s.replace(/^### (.*)$/gm, '<h4>$1</h4>')
       .replace(/^## (.*)$/gm, '<h3>$1</h3>')
       .replace(/^# (.*)$/gm, '<h2>$1</h2>')
       .replace(/^\- (.*)$/gm, '<li>$1</li>')
       .replace(/^\d+\. (.*)$/gm, '<li>$1</li>')
       .replace(/\*\*(.+?)\*\*/g, '<b>$1</b>')
       .replace(/\*(.+?)\*/g, '<i>$1</i>')
       // 图片/视频：居中和尺寸交给 .bl-content img/video 的 CSS 管，
       // 不在行内写样式 —— 行内样式改不动，且以前那样是贴着左边显示的。
       .replace(/!\[([^\]]*)\]\(([^)\s]+)\)/g, (m, alt, url) => isVideoUrl(url)
         ? `<video class="bl-media" src="${url}" controls playsinline preload="metadata"></video>`
         : `<img class="bl-media" src="${url}" alt="${alt}" loading="lazy">`)
       .replace(/\[(.+?)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
  s = s.replace(/(<li>[\s\S]*?<\/li>(\s*<li>[\s\S]*?<\/li>)*)/g, m => '<ul class="bl-ul">' + m + '</ul>');
  // 段落：连续两个换行分段，单个换行折行
  const parts = s.split(/\n{2,}/).filter(x => x.trim());
  if (parts.length <= 1) return s.replace(/\n/g, '<br>');
  return '<p>' + parts.map(x => x.replace(/\n/g, '<br>')).join('</p><p>') + '</p>';
}

function blTime(s) {
  if (!s) return '';
  const today = new Date();
  const d = new Date((s || '').replace(/-/g, '/'));
  if (isNaN(d)) return s;
  const pad = n => String(n).padStart(2, '0');
  if (d.toDateString() === today.toDateString()) return '今天 ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
  if (d.getFullYear() === today.getFullYear()) return `${d.getMonth() + 1}-${pad(d.getDate())}`;
  return `${d.getFullYear()}-${d.getMonth() + 1}-${pad(d.getDate())}`;
}

const BL_STATUS = { pending: ['待审核', 'no'], approved: ['已发布', 'ok'], rejected: ['未通过', 'bad'] };

function openBooklist(id) {
  const target = '#/booklist/' + id;
  if (location.hash !== target) location.hash = target;
  else openBooklistView(id);
}
async function openBooklistView(id) {
  blDetail = await api('/api/booklists/' + id);
  showView('booklist');
  renderBooklistDetail();
}
function closeBooklist() { location.hash = lastHash; }

function renderBooklistDetail() {
  const d = blDetail, a = d.article;
  const st = BL_STATUS[a.status] || ['', ''];
  const stBadge = a.status === 'approved' ? '' : `<span class="badge ${st[1]}">${st[0]}</span>`;
  const pinBadge = a.pinned ? '<span class="badge top">置顶</span>' : '';
  const tagBadge = blTagBadge(a.tag);
  let actions = '';
  const isMe = USER && (USER.id === a.author_id && USER.role !== 'guest');
  if ((USER && USER.role === 'admin') || (isMe && USER.role !== 'guest'))
    actions = `<button class="btn ghost sm" onclick="showEditBooklist(${a.id})">✏️ 编辑</button>
               <button class="btn danger sm" onclick="delBooklist(${a.id})">🗑 删除</button>`;
  if (USER && USER.role === 'admin')
    actions += `<button class="btn ghost sm" onclick="pinBooklist(${a.id}, ${a.pinned ? 0 : 1})">${a.pinned ? '取消置顶' : '置顶'}</button>`;
  // 管理员：待审文章 → 「置顶」右边给出「通过申请 / 驳回申请」
  if (d.can_review_article)
    actions += `<button class="btn sm" onclick="reviewBooklist(${a.id}, 'approve')">通过申请</button>
                <button class="btn danger sm" onclick="reviewBooklist(${a.id}, 'reject')">驳回申请</button>`;
  const el = document.getElementById('bl-detail-body');
  el.innerHTML = `
    <div class="card bl-article">
      <h2 style="margin:0 0 6px">${esc(a.title)} ${stBadge} ${pinBadge}</h2>
      <div class="bl-meta">${tagBadge} ${esc(d.author_name)} · ${blTime(a.created_at)} · 👁 ${a.view_count} 浏览 · 💬 ${d.comments.length} 回复</div>
      ${a.updated_at && a.updated_at !== a.created_at ? `<div class="muted" style="font-size:12px">编辑于 ${blTime(a.updated_at)}</div>` : ''}
      <div class="bl-content">${md(a.content)}</div>
      <div style="display:flex;gap:8px;margin-top:14px">${actions}</div>
    </div>
    <div class="card bl-comments">
      <h3 style="margin:0 0 12px">回复（${d.comments.length}）</h3>
      <div id="bl-comment-list">${renderComments(d.comments, d.is_owner)}</div>
      ${GUEST ? `<p class="muted" style="font-size:13px">登录后可参与回复</p>`
        : `<div class="bl-comment-box">
             <textarea id="bl-cmt-input" rows="2" maxlength="2000" placeholder="写下你的回复，作者或管理员审查后显示…"></textarea>
             <div style="display:flex;justify-content:flex-end;margin-top:8px">
               <button class="btn sm" onclick="submitComment()">发表回复</button>
             </div>
           </div>`}
    </div>`;
}

function renderComments(list, isOwner) {
  if (!list || !list.length) return '<p class="muted" style="font-size:13px">还没有回复，来抢沙发～</p>';
  return list.map(c => {
    const pend = c.status === 'pending' ? '<span class="badge no">待审查</span>' : '';
    const reviewBtns = (isOwner && c.status === 'pending')
      ? `<span style="margin-left:6px">
           <a href="javascript:reviewComment(${c.id},'approve')" style="color:var(--ok)">通过</a> ·
           <a href="javascript:reviewComment(${c.id},'reject')" style="color:var(--danger)">拒绝</a>
         </span>` : '';
    const canDel = isOwner || (USER && USER.id === c.user_id);
    const delBtn = canDel
      ? `<a href="javascript:delComment(${c.id})" style="color:var(--danger);margin-left:6px">删除</a>` : '';
    return `<div class="bl-cmt">
      <div class="c-head"><b>${esc(c.user_name)}</b> <span class="muted">${blTime(c.created_at)}</span> ${pend}${reviewBtns}${delBtn}</div>
      <div class="c-body">${esc(c.content).replace(/\n/g, '<br>')}</div>
    </div>`;
  }).join('');
}

async function submitComment() {
  const inp = document.getElementById('bl-cmt-input');
  const content = (inp.value || '').trim();
  if (!content) { toast('回复内容不能为空'); return; }
  try {
    const r = await api('/api/booklists/' + blDetail.article.id + '/comments', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ content })
    });
    toast(r.status === 'approved' ? '回复已发布' : '回复已提交，等待作者或管理员审查');
    inp.value = '';
    openBooklistView(blDetail.article.id);
  } catch (e) { toast(e.message); }
}

async function reviewComment(cid, action) {
  if (!confirm('确定' + (action === 'approve' ? '通过' : '拒绝') + '该回复？')) return;
  try {
    await api(`/api/booklists/${blDetail.article.id}/comments/${cid}/review`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action })
    });
    toast('已' + (action === 'approve' ? '通过' : '拒绝'));
    openBooklistView(blDetail.article.id);
  } catch (e) { toast(e.message); }
}

async function delComment(cid) {
  if (!confirm('确定删除这条回复？')) return;
  try {
    await api(`/api/booklists/${blDetail.article.id}/comments/${cid}`, { method: 'DELETE' });
    toast('回复已删除');
    openBooklistView(blDetail.article.id);
  } catch (e) { toast(e.message); }
}

async function pinBooklist(id, pinned) {
  try {
    await api(`/api/booklists/${id}/pin`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ pinned })
    });
    toast(pinned ? '已置顶' : '已取消置顶');
    openBooklistView(id);
  } catch (e) { toast(e.message); }
}
// 管理员在文章详情页直接审批书单/文章（与后台「书单审核」同一条处理逻辑）
async function reviewBooklist(id, action) {
  if (action === 'reject') {
    return askRejectReason({
      title: '驳回文章申请',
      hint: '驳回后文章不会公开展示。下面填写的理由会原文显示在作者的「我的消息」里。',
      onSubmit: reason => doReviewBooklist(id, 'reject', reason)
    });
  }
  if (!confirm('确定通过这篇文章？\n\n通过后所有人可见，并按后台设置为作者发放树叶奖励。')) return;
  doReviewBooklist(id, 'approve', '');
}
async function doReviewBooklist(id, action, reason) {
  try {
    const r = await api(`/api/admin/booklists/${id}/review`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: action, reason: reason || '' })
    });
    toast(action === 'approve'
      ? (r.leaves ? `已通过，奖励作者 ${r.leaves} 树叶` : '已通过，现已公开展示')
      : '已驳回，理由已通知作者');
    openBooklistView(id);
    if (typeof loadBooklists === 'function' && document.getElementById('page-booklists') && !document.getElementById('page-booklists').classList.contains('hidden')) loadBooklists();
  } catch (e) { toast(e.message); }
}

// ---------- 书单列表页 ----------
async function loadBooklists() {
  document.getElementById('bl-new-btn').style.display = can('publish_booklist') && !GUEST ? '' : 'none';
  renderBlTagFilter();
  loadBlSidebar();
  try {
    const qs = (blQ ? '&q=' + encodeURIComponent(blQ) : '') + (blTag ? '&tag=' + blTag : '');
    const r = await api('/api/booklists?page=' + blPage + qs);
    blPages = r.pages || 1;
    if (blPage > blPages) blPage = blPages;
    document.getElementById('bl-count').textContent = blQ
      ? `“${blQ}” 找到 ${r.total} 篇` : (r.total ? `共 ${r.total} 篇文章` : '');
    const wrap = document.getElementById('bl-list');
    if (!r.total) {
      wrap.innerHTML = blQ
        ? '<div class="empty">没有找到与「' + esc(blQ) + '」相关的文章，换个关键词试试</div>'
        : '<div class="empty">还没有文章，点击右上角「＋ 发表文章」分享你的书单或话题</div>';
    } else {
      wrap.innerHTML = r.items.map(x => `
        <div class="card bl-item" onclick="openBooklist(${x.id})">
          <div class="t">${x.status === 'pending' ? '<span class="badge no">待审核</span> ' : ''}${x.pinned ? '<span class="badge top">置顶</span> ' : ''}${esc(x.title)}</div>
          <div class="br">${esc(x.brief || '')}</div>
          <div class="m">${blTagBadge(x.tag)} ${esc(x.author_name)} · ${blTime(x.created_at)} · 👁 ${x.view_count} · 💬 ${x.comment_count}</div>
        </div>`).join('');
    }
    const pager = document.getElementById('bl-pager');
    if (blPages <= 1) { pager.innerHTML = ''; return; }
    pager.innerHTML = `<button onclick="blGoPage(${blPage - 1})" ${blPage <= 1 ? 'disabled' : ''}>‹</button>
      <span class="muted" style="font-size:14px">${blPage} / ${blPages} 页</span>
      <button onclick="blGoPage(${blPage + 1})" ${blPage >= blPages ? 'disabled' : ''}>›</button>`;
  } catch (e) { toast(e.message); }
}
function renderBlTagFilter() {
  const el = document.getElementById('bl-tag-filter');
  if (!el) return;
  const opts = [['', '全部'], ...Object.entries(BL_TAGS).map(([k, v]) => [k, v[0]])];
  el.innerHTML = opts.map(([k, v]) =>
    `<button class="chip ${blTag === k ? 'active' : ''}" onclick="blSetTag('${k}')">${v}</button>`).join('');
}
function blSetTag(t) {
  blTag = t; blPage = 1;
  loadBooklists();
}
function blGoPage(p) {
  if (p < 1 || p > blPages || p === blPage) return;
  blPage = p;
  loadBooklists();
  window.scrollTo({ top: 0 });
}
function blSearch() {
  const inp = document.getElementById('bl-search');
  blQ = (inp.value || '').trim();
  blPage = 1;
  loadBooklists();
}
function blSearchClear(inp) {
  document.getElementById('bl-search-clear').style.display = (inp.value || '').trim() ? '' : 'none';
}
function blClearSearch() {
  const inp = document.getElementById('bl-search');
  inp.value = ''; blQ = ''; blPage = 1;
  document.getElementById('bl-search-clear').style.display = 'none';
  loadBooklists();
}
async function loadBlSidebar() {
  try {
    const d = await api('/api/booklists/sidebar');
    // 最新签到：头像（昵称首字）+ 昵称 + 当前树叶余额 + 连签天数
    const sg = document.getElementById('bl-signin');
    if (sg) {
      // 用真表格（table-layout:fixed）而不是 flex 列表：右栏只有 1/3 屏宽，
      // 用 flex 时每行宽度取决于昵称长短，数字列会参差不齐；表格能保证
      // 「树叶」「连签」两列严格对齐成一竖列。
      sg.innerHTML = (d.latest_signins || []).length
        ? '<table class="bl-signin-tb"><colgroup>'
          + '<col class="c-u"><col class="c-l"><col class="c-s"></colgroup>'
          + '<thead><tr><th>用户</th><th class="num">树叶</th><th class="num">连签</th></tr></thead>'
          + '<tbody>' + d.latest_signins.map(x => `<tr>
               <td class="u"><span class="u-in">
                 <span class="av">${esc(x.initial || '?')}</span>
                 <span class="nm-wrap">
                   <span class="nm" title="${esc(x.name)}">${esc(x.name)}</span>
                   <span class="tm">${blTime(x.created_at || x.signin_date)}</span>
                 </span>
               </span></td>
               <td class="num"><b>${x.balance}</b><i>🌿</i></td>
               <td class="num">${x.streak} 天</td>
             </tr>`).join('') + '</tbody></table>'
        : '<p class="muted" style="font-size:13px">暂无签到</p>';
    }
    const rc = document.getElementById('bl-recent');
    rc.innerHTML = d.recent_comments.length
      ? d.recent_comments.map(c => `<div class="bl-ri" onclick="openBooklist(${c.booklist_id})">
           <div class="t">${esc(c.booklist_title || '书单')}</div>
           <div class="c">${esc(c.user_name)}：${esc(c.content)}</div>
           <div class="ti">${blTime(c.created_at)}</div>
         </div>`).join('')
      : '<p class="muted" style="font-size:13px">暂无回复</p>';
    const tp = document.getElementById('bl-top');
    tp.innerHTML = d.top_views.length
      ? d.top_views.map((x, i) => `<div class="bl-ri top" onclick="openBooklist(${x.booklist_id})">
           <span class="no">${i + 1}</span>
           <span class="t">${esc(x.title)}</span>
           <span class="ti">${x.views} 次</span>
         </div>`).join('')
      : '<p class="muted" style="font-size:13px">本月暂无浏览</p>';
    // 友情链接：后台「概览 → 友情链接管理」里配的（≤5 条）。
    // 一条都没有时**整块隐藏**（包括标题）—— 空标题比没这块更难看。
    // ★ 后端只收 http/https，这里照样 esc()：地址里带 & 的查询串不转义会把 href 截断。
    const lkCard = document.getElementById('bl-links-card');
    const lk = document.getElementById('bl-links');
    if (lkCard && lk) {
      const links = d.links || [];
      lkCard.style.display = links.length ? '' : 'none';
      lk.innerHTML = links.map(x =>
        `<a class="bl-link" href="${esc(x.url)}" target="_blank" rel="noopener noreferrer nofollow"
            title="${esc(x.name || x.url)}">${esc(x.name || x.url)}</a>`).join('');
    }
  } catch (e) {}
}

// ---------- 发表 / 编辑 / 我的书单 ----------
let editBlId = null;   // 当前编辑的文章 id，null 表示发表
function showNewBooklist() {
  if (GUEST) { showAuth(); return; }
  if (!can('publish_booklist')) { toast('无发表书单权限，请联系管理员开通'); return; }
  const target = '#/write';
  if (location.hash !== target) location.hash = target;
  else openWriteView();
}
function showEditBooklist(id) {
  const target = '#/edit/' + id;
  if (location.hash !== target) location.hash = target;
  else openEditView(id);
}
function openWriteView() {
  if (GUEST) { showAuth(); return; }
  if (!can('publish_booklist')) { toast('无发表书单权限，请联系管理员开通'); location.hash = '#/booklists'; return; }
  editBlId = null;
  showView('write');
  document.getElementById('write-title').textContent = '发表文章';
  renderWriteForm('', '', 'share');
}
async function openEditView(id) {
  if (GUEST) { showAuth(); return; }
  try {
    const d = await api('/api/booklists/' + id);
    const a = d.article;
    editBlId = id;
    showView('write');
    document.getElementById('write-title').textContent = '编辑文章';
    renderWriteForm(a.title, a.content, a.tag || 'share');
  } catch (e) { toast(e.message); location.hash = '#/booklists'; }
}
function renderWriteForm(title, content, tag) {
  document.getElementById('write-body').innerHTML = `
    <div class="write-form">
      <div class="card">
        <div class="form-group"><label>标题</label><input id="blf-title" maxlength="80" placeholder="文章标题"></div>
        <div class="form-group"><label>标签</label><div class="bl-tag-row">${blTagOptions(tag)}</div></div>
        <div class="form-group"><label>内容（支持 Markdown：标题 / 列表 / **加粗** / 链接 / 图片 / 视频）</label>
          <textarea id="blf-content" rows="16" placeholder="例如：&#10;# 我的年度十佳&#10;- 《书名》作者&#10;- 《书名》作者&#10;&#10;**推荐理由**：…&#10;&#10;请尊重版权，勿发布电子书下载链接"></textarea>
          <div style="margin-top:8px;display:flex;gap:8px;flex-wrap:wrap;align-items:center">
            <button class="btn ghost sm" onclick="blPickImage()">插入图片（≤1MB）</button>
            <button class="btn ghost sm" onclick="blPickVideo()">插入视频（≤50MB）</button>
            <span class="muted" style="font-size:12px">视频支持 MP4 / WebM，插在光标处，可手动拖动调整位置</span>
          </div>
        </div>
        <p class="muted" style="font-size:12px">${isTrusted() ? (editBlId != null ? '编辑后直接展示' : '发表后直接展示') : (editBlId != null ? '编辑后需重新通过管理员审核' : '发表后需管理员审核通过才会展示')}</p>
        <div style="display:flex;gap:10px;margin-top:8px">
          <button class="btn" onclick="${editBlId != null ? `submitEditBooklist(${editBlId})` : 'submitNewBooklist()'}">${editBlId != null ? '保存' : '提交'}</button>
          <button class="btn ghost" onclick="closeWrite()">取消</button>
        </div>
      </div>
    </div>`;
  document.getElementById('blf-title').value = title || '';
  document.getElementById('blf-content').value = content || '';
}
function closeWrite() {
  if (editBlId != null) {
    const id = editBlId; editBlId = null;
    location.hash = '#/booklist/' + id;
  } else {
    location.hash = '#/booklists';
  }
}
async function submitNewBooklist() {
  const title = (document.getElementById('blf-title').value || '').trim();
  const content = (document.getElementById('blf-content').value || '').trim();
  const tag = (document.querySelector('input[name="blf-tag"]:checked') || {}).value || 'share';
  if (!title || !content) { toast('请填写标题与内容'); return; }
  try {
    const r = await api('/api/booklists', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ title, content, tag }) });
    toast(r.status === 'approved' ? '文章已发布' : '已提交，等待管理员审核');
    location.hash = '#/booklists';
  } catch (e) { toast(e.message); }
}
async function submitEditBooklist(id) {
  const title = (document.getElementById('blf-title').value || '').trim();
  const content = (document.getElementById('blf-content').value || '').trim();
  const tag = (document.querySelector('input[name="blf-tag"]:checked') || {}).value || 'share';
  if (!title || !content) { toast('请填写标题与内容'); return; }
  try {
    const r = await api('/api/booklists/' + id, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ title, content, tag }) });
    toast(r.status === 'approved' ? '已保存并发布' : '已保存，等待管理员重新审核');
    editBlId = null;
    location.hash = '#/booklist/' + id;
  } catch (e) { toast(e.message); }
}
// 文章内嵌媒体（图片 / 视频）的上传配置：与后端 booklists.py 的限制一一对应
const BL_MEDIA = {
  image: {
    accept: 'image/jpeg,image/png,image/gif,image/webp,image/bmp',
    url: '/api/booklists/upload-image', max: 1024 * 1024, maxText: '1MB', label: '图片',
  },
  video: {
    accept: 'video/mp4,video/webm,video/ogg,video/quicktime,video/x-m4v,.mp4,.webm,.ogv,.mov,.m4v',
    url: '/api/booklists/upload-video', max: 50 * 1024 * 1024, maxText: '50MB', label: '视频',
  },
};
// fetch 拿不到上传进度，而视频动辄几十 MB，上传期间必须让用户看到在动，
// 否则会被当成卡死 —— 所以这里用 XHR。
function blUploadMedia(file, cfg) {
  return new Promise((resolve, reject) => {
    const fd = new FormData();
    fd.append('file', file);
    const xhr = new XMLHttpRequest();
    xhr.open('POST', cfg.url);
    if (TOKEN) xhr.setRequestHeader('Authorization', 'Bearer ' + TOKEN);
    xhr.upload.onprogress = e => {
      if (e.lengthComputable && e.total) {
        toast(`正在上传${cfg.label} ${Math.round(e.loaded / e.total * 100)}%`);
      }
    };
    xhr.onload = () => {
      let d = null;
      try { d = JSON.parse(xhr.responseText); } catch (e) {}
      if (xhr.status === 401) { logout(false); reject(new Error('未登录')); return; }
      if (xhr.status >= 200 && xhr.status < 300 && d) resolve(d);
      else reject(new Error(apiErrText(d, xhr.status) || ('上传失败 ' + xhr.status)));
    };
    xhr.onerror = () => reject(new Error('网络中断，上传失败'));
    xhr.ontimeout = () => reject(new Error('上传超时，请重试'));
    xhr.timeout = 10 * 60 * 1000;
    xhr.send(fd);
  });
}
function blInsertMedia(kind) {
  const cfg = BL_MEDIA[kind];
  const inp = document.createElement('input');
  inp.type = 'file';
  inp.accept = cfg.accept;
  inp.onchange = async () => {
    const f = inp.files && inp.files[0];
    if (!f) return;
    if (f.size > cfg.max) { toast(`${cfg.label}大小不能超过 ${cfg.maxText}`); return; }
    try {
      toast(`正在上传${cfg.label}…`);
      const r = await blUploadMedia(f, cfg);
      const ta = document.getElementById('blf-content');
      if (!ta) return;
      // 图片和视频用同一个 Markdown 语法，渲染时按扩展名决定出 <img> 还是 <video>
      const snippet = `\n![${cfg.label}](${r.url})\n`;
      const s = (ta.selectionStart != null ? ta.selectionStart : ta.value.length);
      ta.value = ta.value.slice(0, s) + snippet + ta.value.slice(s);
      ta.focus();
      toast(`${cfg.label}已插入`);
    } catch (e) { toast(e.message); }
  };
  inp.click();
}
function blPickImage() { blInsertMedia('image'); }
function blPickVideo() { blInsertMedia('video'); }
async function delBooklist(id) {
  if (!confirm('确定删除这篇文章？其回复将一并删除。')) return;
  try {
    await api('/api/booklists/' + id, { method: 'DELETE' });
    toast('已删除');
    closeBooklist();
    loadBooklists();
  } catch (e) { toast(e.message); }
}
let meArticles = [], meArticlePage = 1;
async function loadMyArticles() {
  const card = document.getElementById('me-articles-card');
  if (!card) return;
  if (GUEST) { card.style.display = 'none'; return; }
  card.style.display = '';
  try {
    const d = await api('/api/booklists/mine');
    meArticles = d.items || [];
    meArticlePage = 1;
    renderMyArticles();
  } catch (e) {}
}
function renderMyArticles() {
  const list = document.getElementById('me-articles-list');
  const pager = document.getElementById('me-articles-pager');
  const total = meArticles.length;
  const pageSize = 6;
  const pages = Math.max(1, Math.ceil(total / pageSize));
  if (meArticlePage > pages) meArticlePage = pages;
  if (!total) { list.innerHTML = '<p class="muted">你还没有发表过文章</p>'; pager.innerHTML = ''; return; }
  const slice = meArticles.slice((meArticlePage - 1) * pageSize, meArticlePage * pageSize);
  list.innerHTML = slice.map(a => {
    const st = BL_STATUS[a.status] || ['', ''];
    return `<div class="list-item">
      <div class="tt" style="cursor:pointer" onclick="openBooklistFromMine(${a.id})">${esc(a.title)} ${blTagBadge(a.tag)} <span class="badge ${st[1]}">${st[0]}</span></div>
      <div class="muted" style="font-size:12px">${blTime(a.created_at)} · 👁 ${a.view_count} · 💬 ${a.comment_count}</div>
      <div style="display:flex;gap:8px;margin-top:6px">
        <button class="btn ghost sm" onclick="showEditBooklistFromMine(${a.id})">编辑</button>
        <button class="btn danger sm" onclick="delBooklistFromMine(${a.id})">删除</button>
      </div>
    </div>`;
  }).join('');
  pager.innerHTML = pages > 1
    ? `<button ${meArticlePage <= 1 ? 'disabled' : ''} onclick="goMeArticlePage(${meArticlePage - 1})">上一页</button><span>${meArticlePage} / ${pages}</span><button ${meArticlePage >= pages ? 'disabled' : ''} onclick="goMeArticlePage(${meArticlePage + 1})">下一页</button>`
    : '';
}
function goMeArticlePage(p) { meArticlePage = p; renderMyArticles(); }
async function openBooklistFromMine(id) { openBooklistView(id); }
async function showEditBooklistFromMine(id) {
  showEditBooklist(id);
}
async function delBooklistFromMine(id) {
  if (!confirm('确定删除这篇文章？')) return;
  try {
    await api('/api/booklists/' + id, { method: 'DELETE' });
    toast('已删除');
    loadMyArticles();
  } catch (e) { toast(e.message); }
}

// ---------- 功能介绍 ----------
function showIntro() {
  const target = '#/intro';
  if (location.hash !== target) location.hash = target;
  else openIntroView();
}
function openIntroView() {
  showView('intro');
  renderIntro();
}
function closeIntro() { location.hash = lastHash || '#/library'; }
async function renderIntro() {
  const body = document.getElementById('intro-body');
  body.innerHTML = '<p class="muted" style="padding:20px 0">加载中…</p>';
  try {
    const r = await api('/api/intro');
    body.innerHTML = r.content || '';
  } catch (e) {
    body.innerHTML = '<p class="muted" style="padding:20px 0">功能介绍加载失败，请稍后重试</p>';
  }
}
