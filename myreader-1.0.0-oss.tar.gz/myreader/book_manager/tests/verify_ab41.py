# -*- coding: utf-8 -*-
"""独立核验有声书任务 #41 的最终产物（不依赖监督脚本给出的结论）。

核验面（每一条都重新去拿证据，不引用监督脚本的中间状态）：
  ① 库内状态自洽：job/ab_file/ab_seg 三者对得上
  ② 远端 WebDAV 实际文件数与字节数（PROPFIND Depth:1），与库里逐个比对
  ③ 抽样真下载 + ffprobe：时长、ID3（艺术家/专辑/音轨号）
  ④ 应用侧可见性：任务挂的书存在、模块接口能取到
  ⑤ 残留检查：旧位置与临时目录

用法：venv/bin/python tests/verify_ab41.py [任务号]
"""
import os
import sys
import json
import subprocess
import tempfile
import urllib.parse
import xml.etree.ElementTree as ET
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
os.chdir(_ROOT)
import config, db  # noqa: E402
from audiobook import dav  # noqa: E402

JID = int(sys.argv[1]) if len(sys.argv) > 1 else 41
_pass, _fail = [0], [0]


def ck(name, ok, extra=''):
    if ok:
        _pass[0] += 1
        print('  [OK] %s%s' % (name, ('  ' + str(extra)) if extra != '' else ''))
    else:
        _fail[0] += 1
        print('  [FAIL] %s%s' % (name, ('  ' + str(extra)) if extra != '' else ''))


def dav_list(d):
    """PROPFIND Depth:1 → {文件名: 字节数}"""
    body = ('<?xml version="1.0"?><d:propfind xmlns:d="DAV:"><d:prop>'
            '<d:getcontentlength/></d:prop></d:propfind>').encode()
    with dav._req("PROPFIND", d, body=body, timeout=120,
                  headers={'Depth': '1', 'Content-Type': 'application/xml'}) as r:
        xml = r.read().decode('utf-8', 'replace')
    out = {}
    for resp in ET.fromstring(xml).findall('{DAV:}response'):
        href = (resp.findtext('{DAV:}href') or '').strip()
        if href.endswith('/'):
            continue                       # 目录自己
        name = urllib.parse.unquote(href.split('/')[-1])
        size = None
        for el in resp.iter():
            if el.tag.endswith('getcontentlength'):
                size = int(el.text or 0)
        out[name] = size
    return out


print('=' * 78)
print('① 库内状态自洽')
print('=' * 78)
job = db.q("SELECT * FROM ab_job WHERE id=?", (JID,), one=True)
ck('任务存在', bool(job))
if not job:
    sys.exit(1)
ck('状态是 done', job['status'] == 'done', job['status'])
ck('阶段是「全部完成」', job['stage'] == '全部完成', job['stage'])
ck('进度满：done_files == total_files == 93',
   job['done_files'] == job['total_files'] == 93, '%s/%s' % (job['done_files'], job['total_files']))
ck('有完成时间', bool(job['finished_at']), job['finished_at'])
ck('没有遗留错误信息', not (job['error'] or ''), repr(job['error']))
ck('输出目录在 /music 下', (job['dest'] or '').startswith('/music/'), job['dest'])

files = [dict(r) for r in db.q("SELECT * FROM ab_file WHERE job_id=? ORDER BY seq", (JID,))]
ck('ab_file 行数 = job.total_files', len(files) == job['total_files'],
   '%s vs %s' % (len(files), job['total_files']))
ck('seq 从 1 到 %s 连续无空洞' % len(files),
   [f['seq'] for f in files] == list(range(1, len(files) + 1)),
   '首 %s 末 %s' % (files[0]['seq'], files[-1]['seq']))
# ★ skipped = 整个文件覆盖的章节都是版权页/目录（见 docs §14.52），属于正常结果：
#   它没有远端文件、没有字节数，不算「异常行」，也不参与字节/时长的比对。
bad = [f['seq'] for f in files if f['status'] not in ('uploaded', 'skipped')]
ck('每一行状态都是 uploaded 或 skipped', not bad, '异常: %s' % bad[:5])
ups = [f for f in files if f['status'] == 'uploaded']
skips = [f for f in files if f['status'] == 'skipped']
if skips:
    print('    其中 skipped（整章版权页，无音频）: %d 个 → seq %s'
          % (len(skips), [f['seq'] for f in skips][:6]))
    ck('skipped 的文件确实是 0 字节 0 秒且无远端路径',
       all(not f['bytes'] and not f['seconds'] and not (f['remote'] or '') for f in skips))
ck('有文件产出音频', len(ups) > 0, len(ups))
zero_b = [f['seq'] for f in ups if not f['bytes']]
ck('没有 0 字节文件', not zero_b, '异常: %s' % zero_b[:5])
zero_s = [f['seq'] for f in ups if not f['seconds']]
ck('没有 0 秒文件', not zero_s, '异常: %s' % zero_s[:5])
no_remote = [f['seq'] for f in ups if not (f['remote'] or '').strip()]
ck('每个产出文件都记了远端路径', not no_remote, '异常: %s' % no_remote[:5])
files = ups                      # 后面的远端比对只针对真正产出音频的文件
db_bytes = sum(f['bytes'] or 0 for f in files)
db_secs = sum(f['seconds'] or 0 for f in files)
print('    库内合计：%.2f GB / %.1f 小时（%d 个文件）' % (db_bytes / 1e9, db_secs / 3600, len(files)))

segs = db.q("SELECT COUNT(*) c FROM ab_seg WHERE job_id=?", (JID,), one=True)['c']
ck('分句数 = job.done_segs', segs == job['done_segs'], '%s vs %s' % (segs, job['done_segs']))
seg_files = db.q("SELECT COUNT(DISTINCT file_seq) c FROM ab_seg WHERE job_id=?", (JID,), one=True)['c']
ck('分句覆盖到全部 93 个文件', seg_files == 93, seg_files)

print()
print('=' * 78)
print('② 远端实际文件（PROPFIND Depth:1）')
print('=' * 78)
dest = job['dest']
try:
    rfiles = dav_list(dest)
    ok_list = True
except Exception as e:
    rfiles, ok_list = {}, False
    ck('能列出远端目录', False, '%s → %r' % (dest, e))
if ok_list:
    ck('能列出远端目录', True, '%s → %d 个文件' % (dest, len(rfiles)))
    ck('远端 mp3 数 = 93', len(rfiles) == 93, len(rfiles))
    missing, mismatch = [], []
    for f in files:
        nm = os.path.basename(urllib.parse.unquote(f['remote'] or ''))
        if nm not in rfiles:
            cand = [k for k in rfiles if k.startswith('%03d' % f['seq'])]
            nm = cand[0] if cand else ''
        if not nm or nm not in rfiles:
            missing.append(f['seq'])
        elif rfiles[nm] is not None and int(rfiles[nm]) != int(f['bytes']):
            mismatch.append((f['seq'], rfiles[nm], f['bytes']))
    ck('库里每个文件都能在远端找到', not missing, '缺序号: %s' % missing[:5])
    ck('字节数与库里逐个一致', not mismatch, '不一致: %s' % mismatch[:3])
    rbytes = sum(int(v or 0) for v in rfiles.values())
    print('    远端合计：%.2f GB（库里 %.2f GB，差 %.1f MB）'
          % (rbytes / 1e9, db_bytes / 1e9, (rbytes - db_bytes) / 1e6))
    ck('远端总量与库里记录相差在 1MB 内（同一批文件）',
       abs(rbytes - db_bytes) < 1024 * 1024, '%.0f 字节' % (rbytes - db_bytes))

    print()
    print('=' * 78)
    print('③ 抽样真下载 + ffprobe（头 / 中 / 尾各一个）')
    print('=' * 78)
    for idx in (0, 46, 92):
        f = files[idx]
        nm = os.path.basename(urllib.parse.unquote(f['remote'] or ''))
        if nm not in rfiles:
            cand = [k for k in rfiles if k.startswith('%03d' % f['seq'])]
            nm = cand[0] if cand else None
        if not nm:
            ck('第 %d 个文件在远端存在' % f['seq'], False, str(f['remote']))
            continue
        tmp = tempfile.mktemp(suffix='.mp3')
        try:
            dav.get(os.path.join(dest, nm), tmp)
            ck('第 %d 个文件能下载' % f['seq'], os.path.getsize(tmp) > 0,
               '%.1f MB' % (os.path.getsize(tmp) / 1e6))
            out = subprocess.run(
                ['tools/bin/ffprobe', '-v', 'error', '-show_entries',
                 'format=duration:format_tags=title,artist,album,track',
                 '-of', 'json', tmp],
                capture_output=True, text=True, timeout=180).stdout
            fmt = (json.loads(out or '{}') or {}).get('format') or {}
            tags = {k.lower(): v for k, v in (fmt.get('tags') or {}).items()}
            dur = float(fmt.get('duration') or 0)
            ck('第 %d 个能读出时长' % f['seq'], dur > 1, '%.0f 秒' % dur)
            ck('时长与库里记录一致（±5 秒）', abs(dur - (f['seconds'] or 0)) <= 5,
               '读回 %.0f / 库里 %s' % (dur, f['seconds']))
            ck('艺术家标签 = 示例', tags.get('artist') == '示例', tags.get('artist'))
            ck('专辑标签 = 书名', tags.get('album') == job['title'], tags.get('album'))
            ck('音轨号正确', (tags.get('track') or '').split('/')[0].lstrip('0') == str(f['seq']),
               '%s（应为 %s）' % (tags.get('track'), f['seq']))
            ck('标题标签以序号开头', (tags.get('title') or '').startswith('%03d' % f['seq']),
               (tags.get('title') or '')[:40])
        except Exception as e:
            ck('第 %d 个文件核验' % f['seq'], False, repr(e)[:140])
        finally:
            if os.path.exists(tmp):
                os.remove(tmp)

print()
print('=' * 78)
print('④ 应用侧可见性')
print('=' * 78)
bk = db.q("SELECT id, title, hidden FROM books WHERE id=?", (job['book_id'],), one=True)
ck('任务挂着的书在书库里', bool(bk), (bk['title'] if bk else 'book_id=%s' % job['book_id']))
ck('该书没有下架', bool(bk) and not bk['hidden'], (bk['hidden'] if bk else ''))
done_jobs = [dict(r) for r in db.q(
    "SELECT id, status, dest FROM ab_job WHERE book_id=? AND status='done'", (job['book_id'],))]
ck('该书有已完成的有声书任务', len(done_jobs) >= 1,
   ['#%s → %s' % (d['id'], d['dest']) for d in done_jobs])

print()
print('=' * 78)
print('⑤ 残留检查')
print('=' * 78)
for p in ('/Media/' + job['title'],
          '/books/Music/' + job['title'],
          '/media/' + job['title']):
    try:
        items = dav_list(p)
        ck('旧位置无残留：%s' % p, len(items) == 0, '%d 个文件' % len(items))
    except Exception as e:
        ck('旧位置无残留：%s' % p, True, '目录不存在(%s)' % type(e).__name__)
local_dirs = []
for base in (config.DATA_DIR, os.path.join(config.DATA_DIR, 'audiobook'), '/tmp'):
    try:
        for x in os.listdir(base):
            full = os.path.join(base, x)
            if os.path.isdir(full) and ('三体' in x or 'ab_tmp' in x):
                local_dirs.append(full)
    except Exception:
        pass
ck('本地没有留下整批临时音频目录', not local_dirs, local_dirs[:3])

print()
print('=' * 78)
print('通过 %d / 失败 %d' % (_pass[0], _fail[0]))
print('=' * 78)
sys.exit(1 if _fail[0] else 0)
