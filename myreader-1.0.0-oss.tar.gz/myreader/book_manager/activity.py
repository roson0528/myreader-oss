#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""阅读 / 听书活动日志：按天存档，落到 WebDAV，保留三年。

存储结构
--------
WebDAV:  activity/<年>/<YYYY-MM-DD>.json

每个日文件是自洽的，单独拿走也能看懂当天情况：

    {
      "date": "2026-10-03",
      "events": [
        {"t": "2026-10-03 21:33:07", "uid": 45, "u": "test", "kind": "listen",
         "bid": 91, "book": "508-三指禅", "ip": "1.2.3.4", "detail": "开始听书"},
        ...
      ],
      "dropped": 0,
      "updated_at": "2026-10-03 21:34:02"
    }

后台「听书日志」「阅读日志」两个页面就是读这些文件。

为什么单独一个模块、而不是塞进库里
---------------------------------
沿用 stats.py 的约定：日志属于「档案」，按天落 WebDAV、保留三年，
不跟业务数据混在 SQLite 里。这样库只留活数据，日志可以单独备份/迁移。

为什么不用 listen_logs 表
------------------------
那张表是听书「配额记账」用的，只在①该分组有免费额度上限、②本月第一次听这本
时才写一行，管理员和无限额度分组根本不写。它是账本，不是活动流水。
阅读侧原先完全没有流水：progress 只存最新位置，reading_time 只存累计秒数。

设计要点
--------
* 不能拖慢正常请求：record() 只往内存列表里追加，落盘交给后台线程。
* 进程重启不丢当天数据：当天第一次用到时先把 WebDAV 上的当天文件读回来合并。
* 会话去重：同一用户对同一本书 30 分钟内只记一条「开始」，否则翻页/续播会把
  日志刷屏。去重表在载入当天文件时重建，重启后依然有效。
* 写失败不报错：WebDAV 挂了就留在内存里下次再试；record() 调用方是存进度和
  开始听书这两条核心链路，绝不能因为日志把它拖垮。
"""
import json
import threading
import time
from datetime import datetime, timedelta, timezone
from concurrent.futures import ThreadPoolExecutor

import db
import ftp_service

ACTIVITY_ROOT = "activity"
RETENTION_DAYS = 365 * 3          # 历史保留三年
FLUSH_SEC = 60                    # 落盘间隔
SESSION_MINUTES = 30              # 同一用户同一本书的去重窗口
MAX_EVENTS_PER_DAY = 50000        # 单日事件上限，防止文件无限膨胀
MAX_RANGE_DAYS = 366              # 单次查询最多跨这么多天
MAX_CACHED_DAYS = 400             # 历史日文件最多在内存里留这么多天
READ_WORKERS = 12                 # 并行读 WebDAV 的线程数

KINDS = ("read", "listen", "audio")
KIND_LABEL = {"read": "阅读", "listen": "听书", "audio": "有声"}
# 合并页用：kind="all" 表示「听书 + 有声 + 阅读」一起看
ALL_KIND = "all"

_lock = threading.RLock()
_days = {}                        # date -> [event, ...]
_dirty = set()                    # 待落盘的日期
_loaded = set()                   # 已经和 WebDAV 合并过的日期
_dropped = {}                     # date -> 因超上限被丢弃的条数
_recent = {}                      # (uid, kind, bid) -> 最近一次记录时间戳
_started = False
_last_prune = 0.0
_last_error = ""


# ---------------------------------------------------------------- 基础工具
def _bj_now():
    return datetime.now(timezone.utc) + timedelta(hours=8)


def now_str():
    return _bj_now().strftime("%Y-%m-%d %H:%M:%S")


def today():
    return _bj_now().strftime("%Y-%m-%d")


def day_path(date):
    return f"{ACTIVITY_ROOT}/{date[:4]}/{date}.json"


def _valid_date(s):
    try:
        datetime.strptime(s, "%Y-%m-%d")
        return True
    except Exception:
        return False


# ---------------------------------------------------------------- 记录
def record(user, kind, book_id, book_title, detail="", ip=""):
    """记一条活动。只写内存，立即返回；WebDAV 由后台线程落盘。

    返回是否真的记下了（会话去重命中、参数不合法时为 False）。
    调用方不需要关心失败 —— 这里不抛异常。
    """
    try:
        if kind not in KINDS:
            return False
        uid = _uget(user, "id", 0)
        if not uid:
            return False
        uid = int(uid)
        bid = int(book_id or 0)
        date = today()
        ts = time.time()

        with _lock:
            key = (uid, kind, bid)
            last = _recent.get(key)
            if last is not None and ts - last < SESSION_MINUTES * 60:
                return False
            _recent[key] = ts

            ev = {
                "t": now_str(),
                "uid": uid,
                "u": _uget(user, "username", "") or "",
                "kind": kind,
                "bid": bid,
                "book": book_title or "",
                "ip": ip or "",
                "detail": detail or "",
            }
            bucket = _bucket_locked(date)
            if len(bucket) >= MAX_EVENTS_PER_DAY:
                _dropped[date] = _dropped.get(date, 0) + 1
                return False
            bucket.append(ev)
            _dirty.add(date)
        return True
    except Exception:
        return False



def _uget(user, key, default=None):
    """从 user 里取字段。

    项目里 user 有两种形态：游客是普通 dict，登录用户是 sqlite3.Row
    （Row 没有 .get()，只能下标访问），所以这里统一按下标取。
    """
    try:
        v = user[key]
        return default if v is None else v
    except Exception:
        return default


def _bucket_locked(date):
    """取当天列表。调用方必须持有 _lock。"""
    if date not in _loaded:
        _load_into(date)
    return _days.setdefault(date, [])


def _load_into(date):
    """把 WebDAV 上的当天文件读回内存（只做一次）。调用方必须持有 _lock。"""
    _loaded.add(date)
    doc = _load_day_uncached(date)
    events = (doc or {}).get("events") or []
    if not isinstance(events, list):
        events = []
    _days[date] = events
    _dropped[date] = int((doc or {}).get("dropped") or 0)
    # 用已有事件重建去重表，这样重启后不会把同一场会话重复记一遍
    for ev in events[-2000:]:
        try:
            k = (int(ev.get("uid") or 0), ev.get("kind"), int(ev.get("bid") or 0))
            _recent[k] = _ts_of(ev.get("t")) or 0
        except Exception:
            continue


def _ts_of(t):
    try:
        return (datetime.strptime(t, "%Y-%m-%d %H:%M:%S")
                .replace(tzinfo=timezone.utc).timestamp() - 8 * 3600)
    except Exception:
        return 0


# ---------------------------------------------------------------- WebDAV 读写
def _load_day_uncached(date):
    try:
        raw = ftp_service.read_bytes(day_path(date))
        if not raw:
            return None
        d = json.loads(raw.decode("utf-8"))
        return d if isinstance(d, dict) else None
    except Exception:
        return None



def load_day(date, use_cache=True):
    """取某天的事件列表。

    关键：内存里的数据永远优先于 WebDAV —— 刚记下的事件要等后台线程 flush
    才落盘，如果这里直接读远端，刚发生的事在后台页面上会「看不见」。
    当天数据本来就在 _days 里活着，所以这里不做 TTL；历史日期读到内存后
    也不再变（已封盘），可以长期缓存。
    """
    with _lock:
        if date in _loaded:
            return list(_days.get(date) or [])
    doc = _load_day_uncached(date)
    events = (doc or {}).get("events") or []
    if not isinstance(events, list):
        events = []
    with _lock:
        _days[date] = events
        _loaded.add(date)
        _dropped.setdefault(date, int((doc or {}).get("dropped") or 0))
        _evict_old_cache_locked()
    return list(events)


def _evict_old_cache_locked():
    """缓存上限保护：只留最近 MAX_CACHED_DAYS 天，避免后台页面翻很久把内存撑大。
    调用方持锁。当天和昨天永不淘汰。"""
    if len(_days) <= MAX_CACHED_DAYS:
        return
    keep_after = (_bj_now() - timedelta(days=MAX_CACHED_DAYS)).strftime("%Y-%m-%d")
    for d in sorted(_days):
        if len(_days) <= MAX_CACHED_DAYS:
            break
        if d >= keep_after or d in _dirty:
            continue
        _days.pop(d, None)
        _loaded.discard(d)
        _dropped.pop(d, None)


def save_day(date):
    """把某天写回 WebDAV"""
    global _last_error
    with _lock:
        events = list(_days.get(date) or [])
        dropped = _dropped.get(date, 0)
    doc = {"date": date, "events": events, "dropped": dropped, "updated_at": now_str()}
    try:
        ftp_service.write_bytes(day_path(date),
                                json.dumps(doc, ensure_ascii=False).encode("utf-8"))
        _last_error = ""
        return True
    except Exception as e:
        _last_error = str(e)[:200]
        return False


def flush():
    """把脏日期写回 WebDAV，返回成功落盘的天数"""
    with _lock:
        dates = sorted(_dirty)
    ok = 0
    for d in dates:
        if save_day(d):
            ok += 1
            with _lock:
                _dirty.discard(d)
    return ok


def prune(days=RETENTION_DAYS):
    """删掉超过保留期的老文件，返回删除数量"""
    global _last_prune
    _last_prune = time.time()
    cutoff = (_bj_now() - timedelta(days=days)).strftime("%Y-%m-%d")
    removed = 0
    try:
        years = ftp_service.list_dir(ACTIVITY_ROOT) or []
    except Exception:
        return 0
    for item in years:
        name = item.get("name") or ""
        if not (len(name) == 4 and name.isdigit()):
            continue
        try:
            files = ftp_service.list_dir(f"{ACTIVITY_ROOT}/{name}") or []
        except Exception:
            continue
        left = []
        for f in files:
            fn = f.get("name") or ""
            if not fn.endswith(".json") or len(fn) != 15:
                left.append(fn)
                continue
            if fn[:10] < cutoff:
                try:
                    ftp_service.delete(f"{ACTIVITY_ROOT}/{name}/{fn}")
                    removed += 1
                except Exception:
                    pass
            else:
                left.append(fn)
        if not left:                  # 该年空了，把空目录也收掉
            try:
                ftp_service.delete(f"{ACTIVITY_ROOT}/{name}")
            except Exception:
                pass
    return removed


# ---------------------------------------------------------------- 后台线程
def _loop():
    while True:
        time.sleep(FLUSH_SEC)
        try:
            flush()
        except Exception:
            pass
        try:
            if time.time() - _last_prune > 6 * 3600:
                prune()
        except Exception:
            pass


def start():
    """启动后台落盘线程（幂等）"""
    global _started
    with _lock:
        if _started:
            return
        _started = True
    threading.Thread(target=_loop, daemon=True, name="activity-flusher").start()


def shutdown():
    try:
        flush()
    except Exception:
        pass


# ---------------------------------------------------------------- 查询
def _date_range(start, end):
    """把 (start, end) 规整成合法且不超过 MAX_RANGE_DAYS 的日期列表（新→旧）"""
    if not (start and _valid_date(start)):
        start = today()
    if not (end and _valid_date(end)):
        end = today()
    if start > end:
        start, end = end, start
    d0 = datetime.strptime(start, "%Y-%m-%d").date()
    d1 = datetime.strptime(end, "%Y-%m-%d").date()
    if (d1 - d0).days > MAX_RANGE_DAYS:
        d0 = d1 - timedelta(days=MAX_RANGE_DAYS)
    out, cur = [], d1
    while cur >= d0:
        out.append(cur.strftime("%Y-%m-%d"))
        cur -= timedelta(days=1)
    return out


def query(kind, start=None, end=None, keyword=None, page=1, size=50):
    """按时间倒序查询某类活动。

    先读涉及的所有日文件（并行、带缓存），再在内存里过滤/排序/分页。
    日志量级是「每天几百条」，这么做的代价远小于维护一套索引。
    """
    if kind not in KINDS and kind != ALL_KIND:
        return {"items": [], "total": 0, "days": [],
                "error": "kind 只能是 read / listen / audio / all"}
    dates = _date_range(start, end)
    if len(dates) > 1:
        with ThreadPoolExecutor(max_workers=READ_WORKERS) as ex:
            list(ex.map(load_day, dates))
    else:
        load_day(dates[0])

    kw = (keyword or "").strip().lower()
    events = []
    for d in dates:
        for ev in load_day(d):
            # kind="all" = 合并页「听书阅读」：三类活动一起出，靠 ev.kind 区分展示
            if kind != ALL_KIND and ev.get("kind") != kind:
                continue
            if kw:
                hay = (str(ev.get("u") or "") + " " + str(ev.get("book") or "")
                       + " " + str(ev.get("ip") or "")).lower()
                if kw not in hay:
                    continue
            events.append(ev)
    events.sort(key=lambda e: (e.get("t") or "", e.get("uid") or 0), reverse=True)

    total = len(events)
    page = max(1, int(page or 1))
    size = min(200, max(1, int(size or 50)))
    return {
        "items": events[(page - 1) * size: page * size],
        "total": total,
        "page": page,
        "size": size,
        "days": dates,
        "users": len({e.get("uid") for e in events}),
        "books": len({e.get("bid") for e in events}),
    }


def stats():
    """给页面顶部用的一行提示"""
    return {"today": today(), "root": ACTIVITY_ROOT,
            "retention_days": RETENTION_DAYS,
            "session_minutes": SESSION_MINUTES,
            "last_error": _last_error}
