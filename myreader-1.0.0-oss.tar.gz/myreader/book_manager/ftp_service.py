# -*- coding: utf-8 -*-
"""存储后端封装：WebDAV 为主（更稳定、原生 UTF-8），FTP/SFTP 兜底。

接口与原先的 FTP 封装保持一致，调用方无需改动：
  list_dir / stat / download_to / read_bytes / upload_file / delete / rename / makedirs / rmtree
"""
import os, time, base64, urllib.request, urllib.parse
import xml.etree.ElementTree as ET
import ftplib
import paramiko
import config

WEBDAV_BASE = f"http://{config.WEBDAV_HOST}:{config.WEBDAV_PORT}"

PROPFIND_BODY = (
    b'<?xml version="1.0" encoding="utf-8"?>'
    b'<D:propfind xmlns:D="DAV:"><D:prop>'
    b'<D:resourcetype/><D:getcontentlength/>'
    b'</D:prop></D:propfind>'
)


# ================= WebDAV 基础 =================
def _dav_url(relpath=""):
    """把 FTP_BASE 下的相对路径拼成 WebDAV URL（按 UTF-8 分段编码）。
    以 / 开头的路径视为服务器绝对路径（如 /迅雷/电子书/xxx），不再拼接 FTP_BASE。"""
    if relpath.startswith("/"):
        p = relpath.strip("/")
    else:
        base = (config.FTP_BASE or "").strip("/")
        p = (base + "/" + relpath).strip("/") if relpath else base
    segs = [urllib.parse.quote(s, safe="") for s in p.split("/") if s]
    return WEBDAV_BASE + "/" + "/".join(segs)


def _dav_headers():
    token = base64.b64encode(f"{config.FTP_USER}:{config.FTP_PASS}".encode()).decode()
    return {"Authorization": "Basic " + token}


def _dav_open(method, relpath="", body=None, timeout=60, extra=None):
    req = urllib.request.Request(_dav_url(relpath), data=body, method=method)
    h = _dav_headers()
    if extra:
        h.update(extra)
    for k, v in h.items():
        req.add_header(k, v)
    return urllib.request.urlopen(req, timeout=timeout)


def _dav_propfind(relpath="", depth=1, timeout=60):
    req = urllib.request.Request(_dav_url(relpath) + "/", data=PROPFIND_BODY, method="PROPFIND")
    h = _dav_headers()
    h["Depth"] = str(depth)
    h["Content-Type"] = "application/xml"
    for k, v in h.items():
        req.add_header(k, v)
    return urllib.request.urlopen(req, timeout=timeout)


def _parse_propfind(xml_bytes, relpath=""):
    ns = {"D": "DAV:"}
    root = ET.fromstring(xml_bytes)
    base = (config.FTP_BASE or "").strip("/")
    self_href = (base + "/" + relpath).strip("/") if relpath else base
    items = []
    for resp in root.findall("D:response", ns):
        href = (resp.findtext("D:href", "", ns) or "").strip()
        href = urllib.parse.unquote(href).strip("/")
        if not href or href == self_href:
            continue
        name = href.rsplit("/", 1)[-1]
        is_dir = resp.find(".//D:collection", ns) is not None
        size = 0
        if not is_dir:
            v = resp.findtext(".//D:getcontentlength", None, ns)
            try:
                size = int(v or 0)
            except Exception:
                size = 0
        items.append({"name": name, "size": size, "is_dir": is_dir})
    return items


# ================= 公共接口（WebDAV 优先） =================
def list_dir(relpath=""):
    """列出目录条目，返回 [{name, size, is_dir}]"""
    try:
        with _dav_propfind(relpath, 1) as r:
            return _parse_propfind(r.read(), relpath)
    except Exception:
        return _ftp_list_dir(relpath)


def stat(relpath):
    """返回 size 或 None"""
    try:
        req = urllib.request.Request(_dav_url(relpath), method="HEAD")
        for k, v in _dav_headers().items():
            req.add_header(k, v)
        with urllib.request.urlopen(req, timeout=30) as r:
            cl = r.headers.get("Content-Length")
            return int(cl) if cl is not None else None
    except Exception:
        return _ftp_stat(relpath)


def download_to(relpath, local_path, timeout=300):
    """下载远程文件到本地路径，返回大小"""
    os.makedirs(os.path.dirname(local_path) or ".", exist_ok=True)
    try:
        with _dav_open("GET", relpath, timeout=timeout) as r:
            total = 0
            with open(local_path, "wb") as fh:
                while True:
                    b = r.read(1 << 20)
                    if not b:
                        break
                    fh.write(b)
                    total += len(b)
            return total
    except Exception:
        return _ftp_download_to(relpath, local_path, timeout)


def read_bytes(relpath, timeout=120):
    """读取小文件全部字节（封面等）"""
    tmp = os.path.join(config.CACHE_DIR, "tmp_" + str(time.time()) + "_" + os.path.basename(relpath))
    try:
        download_to(relpath, tmp, timeout=timeout)
        with open(tmp, "rb") as fh:
            return fh.read()
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)


def upload_file(local_path, relpath):
    """上传本地文件到远程（自动建父目录）"""
    parent = os.path.dirname(relpath)
    if parent:
        makedirs(parent)
    try:
        with open(local_path, "rb") as fh:
            data = fh.read()
        with _dav_open("PUT", relpath, body=data, timeout=120) as r:
            r.read()
        return os.path.getsize(local_path)
    except Exception:
        return _ftp_upload_file(local_path, relpath)


def write_bytes(relpath, data):
    """把字节内容写到远程文件（自动建父目录），返回字节数"""
    parent = os.path.dirname(relpath)
    if parent:
        makedirs(parent)
    try:
        with _dav_open("PUT", relpath, body=data, timeout=120) as r:
            r.read()
        return len(data)
    except Exception:
        tmp = os.path.join(config.CACHE_DIR, "tmp_" + str(time.time()) + "_" + os.path.basename(relpath))
        try:
            with open(tmp, "wb") as fh:
                fh.write(data)
            return _ftp_upload_file(tmp, relpath)
        finally:
            if os.path.exists(tmp):
                os.remove(tmp)


def delete(relpath):
    """删除文件或目录，成功返回 True"""
    try:
        with _dav_open("DELETE", relpath, timeout=120) as r:
            r.read()
        return True
    except Exception:
        return _ftp_delete(relpath)


def rename(oldpath, newpath):
    """移动/重命名（MOVE），成功返回 True"""
    try:
        req = urllib.request.Request(_dav_url(oldpath), method="MOVE")
        h = _dav_headers()
        h["Destination"] = _dav_url(newpath)
        for k, v in h.items():
            req.add_header(k, v)
        with urllib.request.urlopen(req, timeout=60) as r:
            r.read()
        return True
    except Exception:
        return _ftp_rename(oldpath, newpath)


def makedirs(relpath):
    """递归创建目录"""
    parts = [p for p in relpath.split("/") if p]
    cur = ""
    try:
        for p in parts:
            cur = (cur + "/" + p) if cur else p
            try:
                with _dav_open("MKCOL", cur, timeout=30) as r:
                    r.read()
            except Exception:
                pass  # 已存在（405）等
        return True
    except Exception:
        return _ftp_makedirs(relpath)


def rmtree(relpath):
    """递归删除目录（WebDAV DELETE 即递归）"""
    try:
        with _dav_open("DELETE", relpath, timeout=120) as r:
            r.read()
        return True
    except Exception:
        return _ftp_rmtree(relpath)


# ================= FTP/SFTP 兜底 =================
def _open_ftp():
    f = ftplib.FTP()
    f.encoding = "gbk"
    f.connect(config.FTP_HOST, config.FTP_PORT, timeout=30)
    f.login(config.FTP_USER, config.FTP_PASS)
    f.cwd(config.FTP_BASE)
    return f


def _open_sftp():
    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    c.connect(config.SFTP_HOST, port=config.SFTP_PORT, username=config.FTP_USER,
              password=config.FTP_PASS, timeout=30, allow_agent=False, look_for_keys=False)
    return c, c.open_sftp()


def open_ftp():
    """返回已登录并 cwd 到 FTP_BASE 的连接（FTP 兜底专用）"""
    return _open_ftp()


def list_dir_on(f, relpath=""):
    """在已建立的 FTP 连接上列目录"""
    lines = []
    try:
        f.retrlines("LIST " + (relpath or "."), lines.append)
    except Exception:
        pass
    items = []
    for ln in lines:
        parts = ln.split(None, 8)
        if len(parts) < 9:
            continue
        is_dir = ln.startswith("d")
        name = parts[8]
        size = 0 if is_dir else int(parts[4])
        items.append({"name": name, "size": size, "is_dir": is_dir})
    return items


def _ftp_list_dir(relpath=""):
    f = _open_ftp()
    try:
        return list_dir_on(f, relpath)
    finally:
        try:
            f.quit()
        except Exception:
            pass


def _ftp_stat(relpath):
    f = _open_ftp()
    try:
        return f.size(relpath)
    except Exception:
        return None
    finally:
        try:
            f.quit()
        except Exception:
            pass


def _ftp_download_to(relpath, local_path, timeout=300):
    os.makedirs(os.path.dirname(local_path) or ".", exist_ok=True)
    f = _open_ftp()
    try:
        rc = f.ntransfercmd("RETR " + relpath)[0]
        rc.settimeout(timeout)
        total = 0
        with open(local_path, "wb") as fh:
            while True:
                b = rc.recv(1 << 20)
                if not b:
                    break
                fh.write(b)
                total += len(b)
        rc.close()
        f.voidresp()
        return total
    except Exception:
        try:
            f.quit()
        except Exception:
            pass
        c, s = _open_sftp()
        try:
            total = 0
            with s.open(config.FTP_BASE + "/" + relpath, "rb") as rf, \
                 open(local_path, "wb") as wf:
                while True:
                    b = rf.read(1 << 20)
                    if not b:
                        break
                    wf.write(b)
                    total += len(b)
            return total
        finally:
            s.close()
            c.close()
    finally:
        try:
            f.quit()
        except Exception:
            pass


def _ftp_upload_file(local_path, relpath):
    parent = os.path.dirname(relpath)
    if parent:
        _ftp_makedirs(parent)
    f = _open_ftp()
    try:
        with open(local_path, "rb") as fh:
            f.storbinary("STOR " + relpath, fh, blocksize=1 << 20)
        return f.size(relpath)
    except Exception:
        try:
            f.quit()
        except Exception:
            pass
        c, s = _open_sftp()
        try:
            s.put(local_path, config.FTP_BASE + "/" + relpath)
            return s.stat(config.FTP_BASE + "/" + relpath).st_size
        finally:
            s.close()
            c.close()
    finally:
        try:
            f.quit()
        except Exception:
            pass


def _ftp_delete(relpath):
    f = _open_ftp()
    try:
        f.delete(relpath)
        return True
    except Exception:
        try:
            f.quit()
        except Exception:
            pass
        c, s = _open_sftp()
        try:
            s.remove(config.FTP_BASE + "/" + relpath)
            return True
        except Exception:
            return False
        finally:
            s.close()
            c.close()
    finally:
        try:
            f.quit()
        except Exception:
            pass


def _ftp_rename(oldpath, newpath):
    f = _open_ftp()
    try:
        f.rename(oldpath, newpath)
        return True
    except Exception:
        return False
    finally:
        try:
            f.quit()
        except Exception:
            pass


def _ftp_makedirs(relpath):
    f = _open_ftp()
    try:
        parts = [p for p in relpath.split("/") if p]
        cur = ""
        for p in parts:
            cur = (cur + "/" + p) if cur else p
            try:
                f.mkd(cur)
            except Exception:
                pass
        return True
    finally:
        try:
            f.quit()
        except Exception:
            pass


def _ftp_rmtree(relpath):
    try:
        c, s = _open_sftp()
        try:
            _sftp_rmtree(s, config.FTP_BASE + "/" + relpath)
            return True
        finally:
            s.close()
            c.close()
    except Exception:
        return False


def _sftp_rmtree(s, path):
    try:
        for e in s.listdir_attr(path):
            full = path + "/" + e.filename
            if e.st_mode & 0o040000:
                _sftp_rmtree(s, full)
            else:
                s.remove(full)
        s.rmdir(path)
    except Exception:
        pass
