# -*- coding: utf-8 -*-
"""FTP 书库自动同步：检测 FTP 分类目录的增删改，同步站内 books 表与分类
用法:
  python sync.py           # 手动同步一次
（app 启动后由后台线程周期性调用，也可通过 /api/admin/sync 手动触发）"""
import os, sys, time, threading
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "ebook_task"))
import config, db, ftp_service
import paramiko
import classify  # CAT_FOLDERS / CLASSES / final_name

_lock = threading.Lock()
_last = {"time": None, "result": None, "running": False}


def scan_ftp():
    """扫描全部分类目录，返回 {relpath: (size, folder, letter)}。
    使用 SFTP（UTF-8）扫描，避免 WebDAV 大目录超时 / FTP GBK 编码把含特殊字符
    （如 • U+2022）的文件名解析成乱码，导致误删库内记录。"""
    result = {}
    base = (config.FTP_BASE or "").rstrip("/")
    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    c.connect(config.SFTP_HOST, port=config.SFTP_PORT, username=config.FTP_USER,
              password=config.FTP_PASS, timeout=30, allow_agent=False, look_for_keys=False)
    s = c.open_sftp()
    try:
        for letter, folder in classify.CAT_FOLDERS.items():
            try:
                entries = s.listdir_attr(base + "/" + folder)
            except Exception:
                continue
            for e in entries:
                if e.st_mode & 0o040000:  # 目录跳过
                    continue
                name = e.filename
                ext = ("." + name.rsplit(".", 1)[-1].lower()) if "." in name else ""
                if ext not in config.BOOK_EXTS:
                    continue
                result[folder + "/" + name] = (e.st_size, folder, letter)
    finally:
        s.close()
        c.close()
    return result


def sync_once():
    """同步一次，返回统计；并发调用会被锁串行化"""
    if not _lock.acquire(blocking=False):
        return {"running": True, "added": 0, "removed": 0, "size_updated": 0}
    try:
        _last["running"] = True
        t0 = time.time()
        remote = scan_ftp()
        remote_set = set(remote.keys())
        # 仅同步系统书（owner_id IS NULL）；会员上传的书由上传/删除接口自行管理，
        # 存放在 FTP 的「会员上传」目录，不在分类目录扫描范围内，避免被误删
        db_rows = db.q("SELECT id, path, size FROM books WHERE owner_id IS NULL")
        db_map = {r["path"]: r for r in db_rows}
        db_set = set(db_map.keys())
        added = removed = updated = 0
        # 1) 新增
        for path in sorted(remote_set - db_set):
            size, folder, letter = remote[path]
            name = path.rsplit("/", 1)[-1]
            ext = ("." + name.rsplit(".", 1)[-1].lower()) if "." in name else ""
            fn, title, author = classify.final_name(name)
            if not title:
                title = os.path.splitext(name)[0] or name
            cls = classify.CLASSES.get(letter, {"ddc": "-"})
            db.ex("""INSERT INTO books
                     (path,title,author,category,clc,ddc,ext,size,created_at,updated_at)
                     VALUES (?,?,?,?,?,?,?,?,?,?)""",
                  (path, title, author, folder, letter, cls.get("ddc", "-"), ext,
                   size, db.now(), db.now()))
            added += 1
        # 2) 删除（FTP 已不存在）；跳过以 / 开头的服务器绝对路径（如 /迅雷/电子书，不在分类目录扫描范围，由外部导入管理）
        for path in sorted(db_set - remote_set):
            if path.startswith("/"):
                continue
            # 双保险：删除前用 stat 再确认一次文件真的不存在，避免扫描遗漏误删记录
            if ftp_service.stat(path) is not None:
                continue
            bid = db_map[path]["id"]
            for t in ("shelves", "progress", "shares"):
                db.ex(f"DELETE FROM {t} WHERE book_id=?", (bid,))
            db.ex("DELETE FROM books WHERE id=?", (bid,))
            removed += 1
        # 3) 大小变化
        for path in remote_set & db_set:
            if remote[path][0] != db_map[path]["size"]:
                db.ex("UPDATE books SET size=?, updated_at=? WHERE id=?",
                      (remote[path][0], db.now(), db_map[path]["id"]))
                updated += 1
        result = {"added": added, "removed": removed, "size_updated": updated,
                  "total": len(remote_set), "elapsed": round(time.time() - t0, 1)}
        _last["time"] = db.now()
        _last["result"] = result
        return result
    finally:
        _last["running"] = False
        _lock.release()


def last_result():
    return {"time": _last["time"], "running": _last["running"], "result": _last["result"]}


def start_sync_loop(interval_sec=600):
    """后台线程周期性同步"""
    def loop():
        while True:
            try:
                sync_once()
            except Exception:
                pass
            time.sleep(interval_sec)
    t = threading.Thread(target=loop, daemon=True, name="ftp-sync")
    t.start()
    return t


if __name__ == "__main__":
    db.init_db()
    print(sync_once())
