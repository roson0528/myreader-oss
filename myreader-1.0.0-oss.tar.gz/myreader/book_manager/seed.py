# -*- coding: utf-8 -*-
"""种子导入：扫描 FTP 上 22 个 CLC 分类目录，建立 books 表
用法: python seed.py  （幂等，可重复执行）"""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "ebook_task"))
import config, db, ftp_service
import classify  # 复用 final_name / CLASSES / CAT_FOLDERS

def main():
    db.init_db()
    letters = list(classify.CAT_FOLDERS.keys())
    total = 0
    added = 0
    t0 = time.time()
    for letter in letters:
        folder = classify.CAT_FOLDERS[letter]
        items = ftp_service.list_dir(folder)
        for it in items:
            if it["is_dir"]:
                continue
            name = it["name"]
            ext = ("." + name.rsplit(".", 1)[-1].lower()) if "." in name else ""
            if ext not in config.BOOK_EXTS:
                continue
            path = folder + "/" + name
            # 已存在则跳过
            if db.q("SELECT id FROM books WHERE path=?", (path,), one=True):
                total += 1
                continue
            fn, title, author = classify.final_name(name)
            if not title:
                title = os.path.splitext(name)[0] or name
            cls = classify.CLASSES.get(letter, {"ddc": "-"})
            db.ex("""INSERT INTO books
                     (path,title,author,category,clc,ddc,ext,size,created_at,updated_at)
                     VALUES (?,?,?,?,?,?,?,?,?,?)""",
                  (path, title, author, folder, letter, cls.get("ddc", "-"), ext,
                   it["size"], db.now(), db.now()))
            added += 1
            total += 1
        cnt = sum(1 for i in items if not i["is_dir"] and ("." + i["name"].rsplit(".", 1)[-1].lower() if "." in i["name"] else "") in config.BOOK_EXTS)
        print(f"{folder}: {cnt} 本", flush=True)
    print(f"\n完成: 总 {total} 本, 新增 {added}, 耗时 {time.time()-t0:.0f}s")

if __name__ == "__main__":
    main()
