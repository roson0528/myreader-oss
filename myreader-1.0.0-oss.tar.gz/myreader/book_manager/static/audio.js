/* 有声电子书：列表 / 详情 / 播放（含文字同步、蓝牙控制、听读进度）
 *
 * 与「听书」（listen.js）的区别：
 *   听书 = 现场把书的文字用 TTS 念出来（按需合成，原生 PlaybackService 播放）；
 *   有声 = 播放制作模块**已经合成并上传到 NAS 的 MP3**。
 * 所以这里用 WebView 自己的 <audio> 播放，音频由服务端 /api/audiobooks/<id>/file/<seq>
 * 从 WebDAV 代理出来（支持 Range，能拖进度条）。
 *
 * 蓝牙/锁屏控制走 W3C Media Session（Chrome/WebView 会把 MediaMetadata 与
 * 动作回调接到系统媒体会话，车机与蓝牙耳机的播放/暂停/上一首/下一首就有效），
 * 不需要改动原生 APK。若后台把服务端「蓝牙联动」开关关了，这里就只注册
 * 最小的一组回调（效果一致，只是少一层本地联动）。
 */
let AU_LIST = [], AU_CATS = [], AU_CAT = 0, AU_KEY = '';
let AU_DETAIL = null;
let AUP = null;          // 播放状态：{lib, chap, segs, idx, saveT, ended}
let AUP_TICK = null;
// ★ 全局唯一的播放器：离开播放页、切章、重绘视图都**不能**重建它，
//   否则音频会中断（HTMLAudioElement 一被移出文档就停）。悬浮播放条也用它。
const AU_AUDIO = (typeof Audio !== 'undefined') ? new Audio() : null;
if (AU_AUDIO) {
  AU_AUDIO.id = 'aup-audio';      // 保留固定 id：页面、测试、样式都按它找
  AU_AUDIO.preload = 'metadata';
  // ★ 不用原生控件：它右侧的「…」菜单里有「下载」「播放速度」，用户明确不要。
  //   播放/暂停/进度条/时间全部自己画（ap-* 那套），反而更贴合章节播放。
  AU_AUDIO.controls = false;
}

// ★ api() 把 opts 原样交给 fetch，不会替你加 Content-Type。
//   不声明 application/json 的话，FastAPI 会把 body 当成纯字符串，
//   报 422「Input should be a valid dictionary」（踩过，进度一直存不上）。
function auPost(path, obj) {
  return api(path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(obj || {})
  });
}

// ---------------------------------------------------------------- 列表页
async function loadAudio() {
  const box = document.getElementById('au-list');
  if (!box) return;
  if (typeof GUEST !== 'undefined' && GUEST) {
    const tb = document.querySelector('#page-audio .au-toolbar');
    if (tb) tb.style.display = 'none';
    document.getElementById('au-cats').innerHTML = '';
    document.getElementById('au-empty').style.display = 'none';
    box.innerHTML = '<div class="empty" style="grid-column:1/-1">有声电子书需要登录后查看' +
      '<div style="margin-top:12px"><button class="btn" onclick="showAuth()">登录 / 注册</button></div></div>';
    return;
  }
  const tb0 = document.querySelector('#page-audio .au-toolbar');
  if (tb0) tb0.style.display = '';
  box.innerHTML = '<div class="muted" style="padding:16px 4px">加载中…</div>';
  let d;
  try {
    d = await api('/api/audiobooks?cat_id=' + (AU_CAT || 0) +
                  '&q=' + encodeURIComponent(AU_KEY || ''));
  } catch (e) {
    box.innerHTML = '<div class="muted" style="padding:16px 4px">' + esc(e.message || '加载失败') + '</div>';
    return;
  }
  AU_LIST = d.items || [];
  AU_CATS = d.cats || [];
  auRenderCats();
  document.getElementById('au-empty').style.display = AU_LIST.length ? 'none' : '';
  if (!AU_LIST.length) { box.innerHTML = ''; return; }
  box.innerHTML = AU_LIST.map(auCard).join('');
}

function auFmtHMS(sec) {
  sec = Math.max(0, Math.round(sec || 0));
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
  const p = n => (n < 10 ? '0' + n : '' + n);
  return h > 0 ? h + ':' + p(m) + ':' + p(s) : m + ':' + p(s);
}
function auFmtDur(sec) {
  sec = Math.max(0, Math.round(sec || 0));
  const h = Math.floor(sec / 3600), m = Math.round((sec % 3600) / 60);
  if (h > 0) return h + ' 小时 ' + m + ' 分';
  return Math.max(1, m) + ' 分钟';
}

function auRenderCats() {
  const el = document.getElementById('au-cats');
  if (!el) return;
  const total = AU_CATS.reduce((a, c) => a + (c.count || 0), 0);
  const one = (id, name, n) =>
    '<button class="au-cat' + (AU_CAT === id ? ' on' : '') + '" onclick="auPickCat(' + id + ')">' +
    esc(name) + (n ? ' <span class="au-cat-n">' + n + '</span>' : '') + '</button>';
  let h = one(0, '全部', total);
  h += AU_CATS.map(c => one(c.id, c.name, c.count)).join('');
  if (AU_CATS.length) h += one(-1, '未分类', 0).replace(/<span class="au-cat-n">0<\/span>/, '');
  el.innerHTML = h;
}
function auPickCat(id) {
  AU_CAT = (id === -1 || id === 0) ? 0 : id;
  loadAudio();
}
function auSearch() {
  const el = document.getElementById('au-search');
  AU_KEY = el ? el.value.trim() : '';
  loadAudio();
}

function auCard(it) {
  const cov = it.cover_url
    ? '<img class="au-cover" loading="lazy" src="' + esc(coverUrl(it.cover_url)) + '" onerror="this.style.display=\'none\'">'
    : '<div class="au-cover au-cover-ph">有声</div>';
  const pr = it.progress && it.progress.percent ? it.progress.percent : 0;
  const bar = pr > 0
    ? '<div class="au-bar"><i style="width:' + Math.min(100, pr).toFixed(1) + '%"></i></div>' +
      '<div class="au-sub">听到第 ' + (it.progress.chap_seq || 1) + ' 章 · ' + pr.toFixed(0) + '%</div>'
    : '';
  const tag = it.locked ? '<span class="au-tag lock">部分需兑换</span>'
    : (it.free_chapters ? '<span class="au-tag free">前 ' + it.free_chapters + ' 章免费</span>' : '');
  // 首页「🔥 热度推荐」的入口就放在卡片上（管理员才看得见那颗星）。
  // ★ 为什么放在卡片而不是只放详情页：管理员往往要连着挑好几本，进详情再返回太啰嗦。
  //   星星是绝对定位的独立按钮，不参与 flex 布局，所以不会把封面/标题挤动；
  //   点击必须 stopPropagation，否则会连带触发整张卡片的 openAudio。
  // 非管理员则给一个静态「推荐」角标 —— 让人看得出这是运营推荐位。
  const admin = (typeof USER !== 'undefined' && USER && USER.role === 'admin');
  const on = !!it.guest_featured;
  let corner = '', cls = '';
  if (admin && it.book_id) {
    cls = ' has-star';
    corner = '<button class="au-star' + (on ? ' on' : '') + '"'
      + ' title="' + (on ? '取消首页「热度推荐」' : '加入首页「热度推荐」') + '"'
      + ' onclick="event.stopPropagation();auFeature(' + it.id + ',' + (on ? 1 : 0) + ')">'
      + (on ? '★' : '☆') + '</button>';
  } else if (on) {
    cls = ' has-badge';
    corner = '<span class="au-star-badge">推荐</span>';
  }
  return '<div class="au-card' + cls + '" data-lib="' + it.id + '" onclick="openAudio(' + it.id + ')">' +
    corner + cov +
    '<div class="au-meta"><div class="au-title">' + esc(it.title) + '</div>' +
    '<div class="au-sub">' + esc(it.author || '佚名') + (it.rating ? ' · ★ ' + it.rating : '') + '</div>' +
    '<div class="au-sub">' + it.total_chapters + ' 章 · ' + auFmtDur(it.total_seconds) + '</div>' +
    bar + tag + '</div></div>';
}

// 只把受影响的卡片原地重画，不整页 loadAudio()：
// 整页重载会让滚动位置跳回顶部、图片重新闪一下，连着挑几本时很难用。
function auRepaintCards(bookId) {
  const box = document.getElementById('au-list');
  if (!box || !bookId) return;
  (AU_LIST || []).forEach(x => {
    if (x.book_id !== bookId) return;
    const old = box.querySelector('.au-card[data-lib="' + x.id + '"]');
    if (!old) return;
    const tmp = document.createElement('div');
    tmp.innerHTML = auCard(x);
    old.replaceWith(tmp.firstChild);
  });
}

// 管理员点卡片上的星标：把这本书加进 / 移出首页「🔥 热度推荐」。
// ★ 复用后台「书籍管理 → 访客热度推荐」那同一个接口、同一个标记（books.guest_featured）：
//   所以这里改了，书籍管理里那张表的「推荐」角标也会跟着变，两边永远是同一份状态。
//   首页的「热度推荐」板块（登录用户）和未登录访客首页看到的，就是这个标记。
async function auFeature(libId, on) {
  const it = (AU_LIST || []).find(x => x.id === libId)
    || (AU_DETAIL && AU_DETAIL.id === libId ? AU_DETAIL : null);
  const bookId = it && it.book_id;
  if (!bookId) { toast('这本没有关联书籍，无法加入推荐'); return; }
  try {
    await api('/api/admin/books/guest-feature', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ book_ids: [bookId], featured: on ? 0 : 1 })
    });
  } catch (e) { toast(e.message || '操作失败'); return; }
  const nv = on ? 0 : 1;
  // 同一本书可能对应多条有声记录（不同形态），全部一起同步
  (AU_LIST || []).forEach(x => { if (x.book_id === bookId) x.guest_featured = nv; });
  if (AU_DETAIL && AU_DETAIL.book_id === bookId) AU_DETAIL.guest_featured = nv;
  toast(nv ? '已加入首页「热度推荐」，未登录访客的首页也会看到' : '已取消首页「热度推荐」');
  auRepaintCards(bookId);
  if (AU_DETAIL && AU_DETAIL.id === libId) renderAudioDetail();
}

// ---------------------------------------------------------------- 书架侧栏「有声阅读」
// 取代原来侧栏的「公共书库」：显示有声电子书的分类与书名。
// 版面是桌面端 1/3 宽度（**宽度不许改**），所以每行 3 本、最多 4 行 = 12 本，多出来的翻页。
// 从「2 本 × 9 行」改成「3 本 × 4 行」：行数少了、封面也跟着小一圈，
// 但一屏能看到更多书，也不用为了看第 2 行去滚。
let AU_SHELF = { cat: 0, page: 1, size: 12, items: [] };

async function auShelfLoad(page) {
  const box = document.getElementById('au-shelf-list');
  if (!box) return;
  // ★ 未登录：整个「有声阅读」栏目都不显示（服务端也不给数据，见 ablib_api.access_info）。
  //   侧栏整块隐藏而不是显示一句「请登录」——用户要的是内容不可见，
  //   而且书架页在游客下本来就只有「书架收藏」这一栏。
  if (typeof GUEST !== 'undefined' && GUEST) {
    const aside = document.getElementById('shelf-public');
    if (aside) aside.style.display = 'none';
    return;
  }
  if (page) AU_SHELF.page = page;
  let d;
  try {
    d = await api('/api/audiobooks?cat_id=' + (AU_SHELF.cat || 0));
  } catch (e) {
    box.innerHTML = '<div class="muted" style="padding:10px 2px">' + esc(e.message || '加载失败') + '</div>';
    document.getElementById('au-shelf-pager').innerHTML = '';
    setAuShelfHint(0);
    return;
  }
  AU_SHELF.items = d.items || [];
  auShelfCats(d.cats || [], typeof d.total === 'number' ? d.total : AU_SHELF.items.length);
  if (!AU_SHELF.items.length) {
    box.innerHTML = '<div class="muted" style="padding:10px 2px">' +
      (AU_SHELF.cat ? '该分类下还没有有声电子书' : '还没有有声电子书') + '</div>';
    document.getElementById('au-shelf-pager').innerHTML = '';
    return;
  }
  const size = AU_SHELF.size;
  const pages = Math.max(1, Math.ceil(AU_SHELF.items.length / size));
  if (AU_SHELF.page > pages) AU_SHELF.page = pages;
  const slice = AU_SHELF.items.slice((AU_SHELF.page - 1) * size, AU_SHELF.page * size);
  box.innerHTML = slice.map(auShelfCard).join('');
  auShelfPager(pages);
}

// 提示行：格式对齐「书架收藏」那行的「已收藏 0 / 50 本」。
// 这里没有配额概念，给的是**全站有声电子书总量** —— 侧栏一屏只放得下 12 本，
// 写总量是为了让人知道「还有很多」，而不是以为总共就这些。
function setAuShelfHint(n) {
  const el = document.getElementById('au-shelf-hint');
  if (el) el.textContent = '有声电子书 ' + (n || 0) + ' 本';
}

function auShelfCats(cats, auTotal) {
  const el = document.getElementById('au-shelf-cats');
  if (!el) return;
  const total = cats.reduce((a, c) => a + (c.count || 0), 0);
  // ★ 别拿分类求和当总数：ab_lib_cat 一张行都没有时 cats 是空的、求和恒为 0，
  //   于是明明有 3 本书却显示「有声电子书 0 本」。以接口给的 total 为准。
  setAuShelfHint(auTotal);
  const one = (id, name) =>
    '<button class="au-cat' + (AU_SHELF.cat === id ? ' on' : '') +
    '" onclick="auShelfPick(' + id + ')">' + esc(name) + '</button>';
  el.innerHTML = one(0, '全部' + (total ? ' (' + total + ')' : '')) +
    cats.map(c => one(c.id, c.name + (c.count ? ' (' + c.count + ')' : ''))).join('');
}
function auShelfPick(cid) {
  AU_SHELF.cat = cid || 0;
  AU_SHELF.page = 1;
  auShelfLoad();
}
function auShelfGo(p) {
  const pages = Math.max(1, Math.ceil(AU_SHELF.items.length / AU_SHELF.size));
  AU_SHELF.page = Math.max(1, Math.min(pages, p));
  auShelfLoad();
}
function auShelfPager(pages) {
  const p = document.getElementById('au-shelf-pager');
  if (!p) return;
  if (pages <= 1) { p.innerHTML = ''; return; }
  p.innerHTML =
    '<button onclick="auShelfGo(' + (AU_SHELF.page - 1) + ')"' +
      (AU_SHELF.page <= 1 ? ' disabled' : '') + '>‹</button>' +
    '<span class="muted" style="font-size:13px">第 ' + AU_SHELF.page + ' / ' + pages + ' 页</span>' +
    '<button onclick="auShelfGo(' + (AU_SHELF.page + 1) + ')"' +
      (AU_SHELF.page >= pages ? ' disabled' : '') + '>›</button>';
}

// 侧栏卡片：竖排（封面在上面），每行 3 本时宽度只有 1/9 屏，横排会挤成一团
function auShelfCard(it) {
  const cov = it.cover_url
    ? '<img class="au-cover" loading="lazy" src="' + esc(coverUrl(it.cover_url)) + '" ' +
      'onerror="this.replaceWith(placeholderCover(this))">'
    : '<div class="au-cover au-cover-ph">有声</div>';
  const pr = it.progress && it.progress.percent ? it.progress.percent : 0;
  return '<div class="au-shelf-card" onclick="openAudio(' + it.id + ')">' +
    '<div class="au-shelf-cov">' + cov + '</div>' +
    '<div class="au-title">' + esc(it.title) + '</div>' +
    '<div class="au-sub">' + it.total_chapters + ' 章 · ' + auFmtDur(it.total_seconds) + '</div>' +
    (pr > 0 ? '<div class="au-bar"><i style="width:' + Math.min(100, pr).toFixed(1) + '%"></i></div>' : '') +
    '</div>';
}

// ---------------------------------------------------------------- 详情页
function openAudio(id) {
  const target = '#/audio/' + id;
  if (location.hash !== target) location.hash = target;
  else openAudioView(id);
}
async function openAudioView(id) {
  const body = document.getElementById('au-detail-body');
  showView('audio');
  if (typeof GUEST !== 'undefined' && GUEST) {
    body.innerHTML = '<div class="empty">有声电子书需要登录后查看' +
      '<div style="margin-top:12px"><button class="btn" onclick="showAuth()">登录 / 注册</button></div></div>';
    return;
  }
  body.innerHTML = '<div class="muted" style="padding:16px">加载中…</div>';
  let d;
  try {
    d = await api('/api/audiobooks/' + id);
  } catch (e) {
    body.innerHTML = '<div class="muted" style="padding:16px">' + esc(e.message || '加载失败') + '</div>';
    return;
  }
  AU_DETAIL = d;
  document.getElementById('au-detail-title').textContent = d.title;
  renderAudioDetail();
}
function closeAudio() {
  // 从「图书详情」点「有声阅读」进来的：返回那本书的详情（audioBackTo 由 route() 判定）。
  // 不这么做的话，「← 返回」会把从某本书进来的人一路甩到「有声电子书」列表 ——
  // 他会莫名其妙：我明明是从那本书点进来的。
  if (/^#\/book\/\d+$/.test(audioBackTo || '')) {
    const back = audioBackTo;
    audioBackTo = '';                 // 用完即清，避免下次从列表进来时误用
    location.hash = back;             // 交给路由 → openDetailView
    return;
  }
  audioBackTo = '';
  location.hash = '#/audio';
  switchPageView('audio');
  loadAudio();
}

function renderAudioDetail() {
  const d = AU_DETAIL, body = document.getElementById('au-detail-body');
  if (!d) return;
  const a = d.access || {};
  const p = d.progress || {};
  const cov = d.cover_url
    ? '<img class="ad-cover" src="' + esc(coverUrl(d.cover_url)) + '" onerror="this.style.display=\'none\'">'
    : '<div class="ad-cover ad-cover-ph">有声</div>';
  const nxt = p.chap_seq || 1;
  const hasProg = p.chap_seq && (p.offset > 0 || p.chap_seq > 1);
  const freeTip = a.free
    ? '前 ' + a.free + ' 章免费'
    : (a.per_chapter || a.per_book
        ? ('每章 ' + a.per_chapter + ' 片树叶' + (a.per_book ? ' / 整本 ' + a.per_book + ' 片' : ''))
        : '全部免费');
  let h = '<div class="ad-hero">' + cov + '<div class="ad-info">' +
    '<div class="ad-title">' + esc(d.title) + '</div>' +
    '<div class="ad-line">' + esc(d.author || '佚名') + '</div>' +
    (d.rating ? '<div class="ad-line" style="color:#f59e0b;font-weight:700">★ ' + d.rating + ' 分</div>' : '') +
    '<div class="ad-line muted">归类：' + esc(d.cat_name || '未分类') + '</div>' +
    '<div class="ad-line muted">' + d.total_chapters + ' 章 · 共 ' + auFmtDur(d.total_seconds) + '</div>' +
    '<div class="ad-line muted">' + esc(freeTip) +
      (USER ? ' · 树叶 ' + (a.balance || 0) + ' 片' : '') + '</div>' +
    '</div></div>';

  // 管理员：详情页也给一个带文字的入口（卡片上那颗星太小，第一次未必注意到）。
  // 说明文字讲清楚它落到哪儿 —— 这个标记同时就是「访客推荐」，两个地方是同一份状态。
  const adAdmin = (typeof USER !== 'undefined' && USER && USER.role === 'admin');
  h += '<div class="ad-acts">' +
    '<button class="btn" onclick="audioPlay(' + d.id + ',' + nxt + ',true)">' +
    (hasProg ? '▶ 继续听读（第 ' + nxt + ' 章）' : '▶ 有声听书') + '</button>' +
    (a.per_book && !a.bought_book && d.access.ok
      ? '<button class="btn ghost" onclick="auUnlock(' + d.id + ',\'book\',0)">整本兑换（' + a.per_book + ' 🌿）</button>'
      : '') +
    // ★ 反方向的入口：有声书是同一本小说的「听」形态，听完想看文字版得有路可走。
    //   首页「热度推荐」现在会把有有声版的书直接指到这里，没这个按钮就回不去电子书了。
    (d.book_readable
      ? '<button class="btn ghost" onclick="openDetail(' + d.book_id + ')">📖 读电子书</button>'
      : '') +
    (adAdmin && d.book_id
      ? '<button class="btn ghost" onclick="auFeature(' + d.id + ',' + (d.guest_featured ? 1 : 0) + ')">' +
        // 不加 ★/☆：详情页上面就有一行「★ 8.7 分」的评分，按钮再用星号容易看混；
        // 而且下面那句说明已经把状态讲清楚了（「这本已在首页…里」）。
        (d.guest_featured ? '取消首页「热度推荐」' : '加入首页「热度推荐」') + '</button>'
      : '') +
    '</div>';
  if (adAdmin && d.book_id) {
    h += '<div class="muted" style="font-size:12px;margin:-4px 0 6px">' +
      (d.guest_featured
        ? '这本已在首页「🔥 热度推荐」里：登录用户在首页可见，未登录访客的首页也能看到并可试读、下载。'
        : '加入首页「🔥 热度推荐」后，登录用户在首页可见，未登录访客的首页也能看到并可试读、下载。') +
      '该板块最多展示 6 本，新加入的排在最前。' +
      '</div>';
  }

  if (d.intro) h += '<div class="card" style="margin:12px 0"><div class="muted" style="font-size:13px">' +
    esc(String(d.intro).slice(0, 400)) + '</div></div>';

  h += '<h3 class="ad-h">章节（' + d.chapters.length + '）</h3><div class="ad-chaps">';
  h += d.chapters.map(c => {
    const lock = c.locked
      ? '<span class="au-tag lock">' + (a.per_chapter || 0) + '🌿</span>'
      : '';
    const cur = (p.chap_seq === c.seq && hasProg) ? '<span class="au-tag cur">上次听到这</span>' : '';
    const click = c.locked ? 'auUnlock(' + d.id + ',\'chapter\',' + c.seq + ')'
                           : 'audioPlay(' + d.id + ',' + c.seq + ',false)';
    return '<div class="ad-chap' + (c.locked ? ' locked' : '') + '" onclick="' + click + '">' +
      '<span class="ad-chap-no">' + c.seq + '</span>' +
      '<span class="ad-chap-t">' + esc(c.title) + '</span>' +
      '<span class="ad-chap-d muted">' + auFmtHMS(c.dur_sec) + '</span>' + lock + cur + '</div>';
  }).join('');
  h += '</div>';
  if (!d.has_text) h += '<div class="muted" style="padding:8px 4px">播放时暂无文字内容</div>';
  body.innerHTML = h;
  document.getElementById('au-detail-title').textContent = d.title;
}

async function auUnlock(libId, kind, chap) {
  const cfgTip = kind === 'book' ? '整本' : ('第 ' + chap + ' 章');
  if (!confirm('用树叶兑换' + cfgTip + '的收听权限？')) return;
  try {
    const r = await auPost('/api/audiobooks/' + libId + '/unlock', { kind: kind, chap: chap });
    toast(r.spent ? ('已兑换，消耗 ' + r.spent + ' 🌿') : '已拥有该权限');
    await openAudioView(libId);
  } catch (e) {
    toast(e.message || '兑换失败');
  }
}

// ---------------------------------------------------------------- 播放页
function audioPlay(libId, chap, fromProgress) {
  // ★ 同一本同一章再次进入（比如从悬浮条点回来）＝**继续当前会话**：
  //   保持播放不断，只是把视图重新挂上去。重建会话会让音频从头开始。
  const same = !!(AUP && AUP.lib && AUP.lib.id === libId && AUP.chap === chap);
  if (!same) {
    AUP = { lib: null, chap: chap || 1, segs: [], idx: 0, audio: AU_AUDIO, saveT: 0, ended: false,
            startAt: 0, fromProgress: !!fromProgress,
            // 原生播放用到的字段（APP 内才为 true，网页里一直是 false）
            native: false, nativePos: 0, nativeDur: 0, nativeSaveT: 0,
            chapters: [], chapIndex: [], chapter: '',
            // ★ 已经叫原生切到哪一章（seq）、什么时候叫的。切到位之前，
            //   原生报回来的还是**上一章**的 index/位置，必须丢掉 —— 见 auOnNativeState。
            switchTo: 0, switchAt: 0 };
  }
  showView('audioplay');
  document.getElementById('aup-body').innerHTML = '<div class="muted" style="padding:16px">加载中…</div>';
  AUPInit(libId, chap, fromProgress, same);
}

// 只换「这一章的句子」并重绘文字区，**不动播放会话**。
//
// 谁需要它：原生模式下切章的三条路都不重新初始化播放（整本清单早交给前台服务了）——
//   ① 用户点「下一章/上一章」（auStep）；
//   ② 本章播完原生自动接下一章（auOnNativeState 里发现 st.index 变了）；
//   ③ 通知栏/锁屏上切章。
//
// ★★ 以前这三条路都只调 renderAUP()，而 AUP.segs 还是**上一章的句子**：
//   · 文字区照旧显示旧章内容（用户报的「切下一章只有声音切了、文字没变」）；
//   · 点击某一句是按 `章起点 + 该句章内相对秒` 算目标位置，章起点已经换成新章、
//     句子却还是旧章的偏移 → 跳到错的地方（用户报的「点文本段落无法定位播放」）。
//   实测：《秋园》第 1 章点上第 5 句，seek 报 58955ms，正确应约 24120ms。
//
// 取的是 /lyrics?chap=<序号>；返回失败就置空（显示「暂无文字内容」），
// 绝不把上一章的句子留在这儿冒充本章 —— 那样点击照样会跳错地方。
async function auLoadSegs(chap) {
  if (!AUP || !AUP.lib) return;
  const libId = AUP.lib.id, base = AUP.chapStart || 0, want = chap;
  let segs = [];
  try {
    const ly = await api('/api/audiobooks/' + libId + '/lyrics?chap=' + want);
    // ★ 服务端给的是**文件内绝对时间**（一个 mp3 常装 2 章，第 2 章的句子
    //   start_sec 是从该文件开头算的，比如 167.65 而不是 0）。
    //   高亮与点击跳转都按「章内」算，所以统一减去本章起点再往下传。
    //   不减的话：第 1 章正常（起点是 0），**从第 2 章开始整章都停在第 1 句**。
    segs = (ly.segs || []).map(x => ({
      text: x.text,
      start_sec: Math.max(0, (x.start_sec || 0) - base),
      dur_sec: x.dur_sec || 0
    }));
  } catch (e) {
    segs = [];
  }
  // 这中间又切章了 / 退出播放页了 / 换书了 → 丢掉这一帧，别把对不上的文字贴上去
  if (!AUP || AUP.lib.id !== libId || AUP.chap !== want) return;
  AUP.segs = segs;
  AUP.idx = 0;
  renderAUP();
  // 进章先点亮第 1 句：原生的位置回报要等 500ms 才来，中间看着像「高亮不动」
  try { AUPOnTime(); } catch (e) {}
}

async function AUPInit(libId, chap, fromProgress, cont) {
  let d;
  try {
    d = await api('/api/audiobooks/' + libId);
  } catch (e) {
    document.getElementById('aup-body').innerHTML =
      '<div class="muted" style="padding:16px">' + esc(e.message || '加载失败') + '</div>';
    return;
  }
  AUP.lib = d;
  const c = (d.chapters || []).find(x => x.seq === chap);
  if (!c) { toast('章节不存在'); closeAudioPlay(); return; }
  AUP.chap = chap;
  AUP.fileSeq = c.file_seq;
  AUP.chapStart = c.start_sec || 0;
  AUP.chapEnd = (c.start_sec || 0) + (c.dur_sec || 0);
  AUP.nChap = (d.chapters || []).length;
  // 位置来源优先级：继续当前会话（就地接着放）> 服务端记录的进度 > 从头
  if (cont && AU_AUDIO) {
    AUP.startAt = Math.max(0, (AU_AUDIO.currentTime || 0) - AUP.chapStart);
  } else {
    AUP.startAt = (fromProgress && d.progress && d.progress.chap_seq === chap)
      ? (d.progress.offset || 0) : 0;
  }
  // 句子时间轴统一走 auLoadSegs（取回 + 减去本章起点 + 重绘 + 点亮第 1 句），
  // 免得这里和切章那几处各写一份、改漏一边。
  await auLoadSegs(chap);
  AU_LOCKED = false;      // 每次进播放页重新评估：这个会话还没被判定为「不是我们的」
  await AUPAudio(cont);
  auLockStart();          // 一个账号同一时间只允许一台设备听有声书
  AUPFloatUpdate();
}

function renderAUP() {
  const d = AUP.lib, c = (d.chapters || []).find(x => x.seq === AUP.chap) || {};
  const cov = d.cover_url
    ? '<img class="ap-cover" src="' + esc(coverUrl(d.cover_url)) + '" onerror="this.style.display=\'none\'">'
    : '<div class="ap-cover ap-cover-ph">有声</div>';
  let texts;
  if (AUP.segs.length) {
    texts = AUP.segs.map((s, i) =>
      '<div class="ap-line" id="aup-l' + i + '" data-t="' + s.start_sec + '" ' +
      'onclick="auSeekTo(' + s.start_sec + ',' + i + ')">' + esc(s.text) + '</div>').join('');   // 秒为章内相对：网页分支自己加回 chapStart，原生分支交给原生加（mp.seekTo(st + ms)）；下标用来精确点亮
  } else {
    // ★ 不是系统生成的有声书（没有留存的分句时间轴）就显示这句
    texts = '<div class="ap-notext">暂无文字内容</div>';
  }
  document.getElementById('aup-body').innerHTML =
    '<div class="ap-head">' + cov +
      '<div><div class="ap-title">' + esc(d.title) + '</div>' +
      '<div class="ap-sub">第 ' + AUP.chap + ' / ' + (AUP.nChap || d.total_chapters) + ' 章 · ' +
        esc(c.title || '') + '</div>' +
      '<div class="ap-sub muted">' + auFmtHMS(c.dur_sec || 0) + '</div></div></div>' +
    '<div class="ap-player">' +
      '<div id="ap-slot" class="ap-slot"></div>' +
      '<div class="ap-bar">' +
        '<input type="range" id="ap-seek" min="0" max="1000" step="1" value="0" ' +
          'oninput="apSeekInput(this.value)" onchange="apSeekCommit(this.value)">' +
      '</div>' +
      '<div class="ap-times"><span id="ap-cur">0:00</span>' +
        '<span id="ap-total">' + auFmtHMS(c.dur_sec || 0) + '</span></div>' +
      '<div class="ap-ctrl">' +
        '<button class="btn ghost sm" onclick="auStep(-1)">⏮ 上一章</button>' +
        '<button class="btn ap-play" id="ap-play" onclick="apToggle()">▶</button>' +
        '<button class="btn ghost sm" id="ap-next" onclick="auStep(1)">下一章 ⏭</button>' +
      '</div>' +
    '</div>' +
    '<div class="ap-textwrap-wrap">' +
      '<div class="ap-textwrap" id="aup-texts" onscroll="aupTextScroll()">' + texts + '</div>' +
      '<button class="btn ghost sm ap-follow hidden" id="aup-follow" onclick="aupFollowNow()">↓ 回到当前句</button>' +
    '</div>';
  document.getElementById('aup-title').textContent = d.title;
}

// ---------------------------------------------------------------- APP 原生播放
/* 为什么要有这一套：网页里的 <audio> 一旦 App 切后台/关屏，Chromium 会把页面媒体
   暂停掉（WebView 被判不可见），表现就是「切后台就停」。听书早就把播放搬进了
   原生前台服务（PlaybackService），有声这里走同一套。

   ★ 必须**探测**而不是「有插件就用」：网页是服务器上的最新版，用户装的 APK 却可能
     是旧的。老插件的 startMp3 不存在，硬调会直接抛错、用户什么都听不到。
     新版 status() 返回 version=4 表示支持 MP3，用 >= 判断，别写 ==。
   ★ 探测失败就老老实实用网页播放（就是现在的行为），不能因为拿不到原生能力就不给听。 */
let AU_NATIVE = null;        // null=还没探测；true/false=结果
let AU_NATIVE_PLAYING = false;

function auNativePlugin() {
  try {
    const C = window.Capacitor;
    return (C && C.Plugins && C.Plugins.ListenService) || null;
  } catch (e) { return null; }
}

async function auDetectNative() {
  // 成功结果永久缓存；失败不缓存，下次播放还会再试一遍（探测本身很便宜）
  if (AU_NATIVE === true) return true;
  const p = auNativePlugin();
  if (!p || typeof p.startMp3 !== 'function') { AU_NATIVE = false; return false; }
  try {
    const st = await p.status();
    // ★ 只看能力号 version>=4，**绝对不要再看 st.mode**。
    //   这是「听有声书没有通知栏横幅」的真凶：原生 status() 里的 mode 来自
    //   PlaybackService 的 lastStateJson，而那个值只有**播放过之后**才会被写上。
    //   刚打开 App、服务还没跑起来时，status() 只返回 {version:4, active:false}，
    //   里面根本没有 mode 键 —— 于是 typeof st.mode === 'string' 为假，
    //   探测判死 → 有声落回网页 <audio> → 没有前台服务 → 通知栏/锁屏什么都不出。
    //   更糟的是结果被缓存，整个会话就一直用网页播。
    //   听书侧（listen.js）一直只判 version，所以听书有横幅、有声没有。
    // ★ 门槛是 5，不是 4：v4（V3.3）的原生 MP3 有两处硬伤 ——
    //   ① 那时网页传的是**相对地址**（/api/...），原生 MediaPlayer.setDataSource()
    //      会把它当成手机本地文件，打不开 → 整本没声音；
    //   ② 那时用 #t=start,end 表达「本章在文件里的区间」，而 Android MediaPlayer
    //      **不支持媒体片段**（片段根本不会发到服务器），会把整个文件从头播，
    //      一个文件装多章的书（如《秋园》3 章/文件）每章都会从头重放。
    //   V3.4（v5）改成「绝对地址 + 单独的起止毫秒数组」，才谈得上正确播放。
    //   v4 及以下一律落回网页播放 —— 那是能正常出声的，比硬走原生强。
    AU_NATIVE = !!(st && Number(st.version) >= 5);
  } catch (e) { AU_NATIVE = false; }
  return AU_NATIVE;
}

// 原生状态回调：只在「原生 MP3 播放」时才处理，别的模式（TTS 听书）完全不碰。
// ★ 用链式挂接而不是直接赋值：listen.js 在听书页也占着这个全局名，谁能加载到谁都在，
//   直接覆盖会把对方那套弄坏。
function auHookNativeState() {
  const prev = window.__laoshuPlayerState;
  window.__laoshuPlayerState = function (st) {
    try {
      if (st && st.mode === 'mp3') auOnNativeState(st);
    } catch (e) {}
    if (typeof prev === 'function') return prev.apply(this, arguments);
  };
}

function auOnNativeState(st) {
  if (!AUP || !AUP.native) return;
  AU_NATIVE_PLAYING = !!st.playing;

  // 原生切章了（播完自动接下一章 / 通知栏按了下一章）：界面跟上
  // ★ 注意 AUP.chap 始终是**章序号（数字）**，不是章对象 —— 这里必须取 .seq。
  if (typeof st.index === 'number') {
    const chs = (AUP.chapters && AUP.chapters.length ? AUP.chapters : (AUP.lib.chapters || []));
    const cur = chs[st.index];
    const seq = cur ? cur.seq : null;
    // ★★ 切章「还没到位」时必须丢弃这一帧：
    //   用户点了第 5 章 → 已经把这本整章清单交给原生 → 但原生**还在放第 2 章**，
    //   于是它照常回报 index=第2章。以前这里会照着回报把 AUP.chap 改回第 2 章，
    //   结果「点第 5 章」变成：音频是第 5 章、界面和文字却是第 2 章
    //   （文字高亮、进度、落库全跟着错位）。实测复现：startMp3.index=4（对）
    //   而 AUP.chap=2（错）。
    //   15 秒兜底：原生要是始终没切过来（票据过期等），不能永远拦着状态。
    if (AUP.switchTo) {
      if (seq === AUP.switchTo) {
        AUP.switchTo = 0;
      } else if (Date.now() - (AUP.switchAt || 0) < 15000) {
        return;
      } else {
        AUP.switchTo = 0;
      }
    }
    if (seq && seq !== AUP.chap) {
      AUP.chap = seq;
      const c = (AUP.lib.chapters || []).find(x => x.seq === seq) || {};
      AUP.chapStart = c.start_sec || 0;
      AUP.chapEnd = (c.start_sec || 0) + (c.dur_sec || 0);
      AUP.nativePos = 0;
      AUP.seekAsk = null;                       // 换章了，上一章挂着的兜底作废
      AUP.nativeDur = 0;                        // ★ 跟着换章，否则进度条沿用上一章的总长
      AUP.idx = 0;
      auLoadSegs(seq);                          // ★ 换文字（renderAUP 用的 AUP.segs 是上一章的）
      AUPSave(true);                            // 上一章记成「已听完」
    }
  }

  // 位置回报 → 进度条 + 文字高亮（原生就是靠这条驱动同步的）
  if (typeof st.positionMs === 'number') {
    // ★★ 兜底：给「点击被原生吃掉」的老 APK 用。
    //   历史原因有两层：V3.5 及更早的原生会在 onPrepared 里**无条件** seekTo(本章起点)，
    //   把用户在 prepareAsync 那几百毫秒里点下的位置覆盖掉；V3.7 及更早还有一个更狠的
    //   —— ListenPlugin 用 call.getLong("ms") 取参数，实测恒为 0，于是每次点击都变成
    //   「seek 到本章第 0 毫秒」，听感就是「点了却从本章开头播」（V3.8 改成 getInt 才修好）。
    //   这里再兜一层：点击后 12 秒内，若原生报回来的位置离目标还很远，隔 1.2 秒补发一次，
    //   最多补 3 次。
    //   ★ 判定必须比「目标附近」，不能只看「大于 1.2 秒」：点的是 55 秒处那句、
    //     原生却报 2 秒 —— 那显然是没到位，早先的写法会把这种情况当成成功。
    if (AUP.seekAsk) {
      const a = AUP.seekAsk;
      const pos = Number(st.positionMs) || 0;
      const near = Math.abs(pos - a.ms) <= 2500;
      if (near || Date.now() - a.at > 12000 || a.tries >= 3 || a.ms <= 1500) {
        AUP.seekAsk = null;
      } else if (Date.now() - (a.last || a.at) < 1200) {
        return;                    // ★ 距上次补发不到 1.2 秒：先等它到位，别一帧一补
      } else {
        a.tries++;
        a.last = Date.now();
        const np = auNativePlugin();
        if (np && np.seek) { try { np.seek({ ms: a.ms }).catch(function () {}); } catch (e) {} }
        AUP.nativePos = a.ms;      // 界面别被那帧错误位置带回去
        return;
      }
    }
    AUP.nativePos = st.positionMs;
    if (typeof st.durationMs === 'number' && st.durationMs > AUP.nativeDur) AUP.nativeDur = st.durationMs;
    apSyncUi();
    AUPOnTime();
  }
  if (AU_NATIVE_PLAYING !== AUP.lastPlaying) {
    AUP.lastPlaying = AU_NATIVE_PLAYING;
    apSyncUi();
    AUPFloatUpdate();
    if (!AU_NATIVE_PLAYING) AUPSave(false);
  }
  // 进度落库：原生不会替网页存，这里按 15 秒节流上报
  if (AU_NATIVE_PLAYING) {
    const now = Date.now();
    if (now - (AUP.nativeSaveT || 0) > 15000) { AUP.nativeSaveT = now; AUPSave(false); }
  }
}

// APP 内：把**整章的直链清单**交给原生服务，由它前后台播放并挂通知栏横幅。
// 一次把所有章的地址都取好（每章一张票据），原生就能自己「播完接下一章」，
// 不用网页跟着（网页会被系统冻结）。
async function auNativePlay(cont) {
  const p = auNativePlugin();
  const d = AUP.lib;
  // ★ 一定要把「用户点的是哪一章」在**取票据之前**钉住。
  //   取完整本票据要好几百毫秒到十几秒（长书上百章），这段时间里原生仍在放旧章
  //   并回报状态，AUP.chap 随时可能被改动 —— 后面再读 AUP.chap 就会拿错章。
  const wantChap = AUP.chap;
  const chs = (d.chapters || []).slice().sort((a, b) => a.seq - b.seq);
  const urls = [], titles = [], starts = [], ends = [];
  // ★ 票据改成**有限并发**取，不再一章一章串行等。
  //   串行取 186 张要十几秒：用户点了章节半天没声音，以为没点上就又点别的，
  //   看起来就是「点这章放那章、功能混乱」。并发 6 路既快又不压垮服务端。
  const one = async (c) => {
    try {
      const t = await api('/api/audiobooks/' + d.id + '/ticket?seq=' + c.file_seq + '&chap=' + c.seq);
      // ★ 必须补成**绝对地址**：票据给的是 "/api/audiobooks/..."，
      //   浏览器里能自动补 origin，原生 MediaPlayer 不能 —— 它会把
      //   "/api/..." 当成手机上的本地文件路径，直接打不开、整本没声音。
      // ★ 本章在**整个文件**里的起止毫秒，单独传给原生。
      //   原来是把 "#t=start,end" 拼在地址后面 —— 那是浏览器 <audio> 的媒体片段约定，
      //   Android MediaPlayer 不认，会从文件 0 秒开始播。一个文件装多章的书
      //   （如《秋园》3 章/文件），每章都会从头重放。
      return {
        url: new URL(t.url, location.origin).href,
        title: c.title || ('第 ' + c.seq + ' 章'),
        start: Math.round((c.start_sec || 0) * 1000),
        end: Math.round(((c.start_sec || 0) + (c.dur_sec || 0)) * 1000)
      };
    } catch (e) {
      return { url: '',                          // 没解锁/取不到：留空，原生会跳过
               title: c.title || ('第 ' + c.seq + ' 章'), start: 0, end: 0 };
    }
  };
  const got = new Array(chs.length);
  let next = 0;
  const worker = async () => {
    while (true) {
      const i = next++;
      if (i >= chs.length) return;
      got[i] = await one(chs[i]);
    }
  };
  await Promise.all(new Array(Math.min(6, chs.length || 1)).fill(0).map(worker));
  for (const g of got) {
    if (!g) { urls.push(''); titles.push(''); starts.push(0); ends.push(0); continue; }
    urls.push(g.url);
    titles.push(g.title);
    starts.push(g.start);
    ends.push(g.end);
  }
  AUP.native = true;
  AUP.nativePos = 0;
  AUP.chapters = chs;                          // 原生清单的顺序，切章要按它换算下标
  AUP.chapIndex = chs.map(c => c.seq);
  const idx = Math.max(0, chs.findIndex(c => c.seq === wantChap));
  await p.startMp3({
    title: d.title || '有声书',
    index: idx,
    total: urls.length,
    urls: urls,
    titles: titles,
    starts: starts,       // 本章起点（毫秒，相对整个文件）
    ends: ends            // 本章终点，原生到点自动接下一章
  });
  AUP.chapter = String(wantChap);
  // ★ 从现在起丢掉「旧章节」的状态回报，直到原生真的切到 wantChap。
  AUP.switchTo = wantChap;
  AUP.switchAt = Date.now();
  // ★ 起播前用户点过的句子：那时原生还没接管，点击被记在 pendingClickAt 上，现在补跳。
  //   不给它补，用户看到的就是「点了没反应，然后从本章开头播」。
  if (typeof AUP.pendingClickAt === 'number') {
    const _s = AUP.pendingClickAt, _i = AUP.pendingClickIdx;
    AUP.pendingClickAt = null;
    AUP.pendingClickIdx = -1;
    auSeekTo(_s, _i);
  }
  // 记一笔「原生正在放哪本」：页面重载后 AUP 会丢，只能靠它认回来
  auRememberNativeLib(d, wantChap);
}

// 原生前台服务此刻是不是**已经在放这本书**了。
// ★ 用途：从悬浮条点回播放页时，声音其实一直没停，界面只是重新挂上来而已。
//   这时如果还发一次 startMp3，原生会走 playIndex(index, true) —— 那是「重放本章」，
//   听感就是「退出播放界面再点浮窗回来，又从头开始」。
async function auNativePlayingThis(d) {
  const p = auNativePlugin();
  if (!p || !p.status) return false;
  try {
    const st = await p.status();
    if (!st || !st.active || st.mode !== 'mp3') return false;
    // 标题对不上说明服务里放的是别的书，那就该老老实实重新起播
    if (st.title && d && d.title && st.title !== d.title) return false;
    return true;
  } catch (e) { return false; }
}

async function AUPAudio(cont) {
  const el = AU_AUDIO;
  if (!el) return;

  // ★ App 里走原生前台服务：切后台/关屏继续放，并挂系统通知栏（锁屏）横幅。
  //   探测失败（老 APK）就落回下面的网页播放，行为与以前完全一致。
  try {
    if (await auDetectNative()) {
      auHookNativeState();
      // ★ 声音已经在前台服务里活着：只把界面挂回去，**绝不能**再发一次 startMp3 ——
      //   那会让原生 playIndex(index, true) 把本章从头重放一遍。
      //   两种情况都算「活着」：
      //     ① AUP.restored —— 页面重载后认领回来的会话；
      //     ② 原生此刻 status() 就说它在放这本书 —— 退出播放页再点悬浮条回来就是这种，
      //        声音一直没停，界面只是重新挂上来。
      //   ★ 原来只挡了 ①，于是每次「退出播放界面 → 点浮窗返回」都会重发 startMp3，
      //     表现就是「又回到从头播」。
      if (cont && AUP.native && (AUP.restored || await auNativePlayingThis(AUP.lib))) {
        AUP.restored = false;
        AUPFloatUpdate();
        apSyncUi();
        return;
      }
      await auNativePlay(cont);
      return;
    }
  } catch (e) {
    console.warn('原生播放不可用，改用网页播放', e);
  }

  const slot = document.getElementById('ap-slot');
  if (slot && el.parentNode !== slot) slot.appendChild(el);
  el.preload = 'metadata';
  const d = AUP.lib;
  if (!cont) {
    // 取一次**绑定到这次播放**的签名地址（防盗链）：换人/换书/换章/过期都不认
    let url = '';
    try {
      const t = await api('/api/audiobooks/' + d.id + '/ticket?seq=' + AUP.fileSeq +
                          '&chap=' + AUP.chap + '&sid=' + encodeURIComponent(AU_SID));
      url = t.url;
    } catch (e) {
      // ★ 409 = 这个账号正在另一台设备上听有声书。这里要弹「在这台设备上继续听」，
      //   不能只 toast —— 用户得有个明确的动作能把锁抢过来。
      if (e && e.status === 409) { auLockConflict(e.message); return; }
      toast(e.message || '取播放凭证失败');
      return;
    }
    if (!AUP || AUP.lib.id !== d.id) return;      // 期间切走了
    const src = url + '#t=' + AUP.chapStart.toFixed(2) + ',' + AUP.chapEnd.toFixed(2);
    if (el.getAttribute('src') !== src) {
      el.setAttribute('src', src);
      el.load();
    }
  }
  AUP.audio = el;
  if (cont) {
    // 就地继续：元数据早就加载过了，直接改时间，不能再等 loadedmetadata（不会再触发）
    try { el.currentTime = AUP.chapStart + AUP.startAt; } catch (e) {}
  } else if (AUP.startAt > 0) {
    // 继续听读：等媒体片段生效后再跳到上次的位置
    const jump = () => {
      try { el.currentTime = AUP.chapStart + AUP.startAt; } catch (e) {}
      el.removeEventListener('loadedmetadata', jump);
    };
    el.addEventListener('loadedmetadata', jump);
  }
  // ★ 文字先出来、播放器还没就绪时点的那一下：auSeekTo 记在 pendingClickAt 上，这里补跳。
  //   必须注册在 startAt 之后 —— 用户刚点的位置要压过「上次听到哪」。
  //   （APP 走原生那条路时函数早就 return 了，那份由 auNativePlay 消费。）
  if (typeof AUP.pendingClickAt === 'number') {
    const _s = AUP.pendingClickAt, _i = AUP.pendingClickIdx;
    AUP.pendingClickAt = null;
    AUP.pendingClickIdx = -1;
    const jump2 = () => {
      try { el.currentTime = AUP.chapStart + _s; } catch (e) {}
      if (typeof _i === 'number' && _i >= 0) aupSetActive(_i); else AUPOnTime();
      apSyncUi();
      el.removeEventListener('loadedmetadata', jump2);
    };
    if (el.readyState >= 1) jump2();
    else el.addEventListener('loadedmetadata', jump2);
  }
  if (!el.__auWired) {
    el.__auWired = true;
    el.addEventListener('timeupdate', AUPOnTime);
    el.addEventListener('timeupdate', AUPSync);
    el.addEventListener('pause', () => { AUPSave(false); AUPFloatUpdate(); apSyncUi(); });
    el.addEventListener('play', () => { AUPSync(); AUPFloatUpdate(); apSyncUi(); });
    el.addEventListener('ended', () => { AUPSave(true); auAutoNext(); });
    el.addEventListener('loadedmetadata', AUPSync);
    el.addEventListener('timeupdate', apSyncUi);
    el.addEventListener('error', function () {
      // 票据过期 / 链接被拒：换一张再试一次，别让用户卡住
      if (!AUP || AUP.retried) return;
      AUP.retried = true;
      const at = el.currentTime || AUP.chapStart;
      AUPAudio(false).then(function () {
        try { el.currentTime = at; } catch (e) {}
        el.play().catch(function () {});
      });
    });
  }
  apSyncUi();
  el.play().catch(() => { toast('点一下播放开始'); });
  // ★ 开播后立刻记一次（等 currentTime 真的动起来）：不然第一次落库要等到
  //   15 秒的定时器或暂停事件，中途退出就完全没记录，「继续听读」也就无从谈起。
  setTimeout(() => { if (AUP && AUP.audio === el) AUPSave(false, true); }, 2500);
  AUPSetMediaSession();
  if (AUP_TICK) clearInterval(AUP_TICK);
  AUP_TICK = setInterval(AUPSave, 15000);      // 每 15 秒记一次进度，掉线也不丢
}

// 文字同步：按分句时间轴高亮当前句并滚动到中间（歌词效果）
function AUPOnTime() {
  if (!AUP || !AUP.audio || !AUP.segs.length) return;
  // t 与 AUP.segs[].start_sec 都是**章内相对时间**（载入时已减去 chapStart）
  const t = AUP.native ? (AUP.nativePos || 0) / 1000
                       : (AUP.audio.currentTime - AUP.chapStart);
  let i = AUP.idx;
  if (i >= AUP.segs.length) i = AUP.segs.length - 1;
  if (t < AUP.segs[i].start_sec - 0.3 || t > AUP.segs[i].start_sec + AUP.segs[i].dur_sec + 0.3) {
    // 直接二分找到所在句（seek 之后也能立刻跟上）
    let lo = 0, hi = AUP.segs.length - 1;
    while (lo < hi) {
      const mid = (lo + hi + 1) >> 1;
      if (AUP.segs[mid].start_sec <= t) lo = mid; else hi = mid - 1;
    }
    i = lo;
  }
  if (i !== AUP.idx) {
    const old = document.getElementById('aup-l' + AUP.idx);
    if (old) { old.classList.remove('on'); old.classList.add('done'); }
    const cur = document.getElementById('aup-l' + i);
    if (cur) {
      cur.classList.add('on'); cur.classList.remove('done');
      aupScrollTo(cur);
    }
    AUP.idx = i;
  } else {
    // 同一句：确保它还是高亮的（重绘/换章后可能丢了）
    const cur = document.getElementById('aup-l' + i);
    if (cur && !cur.classList.contains('on')) { cur.classList.add('on'); aupScrollTo(cur); }
  }
}

// 把当前句滚到文字区中间。用户手动滚动后 6 秒内不抢滚动条（否则看书时很烦）。
function aupScrollTo(cur) {
  const wrap = document.getElementById('aup-texts');
  if (!wrap) return;
  if (AUP.scrollLockUntil && Date.now() < AUP.scrollLockUntil) return;
  const top = cur.offsetTop - wrap.clientHeight / 2 + cur.clientHeight / 2;
  if (Math.abs(wrap.scrollTop - top) < 4) return;
  // ★ 这是我们自己滚的，别让 aupTextScroll 当成「用户手动滚动」把锁又种回去。
  //   ★ 为什么用时间窗而不是一次性标志：.ap-textwrap 上有 scroll-behavior:smooth，
  //   一次 scrollTop 赋值会**连续触发好几个** scroll 事件，一次性标志被第一个吃掉，
  //   后面的事件又会把锁种回 6 秒 —— 结果「点一句滚过去了，但之后不再自动跟随」。
  AUP.selfScrollAt = Date.now();
  wrap.scrollTop = top;
}

// 用户滚动了文字区 → 暂停自动滚动，让他们自己看
function aupTextScroll() {
  const wrap = document.getElementById('aup-texts');
  if (!wrap || !AUP) return;
  if (AUP.ignoreScroll) { AUP.ignoreScroll = false; return; }
  // 刚发生过程序化滚动（含 smooth 动画的一串 scroll 事件）→ 不算用户手动滚动
  if (AUP.selfScrollAt && Date.now() - AUP.selfScrollAt < 1500) return;
  AUP.scrollLockUntil = Date.now() + 6000;
  const btn = document.getElementById('aup-follow');
  if (btn) { btn.classList.remove('hidden'); }
}
function aupFollowNow() {
  if (!AUP) return;
  AUP.scrollLockUntil = 0;
  const btn = document.getElementById('aup-follow');
  if (btn) btn.classList.add('hidden');
  const cur = document.getElementById('aup-l' + AUP.idx);
  if (cur) aupScrollTo(cur);
}

// 进度条与时间：全部按**本章**范围算（一个文件可能装了 2 章，
// 直接拿整文件时长当进度条会显示成「听到一半」其实已经在下一章了）。
function apDur() {
  return Math.max(0.1, (AUP.chapEnd || 0) - (AUP.chapStart || 0));
}
function apSyncUi() {
  if (!AUP || !AUP.audio) return;
  const el = AUP.audio, dur = apDur();
  // 原生播放时位置由原生回报（AUP.nativePos），网页的 el.currentTime 是停着的旧值
  const pos = AUP.native
    ? Math.min(dur, Math.max(0, (AUP.nativePos || 0) / 1000))
    : Math.min(dur, Math.max(0, (el.currentTime || 0) - (AUP.chapStart || 0)));
  const bar = document.getElementById('ap-seek');
  if (bar && !AUP.dragging) bar.value = String(Math.round(pos / dur * 1000));
  const cur = document.getElementById('ap-cur');
  if (cur && !AUP.dragging) cur.textContent = auFmtHMS(pos);
  const tot = document.getElementById('ap-total');
  if (tot) tot.textContent = auFmtHMS(dur);
  const btn = document.getElementById('ap-play');
  if (btn) btn.textContent = (AUP.native ? !AU_NATIVE_PLAYING : el.paused) ? '▶' : '⏸';
  // 播放中**且人就在这个播放页**看着文字时，别让手机熄屏（keepawake.js）。
  // 离开播放页由 showView() 松开 —— 后台放着音、手机装口袋里时屏幕还亮着最费电。
  // apSyncUi 在 timeupdate 上也会被调用，靠 keepAwake 内部的状态去重，不会反复下发。
  const onPlay = AUP.native ? AU_NATIVE_PLAYING : !el.paused;
  const viewEl = document.getElementById('view-audioplay');
  if (typeof keepAwake === 'function')
    keepAwake(onPlay && !!viewEl && !viewEl.classList.contains('hidden'));
}
function apToggle() {
  if (!AUP || !AUP.audio) return;
  if (AUP.native) {
    const p = auNativePlugin();
    if (p) { try { (AU_NATIVE_PLAYING ? p.pause() : p.play()).catch(function () {}); } catch (e) {} }
    AU_NATIVE_PLAYING = !AU_NATIVE_PLAYING;
    apSyncUi(); AUPFloatUpdate();
    return;
  }
  if (AUP.audio.paused) AUP.audio.play().catch(function () { toast('点一下播放开始'); });
  else AUP.audio.pause();
  apSyncUi();
}
// 拖动中只更新时间显示、不 seek（否则一边拖一边被回弹，手感很差）
function apSeekInput(v) {
  if (!AUP || !AUP.audio) return;
  AUP.dragging = true;
  const el = document.getElementById('ap-cur');
  if (el) el.textContent = auFmtHMS(apDur() * (Number(v) / 1000));
}
function apSeekCommit(v) {
  if (!AUP || !AUP.audio) return;
  const ms = Math.round(apDur() * (Number(v) / 1000) * 1000);
  if (AUP.native) {
    const p = auNativePlugin();
    if (p && p.seek) { try { p.seek({ ms: ms }).catch(function () {}); } catch (e) {} }
    AUP.nativePos = ms;
    AUPOnTime();                 // 拖完进度条文字也要立刻跟上
  } else {
    try { AUP.audio.currentTime = AUP.chapStart + apDur() * (Number(v) / 1000); } catch (e) {}
  }
  AUP.dragging = false;
  apSyncUi();
}

// 直接把某一句点亮（点击跳转专用）。
// ★ 为什么不交给 AUPOnTime 按时间反查：点击传下去的是**句子起点的秒**，
//   而 seek 必须取整到毫秒 —— Math.round(23.1234 * 1000) / 1000 = 23.123，
//   **略小于**该句起点 23.1234，二分就落到上一句去了。
//   实测症状：「点第 6 句，高亮停在第 5 句」。
function aupSetActive(i) {
  if (!AUP || !AUP.segs.length) return;
  i = Math.max(0, Math.min(AUP.segs.length - 1, i | 0));
  if (i !== AUP.idx) {
    const old = document.getElementById('aup-l' + AUP.idx);
    if (old) { old.classList.remove('on'); old.classList.add('done'); }
  }
  const cur = document.getElementById('aup-l' + i);
  if (cur) { cur.classList.add('on'); cur.classList.remove('done'); }
  AUP.idx = i;
  aupScrollTo(cur);
}

// 点击某一句 → 声音跳到该句（sec 是**章内相对**秒，原生/网页两条路都加回 chapStart）。
// ★ 为什么两条路都要主动调 AUPOnTime()：
//   网页那条路赋 currentTime 会异步触发 timeupdate，高亮稍后自己就跟上了；
//   但**原生那条路的逐句高亮完全靠位置回报驱动**（约 500ms 一次，
//   暂停时压根不来）。不主动重画就会出现「点了以后进度条动了、高亮却不动」，
//   看着像没点上。实测复现：点第 5 句，原生 seek 收到 21911ms（对），高亮仍停在第 0 句。
function auSeekTo(sec, idx) {
  if (!AUP || !AUP.audio) return;
  sec = Math.max(0, Number(sec) || 0);
  // ★ 用户明确点了某一句，就是要过去：解除「手动滚动后 6 秒不抢滚动条」。
  //   否则他滚下去点一句，画面一动不动，同样像没点上。
  AUP.scrollLockUntil = 0;
  // ★★ 原生会话**还在建立**：auNativePlay() 要把整本的取票跑完才会把 AUP.native 置真
  //   （三体 186 章，并发 6，要好几秒）。这段窗口里 AUP.native 还是 false，
  //   照下面的网页分支去改 AU_AUDIO.currentTime —— APP 里的声音根本在原生那边，
  //   改了完全没声音，**这一下点击等于白点**；紧接着原生起播，就是本章开头。
  //   站长说的「点击后会从本章节开始播放」正是这个。所以先记下来，起播后补跳。
  //   ★ 还多一种：文字已经画出来了、但「原生探测」或「网页播放器拿地址」都还没走完
  //     （AU_NATIVE 还没置真、AU_AUDIO 也还没有 src）。这时点一下同样落不到声音上，
  //     所以判定改成「原生还没接管 **且** 网页播放器也没有源」，一律先记下来。
  const webReady = !!(AUP.audio && AUP.audio.src);
  if (!AUP.native && (AU_NATIVE === true || !webReady)) {
    AUP.pendingClickAt = sec;
    AUP.pendingClickIdx = (typeof idx === 'number' && idx >= 0) ? idx : -1;
    if (typeof idx === 'number' && idx >= 0) aupSetActive(idx);
    apSyncUi();
    return;
  }
  if (AUP.native) {
    const p = auNativePlugin();
    const ms = Math.round(sec * 1000);
    if (p && p.seek) { try { p.seek({ ms: ms }).catch(function () {}); } catch (e) {} }
    AUP.nativePos = ms;
    // 记下这次点击的目标：等原生的位置回报回来核对一次（见 auOnNativeState 里的兜底）
    AUP.seekAsk = { ms: ms, at: Date.now(), tries: 0 };
    // ★ 原生这条路的逐句高亮本来靠位置回报驱动（约 500ms 一次，暂停时压根不来），
    //   所以必须自己立刻点亮，否则「进度条动了、高亮不动」，像没点上。
    if (typeof idx === 'number' && idx >= 0) aupSetActive(idx); else AUPOnTime();
    apSyncUi();
    AUPSave(false);              // 新位置直接落库，不等下一次位置回报
    return;
  }
  try { AUP.audio.currentTime = AUP.chapStart + sec; } catch (e) {}
  if (typeof idx === 'number' && idx >= 0) aupSetActive(idx); else AUPOnTime();
  apSyncUi();
}
function auSeekBy(d) {
  if (!AUP || !AUP.audio) return;
  if (AUP.native) {
    const ms = Math.max(0, Math.min(apDur() * 1000, (AUP.nativePos || 0) + d * 1000));
    const p = auNativePlugin();
    if (p && p.seek) { try { p.seek({ ms: Math.round(ms) }).catch(function () {}); } catch (e) {} }
    AUP.nativePos = ms;
    AUPOnTime();                 // 同 auSeekTo：原生高亮不会自己跟上来
    apSyncUi();
    return;
  }
  try {
    AUP.audio.currentTime = Math.min(AUP.chapEnd, Math.max(AUP.chapStart, AUP.audio.currentTime + d));
  } catch (e) {}
  apSyncUi();
}
function auStep(d) {
  const n = AUP && AUP.nChap ? AUP.nChap : 0;
  const nx = (AUP.chap || 1) + d;
  if (nx < 1 || (n && nx > n)) { toast(d > 0 ? '已经是最后一章' : '已经是第一章'); return; }
  AUPSave(true);
  if (AUP.native) {
    // 整本清单已经交给原生，切章只是换个下标，不要重建播放会话。
    // ★ 先算下标再动 AUP.chap：算下标用的是章清单（对象数组），AUP.chap 是序号。
    const p = auNativePlugin();
    const chs = AUP.chapters || [];
    const idx = chs.map(function (x) { return x.seq; }).indexOf(nx);
    AUP.chap = nx;
    AUP.nativePos = 0;
    const c = chs[idx] || {};
    if (c.seq === nx) {
      AUP.chapStart = c.start_sec || 0;
      AUP.chapEnd = (c.start_sec || 0) + (c.dur_sec || 0);
    }
    AUP.idx = 0;
    // 同上：原生切过来之前会继续回报旧章的 index，丢了它
    AUP.switchTo = nx;
    AUP.switchAt = Date.now();
    if (p && p.gotoIndex && idx >= 0) {
      try { p.gotoIndex({ index: idx }).catch(function () {}); } catch (e) {}
    }
    // ★ 必须换本章文字，不能只 renderAUP()（那还是上一章的句子）。
    //   用户点了下一章，文字就该立刻跟着新章走 —— 这里不等原生确认，
    //   因为「点下一章」是用户的明确意图；万一原生没切过去，
    //   auOnNativeState 的 15 秒兜底会把章号和文字一起改回来。
    auLoadSegs(nx);
    apSyncUi();
    return;
  }
  audioPlay(AUP.lib.id, nx, false);
}
// ★ 返回详情页 = 进入「后台播放」：音频继续播、进度照记，页面上留一个悬浮条。
//   真正停下来只发生在悬浮条的 ✕ 或播完最后一章。
function closeAudioPlay() {
  AUPSave(false);
  const id = AUP && AUP.lib ? AUP.lib.id : 0;
  if (id) openAudioView(id);
  else { location.hash = '#/audio'; switchPageView('audio'); }
  AUPFloatUpdate();
}
// 播完自动接下一章（最后一章则停在末尾）
function auAutoNext() {
  if (!AUP || !AUP.audio) return;
  const n = AUP.nChap || 0;
  if (n && AUP.chap >= n) { toast('已是最后一章'); AUPSave(false, true); AUPFloatUpdate(); return; }
  AUPSave(true);
  audioPlay(AUP.lib.id, AUP.chap + 1, false);
}

// 进度上报（节流：至少间隔 8 秒，切章/暂停/播完/开播首次时强制上报）
async function AUPSave(done, force) {
  if (!AUP || !AUP.lib) return;
  if (GUEST || !USER) return;                  // 游客没有进度可存
  const el = AUP.audio;
  const now = Date.now();
  if (!done && !force && now - (AUP.saveT || 0) < 8000) return;
  AUP.saveT = now;
  const off = AUP.native ? Math.max(0, (AUP.nativePos || 0) / 1000)
                         : (el ? Math.max(0, (el.currentTime || 0) - AUP.chapStart) : 0);
  try {
    const r = await auPost('/api/audiobooks/' + AUP.lib.id + '/progress',
                           { chap: AUP.chap, offset: done ? 0 : off, done: !!done, sid: AU_SID });
    // ★ 服务端会说「这台终端已经不再持有锁」——被别的设备抢了。
    //   这时**立刻停**：既不能再覆盖对方进度，也不该继续响。
    if (r && r.owned === false) auLockLost(r.reason || '该账号已在另一台设备上继续收听。');
  } catch (e) { /* 进度存不上不影响听 */ }
}

// 蓝牙 / 锁屏：交给系统媒体会话（车机、蓝牙耳机的播放暂停切章都靠它）
function AUPSetMediaSession() {
  if (!navigator.mediaSession || !AUP || !AUP.lib) return;
  const d = AUP.lib;
  const c = (d.chapters || []).find(x => x.seq === AUP.chap) || {};
  try {
    navigator.mediaSession.metadata = new MediaMetadata({
      title: c.title || d.title,
      artist: d.author || '云阅读',
      album: d.title,
      artwork: d.cover_url ? [{ src: coverUrl(d.cover_url), sizes: '512x512', type: 'image/jpeg' }] : []
    });
  } catch (e) {}
  const set = (act, fn) => { try { navigator.mediaSession.setActionHandler(act, fn); } catch (e) {} };
  set('play', () => { if (AUP && AUP.audio) AUP.audio.play(); });
  set('pause', () => { if (AUP && AUP.audio) AUP.audio.pause(); });
  set('previoustrack', () => auStep(-1));
  set('nexttrack', () => auStep(1));
  set('seekbackward', () => auSeekBy(-15));
  set('seekforward', () => auSeekBy(15));
  set('seekto', (e) => { if (AUP && AUP.audio && e.seekTime != null) auSeekTo(e.seekTime); });
}
function AUPSync() {
  if (!navigator.mediaSession || !AUP || !AUP.audio) return;
  try {
    navigator.mediaSession.playbackState = AUP.audio.paused ? 'paused' : 'playing';
  } catch (e) {}
}

// 离开页面/切后台时兜底存一次
window.addEventListener('pagehide', () => { if (AUP) AUPSave(false); });
document.addEventListener('visibilitychange', () => { if (document.hidden && AUP) AUPSave(false); });

// ---------------------------------------------------------------- 悬浮播放条
/* 离开播放页后音频继续放（后台播放），页面上留一条悬浮条：
   点它回到播放页继续听、右侧按钮暂停/继续、✕ 结束这次收听。

   ★ 视图切换的钩子：showView() 是 app.js 的全局函数，audio.js 在它之后加载，
     这里包一层，保证「任何视图变化」都会同步悬浮条的显隐（播放页里不显示）。
     比在十几个点击入口上各加一次调用可靠得多。 */
(function () {
  if (typeof window.showView !== 'function' || window.showView.__auWrapped) return;
  const orig = window.showView;
  const wrapped = function () {
    const r = orig.apply(this, arguments);
    try { AUPFloatUpdate(); } catch (e) {}
    return r;
  };
  wrapped.__auWrapped = true;
  window.showView = wrapped;
})();

function AUPFloatUpdate() {
  const el = document.getElementById('au-float');
  if (!el) return;
  const view = document.getElementById('view-audioplay');
  const inPlayer = view && !view.classList.contains('hidden');
  if (!AUP || !AUP.lib || (!AU_AUDIO && !AUP.native) || inPlayer) { el.classList.add('hidden'); return; }
  el.classList.remove('hidden');
  const d = AUP.lib;
  const c = (d.chapters || []).find(x => x.seq === AUP.chap) || {};
  const cov = document.getElementById('au-float-cover');
  if (cov) {
    if (d.cover_url && !cov.querySelector('img')) {
      cov.innerHTML = '<img src="' + esc(coverUrl(d.cover_url)) + '" onerror="this.remove()">';
    } else if (!d.cover_url) {
      cov.textContent = '有声';
    }
  }
  const t = document.getElementById('au-float-title');
  if (t) t.textContent = c.title || d.title;
  const paused = AUP.native ? !AU_NATIVE_PLAYING : (AUP.audio && AUP.audio.paused);
  const sub = document.getElementById('au-float-sub');
  if (sub) {
    const cur = AUP.native ? (AUP.nativePos || 0) / 1000
                           : (AUP.audio ? (AUP.audio.currentTime || 0) : 0);
    sub.textContent = '第 ' + AUP.chap + '/' + (AUP.nChap || d.total_chapters) + ' 章 · ' +
      auFmtHMS(AUP.native ? cur : Math.max(0, cur - (AUP.chapStart || 0))) + ' / ' +
      auFmtHMS(c.dur_sec || 0) + (paused ? ' · 已暂停' : '');
  }
  const btn = document.getElementById('au-float-play');
  if (btn) btn.textContent = paused ? '▶' : '⏸';
}

function auFloatOpen() {
  if (!AUP || !AUP.lib) return;
  const lib = AUP.lib.id, chap = AUP.chap;
  audioPlay(lib, chap, true);      // 同一章 → 就地继续，不打断播放
}
function auFloatToggle() {
  if (!AUP) return;
  if (AUP.native) { apToggle(); AUPFloatUpdate(); return; }
  if (!AU_AUDIO) return;
  if (AU_AUDIO.paused) AU_AUDIO.play().catch(function () { toast('点一下播放开始'); });
  else AU_AUDIO.pause();
  AUPFloatUpdate();
}
function auFloatClose() {
  // ★ 只有这里（和播完最后一章）才真正停下来：返回详情页只是「后台播放」
  auLockRelease();        // 主动放手，别人不必等 40 秒租约到期
  if (AUP && AUP.native) {
    const p = auNativePlugin();
    if (p && p.stop) { try { p.stop().catch(function () {}); } catch (e) {} }
    AU_NATIVE_PLAYING = false;
    AUPSave(false);
  }
  if (AU_AUDIO) { try { AU_AUDIO.pause(); } catch (e) {} }
  if (AUP_TICK) { clearInterval(AUP_TICK); AUP_TICK = null; }
  AUP = null;
  try { localStorage.removeItem(AU_NATIVE_LIB_KEY); } catch (e) {}
  const el = document.getElementById('au-float');
  if (el) el.classList.add('hidden');
}

// ------------------------------------------- 页面重载后从原生状态认领播放会话
/* ★ 为什么必须有这一段（V3.4 起暴露的真问题）：
   原生播放把声音放在**前台服务**里，网页重载 / 被系统回收后**声音还在放**。
   但 AUP 只是网页内存里的一个对象，重载就没了 —— 表现就是用户看到的现象：
   「后台明明还在放有声书，页面上却完全没有回到有声播放的悬浮条」，
   而且再也找不到回播放页的入口。悬浮条的显示条件里就有 !AUP 这一条，
   所以 AUP 一丢，悬浮条必然消失。

   听书那边不受影响，是因为「回到听书」圆形按钮每 3 秒从原生 status() 重组自己
   （backtolisten.js），从不依赖内存状态。这里给有声补上同样的能力。

   ★ 为什么不能只靠内存里的 AUP：WebView 在后台被系统回收是常态，
     用户从最近任务回来时就是一个全新页面。 */
const AU_NATIVE_LIB_KEY = 'au_native_lib';

function auRememberNativeLib(d, chap) {
  try {
    localStorage.setItem(AU_NATIVE_LIB_KEY, JSON.stringify({ id: d.id, title: d.title, chap: chap }));
  } catch (e) {}
}

async function auSyncFloatFromNative() {
  const p = auNativePlugin();
  if (!p || !p.status) return;
  let st;
  try { st = await p.status(); } catch (e) { return; }
  // 只有「有声(MP3) 且确实在服务里活着」才归我们管；
  // 听书(tts) 由 backtolisten.js 的圆形按钮负责，这里绝不插手，否则两个悬浮物一起冒出来。
  const mp3On = !!(st && st.active && st.mode === 'mp3');

  if (AUP) {
    // 认领回来的会话已经被系统结束了（通知栏划掉 / 播完）：把悬浮条收掉
    if (AUP.restored && !mp3On) { AUP = null; AUPFloatUpdate(); }
    return;
  }
  if (!mp3On) return;

  let saved = null;
  try { saved = JSON.parse(localStorage.getItem(AU_NATIVE_LIB_KEY) || 'null'); } catch (e) {}
  if (!saved || !saved.id) return;                       // 没有凭据就别猜
  // 标题对不上说明服务里放的已经不是这本书了，宁可不显示也别把用户指向错的书
  if (st.title && saved.title && st.title !== saved.title) return;

  let d;
  try { d = await api('/api/audiobooks/' + saved.id); } catch (e) { return; }
  if (AUP) return;                                       // 等接口的期间用户自己点开了播放

  const chs = (d.chapters || []).slice().sort((a, b) => a.seq - b.seq);
  const cur = chs[Math.max(0, Number(st.index) || 0)] || chs[0] || {};
  AUP = {
    lib: d, chap: cur.seq || saved.chap || 1, segs: [], idx: 0, audio: AU_AUDIO,
    saveT: 0, ended: false, startAt: 0, fromProgress: false,
    native: true, nativePos: Number(st.positionMs) || 0,
    nativeDur: Number(st.durationMs) || 0, nativeSaveT: 0,
    chapters: chs, chapIndex: chs.map(c => c.seq), chapter: String(cur.seq || 1),
    nChap: chs.length,
    restored: true          // 标记：这是认领回来的，别让 AUPAudio() 重启播放
  };
  AU_NATIVE_PLAYING = !!st.playing;
  auHookNativeState();
  AUPFloatUpdate();
}

// ------------------------------------------------ 有声阅读单端锁（一个账号一台设备）
// 与听书是**两把独立的锁**（服务端见 ablock.py / ablib_api.py）：
// 听书贵在逐句现场合成，有声书只是取现成文件，硬并成一把会把
// 「手机听书 + 平板听有声书」这种互不干扰的用法也拦掉。
//
// 三件事缺一不可：
//   1) 取票带 sid —— 开始/继续播放时就把锁拿到手（被占则 409，弹「在这台设备上继续听」）；
//   2) 心跳每 5 秒续租 —— 租约 40 秒，关页面/断网会自动释放，不会把账号永久锁死；
//   3) 长连接 —— 被抢的那一端要**立刻**停。靠心跳不够：网页切到后台时
//      setInterval 会被浏览器限流到一分钟一次，而手上还缓冲着音频，
//      等它自己发现就已经重叠好几秒了。
//
// ★ 用 sessionStorage：每个标签页各自算一个终端（APP 里就是这一个 WebView）。
//   APP 的 WebView 进程被杀后重开，sid 会变，旧锁还热着 40 秒 ——
//   这时会提示「正在另一台设备上收听」，点一下「在这台设备上继续听」即可，
//   这正是这套交互存在的意义。
const AU_SID = (function () {
  try {
    let x = sessionStorage.getItem('bm_audio_sid');
    if (!x) {
      x = 'as' + Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
      sessionStorage.setItem('bm_audio_sid', x);
    }
    return x;
  } catch (e) {
    return 'as' + Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
  }
})();
let AU_HB = null;            // 心跳定时器
let AU_WATCH_CTL = null;     // 长连接的 AbortController
let AU_WATCH_GEN = 0;        // 每次重连 +1，用来作废在途的旧连接
let AU_LOCKED = false;       // 已经因为被抢而停下，别再跟服务端抢

function auLockStart() {
  auLockStop();
  if (GUEST || !USER || !USER.id) return;      // 游客没有账号，谈不上互斥
  // ★ 本机眼下并不持有锁（取票被 409 挡住、或刚被别处抢走）→ 不要开始续租。
  //   否则心跳会一直报 owned=false，把已经弹出来的冲突框又刷成「已被抢」的版本。
  //   用户点「在这台设备上继续听」后 AU_LOCKED 会清掉，那时才真正开始。
  if (AU_LOCKED) return;
  AU_HB = setInterval(auLockBeat, 5000);
  auLockWatch();
}
function auLockStop() {
  if (AU_HB) { clearInterval(AU_HB); AU_HB = null; }
  AU_WATCH_GEN++;
  if (AU_WATCH_CTL) { try { AU_WATCH_CTL.abort(); } catch (e) {} AU_WATCH_CTL = null; }
}
function auLockRelease() {
  auLockStop();
  if (AU_LOCKED || GUEST || !USER || !USER.id) return;
  // 用 keepalive：这是「离开」时发的，页面可能正在卸载
  try { auPost('/api/audiobooks/session/release', { sid: AU_SID }); } catch (e) {}
}

async function auLockBeat() {
  if (!AUP || !AUP.lib || AU_LOCKED) return;
  try {
    const r = await auPost('/api/audiobooks/session/hb', { sid: AU_SID, lib_id: AUP.lib.id });
    if (r && r.owned === false) auLockLost(r.reason || '该账号已在另一台设备上继续收听。');
  } catch (e) { /* 网络抖动不算掉锁，等下一拍 */ }
}

// 长连接：读 /api/audiobooks/watch，收到 kick 就说明锁被别处抢走了。
// 用 fetch 而不是 EventSource —— 这样才能带上 Authorization 头。
async function auLockWatch() {
  const gen = ++AU_WATCH_GEN;
  const ctl = new AbortController();
  AU_WATCH_CTL = ctl;
  try {
    const r = await fetch('/api/audiobooks/watch?sid=' + encodeURIComponent(AU_SID),
                          { headers: TOKEN ? { Authorization: 'Bearer ' + TOKEN } : {},
                            signal: ctl.signal, cache: 'no-store' });
    if (!r.ok || !r.body) return;
    const rd = r.body.getReader();
    const dec = new TextDecoder();
    let buf = '';
    while (true) {
      const { value, done } = await rd.read();
      if (done || gen !== AU_WATCH_GEN) break;
      buf += dec.decode(value, { stream: true });
      let i;
      while ((i = buf.indexOf('\n\n')) >= 0) {
        const chunk = buf.slice(0, i);
        buf = buf.slice(i + 2);
        for (const line of chunk.split('\n')) {
          if (line.slice(0, 5) !== 'data:') continue;
          let d = null;
          try { d = JSON.parse(line.slice(5).trim()); } catch (e) {}
          // 服务端把「抢锁的那个 sid」放在 sid 上：等于自己的话就是自己抢的，忽略
          if (d && d.sid && d.sid !== AU_SID) {
            auLockLost(d.reason || '该账号已在另一台设备上继续收听。');
          }
        }
      }
    }
  } catch (e) { /* abort / 断网 */ }
  // 断了就重连 —— 只要还在放、还没被抢
  if (gen === AU_WATCH_GEN && AUP && AUP.lib && !AU_LOCKED) {
    setTimeout(function () { if (gen === AU_WATCH_GEN && AUP && AUP.lib && !AU_LOCKED) auLockWatch(); }, 3000);
  }
}

// 被别的设备抢走了 → 立刻停下来并给出「抢回来」的入口
function auLockLost(msg) {
  if (AU_LOCKED) return;
  AU_LOCKED = true;
  auLockStop();
  if (AUP && AUP.native) {
    const p = auNativePlugin();
    if (p && p.pause) { try { p.pause().catch(function () {}); } catch (e) {} }
    AU_NATIVE_PLAYING = false;
  }
  if (AU_AUDIO) { try { AU_AUDIO.pause(); } catch (e) {} }
  if (AUP_TICK) { clearInterval(AUP_TICK); AUP_TICK = null; }
  AUPFloatUpdate();
  try { apSyncUi(); } catch (e) {}
  auLockConflict(String(msg || '该账号已在另一台设备上继续收听。') + '\n本机已停止播放。');
}

// 冲突/被抢的统一弹层（和听书同一个交互：要么抢过来，要么退出去）
function auLockConflict(msg) {
  // 我们没拿到锁，所以没有续租、也没有可盯的东西；等用户点「继续听」再重来
  AU_LOCKED = true;
  auLockStop();
  openModal(
    '<h3>有声阅读同时只能一台设备听</h3>' +
    '<p class="muted" style="white-space:pre-wrap;line-height:1.7">' + esc(msg) + '</p>' +
    '<div style="display:flex;gap:8px;margin-top:14px">' +
      '<button class="btn" onclick="auLockTake()">在这台设备上继续听</button>' +
      '<button class="btn ghost" onclick="closeModal();auLockBack()">返回</button>' +
    '</div>');
}
function auLockBack() {
  closeModal();
  auLockRelease();
  AU_LOCKED = false;
  if (AUP && AUP.lib) audioPlay(AUP.lib.id, AUP.chap, true);
}
async function auLockTake() {
  closeModal();
  if (!AUP || !AUP.lib) return;
  const id = AUP.lib.id, chap = AUP.chap;
  try { await auPost('/api/audiobooks/session/take', { sid: AU_SID, lib_id: id }); } catch (e) {}
  AU_LOCKED = false;
  auLockStart();
  // ★ 必须把会话置空再进：同书同章会走「回到播放页、接着放」那条路（不发 startMp3），
  //   而这里要的是**重新取票**（刚才那张就是被 409 挡下的）。
  AUP = null;
  audioPlay(id, chap, true);      // true = 按服务端进度续上
}

// 时间推进时同步悬浮条的进度与按钮状态（播放页里它自己会隐藏，开销可忽略）
(function () {
  if (!AU_AUDIO || AU_AUDIO.__auFloatWired) return;
  AU_AUDIO.__auFloatWired = true;
  let n = 0;
  AU_AUDIO.addEventListener('timeupdate', function () {
    if ((n++ % 4) !== 0) return;      // 约每 1 秒刷一次就够了
    AUPFloatUpdate();
  });
})();

// 冷启动（含 WebView 被回收后重载）与从后台切回前台时，各对一次原生状态：
// 这两处网页都可能是「全新」的，而声音还在服务里放着。
(function () {
  function boot() {
    auSyncFloatFromNative();
    document.addEventListener('visibilitychange', function () {
      if (!document.hidden) auSyncFloatFromNative();
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
