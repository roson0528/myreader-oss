// 文章内嵌图片/视频的**显示效果**回归（居中和尺寸只能靠浏览器实测）。
//
// 前置：服务在 https://127.0.0.1:9000 运行。
// 本脚本自己造一篇「已发布」文章（含一张小图、一张大图、一段真视频），
// 结束时按精确 id / 精确文件名清理。
// 运行：NODE_PATH=/tmp/pwtest/node_modules node tests/test_article_media_ui.js
const { chromium } = require('playwright-core');
const { execSync } = require('child_process');
const CHROME = '/srv/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome';
const ROOT = '/srv/myreader/book_manager';
const BASE = 'https://localhost:9000';

let pass = 0, fail = 0;
const ck = (n, ok, extra) => { if (ok) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (extra ? '  → ' + extra : '')); } };
// Python 片段从 stdin 喂进去，不走 shell 引号
const py = (code) => execSync('venv/bin/python -', { cwd: ROOT, encoding: 'utf8', input: code }).trim();

// 造数据：小图(200x100) / 大图(2400x1200) / 真视频(640x360 H.264)，并写一篇已发布文章
const FIXTURE = `
import sys, os, json, uuid, struct, zlib, shutil
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
import config, db

tag = uuid.uuid4().hex[:6]

def png(w, h, rgb):
    def chunk(t, d):
        c = t + d
        return struct.pack('>I', len(d)) + c + struct.pack('>I', zlib.crc32(c) & 0xffffffff)
    raw = b''.join(b'\\x00' + bytes(rgb) * w for _ in range(h))
    return (b'\\x89PNG\\r\\n\\x1a\\n'
            + chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 2, 0, 0, 0))
            + chunk(b'IDAT', zlib.compress(raw, 6))
            + chunk(b'IEND', b''))

files = {}
small = 'zzam_small_%s.png' % tag
big = 'zzam_big_%s.png' % tag
tall = 'zzam_tall_%s.png' % tag
vid = 'zzam_clip_%s.mp4' % tag
open(os.path.join(config.IMAGE_DIR, small), 'wb').write(png(200, 100, (60, 130, 220)))
open(os.path.join(config.IMAGE_DIR, big), 'wb').write(png(2400, 1200, (230, 120, 60)))
open(os.path.join(config.IMAGE_DIR, tall), 'wb').write(png(900, 2400, (90, 180, 120)))
shutil.copyfile('/tmp/test_clip.mp4', os.path.join(config.IMAGE_DIR, vid))
files = {'small': small, 'big': big, 'tall': tall, 'video': vid}

body = ('# 媒体显示测试\\n\\n'
        '下面是一张小图（200x100），应当按原始大小居中显示，不能被拉大铺满：\\n\\n'
        '![小图](/uploads/%s)\\n\\n'
        '下面是一张大图（2400x1200），应当等比缩到容器宽度以内并居中：\\n\\n'
        '![大图](/uploads/%s)\\n\\n'
        '下面是一张竖图（900x2400，手机截图那种），不能按宽度铺满把整屏占掉：\\n\\n'
        '![竖图](/uploads/%s)\\n\\n'
        '下面是一段视频，应当居中、带播放控件、能读出时长：\\n\\n'
        '![视频](/uploads/%s)\\n') % (small, big, tall, vid)

author = db.q("SELECT id FROM users WHERE role='admin' ORDER BY id LIMIT 1", one=True)['id']
aid = db.ex("INSERT INTO booklists (title,content,author_id,status,view_count,created_at,updated_at,tag,pinned) "
            "VALUES (?,?,?,?,?,?,?,?,?)",
            ('界面媒体测试' + tag, body, author, 'approved', 0, db.now(), db.now(), 'share', 0))
print(json.dumps({'aid': aid, 'files': files, 'small': small, 'big': big,
                  'tall': tall, 'video': vid}))
`;

const CLEANUP = (ids) => `
import sys, os, json
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
import config, db
ids = ${JSON.stringify(ids)}
if ids.get('aid'):
    # ★ 先删这篇测试文章发出的审核通知，再删文章本身。
    #   以前只删文章、不管通知，管理员和作者的「我的消息」里就会留下
    #   「新的书单待审核：zzam_pub_xxx 发表了《测试视频文章...》」这种悬空消息
    #   （书的 id 都没了，点进去也是空的）。按本次创建的文章 id 精确删，不误伤别人。
    db.ex("DELETE FROM messages WHERE ref_type='booklist' AND ref_id=?", (ids['aid'],))
    db.ex("DELETE FROM booklists WHERE id=?", (ids['aid'],))
for k in ('small', 'big', 'tall', 'video'):
    fn = (ids.get('files') or {}).get(k)
    if fn:
        p = os.path.join(config.IMAGE_DIR, fn)
        if os.path.exists(p): os.remove(p)
print('cleaned')
`;

(async () => {
  const fx = JSON.parse(py(FIXTURE));
  console.log('  造好文章 #%d（小图 %s / 大图 %s / 竖图 %s / 视频 %s）', fx.aid, fx.small, fx.big, fx.tall, fx.video);
  let browser;
  try {
    browser = await chromium.launch({ executablePath: CHROME, headless: true,
      args: ['--no-sandbox', '--ignore-certificate-errors', '--autoplay-policy=no-user-gesture-required'] });
    const ctx = await browser.newContext({ ignoreHTTPSErrors: true, viewport: { width: 1200, height: 900 } });
    const page = await ctx.newPage();
    const errs = [];
    page.on('pageerror', e => errs.push(String(e)));
    page.on('dialog', d => d.accept());

    await page.goto(BASE + '/#/booklist/' + fx.aid, { waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(3500);

    const MEASURE = () => {
      const box = document.querySelector('.bl-content');
      if (!box) return null;
      const kids = [...box.querySelectorAll('img.bl-media, video.bl-media')];
      return {
        boxW: box.clientWidth,
        vh: window.innerHeight,
        boxRect: (() => { const r = box.getBoundingClientRect(); return { l: r.left, r: r.right }; })(),
        items: kids.map(el => {
          const cs = getComputedStyle(el);
          const r = el.getBoundingClientRect();
          return {
            tag: el.tagName.toLowerCase(),
            cls: el.className,
            display: cs.display,
            ml: cs.marginLeft, mr: cs.marginRight,
            maxW: cs.maxWidth,
            controls: el.tagName === 'VIDEO' ? el.hasAttribute('controls') : null,
            playsinline: el.tagName === 'VIDEO' ? el.hasAttribute('playsinline') : null,
            naturalW: el.tagName === 'IMG' ? el.naturalWidth : null,
            naturalH: el.tagName === 'IMG' ? el.naturalHeight : null,
            w: Math.round(r.width), h: Math.round(r.height),
            left: Math.round(r.left), right: Math.round(r.right),
          };
        }),
      };
    };
    const art = await page.evaluate(MEASURE);
    ck('文章正文渲染出来了', !!art, art ? '' : '.bl-content 不存在');
    if (!art) throw new Error('正文没渲染，后面没法测');
    ck('四件媒体都渲染出来了（3 图 1 视频）', art.items.length === 4,
      art.items.map(i => i.tag).join(','));

    const imgs = art.items.filter(i => i.tag === 'img');
    const vids = art.items.filter(i => i.tag === 'video');
    ck('图片仍然是 <img>', imgs.length === 3, String(imgs.length));
    ck('视频渲染成 <video>（不是 img）', vids.length === 1, String(vids.length));

    // ---- 尺寸：不超过容器就按实际大小，超过才等比缩小 ----
    const small = imgs.find(i => i.naturalW === 200);
    const big = imgs.find(i => i.naturalW === 2400);
    ck('小图读到了原始尺寸', !!small, JSON.stringify(imgs.map(i => [i.naturalW, i.naturalH])));
    if (small) {
      ck('小图按实际大小显示（没有被拉大铺满）', small.w === 200 && small.h === 100,
        `${small.w}x${small.h}，原始 ${small.naturalW}x${small.naturalH}`);
      ck('小图远小于正文宽度（确实没铺满）', small.w < art.boxW * 0.6,
        `图 ${small.w} / 容器 ${art.boxW}`);
      ck('小图等比：宽高比保持不变', Math.abs(small.w / small.h - small.naturalW / small.naturalH) < 0.02,
        `${small.w}x${small.h}`);
    }
    if (big) {
      ck('大图被限制在正文宽度以内（没有溢出）', big.w <= art.boxW + 1,
        `图 ${big.w} / 容器 ${art.boxW}`);
      ck('大图等比缩小（宽高比不变）', Math.abs(big.w / big.h - big.naturalW / big.naturalH) < 0.02,
        `${big.w}x${big.h}，原始 ${big.naturalW}x${big.naturalH}`);
      ck('大图没有被压成固定高度（h 不等于 0 或写死值）', big.h > 50, String(big.h));
    }

    // ---- ★ 竖图：不能按宽度铺满后把整屏占掉（与视频同一套规矩）----
    const tall = imgs.find(i => i.naturalW === 900);
    ck('竖图读到了原始尺寸', !!tall, JSON.stringify(imgs.map(i => [i.naturalW, i.naturalH])));
    if (tall) {
      ck('★ 竖图高度不超过 70vh（一屏放得下）', tall.h <= Math.round(art.vh * 0.7) + 2,
        `图高 ${tall.h} / 70vh=${Math.round(art.vh * 0.7)} / 视口 ${art.vh}`);
      ck('★ 竖图等比缩小（宽高比保持不变）',
        Math.abs(tall.w / tall.h - tall.naturalW / tall.naturalH) < 0.02,
        `${tall.w}x${tall.h}（原始 ${tall.naturalW}x${tall.naturalH}）`);
      ck('竖图也没有超出正文宽度', tall.w <= art.boxW + 1, `图 ${tall.w} / 容器 ${art.boxW}`);
      ck('这张图确实是「铺满就会超标」的尺寸（说明上面不是空过的）',
        Math.round(art.boxW * tall.naturalH / tall.naturalW) > art.vh * 0.7,
        `按宽度铺满会是 ${Math.round(art.boxW * tall.naturalH / tall.naturalW)}px 高`);
    }

    // ---- 居中 ----
    for (const [i, it] of art.items.entries()) {
      ck(`第 ${i + 1} 件媒体是块级元素（居中必须有它）`, it.display === 'block', it.display);
      // 注意：元素占满容器时，margin:auto 解析出的计算值就是 0px，
      // 所以这里只断言「左右相等」，「是否真在中间」由下面实测留白那条兜底。
      ck(`第 ${i + 1} 件媒体左右外边距相等 → 居中`,
        it.ml === it.mr, `margin-left=${it.ml} margin-right=${it.mr}`);
      const gapL = it.left - art.boxRect.l, gapR = art.boxRect.r - it.right;
      ck(`第 ${i + 1} 件媒体实测左右留白基本相等（真的在中间）`, Math.abs(gapL - gapR) <= 2,
        `左 ${Math.round(gapL)} / 右 ${Math.round(gapR)}`);
    }

    // ---- 视频能播 ----
    if (vids.length) {
      ck('视频带 controls 控件（可以点播放）', vids[0].controls === true);
      ck('视频带 playsinline（手机上不强制全屏）', vids[0].playsinline === true);
      const meta = await page.evaluate(async () => {
        const v = document.querySelector('video.bl-media');
        if (!v) return null;
        if (!v.readyState) {
          await new Promise(res => { v.addEventListener('loadedmetadata', res, { once: true }); setTimeout(res, 6000); });
        }
        return { dur: v.duration, w: v.videoWidth, h: v.videoHeight, ready: v.readyState,
                 err: v.error ? v.error.code : null,
                 canPlay: !!v.canPlayType('video/mp4') };
      });
      ck('浏览器能识别 mp4 格式', meta && meta.canPlay === true, JSON.stringify(meta && meta.canPlay));
      ck('视频元数据加载成功、能读出时长（说明真的能播）',
        meta && meta.dur > 0 && meta.err == null, JSON.stringify(meta));
      ck('视频尺寸被限制在容器宽度内', vids[0].w <= art.boxW + 1, `${vids[0].w} / ${art.boxW}`);
      ck('视频高度不超过 70vh（竖屏视频不会占满整屏）',
        vids[0].h <= Math.round(art.vh * 0.7) + 2, `${vids[0].h} / 70vh=${Math.round(art.vh * 0.7)}`);
    }

    // ---- ★ 手机视口（21:9 常见机型 390x844）：用户实际就是在这儿看文章 ----
    //   桌面 1200x900 下 900x2400 的竖图「不超标宽」，手机窄屏下才最容易被铺满整屏。
    const phoneCtx = await browser.newContext({ ignoreHTTPSErrors: true,
      viewport: { width: 390, height: 844 } });
    const phone = await phoneCtx.newPage();
    await phone.goto(BASE + '/#/booklist/' + fx.aid, { waitUntil: 'domcontentloaded' });
    await phone.waitForTimeout(3000);
    const artP = await phone.evaluate(MEASURE);
    ck('手机视口下正文渲染出来了', !!artP, artP ? '' : '.bl-content 不存在');
    if (artP) {
      const sP = artP.items.find(i => i.naturalW === 200);
      const bP = artP.items.find(i => i.naturalW === 2400);
      const tP = artP.items.find(i => i.naturalW === 900);
      ck('手机视口：小图仍是原始大小（200x100，没被拉大铺满）',
        !!sP && sP.w === 200 && sP.h === 100, sP ? `${sP.w}x${sP.h}` : '找不到小图');
      ck('手机视口：大图缩到正文宽度以内（没有横向溢出）',
        !!bP && bP.w <= artP.boxW + 1, bP ? `图 ${bP.w} / 容器 ${artP.boxW}` : '找不到大图');
      ck('★ 手机视口：竖图高度不超过 70vh（一屏放得下）',
        !!tP && tP.h <= Math.round(artP.vh * 0.7) + 2,
        tP ? `图高 ${tP.h} / 70vh=${Math.round(artP.vh * 0.7)} / 视口 ${artP.vh}` : '找不到竖图');
      ck('★ 手机视口：竖图是等比缩窄的（不是被裁掉一截）',
        !!tP && tP.w < tP.naturalW * 0.6 && Math.abs(tP.w / tP.h - tP.naturalW / tP.naturalH) < 0.02,
        tP ? `显示 ${tP.w}x${tP.h}（原始 ${tP.naturalW}x${tP.naturalH}）` : '找不到竖图');
      ck('★ 手机视口：竖图仍然居中',
        !!tP && Math.abs((tP.left - artP.boxRect.l) - (artP.boxRect.r - tP.right)) <= 1,
        tP ? `左留白 ${tP.left - artP.boxRect.l} / 右留白 ${artP.boxRect.r - tP.right}` : '找不到竖图');
    }
    await phoneCtx.close();

    // ---- 编辑器有「插入视频」按钮 ----
    const ui = await page.evaluate(() => {
      if (typeof renderWriteForm !== 'function') return { ok: false, why: 'renderWriteForm 不存在' };
      const host = document.createElement('div');
      host.id = 'zzam-probe';
      document.body.appendChild(host);
      const orig = document.getElementById('write-body');
      if (orig) { orig.id = 'write-body-orig'; }
      host.id = 'write-body';
      renderWriteForm('', '', 'share');
      const btns = [...host.querySelectorAll('button')].map(b => b.textContent.trim());
      const label = [...host.querySelectorAll('.form-group label')].map(x => x.textContent.trim()).join(' | ');
      const html = host.innerHTML;
      host.remove();
      if (orig) orig.id = 'write-body';
      return { ok: true, btns, label: label, html: html };
    });
    ck('发表文章表单能渲染', ui.ok === true, ui.why || '');
    if (ui.ok) {
      ck('表单里有「插入图片」按钮（原有功能没丢）',
        ui.btns.some(t => t.indexOf('插入图片') >= 0), JSON.stringify(ui.btns));
      ck('表单里有「插入视频」按钮（本次新增）',
        ui.btns.some(t => t.indexOf('插入视频') >= 0), JSON.stringify(ui.btns));
      ck('内容项的标签里写明了支持视频', ui.label.indexOf('视频') >= 0, ui.label);
      ck('插入视频按钮绑定了 blPickVideo()', ui.html.indexOf('blPickVideo()') >= 0);
    }
    ck('页面上有 blPickVideo 与 isVideoUrl 两个函数',
      await page.evaluate(() => typeof blPickVideo === 'function' && typeof isVideoUrl === 'function'));

    // ---- 渲染函数本身的口径 ----
    const r = await page.evaluate(() => ({
      img: md('![图](/uploads/a.png)'),
      mp4: md('![视频](/uploads/a.mp4)'),
      webm: isVideoUrl('/uploads/a.webm'),
      upper: isVideoUrl('/uploads/a.MP4'),
      query: isVideoUrl('/uploads/a.mp4?t=1'),
      notvid: isVideoUrl('/uploads/a.png'),
    }));
    ck('图片语法渲染成 <img class="bl-media">',
      r.img.indexOf('<img class="bl-media"') >= 0, r.img);
    ck('视频语法渲染成 <video class="bl-media" controls',
      r.mp4.indexOf('<video class="bl-media"') >= 0 && r.mp4.indexOf('controls') >= 0, r.mp4);
    ck('视频标签带 playsinline 与 preload=metadata', r.mp4.indexOf('playsinline') >= 0 && r.mp4.indexOf('preload="metadata"') >= 0, r.mp4);
    ck('不再写行内 style（改由 CSS 统一管）', r.img.indexOf('style=') < 0 && r.mp4.indexOf('style=') < 0);
    ck('扩展名判断大小写不敏感', r.upper === true);
    ck('带查询串的视频地址也认得', r.query === true);
    ck('图片地址不会被误判成视频', r.notvid === false);

    ck('页面无 JS 报错', errs.length === 0, errs.slice(0, 2).join(' | '));
  } finally {
    if (browser) await browser.close();
    py(CLEANUP({ aid: fx.aid, files: fx.files }));
    console.log('  已按精确 id 与文件名清理测试数据');
  }

  console.log('\n  ===== 通过 ' + pass + ' / 失败 ' + fail + ' =====');
  process.exit(fail ? 1 : 0);
})();
