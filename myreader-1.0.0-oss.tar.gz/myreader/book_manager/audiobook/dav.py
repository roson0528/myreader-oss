"""WebDAV 上传（自带，不用 ftp_service 的 makedirs / upload_file）。

★ 为什么不能直接用 ftp_service：
  1) `ftp_service.makedirs()` 用 `relpath.split("/")` 拆路径后**丢掉了开头的 `/`**，
     而 `_dav_url()` 把「没有开头 `/` 的路径」当成相对路径拼到默认根下。
     于是 `makedirs('/books/BakFile/有声书/xx')` 会在
     **/books/** 下面建出一棵 `homes/bookadmin/BakFile/有声书/xx` 的错位目录树
     —— 而它每一级的 MKCOL 异常都被 `except: pass` 吞掉，最后照样 `return True`。
     实测踩过：目录建到了错误的地方，PUT 因父目录不存在而失败。
  2) `ftp_service.upload_file()` 失败时会回退到 FTP，并且**返回本地文件大小**，
     所以调用方看到「有返回值」就以为上传成功了 —— 实测文件根本没上去。
     批量制作动辄几小时的成果，不能建立在一个静默失败的返回值上。

所以这里自己实现：路径一律按绝对路径处理，上传后**回查远端确认**，
拿不到确认就抛异常（任务会记失败并保留断点，不会假装成功）。
"""
import os
import sys
import urllib.parse
import urllib.request
import urllib.error
import base64
import ssl

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE)

import config  # noqa: E402

_CTX = ssl._create_unverified_context()


def _cfg():
    """复用 config 里已有的 WebDAV/FTP 凭据（与备份、上传书籍同一套）。"""
    host = getattr(config, "WEBDAV_HOST", None) or getattr(config, "FTP_HOST", "")
    port = getattr(config, "WEBDAV_PORT", 5005)
    return ("http://%s:%s" % (host, port), config.FTP_USER, config.FTP_PASS)


def _url(path):
    base = (_cfg()[0] or "").rstrip("/")
    if not path.startswith("/"):
        raise ValueError("WebDAV 路径必须是绝对路径（以 / 开头）：%r" % path)
    return base + urllib.parse.quote(path, safe="/")


def _req(method, path, body=None, timeout=120, headers=None):
    url = _url(path)
    req = urllib.request.Request(url, data=body, method=method)
    u, p = _cfg()[1], _cfg()[2]
    if u:
        req.add_header("Authorization",
                       "Basic " + base64.b64encode(("%s:%s" % (u, p)).encode()).decode())
    for k, v in (headers or {}).items():
        req.add_header(k, v)
    return urllib.request.urlopen(req, timeout=timeout, context=_CTX)


def exists(path):
    try:
        with _req("PROPFIND", path, timeout=60, headers={"Depth": "0"}) as r:
            return r.status in (200, 207)
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return False
        raise
    except Exception:
        return False


def mkcol(path):
    """建目录（含各级父目录）。路径按**绝对**处理，绝不丢开头的斜杠。"""
    parts = [p for p in (path or "").split("/") if p]
    cur = ""
    for p in parts:
        cur += "/" + p
        try:
            with _req("MKCOL", cur, timeout=60) as r:
                r.read()
        except urllib.error.HTTPError as e:
            # 405 = 已存在；409 = 父目录还没建好（正常情况下不会，因为我们是顺序建的）
            if e.code in (405, 301):
                continue
            if e.code == 409:
                continue
            raise RuntimeError("建目录 %s 失败：HTTP %d" % (cur, e.code))
    return True


def put(local, remote, verify=True):
    """上传一个文件，成功后返回远端字节数。

    verify=True 时上传后回查 PROPFIND，确认远端确实有这个文件且大小对得上。
    这是对「ftp_service 那种静默失败」的直接回应：宁可让任务失败并保留断点，
    也不能让它以为传上去了。
    """
    mkcol(os.path.dirname(remote))
    with open(local, "rb") as fh:
        data = fh.read()
    try:
        with _req("PUT", remote, body=data, timeout=600,
                  headers={"Content-Type": "application/octet-stream"}) as r:
            r.read()
    except urllib.error.HTTPError as e:
        detail = ""
        try:
            detail = e.read().decode("utf-8", "replace")[:200]
        except Exception:
            pass
        raise RuntimeError("上传 %s 失败：HTTP %d %s" % (os.path.basename(remote), e.code, detail))
    if verify:
        n = size(remote)
        if n is None:
            raise RuntimeError("上传 %s 后回查不到该文件" % os.path.basename(remote))
        if n != len(data):
            raise RuntimeError("上传 %s 大小不符：远端 %s 本地 %s"
                               % (os.path.basename(remote), n, len(data)))
        return n
    return len(data)


def size(path):
    """远端文件大小；不存在返回 None。"""
    try:
        with _req("PROPFIND", path, timeout=60, headers={"Depth": "0"}) as r:
            xml = r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return None
        raise
    import re
    # ★ 属性名的命名空间前缀不固定：Apache mod_dav 回的是 `lp1:getcontentlength`，
    #   而有的服务器回 `D:`/`d:`。只写 (D|d) 会漏掉 lp1，导致「文件明明传上去了
    #   却回查不到大小」—— 实测就这么误判过一次。所以前缀一律用 [\w]*:? 兜住。
    m = re.search(r"<[\w]*:?getcontentlength>\s*(\d+)\s*</", xml, re.I)
    return int(m.group(1)) if m else None


def get(remote, local):
    """从 WebDAV 下载一个文件到本地，返回字节数。

    与 put 对称：下载后核对字节数，和 PROPFIND 报的大小不一致就报错。
    （选取 NAS 上的音乐当背景音乐时用；混音只能读本地文件。）
    """
    os.makedirs(os.path.dirname(os.path.abspath(local)), exist_ok=True)
    tmp = local + ".part"
    n = 0
    try:
        with _req("GET", remote, timeout=600) as r, open(tmp, "wb") as f:
            while True:
                chunk = r.read(1 << 20)
                if not chunk:
                    break
                f.write(chunk)
                n += len(chunk)
    except urllib.error.HTTPError as e:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise RuntimeError("下载 %s 失败：HTTP %d" % (os.path.basename(remote), e.code))
    except Exception:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise
    if n <= 0:
        os.remove(tmp)
        raise RuntimeError("下载 %s 得到 0 字节" % os.path.basename(remote))
    want = size(remote)
    if want is not None and want != n:
        os.remove(tmp)
        raise RuntimeError("下载 %s 不完整：远端 %s 本地 %s" % (os.path.basename(remote), want, n))
    os.replace(tmp, local)
    return n


def delete(path):
    try:
        with _req("DELETE", path, timeout=120) as r:
            r.read()
        return True
    except urllib.error.HTTPError as e:
        return e.code == 404


def move(src, dst, overwrite=True):
    """服务端改名/移动（WebDAV MOVE）—— 一个字节都不搬，目录也一样。

    为什么不用「下载 + 上传 + 删远端」：一本有声书好几百 MB，改名却要来回搬两遍，
    既慢又平白多一次「传到一半失败」的机会。实测标准 WebDAV 支持 MOVE（返回 201），
    文件与目录都能动。调用方仍要自己核对结果 —— 别假设一定成功。
    """
    if not src.startswith("/") or not dst.startswith("/"):
        raise ValueError("WebDAV 路径必须是绝对路径（以 / 开头）")
    parent = dst.rsplit("/", 1)[0]
    if parent:
        mkcol(parent)
    req = urllib.request.Request(_url(src), method="MOVE")
    u, p = _cfg()[1], _cfg()[2]
    if u:
        req.add_header("Authorization",
                       "Basic " + base64.b64encode(("%s:%s" % (u, p)).encode()).decode())
    req.add_header("Destination", _url(dst))
    req.add_header("Overwrite", "T" if overwrite else "F")
    try:
        with urllib.request.urlopen(req, timeout=600, context=_CTX) as r:
            r.read()
            return r.status
    except urllib.error.HTTPError as e:
        raise RuntimeError("MOVE %s → %s 失败：HTTP %d %s" % (src, dst, e.code, e.reason))
    except urllib.error.URLError as e:
        raise RuntimeError("MOVE %s → %s 失败：%s" % (src, dst, e))
