// 上传下载日志的重复记录：**一个 ticket = 一次下载 = 一条日志**。
//
// 背景（§14.74）：浏览器和下载管理器拿到直链后经常发**两次** GET
// （先普通 GET 探一下，再带 `Range: bytes=0-` 正式拉）。原来的「首次」判定是
// 「没有 Range，或 bytes=0-」，这两次**全都算首次**，于是每次下载被记成两条
// 一模一样、同一秒的行 —— 管理页「上传下载」里一半是重复。
// 实测访问日志：9 个 ticket 全部被 GET 了 2 次。
//
// ★ 一次下载会同时写**三张表**，去重必须三张一起看（§14.78）：
//     file_logs      管理页「上传下载」日志
//     download_logs  月度配额计数（重复 = 用户配额被双倍吃掉）
//     audit_logs     审计明细（action=download）
//   以前这个测试只盯 file_logs，`download_logs` 的重复根本没被发现，
//   测试自己跑一轮留 3 条、跑 7 轮就在库里积了 21 条没人清。
//
// 这个测试直接打真实 HTTP，用测试账号 test，自己造数据、按**精确 id** 清理
// （不用 `id > 快照` —— 那样会连带删掉别人并发写入的行）。
const { execSync } = require('child_process');
const ROOT = '/srv/myreader/book_manager';
const BASE = 'https://127.0.0.1:9000';

let pass = 0, fail = 0;
const ck = (n, ok, extra) => {
  if (ok) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (extra ? '  → ' + extra : '')); }
};
const py = (c) => execSync('venv/bin/python -', { cwd: ROOT, encoding: 'utf8', input: c }).trim();
const H = (tok) => ({ 'Authorization': 'Bearer ' + tok, 'X-BM-No-Push': '1' });

process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

// 三张表统一的「取当前最大 id / 取 id 之后的整行 / 按精确 id 删」
const T = { file: 'file_logs', dl: 'download_logs', audit: 'audit_logs' };
const collected = { file: [], dl: [], audit: [] };
const snap = () => Object.fromEntries(Object.entries(T).map(([k, t]) =>
  [k, Number(py(`import sys; sys.path.insert(0,'${ROOT}')
import db
r = db.q("SELECT MAX(id) m FROM ${t}", one=True)
print(r["m"] or 0)`))]));

// 收集「快照之后属于本次测试账号」的精确 id（用于断言 + 精确清理）
const collect = (s, uid) => {
  const got = JSON.parse(py(`import sys, json
sys.path.insert(0, '${ROOT}')
import db
SNAP = ${JSON.stringify(s)}
UID = ${uid}
out = {}
for k, t in (('file','file_logs'), ('dl','download_logs'), ('audit','audit_logs')):
    out[k] = [r["id"] for r in db.q("SELECT id FROM " + t + " WHERE id>? AND user_id=? ORDER BY id", (SNAP[k], UID))]
print(json.dumps(out))`));
  for (const k of Object.keys(got)) for (const id of got[k]) if (!collected[k].includes(id)) collected[k].push(id);
  return got;
};

(async () => {
  const info = JSON.parse(py(`
import sys, json
sys.path.insert(0, '${ROOT}')
import db, auth
u = db.q("SELECT * FROM users WHERE username='test' AND enabled=1", one=True)
if not u:
    raise SystemExit('测试账号 test 不存在')
# 挑一本能下的书（不依赖具体 id）
b = db.q("SELECT id, ext FROM books WHERE hidden=0 AND size>1000 ORDER BY id LIMIT 1", one=True)
print(json.dumps({"tok": auth.create_token(u), "uid": u["id"], "bid": b["id"], "ext": (b["ext"] or "").lstrip(".")}))`));
  const { tok, bid, ext } = info;
  const S = snap();

  const ticket = async () => {
    const r = await fetch(`${BASE}/api/books/${bid}/download-ticket`,
                          { method: 'POST', headers: H(tok) });
    return (await r.json()).ticket;
  };
  const get = (tk, range) => fetch(
    `${BASE}/api/books/${bid}/download${ext ? '.' + ext : ''}?ticket=${tk}`,
    { headers: range ? { Range: range } : {} });

  const count = () => { const g = collect(S, info.uid); return { file: g.file.length, dl: g.dl.length, audit: g.audit.length }; };

  try {
    // 1) 同一个 ticket 连发 3 次（模拟：探测 + 正式拉 + 重试）
    const t1 = await ticket();
    const n0 = count();
    await get(t1); await get(t1, 'bytes=0-'); await get(t1);
    const n1 = count();
    ck('★ 同一个 ticket 发 3 次 GET，file_logs 只记 1 条', n1.file - n0.file === 1, '多了 ' + (n1.file - n0.file) + ' 条');
    // ★ 配额表也必须只记 1 条 —— 重复记 = 用户的月度下载配额被双倍吃掉
    ck('★ 同一个 ticket 发 3 次 GET，download_logs（配额）只记 1 条',
       n1.dl - n0.dl === 1, '多了 ' + (n1.dl - n0.dl) + ' 条');
    ck('★ 同一个 ticket 发 3 次 GET，audit_logs 只记 1 条',
       n1.audit - n0.audit === 1, '多了 ' + (n1.audit - n0.audit) + ' 条');

    // 2) 换一个新 ticket = 新的一次下载 → 三张表各 +1
    const t2 = await ticket();
    await get(t2, 'bytes=0-'); await get(t2);
    const n2 = count();
    ck('★ 新 ticket（新的一次下载）file_logs 再记 1 条', n2.file - n1.file === 1, '多了 ' + (n2.file - n1.file) + ' 条');
    ck('★ 新 ticket download_logs 再记 1 条', n2.dl - n1.dl === 1, '多了 ' + (n2.dl - n1.dl) + ' 条');
    ck('★ 新 ticket audit_logs 再记 1 条', n2.audit - n1.audit === 1, '多了 ' + (n2.audit - n1.audit) + ' 条');

    // 3) 记录的内容仍然完整（别为了去重把字段丢了）
    const row = JSON.parse(py(`
import sys, json
sys.path.insert(0, '${ROOT}')
import db
r = db.q("SELECT * FROM file_logs WHERE user_id=? ORDER BY id DESC LIMIT 1", (${info.uid},), one=True)
print(json.dumps({k: r[k] for k in r.keys()}))`));
    ck('日志字段完整（扩展名/大小/来源/书籍）',
       !!row.filename && row.ext === ext && row.source === 'web' && Number(row.book_id) === Number(bid),
       JSON.stringify({ f: row.filename, e: row.ext, s: row.source, b: row.book_id }));
    ck('记的是当前测试账号', Number(row.user_id) === Number(info.uid), row.username);

    // 4) 老的 Bearer 直连（没有 ticket）仍按 Range 判定：中途分段不重复记
    const m1 = count();
    await fetch(`${BASE}/api/books/${bid}/download`, { headers: H(tok) });
    const m2 = count();
    await fetch(`${BASE}/api/books/${bid}/download`, { headers: { ...H(tok), Range: 'bytes=1000-' } });
    const m3 = count();
    ck('无 ticket 的老式调用 file_logs 仍记 1 条', m2.file - m1.file === 1, '多了 ' + (m2.file - m1.file) + ' 条');
    ck('无 ticket 的老式调用 download_logs 仍记 1 条', m2.dl - m1.dl === 1, '多了 ' + (m2.dl - m1.dl) + ' 条');
    ck('★ 中途分段请求（bytes=1000-）file_logs 不重复记', m3.file - m2.file === 0, '多了 ' + (m3.file - m2.file) + ' 条');
    ck('★ 中途分段请求 download_logs 不重复记', m3.dl - m2.dl === 0, '多了 ' + (m3.dl - m2.dl) + ' 条');
    ck('★ 中途分段请求 audit_logs 不重复记', m3.audit - m2.audit === 0, '多了 ' + (m3.audit - m2.audit) + ' 条');
  } finally {
    // ★ 按**精确 id** 清理三张表（本测试每次跑会真的产生下载记录，
    //   不清就会在库里越积越多 —— 以前只清 file_logs，download_logs 积了 21 条）
    const n = collect(S, info.uid);
    const del = [];
    for (const k of Object.keys(T)) for (const id of (n[k] || [])) if (!del.includes(T[k] + ':' + id)) del.push(T[k] + ':' + id);
    py(`import sys; sys.path.insert(0,'${ROOT}')
import db
for item in ${JSON.stringify(del)}:
    t, i = item.split(':')
    db.ex("DELETE FROM " + t + " WHERE id=?", (int(i),))
print("ok")`);
    const left = count();
    ck('测试数据已按精确 id 清理（三张表都清）',
       left.file === 0 && left.dl === 0 && left.audit === 0,
       JSON.stringify(left));
  }

  console.log(`\n上传下载日志去重：${pass} 通过 / ${fail} 失败`);
  process.exit(fail ? 1 : 0);
})();
