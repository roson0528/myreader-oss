# 架构说明

## 1. 整体结构

```
浏览器 / Kindle / App
        │  HTTPS
        ▼
   FastAPI 应用（app.py，单进程，同步路由为主）
        ├── 鉴权层 auth.py           JWT、角色、可见性、用户组能力开关
        ├── 业务模块                 books / booklists / promote / notify / stats / audiobook
        ├── 阅读管线 reader.py       章节切分 → 分段返回 → 正文渲染（含 Markdown、PDF、DOCX）
        ├── 存储抽象 ftp_service.py  WebDAV（主）/ FTP / SFTP（兜底）
        └── 数据层 db.py             SQLite（WAL），裸 SQL，无 ORM
```

前端是原生 HTML/CSS/JS：`index.html`（书库）、`reader.html`（阅读器）、`listen.html`（听书）、`share.html`（分享页）、`admin.html`（后台），各自配套一个 `.js`，没有构建步骤。

## 2. 一次阅读请求的链路

1. 前端 `GET /api/books/{id}/toc` 拿目录（章节目录从存储后端的源文件解析一次后缓存到数据库）。
2. 滚动/翻页时 `GET /api/books/{id}/txt?idx=n` 取该段正文。
3. 服务端 `reader.py`：
   - 先 `covers.ensure_local(book)` 把书缓存到 `data/cache/b{id}_…`；
   - 按格式分派：EPUB 走 `formats.py` 解析 → 章节 HTML；TXT/MD/DOCX 切段；PDF 走 pdf.js 前端渲染。
   - **缓存新鲜度**：命中缓存的条件是「大小相同 **且** 缓存 mtime 不早于 `books.updated_at`」，只比大小会让「改几个字但字节数不变」的文档一直读旧内容。
4. 响应头 `Cache-Control: no-store`（`/api/books/*` 前缀统一加），避免浏览器留着旧正文。

## 3. 书库与存储

书本身**不在服务器硬盘上**，源文件放在存储后端（WebDAV / FTP）的分类目录里，数据库只记路径与元数据。

- `sync.py`：对比后端目录与 `books` 表，增量增删改。
- `seed.py`：首次按 CLC 分类目录批量入库。
- `import_xunlei.py`：把下载目录里的电子书分类 → MOVE 进书库目录。
- `dedup.py`：`size` 分组 → 全文件 MD5 → 揪出字节级重复。
- 本地 `data/` 下只有缓存（`cache/`、`covers/`、`converted/`），删了不丢数据。

### 技术报告投放区（report_sync.py）

一个本地文件夹就是真源：

```
report/*.md|txt|docx ──扫描──► books(owner=指定账号, path=upload/user_N/report/*)
                              └──► 书架「技术报告」
```

- **幂等**：文件名 + 内容 sha256（`data/report_manifest.json`）判断新增/更新/未变。
- **更新即刷新**：内容变了就更新书行（id 不变、进度不丢）、覆盖后端副本、**清掉本地缓存**，打开就是新内容。
- **回收**：扫描不到的源文件对应的书，连后端副本、进度、笔记、分享一起清掉；两道安全阀（投放区不可读则不清理；扫到 0 个文件但书架还有书则默认不动，要 `--force`）。

## 4. 数据模型（主要表）

| 表 | 用途 |
| --- | --- |
| `users` / `user_groups` | 账号、角色、组能力开关（分享、发表、听书线路…） |
| `books` | 书：路径、格式、大小、封面、简介、可见性、`updated_at` |
| `shelves` / `shelf_collections` | 书架条目与分类 |
| `progress` / `reading_stats` | 阅读进度、阅读时长沉淀 |
| `notes` / `book_reports` | 笔记划线、纠错反馈 |
| `shares` / `share_requests` | 分享链接与提取申请 |
| `booklists` / `booklist_items` | 书单讨论文章 |
| `download_logs` / `convert_logs` / `file_logs` | 下载、转换、文件操作审计 |
| `listen_*` | 听书线路、会话、进度、日志 |
| `ab_*` | 「有声」库：作品、章节、逐句文本 |

## 5. 缓存与性能

| 缓存 | 位置 | 失效方式 |
| --- | --- | --- |
| 书籍正文 | `data/cache/b{id}_*` | 大小或 `updated_at` 变化即重新下载；同步脚本更新书时主动删 |
| 封面 | `data/covers/` | 同上 |
| 章节结构 | 数据库（首次解析后落库） | 书内容更新时重建 |
| TTS 音频 | 内存 LRU + 磁盘 | 容量淘汰 |
| 静态资源 | 浏览器 | `?v=` 版本号 + 中间件 `no-store` |

## 6. 扩展点

- **新增阅读格式**：在 `reader.py` 的分派里加一个分支，或在 `formats.py` 增加解析器；`config.BOOK_EXTS` 加后缀即可被上传/同步接受。
- **新增存储后端**：`ftp_service.py` 对外只有 `list_dir / stat / download_to / upload / move / delete` 几个方法，换实现不影响上面所有业务。
- **新增 TTS 线路**：`listen_admin.py` 里配线路（地址/密钥/音色），`tts.py` 的调用层是通用的 OpenAI 兼容协议。
