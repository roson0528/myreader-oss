# 第三方组件

本项目的自有代码以 MIT 发布；下列第三方资产随包分发，遵循其各自许可。

| 组件 | 位置 | 许可 | 说明 |
| --- | --- | --- | --- |
| pdf.js（pdf.min.js / pdf.worker.min.js） | `book_manager/static/vendor/` | Apache-2.0 | 在浏览器端渲染 PDF 页面 |

## 未随包分发、需要自行安装的可选依赖

| 组件 | 用途 | 许可 |
| --- | --- | --- |
| FFmpeg | 有声书混音/转码 | LGPL/GPL（取决于构建选项） |
| calibre（ebook-convert） | mobi/azw3 → epub 转换 | GPL-3.0 |
| catdoc | 读取 .doc（Word 97） | GPL |
| Python 包（FastAPI、uvicorn、PyJWT、Pillow、Markdown、paramiko、httpx 等） | 运行时依赖 | 见 `requirements.txt` 各自的许可 |

## 字体与图标

前端只使用系统字体与内联 SVG，不含需授权的字体文件或图标集。`static/logo.png` 为占位图。

## 书籍内容

书库中的电子书版权归各自权利人所有。本项目只提供管理与阅读工具，不附带任何书籍内容；请勿将本工具用于侵权分发。
