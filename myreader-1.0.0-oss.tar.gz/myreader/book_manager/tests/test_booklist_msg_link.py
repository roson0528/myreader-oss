# -*- coding: utf-8 -*-
"""书单回复两条消息的跳转链接：必须直达**那一篇**书单，不是书单列表。

需求（2026-10-11）：
  · 收到「新的书单回复待审查」时，消息弹窗底部「关闭」旁边要有「前往查看」，
    点了直达文章链接（如 https://localhost:9000/#/booklist/18）；
  · 收到「您的书单收到新回复」时，点「前往查看」也要直达那篇文章，
    而不是书单讨论页。

原来的实际情况（已从库里核对）：
  · 「新的书单回复待审查」→ `notify_admins(...)` **根本没传 link** → 弹窗里只有「关闭」；
  · 「您的书单收到新回复」→ link 写死 `"#/booklists"` → 只到列表，还得自己翻那一篇。

本测试验后端产出的 link 与 ref（前端「按 ref 兜底」那一层由
tests/test_booklist_msg_link_ui.js 验）：
  1. 作者收到的消息 link == `#/booklist/<blid>`，ref_type/ref_id 齐全；
  2. 管理员收到的「待审查」消息 link **非空**且同样直达那一篇；
  3. 两类消息都带 ref，老消息才兜得住。

安全：临时分组 + 两个临时账号 + 一条临时书单，跑完按**精确 id** 清干净
（消息按 ref_type+ref_id 定位，是本测试独有的）。请求都带 X-BM-No-Push，
不会真发 Server酱。
运行：venv/bin/python tests/test_booklist_msg_link.py
"""
import os
import ssl
import sys
import json
import uuid
import urllib.request
import urllib.error
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
os.chdir(_ROOT)
import db, auth  # noqa: E402

BASE = 'https://127.0.0.1:9000'
CTX = ssl._create_unverified_context()

_pass = [0]
_fail = [0]
_created = {'users': [], 'groups': [], 'booklists': []}


def check(name, ok, extra=''):
    if ok:
        _pass[0] += 1
        print('  [OK] %s' % name + ('  %s' % extra if extra else ''))
    else:
        _fail[0] += 1
        print('  [FAIL] %s' % name + ('  %s' % extra if extra else ''))


def req(path, token=None, method='GET', body=None):
    h = {'X-BM-No-Push': '1'}     # 测试请求：服务端别真发 Server酱
    if token:
        h['Authorization'] = 'Bearer ' + token
    data = None
    if body is not None:
        data = json.dumps(body).encode()
        h['Content-Type'] = 'application/json'
    r = urllib.request.Request(BASE + path, data=data, headers=h, method=method)
    try:
        with urllib.request.urlopen(r, context=CTX, timeout=60) as resp:
            return resp.status, resp.read().decode('utf-8', 'replace')
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode('utf-8', 'replace')


def mk_user(group_id, tag):
    uname = 'zzbl_%s_%s' % (tag, uuid.uuid4().hex[:8])
    uid = db.ex("INSERT INTO users (username,password_hash,role,enabled,group_id,quota,created_at) "
                "VALUES (?,?,?,?,?,?,?)",
                (uname, auth.hash_password('zz' + uuid.uuid4().hex), 'user', 1, group_id, 50, db.now()))
    _created['users'].append(uid)
    return db.q('SELECT * FROM users WHERE id=?', (uid,), one=True)


def msgs_of(blid):
    return db.q("SELECT * FROM messages WHERE ref_type='booklist' AND ref_id=? ORDER BY id", (blid,))


def cleanup():
    for bid in _created['booklists']:
        db.ex('DELETE FROM messages WHERE ref_type=? AND ref_id=?', ('booklist', bid))
        db.ex('DELETE FROM booklist_comments WHERE booklist_id=?', (bid,))
        db.ex('DELETE FROM booklists WHERE id=?', (bid,))
    for uid in _created['users']:
        db.ex('DELETE FROM users WHERE id=?', (uid,))
    for gid in _created['groups']:
        db.ex('DELETE FROM user_groups WHERE id=?', (gid,))


def main():
    gid = db.add_group('zzbl_%s' % uuid.uuid4().hex[:6], can={'publish_booklist': True}, limits={})
    _created['groups'].append(gid)
    author = mk_user(gid, 'a')
    commenter = mk_user(gid, 'b')
    atok = auth.create_token(author)
    ctok = auth.create_token(commenter)

    # 一条已发布的临时书单（作者是 author，回复者是 commenter，两者不同人）
    blid = db.ex("INSERT INTO booklists (title,content,author_id,status,view_count,created_at,updated_at) "
                 "VALUES (?,?,?,?,?,?,?)",
                 ('zzbl测试书单%s' % uuid.uuid4().hex[:6], '正文', author['id'], 'approved', 0,
                  db.now(), db.now()))
    _created['booklists'].append(blid)

    print('== 1. 非免审用户回复 → 回复待审查 → 两条消息都该直达这一篇 ==')
    st, txt = req('/api/booklists/%d/comments' % blid, token=ctok, method='POST',
                  body={'content': '这是一条待审查的测试回复'})
    check('回复提交成功', st == 200, '%s %s' % (st, txt[:100]))
    try:
        st_status = json.loads(txt).get('status')
    except Exception:
        st_status = None
    check('回复确实是待审查（pending）', st_status == 'pending', str(st_status))

    ms = msgs_of(blid)
    want = '#/booklist/%d' % blid
    to_author = [m for m in ms if m['to_id'] == author['id']]
    admins = set(db.admin_ids())
    to_admins = [m for m in ms if m['to_id'] in admins]

    check('作者收到「您的书单收到新回复」', len(to_author) == 1 and to_author[0]['title'] == '您的书单收到新回复',
          str([m['title'] for m in to_author]))
    check('作者那条 link 直达这一篇（不再是 #/booklists）',
          bool(to_author) and to_author[0]['link'] == want,
          str(to_author[0]['link']) if to_author else '（没有这条消息）')
    check('管理员收到「新的书单回复待审查」', len(to_admins) >= 1,
          '%d 条 → %s' % (len(to_admins), [m['to_id'] for m in to_admins]))
    bad = [m['to_id'] for m in to_admins if m['link'] != want]
    check('管理员那条 link **非空**且同样直达这一篇（原来压根没有 link，弹窗只有「关闭」）',
          bool(to_admins) and not bad, '不达标的管理员: %s' % bad)
    check('两类消息都带 ref_type=booklist / ref_id（前端才能给老消息兜底）',
          all(m['ref_type'] == 'booklist' and m['ref_id'] == blid for m in ms),
          str([(m['ref_type'], m['ref_id']) for m in ms]))
    check('管理员那条 kind 仍是 review（弹窗按类型显示「待审查」徽标）',
          all(m['kind'] == 'review' for m in to_admins), str([m['kind'] for m in to_admins]))
    check('作者那条 kind 是 booklist', bool(to_author) and to_author[0]['kind'] == 'booklist')

    print('\n== 2. 作者本人回复 → 直接通过，不再提醒自己 ==')
    n_before = len(msgs_of(blid))
    st, txt = req('/api/booklists/%d/comments' % blid, token=atok, method='POST',
                  body={'content': '作者自己回复，应直接显示'})
    check('作者回复成功', st == 200, '%s %s' % (st, txt[:80]))
    ms2 = msgs_of(blid)
    check('作者自己回复不再给自己发「收到新回复」',
          len([m for m in ms2 if m['to_id'] == author['id'] and m['title'] == '您的书单收到新回复']) == 1,
          '共 %d 条（原来 1 条）' % len([m for m in ms2 if m['to_id'] == author['id']]))
    check('作者本人回复不产生新的待审查消息', len(ms2) - n_before <= 0, '新增 %d 条' % (len(ms2) - n_before))


if __name__ == '__main__':
    print('=== 书单回复消息的「前往查看」直达链接 后端回归 ===')
    try:
        main()
    finally:
        cleanup()
    print('\n通过 %d，失败 %d' % (_pass[0], _fail[0]))
    sys.exit(1 if _fail[0] else 0)
