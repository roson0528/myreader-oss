#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CLC(中图法22大类)+DDC 参照 图书分类器
输入: state/manifest.json + clc_terms.json
输出: state/plan.json (cat=CLC字母), reports/audit.csv (可复核/迭代训练)
"""
import json, os, re, sys
from collections import defaultdict, Counter

W = os.path.dirname(os.path.abspath(__file__))


def _load_manifest(path):
    """扫描结果不进仓库：先跑 scan.py 生成 state/manifest.json，再跑分类。

    缺文件时返回空清单，保证 import 本模块（book_manager 会复用 CAT_FOLDERS）
    在没有扫描数据的机器上也不会炸。"""
    try:
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    except FileNotFoundError:
        return {"files": []}


M = _load_manifest(os.path.join(W, "state", "manifest.json"))
FILES = M["files"]
TERMS = json.load(open(W + "/clc_terms.json"))

BOOK_EXT = {
    "epub", "mobi", "azw3", "azw", "txt", "pdf", "djvu", "chm",
    "doc", "docx", "uvz", "prc", "pdb", "html", "htm", "mob",
    "fb2", "lit", "ibooks", "umd", "cbr", "cbz", "pdg", "nh", "oeb"
}
ARCHIVE_EXT = {"zip", "rar", "7z"}

def ext_of(path):
    base = path.rsplit("/", 1)[-1]
    if "." not in base:
        return ""
    return base.rsplit(".", 1)[-1].lower()

CLASSES = {c["letter"]: c for c in TERMS["classes"]}
CAT_FOLDERS = {c["letter"]: f"{c['letter']}_{c['name']}" for c in TERMS["classes"]}
CAT_FOLDERS["00"] = "00_待分类"

# 英文关键词 -> CLC 字母（DDC 参照）
EN_MAP = {
    "F": ["economy", "economics", "economic", "finance", "financial", "financing", "invest", "investing", "investment",
          "investor", "business", "management", "managing", "manage", "marketing", "market", "money", "wealth",
          "leadership", "strategy", "strategic", "entrepreneur", "entrepreneurship", "startup", "capital", "wall street",
          "trading", "trade", "banking", "bank", "fund", "accounting", "account", "tax", "taxation", "negotiation",
          "selling", "sales", "branding", "brand", "advertising", "advertiser"],
    "O": ["mathematics", "math", "maths", "physics", "physical", "chemistry", "chemical", "algebra", "geometry",
          "calculus", "probability", "statistics", "quantum", "relativity", "thermodynamics"],
    "P": ["astronomy", "astronomical", "cosmos", "cosmology", "planet", "planets", "galaxy", "universe", "earth",
          "geology", "geological", "volcano", "earthquake", "ocean", "meteorology", "climate", "geography",
          "geographic", "fossil", "dinosaur", "space"],
    "Q": ["biology", "biological", "botany", "plant", "animals", "zoology", "microbiology", "genetics", "genome",
          "gene", "evolution", "ecology", "species", "insect", "bird", "mammal", "human body", "anatomy"],
    "R": ["health", "healthy", "medical", "medicine", "medicinal", "diet", "nutrition", "nutritional", "fitness",
          "yoga", "cancer", "disease", "diseases", "anatomy", "psychiatry", "wellness", "immune", "immunity",
          "vaccine", "vaccination", "physiology", "pathology", "herbal", "therapy", "healing"],
    "T": ["computer", "computing", "programming", "program", "python", "java", "javascript", "docker", "kubernetes", "linux", "unix", "android", "ios", "git", "software", "hardware",
          "engineering", "technology", "technological", "algorithm", "algorithms", "robot", "robotics", "database",
          "sql", "network", "internet", "web", "artificial intelligence", "machine learning", "neural", "coding",
          "code", "cloud", "blockchain", "embedded", "chip", "electronics", "circuit", "mechanical", "architecture",
          "construction", "energy", "industrial", "automation"],
    "U": ["transport", "transportation", "railway", "rail", "subway", "metro", "highway", "motorway", "locomotive",
          "automobile", "vehicle", "automotive", "shipping industry", "port", "logistics", "traffic"],
    "V": ["aviation", "aircraft", "airplane", "aerospace", "satellite", "spacecraft",
          "space station", "astronaut", "space exploration"],
    "X": ["environment", "environmental", "pollution", "climate change", "sustainability", "recycling", "waste",
          "carbon", "ecology protection", "disaster", "safety", "firefighting", "fire safety", "hazard"],
    "S": ["agriculture", "agricultural", "farming", "crop", "garden", "gardening", "horticulture", "flower", "livestock",
          "veterinary", "aquaculture", "fishery", "soil", "fertilizer"],
    "G": ["education", "educational", "teaching", "teacher", "learn", "learning", "study", "studying", "school",
          "college", "university", "exam", "sport", "sports", "fitness", "running", "basketball", "football",
          "chess", "game", "training", "culture"],
    "H": ["language", "languages", "grammar", "vocabulary", "dictionary", "dictionaries", "english", "chinese",
          "japanese", "french", "german", "spanish", "russian", "korean", "translation", "translating", "pronunciation",
          "phrase", "idiom", "writing"],
    "B": ["philosophy", "philosophical", "philosopher", "philosophers", "religion", "religious", "theology",
          "theological", "ethics", "ethical", "existential", "existentialism", "zen", "buddhism", "buddhist",
          "christian", "christianity", "islam", "islamic", "judaism", "taoism", "taoist", "confucius", "confucian",
          "kant", "nietzsche", "plato", "aristotle", "socrates", "hegel", "psychology", "psychological", "habit",
          "habits", "mindset", "success", "communication", "public speaking", "productivity", "memory", "thinking",
          "logic", "mind", "self-help", "self help", "spirituality", "spiritual", "meditation", "mindfulness"],
    "D": ["politics", "political", "politician", "law", "legal", "legislation", "constitution", "constitutional",
          "democracy", "democratic", "government", "governance", "diplomacy", "diplomatic", "geopolitics",
          "geopolitical", "foreign policy", "fascism", "fascist", "communism", "communist", "socialism", "socialist",
          "capitalism", "ideology", "ideological", "totalitarian", "societ", "war", "military", "army", "navy"],
    "E": ["military", "army", "navy", "warfare", "battle", "campaign", "strategy", "tactics", "weapon", "soldier",
          "general", "world war", "wwii", "wwi", "normandy", "pearl harbor", "spy", "intelligence", "war"],
    "J": ["artist", "artists", "artwork", "artworks", "art history", "music", "musical", "photography", "photographer", "design", "designing",
          "designer", "painting", "drawing", "sculpture", "film", "films", "cinema", "movie", "dance", "theater",
          "theatre", "opera", "calligraphy", "fashion", "museum", "illustration", "comic", "manga", "animation"],
    "K": ["history", "histories", "historical", "historian", "revolution", "empire", "dynasty", "century",
          "middle ages", "renaissance", "hitler", "napoleon", "roman", "ancient", "medieval", "civil war", "cold war",
          "crusade", "republic", "kingdom", "chronicle", "memoir", "memoirs", "biography", "biographies",
          "autobiography", "autobiographies", "reminiscence", "geography", "travel", "journey", "exploration"],
    "I": ["novel", "fiction", "story", "stories", "poetry", "poem", "poems", "essay", "essays", "literature",
          "literary", "fantasy", "science fiction", "sci-fi", "mystery", "thriller", "detective", "romance", "horror",
          "adventure", "fairy tale", "fairy tales", "folklore", "myth", "myths", "saga", "classic", "classics",
          "anthology", "collection", "tale", "tales", "drama", "play", "plays", "shakespeare", "hamlet"],
    "Z": ["encyclopedia", "encyclopedias", "dictionary of", "compendium", "handbook", "manual", "almanac",
          "yearbook", "directory", "anthology", "omnibus", "complete works", "reference", "reader's digest"],
}
en_compiled = {}
for letter, words in EN_MAP.items():
    en_compiled[letter] = re.compile(r"\b(" + "|".join(words) + r")\b", re.I)

def term_re(letter):
    return re.compile("(" + "|".join(re.escape(t) for t in CLASSES[letter]["keywords"]) + ")")

compiled = {l: term_re(l) for l in CLASSES}

# 经典章回小说（避免误入 K 传记）
CLASSIC_NOVEL_EXCLUDE = {"水浒传", "水浒全传", "说岳全传", "薛仁贵征东", "隋唐演义", "封神演义", "三侠五义",
                         "小五义", "续小五义", "七侠五义", "白眉大侠", "蜀山剑侠传", "济公全传", "施公案", "彭公案"}
# 以"辞典/词典/字典"命名的小说（归 I 文学）
FICTION_DICT_TITLES = {"哈扎尔辞典", "马桥词典", "玫瑰词典", "风语辞典"}

# 各规则的优先级（先具体后宽泛）
#
# 修复记录：原表漏了 C，导致 22 个中图法大类里唯独「C 社会科学总论」永远
# 不会被判定 —— clc_terms.json 为它准备了 29 个关键词（社会学/社会调查/
# 人口学/管理学/传播学…）、DDC 300，但 classify() 只遍历 PRIORITY，
# C 的正则从未执行。后果是 audit.csv 里 letter=='C' 恒为 0 行，
# 这批社科书被 I / D / 00_待分类 吞掉。
#
# 位置选择：C 是「总论」性质，按中图法应当让位于 D/E/F/G/H/J/K 等专类，
# 因此放在 I 之前、Z 之前 —— 只在没有更具体的类命中时才归 C，这样既修好
# 了漏判，又把对既有分类的扰动压到最小。
PRIORITY = ["A", "R", "E", "K", "D", "F", "T", "U", "V", "X", "O", "P", "N", "Q", "S", "G", "H", "B", "J", "C", "I", "Z"]

# 人物传记："XX——人名传"/"XX：人名传"/"(丛书)人名传"，人名2-4字，前面有分隔符或开头
PERSON_RE = re.compile(r"(?:^|[—\-_：:\s（(])([\u4e00-\u9fff·]{2,4})传(?=\s*(?:[（(][^（）()]*[)）]|\s*[-—–]|\s*$))")

def classify(path, rel, matched_out=None):
    """返回 CLC 字母；matched_out 可选收集命中词"""
    def hit(letter, base):
        m = compiled[letter].search(base)
        if m:
            if matched_out is not None:
                matched_out.append((letter, m.group(1)))
            return True
        return False

    # 1) 目录上下文
    if "全国各地地方志" in rel or "/地方志" in rel or "各地方志" in rel or "一统志" in rel or "方舆" in rel:
        return "K"
    if "故事会" in rel:
        return "I"
    if "世界史的故事" in rel:
        return "K"
    if "知乎" in rel:
        return "I"
    if "901中华传世藏书" in rel:
        if "/经部" in rel: return "B"
        if "/史部" in rel: return "K"
        if "/集部" in rel: return "I"
        if "/子部" in rel:
            base = path.rsplit("/", 1)[-1]
            if re.search(r"小说|话本|曲", base): return "I"
            if re.search(r"医|本草|药|伤寒|医案", base): return "R"
            if re.search(r"兵|战|阵", base): return "E"
            if re.search(r"农|桑|谷", base): return "S"
            if re.search(r"工|技|器|营造", base): return "T"
            if re.search(r"佛|释|禅", base): return "B"
            return "B"
    if "蔡澜" in rel:
        return "I"

    base = path.rsplit("/", 1)[-1]
    # 剥除"系列/丛书/套装/册数"类括注与 Kindle 哈希尾缀，避免干扰分类
    cbase = re.sub(r"[（(][^（）()]*(丛书|系列|套装|大家丛书|全\d+册|共\d+册|典藏版|珍藏版|插图本)[^（）()]*[)）]", "", base)
    cbase = re.sub(r"\.azw[_]?[A-Z0-9]{8,}$", "", cbase, flags=re.I)
    cbase = re.sub(r"[-_]\d{5,}$", "", cbase)
    stem_b = cbase.rsplit(".", 1)[0]

    # 系列兜底提示：理想国译丛（政治/社科非虚构为主，无内容词命中时归 D）
    series_hint = "D" if "理想国译丛" in rel else None

    # 2) 人物传记启发式（"XX——人名传"/"XX:人名传"，人名2-4字 -> K）
    if stem_b not in CLASSIC_NOVEL_EXCLUDE and not re.search(r"(正传|全传|外传|别传|后传|前传|大传|小传|新传|正傳|全傳)$", stem_b):
        m = PERSON_RE.search(stem_b)
        if m:
            if matched_out is not None:
                matched_out.append(("K", m.group(1) + "传"))
            return "K"

    # 3) 工具书分流（语言类词典 -> H，诗词文学类 -> I，其余 -> Z；小说型"辞典"书名除外）
    if re.search(r"(辞典|词典|字典)", stem_b):
        if any(t in stem_b for t in FICTION_DICT_TITLES):
            return "I"
        if re.search(r"(Excel|函数|编程|数据库|Word|PPT|Office)", stem_b):
            return "T"
        if re.search(r"(英语|汉语|日语|外语|韩语|法语|德语|俄语|西班牙语|成语|汉字|拼音|英和|和英|英英|日中|中日|英中|中英|英汉|汉英)", stem_b):
            return "H"
        if re.search(r"(诗|词|文学|小说|戏剧|散文|曲|古文|文言)", stem_b):
            return "I"
        return "Z"

    # 3.5) 小说强标记（三部曲/篇幅词）优先 -> I
    if re.search(r"(三部曲|四部曲|五部曲|六部曲|长篇小说|中篇小说|短篇小说|小说集|散文集|诗集|诗文集|词集)", stem_b):
        return "I"

    # 4) 中文关键词（按优先级）
    for letter in PRIORITY:
        if hit(letter, cbase):
            return letter
    # 5) 英文关键词
    eb = cbase.replace("_", " ")
    for letter, pat in en_compiled.items():
        if pat.search(eb):
            if matched_out is not None:
                matched_out.append((letter, "en"))
            return letter
    # 5.5) 系列兜底
    if series_hint:
        return series_hint
    # 6) 兜底：短纯中文标题或有文学特征 -> I；英文 -> I；否则 00 待分类
    clean_title = re.sub(r"[\d_\-—–·.、【】\[\]（）()《》<>【】\s，。！？；：、“”‘’…、〈〉「」『』]+", "", stem_b)
    if re.search(r"(著|作者|作品|文集|小说|故事|诗|词|录|篇|章|传)", stem_b):
        return "I"
    if re.search(r"[a-zA-Z]", stem_b):
        return "I"
    if re.match(r"^[\u4e00-\u9fff]{2,12}$", clean_title):
        return "I"
    return "00"

# ---------------- 命名（沿用已校验逻辑） ----------------
JUNK_IN = r"(公众号|书单严选|亚马逊|中亚|自购|kindle|Kindle|mebook|mobi|epub|azw3|通读|在线阅读|电子书|派派小说|天涯|转载|通俗说|tongsushuo|完整版|全本|精校|校对|最新|珍藏|标清|高清|扫描|彩色|文字版|\.com|\.cc|www\.|http|微盘|豆丁|道客巴巴|wenku)"
TRAILING_SITE = re.compile(
    r"[-－—–_ ]{0,3}(通读|在线阅读|电子书|派派小说|天涯社区|百度贴吧|豆丁|道客巴巴|"
    r"wenku|微盘|mebook\.cc|tongsushuo\.com|公众号[:：]?[^\-－—–_ ]{0,12}|书单严选|"
    r"亚马逊|中亚自购|精校版|完整版|最新版|珍藏版|全本|全集版)\s*$"
)

def norm_ws(s):
    s = s.replace("＿", "_").replace("—", "-").replace("–", "-").replace("－", "-")
    s = s.replace("．", ".").replace("〜", "~")
    s = re.sub(r"\s+", " ", s)
    return s.strip()

def clean_stem(base):
    stem = base
    if "." in base:
        stem = base.rsplit(".", 1)[0]
    stem = norm_ws(stem)
    stem = re.sub(r"\.(azw|mobi|epub|azw3)_[A-Z0-9]{8,}$", "", stem, flags=re.I)
    stem = re.sub(r"[-_]\d{5,}$", "", stem)
    stem = TRAILING_SITE.sub("", stem)
    stem = re.sub(r"【([^】]{0,60}?)】|\[([^\]]{0,60}?)\]|〔([^〕]{0,60}?)〕|\(([^)]{0,40})\)",
                  lambda m: "" if re.search(JUNK_IN, m.group(0)) else m.group(0), stem)
    stem = re.sub(r"^[\s\-—–_·.、]+|[\s\-—–_·.、]+$", "", stem)
    stem = re.sub(r"[\s\-—–_]{2,}", "-", stem)
    return stem

def extract_author(stem):
    author = None
    title = stem
    m = re.match(
        r"^[\[（(]([美英法德日俄意西印葡澳加荷瑞韩朝中东]|[秦汉唐宋元明清近现代当古]{1,2})[\]）)]\s*([^\-—–_]{1,18})\s*[-－—–]\s*(.+)$",
        stem)
    if m:
        author = m.group(2).strip()
        title = m.group(3).strip()
        if author:
            return title, author
    parts = re.split(r"\s*[-–]\s*", stem)
    if len(parts) >= 2 and len(parts[0]) >= 2:
        head = parts[0]
        tail = parts[-1]
        head_ok = (re.search(r"[\u4e00-\u9fff]", head)
                   and not re.search(r"(研究所|出版社|杂志社|报社|书局|书院|工作室|著|主编|编著|编译|译著|译者|编辑部|委员会|学校|大学|学院|公司|集团|传媒|网站|论坛|社区)$", head)
                   and not re.search(r"(届|期|卷|编|册|辑|号|集|篇|部|年|月|日|级|组|第)$", head))
        if re.match(r"^[\[\(［]([美英法德日俄意西印葡澳加荷瑞韩朝中东]+)[\]\)］]", tail):
            return " - ".join(parts[:-1]), tail
        if "·" in tail and 2 <= len(tail) <= 14 and not re.search(r"[（(]", tail):
            return " - ".join(parts[:-1]), tail
        if len(parts) == 2 and head_ok and re.match(r"^[\u4e00-\u9fff·]{2,4}$", tail) and len(head) >= 3:
            return head, tail
    m = re.match(r"^(.+?)-([秦汉唐宋元明清近现代当隋唐宋元明清]+)-(.+)$", stem)
    if m:
        return m.group(1), m.group(3)
    m = re.match(r"^(.+?)--$", stem)
    if m:
        return m.group(1), None
    if "_" in stem:
        parts = stem.split("_")
        if len(parts) == 2:
            tail = parts[-1]
            if re.match(r"^[\u4e00-\u9fff·]{2,6}$", tail) and len(parts[0]) >= 2:
                return parts[0], tail
    return title, author

def final_name(path):
    base = path.rsplit("/", 1)[-1]
    ext = ext_of(path)
    stem = clean_stem(base)
    title, author = extract_author(stem)
    title = title.strip(" -—–_·")
    if not title:
        title = stem
    if author:
        author = author.strip()
        author = re.sub(r"^[\[\(［][美英法德日俄意西印葡澳加荷瑞韩朝中东]+[\]\)］]", "", author)
        author = author.strip(" -—–_·")
    fn = (title + "_" + author + "." + ext) if author else (title + "." + ext)
    return fn, title, author

# ---------------- 主流程 ----------------
def main():
    books, archives, skipped, sftp_pending = [], [], [], []
    for f in FILES:
        p = f["path"]
        e = ext_of(p)
        if e in BOOK_EXT:
            try:
                p.encode("gbk")
                books.append(f)
            except UnicodeEncodeError:
                sftp_pending.append(f)
        elif e in ARCHIVE_EXT:
            archives.append(f)
        else:
            skipped.append((p, f["size"], e))

    cat_count = Counter()
    plans = []
    noauthor = []
    renamed = []
    audit_rows = []
    for f in books:
        p = f["path"]
        hits = []
        cat = classify(p, p, hits)
        cat_count[cat] += 1
        fn, title, author = final_name(p)
        base = p.rsplit("/", 1)[-1]
        cls = CLASSES.get(cat, {"name": "待分类", "ddc": "-"})
        audit_rows.append({
            "src": p, "title": title, "letter": cat,
            "class": cls["name"], "ddc": cls["ddc"],
            "hits": "|".join(f"{l}:{t}" for l, t in hits[:5]),
            "method": "context" if "各地方志" in p or "901" in p else ("keyword" if hits else ("en" if re.search(r"[a-zA-Z]", base.rsplit(".",1)[0]) else "fallback")),
        })
        plans.append({
            "src": p, "size": f["size"], "cat": cat, "cat_folder": CAT_FOLDERS[cat],
            "name": fn, "title": title, "author": author,
            "changed": fn != base, "orig": base, "via": "ftp",
        })
        if not author:
            noauthor.append((p, title, base))
        if fn != base:
            renamed.append((p, base, fn))

    seen = defaultdict(int)
    for pl in plans:
        key = (pl["cat"], pl["name"])
        if seen[key] > 0:
            e = pl["name"].rsplit(".", 1)
            pl["name"] = f"{e[0]}({seen[key]})" + ("." + e[1] if len(e) == 2 else "")
        seen[key] += 1
        pl["dest"] = f"{pl['cat_folder']}/{pl['name']}"

    print("books(direct):", len(books), "archives:", len(archives),
          "sftp_pending:", len(sftp_pending), "skipped:", len(skipped))
    print("\n-- CLC 分类分布 --")
    for c, n in cat_count.most_common():
        name = CLASSES.get(c, {"name": "待分类"})["name"]
        print(f"  {c} {name}: {n}")
    print("\n-- 各分类样本(每类4个) --")
    bycat = defaultdict(list)
    for pl in plans:
        bycat[pl["cat"]].append(pl)
    for c, items in sorted(bycat.items()):
        if len(items) < 4:
            continue
        print(f"[{c}] ", end="")
        for x in items[:4]:
            print(f"{x['orig'][:26]} | ", end="")
        print()

    out = {
        "categories": list(CAT_FOLDERS.values()),
        "cat_map": CAT_FOLDERS,
        "class_meta": {c["letter"]: {"name": c["name"], "ddc": c["ddc"]} for c in TERMS["classes"]},
        "plans": plans, "archives": archives, "skipped": skipped,
        "sftp_pending": sftp_pending,
        "noauthor": [{"src": s, "title": t, "orig": o} for s, t, o in noauthor],
        "stats": {"books": len(books), "archives": len(archives),
                  "skipped": len(skipped), "sftp_pending": len(sftp_pending),
                  "cat_count": dict(cat_count), "renamed": len(renamed),
                  "noauthor": len(noauthor)},
    }
    json.dump(out, open(W + "/state/plan.json", "w"), ensure_ascii=False)

    import csv
    with open(W + "/reports/audit.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(audit_rows[0].keys()))
        w.writeheader()
        for r in audit_rows:
            w.writerow(r)
    with open(W + "/reports/noauthor.csv", "w", encoding="utf-8") as fh:
        fh.write("源路径,清理后书名,原始文件名\n")
        for s, t, o in noauthor:
            fh.write(f"{s},{t},{o}\n")
    with open(W + "/reports/renamed.csv", "w", encoding="utf-8") as fh:
        fh.write("源文件名,新文件名\n")
        for p, o, n in renamed:
            fh.write(f"{o},{n}\n")
    print("\nsaved plan.json, audit.csv")

if __name__ == "__main__":
    main()
