# -*- coding: utf-8 -*-
"""书库文件去重：size 分组 → 全文件 MD5 → 找出字节级完全相同的文件。
只处理系统入库的书（owner_id IS NULL），不碰用户上传（owner_id 非空）。
保留规则：优先保留中文名，其次保留文件名文字（去扩展名字符数）最多。
生成报告，管理员确认后删除重复文件（删除 FTP 文件 + 库内行与关联记录）。
"""
import os, sys, json, time, threading, hashlib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "ebook_task"))
import config, db, ftp_service

_state = {"running": False, "phase": "", "progress": 0, "total": 0,
          "error": None, "report": None, "lock": threading.Lock()}
REPORT_FILE = os.path.join(config.DATA_DIR, "dedup_report.json")


def _set(**kw):
    with _state["lock"]:
        for k, v in kw.items():
            _state[k] = v


def status():
    with _state["lock"]:
        return {k: v for k, v in _state.items() if k != "lock"}


def _stem(name):
    """去扩展名"""
    return (name or "").rsplit(".", 1)[0]


def _is_chinese(s):
    return any('\u4e00' <= ch <= '\u9fff' for ch in (s or ""))


def _pick_keep(group):
    """从重复组中选保留项：优先中文名，其次文件名文字（去扩展名字符数）最多。
    group: [{id,path,name,size,md5}]"""
    chinese = [g for g in group if _is_chinese(g["name"])]
    pool = chinese if chinese else group
    return max(pool, key=lambda g: (len(_stem(g["name"])), -len(g["path"])))


def _md5_of(relpath):
    """下载远程文件到本地临时文件，流式计算 MD5，返回 hex 或 None"""
    tmp = os.path.join(config.CACHE_DIR, "md5_%d_%s_%s" % (
        os.getpid(), str(time.time_ns()), os.path.basename(relpath)))
    try:
        ftp_service.download_to(relpath, tmp)
        h = hashlib.md5()
        with open(tmp, "rb") as f:
            for chunk in iter(lambda: f.read(1 << 20), b""):
                h.update(chunk)
        return h.hexdigest()
    except Exception:
        return None
    finally:
        if os.path.exists(tmp):
            try:
                os.remove(tmp)
            except Exception:
                pass


def start_scan():
    """后台线程执行全库去重扫描；已在运行则直接返回 running=True"""
    with _state["lock"]:
        if _state["running"]:
            return {"running": True, "started": False}
        _state["running"] = True
        _state["phase"] = "scan"
        _state["progress"] = 0
        _state["total"] = 0
        _state["error"] = None
        _state["report"] = None
    threading.Thread(target=_worker, daemon=True, name="dedup-scan").start()
    return {"running": True, "started": True}


def _worker():
    try:
        # 1) 只取系统书（owner_id IS NULL）且 size>0；size=0 不可靠，不参与
        rows = db.q("SELECT id, path, size, title FROM books WHERE owner_id IS NULL AND size > 0")
        by_size = {}
        for r in rows:
            by_size.setdefault(r["size"], []).append(r)
        # 2) 只保留 size 出现 >=2 次的组（不同大小必非同文件）
        groups = [(s, v) for s, v in by_size.items() if len(v) >= 2]
        total_md5 = sum(len(v) for _, v in groups)
        _set(total=total_md5, phase="md5", progress=0)

        # 3) 并发算 MD5，按 (size, md5) 归类
        from concurrent.futures import ThreadPoolExecutor
        md5_map = {}
        lock = threading.Lock()

        def work(pair):
            _s, v = pair
            for b in v:
                md5 = _md5_of(b["path"])
                with lock:
                    if md5:
                        md5_map.setdefault((_s, md5), []).append(
                            {**b, "md5": md5, "name": b["path"].rsplit("/", 1)[-1]})
                    _state["progress"] += 1

        with ThreadPoolExecutor(max_workers=10) as ex:
            list(ex.map(work, groups))

        # 4) 找重复组：同一 (size, md5) 且 >=2 本
        dup_groups = [v for v in md5_map.values() if len(v) >= 2]
        report, dup_files = [], 0
        for g in dup_groups:
            keep = _pick_keep(g)
            items = []
            for b in g:
                items.append({
                    "id": b["id"], "title": b["title"], "path": b["path"],
                    "name": b["name"], "size": b["size"], "md5": b["md5"],
                    "chinese": _is_chinese(b["name"]),
                    "stem_len": len(_stem(b["name"])),
                    "keep": b["id"] == keep["id"],
                })
            items.sort(key=lambda x: 0 if x["keep"] else 1)
            report.append({"md5": keep["md5"], "size": keep["size"],
                           "count": len(g), "items": items})
            dup_files += len(g) - 1
        report.sort(key=lambda x: x["count"], reverse=True)
        summary = {"groups": len(dup_groups), "dup_files": dup_files,
                   "scanned": total_md5,
                   "generated": db.now()}
        _set(report=summary, phase="")
        with open(REPORT_FILE, "w", encoding="utf-8") as f:
            json.dump({"summary": summary, "groups": report}, f, ensure_ascii=False)
    except Exception as e:
        _set(error=str(e), phase="")
    finally:
        with _state["lock"]:
            _state["running"] = False


def report():
    """返回完整去重报告（含摘要与所有重复组）"""
    if os.path.exists(REPORT_FILE):
        try:
            with open(REPORT_FILE, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {"summary": None, "groups": []}


def _delete_book_rows(ids):
    if not ids:
        return
    for i in range(0, len(ids), 1000):
        chunk = ids[i:i + 1000]
        ph = ",".join("?" * len(chunk))
        c = db.get_conn()
        c.execute("DELETE FROM books WHERE id IN (%s)" % ph, chunk)
        for t in ("shelves", "progress", "shares", "book_grants"):
            try:
                c.execute("DELETE FROM %s WHERE book_id IN (%s)" % (t, ph), chunk)
            except Exception:
                pass
        c.commit()


def confirm_delete(ids):
    """删除指定重复文件：仅允许删除报告中的“可删除项”（keep=False）。
    先删 FTP 文件，文件删除成功才删库内行。返回统计。"""
    if not ids:
        return {"deleted": 0, "failed": 0, "ignored": 0}
    rep = report()
    del_ids = set()
    for g in rep.get("groups", []):
        for it in g["items"]:
            if not it.get("keep"):
                del_ids.add(it["id"])
    # 只处理报告里明确为可删除项、且存在于库中的 id
    ids = [int(i) for i in ids if int(i) in del_ids]
    # 查全部待删行
    rows = []
    for i in range(0, len(ids), 500):
        chunk = ids[i:i + 500]
        ph = ",".join("?" * len(chunk))
        rows += db.q("SELECT id, path FROM books WHERE id IN (%s)" % ph, chunk)
    deleted = failed = 0
    ok_ids = []
    lock = threading.Lock()
    from concurrent.futures import ThreadPoolExecutor

    def _del(r):
        if ftp_service.delete(r["path"]):
            return r["id"]
        return None

    with ThreadPoolExecutor(max_workers=12) as ex:
        for rid in ex.map(_del, rows):
            with lock:
                if rid is not None:
                    deleted += 1
                    ok_ids.append(rid)
                else:
                    failed += 1
    _delete_book_rows(ok_ids)
    return {"deleted": deleted, "failed": failed,
            "ignored": len(ids) - deleted - failed if ids else 0}
