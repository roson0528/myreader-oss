// 管理员删除用户（界面路径）：用户管理 → 编辑 → 删除，以及批量删除
// 复现原始报错场景：以前这里因为 book_grants 没有 user_id 列而 500，界面弹「请求失败」
const { chromium } = require('/srv/deepseek-harness/node_modules/.pnpm/playwright@1.61.1/node_modules/playwright');
const fs = require('fs'); const { execSync } = require('child_process');
// 多行 python 用临时文件跑（execSync 的 -c 双引号里 \n 不会被 bash 解释）
const py = (c) => {
  fs.writeFileSync('/tmp/_uidel_run.py', c);
  return execSync('cd /srv/myreader/book_manager && venv/bin/python /tmp/_uidel_run.py',
    { encoding: 'utf8' }).trim();
};
let pass = 0, fail = 0;
const check = (n, ok, e) => { console.log((ok ? '  ✅ ' : '  ❌ ') + n + (e ? '  ' + e : '')); ok ? pass++ : fail++; };

const TS = String(Date.now()).slice(-6);
const ADM = 'zzuia' + TS, U1 = 'zzuid1' + TS, U2 = 'zzuid2' + TS, U3 = 'zzuid3' + TS;

(async () => {
  console.log('=== 0. 造临时管理员与 3 个待删用户 ===');
  const setup = py(`
import sys, json; sys.path.insert(0,'.')
import db, auth
from datetime import datetime
def mk(un, role='user', g=5):
    return db.ex("INSERT INTO users (username,password_hash,role,quota,enabled,group_id,name,email,phone,created_at) "
                 "VALUES (?,?,?,?,?,?,?,?,?,?)",
                 (un, auth.hash_password('zztest'), role, 50, 1, g, un, un+'@local.test', '19900000000', db.now()))
a = mk('${ADM}', 'admin', 1)
ids = [mk('${U1}'), mk('${U2}'), mk('${U3}')]
# 给第一个用户造满各类数据，确保删除要走完 book_grants（原来炸的就是这里）
u = ids[0]
db.ex("INSERT INTO shelves (user_id,book_id,added_at) VALUES (?,?,?)", (u, 1, db.now()))
db.ex("INSERT INTO shelf_collections (user_id,name,created_at) VALUES (?,?,?)", (u,'夹子', db.now()))
db.ex("INSERT INTO user_leaves (user_id,balance,updated_at) VALUES (?,?,?)", (u, 5, db.now()))
db.ex("INSERT INTO leaf_gain (user_id,kind,leaves,created_at) VALUES (?,?,?,?)", (u,'signin',1,db.now()))
db.ex("INSERT INTO group_upgrades (user_id,to_group_id,cost,months,status,created_at) VALUES (?,?,?,?,?,?)", (u,4,100,1,'active',db.now()))
db.ex("INSERT INTO share_requests (book_id,requester_id,status,created_at) VALUES (?,?,?,?)", (1,u,'pending',db.now()))
db.ex("INSERT INTO book_grants (book_id,from_user_id,to_user_id,created_at) VALUES (?,?,?,?)", (u,u,ids[1],db.now()))
db.add_message(u,'界面删除测试','正文',kind='system')
adm_user = db.q("SELECT * FROM users WHERE id=?", (a,), one=True)
tok = auth.create_token(adm_user)
print(json.dumps({'adm':a,'ids':ids,'tok':tok,'user':{'id':adm_user['id'],'username':adm_user['username'],
      'name':adm_user['name'],'role':adm_user['role']}}))
`);
  const S = JSON.parse(setup);
  console.log('   管理员', S.adm, '| 待删', JSON.stringify(S.ids));

  const browser = await chromium.launch({ args: ['--no-sandbox'],
    executablePath: '/srv/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome' });
  const ctx = await browser.newContext({ ignoreHTTPSErrors: true, viewport: { width: 1400, height: 1000 },
    baseURL: 'https://127.0.0.1:9000' });
  await ctx.addInitScript(([t, u]) => { localStorage.setItem('bm_token', t); localStorage.setItem('bm_user', u); },
    [S.tok, JSON.stringify(S.user)]);
  const page = await ctx.newPage();
  const errs = []; page.on('pageerror', e => errs.push(e.message));
  const toasts = [];
  await page.exposeFunction('__note', (m) => toasts.push(m));
  page.on('dialog', async d => { await d.accept(); });

  try {
    await page.goto('/admin', { waitUntil: 'networkidle', timeout: 90000 });
    await page.waitForTimeout(3000);
    await page.evaluate(() => switchSec('users'));
    await page.waitForFunction(() => Array.isArray(users) && users.length > 0, null, { timeout: 40000 });
    await page.waitForTimeout(1200);
    // 记录每次 toast 文案
    await page.evaluate(() => { const t = document.getElementById('toast'); const o = toast; window.toast = (m) => { window.__note(String(m)); return o(m); }; });

    console.log();
    console.log('=== 1. 单删：用户管理 → 编辑 → 删除 ===');
    const found = await page.evaluate(n => {
      const tr = [...document.querySelectorAll('#user-list tbody tr')]
        .find(r => { const b = r.querySelector('td b'); return b && b.textContent.trim() === n; });
      if (!tr) return false;
      tr.querySelector('td:last-child button').click();
      return true;
    }, U1);
    check('在用户列表找到待删用户并点开编辑', found, U1);
    await page.waitForTimeout(1200);
    const modalTxt = await page.evaluate(() => (document.querySelector('.modal,.modal-box,#modal') || {}).innerText || '');
    check('编辑弹窗打开', /编辑/.test(modalTxt), modalTxt.replace(/\s+/g, ' ').slice(0, 60));
    const clicked = await page.evaluate(() => {
      const m = document.querySelector('.modal,.modal-box,#modal');
      const btn = m && [...m.querySelectorAll('button')].find(b => b.textContent.trim() === '删除');
      if (!btn) return false;
      btn.click(); return true;
    });
    check('弹窗里有删除按钮并点击', clicked);
    await page.waitForFunction(() => !document.querySelector('.modal,.modal-box,#modal'), null, { timeout: 20000 }).catch(() => { });
    await page.waitForTimeout(2500);
    const t1 = toasts.join(' | ');
    check('提示是「已删除」而不是「请求失败」', /已删除/.test(t1) && !/请求失败/.test(t1), t1 || '(无提示)');
    check('用户确实从库里删除了',
      py(`import sys;sys.path.insert(0,'.');import db;print(db.q("SELECT COUNT(*) n FROM users WHERE id=?",(${S.ids[0]},),one=True)['n'])`) === '0');
    const resid = JSON.parse(py(`
import sys,json; sys.path.insert(0,'.')
import db
u=${S.ids[0]}
print(json.dumps({t: db.q("SELECT COUNT(*) n FROM %s WHERE %s=?" % (t,c), (u,), one=True)['n']
  for t,c in [('shelves','user_id'),('shelf_collections','user_id'),('user_leaves','user_id'),
              ('leaf_gain','user_id'),('group_upgrades','user_id'),('book_grants','from_user_id'),
              ('book_grants','to_user_id'),('messages','to_id'),('share_requests','requester_id')]}))
`));
    check('各类私有数据全部清空', Object.values(resid).every(v => v === 0), JSON.stringify(resid));

    console.log();
    console.log('=== 2. 批量删除（勾选 + 批量删除按钮）===');
    await page.evaluate(() => loadUsers());
    await page.waitForTimeout(2000);
    const sel = await page.evaluate(([a, b]) => {
      let n = 0;
      for (const id of [a, b]) { if (typeof toggleUserSel === 'function') { toggleUserSel(id, true); n++; } }
      return n;
    }, [S.ids[1], S.ids[2]]);
    check('勾选两个用户', sel === 2, String(sel));
    await page.waitForTimeout(600);
    check('批量操作条出现', await page.evaluate(() =>
      getComputedStyle(document.getElementById('user-batch-bar')).display !== 'none'));
    toasts.length = 0;
    await page.evaluate(() => batchUsers('delete'));
    await page.waitForTimeout(3000);
    const t2 = toasts.join(' | ');
    check('批量删除提示正常', /已删除/.test(t2) && !/请求失败/.test(t2), t2 || '(无提示)');
    check('两个用户都已删除',
      py(`import sys;sys.path.insert(0,'.');import db;print(db.q("SELECT COUNT(*) n FROM users WHERE id IN (${S.ids[1]},${S.ids[2]})",one=True)['n'])`) === '0');
    check('列表里已看不到这两个用户', await page.evaluate(([a, b]) => {
      const names = [...document.querySelectorAll('#user-list tbody tr td b')].map(x => x.textContent.trim());
      return !names.includes(a) && !names.includes(b);
    }, [U2, U3]));

    console.log();
    console.log('=== 3. 删除不存在的用户给出中文提示（不再是无信息的「请求失败」）===');
    const r404 = await page.evaluate(async () => {
      try { await api('/api/admin/users/99999999', { method: 'DELETE' }); return 'ok'; }
      catch (e) { return e.message; }
    });
    check('返回可读的中文原因', /不存在/.test(r404), r404);
    check('无 JS 报错', errs.length === 0, errs.slice(0, 2).join(' | '));
  } catch (e) { console.error('FATAL', e.message); fail++; }
  finally {
    py(`import sys; sys.path.insert(0,'.')
import db
for u in db.q("SELECT id FROM users WHERE username LIKE 'zzui%'"):
    i = u['id']
    for t, c in (('shelves','user_id'),('shelf_collections','user_id'),('progress','user_id'),
                 ('settings','user_id'),('notes','user_id'),('shares','user_id'),('download_logs','user_id'),
                 ('reading_time','user_id'),('convert_logs','user_id'),('user_leaves','user_id'),
                 ('leaf_gain','user_id'),('leaf_spend','user_id'),('signin_log','user_id'),
                 ('group_upgrades','user_id'),('share_requests','requester_id'),('book_grants','from_user_id'),
                 ('book_grants','to_user_id'),('messages','to_id'),('messages','from_id'),
                 ('audit_logs','user_id'),('audit_logs','target_id')):
        db.ex("DELETE FROM %s WHERE %s=?" % (t, c), (i,))
    db.ex("DELETE FROM users WHERE id=?", (i,))
`);
    const left = py(`import sys;sys.path.insert(0,'.');import db;print(db.q("SELECT COUNT(*) n FROM users WHERE username LIKE 'zzui%'",one=True)['n'])`);
    console.log();
    console.log('  清理后临时账号残留:', left);
    console.log(`结果: ${pass} 通过 / ${fail} 失败`);
    await browser.close();
    process.exit(fail ? 1 : 0);
  }
})().catch(e => { console.error('FATAL', e); process.exit(1); });
