"""后台制作线程：任务队列 + 断点续传 + 暂停/取消 + 进度。

★ 只跑一个任务。合成本来就吃满 TTS 主机的并发（§14 里那条「并发 3 是
  折中」的结论），再多开任务只会让几台机器互相排队，总时长反而更长。

★ 不碰 tts 的 SynthQueue。那个队列的优先级是按「用户正在等听书」调的，
  批量制作挤进去会把在线听书拖慢 —— 制作慢一点没关系，听书不能受影响。

断点续传的两个粒度：
  · ab_seg   —— 每句已合成的 opus 落盘并记账，重启后不重合成（最贵的一步）
  · ab_file  —— 已上传 WebDAV 的文件不重传（网络跨机，也贵）
暂停/取消在「每句之间」检查，所以最长等一句的合成时间（2~6 秒）就生效。
"""
import json
import logging
import os
import shutil
import subprocess
import sys
import threading
import time
import traceback
from datetime import datetime, timedelta, timezone

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE)
sys.path.insert(0, os.path.join(BASE, "audiobook"))

import db  # noqa: E402
from audiobook import ai as A  # noqa: E402
from audiobook import book as B  # noqa: E402
from audiobook import mix as M  # noqa: E402
from audiobook import speech as S  # noqa: E402
from audiobook import store as ST  # noqa: E402

log = logging.getLogger("audiobook")

TMP_ROOT = os.path.join(BASE, "data", "audiobook", "tmp")

_ctrl = {}                 # job_id -> 'pause' | 'cancel'
_lock = threading.Lock()
_thread = None
_wake = threading.Event()

# 卡死看守：running 任务多久没有任何进展就认定「工作线程卡住了」。
# 正常一句 2~6 秒、一个文件连拼接带加 BGM 带上传也就几分钟，
# 30 分钟没动静基本不可能是正常干活。
STALL_MINUTES = 30
_STALL_MARK = "工作线程已"

# 自动恢复：卡死超过 AUTO_RESTART_MINUTES 就自动重启服务续跑。
# ★ 为什么敢自动重启：重启后 start() 会把 running 改回 queued，
#   ab_seg 里已合成的分句全在，接着跑不重来；单元是 Restart=always 且有
#   socket activation（端口不掉），重启代价就是当前这一句白做。
# ★ 冷却时间防止无限重启：连续卡死时最多每 2 小时重启一次，其余时间只报告。
AUTO_RESTART_MINUTES = 60
_RESTART_COOLDOWN = 2 * 3600
_SERVICE = "bookmgr.service"
_last_restart = 0.0

# 自动恢复的另外两种情形（与卡死重启并列）。
# ★ 有上限：线路长期不通、或者任务一跑就崩，硬撑没有意义，
#   到上限就停下来把原因留在任务详情里，等人来看。
LINE_PAUSE_MARK = "已暂停（线路异常"     # 暂停收尾写下的标记，人为暂停不会有
FAIL_GAP = 1800            # 秒：失败后隔多久再试
FAIL_MAX = 3               # 次：失败最多自动续跑几次
LINE_GAP = 1800            # 秒：线路异常暂停后隔多久再试
LINE_MAX = 20             # 次
_HEAL = {}                 # job_id -> [失败续跑次数, 线路续跑次数, 上次动作时间]


class Stop(Exception):
    """暂停/取消。由 run_job 内部抛出，走自己的收尾逻辑。"""


def _check(job_id):
    with _lock:
        c = _ctrl.get(job_id)
    if c == "cancel":
        raise Stop("cancel")
    if c == "pause":
        raise Stop("pause")
    # ★ 任务行已经不存在了（人在排队或制作途中点了删除）就必须停。
    #   否则工作线程会继续合成、继续写 ab_seg、继续往 WebDAV 传，
    #   而 ab_job 已经删了 —— 留下谁也删不掉的孤儿行和临时目录。
    #   实测就漏过 165 行 ab_seg 和 3 个 job* 临时目录。
    if ST.job_get(job_id) is None:
        raise Stop("gone")


def control(job_id, act):
    """外部控制入口。act ∈ pause/resume/cancel。"""
    with _lock:
        if act == "pause":
            _ctrl[job_id] = "pause"
        elif act == "cancel":
            _ctrl[job_id] = "cancel"
        else:
            _ctrl.pop(job_id, None)
    _wake.set()
    if act == "resume":
        # ★ 顺手清掉 error：上一次线路异常留下的原因如果一直挂着，
        #   下次**人为**暂停就会被误判成线路异常而被自动续跑。
        ST.job_set(job_id, status="queued", stage="已加入队列", error="")


def tmpdir_of(job_id):
    return os.path.join(TMP_ROOT, "job%d" % job_id)


def _cleanup(job_id):
    """清掉这个任务的全部临时文件。失败也不能让它把任务带崩。"""
    d = tmpdir_of(job_id)
    for _ in range(3):
        try:
            shutil.rmtree(d, ignore_errors=False)
            return
        except FileNotFoundError:
            return
        except Exception:
            time.sleep(0.5)
    try:
        shutil.rmtree(d, ignore_errors=True)
    except Exception:
        pass


def _pool(cfg, line):
    """这条线路的音色池（含性别），用于给角色分配音色。"""
    try:
        import tts
        for l in tts.line_info(cfg, force=False):
            if l["id"] == line:
                return l["voices"]
    except Exception:
        pass
    return []


def _analyze_chapter(job, ch):
    """对一章做角色分析。结果缓存在 ab_job.ai_chars 里，断点续跑不重复花钱。

    ★ 必须从**数据库重新读**任务的 ai_chars，不能用传进来的 job 快照：
      快照是 run_job 开头取的，之后每一章分析完都会写回 ai_chars，
      拿着旧快照会导致每章都把上一章的分析结果覆盖掉 ——
      结果是只有最后一章的角色被记住，而且同一个角色在不同章会被分配不同音色。
    """
    cfg_all = ST.cfg_all()
    fresh = ST.job_get(job["id"]) or job
    try:
        cache = json.loads(fresh["ai_chars"] or "{}") or {}
    except Exception:
        cache = {}

    # ★ 按**当前线路**校正音色，必须放在"这一章是否已分析过"的判断之前。
    #   放后面的话，已经分析过的章会直接 return 缓存，人换了线路之后那些
    #   属于旧线路的音色就永远留在那里 —— 合成时那台服务器上根本没有这个
    #   音色 id，必然 4xx。这个坑实测踩到过：换了线路，5 个角色全都还引用着
    #   旧线路的 pool_27 / pool_57。
    import tts
    cfg = tts.settings()
    pool = _pool(cfg, job["line"]) or []
    if pool:
        valid = set(v["voice"] for v in pool)
        voices0 = cache.get("voices") or {}
        stale = [n for n, x in voices0.items() if (x or {}).get("voice") not in valid]
        if stale:
            for n in stale:
                voices0.pop(n, None)
            cache["voices"] = voices0
            ST.job_set(job["id"], ai_chars=json.dumps(cache, ensure_ascii=False))

    chs_cache = cache.get("chapters") or {}
    key = str(ch["idx"])
    if key in chs_cache:
        return chs_cache[key], cache

    sents = S.split_sentences(ch["text"])
    if not sents:
        res = {"characters": [], "speakers": {}}
    else:
        try:
            res = A.analyze(sents, cfg_all)
        except Exception as e:
            # ★ AI 分析失败**不整本放弃**：退化成这一章全用旁白音色，把原因记在任务的
            #   error 里让人看得见。限额、服务商抖动都可能发生，
            #   因为分析挂了就不产出整本有声书，代价太大。
            note = "第 %d 章 AI 分析失败，已退化为旁白：%s" % (ch["idx"] + 1, e)
            # ★ 这里必须 dict(fresh)：job_get 返回的是 sqlite3.Row，它没有 .get()。
            #   以前写成 fresh.get("error")，结果 AI 一失败就在这个"兜底"分支里
            #   抛 AttributeError 把整个任务搞崩 —— 兜底分支自己崩掉是最坏的情况，
            #   因为设计本来是 AI 挂了也要把书做完。
            prev = dict(fresh).get("error") or ""
            ST.job_set(job["id"], error=(prev + "；" if prev else "") + note)
            res = {"characters": [], "speakers": {}}
    voices = cache.get("voices") or {}
    for name, info in A.assign_voices(res.get("characters") or [], pool, job["voice"]).items():
        voices.setdefault(name, info)
    chs_cache[key] = res
    cache["chapters"] = chs_cache
    cache["voices"] = voices
    ST.job_set(job["id"], ai_chars=json.dumps(cache, ensure_ascii=False))
    return res, cache


def _synth_file(job, f, chapters, tmpdir):
    """产出一个 MP3 文件（含其覆盖的所有章节），返回本地路径。"""
    cfg = None
    segs = {r["idx"]: r for r in ST.seg_of_file(job["id"], f["seq"])}
    seq_idx = 0
    ai_cache = None
    if job["ai_enabled"]:
        try:
            ai_cache = json.loads(job["ai_chars"] or "{}") or {}
        except Exception:
            ai_cache = {}

    total = 0
    # 本文件里「每一章的第一句」的句序号，用来在章与章之间插更长的停顿
    ch_start = set()
    skipped = []
    do_skip = bool(job["skip_front"])
    extra_kw = ST.cfg_get("skip_front_kw") or ""
    for ch in chapters[f["a"]:f["b"] + 1]:
        sents = S.split_sentences(ch["text"])
        # ★ 跳过版权页/目录：**句序号照占**（seq_idx 继续往前加），只是不合成、
        #   不入库、不参与拼接。这样文件分组和每一句的 idx 完全不变，
        #   断点续传的缓存不会因为"少跳了一章"而全部失效 ——
        #   一本 4 小时的书要是缓存失效就得从头再合成一遍。
        if do_skip and B.is_front_matter(ch["title"], ch["text"], extra_kw):
            # ★ 光"不再合成"不够：拼接是从 ab_seg 读的，上一轮跑出来的那些分句
            #   还在表里、缓存文件还在盘上，照样会被拼进成品 —— "跳过"就成了假跳过。
            #   所以这里连同旧记录和缓存文件一起清掉。
            lo, hi = seq_idx, seq_idx + len(sents) - 1
            for rel in ST.seg_del_range(job["id"], f["seq"], lo, hi):
                try:
                    os.remove(os.path.join(tmpdir, rel))
                except OSError:
                    pass
            seq_idx += len(sents)
            skipped.append(ch["title"])
            continue
        if sents:
            ch_start.add(seq_idx)
        # ★ 角色分析按章**按需**做（结果缓存在 ab_job.ai_chars，断点续跑不重复花钱）。
        #   原来是在任务开头把全书分析完再开始合成 —— 74 章的书要干等十几分钟
        #   才出第一个文件，中途取消还白花了分析的钱。现在做完一章就出一章的声音。
        chres, ai_cache = ({}, ai_cache)
        if job["ai_enabled"]:
            chres, ai_cache = _analyze_chapter(job, ch)
        for li, s in enumerate(sents):
            total += 1
            idx = seq_idx
            seq_idx += 1
            cached = segs.get(idx)
            cpath = os.path.join(tmpdir, cached["cache"]) if cached else ""
            # 断点续传：这一句已经在磁盘上。★ 还要看大小 —— 进程被杀在写文件中途
            # 会留下 0 字节/半截文件，只看「文件在不在」会把坏片段当成已完成，
            # 后面拼接（或混音）必炸。
            if cached and os.path.isfile(cpath) and os.path.getsize(cpath) >= 256:
                continue
            _check(job["id"])
            speaker = ""
            voice = job["voice"]
            if job["ai_enabled"]:
                # ★ 这里必须用**章内**序号 li 去查说话人，不能用文件内全局序号 idx。
                #   每 N 章一个文件（N>1）时，第 2 章起两者的偏移不同，
                #   用 idx 查会把整章的说话人全部张冠李戴。
                sp = chres.get("speakers") or {}
                speaker = sp.get(li) or sp.get(str(li)) or ""
                if speaker and speaker != "旁白":
                    voice = (ai_cache.get("voices") or {}).get(speaker, {}).get("voice") or job["voice"]
                else:
                    speaker = speaker or "旁白"
            # ★ 拿到的音频必须**先验证再落盘**。实测线路偶发返回 0 字节，
            #   原来照样写进缓存、接着 ffmpeg 打开即 EOF，整个任务在跑到一半时
            #   失败（这本书正是第 2 个文件第 56 句）；坏字节进了缓存更麻烦，
            #   重跑会一直复用它。所以「取流 → 落盘 → 转码」整段可重试。
            op = S.seg_path(tmpdir, idx, f["seq"])
            mp = S.seg_mp3_path(tmpdir, idx, f["seq"])
            for attempt in range(5):
                try:
                    opus, used = S.synth(s, voice, job["line"], cfg)
                except Exception as e:
                    # 单句失败不整章放弃：换旁白音色再试一次（角色音色可能是刚被后台停用的）
                    if voice != job["voice"]:
                        opus, used = S.synth(s, job["voice"], job["line"], cfg)
                        voice, speaker = job["voice"], ""
                    else:
                        raise RuntimeError("第 %d 句合成失败：%s" % (idx + 1, e))
                try:
                    if not S.ok_audio(opus):
                        raise RuntimeError("线路返回的音频不完整（%d 字节）" % len(opus or b""))
                    with open(op, "wb") as fp:
                        fp.write(opus)
                    M.to_mp3(op, mp)
                    break
                except Exception as e:
                    if attempt >= 4:
                        # ★ 不再把任务判死。线路抖动是暂时的（实测就一次 135 字节的
                        #   残音频，几秒后再问同一句完全正常），可一本书要跑几十小时，
                        #   判失败就得人工盯着从头续。改成「暂停」：线路恢复后点继续即可，
                        #   已合成的分句全在缓存里，一句都不会白跑。原因写进 error 字段，
                        #   任务详情里能看到。
                        ST.job_set(job["id"],
                                   error="第 %d 句音频不可用（线路连续返回残音频）：%s" % (idx + 1, e),
                                   stage="线路异常，已暂停（恢复后点「继续」即可）")
                        raise Stop("pause")
                    time.sleep(min(8.0, 1.0 * (2 ** attempt)))
            # opus 只是中转，转完就删 —— 不删的话每本书都会在临时目录里
            # 攒下几十 MB 再没人用的 opus（实测一本攒了 493 个、13MB）
            try:
                os.remove(op)
            except OSError:
                pass
            sec = M.duration(mp)
            rel = os.path.relpath(mp, tmpdir)
            ST.seg_put(job["id"], f["seq"], idx, voice, speaker, rel, sec)
            done = ST.seg_count(job["id"])
            ST.job_set(job["id"], done_segs=done, stage="第 %d 个文件 · 第 %d 句" % (f["seq"], idx + 1))
    # 拼接：句与句之间插静音，章与章之间插更长的静音。
    # ★ 原来是一段接一段零间隔直接拼，听着像连珠炮、中间没有喘气的地方。
    #   静音是**独立生成一次就复用**（按毫秒数命名），不是每句现生成。
    parts = []
    rows = ST.seg_of_file(job["id"], f["seq"])
    gap = max(0, int(job["gap_ms"] or 0)) / 1000.0
    cgap = max(0, int(job["chap_gap_ms"] if job["chap_gap_ms"] is not None else 0)) / 1000.0
    sil_cache = {}
    for r in rows:
        p = os.path.join(tmpdir, r["cache"])
        if not os.path.isfile(p):
            continue
        if parts:
            d = cgap if r["idx"] in ch_start else gap
            if d > 0.02:
                ms = int(round(d * 1000))
                sp = sil_cache.get(ms)
                if not sp:
                    sp = os.path.join(tmpdir, "sil_%05dms.mp3" % ms)
                    if not os.path.isfile(sp):
                        M.silent_mp3(sp, d)
                    sil_cache[ms] = sp
                parts.append(sp)
        parts.append(p)
    if not parts:
        # ★ 「整章都被跳过」不是错误，不该判整本书失败。
        #   实测：这本书（A14305. 魔戒三部曲）第 1 个文件正好覆盖「总目录」「目录」两章，
        #   两章都被 is_front_matter 正确判为版权页 → 一句都不合成 → parts 为空 →
        #   抛错 → 整个 225 章的任务在 48 秒内失败，而后面 223 章正文完好。
        #   （线路是好的：同一时刻真合成一句返回 24820 字节。）
        # ★ 这里**绝不能**为了「别产出空文件」去改分组 —— 分组一变，按
        #   (任务, 文件序号, 句序号) 存的断点续传缓存全部作废，一本几十小时的书就得重跑。
        #   所以返回 None（本文件不产出音频），由 run_job 标记为 skipped 后继续下一个文件。
        if skipped:
            return None
        raise RuntimeError("第 %d 个文件没有任何音频" % f["seq"])
    raw = os.path.join(tmpdir, "file%03d.mp3" % f["seq"])
    M.concat_mp3(parts, raw)
    if job["bgm"] and job["bgm"] != "[]":
        try:
            bgm = [x for x in json.loads(job["bgm"]) if x]
        except Exception:
            bgm = []
        if bgm:
            mixed = os.path.join(tmpdir, "file%03d.mix.mp3" % f["seq"])
            M.mix_bgm(raw, bgm, mixed, volume=job["bgm_volume"])
            raw = mixed
    if skipped:
        # 记下跳过了哪些章，前端要如实告诉人"这些内容不会被念"（不能静默吞掉）
        try:
            cur = json.loads((ST.job_get(job["id"]) or {})["skipped"] or "[]")
        except Exception:
            cur = []
        for t in skipped:
            if t not in cur:
                cur.append(t)
        ST.job_set(job["id"], skipped=json.dumps(cur, ensure_ascii=False))
    _tag_final(raw, job, f)
    return raw


def _creator_name(uid):
    """建任务的管理员昵称 —— 写进音频的「艺术家」。

    用户要的是**昵称**（admin → 示例），不是用户名；取不到就退回用户名，再退回「未知」。
    """
    try:
        r = db.q("SELECT name, username FROM users WHERE id=?", (int(uid or 0),), one=True)
    except Exception:
        r = None
    if not r:
        return "未知"
    return (r["name"] or "").strip() or (r["username"] or "").strip() or "未知"


def _tag_final(path, job, f):
    """给成品写 ID3 标签。

    艺术家 / 参与创作的艺术家 = 建任务的管理员昵称，专辑 = 电子书名，
    标题 = 文件名（序号-章节名）+ 书名，音轨号 = 序号/总数。

    ★ 标签写失败**绝不能**把任务搞失败：一本书要合成几小时，
      为了几个元数据把整本成品扔掉不值得，所以这里吞掉异常只打日志。
    """
    try:
        album = (job["title"] or "").strip()
        base = os.path.splitext(f["name"])[0]
        total = 0
        try:
            row = ST.job_get(job["id"])            # 取新的：total_files 是开跑后才写进去的
            total = int((row["total_files"] if row else 0) or 0)
        except Exception:
            total = 0
        M.tag_mp3(path,
                  title=(base + "-" + album) if album else base,
                  artist=_creator_name(job["created_by"]),
                  album=album, track=f["seq"], total=total)
    except Exception as e:
        print("写音频标签失败（不影响成品上传）：%s" % e)


def _plan(chs, job, skipf):
    """分文件。两种方式：

    * `chapters`（默认，老行为）：每 `chapters_per_file` 章一个文件。
      简单可预期，但章节本身短长不一，文件时长会差得比较开
      （实测《秋园》26.8～61.8 分钟，最大/最小 2.31）。
    * `balanced`：按**预估时长**做均衡划分（见 B.plan_balanced）。
      同样不切章，但文件之间均匀得多（同一本书 9 个文件、比值 1.43）。

    ★ 两种方式都只依赖**文本长度**，不依赖任何实测时长 —— 重跑必须算出
      完全相同的边界，否则断点续传的分句缓存会全部作废。
    """
    mode = "chapters"
    try:
        mode = job["split_mode"] or "chapters"
    except (KeyError, IndexError):
        pass
    if mode == "balanced":
        try:
            tgt = int(job["target_min"] or 40)
            cap = int(job["max_min"] or 60)
        except (KeyError, IndexError, TypeError, ValueError):
            tgt, cap = 40, 60
        return B.plan_balanced(chs, tgt, cap, skipf)
    return B.plan_files(chs, job["chapters_per_file"], skipf)


def _to_library(jid):
    """制作完成 → 自动加入「有声」页面（制作时勾了才做）。

    ★ 登记失败**不能**把任务判成失败：音频已经完整传上去了，
      索引建不出来是「有声」页面自己的事，后台点一次「重建索引」就能补。
      这里如果把异常抛出去，一个索引问题会让整个几小时的任务变成 failed。
    """
    try:
        job = ST.job_get(jid)
        if not job or not job["to_lib"]:
            return
        from audiobook import library as L
        lib_id, info = L.register(jid, cat_id=job["lib_cat"] or 0,
                                  created_by=job["created_by"])
        log.info("有声书 #%s 已加入有声电子书页面：lib=%s，%s 章 / %.2f 小时",
                 jid, lib_id, info["chapters"], info["seconds"] / 3600.0)
    except Exception:
        import traceback
        traceback.print_exc()


def run_job(job):
    jid = job["id"]
    tmpdir = tmpdir_of(jid)
    os.makedirs(tmpdir, exist_ok=True)
    # ★ 同时清 finished_at：任务被「重新开始/重做第 N 个文件」重新排队时会再进这里，
    #   不清的话一个正在跑的任务会带着上次跑完的时间戳，从库上根本看不出它还在动。
    ST.job_set(jid, status="running", stage="解析电子书", error="", finished_at="")
    try:
        b = db.q("SELECT * FROM books WHERE id=?", (job["book_id"],), one=True)
        if not b:
            raise RuntimeError("书不存在（book_id=%s）" % job["book_id"])
        chs = B.chapters(b)
        # 跳过版权页/目录这类非正文（可在后台关掉）。这里只用来给文件起名，
        # 真正的跳过发生在 _synth_file 里 —— 分组和句序号保持完全不变，
        # 否则断点续传的缓存会全部失效。
        extra_kw = ST.cfg_get("skip_front_kw") or ""
        skipf = B.front_matcher(extra_kw) if job["skip_front"] else None
        # 只做指定章节（1 起、含两端；0/0 = 整本）。
        # ★ 选章节只影响「做哪些文件」，不动章节下标 f["a"]/f["b"] ——
        #   _synth_file 是按完整章节列表下标取正文的，所以下面给它传的仍是 chs。
        try:
            fr, to = int(job["chap_from"] or 0), int(job["chap_to"] or 0)
        except (KeyError, IndexError, TypeError, ValueError):
            fr = to = 0
        sel = chs
        if fr or to:
            fr = max(1, fr or 1)
            to = min(len(chs), to or len(chs))
            if to < fr:
                raise RuntimeError("章节范围不合法：第 %d 到第 %d 章（共 %d 章）" % (fr, to, len(chs)))
            sel = [c for c in chs if fr <= c["idx"] + 1 <= to]
            if not sel:
                raise RuntimeError("第 %d-%d 章没有正文" % (fr, to))
        files = _plan(sel, job, skipf)
        if sel is not chs:
            # 名字里的序号改成「这一章在完整目录里的序号」：只做第 3 章就该叫
            # 003-xxx.mp3，而不是 001-xxx.mp3 —— 后者会和整本任务的文件同名，
            # 传到同一个目录里就把别人的成品覆盖了。
            for f in files:
                tail = f["name"].split("-", 1)[1] if "-" in f["name"] else f["name"]
                f["name"] = "%03d-%s" % (f["a"] + 1, tail)
        ST.file_reset(jid, files)
        ST.job_set(jid, total_chapters=len(sel), total_files=len(files),
                   stage=("共 %d 章 / %d 个文件" % (len(sel), len(files)) if sel is chs
                          else "第 %d-%d 章 / %d 个文件" % (fr, to, len(files))))

        import dav
        root = (ST.cfg_get("webdav_root") or "/music").rstrip("/")
        dest = (job["dest"] or "").strip() or (root + "/" + B._safe(job["title"]))
        ST.job_set(jid, dest=dest)

        # 真正产出过音频的文件数：断点续跑时之前已上传的也要算进来，
        # 全部跑完后用它兜底判断「这本书是不是一个音都没产出来」。
        produced = sum(1 for x in ST.files_of(jid) if x["status"] == "uploaded")
        # ★ done_files 的语义是「最后一个完成的文件序号」，界面拿它算百分比。
        #   断点续跑时，之前已传完的文件在本轮会走到下面的 uploaded 分支直接
        #   continue —— 原来那里不碰 done_files，于是跑第二遍时进度会**退回去**：
        #   本轮只新处理了 seq 1（被判目录跳过）→ done_files=1，
        #   而 seq 2..43 早就传完了，界面就一直显示 1/113。
        #   实测 #999906 就是这样：真实进度 43/113，界面显示 1%。
        #   所以这里先把已有进度读进来，补写时只增不减。
        _prog = int(job["done_files"] or 0)

        for f in ST.files_of(jid):
            _check(jid)
            if f["status"] == "uploaded":
                produced += 1
                if f["seq"] > _prog:
                    _prog = f["seq"]
                    ST.job_set(jid, done_files=_prog)
                continue
            ST.file_set(jid, f["seq"], status="running", err="")
            t0 = time.time()
            local = _synth_file(dict(job, **{"id": jid}), f, chs, tmpdir)
            if local is None:
                # 整个文件覆盖的章节都是版权页/目录，跳过之后没有音频可产出。
                # 不产出、不上传，但**必须把进度推过去**：done_files 存的是
                # 「最后一个完成的文件序号」，不推的话界面停在原地，任务也走不完。
                ST.file_set(jid, f["seq"], status="skipped", bytes=0, seconds=0,
                            err="整章均为版权页/目录，已跳过")
                if f["seq"] > _prog:
                    _prog = f["seq"]
                ST.job_set(jid, done_files=_prog,
                           stage="跳过 %s（整章为版权页/目录）" % f["name"])
                continue
            sec = M.duration(local)
            ST.job_set(jid, stage="上传 %s" % f["name"])
            remote = dest + "/" + f["name"]
            # ★ 走自带的 dav.put：它会回查远端确认，拿不到确认就抛异常。
            #   绝不用 ftp_service.upload_file —— 它失败时静默回退 FTP 并返回本地大小，
            #   调用方会以为传成功了（实测踩过：文件根本没上去）。
            size = dav.put(local, remote)
            # 每传完一个就删本地 —— 一本 10 小时的书全程 MPC 也就几百 MB，
            # 不留着能保证临时目录不会撑爆磁盘
            try:
                os.remove(local)
            except OSError:
                pass
            ST.file_set(jid, f["seq"], status="uploaded", remote=remote,
                        bytes=size, seconds=sec)
            produced += 1
            _prog = max(_prog, f["seq"])
            ST.job_set(jid, done_files=_prog,
                       stage="已上传 %s（%.1f 分钟）" % (f["name"], (time.time() - t0) / 60))
            for r in ST.seg_of_file(jid, f["seq"]):
                try:
                    os.remove(os.path.join(tmpdir, r["cache"]))
                except OSError:
                    pass
        if not produced:
            # 一个文件都没产出音频（整本书的章节都被判成版权页/目录）。
            # 这种情况必须报错，不能静默地「成功」出一个空目录。
            raise RuntimeError("整本书的章节都被判定为版权页/目录，没有可合成的内容")
        ST.job_set(jid, status="done", stage="全部完成", finished_at=db.now())
        _to_library(jid)
    except Stop as st:
        if str(st) == "gone":
            # 任务已经被删了：不要再写状态（写了也没用），把竞态里刚写进去的
            # 那批 ab_seg 再补删一次。
            ST.job_del(jid)
        elif str(st) == "cancel":
            ST.job_set(jid, status="canceled", stage="已取消")
        else:
            # ★ 这里必须区分两种暂停：**线路异常**导致的暂停（error 里有原因）和
            #   **人为**暂停。原来一律写「已暂停」，把上面 L295 写的
            #   「线路异常，已暂停」覆盖掉了 —— 从库上就分不出是哪一种，
            #   监督/运维也就没法安全地自动续跑（不敢动，怕把人为暂停也续上）。
            #   实测就卡在这个区分上：任务被线路抖动暂停后会一直躺着等人发现。
            try:
                _err = ST.job_get(jid)["error"] or ""
            except Exception:
                _err = ""
            ST.job_set(jid, status="paused",
                       stage="已暂停（线路异常，等待自动续跑）" if _err else "已暂停")
    except Exception as e:
        ST.job_set(jid, status="failed", stage="失败", error="%s" % e,
                   finished_at=db.now())
        traceback.print_exc()
    finally:
        # ★ 这里必须先取行再判空。原来写的是 ST.job_get(jid)["status"]，
        #   任务被删掉时 job_get 返回 None，None["status"] 抛 TypeError ——
        #   异常从 finally 里抛出去被 _loop 吞掉，**临时目录永远清不掉**。
        _r = ST.job_get(jid)
        if not _r or _r["status"] in ("done", "canceled"):
            # ★ 失败**不**清临时目录：失败恰恰是最想「修好接着跑」的情况，
            #   而 ab_seg 里已合成的分句缓存就存在这个目录里。原来失败即清，
            #   一本几十小时的书跑到一半失败一次，续跑就得从零重新合成。
            #   磁盘由 _sweep_orphans（任务被删时）和 done/canceled 负责回收。
            _cleanup(jid)


# 正在跑的任务：job_id -> Thread。★ 同一时刻可以有好几个 ——
# 每本书都绑在**自己的线路**上（ab_job.line），所以两台 TTS 机器可以各做一本，
# 互不排队。以前这里是「一次一个」，理由是「串行比并行快」，那只在
# 「所有任务抢同一台机器」时才成立；线路是分开的就不成立，白白让机器闲着。
_running = {}
_run_lock = threading.Lock()


def _max_concurrent():
    """同时跑几个任务。配置坏了就退回 1（老行为），绝不让它把调度搞崩。"""
    try:
        n = int(str(ST.cfg_get("max_concurrent") or "1").strip())
    except Exception:
        n = 1
    return max(1, min(8, n))


def _run_one(job):
    """一个任务的线程体：跑完（无论成败）把自己从在跑表里摘掉。"""
    jid = job["id"]
    try:
        run_job(job)
    except Exception:
        traceback.print_exc()
        log.error("有声书任务 #%s 工作线程异常退出", jid)
    finally:
        with _run_lock:
            _running.pop(jid, None)
        _wake.set()          # 让调度线程立刻再来看一眼有没有空位


def running_jobs():
    with _run_lock:
        return sorted(_running)


def _tick():
    """调度一轮：回收已结束的线程，再按并发上限取新任务。

    返回本轮启动的任务 id 列表。★ 单独抽出来是为了能**不开线程、不碰库**
    地单测调度逻辑（并发上限、不重复取同一个任务）—— 以前这段埋在
    `while True` 里，只能靠观察线上行为，回归测不了。
    """
    with _lock:
        _ctrl.pop(0, None)
    with _run_lock:
        for jid in [k for k, t in _running.items() if not t.is_alive()]:
            _running.pop(jid, None)
        room = _max_concurrent() - len(_running)
    started = []
    while room > 0:
        job = ST.job_next_queued()
        if not job:
            break
        # ★ 必须**在这里**就把状态占成 running：调度线程不等人，
        #   否则下一轮 job_next_queued() 会把这个还没被线程改状态的任务再取一次，
        #   同一本书被两个线程同时制作（会互相覆盖缓存与上传）。
        ST.job_set(job["id"], status="running", stage="已开始")
        t = threading.Thread(target=_run_one, args=(job,), daemon=True,
                             name="audiobook-job%d" % job["id"])
        with _run_lock:
            _running[job["id"]] = t
        t.start()
        started.append(job["id"])
        room -= 1
    return started


def _loop():
    while True:
        try:
            if not _tick():
                _wake.wait(timeout=3)
                _wake.clear()
        except Exception:
            traceback.print_exc()
            time.sleep(3)


def _bj_now():
    """库里的时间戳是北京时间（见 store.now），比时间必须用同一口径。

    ★ 这里必须返回**不带时区**的时间：库里的 updated_at 是拼出来的字符串，
      strptime 解出来是 naive 的，拿带时区的去比会直接 TypeError。
      （这不是设想，是单测当场抓出来的。）
    """
    return datetime.now(timezone.utc).replace(tzinfo=None) + timedelta(hours=8)


def stall_check(now=None, minutes=None):
    """running 任务长时间没有任何进展 → 把事实写到 ab_job.error 上。

    ★ 为什么必须另开一个线程做这件事：卡住的正是**工作线程自己**，
      它没法给自己当看守。实测 #41 就是这样 —— 线程卡在一把锁上，
      任务状态一直显示 running、error 字段是空的，十几个小时里看起来
      就像「自己停了」。同时整个进程还是好的（网页、在线听书都正常），
      所以从外面完全看不出异常。

    ★ 只报告，不动手：自动重启服务会掐断正在听书的用户。这里只把事实
      写进任务详情（后台任务列表能看到）+ 记一条 ERROR 日志。
      恢复动作是重启服务 —— 重启时 start() 会把 running 改回 queued，
      已合成的分句都在 ab_seg 里，接着跑不会重来。

    ★ 判「有没有进展」用**真实进度计数**（done_segs/done_files），
      不能用 updated_at —— job_set 每次都会把 updated_at 刷成当前时间，
      拿它比会导致「标记卡死 → 下次一看时间很新 → 清除 → 再标记」来回横跳。
      （这两个坑都是单测当场抓出来的。）
    """
    minutes = STALL_MINUTES if minutes is None else minutes
    now = now or _bj_now()
    live = set()
    for r in ST.job_list(limit=500, status="running"):
        jid = r["id"]
        live.add(jid)
        sig = (r["done_segs"], r["done_files"])       # 进度签名：只有真干活才会变
        old = _seen.get(jid)
        if old is None or old[0] != sig:
            _seen[jid] = (sig, now)                   # 有进展（或第一次见）：重新计时
            if (r["error"] or "").startswith(_STALL_MARK):
                ST.job_set(jid, error="")             # 又在动了，撤掉看守留下的提示
            continue
        idle = int((now - old[1]).total_seconds() // 60)
        if idle >= minutes:
            msg = ("%s %d 分钟没有任何进展（工作线程疑似卡住）。"
                   "重启服务即可从已合成的缓存接着跑。" % (_STALL_MARK, idle))
            if (r["error"] or "") != msg:
                ST.job_set(jid, error=msg)
                log.error("有声书任务 #%s 疑似卡死：%s（停在 %s）", jid, msg, r["stage"])
            if idle >= AUTO_RESTART_MINUTES:
                auto_restart(jid, idle)
    for k in list(_seen):                             # 不再 running 的任务别留着占内存
        if k not in live:
            _seen.pop(k, None)


def auto_restart(job_id, idle_minutes):
    """卡死过久 → 重启服务，让任务从缓存续跑。返回是否真的发起了重启。

    ★ 必须 --no-block：绝不能在**这个进程里**等 systemd 把自己关掉 ——
      systemd 在等我们退出、我们在等 systemctl 返回，会死等。
      --no-block 立刻返回，重启由 systemd 异步做。
    ★ 万一 systemctl 不可用：单元是 Restart=always（RestartSec=5），
      直接退出进程，5 秒后 systemd 会把它拉起来，效果一样。
    ★ 冷却期内不重启，只把「本小时已重启过」写进任务详情，避免无限重启。
    """
    global _last_restart
    now = time.time()
    if now - _last_restart < _RESTART_COOLDOWN:
        ST.job_set(job_id, error="%s %d 分钟没有任何进展（工作线程疑似卡住）。"
                                 "冷却期内暂不自动重启，稍后会再试。" % (_STALL_MARK, idle_minutes))
        return False
    _last_restart = now
    log.error("有声书任务 #%s 已卡死 %d 分钟，自动重启服务续跑", job_id, idle_minutes)
    env = dict(os.environ)
    env.setdefault("XDG_RUNTIME_DIR", "/run/user/%d" % os.getuid())
    try:
        subprocess.run(["systemctl", "--user", "restart", "--no-block", _SERVICE],
                       env=env, timeout=20, check=False)
        return True
    except Exception:
        traceback.print_exc()
        log.error("systemctl 调用失败，直接退出进程等 systemd 拉起（Restart=always）")
        os._exit(1)


_seen = {}      # job_id -> (进度签名, 首次见到该签名的时间)
def recover_check(now=None):
    """失败 / 线路异常暂停的任务自动续跑。

    ★ 为什么放在应用里而不是只靠外部脚本：外部脚本随会话结束就没了，
      应用是 systemd 托管的，能一直活着。两条恢复路径都以 ab_seg 缓存
      为底，续跑不会重合成已完成的句子。
    ★ 与 stall_check 分开：stall_check 只读不写（好单测），
      这里会写状态，所以单独一个函数、单独测。
    """
    now = now or _bj_now()
    ts = now.timestamp()
    for r in ST.job_list(limit=500):
        jid, st, stage, err = r["id"], r["status"], (r["stage"] or ""), (r["error"] or "")
        if st not in ("failed", "paused"):
            continue
        h = _HEAL.setdefault(jid, [0, 0, 0.0])
        if st == "failed":
            if h[0] >= FAIL_MAX:
                continue
            if ts - h[2] < FAIL_GAP:
                continue
            h[0] += 1
            h[2] = ts
            log.error("有声书任务 #%s 失败，自动续跑（第 %d 次）：%s", jid, h[0], err[:120])
            ST.job_set(jid, status="queued", stage="失败自动续跑（第 %d 次）" % h[0], error="")
        else:
            # ★ 只认 worker 自己写下的标记。人为暂停的 stage 就是「已暂停」，
            #   绝不能自动恢复 —— 那是在跟人对着干。
            if not stage.startswith(LINE_PAUSE_MARK):
                continue
            if h[1] >= LINE_MAX:
                continue
            if ts - h[2] < LINE_GAP:
                continue
            h[1] += 1
            h[2] = ts
            log.error("有声书任务 #%s 因线路异常暂停，自动续跑（第 %d 次）：%s", jid, h[1], err[:120])
            ST.job_set(jid, status="queued", stage="线路异常自动续跑（第 %d 次）" % h[1], error="")
    # ★ 只在任务真正结束/被删时才清计数。不能写「不在失败/暂停态就清」——
    #   续跑后任务正好变成 queued，计数会被当场抹掉，上限永远累加不起来，
    #   于是一个总是失败的任务会被无限每 30 分钟重试一次。
    #   （这是单测当场抓出来的。）
    for k in list(_HEAL):
        row = ST.job_get(k)
        if not row or row["status"] in ("done", "canceled"):
            _HEAL.pop(k, None)


_watchdog = None


def _watchdog_loop():
    while True:
        try:
            stall_check()
            recover_check()
        except Exception:
            traceback.print_exc()
        time.sleep(60)


def start():
    global _thread, _watchdog
    if _thread and _thread.is_alive():
        return
    ST.init()
    # 上次进程退出时正在跑的任务：状态留在 running，重启后没人管它了 —— 改回 queued
    # 让它接着跑。ab_seg / ab_file 里的进度都在，不会从头再来。
    for r in ST.job_list(limit=500, status="running"):
        ST.job_set(r["id"], status="queued", stage="服务重启，接着跑")
    _sweep_orphans()
    _thread = threading.Thread(target=_loop, daemon=True, name="audiobook-worker")
    _thread.start()
    if not (_watchdog and _watchdog.is_alive()):
        _watchdog = threading.Thread(target=_watchdog_loop, daemon=True, name="audiobook-stall")
        _watchdog.start()


def _sweep_orphans():
    """开机清一次孤儿：ab_job 里已经不存在的 ab_seg/ab_file 行，以及没人认领的临时目录。

    这些是"合成中途删任务"竞态的历史遗留（守卫加上之后不再产生新的，
    但老的可能还在），不清就会一直占着数据库和磁盘。
    """
    try:
        live = set(r["id"] for r in ST.job_list(limit=100000))
        db.ex("DELETE FROM ab_seg WHERE job_id NOT IN (SELECT id FROM ab_job)")
        db.ex("DELETE FROM ab_file WHERE job_id NOT IN (SELECT id FROM ab_job)")
        root = TMP_ROOT
        if os.path.isdir(root):
            for d in os.listdir(root):
                jid = None
                if d.startswith("job") and d[3:].isdigit():
                    jid = int(d[3:])
                if jid is None or jid not in live:
                    shutil.rmtree(os.path.join(root, d), ignore_errors=True)
    except Exception:
        traceback.print_exc()


def status():
    return {"alive": bool(_thread and _thread.is_alive()),
            "paused": [k for k, v in _ctrl.items() if v == "pause"],
            "running": running_jobs(),
            "max_concurrent": _max_concurrent()}
