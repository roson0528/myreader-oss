// 后台「封面刮削接入资源」新增「电子书内图片」类型（§14.95）——界面部分
//
// 只读检查，不改任何配置：确认①「添加资源」对话框的类型下拉里有「电子书内图片」
// 且 value=ebook；②选中它时出现说明文字（站长不会以为它坏了）；
// ③列表里能看到这条资源（由 GET /api/admin/sources 预置，需要重启后生效）；
// ④全程没有 JS 报错。
//
// 跑法：NODE_PATH=/tmp/pwtest/node_modules node tests/test_cover_source_ui.js
const { chromium } = require('playwright-core');
const { execSync } = require('child_process');

const CHROME = '/srv/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome';
const ROOT = '/srv/myreader/book_manager';
const BASE = 'https://127.0.0.1:9000';

let pass = 0, fail = 0;
const ck = (name, ok, extra) => {
  if (ok) { pass++; console.log('  ✓ ' + name); }
  else { fail++; console.log('  ✗ ' + name + (extra !== undefined ? '  → ' + JSON.stringify(extra) : '')); }
};

const info = JSON.parse(execSync('venv/bin/python -', {
  cwd: ROOT, encoding: 'utf8', input: `
import sys, json
sys.path.insert(0, '${ROOT}')
import db, auth
u = db.q("SELECT * FROM users WHERE role='admin' AND enabled=1 ORDER BY id LIMIT 1", one=True)
print(json.dumps({"token": auth.create_token(u), "user": dict(u)}))
`}).trim());

(async () => {
  const browser = await chromium.launch({ executablePath: CHROME, args: ['--no-sandbox'] });
  const ctx = await browser.newContext({ ignoreHTTPSErrors: true, viewport: { width: 1440, height: 1200 } });
  await ctx.setExtraHTTPHeaders({ 'Cache-Control': 'no-cache' });
  await ctx.addInitScript(([t, u]) => {
    localStorage.setItem('bm_token', t); localStorage.setItem('bm_user', u);
  }, [info.token, JSON.stringify(info.user)]);
  const p = await ctx.newPage();
  const errs = [];
  p.on('pageerror', e => errs.push(String(e.message)));
  p.on('console', m => { if (m.type() === 'error') errs.push('console: ' + m.text()); });

  console.log('\nA. 「添加资源」对话框');
  await p.goto(BASE + '/admin', { waitUntil: 'domcontentloaded' });
  await p.waitForTimeout(2600);

  // 找「封面刮削接入资源」那张卡（按标题定位，不靠固定下标）
  const cardFound = await p.evaluate(() => {
    const h = Array.from(document.querySelectorAll('#app .card h3')).find(x => x.textContent.includes('封面刮削接入资源'));
    window.__srcCard = h ? h.closest('.card') : null;
    return !!window.__srcCard;
  });
  ck('A1 后台有「封面刮削接入资源」板块', cardFound);
  if (!cardFound) { await browser.close(); console.log(`\n通过 ${pass} / 失败 ${fail}`); process.exit(1); }

  await p.evaluate(() => window.__srcCard.querySelector('button').click() || window.showAddSource && window.showAddSource());
  await p.waitForTimeout(400);
  // 有的版本是卡片里第一个按钮就是「添加资源」；没有就显式调函数
  let hasSel = await p.evaluate(() => !!document.getElementById('so-type'));
  if (!hasSel) { await p.evaluate(() => showAddSource()); await p.waitForTimeout(400); hasSel = await p.evaluate(() => !!document.getElementById('so-type')); }
  ck('A2 添加资源对话框打开（有类型下拉）', hasSel);

  const opts = await p.evaluate(() => Array.from(document.querySelectorAll('#so-type option'))
    .map(o => ({ v: o.value, t: o.textContent.trim() })));
  const ebook = opts.find(o => o.v === 'ebook');
  ck('A3 类型下拉里有 value=ebook', !!ebook, opts);
  ck('A4 它的显示名是「电子书内图片」', !!ebook && ebook.t === '电子书内图片', ebook);
  ck('A5 原有的 4 个在线源都还在', ['douban', 'bing', 'google', 'openlibrary'].every(t => opts.some(o => o.v === t)), opts.map(o => o.v));

  // 选中 ebook → 出现说明
  await p.selectOption('#so-type', 'ebook');
  await p.waitForTimeout(300);
  const hint = await p.evaluate(() => {
    const h = document.getElementById('so-hint');
    return h ? h.textContent.trim() : '';
  });
  ck('A6 选中后显示它是从文件里取图（epub/pdf/漫画/mobi）',
    hint.includes('epub') && (hint.includes('pdf') || hint.includes('第 1 页')) && hint.length > 30, hint);
  ck('A7 说明里点明没有图片的格式会顺延', hint.includes('顺延'), hint);
  await p.keyboard.press('Escape');
  await p.evaluate(() => { const b = document.querySelector('.modal .close'); if (b) b.click(); });
  await p.waitForTimeout(300);

  console.log('\nB. 资源列表');
  const rows = await p.evaluate(() => Array.from(document.querySelectorAll('#source-list .list-item')).map(el => ({
    text: el.querySelector('.tt') ? el.querySelector('.tt').textContent.trim() : '',
    tag: el.querySelector('.tag') ? el.querySelector('.tag').textContent.trim() : '',
    buttons: Array.from(el.querySelectorAll('button')).map(b => b.textContent.trim()),
  })));
  ck('B1 列表里有「电子书内图片」这条资源', rows.some(r => r.tag === '电子书内图片' || r.text.includes('电子书内图片')), rows.map(r => r.text));
  ck('B2 每条都有 上移/下移/编辑/启停/删除（能排序、能停用）',
    rows.length > 0 && rows.every(r => r.buttons.length >= 5), rows.map(r => r.buttons));
  const api = JSON.parse(execSync(`curl -sk -H "Authorization: Bearer ${info.token}" ${BASE}/api/admin/sources`, { encoding: 'utf8' }));
  ck('B3 接口返回的 ebook 源 enabled=1（预置即可用）',
    api.some(s => s.type === 'ebook' && s.enabled === 1), api.map(s => `${s.type}:${s.enabled}`));
  ck('B4 它默认排在在线源后面（兜底位置）',
    api.length > 1 && api[api.length - 1].type === 'ebook', api.map(s => s.type));

  ck('C 全程没有 JS 报错', errs.length === 0, errs.slice(0, 3));

  await browser.close();
  console.log(`\n后台「电子书内图片」源界面：${pass} 通过 / ${fail} 失败`);
  process.exit(fail ? 1 : 0);
})();
