# -*- coding: utf-8 -*-
"""线路文本清洗（safe_text）的回归测试。

背景（实测事故）：《A14305. 魔戒三部曲.B00NZKTYM2》第 4 个文件第 200 句
  「托尔金根据古英语的 máðm（意为“珍贵之物，财宝”）一词造出了该词……」
里的 ð(U+00F0) 在 GBK 里编不出来，而三台线路都按 GBK 编码文本：
  .3  → 500 'gbk' codec can't encode character '\xc1'
  .16 → 400 'gbk' codec can't encode character '\xf0' in position 11（与该字符位置完全一致）
  .6  → 400 未知音色 pool_49
三台全灭 → 整本书在第 200 句失败。这是**文本**问题，不是线路宕机。

修法：在 speech.synth()（网络调用前的最后一层）把线路编不出的字符折成发音等价写法。

安全：本测试**不联网**（tts.call_tts 被换成会报错的桩），只建临时任务行并按 id 清理。
"""
import os
import sys
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
os.chdir(_ROOT)
import db  # noqa: E402
from audiobook import book as B, speech as S, store as ST  # noqa: E402

BOOK_ID = 383692
_pass, _fail = [0], [0]


def ck(name, ok, extra=''):
    if ok:
        _pass[0] += 1
        print('  [OK] %s%s' % (name, ('  ' + str(extra)) if extra != '' else ''))
    else:
        _fail[0] += 1
        print('  [FAIL] %s%s' % (name, ('  ' + str(extra)) if extra != '' else ''))


def gbk_ok(s):
    try:
        (s or '').encode('gbk')
        return True
    except UnicodeEncodeError:
        return False


SENT = '托尔金根据古英语的máðm（意为“珍贵之物，财宝”）一词造出了该词，并指明这并不是西部语，因此应音译。'

print('=' * 78)
print('A. 复现：这句话确实让所有线路编码失败')
print('=' * 78)
ck('原文 GBK 编不出来（就是 500/400 的成因）', not gbk_ok(SENT))
try:
    SENT.encode('gbk')
    ck('定位不到出问题的字符', False)
except UnicodeEncodeError as e:
    ck('出错字符是 ð(U+00F0)，位置 11（与 .16 报错 position 11 一致）',
       '\\xf0' in str(e) and 'position 11' in str(e), str(e))

print()
print('=' * 78)
print('B. 清洗：折成发音等价写法，且只动编不出来的字符')
print('=' * 78)
t = S.safe_text(SENT)
ck('清洗后 GBK 能编了', gbk_ok(t))
ck('原文里的 ð 被折成 d（á 也一起折了，见 E 段）', 'madm' in t, t[9:16])
ck('长度不变（逐字符替换，不是删字符）', len(t) == len(SENT), '%d → %d' % (len(SENT), len(t)))
ck('中文与标点原样保留', '珍贵之物，财宝' in t and '“' in t and '。' in t)

cases = [
    ('þeoden', 'theoden', 'thorn → th'),
    ('Ælfwine', 'Aelfwine', 'ash → Ae'),
    ('smial', 'smial', '纯 ASCII 不动'),
    # ★ 这三条以前断言「ó/é 小写能编 GBK 所以原样保留」——那是**旧的错误前提**：
    #   线路会把字母转成大写再编码，而 Ó/É/Á 在 GBK 里根本没有（见 E 段实测）。
    #   留着它们 = 留着一个必炸的字符，所以现在统一折成 ASCII。
    ('Lothlórien', 'Lothlorien', 'ó 小写能编 GBK，但大写 Ó 编不出 → 折成 o'),
    ('Sméagol', 'Smeagol', 'é 同理 → 折成 e（线路转大写后 É 不在 GBK）'),
    ('α β γ', 'α β γ', '希腊字母在 GBK 里 → 原样保留'),
    ('①②③', '①②③', '带圈数字在 GBK 里 → 原样保留'),
    ('naïve café', 'naive cafe', 'ï 不在 GBK；é 的大写 É 也不在 → 都去音标'),
    ('中文，标点！', '中文，标点！', '中文原样'),
]
for src, want, why in cases:
    got = S.safe_text(src)
    ck('%r → %r（%s）' % (src, got, why), got == want, '' if got == want else '实际 %r' % got)

ck('空串 / None 不炸', S.safe_text('') == '' and S.safe_text(None) == '')
ck('大段文本里只有个别字符被改', S.safe_text(SENT).count('ð') == 0)

print()
print('=' * 78)
print('C. synth() 只把清洗后的文本发出去（tts.call_tts 换成桩，不联网）')
print('=' * 78)
import tts  # noqa: E402
_real_call = tts.call_tts
sent_box = []


def fake_call(text, voice=None, cfg=None, line=None):
    sent_box.append(text)
    return b'\x00' * 1024, None, (line or 'stub')


tts.call_tts = fake_call
try:
    audio, used = S.synth(SENT, 'pool_49', 'http://127.0.0.1:1', None)
    ck('synth 返回了音频', bool(audio))
    ck('发给线路的文本已经清洗过', gbk_ok(sent_box[0]), sent_box[0][:24] + '…')
    ck('发给线路的文本仍含中文内容（没被清空）', '珍贵之物' in sent_box[0])
    # 全是线路不支持字符的句子：不能发空文本过去
    sent_box.clear()
    try:
        S.synth('ðþ', 'pool_49', 'http://127.0.0.1:1', None)
        ck('清洗后只剩 dth 这种安全内容', sent_box and sent_box[0] == 'dth', sent_box[:1])
    except Exception as e:
        ck('清洗后只剩 dth 这种安全内容', False, repr(e))
finally:
    tts.call_tts = _real_call

print()
print('=' * 78)
print('D. 整本书体检：全库句子里还有没有线路编不出的字符')
print('=' * 78)
b = dict(db.q("SELECT * FROM books WHERE id=?", (BOOK_ID,), one=True))
chs = B.chapters(b)
all_sents = []
for ch in chs:
    all_sents.extend(S.split_sentences(ch['text']))
bad_before = [s for s in all_sents if not gbk_ok(s)]
print('  《%s》共 %d 句，清洗前有 %d 句含线路编不出的字符' % (b['title'], len(all_sents), len(bad_before)))
for s in bad_before[:3]:
    bad = [(i, c, 'U+%04X' % ord(c)) for i, c in enumerate(s) if not gbk_ok(c)]
    print('    %r → %s' % (s[:44], bad))
bad_after = [s for s in all_sents if not gbk_ok(S.safe_text(s))]
ck('清洗后全书没有一句再含编不出的字符', not bad_after, '剩 %d 句' % len(bad_after))
ck('出事的那句在书里（说明测试对准了真问题）',
   any('máðm' in s for s in all_sents))
ck('清洗不改变句数（不影响断句与缓存键）',
   len([S.safe_text(s) for s in all_sents]) == len(all_sents))
print()

print('=' * 78)
print('通过 %d / 失败 %d' % (_pass[0], _fail[0]))
print()
print('=' * 78)
print('E. 大小写陷阱：线路会做大小写归一，只看原字符会漏（本次《魔戒》失败的真因）')
print('=' * 78)
# 真事故：第 34 个文件第 334 句是精灵语 laurië lantar lassi súrinen,
#   ë 被旧规则判出来了，ú 却漏了过去 —— 因为**小写** ú 能编 GBK，
#   而线路把字母转成大写后 GBK 里没有 Ú，于是 500：
#     'gbk' codec can't encode character '\xda' in position 2
#   报的是**大写**形态，原文里根本没有 Ú，所以只看报错会找不到是哪个字。
def all_case_gbk_ok(x):
    for v in (x, x.upper(), x.lower()):
        if not gbk_ok(v):
            return False
    return True


ck('小写 ú 能编 GBK（所以旧规则放它过去）', gbk_ok('ú'))
ck('★ 大写 Ú 编不出 GBK（线路转大写后就炸在这）', not gbk_ok('ú'.upper()))
try:
    'ú'.upper().encode('gbk')
    ck('定位不到大写形态的报错字符', False)
except UnicodeEncodeError as e:
    ck('★ 报错字符正是大写 Ú（说明线路做了大小写归一）', '\\xda' in repr(str(e)), repr(str(e)))

MO_SENT = 'laurië lantar lassi súrinen,'
# 旧规则会把 ë 折掉（它确实编不出 GBK），但**留下** ú —— 于是清洗完还是炸。
# 所以当初不是「完全没清洗」，而是「清洗漏了一类字符」，这更难发现。
import unicodedata  # noqa: E402


def old_safe_text(text):
    out = []
    for ch in (text or ''):
        if gbk_ok(ch):
            out.append(ch)
            continue
        a = ''.join(c for c in unicodedata.normalize('NFKD', ch) if ord(c) < 128)
        out.append(a or ' ')
    return ''.join(out)


_old_fixed = old_safe_text(MO_SENT)
ck('★ 旧规则清洗后 ë 没了、ú 还在', 'ë' not in _old_fixed and 'ú' in _old_fixed, repr(_old_fixed))
ck('★ 旧规则清洗后仍然必炸（这就是它放过故障的原因）', not all_case_gbk_ok(_old_fixed))
ck('★ 新判据（三种大小写形态全验）能拦下它', not all_case_gbk_ok(MO_SENT))
fixed = S.safe_text(MO_SENT)
ck('★ 清洗后折成发音等价的 ASCII',
   fixed == 'laurie lantar lassi surinen,', repr(fixed))
ck('★ 清洗后三种大小写形态都能编 GBK（线路怎么转都不炸）', all_case_gbk_ok(fixed))
ck('中文不受影响（该留的一个没动）',
   S.safe_text('中华人民共和國，你好！') == '中华人民共和國，你好！')
bad_case = [s for s in all_sents if not all_case_gbk_ok(S.safe_text(s))]
ck('★ 清洗后全书没有一句再含「任一大小写形态编不出 GBK」的字符',
   not bad_case, '剩 %d 句' % len(bad_case))
n_old = len([s for s in all_sents if gbk_ok(s) and not all_case_gbk_ok(s)])
print('  《魔戒》里「旧规则放行、线路上必炸」的句子：%d 句' % n_old)
ck('★ 本次事故的句子确实在书里（说明回归对准了真问题）',
   any('laurië lantar lassi súrinen' in s for s in all_sents))
print()

print('=' * 78)
sys.exit(1 if _fail[0] else 0)
