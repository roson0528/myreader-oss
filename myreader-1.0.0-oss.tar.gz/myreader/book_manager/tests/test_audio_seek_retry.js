// seek 兜底：给还没升级到 V3.6 的 APK 用。
//
// 背景：V3.5 及更早的原生 onPreparedListener **无条件** seekTo(本章起点)，
// 会把用户在「本章还在 prepareAsync」那几百毫秒里点下的位置覆盖掉 ——
// 站长报的「点击后会从本章节开始播放」就是它。
//
// V3.6 已在原生用 pendingSeekMs 修掉；网页这边再兜一层：点击后 8 秒内，
// 若原生报回来的位置几乎还在本章起点（说明那次点击被吃掉了），补发一次。
//
// 这个脚本只读服务端数据，不写库表。
const { chromium } = require('playwright-core');
const { execSync } = require('child_process');
const CHROME = '/srv/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome';
const ROOT = '/srv/myreader/book_manager';

let pass = 0, fail = 0;
const ck = (n, ok, extra) => {
  if (ok) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (extra ? '  → ' + extra : '')); }
};
const py = (c) => execSync('venv/bin/python -', { cwd: ROOT, encoding: 'utf8', input: c }).trim();

// 桩：seek 只记录，位置回报完全由测试用 __laoshuPlayerState 推。
const BRIDGE = (title) => `
window.__nativeCalls = [];
(function () {
  const st = { version: 5, btLink: true, active: false, mode: 'mp3', playing: false,
               title: ${JSON.stringify(title)}, index: 0, positionMs: 0, durationMs: 0, total: 1 };
  const rec = (n) => function (a) {
    window.__nativeCalls.push({ name: n, arg: a || null });
    if (n === 'status') return Promise.resolve(Object.assign({}, st));
    if (n === 'startMp3') { st.active = true; st.playing = true; st.index = (a && a.index) || 0; return Promise.resolve({ ok: true }); }
    if (n === 'seek') { return Promise.resolve({ ok: true }); }   // ★ 故意不改 st.positionMs
    return Promise.resolve({ ok: true });
  };
  const p = {};
  ['status','startMp3','seek','play','pause','next','prev','gotoIndex','setVoice','setRate','stop']
    .forEach(k => { p[k] = rec(k); });
  window.Capacitor = { Plugins: { ListenService: p } };
})();
`;

(async () => {
  const info = JSON.parse(py(`
import sys, json
sys.path.insert(0, '${ROOT}')
import db, auth
u = db.q("SELECT * FROM users WHERE role='admin' AND enabled=1 ORDER BY id LIMIT 1", one=True)
db.ex("DELETE FROM ab_session WHERE user_id=?", (u["id"],))   # 清掉上一轮测试遗留的有声单端锁
c = db.q("SELECT lib_id, seq FROM ab_lib_chap WHERE n_segs>=8 AND start_sec>1 ORDER BY lib_id, seq LIMIT 1", one=True)
l = db.q("SELECT id, title FROM ab_lib WHERE id=?", (c["lib_id"],), one=True)
print(json.dumps({"tok": auth.create_token(u), "user": dict(u), "l": dict(l), "c": dict(c)}))`));

  const browser = await chromium.launch({
    executablePath: CHROME, args: ['--no-sandbox', '--autoplay-policy=no-user-gesture-required'] });
  const ctx = await browser.newContext({ ignoreHTTPSErrors: true, viewport: { width: 420, height: 900 } });
  await ctx.addInitScript(([t, u]) => {
    localStorage.setItem('bm_token', t); localStorage.setItem('bm_user', u);
    try { sessionStorage.setItem('bm_audio_sid', 'fixseekretry'); } catch (e) {}
  }, [info.tok, JSON.stringify(info.user)]);
  await ctx.addInitScript(BRIDGE(info.l.title));
  const page = await ctx.newPage();
  const errs = [];
  page.on('pageerror', e => errs.push(String(e).slice(0, 90)));
  await page.goto('https://127.0.0.1:9000/', { waitUntil: 'domcontentloaded' });
  await page.waitForFunction(() => typeof audioPlay === 'function', null, { timeout: 20000 });
  await page.waitForTimeout(900);

  await page.evaluate(([id, ch]) => audioPlay(id, ch, false), [info.l.id, info.c.seq]);
  // ★ 用显式等待而不是固定 sleep：整套连跑时取歌词接口会慢，固定 4 秒会偶发不够
  let loaded = true;
  try {
    // ★ 必须等到 AUP.native 置真：auNativePlay 要把整本取票跑完才算接管，
    //   在那之前 AUP.native 还是 false，点击会被记成 pendingClickAt（测不到 seek）
    await page.waitForFunction(() => AUP && AUP.segs && AUP.segs.length >= 8 && AUP.native === true, null, { timeout: 40000 });
  } catch (e) { loaded = false; }
  const nseg = await page.evaluate(() => (AUP && AUP.segs ? AUP.segs.length : 0));
  ck('native：文字已加载', loaded && nseg >= 8, 'n=' + nseg);

  // 点第 5 句
  const target = await page.evaluate(() => {
    window.__nativeCalls.length = 0;
    document.getElementById('aup-l5').click();
    return Math.round(AUP.segs[5].start_sec * 1000);
  });
  await page.waitForTimeout(300);
  const s1 = await page.evaluate(() => (window.__nativeCalls || []).filter(c => c.name === 'seek').map(c => c.arg.ms));
  ck('点第 5 句 → 发出了 seek(' + target + ')', s1.length >= 1 && s1[0] === target, JSON.stringify(s1));

  // ★ 模拟 V3.5 的 onPrepared 覆盖：报回来的位置还在本章起点。
  //   ★★ 补发必须**节流**：早先是一来帧就补，一次点击能连发 3 次 seek（实测 20ms 内），
  //   每次都让原生重新定位一遍。现在要求距上次尝试 >=1.2 秒才补。
  const frame = (pos) => page.evaluate(([idx, p]) => {
    window.__laoshuPlayerState({ version: 5, mode: 'mp3', active: true, playing: true,
      index: idx, total: 1, chapter: '章', positionMs: p, durationMs: 60000, bookId: 0 });
  }, [info.c.seq - 1, pos]);

  await page.evaluate(() => { window.__nativeCalls.length = 0; });
  await frame(0);
  await page.waitForTimeout(500);
  const sEarly = await page.evaluate(() => (window.__nativeCalls || []).filter(c => c.name === 'seek').length);
  ck('★ 补发有节流：0.5 秒内不抢着补', sEarly === 0, '0.5 秒内补发=' + sEarly + ' 次');

  await page.waitForTimeout(900);              // 累计 1.4 秒 > 1.2 秒
  await frame(0);                              // 再来一帧「还在章首」，这次才该补
  await page.waitForTimeout(400);
  const s2 = await page.evaluate(() => (window.__nativeCalls || []).filter(c => c.name === 'seek').map(c => c.arg.ms));
  ck('★ 位置被覆盖回章起点（0ms）→ 隔 1.2 秒补发 seek(' + target + ')',
     s2.length >= 1 && s2[0] === target, JSON.stringify(s2));

  // ★★ 老判据是「位置 > 1.2 秒就算到位」，于是「点的是 30 秒处那句、原生报 2 秒」
  //    也会被当成成功，这一下点击就静默丢了。现在必须比到目标附近才算数。
  await page.evaluate(() => { document.getElementById('aup-l5').click(); window.__nativeCalls.length = 0; });
  await frame(2000);                           // 2 秒：>1.2 秒，但离目标 30 秒还很远
  await page.waitForTimeout(1400);
  await frame(2000);
  await page.waitForTimeout(400);
  const sFar = await page.evaluate(() => (window.__nativeCalls || []).filter(c => c.name === 'seek').map(c => c.arg.ms));
  ck('★ 只报「2 秒」不算到位（目标 ' + Math.round(target / 1000) + ' 秒）→ 仍然补发',
     sFar.length >= 1 && sFar[0] === target, JSON.stringify(sFar));

  // 位置真的到了目标 → 不该再补
  await page.evaluate(() => { window.__nativeCalls.length = 0; });
  await frame(target + 400);
  await page.waitForTimeout(1500);
  await frame(target + 420);
  await page.waitForTimeout(400);
  const s3 = await page.evaluate(() => (window.__nativeCalls || []).filter(c => c.name === 'seek').length);
  ck('★ 位置到目标后**不再**补发（否则会和播放抢位置）', s3 === 0, '补发=' + s3 + ' 次');
  const hl = await page.evaluate(() => Array.from(document.querySelectorAll('.ap-line')).findIndex(e => e.classList.contains('on')));
  ck('★ 高亮停在补发后的那一句（没被错误位置带回去）', hl === 5, '高亮=' + hl);

  // ------------- D. 原生会话还在建立时的点击不能丢 -------------
  // auNativePlay() 要把**整本**的取票跑完才会把 AUP.native 置真（三体 186 章、并发 6，
  // 要好几秒）。这段窗口里 AUP.native 还是 false，若直接走网页分支改
  // AU_AUDIO.currentTime，APP 里的声音在原生那边、根本不受影响 —— 这一下点击等于白点，
  // 紧接着原生起播就是本章开头。站长说的「点击后会从本章节开始播放」正是这个。
  const during = await page.evaluate(async ([id, ch]) => {
    AUP = null;
    window.__nativeCalls.length = 0;
    audioPlay(id, ch, false);                       // 不 await：就是要抢在接管之前
    let clicked = -1, nativeAtClick = null;
    for (let i = 0; i < 3000; i++) {          // 最多 30 秒等文字渲染出来
      const el = document.getElementById('aup-l6');
      // ★ 注意用裸 AUP：它是 let 声明的，**不是 window 属性**，window.AUP 恒为 undefined
      if (el && typeof AUP !== 'undefined' && AUP && AUP.segs && AUP.segs.length >= 8) {
        nativeAtClick = AUP.native;
        el.click();
        clicked = 6;
        break;
      }
      await new Promise(r => setTimeout(r, 10));
    }
    const askAt = AUP && AUP.pendingClickAt;
    for (let i = 0; i < 800; i++) {                 // 等原生真的接管
      if (AUP && AUP.native === true) break;
      await new Promise(r => setTimeout(r, 25));
    }
    await new Promise(r => setTimeout(r, 500));
    const seeks = (window.__nativeCalls || []).filter(c => c.name === 'seek').map(c => c.arg.ms);
    return { clicked, nativeAtClick, askAt, seeks, native: AUP.native,
             want: Math.round(AUP.segs[6].start_sec * 1000) };
  }, [info.l.id, info.c.seq]);
  ck('起播窗口内点击时原生确实还没接管（否则这条测不到东西）',
     during.clicked === 6 && during.nativeAtClick === false, String(during.nativeAtClick));
  ck('★ 那一下点击被记下来（不是丢掉）', typeof during.askAt === 'number', 'askAt=' + during.askAt);
  ck('★ 原生接管后自动补跳到那一句（seek=' + during.want + '）',
     during.native === true && during.seeks.length >= 1 && during.seeks[0] === during.want,
     'seeks=' + JSON.stringify(during.seeks));

  ck('没有 JS 报错', errs.length === 0, errs[0] || '');
  // ★ 收尾：把自己留下的有声单端锁清掉。
  //   不清的话它会活 40 秒租约，紧接着打开 APP 会误报「正在另一台设备上收听」。
  try {
    py(`import sys; sys.path.insert(0, '${ROOT}')
import db
db.ex("DELETE FROM ab_session WHERE user_id=?", (1,))`);
  } catch (e) {}


  await browser.close();
  console.log(`\nseek 兜底：${pass} 通过 / ${fail} 失败`);
  process.exit(fail ? 1 : 0);
})();
