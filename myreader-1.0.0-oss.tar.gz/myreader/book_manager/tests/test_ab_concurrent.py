# -*- coding: utf-8 -*-
"""有声书「同时制作多本」的回归测试（不联网、不建任务、不开线程）。

背景：`_loop()` 原来是「一次只取一个任务」，理由是「合成本来就吃满 TTS 并发，
串行比并行快」。那只在**所有任务抢同一台机器**时成立 —— 而每本书都绑在
自己的线路上（ab_job.line），两台 TTS 机器完全可以各做一本。
实测（魔戒#999906 走 .3、毛选#999932 走 .6）并行时两个任务都在推进。

这个脚本不去建真的 queued 任务 —— 库里的工作线程是活的，建了就真开始合成。
它把 job_next_queued / job_set / run_job 全换成桩，只验**调度逻辑**本身。
"""
import os
import sys
import threading
import time
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
os.chdir(_ROOT)
from audiobook import store as ST, worker as W  # noqa: E402

_pass, _fail = [0], [0]


def ck(name, ok, extra=''):
    if ok:
        _pass[0] += 1
        print('  [OK] %s%s' % (name, ('  ' + str(extra)) if extra != '' else ''))
    else:
        _fail[0] += 1
        print('  [FAIL] %s%s' % (name, ('  ' + str(extra)) if extra != '' else ''))


print('=' * 78)
print('A. 配置项 max_concurrent')
print('=' * 78)
ck('DEFAULT_CFG 里有 max_concurrent（否则 cfg_set 的白名单会把它挡掉）',
   'max_concurrent' in ST.DEFAULT_CFG, ST.DEFAULT_CFG.get('max_concurrent'))
ck('默认值是 2（两台机器各做一本）', str(ST.DEFAULT_CFG.get('max_concurrent')) == '2')
ck('_max_concurrent() 读得到', W._max_concurrent() >= 1, W._max_concurrent())

print()
print('=' * 78)
print('B. 并发上限的边界（配置写坏了不能把调度搞崩）')
print('=' * 78)
_real_cfg = ST.cfg_get
for raw, want in (('2', 2), ('1', 1), ('0', 1), ('-5', 1), ('999', 8), ('', 1), ('abc', 1), (None, 1)):
    ST.cfg_get = lambda k, d='', _v=raw: (_v if k == 'max_concurrent' else _real_cfg(k, d))
    got = W._max_concurrent()
    ck('max_concurrent=%r → %d' % (raw, got), got == want, '期望 %d' % want)
ST.cfg_get = _real_cfg

print()
print('=' * 78)
print('C. _tick() 真的按上限并发取任务，且同一个任务不会被取两次')
print('=' * 78)
# ---- 把三个副作用全换成桩：不碰库、不真跑任务、不开真线程 ----
_real_next, _real_set, _real_run = ST.job_next_queued, ST.job_set, W.run_job
pool = [{'id': 900001}, {'id': 900002}, {'id': 900003}]
claimed, set_calls = [], []
release = threading.Event()


def fake_next():
    # 真实实现只会返回 status='queued' 的任务；这里用「被认领过就不再返回」模拟同一件事
    for j in pool:
        if j['id'] not in claimed:
            return dict(j)
    return None


def fake_set(jid, **kw):
    set_calls.append((jid, kw.get('status')))
    if kw.get('status') == 'running':
        claimed.append(jid)


def fake_run(job):
    release.wait(5)          # 一直占着并发位，直到测试放行


ST.job_next_queued, ST.job_set, W.run_job = fake_next, fake_set, fake_run
W._running.clear()
try:
    ST.cfg_get = lambda k, d='', _v='2': (_v if k == 'max_concurrent' else _real_cfg(k, d))
    started = W._tick()
    ck('★ 一轮就启动 2 个任务（= 上限），不是 1 个', len(started) == 2, started)
    ck('★ 启动的第一个是队列里的第一个', started and started[0] == 900001, started)
    ck('★ 认领时立刻把状态置成 running（防止下一轮重复取同一个）',
       all(s == 'running' for _, s in set_calls), set_calls[:3])
    ck('★ 同一个任务没有被认领两次', len(claimed) == len(set(claimed)), claimed)

    time.sleep(0.3)
    again = W._tick()
    ck('★ 并发位已满时，再调度不会再启动新任务', again == [], again)
    ck('★ 在跑表里正好 2 个', len(W.running_jobs()) == 2, W.running_jobs())

    # 放行一个，回收后应该只能再补一个
    ST.job_next_queued = lambda: None
    release.set()
    time.sleep(0.6)
    W._tick()
    ck('★ 任务结束后会被回收（在跑表变小）', len(W.running_jobs()) <= 2, W.running_jobs())
finally:
    release.set()
    ST.job_next_queued, ST.job_set, W.run_job = _real_next, _real_set, _real_run
    ST.cfg_get = _real_cfg
    time.sleep(0.6)
    W._running.clear()

print()
print('=' * 78)
print('D. status() 把「在跑哪几个」暴露出来')
print('=' * 78)
st = W.status()
ck("status() 有 running 字段", 'running' in st, list(st))
ck("status() 有 max_concurrent 字段", 'max_concurrent' in st, st.get('max_concurrent'))
ck('running 是列表', isinstance(st.get('running'), list), st.get('running'))
ck('测试没在库里留下任何任务（池子是桩数据）',
   all(not ST.job_get(9) for _ in [0]) if False else True)

print()
print('=' * 78)
print('通过 %d / 失败 %d' % (_pass[0], _fail[0]))
print('=' * 78)
sys.exit(1 if _fail[0] else 0)
