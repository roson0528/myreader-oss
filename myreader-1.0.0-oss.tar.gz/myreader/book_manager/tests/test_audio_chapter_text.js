// 「有声播放页：文字跟着章走 / 点击某句能正确定位」的回归（不需要真机）。
//
// 线上现象（用户报，2026-10-12）：
//   ① 点击某个文本段落**无法定位播放**；
//   ② 点「下一章」时**文字还停在当前章**，只有声音切过去了。
//
// 真因（本脚本先复现再修）：原生模式下切章**只改了章号与 chapStart，没有重新取这一章的歌词**，
// 于是 AUP.segs 还是上一章的句子：
//   · 文字区照旧渲染旧章内容（现象②）；
//   · 而点击某句是按 `chapStart + 章内相对秒` 算目标位置，章起点已经换成新章、
//     句子却是旧章的偏移 → 跳到错的地方（现象①）。
// 注意原生的契约（两边都对齐，别改错）：
//   · PlaybackService 回报的 positionMs/durationMs 是**章内相对**（abs - st）；
//   · 原生 seekToMs(ms) 内部自己加本章起点（mp.seekTo(st + ms)），
//     所以网页传的 ms 也必须是**章内相对**。
//
// 本脚本只读服务端数据，不写任何库表（只清自己留下的单端锁）。
const { chromium } = require('playwright-core');
const { execSync } = require('child_process');
const CHROME = '/srv/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome';
const ROOT = '/srv/myreader/book_manager';

let pass = 0, fail = 0;
const ck = (n, ok, extra) => {
  if (ok) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (extra ? '  → ' + extra : '')); }
};
const py = (code) => execSync('venv/bin/python -', { cwd: ROOT, encoding: 'utf8', input: code }).trim();

// 有状态的原生桩：gotoIndex 真的换章、seek 记下来、status 按当前章回报。
const BRIDGE = `
window.__nc = { gotoIndex: [], seek: [], startMp3: [], play: 0, pause: 0 };
(function () {
  let cur = 0, pos = 0, playing = true, dur = 60000;
  const total = 0;                                   // 由测试用 __setTotal 补
  window.__setChapters = function (n, i) { window.__total = n; cur = i; };
  window.__report = function (index, positionMs) { cur = index; pos = positionMs; };
  const plug = {
    status: function () { return Promise.resolve({ version: 5, btLink: true, active: true,
      playing: playing, mode: 'mp3', index: cur, total: window.__total || 1,
      chapter: '第' + (cur + 1) + '章', positionMs: pos, durationMs: dur, bookId: 0 }); },
    startMp3: function (a) { window.__nc.startMp3.push(a); if (a && typeof a.index === 'number') cur = a.index; return Promise.resolve({ ok: true }); },
    gotoIndex: function (a) { window.__nc.gotoIndex.push(a); if (a && typeof a.index === 'number') cur = a.index; pos = 0; return Promise.resolve({ ok: true }); },
    seek: function (a) { window.__nc.seek.push(a); pos = (a && a.ms) || 0; return Promise.resolve({ ok: true }); },
    play: function () { window.__nc.play++; playing = true; return Promise.resolve({ ok: true }); },
    pause: function () { window.__nc.pause++; playing = false; return Promise.resolve({ ok: true }); },
    next: function () { cur++; return Promise.resolve({ ok: true }); },
    prev: function () { cur--; return Promise.resolve({ ok: true }); },
    setVoice: function () { return Promise.resolve({ ok: true }); },
    setRate: function () { return Promise.resolve({ ok: true }); },
    stop: function () { return Promise.resolve({ ok: true }); },
  };
  window.Capacitor = { Plugins: { ListenService: plug } };
})();
`;

(async () => {
  const info = JSON.parse(py(`
import sys, json
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
import db, auth
u = db.q("SELECT * FROM users WHERE role='admin' AND enabled=1 ORDER BY id LIMIT 1", one=True)
db.ex("DELETE FROM ab_session WHERE user_id=?", (u["id"],))
# 挑一本有多章、且第一章确实有分句时间轴的书
# ★ 章数**从少到多**挑：原生要把整本直链清单一次性取完才会置 AUP.native，
#   章数越多这步越慢（9 章的书实测要 17 秒），挑最少的能快很多。
rows = db.q("""SELECT l.id, l.title, l.total_chapters FROM ab_lib l
  WHERE l.hidden=0 AND l.total_chapters>=4 ORDER BY l.total_chapters ASC LIMIT 6""")
print(json.dumps({"token": auth.create_token(u), "uid": u["id"], "libs": [dict(r) for r in rows]}))
`));
  const browser = await chromium.launch({ executablePath: CHROME, args: ['--no-sandbox'] });
  const ctx = await browser.newContext({ ignoreHTTPSErrors: true, viewport: { width: 420, height: 900 } });
  await ctx.addInitScript(tk => { localStorage.setItem('bm_token', tk);
    localStorage.setItem('bm_user', '{"id":1,"role":"admin"}');
    try { sessionStorage.setItem('bm_audio_sid', 'fixchaptertext'); } catch (e) {} }, info.token);
  await ctx.addInitScript(BRIDGE);
  const page = await ctx.newPage();
  const errs = [];
  page.on('pageerror', e => errs.push(String(e).slice(0, 160)));
  await page.goto('https://127.0.0.1:9000/', { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(2000);

  try {
    // 找一本「相邻两章都有分句」的书，否则文字断言没意义
    let LIB = null, chs = null, ly1 = null, ly2 = null, ly3 = null;
    for (const L of info.libs) {
      const d = await page.evaluate(id => api('/api/audiobooks/' + id), L.id);
      const cs = (d.chapters || []).slice().sort((a, b) => a.seq - b.seq);
      if (cs.length < 4) continue;
      const a = await page.evaluate(([id, c]) => api('/api/audiobooks/' + id + '/lyrics?chap=' + c), [L.id, cs[0].seq]);
      const b2 = await page.evaluate(([id, c]) => api('/api/audiobooks/' + id + '/lyrics?chap=' + c), [L.id, cs[1].seq]);
      const c3 = await page.evaluate(([id, c]) => api('/api/audiobooks/' + id + '/lyrics?chap=' + c), [L.id, cs[2].seq]);
      if ((a.segs || []).length > 3 && (b2.segs || []).length > 3 && (c3.segs || []).length > 3) {
        LIB = L; chs = cs; ly1 = a; ly2 = b2; ly3 = c3; break;
      }
    }
    if (!LIB) { console.log('  没找到相邻章都有分句的有声书，跳过'); await browser.close(); process.exit(0); }
    const c1 = chs[0], c2 = chs[1], c3 = chs[2];
    console.log('  用《' + LIB.title + '》第 ' + c1.seq + ' → ' + c2.seq + ' → ' + c3.seq + ' 章');

    // 开第 1 章（原生）
    await page.evaluate(([id, seq, n]) => { window.__setChapters(n, 0); audioPlay(id, seq, false); },
      [LIB.id, c1.seq, chs.length]);
    // 原生会话建立要等整本取票，给足 60 秒（章数少的书通常几秒）
    for (let i = 0; i < 60; i++) {
      await page.waitForTimeout(1000);
      if (await page.evaluate(() => !!(AUP && AUP.native))) break;
    }
    ck('原生会话已建立（AUP.native）', await page.evaluate(() => !!(AUP && AUP.native)));

    const line0 = await page.evaluate(() => {
      const e = document.getElementById('aup-l0');
      return e ? e.textContent : null;
    });
    ck('第 1 章文字已渲染', line0 === ly1.segs[0].text, JSON.stringify(String(line0).slice(0, 20)));

    // ---------------------------------------------- A. 点「下一章」：文字必须跟着换
    await page.evaluate(() => { window.__nc.gotoIndex.length = 0; auStep(1); });
    await page.waitForTimeout(2500);       // 等歌词请求回来
    const afterStep = await page.evaluate(() => ({
      chap: AUP.chap, chapStart: AUP.chapStart,
      line0: (document.getElementById('aup-l0') || {}).textContent || null,
      segs0: AUP.segs.length ? AUP.segs[0].text : null,
      goto: window.__nc.gotoIndex.length ? window.__nc.gotoIndex[0].index : null,
    }));
    ck('★ 点下一章后章号已换', afterStep.chap === c2.seq, 'AUP.chap=' + afterStep.chap);
    ck('★ 章起点已换成新章', Math.abs((afterStep.chapStart || 0) - (c2.start_sec || 0)) < 0.01,
      afterStep.chapStart + ' vs ' + c2.start_sec);
    ck('★ 文字区换成了第 ' + c2.seq + ' 章的内容（不能还停在上一章）',
      afterStep.line0 === ly2.segs[0].text,
      '显示=' + JSON.stringify(String(afterStep.line0).slice(0, 24)) +
      ' 期望=' + JSON.stringify(String(ly2.segs[0].text).slice(0, 24)));
    ck('★ AUP.segs 也换成了第 ' + c2.seq + ' 章', afterStep.segs0 === ly2.segs[0].text,
      JSON.stringify(String(afterStep.segs0).slice(0, 24)));

    // ---------------------------------------------- B. 点击某一句：必须按**本章**的时间轴定位
    await page.evaluate(() => { window.__nc.seek.length = 0; });
    await page.click('#aup-l4');
    await page.waitForTimeout(500);
    const clickRes = await page.evaluate(() => ({
      seek: window.__nc.seek.length ? window.__nc.seek[0].ms : null,
      idx: AUP.idx,
      onId: (document.querySelector('#aup-texts .ap-line.on') || {}).id || null,
    }));
    const wantMs = Math.round(Math.max(0, (ly2.segs[4].start_sec || 0) - (c2.start_sec || 0)) * 1000);
    ck('★ 点击第 5 句 → 原生 seek 到**本章**对应位置（章内相对毫秒）',
      clickRes.seek !== null && Math.abs(clickRes.seek - wantMs) <= 1200,
      'seek=' + clickRes.seek + ' 期望≈' + wantMs);
    ck('★ 点击后这一句立刻高亮', clickRes.onId === 'aup-l4', 'on=' + clickRes.onId);

    // ---------------------------------------------- C. 原生自己播到下一章（自动接章）：文字也要跟着换
    // ★ 分两步：先让原生回报「已经切到第 2 章」解除 switchTo 拦截（否则这一帧会被
    //   防错位的守卫丢掉 —— 那是设计如此），再模拟「本章播完、原生自动接第 3 章」。
    const idx2 = chs.findIndex(c => c.seq === c2.seq);
    const idx3 = chs.findIndex(c => c.seq === c3.seq);
    await page.evaluate(([idx]) => {
      window.__report(idx, 1000);
      window.__laoshuPlayerState({ version: 5, mode: 'mp3', active: true, playing: true,
        index: idx, total: window.__total, chapter: '第' + (idx + 1) + '章',
        positionMs: 1000, durationMs: 60000, bookId: 0 });
    }, [idx2]);
    await page.waitForTimeout(1200);
    await page.evaluate(([idx]) => {
      window.__report(idx, 3000);
      window.__laoshuPlayerState({ version: 5, mode: 'mp3', active: true, playing: true,
        index: idx, total: window.__total, chapter: '第' + (idx + 1) + '章',
        positionMs: 3000, durationMs: 60000, bookId: 0 });
    }, [idx3]);
    await page.waitForTimeout(2500);
    const afterAuto = await page.evaluate(() => ({
      chap: AUP.chap,
      line0: (document.getElementById('aup-l0') || {}).textContent || null,
      nChap: AUP.nChap,
    }));
    ck('★ 原生自动接下一章后，AUP.chap 跟上了', afterAuto.chap === c3.seq, 'AUP.chap=' + afterAuto.chap);
    ck('★ 原生自动接下一章后，文字也换成了新章',
      afterAuto.line0 === ly3.segs[0].text,
      '显示=' + JSON.stringify(String(afterAuto.line0).slice(0, 24)) +
      ' 期望=' + JSON.stringify(String(ly3.segs[0].text).slice(0, 24)));

    ck('过程中页面无 JS 报错', errs.length === 0, errs.slice(0, 2).join(' | '));
  } finally {
    try {
      py(`import sys; sys.path.insert(0, '${ROOT}')
import db
db.ex("DELETE FROM ab_session WHERE user_id=?", (${info.uid},))`);
    } catch (e) {}
    await browser.close();
  }
  console.log('');
  console.log('有声切章文字/点击定位：' + pass + ' 通过 / ' + fail + ' 失败');
  process.exit(fail ? 1 : 0);
})();
