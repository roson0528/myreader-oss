#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""书源本地镜像缓存清理（data/cache）

背景
    data/cache 是「书源文件在本地的一份镜像」，按需拉取，命名 b{book_id}_{book_id}{ext}。
    它一路增长到 15 GB（1582 个文件），但代码里没有 TTL、没有 LRU、没有容量上限，
    也没有任何定时清理 —— 这是 /data 分区（剩 175 GB）最大的隐性风险。

清理判据
    mtime 超过 --days 天（默认 30）。
    关于 mtime 的取舍：这些文件是下载来的，部分保留了源文件时间戳 —— 实测有 2 个
    文件的 mtime 是 2026-07-27，比项目立项（2026-09-08）还早六周，说明 mtime 并不
    严格等于「写入缓存的时间」。好在 1582 个文件里只有这 2 个如此，而且删错也只是
    下次阅读时重新拉一遍 —— 缓存命中条件本来就是 `exists && getsize == books.size`
    （covers.ensure_local），所以用 mtime 判龄是安全且足够的。

安全护栏
    * 默认干跑，只有显式 --apply 才真删。
    * 跳过最近 60 分钟内动过的文件，避免删掉正在被读的那一本。
    * 只删符合 b<数字>_<数字>.<扩展名> 的镜像文件；封面/临时文件（cv_/md5_/imp_/ph）
      不归本脚本管，避免误伤。

用法
    venv/bin/python tools/clean_cache.py                 # 干跑，只报告
    venv/bin/python tools/clean_cache.py --apply         # 真正删除
    venv/bin/python tools/clean_cache.py --days 60 --apply
"""
import os
import re
import sys
import time

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CACHE_DIR = os.path.join(BASE_DIR, "data", "cache")

# 只认「书源镜像」这一种命名，别的文件（封面/临时）不碰
MIRROR_RE = re.compile(r"^b\d+_\d+\.[A-Za-z0-9]{1,8}$")
# 最近这么久之内动过的文件一律跳过（防删正在读的）
RECENT_GUARD_SEC = 3600


def human(n):
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return "%.1f %s" % (n, unit)
        n /= 1024.0


def scan(days):
    now = time.time()
    cutoff = now - days * 86400
    victims, kept, other = [], 0, 0
    kept_bytes = other_bytes = 0
    by_ext = {}
    for fn in os.listdir(CACHE_DIR):
        p = os.path.join(CACHE_DIR, fn)
        try:
            if not os.path.isfile(p):
                continue
            st = os.stat(p)
        except OSError:
            continue
        if not MIRROR_RE.match(fn):
            other += 1
            other_bytes += st.st_size
            continue
        if st.st_mtime > cutoff or (now - st.st_mtime) < RECENT_GUARD_SEC:
            kept += 1
            kept_bytes += st.st_size
            continue
        victims.append((p, st.st_size, st.st_mtime))
        ext = fn.rsplit(".", 1)[-1].lower()
        d = by_ext.setdefault(ext, [0, 0])
        d[0] += 1
        d[1] += st.st_size
    return victims, kept, kept_bytes, other, other_bytes, by_ext


def main():
    args = sys.argv[1:]
    days = 30
    if "--days" in args:
        days = int(args[args.index("--days") + 1])
    apply_ = "--apply" in args

    if not os.path.isdir(CACHE_DIR):
        print("缓存目录不存在：%s" % CACHE_DIR)
        return 1

    victims, kept, kept_bytes, other, other_bytes, by_ext = scan(days)
    total = sum(v[1] for v in victims)

    print("缓存目录：%s" % CACHE_DIR)
    print("判龄阈值：mtime 超过 %d 天（并跳过最近 %d 分钟动过的）"
          % (days, RECENT_GUARD_SEC // 60))
    print("=" * 56)
    print("保留（未超期）镜像   : %5d 个  %10s" % (kept, human(kept_bytes)))
    print("非镜像文件（不归本脚本）: %5d 个  %10s" % (other, human(other_bytes)))
    print("待清理镜像           : %5d 个  %10s" % (len(victims), human(total)))
    if by_ext:
        print("-" * 56)
        print("待清理按格式：")
        for ext, (n, b) in sorted(by_ext.items(), key=lambda x: -x[1][1]):
            print("  %-8s %5d 个  %10s" % (ext, n, human(b)))
    if victims:
        oldest = min(v[2] for v in victims)
        print("-" * 56)
        print("其中最早的一份：%s" % time.strftime("%Y-%m-%d %H:%M", time.localtime(oldest)))

    if not apply_:
        print()
        print("以上为干跑结果，未删除任何文件。加 --apply 才会真删。")
        return 0

    done = 0
    freed = 0
    for p, size, _ in victims:
        try:
            os.remove(p)
            done += 1
            freed += size
        except OSError as e:
            print("  删除失败 %s：%s" % (os.path.basename(p), e))
    print()
    print("已删除 %d 个文件，释放 %s" % (done, human(freed)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
