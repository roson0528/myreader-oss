# -*- coding: utf-8 -*-
"""epub 解析（zipfile + xml），供封面/简介/阅读共用"""
import os, re, zipfile, posixpath
import xml.etree.ElementTree as ET
from urllib.parse import unquote

NS = {
    "opf": "http://www.idpf.org/2007/opf",
    "dc": "http://purl.org/dc/elements/1.1/",
    "xhtml": "http://www.w3.org/1999/xhtml",
    "container": "urn:oasis:names:tc:opendocument:xmlns:container",
    "calibre": "http://calibre.ebooks.com/2009/plugins",
}


def _nsparse(xml_bytes):
    try:
        return ET.fromstring(xml_bytes)
    except Exception:
        try:
            return ET.fromstring(xml_bytes.decode("utf-8", "replace"))
        except Exception:
            return None


def _find(e, tag):
    """按本地名查找（忽略命名空间前缀），含 e 自身与所有后代"""
    return next((x for x in e.iter() if x.tag.rsplit("}", 1)[-1] == tag), None)


def _text(e, tag):
    el = _find(e, tag)
    return (el.text or "").strip() if el is not None else ""


def _opf_path(z):
    try:
        root = _nsparse(z.read("META-INF/container.xml"))
        for rf in root.iter():
            if rf.tag.rsplit("}", 1)[-1] == "rootfile":
                return rf.get("full-path")
    except Exception:
        pass
    # 兜底：常见路径
    for cand in ("OEBPS/content.opf", "OPS/content.opf", "content.opf", "opf/content.opf"):
        try:
            z.getinfo(cand)
            return cand
        except Exception:
            continue
    return None


def read_epub_meta(epub_path):
    """返回 {title, author, description, cover_data}"""
    out = {"title": None, "author": None, "description": None, "cover_data": None}
    try:
        with zipfile.ZipFile(epub_path) as z:
            opf = _opf_path(z)
            if not opf:
                return out
            root = _nsparse(z.read(opf))
            if root is None:
                return out
            out["title"] = _text(root, "title")
            creator = _find(root, "creator")
            out["author"] = (creator.text or "").strip() if creator is not None else None
            desc = _find(root, "description")
            if desc is not None and desc.text:
                out["description"] = desc.text.strip()
            base = posixpath.dirname(opf)
            # 找封面
            cover_id = None
            for m in root.iter():
                if m.tag.rsplit("}", 1)[-1] == "meta" and m.get("name") == "cover":
                    cover_id = m.get("content")
                    break
            manifest = {}
            for item in root.iter():
                if item.tag.rsplit("}", 1)[-1] == "item":
                    iid = item.get("id")
                    manifest[iid] = {
                        "href": item.get("href"),
                        "media-type": item.get("media-type", ""),
                        "properties": item.get("properties", ""),
                    }
            href = None
            if cover_id and cover_id in manifest:
                href = manifest[cover_id]["href"]
            else:
                for iid, it in manifest.items():
                    if "cover-image" in it["properties"] or (
                            "image" in it["media-type"] and "cover" in iid.lower()):
                        href = it["href"]
                        break
                if href is None:
                    # 兜底：manifest 里第一个 image
                    for it in manifest.values():
                        if "image" in it["media-type"]:
                            href = it["href"]
                            break
            if href:
                full = posixpath.normpath(posixpath.join(base, href))
                try:
                    out["cover_data"] = z.read(full)
                except Exception:
                    out["cover_data"] = None
            return out
    except Exception:
        return out


# ---------------------------------------------------------------- 电子书内图片
# 「电子书内图片」刮削源用：按**阅读顺序**找书里第一张像封面的图。
#
# ★ 为什么要有它：很多电子书在制作时会把**纸质版封面的照片**直接放进正文第一页
#   （或扉页），却没有写成 EPUB 的 cover 元数据 —— read_epub_meta 的 cover_data
#   自然取不到，在线刮削又常常匹配到别的版本。这类书真正正确的封面就在文件里，
#   只要按读者翻页的顺序去找。
#
# ★ 为什么按 spine 顺序、而不是 manifest 里第一个 image：manifest 的顺序是
#   **打包顺序**，出版社 logo、图标、装饰线常常排在封面之前；spine 才是翻页顺序
#   （封面页 → 扉页 → 正文）。
_IMG_EXT = (".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".svg")
_IMG_MT = {".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png",
           ".gif": "image/gif", ".webp": "image/webp", ".bmp": "image/bmp",
           ".svg": "image/svg+xml"}
# 小于这个边长的图不当封面（图标/logo/分割线）。一个都不够大时退而取面积最大的。
_MIN_SIDE = 240
# 字节下限只用来挡 1×1 追踪像素这类退化文件：定 2048 会误杀纯色的真封面
# （200×200 的纯色 PNG 才 ~1KB），所以放到 512，主要靠尺寸判断。
_MIN_BYTES = 512


def _img_mt(path):
    ext = os.path.splitext(path.lower().split("?")[0])[1]
    return _IMG_MT.get(ext, "")


def _img_size(data):
    """图片像素尺寸；打不开（含纯矢量 SVG）返回 (0, 0)"""
    try:
        import io
        from PIL import Image
        with Image.open(io.BytesIO(data)) as im:
            return im.size
    except Exception:
        return (0, 0)


def _epub_image_hrefs(doc):
    """从一页 HTML/SVG 里按出现顺序取出图片引用（img src 与 SVG image href）"""
    text = doc.decode("utf-8", "ignore")
    out = [m.group(1) for m in
           re.finditer(r"<img\b[^>]*?\bsrc\s*=\s*[\"']([^\"']+)[\"']", text, re.I)]
    out += [m.group(1) for m in
            re.finditer(r"<image\b[^>]*?\b(?:xlink:href|href)\s*=\s*[\"']([^\"']+)[\"']", text, re.I)]
    return out


def read_epub_inner_image(epub_path, min_side=_MIN_SIDE):
    """按阅读顺序取电子书里「最像封面」的一张图，返回 (data, media_type)。

    顺序：spine 第 1 页 → 第 2 页 → …… 出现的第一张**够大**的图；
    都不够大就取面积最大的一张；书里没有可用图片则 (None, None)。
    """
    try:
        with zipfile.ZipFile(epub_path) as z:
            opf = _opf_path(z)
            if not opf:
                return (None, None)
            root = _nsparse(z.read(opf))
            if root is None:
                return (None, None)
            base = posixpath.dirname(opf)
            manifest = {}
            for it in root.iter():
                if it.tag.rsplit("}", 1)[-1] == "item":
                    manifest[it.get("id")] = {"href": it.get("href") or "",
                                              "media-type": it.get("media-type", "")}
            spine = []
            for it in root.iter():
                if it.tag.rsplit("}", 1)[-1] == "itemref":
                    m = manifest.get(it.get("idref"))
                    if m:
                        spine.append(m)
            if not spine:  # 没有 spine 的坏 epub：退回 manifest 顺序
                spine = list(manifest.values())
            cands = []  # [(zip 内完整路径, media-type)]
            for item in spine:
                href = (item["href"] or "").split("#")[0]
                if not href:
                    continue
                full = posixpath.normpath(posixpath.join(base, unquote(href)))
                if full.lower().endswith(_IMG_EXT):
                    cands.append((full, item["media-type"] or _img_mt(full)))
                    continue
                try:  # 页面文件：读出里面的 <img>/<image>
                    doc = z.read(full)
                except Exception:
                    continue
                here = posixpath.dirname(full)
                for ref in _epub_image_hrefs(doc):
                    ref = ref.split("#")[0].strip()
                    if not ref or ref.startswith(("http://", "https://", "data:", "//")):
                        continue
                    cands.append((posixpath.normpath(posixpath.join(here, unquote(ref))), ""))
            best = None
            for full, mt in cands:
                try:
                    data = z.read(full)
                except Exception:
                    continue
                if not data or len(data) < _MIN_BYTES:
                    continue
                w, h = _img_size(data)
                if not w or not h:
                    continue
                mt = mt or _img_mt(full)
                if min(w, h) >= min_side:
                    return (data, mt)  # ★ 阅读顺序优先：第一张够大的就用它
                # 兜底只在「立式/方形」里挑最大的。★ 实测有本书（玫瑰之翼）整本的图
                # 只有一张 320×148 的横幅装饰图，横图当封面比占位图更糟 —— 这种情况
                # 宁可不给，让上层继续顺延、或落到占位图。
                if h >= w * 0.9 and (best is None or w * h > best[0]):
                    best = (w * h, data, mt)
            if best:
                return (best[1], best[2])
            return (None, None)
    except Exception:
        return (None, None)


_toc_cache = {}  # (epub_path, mtime) -> toc，避免每次翻页重复解析整本 epub


def read_epub_toc(epub_path):
    """返回 [{idx, href, fragment, title, front, level}]。
    优先按 ncx/nav 目录（含锚点 fragment 与层级，可精确定位到章节内位置）；
    目录缺失或过于粗糙（条目数远少于 spine 文件数，如套装书只列了分册封面）
    时回退为按 spine 顺序分章，并从各 HTML 的 <title> 提取章节标题。"""
    try:
        mtime = os.path.getmtime(epub_path)
    except Exception:
        mtime = 0
    key = (epub_path, mtime)
    cached = _toc_cache.get(key)
    if cached is not None:
        return cached
    toc = _build_epub_toc(epub_path)
    _toc_cache[key] = toc
    if len(_toc_cache) > 50:
        _toc_cache.pop(next(iter(_toc_cache)))
    return toc


def _build_epub_toc(epub_path):
    toc = []
    try:
        with zipfile.ZipFile(epub_path) as z:
            opf = _opf_path(z)
            if not opf:
                return toc
            root = _nsparse(z.read(opf))
            if root is None:
                return toc
            base = posixpath.dirname(opf)
            manifest = {}
            for item in root.iter():
                if item.tag.rsplit("}", 1)[-1] == "item":
                    manifest[item.get("id")] = item.get("href")
            # spine 顺序（实际阅读顺序）
            spine = []
            for item in root.iter():
                if item.tag.rsplit("}", 1)[-1] == "itemref":
                    spine.append(item.get("idref"))
            # 优先：ncx / nav 目录（含锚点 fragment 与层级）
            nav_items = _epub_nav_items(z, opf, root, manifest)
            if nav_items and not _toc_too_sparse(nav_items, spine):
                for idx, ni in enumerate(nav_items):
                    toc.append({"href": ni["href"], "fragment": ni.get("fragment", ""),
                                "title": ni["title"] or _basename_title(ni["href"]),
                                "idx": idx, "level": ni.get("level", 0),
                                "front": _is_front(ni["href"], ni["title"], "")})
                return toc
            # 回退：按 spine 顺序（无 fragment，无法定位章节内锚点），
            # 标题从各 HTML 的 <title> 提取，未提取到才用文件名兜底
            for idx, idref in enumerate(spine):
                href = manifest.get(idref)
                if not href:
                    continue
                full = posixpath.normpath(posixpath.join(base, href))
                title = _spine_title(z, full)
                toc.append({"href": full, "fragment": "", "title": title or _basename_title(full),
                            "idx": idx, "idref": idref,
                            "front": _is_front(full, title, idref), "level": 0})
            return toc
    except Exception:
        return toc


def _toc_too_sparse(nav_items, spine):
    """ncx/nav 目录是否过于粗糙：条目数远少于 spine 文件数（如套装书只列分册封面）。"""
    if not spine or not nav_items:
        return False
    return len(spine) > len(nav_items) * 3 and len(spine) - len(nav_items) >= 8


def _spine_title(z, href):
    """从 HTML 头部 <title> 提取章节标题（轻量：只读前 4KB）。"""
    try:
        head = z.read(href)[:4096].decode("utf-8", "replace")
        m = re.search(r"<title[^>]*>(.*?)</title>", head, re.S | re.I)
        if m:
            t = re.sub(r"<[^>]+>", "", m.group(1))
            t = re.sub(r"\s+", " ", t).strip()
            if t:
                return t
    except Exception:
        pass
    return ""


def _basename_title(full):
    s = os.path.splitext(os.path.basename(full))[0]
    return s


def _epub_nav_items(z, opf_path, root, manifest):
    """解析 toc.ncx 或 epub3 nav.xhtml，返回 [{href, fragment, title, level}]（展平，含层级）。
    href 为 zip 内完整路径，fragment 为章节内锚点（可为空），level 为目录层级深度。"""
    items = []
    opf_dir = posixpath.dirname(opf_path)
    # ---- 1) ncx navMap（树形 navPoint 递归展平） ----
    ncx_href = None
    for item in root.iter():
        if item.tag.rsplit("}", 1)[-1] == "item" and "ncx" in (item.get("media-type") or "").lower():
            ncx_href = item.get("href")
            break
    if ncx_href is None:
        sp = _find(root, "spine")
        if sp is not None:
            ncx_href = manifest.get(sp.get("toc"))
    if ncx_href is None:
        for cand in ("toc.ncx", "OEBPS/toc.ncx", "OPS/toc.ncx"):
            if cand in set(manifest.values()):
                ncx_href = cand
                break
    if ncx_href:
        full_ncx = posixpath.normpath(posixpath.join(opf_dir, ncx_href))
        try:
            ncx = _nsparse(z.read(full_ncx))
            if ncx is not None:
                nm = _find(ncx, "navMap")
                if nm is not None:
                    ncx_dir = posixpath.dirname(full_ncx)
                    def walk(parent, level):
                        for child in parent:
                            if child.tag.rsplit("}", 1)[-1] != "navPoint":
                                continue
                            title, src = "", ""
                            for sub in child:
                                stag = sub.tag.rsplit("}", 1)[-1]
                                if stag == "navLabel":
                                    t = _find(sub, "text")
                                    title = (t.text or "").strip() if t is not None else ""
                                elif stag == "content":
                                    src = sub.get("src") or ""
                            href = src.split("#", 1)[0]
                            frag = src.split("#", 1)[1] if "#" in src else ""
                            if href:
                                items.append({"href": posixpath.normpath(posixpath.join(ncx_dir, href)),
                                              "fragment": frag, "title": title, "level": level})
                            walk(child, level + 1)
                    walk(nm, 0)
        except Exception:
            pass
    if items:
        return items
    # ---- 2) epub3 nav.xhtml（ol/li/a 结构，HTMLParser 解析层级与锚点） ----
    nav_href = None
    for item in root.iter():
        if item.tag.rsplit("}", 1)[-1] == "item" and "nav" in (item.get("properties") or ""):
            nav_href = item.get("href")
            break
    if nav_href:
        full_nav = posixpath.normpath(posixpath.join(opf_dir, nav_href))
        try:
            doc = z.read(full_nav).decode("utf-8", "replace")
            items = _parse_nav_html(doc, posixpath.dirname(full_nav))
        except Exception:
            pass
    return items


def _parse_nav_html(doc, nav_dir):
    """解析 epub3 nav.xhtml 的目录链接（<nav epub:type='toc'> 内 ol/li/a），
    返回 [{href, fragment, title, level}]。"""
    from html.parser import HTMLParser
    items = []
    # 只取 toc 导航块，排除 page-list / landmarks 等
    m = re.search(r'<nav[^>]*epub:type="toc"[^>]*>(.*?)</nav>', doc, re.S | re.I)
    block = m.group(1) if m else doc

    class P(HTMLParser):
        def __init__(self):
            super().__init__()
            self.level = 0
            self.in_a = False
            self.a_href = ''
            self.a_text = []
        def handle_starttag(self, tag, attrs):
            a = dict(attrs)
            if tag == 'ol':
                self.level += 1
            elif tag == 'a':
                self.in_a = True
                self.a_href = a.get('href', '') or ''
                self.a_text = []
        def handle_endtag(self, tag):
            if tag == 'ol':
                self.level = max(0, self.level - 1)
            elif tag == 'a' and self.in_a:
                self.in_a = False
                href = self.a_href
                title = ''.join(self.a_text).strip()
                if href and not href.startswith(('http:', 'https:', 'data:', 'mailto:')):
                    clean = href.split('#', 1)[0]
                    frag = href.split('#', 1)[1] if '#' in href else ''
                    if clean:
                        items.append({"href": posixpath.normpath(posixpath.join(nav_dir, clean)),
                                      "fragment": frag, "title": title,
                                      "level": max(0, self.level - 1)})
        def handle_data(self, data):
            if self.in_a:
                self.a_text.append(data)
    p = P()
    try:
        p.feed(block)
    except Exception:
        pass
    return items


_FRONT_TITLES = {"封面", "封皮", "目录", "扉页", "版权页", "书名页",
                 "cover", "table of contents", "contents", "title page",
                 "copyright", "front matter", "frontmatter"}


def _is_front(href, title, idref):
    t = (title or "").strip().lower()
    if t in _FRONT_TITLES:
        return True
    h = (href or "").lower()
    i = (idref or "").lower()
    for k in ("cover", "titlepage", "copyright", "frontmatter", "front-matter",
              "halftitle", "colophon", "toc", "nav"):
        if k in h or k in i or k in t:
            return True
    base = os.path.basename(href).lower()
    if base in ("cover.xhtml", "cover.html", "titlepage.xhtml", "titlepage.html"):
        return True
    return False


# ---- 大章节虚拟切分：多章合一的巨型单文件，按目录锚点切成小段，避免整章 CSS 多栏全量布局卡顿 ----
_BLOCK_RE = re.compile(r'<(p|h[1-6]|div|section|article|li|blockquote|tr|figure|td|th)\b', re.I)
_ID_RE = re.compile(r'\bid\s*=\s*["\']([^"\']+)["\']', re.I)
_seg_cache = {}  # (epub_path, href) -> [(fragment, segment_html)]


def _extract_body(raw):
    body = re.search(r"<body[^>]*>(.*?)</body>", raw, re.S | re.I)
    return body.group(1) if body else raw


def _segment_by_anchors(content):
    """按锚点（id）所在块级元素边界切分 HTML，返回 [(fragment, segment_html)]。
    首段 fragment=''（第一个锚点前的引子）。锚点不足 2 个时返回 [('', content)]。
    说明：切在块级标签边界，绝大多数段为完整块级元素序列（标签闭合）；
    含嵌套 div 锚点的少数首尾段可能标签不闭合，浏览器会容错，不影响正文阅读。"""
    return _segment_by_anchors_regex(content)


def _segment_by_anchors_regex(content):
    """正则兜底：按锚点所在块级元素边界切分（边界可能穿过嵌套标签，浏览器容错）。"""
    import bisect
    block_pos = [m.start() for m in _BLOCK_RE.finditer(content)]
    if not block_pos:
        return [('', content)]
    ids = [(m.start(), m.group(1)) for m in _ID_RE.finditer(content)]
    if not ids:
        return [('', content)]
    boundaries = {}
    for pos, frag in ids:
        k = bisect.bisect_right(block_pos, pos) - 1
        if k >= 0:
            bpos = block_pos[k]
            if bpos not in boundaries:
                boundaries[bpos] = frag
    if len(boundaries) <= 1:
        return [('', content)]
    sorted_bounds = sorted(boundaries)
    segments = []
    if sorted_bounds[0] > 0:
        pre = content[:sorted_bounds[0]]
        if pre.strip():
            segments.append(('', pre))
    for i, bpos in enumerate(sorted_bounds):
        end = sorted_bounds[i + 1] if i + 1 < len(sorted_bounds) else len(content)
        segments.append((boundaries[bpos], content[bpos:end]))
    return segments


_STUB_TEXT_CHARS = 120     # 去标签后正文少于此字数 → 判定为「章节标题页」
_MAX_CHAPTER_FILES = 24    # 续读文件数上限，防目录极稀疏时拼进整本书
_stub_cache = {}           # (epub_path, href) -> bool
_spine_cache = {}          # (epub_path, mtime) -> [href, ...]


def _spine_hrefs(epub_path):
    """按 spine 顺序返回 zip 内完整路径列表（缓存）。"""
    try:
        mtime = os.path.getmtime(epub_path)
    except Exception:
        mtime = 0
    key = (epub_path, mtime)
    cached = _spine_cache.get(key)
    if cached is not None:
        return cached
    hrefs = []
    try:
        with zipfile.ZipFile(epub_path) as z:
            opf = _opf_path(z)
            if opf:
                root = _nsparse(z.read(opf))
                if root is not None:
                    base = posixpath.dirname(opf)
                    manifest = {it.get("id"): it.get("href") for it in root.iter()
                                if it.tag.rsplit("}", 1)[-1] == "item"}
                    for it in root.iter():
                        if it.tag.rsplit("}", 1)[-1] == "itemref":
                            h = manifest.get(it.get("idref"))
                            if h:
                                hrefs.append(posixpath.normpath(posixpath.join(base, h)))
    except Exception:
        hrefs = []
    _spine_cache[key] = hrefs
    if len(_spine_cache) > 30:
        _spine_cache.pop(next(iter(_spine_cache)))
    return hrefs


def _is_stub_file(epub_path, href):
    """目标文件是否只是「章节标题页」——去标签后几乎没有正文。

    典型形态是 azw3/mobi 转换产物把每个标题单独成页（正文在紧随其后的文件里），
    例如 zipped 的 text/part0009.html 只有一行标题、text/part0010.html 才是正文。
    """
    key = (epub_path, href)
    cached = _stub_cache.get(key)
    if cached is not None:
        return cached
    stub = False
    try:
        with zipfile.ZipFile(epub_path) as z:
            raw = z.read(href).decode("utf-8", "replace")
        txt = re.sub(r"<[^>]+>", " ", _extract_body(raw))
        txt = re.sub(r"&[a-zA-Z#0-9]+;", " ", txt)
        stub = len(re.sub(r"\s+", "", txt)) < _STUB_TEXT_CHARS
    except Exception:
        stub = False
    _stub_cache[key] = stub
    if len(_stub_cache) > 500:
        _stub_cache.pop(next(iter(_stub_cache)))
    return stub


def _chapter_files(epub_path, href):
    """返回该章应当读取的文件列表（含 href 自身）。

    EPUB 的目录项只标记章节「起点」，正文可能落在紧随其后的文件里。若只读目录
    指向的那一个文件，遇到「标题单独成页」的书就会点进去只有一行标题、听书时
    整章被当成空白跳过。所以这里按目录语义向后补读到下一个目录项之前。

    目标文件本身就有正文时原样返回单文件，行为与改动前完全一致。
    """
    spine = _spine_hrefs(epub_path)
    if not spine or href not in spine or not _is_stub_file(epub_path, href):
        return [href]
    start = spine.index(href)
    end = len(spine)
    for c in read_epub_toc(epub_path):
        h = c.get("href")
        if h == href or h not in spine:
            continue
        i = spine.index(h)
        if start < i < end:      # 取本章之后最近的一个目录项作为终点
            end = i
    files = spine[start:end]
    return files[:_MAX_CHAPTER_FILES] or [href]


def _chapter_segment(epub_path, href, fragment=""):
    """取单个文件的正文片段（含锚点切分缓存）；读不到返回 None。"""
    key = (epub_path, href)
    segs = _seg_cache.get(key)
    if segs is None:
        try:
            with zipfile.ZipFile(epub_path) as z:
                raw = z.read(href).decode("utf-8", "replace")
        except Exception:
            return None
        segs = _segment_by_anchors(_extract_body(raw))
        _seg_cache[key] = segs
        if len(_seg_cache) > 40:
            _seg_cache.pop(next(iter(_seg_cache)))
    # 命中 fragment 对应段；未命中/无 fragment 返回整章（合并，等价于不切分）
    if fragment:
        for frag, seg in segs:
            if frag == fragment:
                return seg
    return ''.join(s for _, s in segs)


def _rewrite_refs(content, base, resource_base):
    """重写资源引用并把 base 目录下的相对路径转成绝对（供 resource 接口取用）。"""
    def to_abs(url):
        if url.startswith(("http://", "https://", "data:", "#")):
            return None
        clean = url.split("#")[0].split("?")[0]
        if not clean:
            return None
        return posixpath.normpath(posixpath.join(base, clean))

    def rw(m):
        pre, url = m.group(1), m.group(2)
        full = to_abs(url)
        if full is None:
            return m.group(0)
        return f'{pre}"{resource_base}{_urlenc(full)}"'

    # 1) src 属性（img / script 等资源）
    content = re.sub(r'(\ssrc\s*=\s*)"([^"]+)"', rw, content)
    # 2) <link href>（样式表）与 <image href/xlink:href>（SVG 图片）资源；
    #    <a href> 不在此列，保留书内导航链接
    content = re.sub(r'((?:<link\b|<image\b)[^>]*?\s(?:xlink:)?href\s*=\s*)"([^"]+)"', rw, content)
    # 图片懒加载 + 异步解码：降低分栏渲染与翻页时的主线程阻塞
    content = re.sub(r'<img\b(?!\s+loading\s*=)', '<img loading="lazy" decoding="async" ', content)
    return content


def read_epub_chapter(epub_path, href, resource_base, fragment=""):
    """读取章节 HTML，返回处理后的 html 字符串。

    fragment 非空时按目录锚点虚拟切分，只返回该锚点对应的小段（大文件书翻页提速）。
    目标文件若只是「章节标题页」，会把紧随其后的正文文件一并读出拼接
    （见 _chapter_files），避免出现「点进章节只看到标题、看不到正文」。
    只重写资源引用（img src / link href / image href），保留 <a href> 书内导航链接。"""
    out = []
    for i, f in enumerate(_chapter_files(epub_path, href)):
        content = _chapter_segment(epub_path, f, fragment if i == 0 else "")
        if content is None:
            continue
        out.append(_rewrite_refs(content, posixpath.dirname(f), resource_base))
    return "".join(out) if out else "<p>章节无法读取</p>"


def _urlenc(s):
    import urllib.parse
    return urllib.parse.quote(s, safe="/")


def read_epub_resource(epub_path, href):
    try:
        with zipfile.ZipFile(epub_path) as z:
            return z.read(href)
    except Exception:
        return None
