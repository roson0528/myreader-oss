#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""管理员删除用户：单删 / 批量删 / 自我删除保护 / 不存在用户
关键点：删除前给目标用户在「每一张引用用户的表」里都造上数据，
删除后逐表核对归零，并确认公开内容（书、文章、审计）按设计保留。
曾经的问题：book_grants 的归属列是 from_user_id/to_user_id 而不是 user_id，
DELETE ... WHERE user_id 直接抛 no such column → HTTP 500 → 前端「请求失败」。
"""
import sys, os, json, ssl, time, urllib.request, urllib.parse, urllib.error
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
import db, auth

BASE = "https://127.0.0.1:9000"
CTX = ssl._create_unverified_context()
_pass = _fail = 0


def check(name, ok, extra=""):
    global _pass, _fail
    print(("  [OK] " if ok else "  [FAIL] ") + name + (("  " + str(extra)) if extra else ""))
    if ok:
        _pass += 1
    else:
        _fail += 1


def req(method, path, token=None, body=None):
    data = json.dumps(body).encode() if body is not None else None
    r = urllib.request.Request(BASE + path, data=data, method=method,
                               headers={'X-BM-No-Push': '1'})   # 测试请求：别真发 Server酱
    if token:
        r.add_header("Authorization", "Bearer " + token)
    if data:
        r.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(r, context=CTX, timeout=30) as resp:
            return resp.status, json.loads(resp.read().decode() or "{}")
    except urllib.error.HTTPError as e:
        raw = e.read().decode()
        try:
            return e.code, json.loads(raw or "{}")
        except Exception:
            return e.code, {"raw": raw[:200]}


def login(un, pw):
    fd = urllib.parse.urlencode({"username": un, "password": pw}).encode()
    r = urllib.request.Request(BASE + "/api/login", data=fd, method="POST")
    with urllib.request.urlopen(r, context=CTX, timeout=30) as resp:
        return json.loads(resp.read().decode())["token"]


# 每张引用用户的表 → 该用户的归属列
OWN = [("shelves", "user_id"), ("shelf_collections", "user_id"), ("progress", "user_id"),
       ("settings", "user_id"), ("notes", "user_id"), ("shares", "user_id"),
       ("download_logs", "user_id"), ("reading_time", "user_id"), ("convert_logs", "user_id"),
       ("user_leaves", "user_id"), ("leaf_gain", "user_id"), ("leaf_spend", "user_id"),
       ("signin_log", "user_id"), ("group_upgrades", "user_id"), ("share_requests", "requester_id")]
# 这两张的归属列名不一样，是本次 bug 的根源
SPECIAL = [("book_grants", "from_user_id"), ("book_grants", "to_user_id"), ("messages", "to_id"), ("messages", "from_id")]
# 按设计要保留的（公开内容 / 审计留痕）
KEPT = [("booklists", "author_id"), ("booklist_comments", "user_id"),
        ("book_reports", "user_id"), ("audit_logs", "user_id"), ("books", "owner_id")]


def make_user(username, role="user", group=5):
    return db.ex("INSERT INTO users (username,password_hash,role,quota,enabled,group_id,name,email,phone,created_at) "
                 "VALUES (?,?,?,?,?,?,?,?,?,?)",
                 (username, auth.hash_password("zztest"), role, 50, 1, group,
                  username, username + "@local.test", "19900000000", db.now()))


def seed(uid, other_uid):
    """把这个用户的所有私有数据 + 公开内容都造上"""
    db.ex("INSERT INTO shelves (user_id,book_id,added_at) VALUES (?,?,?)", (uid, 1, db.now()))
    db.ex("INSERT INTO shelf_collections (user_id,name,created_at,sort_order) VALUES (?,?,?,?)",
          (uid, "测试收藏夹", db.now(), 0))
    db.ex("INSERT INTO progress (user_id,book_id,position,percent,updated_at) VALUES (?,?,?,?,?)",
          (uid, 1, "10", 5.0, db.now()))
    db.ex("INSERT INTO settings (user_id,theme) VALUES (?,?)", (uid, "dark"))
    db.ex("INSERT INTO notes (user_id,book_id,updated_at) VALUES (?,?,?)", (uid, 1, db.now()))
    db.ex("INSERT INTO shares (user_id,book_id,token,created_at) VALUES (?,?,?,?)",
          (uid, 1, "tok" + str(uid), db.now()))
    db.ex("INSERT INTO download_logs (user_id,book_id,created_at) VALUES (?,?,?)", (uid, 1, db.now()))
    db.ex("INSERT INTO reading_time (user_id,total_seconds,updated_at) VALUES (?,?,?)", (uid, 60, db.now()))
    db.ex("INSERT INTO convert_logs (user_id,book_id,created_at) VALUES (?,?,?)", (uid, 1, db.now()))
    db.ex("INSERT INTO user_leaves (user_id,balance,updated_at) VALUES (?,?,?)", (uid, 10, db.now()))
    db.ex("INSERT INTO leaf_gain (user_id,kind,leaves,created_at) VALUES (?,?,?,?)", (uid, "signin", 1, db.now()))
    db.ex("INSERT INTO leaf_spend (user_id,book_id,kind,leaves,created_at) VALUES (?,?,?,?,?)",
          (uid, 1, "download", 1, db.now()))
    db.ex("INSERT INTO signin_log (user_id,signin_date,leaves,streak,created_at) VALUES (?,?,?,?,?)",
          (uid, db.today(), 1, 1, db.now()))
    db.ex("INSERT INTO group_upgrades (user_id,to_group_id,cost,months,status,created_at) VALUES (?,?,?,?,?,?)",
          (uid, 4, 100, 1, "active", db.now()))
    db.ex("INSERT INTO share_requests (book_id,requester_id,status,created_at) VALUES (?,?,?,?)",
          (1, uid, "pending", db.now()))
    # book_grants 有 UNIQUE(book_id,to_user_id)，用 uid 当 book_id 免得多个测试用户互相撞
    db.ex("INSERT INTO book_grants (book_id,from_user_id,to_user_id,created_at) VALUES (?,?,?,?)",
          (uid, uid, other_uid, db.now()))
    db.ex("INSERT INTO book_grants (book_id,from_user_id,to_user_id,created_at) VALUES (?,?,?,?)",
          (uid, other_uid, uid, db.now()))
    db.add_message(uid, "给待删用户的消息", "正文", kind="system")
    db.add_message(other_uid, "待删用户发出的消息", "正文", kind="pm", from_id=uid)
    # 公开内容 / 审计：按设计要保留
    db.ex("INSERT INTO book_reports (book_id,user_id,reason,status,created_at) VALUES (?,?,?,?,?)",
          (1, uid, "测试举报", "pending", db.now()))
    db.ex("INSERT INTO audit_logs (user_id,username,action,target_type,target_id,detail,created_at) "
          "VALUES (?,?,?,?,?,?,?)", (uid, "seed", "seed", "user", uid, "造数据", db.now()))


def counts(uid):
    out = {}
    for t, col in OWN + SPECIAL:
        key = t + "." + col
        out[key] = db.q("SELECT COUNT(*) n FROM %s WHERE %s=?" % (t, col), (uid,), one=True)["n"]
    return out


def kept_counts(uid):
    return {t + "." + c: db.q("SELECT COUNT(*) n FROM %s WHERE %s=?" % (t, c), (uid,), one=True)["n"]
            for t, c in KEPT}


print("=== 0. 准备临时管理员与待删用户 ===")
# 清扫上次中断留下的测试账号
for _u in db.q("SELECT id FROM users WHERE username LIKE 'zzdel%' OR username LIKE 'zzadmdel%'"):
    _i = _u["id"]
    for _t, _c in (("messages", "to_id"), ("messages", "from_id"), ("book_grants", "from_user_id"),
                   ("book_grants", "to_user_id"), ("share_requests", "requester_id"),
                   ("shelves", "user_id"), ("shelf_collections", "user_id"), ("progress", "user_id"),
                   ("settings", "user_id"), ("notes", "user_id"), ("shares", "user_id"),
                   ("download_logs", "user_id"), ("reading_time", "user_id"), ("convert_logs", "user_id"),
                   ("user_leaves", "user_id"), ("leaf_gain", "user_id"), ("leaf_spend", "user_id"),
                   ("signin_log", "user_id"), ("group_upgrades", "user_id"),
                   ("book_reports", "user_id"), ("booklist_comments", "user_id"),
                   ("booklists", "author_id"), ("audit_logs", "user_id")):
        db.ex("DELETE FROM %s WHERE %s=?" % (_t, _c), (_i,))
    db.ex("DELETE FROM users WHERE id=?", (_i,))
ts = str(int(time.time()))[-6:]
adm = make_user("zzadmdel" + ts, role="admin", group=1)
tok = login("zzadmdel" + ts, "zztest")
print("   临时管理员 id =", adm)

print()
print("=== 1. 单删：目标用户在每张表都有数据 ===")
u1 = make_user("zzdel1" + ts)
other = make_user("zzdel0" + ts)
seed(u1, other)
c1 = counts(u1)
empty = [k for k, v in c1.items() if v == 0]
check("每一张引用表都造上了数据", not empty, "缺: " + str(empty))
st, r = req("DELETE", "/api/admin/users/%d" % u1, tok)
check("删除返回 200（原来这里 500）", st == 200, "%s %s" % (st, r))
check("用户行已删除", db.q("SELECT id FROM users WHERE id=?", (u1,), one=True) is None)
c1b = counts(u1)
bad = {k: v for k, v in c1b.items() if v}
check("所有私有数据 + 两个方向的授权/消息都已清空", not bad, str(bad))
check("书名下的授权（别人授予他）也清了",
      db.q("SELECT COUNT(*) n FROM book_grants WHERE from_user_id=? OR to_user_id=?", (u1, u1), one=True)["n"] == 0)
check("写下了删除审计", db.q("SELECT COUNT(*) n FROM audit_logs WHERE action='user_delete' AND target_id=?",
                              (u1,), one=True)["n"] == 1)
k1 = kept_counts(u1)
check("其公开内容与审计留痕保留（书/文章/举报/审计）", k1["audit_logs.user_id"] >= 1, str(k1))
check("没有留下指向已删用户的死信",
      db.q("SELECT COUNT(*) n FROM messages WHERE to_id=? OR from_id=?", (u1, u1), one=True)["n"] == 0)

print()
print("=== 2. 重复删除 / 不存在的用户 ===")
st, r = req("DELETE", "/api/admin/users/%d" % u1, tok)
check("删已删除的用户返回 404 且有中文提示", st == 404 and "不存在" in str(r.get("detail", "")), "%s %s" % (st, r))
st, r = req("DELETE", "/api/admin/users/99999999", tok)
check("删不存在的用户返回 404", st == 404, "%s %s" % (st, r))

print()
print("=== 3. 不能删除自己 ===")
st, r = req("DELETE", "/api/admin/users/%d" % adm, tok)
check("删自己返回 400", st == 400 and "自己" in str(r.get("detail", "")), "%s %s" % (st, r))
check("管理员自己仍然存在", db.q("SELECT id FROM users WHERE id=?", (adm,), one=True) is not None)

print()
print("=== 4. 批量删除 ===")
b1, b2 = make_user("zzdelb1" + ts), make_user("zzdelb2" + ts)
seed(b1, other); seed(b2, other)
st, r = req("POST", "/api/admin/users/batch", tok, {"action": "delete", "user_ids": [b1, b2]})
check("批量删除返回 200", st == 200, "%s %s" % (st, r))
check("两个用户都被删除",
      db.q("SELECT COUNT(*) n FROM users WHERE id IN (?,?)", (b1, b2), one=True)["n"] == 0)
b1c = counts(b1)
check("用户1 数据清空", not {k: v for k, v in b1c.items() if v}, str({k: v for k, v in b1c.items() if v}))
b2c = counts(b2)
check("用户2 数据清空", not {k: v for k, v in b2c.items() if v}, str({k: v for k, v in b2c.items() if v}))

print()
print("=== 5. 批量里混入自己（应被剔除而不是报错）===")
b3 = make_user("zzdelb3" + ts)
seed(b3, other)
st, r = req("POST", "/api/admin/users/batch", tok, {"action": "delete", "user_ids": [b3, adm]})
check("批量删除跳过自己并成功", st == 200, "%s %s" % (st, r))
check("目标用户被删除", db.q("SELECT id FROM users WHERE id=?", (b3,), one=True) is None)
check("管理员自己还在", db.q("SELECT id FROM users WHERE id=?", (adm,), one=True) is not None)

print()
print("=== 6. 事务性：删一半失败要整体回滚 ===")
u6 = make_user("zzdel6" + ts)
db.ex("INSERT INTO shelves (user_id,book_id,added_at) VALUES (?,?,?)", (u6, 1, db.now()))
import app as _app
orig = _app._USER_OWN_TABLES
_app._USER_OWN_TABLES = (("shelves", "user_id"), ("__not_a_table__", "user_id"))
try:
    _app.purge_user_data(u6)
    check("坏表名应当抛异常", False)
except Exception as e:
    check("坏表名抛异常", "no such table" in str(e), str(e)[:80])
finally:
    _app._USER_OWN_TABLES = orig
check("回滚后用户仍在（没有半残）", db.q("SELECT id FROM users WHERE id=?", (u6,), one=True) is not None)
check("回滚后 shelves 记录仍在（第一步也回滚了）",
      db.q("SELECT COUNT(*) n FROM shelves WHERE user_id=?", (u6,), one=True)["n"] == 1)
req("DELETE", "/api/admin/users/%d" % u6, tok)

print()
print("=== 清理 ===")
for uid in (other,):
    db.ex("DELETE FROM messages WHERE to_id=? OR from_id=?", (uid, uid))
    db.ex("DELETE FROM book_grants WHERE from_user_id=? OR to_user_id=?", (uid, uid))
    db.ex("DELETE FROM share_requests WHERE requester_id=?", (uid,))
    db.ex("DELETE FROM user_leaves WHERE user_id=?", (uid,))
    db.ex("DELETE FROM signin_log WHERE user_id=?", (uid,))
    db.ex("DELETE FROM audit_logs WHERE user_id=?", (uid,))
    db.ex("DELETE FROM users WHERE id=?", (uid,))
# 第 1 步留下的公开内容（按设计保留）也一并清掉，别污染真实站点
for uid in (u1, b1, b2, b3, u6):
    db.ex("DELETE FROM booklists WHERE author_id=?", (uid,))
    db.ex("DELETE FROM booklist_comments WHERE user_id=?", (uid,))
    db.ex("DELETE FROM book_reports WHERE user_id=?", (uid,))
    db.ex("DELETE FROM audit_logs WHERE user_id=? OR target_id=?", (uid, uid))
db.ex("DELETE FROM messages WHERE to_id=? OR from_id=?", (adm, adm))
db.ex("DELETE FROM audit_logs WHERE user_id=? OR target_id=?", (adm, adm))
db.ex("DELETE FROM user_leaves WHERE user_id=?", (adm,))
db.ex("DELETE FROM signin_log WHERE user_id=?", (adm,))
db.ex("DELETE FROM users WHERE id=?", (adm,))
left = db.q("SELECT COUNT(*) n FROM users WHERE username LIKE 'zzdel%' OR username LIKE 'zzadmdel%'", one=True)["n"]
check("临时账号无残留", left == 0, str(left))
print()
print("结果: %d 通过 / %d 失败" % (_pass, _fail))
sys.exit(1 if _fail else 0)
