# -*- coding: utf-8 -*-
"""极简页（/lite）正文里**链接清理**的回归测试。

背景（站长报的 bug）：在极简页打开一本 epub、点目录，页面上糊出一坨 JSON：

    {"detail":[{"type":"int_parsing","loc":["path","idx"],
                "msg":"Input should be a valid integer, unable to parse string as an integer",
                "input":"part0004_split_000.html"}]}

根因：epub 正文里自带**同书互链**（`chap0.xhtml`、`part0004_split_000.html` 这种），
而 `_sanitize()` 当时只管 `<script>`/`on*`/`javascript:`，**没管相对链接**。
相对链接会按**当前地址**解析 —— 当前是 `/lite/book/N/ch/M`，于是变成
`/lite/book/N/ch/chap0.xhtml`，撞上 `idx: int` 直接 422。

修法：① 能对上本书目录里某一章 → 改写成 `/lite/book/N/ch/<章号>?fs=`；
② 对不上（图片、脚注文件、缺失文件）→ 退化成纯文字 `<span>`；
③ 站内绝对路径 / 页内锚点 / http(s) / data: 原样保留。

本测试**不联网、只读**：直接调纯函数，另用真实 epub（书 #31）验一遍渲染结果。
"""
import os
import sys
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
os.chdir(_ROOT)
import db                                  # noqa: E402
import lite                                # noqa: E402
import reader as R                         # noqa: E402

_pass, _fail = [0], [0]


def ck(name, ok, extra=''):
    print(('  ✓ ' if ok else '  ✗ ') + name + (('  → ' + str(extra)) if extra else ''))
    (_pass if ok else _fail)[0] += 1


print('=' * 78)
print('极简页正文链接清理')
print('=' * 78)

# ---- 1. 纯函数：四类链接 ----
RW = lambda href: '/lite/book/31/ch/1?fs=22' if 'chap0' in href else None   # noqa: E731

ck('相对链接能对上章 → 改写成本页走得通的章链接',
   lite._sanitize('<a href="chap0.xhtml">前言</a>', RW)
   == '<a href="/lite/book/31/ch/1?fs=22">前言</a>',
   lite._sanitize('<a href="chap0.xhtml">前言</a>', RW))

ck('★ 相对链接对不上（part0004_split_000.html 这种）→ 退化成纯文字，不留死链',
   lite._sanitize('<a href="part0004_split_000.html">x</a>', RW) == '<span>x</span>',
   lite._sanitize('<a href="part0004_split_000.html">x</a>', RW))

for href, why in [('https://example.com/a', '外站 http'),
                  ('http://example.com/a', '外站 http(明文)'),
                  ('/api/books/6/resource?p=a.jpg', '站内绝对路径（图片资源）'),
                  ('#note1', '页内锚点'),
                  ('data:image/png;base64,AAA', 'data: 内联')]:
    h = '<a href="%s">文字</a>' % href
    ck('%s 原样保留' % why, lite._sanitize(h, RW) == h, lite._sanitize(h, RW))

ck('<a name="top"></a> 这类没有 href 的锚点原样保留（lite 自己的「顶部」就是它）',
   lite._sanitize('<a name="top"></a>', RW) == '<a name="top"></a>')

ck('相对链接带 #片段 也照样能对上章（片段对结果没影响）',
   lite._sanitize('<a href="chap0.xhtml#a004">x</a>', RW)
   == '<a href="/lite/book/31/ch/1?fs=22">x</a>')

# ---- 2. 没有改写器时（md/txt 分支）相对链接也要退化成纯文字 ----
ck('没给改写器时，相对链接同样不留死链',
   lite._sanitize('<a href="foo.html">x</a>') == '<span>x</span>')

# ---- 3. 原来的清理不能被弄坏（script / on* / javascript:）----
ck('＜script＞ 仍被清掉', '<script' not in lite._sanitize('<script>alert(1)</script>正文'))
ck('on* 事件属性仍被清掉', 'onclick' not in lite._sanitize('<p onclick="x()">a</p>'))
ck('javascript: 伪协议仍被清掉', 'javascript:' not in lite._sanitize('<a href="javascript:x()">a</a>'))

# ---- 4. href 归一化 ----
ck('_norm_href 折平 ./ 与 ../',
   lite._norm_href('OEBPS/../OEBPS/chap0.xhtml') == 'OEBPS/chap0.xhtml')
ck('_norm_href 去掉 #片段 与查询串',
   lite._norm_href('a.html?q=1#x') == 'a.html')
ck('_norm_href 解百分号编码（epub 里带空格的文件名很常见）',
   lite._norm_href('Text/a%20b.html') == 'Text/a b.html')
ck('_norm_href 去掉开头的斜杠（/OEBPS/x 与 OEBPS/x 必须算同一个）',
   lite._norm_href('/OEBPS/x.html') == lite._norm_href('OEBPS/x.html'))

# ---- 5. 真实 epub：渲染出来的一页里不能有相对链接 ----
#    书 #31 的第 0 章就是它自带的目录页（OEBPS/catalog.xhtml），里面链到 chap0.xhtml。
b = db.q("SELECT * FROM books WHERE id=31", one=True)
if not b:
    ck('书 #31 存在（本步前提）', False)
else:
    toc = R.epub_toc(b)
    ck('书 #31 的目录里有 OEBPS/chap0.xhtml（本步前提）',
       any('chap0.xhtml' in (c.get('href') or '') for c in toc), len(toc))
    cat = [i for i, c in enumerate(toc) if 'catalog.xhtml' in (c.get('href') or '')]
    if not cat:
        ck('书 #31 的目录页在目录列表里（本步前提）', False)
    else:
        c = toc[cat[0]]
        html = lite._sanitize(R.epub_chapter(b, c['href'], '/api/books/31/resource?p=', ''),
                              lite._epub_link_rewriter(toc, c['href'], 31, 22))
        import re
        rel = re.findall(r'<a\b[^>]*href="(?!#|/|https?://|data:)[^"]*"', html, re.I)
        ck('★ 真实渲染出的目录页里已经没有相对链接', not rel, '%d 个：%s' % (len(rel), rel[:3]))
        ck('★ 正文里链到 chap0.xhtml 的那条被改写成了 /lite/book/31/ch/1',
           'href="/lite/book/31/ch/1?fs=22"' in html)
        ck('原始 epub 里确实存在相对链接（说明上面不是空过的）',
           'chap0.xhtml' in (R.epub_chapter(b, c['href'], '', '') or ''))

print()
print('=' * 78)
print('极简页正文链接清理：%d 通过 / %d 失败' % (_pass[0], _fail[0]))
sys.exit(1 if _fail[0] else 0)
