// 管理员把「有声电子书」页面的有声书加入首页「🔥 热度推荐」（同时也就是「访客推荐」）。
//
// 背景：首页「热度推荐」和未登录访客的首页用的是 books 上的**同一个** guest_featured 标记。
// 以前只能去后台「书籍管理」里勾，有声书要翻半天才能找到对应的那本书；
// 现在有声卡片右上角有一颗星（只有管理员看得见），详情页也有一个带说明的按钮。
//
// 这个测试除了验功能，还要盯住几个容易出问题的地方：
//   ① 热度推荐是 LIMIT 6 的运营位、**经常是满的** —— 新加的那本必须排到最前，
//      否则「加了却在首页找不到」，必被当成 bug（服务端为此把 books.updated_at 顶到当前）。
//   ② 被顶过的 updated_at 必须能原样还原，所以测试自己快照、自己恢复。
//   ③ 首页板块要真的重画出来（loadHot 挂在 loadBooks 的默认首页分支里，
//      走 goHome() 才会重跑；只切视图不刷新会读到旧 DOM）。
//   ④ 只有管理员看得到星标 —— 普通用户登录的是**真实账号**，
//      在 localStorage 里把 role 改成 user 是没用的，服务端一返回就被覆盖。
const { chromium } = require('playwright-core');
const fs = require('fs'); const { execSync } = require('child_process');
const ROOT = '/srv/myreader/book_manager';
const BASE = 'https://127.0.0.1:9000';
const CHROME = '/srv/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome';
const py = (c) => {
  fs.writeFileSync('/tmp/_aufeat.py', c);
  return execSync(`cd ${ROOT} && venv/bin/python /tmp/_aufeat.py`, { encoding: 'utf8' }).trim();
};
let pass = 0, fail = 0;
const ck = (n, ok, e) => { console.log((ok ? '  ✓ ' : '  ✗ ') + n + (e ? '  → ' + e : '')); ok ? pass++ : fail++; };
const TS = String(Date.now()).slice(-6);
const ADM = 'zzauf' + TS, USR = 'zzaufu' + TS;   // 临时管理员 + 临时普通用户，跑完删掉
const TARGET_BOOK = 383692;                      // 《魔戒三部曲》对应的小说
const TARGET_TITLE = '魔戒三部曲';

(async () => {
  process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

  // ── 0. 快照：被推荐的每一本的 guest_featured + updated_at 都要能原样还原
  const snap = JSON.parse(py(`
import sys, json; sys.path.insert(0,'.')
import db, auth
rows = db.q("SELECT id, COALESCE(updated_at,'') ua FROM books WHERE COALESCE(guest_featured,0)=1")
b = db.q("SELECT id, COALESCE(updated_at,'') ua, COALESCE(guest_featured,0) gf FROM books WHERE id=?", (${TARGET_BOOK},), one=True)
def mk(un, role):
    db.ex("INSERT INTO users (username,password_hash,role,quota,enabled,group_id,name,created_at) VALUES (?,?,?,?,?,?,?,?)",
          (un, auth.hash_password('zztest'), role, 50, 1, 1, un, db.now()))
    return db.q("SELECT * FROM users WHERE username=?", (un,), one=True)
a = mk('${ADM}', 'admin'); u = mk('${USR}', 'user')
print(json.dumps({'featured': {str(r['id']): r['ua'] for r in rows},
                  'target': {'ua': b['ua'], 'gf': b['gf']},
                  'tok': auth.create_token(a), 'utok': auth.create_token(u),
                  'user': {'id': a['id'], 'username': a['username'], 'name': a['name'], 'role': a['role']},
                  'uuser': {'id': u['id'], 'username': u['username'], 'name': u['name'], 'role': u['role']}}))`));
  console.log(`  快照：原有推荐 ${Object.keys(snap.featured).length} 本；目标书 ${TARGET_BOOK} 原 updated_at=${snap.target.ua}`);
  const restore = () => py(`
import sys, json; sys.path.insert(0,'.')
import db
snap = json.loads('''${JSON.stringify(snap)}''')
db.ex("UPDATE books SET guest_featured=0 WHERE id=?", (${TARGET_BOOK},))
for bid, ua in snap['featured'].items():
    db.ex("UPDATE books SET guest_featured=1, updated_at=? WHERE id=?", (ua, int(bid)))
db.ex("UPDATE books SET updated_at=? WHERE id=?", (snap['target']['ua'], ${TARGET_BOOK}))
if snap['target']['gf']:
    db.ex("UPDATE books SET guest_featured=1 WHERE id=?", (${TARGET_BOOK},))
db.ex("DELETE FROM users WHERE username IN (?,?)", ('${ADM}', '${USR}'))
now = {str(r['id']): r['ua'] for r in db.q("SELECT id, COALESCE(updated_at,'') ua FROM books WHERE COALESCE(guest_featured,0)=1")}
left = db.q("SELECT COUNT(*) c FROM users WHERE username IN (?,?)", ('${ADM}', '${USR}'), one=True)['c']
tgt = db.q("SELECT COALESCE(updated_at,'') ua, COALESCE(guest_featured,0) gf FROM books WHERE id=?", (${TARGET_BOOK},), one=True)
print(json.dumps({'same': now == snap['featured'], 'left_user': left,
                  'tgt_ua': tgt['ua'], 'tgt_gf': tgt['gf'], 'n': len(now)}))`);

  const browser = await chromium.launch({ args: ['--no-sandbox'], executablePath: CHROME });
  const errs = [];
  const mkCtx = async (tok, usr) => {
    const ctx = await browser.newContext({ ignoreHTTPSErrors: true, viewport: { width: 1400, height: 1000 }, baseURL: BASE });
    if (tok) await ctx.addInitScript(([t, u]) => {
      localStorage.setItem('bm_token', t); localStorage.setItem('bm_user', u);
    }, [tok, JSON.stringify(usr)]);
    const p = await ctx.newPage();
    p.on('pageerror', e => errs.push(e.message));
    return [ctx, p];
  };
  // ★ 必须走页面自己的 api()（它会带 Authorization），裸 fetch 拿不到令牌会 401
  const hotIds = (p) => p.evaluate(async () => ((await api('/api/home/hot')).items || []).map(x => x.id));

  try {
    // ── 1. 管理员：有声电子书页面卡片上有星标
    const [ctxA, page] = await mkCtx(snap.tok, snap.user);
    await page.goto('/', { waitUntil: 'domcontentloaded', timeout: 90000 });
    await page.waitForTimeout(4000);
    await page.evaluate(() => switchPage('audio'));
    await page.waitForSelector('#au-list .au-card', { timeout: 30000 });
    const stars = await page.locator('#au-list .au-star').count();
    const cards = await page.locator('#au-list .au-card').count();
    ck('★ 管理员在每张有声卡片上都能看到「热度推荐」星标',
       cards > 0 && stars === cards, `卡片 ${cards} 张 / 星标 ${stars} 颗`);

    // 定位目标卡片（按书名找，不用「第几张」—— 列表顺序会变）
    const card = page.locator('#au-list .au-card', { hasText: TARGET_TITLE }).first();
    await card.waitFor({ timeout: 15000 });
    const before = await card.locator('.au-star').getAttribute('class');
    ck('目标书加入前是未推荐状态（☆）', !/ on\b/.test(before || ''), before);

    // ── 2. 点星标 → 加入热度推荐
    await card.locator('.au-star').click();
    await page.waitForTimeout(2500);
    const after = await card.locator('.au-star').getAttribute('class');
    ck('★ 点星标后星标变成已推荐（★）', / on\b/.test(after || ''), after);

    const hot1 = await hotIds(page);
    ck('★ 首页「热度推荐」接口里出现了这本书', hot1.includes(TARGET_BOOK), JSON.stringify(hot1));
    ck('★ 新加的那本排在第一位（运营位满 6 本时也能一眼看到）',
       hot1[0] === TARGET_BOOK, '第一位是 ' + hot1[0]);

    // ── 3. 首页板块里真的能看到（goHome 会重跑 loadBooks → loadHot）
    await page.evaluate(() => goHome());
    await page.waitForTimeout(3000);
    const hotTxt = await page.locator('#home-hot-list').innerText().catch(() => '');
    ck('★ 首页「🔥 热度推荐」板块里能看到《' + TARGET_TITLE + '》',
       hotTxt.includes(TARGET_TITLE), hotTxt.replace(/\s+/g, ' ').slice(0, 70));

    // ── 3b. ★ 卡片必须按**有声书**呈现，点开进有声详情 —— 这是业主报的那个 bug：
    //        从有声页面加的推荐，点开却是一本普通电子书（要再点一次「听有声」才听得到）。
    const hotCard = page.locator('#home-hot-list .book-card', { hasText: TARGET_TITLE }).first();
    const oc = await hotCard.getAttribute('onclick');
    ck('★★ 首页卡片点开进的是有声详情（不是普通电子书）', /openAudio\(\d+\)/.test(oc || ''), oc);
    ck('★ 卡片上有「🎧 有声」角标', (await hotCard.locator('.hot-audio').count()) === 1);
    await hotCard.click();
    await page.waitForSelector('#view-audio:not(.hidden)', { timeout: 20000 });
    await page.waitForTimeout(2500);
    const auTitle = await page.locator('#au-detail-title').innerText().catch(() => '');
    ck('★★ 点开后确实进的是有声详情页', auTitle.includes(TARGET_TITLE), 'au-detail-title=' + auTitle);
    // 反方向也要有路：有声详情 → 电子书（否则想读文字版的人没入口）
    const readBtn = page.locator('#au-detail-body button', { hasText: '读电子书' });
    ck('★ 有声详情页有「📖 读电子书」入口', (await readBtn.count()) === 1, '匹配 ' + await readBtn.count() + ' 个');
    await readBtn.click();
    await page.waitForTimeout(2500);
    ck('★ 点「读电子书」进的是电子书详情',
       await page.locator('#view-detail').isVisible().catch(() => false));

    // ── 4. 访客（未登录）也能看到 —— 这就是「访客推荐」。
    //      但访客进不去有声（§14.74），所以他们的卡片**不该**出现有声角标、点开仍是电子书。
    const [ctxG, gpage] = await mkCtx(null, null);
    await gpage.goto('/', { waitUntil: 'domcontentloaded', timeout: 90000 });
    await gpage.waitForTimeout(4500);
    const guestIds = await gpage.evaluate(async () => {
      const r = await fetch('/api/books?page=1&page_size=60', { headers: { 'X-BM-No-Push': '1' } });
      return ((await r.json()).items || []).map(x => x.id);
    });
    ck('★ 未登录访客能看到的书里也有这本（访客推荐）',
       guestIds.includes(TARGET_BOOK), `访客可见 ${guestIds.length} 本`);
    const gTxt = await gpage.locator('body').innerText().catch(() => '');
    ck('访客首页界面上也能看到《' + TARGET_TITLE + '》', gTxt.includes(TARGET_TITLE));
    ck('★ 访客的卡片上没有有声角标（访客听不了有声，给了只会点出 403）',
       (await gpage.locator('.hot-audio').count()) === 0);
    await ctxG.close();

    // ── 5. 普通用户看不到星标（这是管理员操作）—— 用真实的普通账号
    const [ctxU, upage] = await mkCtx(snap.utok, snap.uuser);
    await upage.goto('/', { waitUntil: 'domcontentloaded', timeout: 90000 });
    await upage.waitForTimeout(3000);
    const uRole = await upage.evaluate(() => USER && USER.role);
    ck('临时普通账号登录身份确实是 user', uRole === 'user', 'role=' + uRole);
    await upage.evaluate(() => switchPage('audio'));
    await upage.waitForSelector('#au-list .au-card', { timeout: 30000 });
    const uStars = await upage.locator('#au-list .au-star').count();
    const uBadges = await upage.locator('#au-list .au-star-badge').count();
    ck('★ 普通用户看不到星标按钮（只有管理员能改）', uStars === 0, '星标 ' + uStars + ' 颗');
    ck('普通用户能看到「推荐」角标（知道这是推荐位）', uBadges >= 1, '角标 ' + uBadges + ' 个');
    await ctxU.close();

    // ── 6. 详情页也能取消：点卡片进详情，用详情页那个带说明的按钮
    await page.evaluate(() => switchPage('audio'));
    await page.waitForTimeout(2500);
    await page.locator('#au-list .au-card', { hasText: TARGET_TITLE }).first().click();
    await page.waitForSelector('#au-detail-body .ad-acts', { timeout: 20000 });
    await page.waitForTimeout(1200);
    const detBtn = page.locator('#au-detail-body button', { hasText: '取消首页「热度推荐」' });
    ck('★ 详情页显示「取消首页「热度推荐」」（状态对了才显示取消）',
       await detBtn.count() === 1, '匹配到 ' + await detBtn.count() + ' 个');
    const detTip = await page.locator('#au-detail-body').innerText().catch(() => '');
    ck('详情页有说明（含「最多展示 6 本」）', /最多展示 6 本/.test(detTip));
    await detBtn.click();
    await page.waitForTimeout(2500);

    const hot2 = await hotIds(page);
    ck('★ 取消后热度推荐里不再有这本', !hot2.includes(TARGET_BOOK), JSON.stringify(hot2));
    ck('取消后推荐位数量回到原来的 ' + Object.keys(snap.featured).length + ' 本',
       hot2.length === Object.keys(snap.featured).length, '现在 ' + hot2.length + ' 本');
    await page.evaluate(() => switchPage('audio'));
    await page.waitForTimeout(2500);
    const back = await page.locator('#au-list .au-card', { hasText: TARGET_TITLE }).first()
      .locator('.au-star').getAttribute('class');
    ck('★ 回到列表，星标也变回 ☆（两处状态同步）', !/ on\b/.test(back || ''), back);

    ck('整个过程没有 JS 报错', errs.length === 0, errs.slice(0, 2).join(' | '));
    await ctxA.close();
  } finally {
    // ── 7. 还原：推荐集合、updated_at、临时账号，全部精确恢复
    const o = JSON.parse(restore());
    ck('★ 推荐数据已精确还原（含被顶过的 updated_at）', o.same, JSON.stringify(o));
    ck('临时管理员与临时普通账号都已删除', o.left_user === 0, '残留 ' + o.left_user);
    ck('目标书状态已还原', o.tgt_gf === snap.target.gf && o.tgt_ua === snap.target.ua,
       `gf=${o.tgt_gf}/${snap.target.gf} ua=${o.tgt_ua}/${snap.target.ua}`);
    await browser.close();
  }

  console.log(`\n有声书加入首页热度推荐：${pass} 通过 / ${fail} 失败`);
  process.exit(fail ? 1 : 0);
})();
