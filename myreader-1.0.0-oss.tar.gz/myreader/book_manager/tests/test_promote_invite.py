#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""推广 / 邀请（两条独立渠道）的后端回归。

「推广」和「邀请」是**两个单独的权限**，权限开关、码、奖励树叶数全都分开配。
本套件重点就是验证它们**真的互不串味**。

A. 分组：两条渠道各自一个权限位、各自一个奖励数
B. 码：一人每条渠道一个码；两条渠道的码不同；换一条不影响另一条
C. 权限：只有一边权限时，另一边的接口必须 403，且不会偷偷生成码
D. 「有效注册」判定：同一设备指纹只算一个有效用户（两条渠道共用这个判定）
E. 奖励：按码所属渠道的**各自单价**发放，且重复发放不变多
F. 「邀请注册」总开关：开启=必须，关闭=可选
G. 审计日志：生成/注册/两条渠道的奖励/被拒，都在

★ 数据安全：临时分组 + 临时用户，按**精确 id 与精确用户名**清理；
  HTTP 请求一律带 X-BM-No-Push，避免测试触发真实 Server酱 推送。
"""
import os
import ssl
import sys
import json
import uuid
import urllib.parse
import urllib.request
import urllib.error
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
os.chdir(_ROOT)
import db          # noqa: E402
import auth        # noqa: E402
import promote     # noqa: E402

BASE = 'https://127.0.0.1:9000'
CTX = ssl._create_unverified_context()

PASS = FAIL = 0


def ck(name, cond, extra=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print("  ✓ %s" % name)
    else:
        FAIL += 1
        print("  ✗ %s %s" % (name, extra))


def call(path, token=None, method='GET', payload=None, form=None):
    h = {'X-BM-No-Push': '1'}
    if token:
        h['Authorization'] = 'Bearer ' + token
    data = None
    if payload is not None:
        data = json.dumps(payload).encode()
        h['Content-Type'] = 'application/json'
    elif form is not None:
        data = urllib.parse.urlencode(form).encode()
        h['Content-Type'] = 'application/x-www-form-urlencoded'
    r = urllib.request.Request(BASE + path, data=data, headers=h, method=method)
    try:
        with urllib.request.urlopen(r, context=CTX, timeout=60) as resp:
            return resp.status, json.loads(resp.read() or b'{}')
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read() or b'{}')
        except Exception:
            return e.code, {}


def admin_token():
    u = db.q("SELECT * FROM users WHERE role='admin' AND enabled=1 ORDER BY id LIMIT 1", one=True)
    return auth.create_token(u), u


TAG = 'zzt_pm_' + uuid.uuid4().hex[:6]
# 注册接口中途 500 时拿不到 uid，所以除了记 uid，还要记「打算建的用户名」，
# 清理时按**精确用户名**兜底 —— 不能用 username LIKE 这类宽条件（README 有明文约定）。
UN = {n: '%s_n%d' % (TAG, n) for n in range(1, 12)}
created_users = []
created_groups = []
_orig_cfg = {}


def mk_user(group_id, username=None, fp=''):
    un = username or (TAG + '_u' + uuid.uuid4().hex[:5])
    uid = db.ex("INSERT INTO users (username,password_hash,role,quota,enabled,group_id,name,"
                "email,phone,created_at,last_login,signup_fp) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                (un, auth.hash_password('test4'), 'user', 0, 1, group_id,
                 '测试' + un[-4:], un + '@t.local', '13800000000',
                 db.now(), db.now(), fp))
    created_users.append(uid)
    u = db.q("SELECT * FROM users WHERE id=?", (uid,), one=True)
    return uid, auth.create_token(u)


def reg(username, code=None, fp=None):
    """走真实的注册接口。fp=None 表示**不带**指纹字段。"""
    f = {'username': username, 'password': 'test4', 'name': '测试' + username[-4:],
         'email': username + '@t.local', 'phone': '139' + str(abs(hash(username)) % 10 ** 8).zfill(8),
         'agree': '1'}
    if code is not None:
        f['invite'] = code
    if fp is not None:
        f['fp'] = fp
    return call('/api/register', method='POST', form=f)


def cleanup():
    try:
        qs = ','.join('?' * len(UN))
        for r in db.q("SELECT id FROM users WHERE username IN (%s)" % qs, tuple(UN.values())):
            if r['id'] not in created_users:
                created_users.append(r['id'])
    except Exception:
        pass
    for uid in created_users:
        for sql in ("DELETE FROM invites WHERE invitee_id=? OR inviter_id=?",
                    "DELETE FROM invite_codes WHERE uid=?",
                    "DELETE FROM leaf_gain WHERE user_id=?",
                    "DELETE FROM user_leaves WHERE user_id=?",
                    "DELETE FROM signin_log WHERE user_id=?",
                    "DELETE FROM messages WHERE to_id=? OR from_id=?"):
            args = (uid, uid) if sql.count('?') == 2 else (uid,)
            try:
                db.ex(sql, args)
            except Exception:
                pass
        try:
            db.ex("DELETE FROM users WHERE id=?", (uid,))
        except Exception:
            pass
    for gid in created_groups:
        try:
            db.ex("DELETE FROM user_groups WHERE id=?", (gid,))
        except Exception:
            pass
    for k, v in _orig_cfg.items():
        try:
            db.set_config(k, v)
        except Exception:
            pass


def main():
    tok, admin = admin_token()

    # ---------- A. 分组：两条渠道各自一个权限位与奖励 ----------
    st, g = call('/api/admin/groups', tok, 'POST', form={
        'name': TAG + '全渠道', 'sort_order': 998,
        'can_promote': '1', 'can_invite': '1',
        'promote_reward': '3', 'invite_reward': '5'})
    assert st == 200, (st, g)
    gid = g['id']; created_groups.append(gid)

    st, g2 = call('/api/admin/groups', tok, 'POST', form={
        'name': TAG + '只推广', 'sort_order': 999,
        'can_promote': '1', 'can_invite': '0', 'promote_reward': '9', 'invite_reward': '0'})
    assert st == 200, (st, g2)
    gid2 = g2['id']; created_groups.append(gid2)

    grp = db.get_group(gid)
    ck('A1 分组能存下两个权限位（都开）', grp['can_promote'] == 1 and grp['can_invite'] == 1)
    ck('A2 分组能存下两个奖励数（3 / 5）',
       grp['promote_reward'] == 3 and grp['invite_reward'] == 5)
    grp2 = db.get_group(gid2)
    ck('A3 两条渠道可以只开一条', grp2['can_promote'] == 1 and grp2['can_invite'] == 0)
    ck('A4 只开推广时邀请奖励独立为 0', grp2['promote_reward'] == 9 and grp2['invite_reward'] == 0)

    call('/api/admin/groups/%d' % gid, tok, 'PUT', form={'promote_reward': '11'})
    grp = db.get_group(gid)
    ck('A5 改推广奖励不影响邀请奖励', grp['promote_reward'] == 11 and grp['invite_reward'] == 5)
    call('/api/admin/groups/%d' % gid, tok, 'PUT', form={'invite_reward': '7'})
    grp = db.get_group(gid)
    ck('A6 改邀请奖励不影响推广奖励', grp['promote_reward'] == 11 and grp['invite_reward'] == 7)
    call('/api/admin/groups/%d' % gid, tok, 'PUT',
         form={'promote_reward': '3', 'invite_reward': '5'})
    grp = db.get_group(gid)
    ck('A7 两个奖励可同时改', grp['promote_reward'] == 3 and grp['invite_reward'] == 5)

    # ---------- B. 码：一人每渠道一码 ----------
    ck('B1 码表不含易混字符', not (set(promote._ALPHABET) & set('01OIL')))
    ck('B2 归一化：小写/空格/连字符都吃掉', promote.norm_code(' ab-cd ef ') == 'ABCDEF')
    ck('B3 格式校验：太短不合法', promote.check_code('ABC')[0] is False)
    ck('B4 格式校验：不存在的码不合法', promote.check_code('ZZZZZZZZ')[0] is False)
    ck('B5 不存在的码查不回渠道', promote.check_code('ZZZZZZZZ')[4] == '')

    uid_a, tok_a = mk_user(gid)          # 两条渠道都有权限
    st, r = call('/api/promote/me', tok_a)
    ch = r.get('channels') or {}
    ck('B6 面板返回两条渠道', set(ch.keys()) == {'promote', 'invite'}, list(ch.keys()))
    ck('B7 两条渠道都 allowed', ch['promote']['allowed'] and ch['invite']['allowed'])
    pcode, icode = ch['promote']['code'], ch['invite']['code']
    ck('B8 推广码 8 位（藏在链接里，不用手输，抗猜）', len(pcode) == 8, pcode)
    ck('B8b ★邀请码 4 位（要手抄口述，短）', len(icode) == 4, icode)
    ck('B8c 码长是按渠道分开配的',
       promote.CODE_LEN == {'promote': 8, 'invite': 4}, promote.CODE_LEN)
    ck('B8d 4 位码也认（校验正则不是只收 8 位）', promote.check_code(icode)[0] is True)
    ck('B9 两条渠道的码**不相同**', pcode != icode, (pcode, icode))
    ck('B10 奖励各带各的（3 / 5）',
       ch['promote']['reward'] == 3 and ch['invite']['reward'] == 5)
    ck('B11 库里就是两条独立的码',
       db.q("SELECT COUNT(*) c FROM invite_codes WHERE uid=?", (uid_a,), one=True)['c'] == 2)
    ok, c, why, own, kind = promote.check_code(pcode)
    ck('B12 查推广码能查回渠道 promote', ok and kind == 'promote' and own == uid_a)
    ok, c, why, own, kind = promote.check_code(icode)
    ck('B13 查邀请码能查回渠道 invite', ok and kind == 'invite' and own == uid_a)

    st, r = call('/api/promote/me', tok_a)
    ck('B14 再取一次两条码都不变',
       r['channels']['promote']['code'] == pcode and r['channels']['invite']['code'] == icode)

    st, r = call('/api/promote/gen?kind=promote', tok_a, 'POST')
    np_ = r.get('code', '')
    ck('B15 换推广码成功且是新码', st == 200 and np_ and np_ != pcode, (st, r))
    ck('B16 旧推广码失效', promote.check_code(pcode)[0] is False)
    ck('B17 ★换推广码**没有**把邀请码一起换掉', promote.check_code(icode)[0] is True)
    ck('B18 邀请码还是原来那个', promote.check_code(icode)[1] == icode)

    st, r = call('/api/promote/gen?kind=invite', tok_a, 'POST')
    ni = r.get('code', '')
    ck('B19 换邀请码成功且是新码', st == 200 and ni and ni != icode, (st, r))
    ck('B20 旧邀请码失效', promote.check_code(icode)[0] is False)
    ck('B21 ★换邀请码**没有**把推广码一起换掉', promote.check_code(np_)[0] is True)

    st, r = call('/api/promote/gen?kind=xxx', tok_a, 'POST')
    ck('B22 非法渠道参数被拒(400)', st == 400, (st, r))

    # ---------- B23~B26. 汇总统计（「我的」页那张一行四格的卡片） ----------
    st, r = call('/api/promote/me', tok_a)
    t = r.get('totals') or {}
    ck('B23 面板带汇总统计', set(t.keys()) >= {'promote_count', 'invite_count',
                                              'valid_count', 'reward_total'}, list(t.keys()))
    ck('B24 汇总初始为 0', t['promote_count'] == 0 and t['invite_count'] == 0
       and t['valid_count'] == 0 and t['reward_total'] == 0, t)

    code_p, code_i = np_, ni

    # ---------- C. 权限：两条渠道互不越权 ----------
    uid_b, tok_b = mk_user(gid2)         # 只有推广权限
    st, r = call('/api/promote/me', tok_b)
    ch = r.get('channels') or {}
    ck('C1 只有推广权限时 promote=allowed', ch['promote']['allowed'] is True)
    ck('C2 只有推广权限时 invite=不允许', ch['invite']['allowed'] is False)
    ck('C3 没权限的渠道不给码', ch['invite']['code'] == '')
    ck('C4 没权限的渠道不给奖励数', ch['invite']['reward'] == 0)
    ck('C5 ★没权限的渠道**不会偷偷生成**码',
       db.q("SELECT COUNT(*) c FROM invite_codes WHERE uid=? AND kind='invite'",
            (uid_b,), one=True)['c'] == 0)
    ck('C6 有权限的渠道正常给码', len(ch['promote']['code']) == 8)
    ck('C7 只推广的分组，推广单价是它自己设的 9', ch['promote']['reward'] == 9)

    st, r = call('/api/promote/gen?kind=invite', tok_b, 'POST')
    ck('C8 ★越权生成邀请码被拒(403)', st == 403, (st, r))
    ck('C9 越权后库里依然没有邀请码',
       db.q("SELECT COUNT(*) c FROM invite_codes WHERE uid=? AND kind='invite'",
            (uid_b,), one=True)['c'] == 0)

    guest_g = db.group_by_code('guest')
    uid_c, tok_c = mk_user(guest_g['id'])
    st, r = call('/api/promote/me', tok_c)
    ch = r.get('channels') or {}
    ck('C10 无权限用户两条渠道都不允许',
       ch['promote']['allowed'] is False and ch['invite']['allowed'] is False)
    for k in promote.KINDS:
        st, _ = call('/api/promote/gen?kind=' + k, tok_c, 'POST')
        ck('C11 无权限用户生成%s码被拒(403)' % promote.KIND_CN[k], st == 403, st)

    # ---------- D/E. 有效注册判定 + 按渠道单价发奖 ----------
    base = call('/api/promote/me', tok_a)[1]['channels']
    p0, i0 = base['promote'], base['invite']

    st, r1 = reg(UN[1], code_p, 'fp-' + uuid.uuid4().hex)
    ck('D1 用推广码注册成功', st == 200 and 'token' in r1, (st, r1))
    inv1 = db.q("SELECT * FROM invites WHERE invitee_id=?", (r1.get('user', {}).get('id', 0),), one=True)
    ck('D2 邀请记录写的渠道是 promote', inv1 is not None and inv1['kind'] == 'promote',
       dict(inv1) if inv1 else None)
    ck('D3 判定为有效', inv1 and inv1['valid'] == 1)
    ch = call('/api/promote/me', tok_a)[1]['channels']
    ck('D4 推广有效数 +1', ch['promote']['valid'] == p0['valid'] + 1, ch['promote']['valid'])
    ck('D5 推广奖励按推广单价 3 到账',
       ch['promote']['leaves'] == p0['leaves'] + 3, ch['promote']['leaves'])
    ck('D6 ★邀请渠道的统计没被污染',
       ch['invite']['valid'] == i0['valid'] and ch['invite']['leaves'] == i0['leaves'])

    st, r2 = reg(UN[2], code_i, 'fp-' + uuid.uuid4().hex)
    ck('D7 用邀请码注册成功', st == 200 and 'token' in r2, (st, r2))
    inv2 = db.q("SELECT * FROM invites WHERE invitee_id=?", (r2.get('user', {}).get('id', 0),), one=True)
    ck('D8 邀请记录写的渠道是 invite', inv2 is not None and inv2['kind'] == 'invite',
       dict(inv2) if inv2 else None)
    ch = call('/api/promote/me', tok_a)[1]['channels']
    ck('D9 邀请有效数 +1', ch['invite']['valid'] == i0['valid'] + 1, ch['invite']['valid'])
    ck('D10 ★邀请奖励按邀请单价 5 到账（不是推广的 3）',
       ch['invite']['leaves'] == i0['leaves'] + 5, ch['invite']['leaves'])
    ck('D11 两条渠道的叶子分别记账',
       db.q("SELECT COUNT(*) c FROM leaf_gain WHERE user_id=? AND kind='promote'",
            (uid_a,), one=True)['c'] == 1
       and db.q("SELECT COUNT(*) c FROM leaf_gain WHERE user_id=? AND kind='invite'",
                (uid_a,), one=True)['c'] == 1)

    FP = 'fp-' + uuid.uuid4().hex
    st, r3 = reg(UN[3], code_p, FP)
    ck('D12 同指纹仍可注册（不拦人）', st == 200, (st, r3))
    st, r4 = reg(UN[4], code_i, FP)      # 换条渠道，验「判定是两条渠道共用的」
    ck('D13 同指纹换条渠道也仍可注册', st == 200, (st, r4))
    inv4 = db.q("SELECT * FROM invites WHERE invitee_id=?", (r4.get('user', {}).get('id', 0),), one=True)
    ck('D14 ★同一指纹在邀请渠道也不算有效', inv4 is not None and inv4['valid'] == 0,
       dict(inv4) if inv4 else None)
    ck('D15 无效原因写明是同一台机器',
       inv4 and '同一台' in (inv4['reason'] or ''), inv4['reason'] if inv4 else '')

    st, r5 = reg(UN[5], code_p)
    ck('D16 不带指纹仍可注册', st == 200, (st, r5))
    inv5 = db.q("SELECT * FROM invites WHERE invitee_id=?", (r5.get('user', {}).get('id', 0),), one=True)
    ck('D17 不带指纹不算有效', inv5 is not None and inv5['valid'] == 0)

    ok, why = promote.judge(uid_a, uid_a, 'fp-self')
    ck('D18 自己邀请自己无效', ok is False and '自己' in why, why)

    ch_before = call('/api/promote/me', tok_a)[1]['channels']
    promote.grant_reward(r1['user']['id'])
    promote.grant_reward(r1['user']['id'])
    promote.grant_reward(r2['user']['id'])
    ch_after = call('/api/promote/me', tok_a)[1]['channels']
    t = call('/api/promote/me', tok_a)[1]['totals']
    ck('E0a 汇总：推广注册记 3 条（含不计有效的）', t['promote_count'] == 3, t)
    ck('E0b 汇总：邀请注册记 2 条', t['invite_count'] == 2, t)
    # 此时有效的是：推广 r1、邀请 r2、推广 r3（r3 用的是全新指纹，确实该算有效）；
    # r4 是同一指纹换条渠道 → 不算；r5 没带指纹 → 不算。所以有效 3 条。
    ck('E0c 汇总：有效注册只数有效的（3 条，r3 是全新指纹）', t['valid_count'] == 3, t)
    ck('E0d ★汇总：累计奖励 = 推广 3×2 + 邀请 5×1（两条渠道合起来算）',
       t['reward_total'] == 11, t)
    ck('E1 重复发放奖励两条渠道都不会变多',
       ch_after['promote']['leaves'] == ch_before['promote']['leaves']
       and ch_after['invite']['leaves'] == ch_before['invite']['leaves'],
       (ch_before['promote']['leaves'], ch_after['promote']['leaves'],
        ch_before['invite']['leaves'], ch_after['invite']['leaves']))

    # ---------- F. 邀请注册开关 ----------
    _orig_cfg['invite_register'] = db.get_config('invite_register', '0')
    st, c = call('/api/admin/config', tok)
    ck('F1 后台能读到邀请注册开关', 'invite_register' in c)

    call('/api/admin/config', tok, 'POST', payload={'invite_register': '1'})
    ck('F2 开启后写入生效', db.get_config('invite_register', '0') == '1')
    ck('F3 注册页配置变成「必须」', call('/api/promote/config')[1].get('invite_required') is True)

    st, bad = reg(UN[6])
    ck('F4 开启后不填邀请码被拒(400)', st == 400, (st, bad))
    ck('F5 且没有把用户建出来',
       db.q("SELECT 1 FROM users WHERE username=?", (UN[6],), one=True) is None)

    st, bad = reg(UN[7], 'ZZZZZZZZ', 'fp-' + uuid.uuid4().hex)
    ck('F6 填了不存在的码被拒(400)', st == 400, (st, bad))
    ck('F7 错码也不会建号',
       db.q("SELECT 1 FROM users WHERE username=?", (UN[7],), one=True) is None)

    st, bad = reg(UN[8], pcode, 'fp-' + uuid.uuid4().hex)
    ck('F8 拿已被换掉的旧推广码注册被拒(400)', st == 400, (st, bad))

    call('/api/admin/config', tok, 'POST', payload={'invite_register': '0'})
    ck('F9 关闭后变成「可选」', call('/api/promote/config')[1].get('invite_required') is False)
    st, r6 = reg(UN[9], None, 'fp-' + uuid.uuid4().hex)
    ck('F10 关闭后不填邀请码可注册', st == 200 and 'token' in r6, (st, r6))

    # ---------- G. 审计 ----------
    n_gen = db.q("SELECT COUNT(*) c FROM audit_logs WHERE action='promote_gen' AND user_id=?",
                 (uid_a,), one=True)['c']
    n_reg = db.q("SELECT COUNT(*) c FROM audit_logs WHERE action='invite_register'", one=True)['c']
    n_pr = db.q("SELECT COUNT(*) c FROM audit_logs WHERE action='promote_reward'", one=True)['c']
    n_ir = db.q("SELECT COUNT(*) c FROM audit_logs WHERE action='invite_reward'", one=True)['c']
    n_bad = db.q("SELECT COUNT(*) c FROM audit_logs WHERE action='invite_blocked'", one=True)['c']
    ck('G1 有「生成/更换码」审计', n_gen >= 4, n_gen)
    ck('G2 有「推广/邀请注册」审计', n_reg >= 1, n_reg)
    ck('G3 ★推广奖励与邀请奖励是**两个不同**的审计动作', n_pr >= 1 and n_ir >= 1, (n_pr, n_ir))
    ck('G4 有「邀请码被拒」审计', n_bad >= 1, n_bad)
    row = db.q("SELECT detail FROM audit_logs WHERE action='invite_register' ORDER BY id DESC LIMIT 1",
               one=True)
    ck('G5 审计写明走的是哪条渠道、算不算有效',
       bool(row) and ('推广码' in row['detail'] or '邀请码' in row['detail'])
       and '有效' in row['detail'], row['detail'] if row else '')
    rowp = db.q("SELECT detail FROM audit_logs WHERE action='promote_reward' ORDER BY id DESC LIMIT 1",
                one=True)
    cki = db.q("SELECT detail FROM audit_logs WHERE action='invite_reward' ORDER BY id DESC LIMIT 1",
               one=True)
    ck('G6 推广奖励的审计正文写「推广」', bool(rowp) and '推广' in rowp['detail'],
       rowp['detail'] if rowp else '')
    ck('G7 邀请奖励的审计正文写「邀请」', bool(cki) and '邀请' in cki['detail'],
       cki['detail'] if cki else '')


try:
    main()
finally:
    cleanup()
    print()
    print("推广/邀请（双渠道）后端：%d 通过 / %d 失败" % (PASS, FAIL))
