#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把 0 字节的占位书软下架（books.hidden=1）

背景
    库里有 22 行 size=0 的书。它们不是真书，而是网盘搬运时留下的书贩占位文件，
    标题本身就是广告或说明，例如：
        「其他格式周末补齐，急需请私聊群主」
        「推荐看精排PDF格式（微信jnztxy）」
        「原始文件已删：遗失在西方的中国史…」
        「目录：《尼赫鲁世界史》…」（只有目录名，没有正文）
    这些书点进去必然打不开（0 字节），出现在书库列表和搜索结果里只会消耗用户信任。

处置方式：软下架，不删行
    * 置 books.hidden=1。语义与后台「下架」一致：
        - 普通用户/游客：visible_where() 与 can_access_book() 都会排除它，列表、
          搜索、详情页都不再出现；
        - 管理员：auth.visible_where() 对 admin 返回空条件，后台仍能看见、能恢复。
    * **不删行**，因此不触碰任何账本与引用：
        - download_logs 的月度配额是按 DISTINCT book_id 计数的，行还在，历史配额不变；
        - shelves / progress 里的引用行保留，随时可以改回 hidden=0 复原。
    * 实测这 22 行只挂着 1 条 shelves、3 条 progress 引用，全为系统书（owner_id 为空）。

用法
    venv/bin/python tools/hide_empty_books.py           # 干跑，只列出
    venv/bin/python tools/hide_empty_books.py --apply   # 真正置 hidden=1
    venv/bin/python tools/hide_empty_books.py --restore # 撤销（把这些行改回 hidden=0）
"""
import os
import sys

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE_DIR)
import db  # noqa: E402

# 只处理「系统书 + 0 字节」，不碰用户上传的书
WHERE = ("(size = 0 OR size IS NULL) AND owner_id IS NULL")


def admin_user():
    return db.q("SELECT * FROM users WHERE role='admin' ORDER BY id LIMIT 1", one=True)


def main():
    args = sys.argv[1:]
    apply_ = "--apply" in args
    restore = "--restore" in args

    if restore:
        rows = db.q(f"SELECT id, title, category, ext FROM books WHERE hidden=1 AND {WHERE}")
        print("准备复原为可见的书（hidden=1 -> 0）：%d 本" % len(rows))
        for r in rows:
            print("  id=%-7s %-16s %s" % (r["id"], r["category"], (r["title"] or "")[:44]))
        if not apply_:
            print("\n以上为干跑结果，未改动。加 --apply 才生效。")
            return 0
        u = admin_user()
        n = 0
        for r in rows:
            n += db.ex_count(f"UPDATE books SET hidden=0 WHERE id=? AND {WHERE}", (r["id"],))
        db.log_audit(u, "maintenance_restore_empty_book", "book", None,
                     f"复原 0 字节占位书 {n} 本（hidden=1 -> 0）")
        print("\n已复原 %d 本" % n)
        return 0

    rows = db.q(f"SELECT id, title, category, ext FROM books WHERE hidden=0 AND {WHERE} ORDER BY id")
    print("0 字节占位书（系统书）：%d 本" % len(rows))
    print("-" * 64)
    for r in rows:
        print("  id=%-7s %-16s %-6s %s" % (r["id"], r["category"] or "", r["ext"] or "",
                                           (r["title"] or "")[:42]))
    print("-" * 64)

    if not rows:
        print("没有需要处理的书。")
        return 0

    ids = [r["id"] for r in rows]
    ph = ",".join("?" * len(ids))
    print("关联引用（软下架不影响这些行，仅确认影响面）：")
    for t in ("shelves", "progress", "shares", "notes", "download_logs"):
        try:
            n = db.q(f"SELECT COUNT(*) n FROM {t} WHERE book_id IN ({ph})", ids, one=True)["n"]
        except Exception:
            n = -1
        print("  %-16s %d" % (t, n))

    if not apply_:
        print("\n以上为干跑结果，未改动任何行。加 --apply 才生效。")
        return 0

    u = admin_user()
    n = 0
    for bid in ids:
        n += db.ex_count(f"UPDATE books SET hidden=1 WHERE id=? AND {WHERE}", (bid,))
    db.log_audit(u, "maintenance_hide_empty_book", "book", None,
                 f"软下架 0 字节占位书 {n} 本（hidden=0 -> 1）")
    print("\n已软下架 %d 本（hidden=1）。管理员在后台仍可见，可用 --restore 撤销。" % n)
    return 0


if __name__ == "__main__":
    sys.exit(main())
