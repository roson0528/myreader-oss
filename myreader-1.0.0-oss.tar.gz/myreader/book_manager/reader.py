# -*- coding: utf-8 -*-
"""在线阅读管线：txt/epub/pdf/mobi/azw3/md"""
import os, re, subprocess, zipfile
import xml.etree.ElementTree as ET
import config, formats
import covers as covers_mod

try:
    import markdown as _markdown
except Exception:
    _markdown = None


def kind(book):
    ext = (book["ext"] or "").lower()
    if ext == ".epub":
        return "epub"
    if ext == ".txt":
        return "txt"
    if ext == ".pdf":
        return "pdf"
    if ext in (".mobi", ".azw3", ".azw", ".prc"):
        return "mobi"  # 转 epub 后阅读
    if ext in (".html", ".htm"):
        return "html"
    if ext == ".docx":
        return "docx"
    if ext in (".md", ".markdown"):
        return "md"
    return "unsupported"


def convert_to_epub(book):
    """mobi/azw3 → epub，缓存到 CONVERT_DIR"""
    out = os.path.join(config.CONVERT_DIR, f"{book['id']}.epub")
    if os.path.exists(out) and os.path.getsize(out) > 0:
        return out
    local = covers_mod.ensure_local(book)
    tmp = os.path.join(config.CONVERT_DIR, f"{book['id']}.conv.{os.getpid()}.epub")
    try:
        if os.path.exists(tmp):
            os.remove(tmp)
        subprocess.run(["ebook-convert", local, tmp], capture_output=True, timeout=600)
        if os.path.exists(tmp) and os.path.getsize(tmp) > 0:
            os.rename(tmp, out)
            return out
    except Exception:
        pass
    if os.path.exists(tmp):
        os.remove(tmp)
    return None


CONVERT_FORMATS = ("mobi", "azw", "azw3", "epub", "txt", "md")


def convert_book(book, to):
    """把书转换为目标格式（mobi/azw/azw3/epub/txt/md），结果缓存到 CONVERT_DIR；返回文件路径或 None"""
    to = (to or "").lower().lstrip(".")
    if to == "epub":
        return convert_to_epub(book)   # 复用阅读器缓存
    if to == "md":
        return to_markdown(book)       # calibre 无 md 输出：提取正文生成 Markdown
    if to == "azw":
        # calibre 无 azw 输出插件：生成 mobi（同一 Mobipocket 容器）并以 .azw 命名，Kindle 可读
        out = os.path.join(config.CONVERT_DIR, f"{book['id']}.azw")
        if os.path.exists(out) and os.path.getsize(out) > 0:
            return out
        tmp = os.path.join(config.CONVERT_DIR, f"{book['id']}.conv.{os.getpid()}.mobi")
        try:
            local = covers_mod.ensure_local(book)
            if os.path.exists(tmp):
                os.remove(tmp)
            subprocess.run(["ebook-convert", local, tmp], capture_output=True, timeout=900)
            if os.path.exists(tmp) and os.path.getsize(tmp) > 0:
                os.rename(tmp, out)
                return out
        except Exception:
            pass
        return None
    out = os.path.join(config.CONVERT_DIR, f"{book['id']}.{to}")
    if os.path.exists(out) and os.path.getsize(out) > 0:
        return out
    local = covers_mod.ensure_local(book)
    tmp = os.path.join(config.CONVERT_DIR, f"{book['id']}.conv.{os.getpid()}.{to}")
    try:
        if os.path.exists(tmp):
            os.remove(tmp)
        subprocess.run(["ebook-convert", local, tmp], capture_output=True, timeout=900)
        if os.path.exists(tmp) and os.path.getsize(tmp) > 0:
            os.rename(tmp, out)
            return out
    except Exception:
        pass
    if os.path.exists(tmp):
        os.remove(tmp)
    return None


def to_markdown(book):
    """把书转换为 Markdown（calibre 无 md 输出插件）：从 txt/md/docx/epub/html 提取正文生成 .md"""
    out = os.path.join(config.CONVERT_DIR, f"{book['id']}.md")
    if os.path.exists(out) and os.path.getsize(out) > 0:
        return out
    ext = (book["ext"] or "").lower()
    text = ""
    try:
        if ext in (".txt", ".md", ".markdown"):
            local = covers_mod.ensure_local(book)
            if local:
                with open(local, "rb") as fh:
                    text = _decode_txt(fh.read())
        elif ext in (".epub", ".mobi", ".azw3", ".azw", ".prc"):
            for c in epub_toc(book):
                if c.get("front"):
                    continue
                t = _html_to_text(epub_chapter(book, c["href"], "", c.get("fragment", "")))
                if t:
                    text += ("# " + (c.get("title") or "") + "\n\n" + t + "\n\n")
        elif ext == ".docx":
            for c in docx_chunks(book):
                text += ("# " + (c.get("title") or "") + "\n\n" + c["text"] + "\n\n")
        elif ext in (".html", ".htm"):
            local = covers_mod.ensure_local(book)
            if local:
                with open(local, "rb") as fh:
                    text = _html_to_text(_decode_txt(fh.read()))
    except Exception:
        pass
    if not text.strip():
        return None
    try:
        with open(out, "w", encoding="utf-8") as fh:
            fh.write(text)
        return out
    except Exception:
        return None


def remove_convert_file(book_id, fmt):
    """下载结束后自动删除对应转换缓存，释放服务器空间"""
    try:
        p = os.path.join(config.CONVERT_DIR, f"{book_id}.{fmt}")
        if os.path.exists(p):
            os.remove(p)
    except Exception:
        pass


def clean_convert_cache(book_id):
    """清理某本书的转换缓存；跳过进行中转换的临时文件（{id}.conv.*），避免破坏并发转换"""
    try:
        for f in os.listdir(config.CONVERT_DIR):
            if f.startswith(f"{book_id}.conv."):
                continue
            if f.startswith(f"{book_id}."):
                try:
                    os.remove(os.path.join(config.CONVERT_DIR, f))
                except Exception:
                    pass
    except Exception:
        pass


def _decode_txt(raw):
    for enc in ("utf-8", "gbk", "gb18030", "big5"):
        try:
            return raw.decode(enc)
        except Exception:
            continue
    return raw.decode("utf-8", "replace")


CHAPTER_RE = re.compile(
    r"^\s*(第[0-9一二三四五六七八九十百千万零〇两]+[章节回卷篇集部]|"
    r"Chapter\s+\d+|CHAPTER\s+\d+|序章|楔子|尾声|番外|后记|前言|引子).{0,40}$",
    re.M | re.I)


CHUNK_CHARS = 200 * 1024  # 每段最大 200KB 字符


def txt_chunks(book):
    """把 txt 切分为有界的段落，返回 [{idx, title, text}]（每段 ≤200KB）"""
    local = covers_mod.ensure_local(book)
    with open(local, "rb") as fh:
        raw = fh.read()
    text = _decode_txt(raw).replace("\r\n", "\n").replace("\r", "\n")
    lines = text.split("\n")
    marks = [i for i, ln in enumerate(lines) if CHAPTER_RE.match(ln.strip())]
    # 先按章节标题切
    raw_chunks = []
    if len(marks) < 2:
        raw_chunks.append((book["title"], 0, len(lines)))
    else:
        for k, start in enumerate(marks):
            end = marks[k + 1] if k + 1 < len(marks) else len(lines)
            raw_chunks.append((lines[start].strip(), start, end))
    # 再把过大章节按行切到 ≤CHUNK_CHARS
    out = []
    for title, start, end in raw_chunks:
        seg = lines[start:end]
        cur_title, cur_lines, cur_len = title, [], 0
        for ln in seg:
            cur_lines.append(ln)
            cur_len += len(ln) + 1
            if cur_len >= CHUNK_CHARS:
                out.append({"idx": len(out), "title": cur_title,
                            "text": "\n".join(cur_lines)})
                cur_title, cur_lines, cur_len = title + "（续）", [], 0
        if cur_lines:
            out.append({"idx": len(out), "title": cur_title,
                        "text": "\n".join(cur_lines)})
    return out


def chunks(book):
    """txt / docx / md 统一分段：返回 [{idx, title, text}]（md 的 text 为渲染后 HTML）"""
    k = kind(book)
    if k == "docx":
        return docx_chunks(book)
    if k == "md":
        return md_chunks(book)
    return txt_chunks(book)


# ---------- Markdown ----------
MD_HEADING_RE = re.compile(r"^(#{1,6})\s+(.+?)\s*#*\s*$")


def md_to_html(text):
    """Markdown → HTML（用于在线阅读；渲染失败时退回纯文本段落）"""
    if _markdown:
        try:
            return _markdown.markdown(text, extensions=["extra", "sane_lists", "nl2br"])
        except Exception:
            pass
    return "".join("<p>" + _esc_html(ln) + "</p>" for ln in (text or "").split("\n") if ln.strip())


def _esc_html(s):
    return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


def _md_split_long(seg_text, title, limit=CHUNK_CHARS):
    """把过长的 Markdown 段落按空行块切分，保证每块语法基本完整，返回 [{idx, title, text}]"""
    blocks = re.split(r"\n\s*\n", seg_text)
    out, cur, cur_len = [], [], 0
    for b in blocks:
        if cur and cur_len + len(b) > limit:
            out.append({"idx": 0, "title": title if not out else title + "（续）",
                        "text": md_to_html("\n\n".join(cur))})
            cur, cur_len = [], 0
        cur.append(b)
        cur_len += len(b) + 2
    if cur:
        out.append({"idx": 0, "title": title if not out else title + "（续）",
                    "text": md_to_html("\n\n".join(cur))})
    return out or [{"idx": 0, "title": title, "text": md_to_html(seg_text)}]


def md_chunks(book):
    """把 Markdown 切分为有界段落（按标题切，超大段按空行块再切），每段渲染为 HTML，返回 [{idx, title, text}]"""
    local = covers_mod.ensure_local(book)
    with open(local, "rb") as fh:
        raw = fh.read()
    text = _decode_txt(raw).replace("\r\n", "\n").replace("\r", "\n")
    lines = text.split("\n")
    marks = [i for i, ln in enumerate(lines) if MD_HEADING_RE.match(ln)]
    raw_chunks = []
    if len(marks) < 2:
        raw_chunks.append((book["title"], 0, len(lines)))
    else:
        if marks[0] > 0:
            raw_chunks.append((book["title"] + "（前言）", 0, marks[0]))
        for k, start in enumerate(marks):
            end = marks[k + 1] if k + 1 < len(marks) else len(lines)
            title = MD_HEADING_RE.match(lines[start]).group(2).strip()
            raw_chunks.append((title, start, end))
    out = []
    for title, start, end in raw_chunks:
        seg = "\n".join(lines[start:end])
        if len(seg) <= CHUNK_CHARS:
            out.append({"idx": len(out), "title": title, "text": md_to_html(seg)})
        else:
            out += _md_split_long(seg, title)
    for i, c in enumerate(out):
        c["idx"] = i
    return out


def _docx_paragraphs(local):
    """提取 docx 正文段落，返回 [(is_heading, text)]（识别标题样式）"""
    W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    with zipfile.ZipFile(local) as z:
        xml = z.read("word/document.xml")
    root = ET.fromstring(xml)
    out = []
    for p in root.iter(W + "p"):
        is_h = False
        ppr = p.find(W + "pPr")
        if ppr is not None:
            ps = ppr.find(W + "pStyle")
            if ps is not None:
                style = (ps.get(W + "val") or "").lower()
                if "heading" in style or "标题" in style or "title" in style:
                    is_h = True
            if ppr.find(W + "outlineLvl") is not None:
                is_h = True
        parts = []
        for node in p.iter():
            if node.tag == W + "t" and node.text:
                parts.append(node.text)
            elif node.tag == W + "tab":
                parts.append("\t")
            elif node.tag in (W + "br", W + "cr"):
                parts.append("\n")
        out.append((is_h, "".join(parts)))
    return out


def docx_chunks(book):
    """把 docx 转成有界段落（按标题切，超大段再按行切），返回 [{idx, title, text}]"""
    local = covers_mod.ensure_local(book)
    lines, marks = [], []
    for is_h, t in _docx_paragraphs(local):
        t = t.rstrip()
        if not t.strip():
            continue
        if is_h:
            marks.append(len(lines))
        lines.append(t)
    if not lines:
        lines = [book["title"] or "（空文档）"]
    if len(marks) < 2:
        return _chunks_from_lines(book["title"], lines)
    out = []
    if marks[0] > 0:
        out += _chunks_from_lines(book["title"] + "（前言）", lines[:marks[0]])
    for k, start in enumerate(marks):
        end = marks[k + 1] if k + 1 < len(marks) else len(lines)
        out += _chunks_from_lines(lines[start], lines[start:end])
    return out


def _chunks_from_lines(title, lines):
    """把多行文本切成 ≤CHUNK_CHARS 的段落，返回 [{idx, title, text}]"""
    out = []
    cur_title, cur_lines, cur_len = title, [], 0
    for ln in lines:
        cur_lines.append(ln)
        cur_len += len(ln) + 1
        if cur_len >= CHUNK_CHARS:
            out.append({"idx": len(out), "title": cur_title, "text": "\n".join(cur_lines)})
            cur_title, cur_lines, cur_len = title + "（续）", [], 0
    if cur_lines:
        out.append({"idx": len(out), "title": cur_title, "text": "\n".join(cur_lines)})
    return out


def epub_toc(book):
    """返回 [{idx, href, title}]"""
    ext = (book["ext"] or "").lower()
    local = None
    if ext == ".epub":
        local = covers_mod.ensure_local(book)
    else:  # mobi 转 epub
        local = convert_to_epub(book)
    if not local:
        return []
    return formats.read_epub_toc(local)


def epub_chapter(book, href, resource_base, fragment=""):
    ext = (book["ext"] or "").lower()
    local = covers_mod.ensure_local(book) if ext == ".epub" else convert_to_epub(book)
    if not local:
        return "<p>内容加载失败</p>"
    return formats.read_epub_chapter(local, href, resource_base, fragment)


def epub_resource(book, href):
    ext = (book["ext"] or "").lower()
    local = covers_mod.ensure_local(book) if ext == ".epub" else convert_to_epub(book)
    if not local:
        return None
    return formats.read_epub_resource(local, href)


def _html_to_text(html):
    t = re.sub(r"<[^>]+>", " ", html)
    t = t.replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
    t = re.sub(r"&[a-zA-Z#0-9]+;", " ", t)
    t = re.sub(r"\s+", " ", t)
    return t.strip()


def search_book(book, q, limit=50):
    """在书籍内容中搜索，返回 [{idx, title, snippet, count}]"""
    ql = q.lower()
    matches = []
    ext = (book["ext"] or "").lower()
    try:
        if ext in (".epub", ".mobi", ".azw3", ".azw", ".prc"):
            toc = epub_toc(book)
            for item in toc:
                if item.get("front"):
                    continue
                html = epub_chapter(book, item["href"], "")
                text = _html_to_text(html)
                if ql in text.lower():
                    count = text.lower().count(ql)
                    pos = text.lower().find(ql)
                    snippet = text[max(0, pos - 40): pos + 90]
                    matches.append({"idx": item["idx"], "title": item["title"],
                                    "snippet": snippet, "count": count})
                    if len(matches) >= limit:
                        break
        elif ext in (".txt", ".docx", ".md", ".markdown"):
            for c in chunks(book):
                text = _html_to_text(c["text"]) if ext in (".md", ".markdown") else c["text"]
                if ql in text.lower():
                    count = text.lower().count(ql)
                    pos = text.lower().find(ql)
                    snippet = text[max(0, pos - 40): pos + 90]
                    matches.append({"idx": c["idx"], "title": c["title"],
                                    "snippet": snippet, "count": count})
                    if len(matches) >= limit:
                        break
    except Exception:
        pass
    return matches
