// 「退出播放界面 → 点悬浮条返回」不能把本章从头重放。
//
// 背景（站长报障）：APP 里退出播放界面，点浮窗返回播放界面，声音会**回到从头播放**。
//
// 根因：AUPAudio(cont) 里那个「声音已经在前台服务里活着就别再 startMp3」的守卫
// 只认 AUP.restored（页面重载后认领回来的会话）。而「退出播放页再点悬浮条回来」
// 时页面根本没重载、AUP.restored 是 false，于是走了 auNativePlay → startMp3 →
// 原生 playIndex(index, true) —— 那正是「重放本章」。
//
// 修法：守卫放宽成「AUP.restored **或** 原生 status() 说它正在放这本书」。
//
// 这个脚本只读服务端数据，不写库表。
const { chromium } = require('playwright-core');
const { execSync } = require('child_process');
const CHROME = '/srv/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome';
const ROOT = '/srv/myreader/book_manager';

let pass = 0, fail = 0;
const ck = (n, ok, extra) => {
  if (ok) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (extra ? '  → ' + extra : '')); }
};
const py = (c) => execSync('venv/bin/python -', { cwd: ROOT, encoding: 'utf8', input: c }).trim();

// 这个桩**会记住 startMp3 的参数并一直报「active」**，模拟「声音还在前台服务里放着」。
const BRIDGE = (title) => `
window.__nativeCalls = [];
(function () {
  const st = { version: 5, btLink: true, active: false, mode: 'mp3', playing: false,
               title: ${JSON.stringify(title)}, index: 0, positionMs: 0, durationMs: 0 };
  const rec = (n) => function (a) {
    window.__nativeCalls.push({ name: n, arg: a || null });
    if (n === 'status') return Promise.resolve(Object.assign({}, st));
    if (n === 'startMp3') { st.active = true; st.playing = true; st.index = (a && a.index) || 0;
                            st.title = (a && a.title) || st.title; return Promise.resolve({ ok: true }); }
    if (n === 'seek') { st.positionMs = (a && a.ms) || 0; return Promise.resolve({ ok: true }); }
    if (n === 'stop') { st.active = false; st.playing = false; return Promise.resolve({ ok: true }); }
    return Promise.resolve({ ok: true });
  };
  const p = {};
  ['status','startMp3','seek','play','pause','next','prev','gotoIndex','setVoice','setRate','stop']
    .forEach(k => { p[k] = rec(k); });
  window.Capacitor = { Plugins: { ListenService: p } };
})();
`;

(async () => {
  const info = JSON.parse(py(`
import sys, json
sys.path.insert(0, '${ROOT}')
import db, auth
u = db.q("SELECT * FROM users WHERE role='admin' AND enabled=1 ORDER BY id LIMIT 1", one=True)
db.ex("DELETE FROM ab_session WHERE user_id=?", (u["id"],))   # 清掉上一轮测试遗留的有声单端锁
l = db.q("SELECT id, title FROM ab_lib WHERE hidden=0 ORDER BY id LIMIT 1", one=True)
print(json.dumps({"tok": auth.create_token(u), "user": dict(u), "l": dict(l)}))`));

  const browser = await chromium.launch({
    executablePath: CHROME, args: ['--no-sandbox', '--autoplay-policy=no-user-gesture-required'] });
  const ctx = await browser.newContext({ ignoreHTTPSErrors: true, viewport: { width: 420, height: 900 } });
  await ctx.addInitScript(([t, u]) => {
    localStorage.setItem('bm_token', t); localStorage.setItem('bm_user', u);
    try { sessionStorage.setItem('bm_audio_sid', 'fixnativeresume'); } catch (e) {}
  }, [info.tok, JSON.stringify(info.user)]);
  await ctx.addInitScript(BRIDGE(info.l.title));
  const page = await ctx.newPage();
  const errs = [];
  page.on('pageerror', e => errs.push(String(e).slice(0, 90)));
  await page.goto('https://127.0.0.1:9000/', { waitUntil: 'domcontentloaded' });
  await page.waitForFunction(() => typeof audioPlay === 'function', null, { timeout: 20000 });
  await page.waitForTimeout(900);

  // 第一次进播放页：应当正常起播（会发 startMp3）
  await page.evaluate((id) => audioPlay(id, 1, false), info.l.id);
  // ★ 别用固定 2.5 秒：下一章那几本长书要等整本取票才会置 AUP.native，
  //   服务器忙的时候 2.5 秒不够，会偶发假红（实测负载下就红过一次）。
  //   等条件成立，最多 60 秒。
  try { await page.waitForFunction(() => !!(AUP && AUP.native), null, { timeout: 60000 }); }
  catch (e) {}
  const first = await page.evaluate(() => ({
    starts: (window.__nativeCalls || []).filter(c => c.name === 'startMp3').length,
    native: AUP && AUP.native }));
  ck('首次进播放页会起播（发了 1 次 startMp3）', first.starts === 1 && first.native === true,
     'startMp3 次数=' + first.starts + ' native=' + first.native);

  // 退出播放界面（切到别的页），声音还在服务里放着
  await page.evaluate(() => switchPage('shelf'));
  await page.waitForTimeout(1200);
  const floatVis = await page.evaluate(() => {
    const el = document.getElementById('au-float');
    return !!el && !el.classList.contains('hidden');
  });

  // 清空调用记录，再点悬浮条返回播放页
  await page.evaluate(() => { window.__nativeCalls.length = 0; });
  await page.evaluate((id) => audioPlay(id, 1, false), info.l.id);
  // 等界面真的挂回来（文字区有行了）再断言，同样不用固定等待
  try { await page.waitForFunction(() => !!document.querySelector('.ap-line'), null, { timeout: 30000 }); }
  catch (e) {}
  await page.waitForTimeout(600);
  const back = await page.evaluate(() => ({
    starts: (window.__nativeCalls || []).filter(c => c.name === 'startMp3').length,
    inPlayer: !document.getElementById('view-audioplay').classList.contains('hidden'),
    hl: (() => { const a = Array.from(document.querySelectorAll('.ap-line'));
                 return a.findIndex(e => e.classList.contains('on')); })() }));
  ck('★ 返回播放页**不再**重发 startMp3（否则原生会重放本章）',
     back.starts === 0, 'startMp3 次数=' + back.starts);
  ck('★ 播放页确实挂回来了', back.inPlayer);
  ck('★ 文字区仍有高亮（界面接上了原生会话）', back.hl >= 0, '高亮=' + back.hl);
  ck('悬浮条在离开播放页时是显示的', floatVis);
  ck('没有 JS 报错', errs.length === 0, errs[0] || '');
  // ★ 收尾：把自己留下的有声单端锁清掉。
  //   不清的话它会活 40 秒租约，紧接着打开 APP 会误报「正在另一台设备上收听」。
  try {
    py(`import sys; sys.path.insert(0, '${ROOT}')
import db
db.ex("DELETE FROM ab_session WHERE user_id=?", (1,))`);
  } catch (e) {}


  await browser.close();
  console.log(`\n原生会话续接：${pass} 通过 / ${fail} 失败`);
  process.exit(fail ? 1 : 0);
})();
