// 「文字已经出来、声音还没就绪」时点某一句 —— 不能白点。
//
// 播放页的文字是 AUPInit 里 auLoadSegs() 画出来的，声音要等 AUPAudio()：
//   原生：auDetectNative() + 整本取票（长书十几秒）之后才接管；
//   网页：/ticket 取直链回来之后 <audio> 才有 src。
// 这两段窗口里 auSeekTo 去改 AU_AUDIO.currentTime 完全无效 —— 播放器连源都没有，
// 用户看到的就是「点了没反应，然后从本章开头播」。
// 早先只有「原生已探测到、但还没接管」这一种被记成 pendingClickAt，其余都白点；
// 现在判定放宽成「原生没接管 **且** 网页播放器也没有源」，网页这条路上则在
// loadedmetadata 之后补跳。
//
// 本脚本只读服务端数据，不写库表（只清理测试自己账号的有声单端锁）。
const { chromium } = require('playwright-core');
const { execSync } = require('child_process');
const CHROME = '/srv/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome';
const ROOT = '/srv/myreader/book_manager';

let pass = 0, fail = 0;
const ck = (n, ok, extra) => {
  if (ok) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (extra ? '  → ' + extra : '')); }
};
const py = (c) => execSync('venv/bin/python -', { cwd: ROOT, encoding: 'utf8', input: c }).trim();

(async () => {
  const info = JSON.parse(py(`
import sys, json
sys.path.insert(0, '${ROOT}')
import db, auth
u = db.q("SELECT * FROM users WHERE role='admin' AND enabled=1 ORDER BY id LIMIT 1", one=True)
db.ex("DELETE FROM ab_session WHERE user_id=?", (u["id"],))   # 清掉上一轮遗留的有声单端锁
c = db.q("""SELECT lib_id, seq, file_seq, start_sec, n_segs FROM ab_lib_chap
             WHERE n_segs >= 8 ORDER BY lib_id, seq LIMIT 1""", one=True)
print(json.dumps({"tok": auth.create_token(u), "user": dict(u), "c": dict(c)}))`));

  const browser = await chromium.launch({
    executablePath: CHROME, args: ['--no-sandbox', '--autoplay-policy=no-user-gesture-required'] });
  const ctx = await browser.newContext({ ignoreHTTPSErrors: true, viewport: { width: 420, height: 900 } });
  await ctx.addInitScript(([t, u]) => {
    localStorage.setItem('bm_token', t); localStorage.setItem('bm_user', u);
    try { sessionStorage.setItem('bm_audio_sid', 'earlyclick'); } catch (e) {}
  }, [info.tok, JSON.stringify(info.user)]);
  const page = await ctx.newPage();
  const errs = [];
  page.on('pageerror', e => errs.push(String(e).slice(0, 90)));

  // ★ 把取直链拖慢 1.5 秒：制造「文字已经画出来、<audio> 还没有 src」的真实窗口
  await page.route('**/ticket?**', async (route) => {
    await new Promise(r => setTimeout(r, 1500));
    await route.continue();
  });

  await page.goto('https://127.0.0.1:9000/', { waitUntil: 'domcontentloaded' });
  await page.waitForFunction(() => typeof audioPlay === 'function', null, { timeout: 20000 });
  await page.waitForTimeout(600);
  await page.evaluate(([id, ch]) => audioPlay(id, ch, false), [info.c.lib_id, info.c.seq]);

  let ok = true;
  try { await page.waitForSelector('#aup-texts .ap-line', { timeout: 30000 }); } catch (e) { ok = false; }
  const nseg = await page.evaluate(() => (AUP && AUP.segs ? AUP.segs.length : 0));
  ck('文字已渲染', ok && nseg >= 6, 'n=' + nseg);

  const before = await page.evaluate(() => ({ src: AUP.audio ? String(AUP.audio.src) : '', native: AUP.native }));
  ck('★ 点击时网页播放器确实还没有源（否则这条测不到东西）', !before.src, 'src=' + before.src.slice(0, 40));

  const t = await page.evaluate(() => {
    document.getElementById('aup-l4').click();
    return { sec: AUP.segs[4].start_sec, pending: AUP.pendingClickAt, chapStart: AUP.chapStart, onIdx: AUP.idx };
  });
  ck('★ 这一下点击被记成 pendingClickAt（不是丢掉）',
     typeof t.pending === 'number' && Math.abs(t.pending - t.sec) < 0.01, 'pending=' + t.pending);
  ck('★ 点击后先就地高亮那一句', t.onIdx === 4, 'idx=' + t.onIdx);

  // 播放器就绪后应当自动补跳到那一句
  const want = t.chapStart + t.sec;
  let got = null;
  try {
    await page.waitForFunction((w) => AUP.audio && AUP.audio.src && AUP.audio.readyState >= 1 &&
      Math.abs(AUP.audio.currentTime - w) <= 3, want, { timeout: 30000 });
    got = await page.evaluate(() => AUP.audio.currentTime);
  } catch (e) {}
  ck('★ 播放器就绪后自动补跳到那一句（' + want.toFixed(1) + 's）',
     got !== null, got === null ? 'currentTime 没到位' : '');
  const st = await page.evaluate(() => ({
    pending: AUP.pendingClickAt === undefined ? null : AUP.pendingClickAt,
    on: (document.querySelector('.ap-line.on') || {}).id }));
  ck('★ 补跳后不再挂着 pendingClickAt', !st.pending, 'pending=' + st.pending);
  ck('★ 高亮停在点的那一句上', st.on === 'aup-l4', 'on=' + st.on);
  ck('没有 JS 报错', errs.length === 0, errs.join(' | '));

  await browser.close();
  py(`
import sys
sys.path.insert(0, '${ROOT}')
import db
u = db.q("SELECT * FROM users WHERE role='admin' AND enabled=1 ORDER BY id LIMIT 1", one=True)
db.ex("DELETE FROM ab_session WHERE user_id=?", (u["id"],))
print("")`);
  console.log('\n  文字未就绪时点击：' + pass + ' 通过 / ' + fail + ' 失败');
  process.exit(fail ? 1 : 0);
})().catch(e => { console.log('  出错：' + String(e).slice(0, 200)); process.exit(1); });
