# -*- coding: utf-8 -*-
"""书单讨论：发表文章（管理员/作家等有「发表书单」权限的用户）、
管理员审核后才显示、文章回复由作者或管理员审查后才显示、浏览量统计、最近回复与本月排行、
文章标签（分享/讨论/找书）与标签筛选、管理员置顶、删除回复、文章内嵌图片上传（≤1MB）"""
import os, re, json, time, uuid
from fastapi import APIRouter, Depends, HTTPException, Request, Query, UploadFile, File
from webdeps import json_body, json_body_or_empty
import config, db, auth, notify
from auth import get_current_user, require_admin, can

# ---------------------------------------------------------------- 友情链接
# 书单页右侧栏「浏览排行」下面的「友情链接」。位置放在书单模块里，是因为
# 它和数据一起由 /api/booklists/sidebar 返回（侧栏只发一次请求，多一块不多一次往返）。
#
# 存 system_config 的 site_links 键，值是 JSON 数组：
#     [{"name": "示例的小站", "url": "https://example.com"}, ...]
# 最多 5 条（站长要求，后端也卡这个数）；name 可以留空，留空时侧栏直接显示地址。
SITE_LINKS_KEY = "site_links"
SITE_LINKS_MAX = 5
SITE_LINKS_NAME_MAX = 40
SITE_LINKS_URL_MAX = 500


def site_links():
    """读取友情链接（已清洗），返回 [{"name","url"}, ...]，最多 5 条。

    ★ 地址只收 http/https：侧栏是渲染成 <a href> 的，放行 javascript:/data:
      之类等于给全站开了 XSS 口子（后台能填的人不多，但这是必须守的底线）。
    ★ 坏数据一律**跳过**而不是抛错：历史遗留、手改过配置、半截 JSON 都不该
      让侧栏整块消失 —— 书单页不能因为一条脏友链打不开。
    """
    try:
        raw = json.loads(db.get_config(SITE_LINKS_KEY, "") or "[]")
    except Exception:
        return []
    if not isinstance(raw, list):
        return []
    out = []
    for it in raw:
        if isinstance(it, str):       # 兼容「只存了地址」的写法
            it = {"name": "", "url": it}
        if not isinstance(it, dict):
            continue
        url = str(it.get("url") or "").strip()
        if not re.match(r"^https?://", url, re.I):
            continue
        out.append({"name": str(it.get("name") or "").strip()[:SITE_LINKS_NAME_MAX],
                    "url": url[:SITE_LINKS_URL_MAX]})
        if len(out) >= SITE_LINKS_MAX:
            break
    return out


def site_links_save(items):
    """保存友情链接：校验后落库，返回清洗后的列表（不合法直接 400）。

    ★ 校验失败必须报错而不是静默丢弃：后台点「保存」就该知道哪一条不合格，
      悄悄少存一条是最难查的那类 bug（用户以为存上了）。
    """
    if not isinstance(items, list):
        raise HTTPException(400, "友情链接格式不对")
    if len(items) > SITE_LINKS_MAX:
        raise HTTPException(400, "友情链接最多 %d 条" % SITE_LINKS_MAX)
    out = []
    for i, it in enumerate(items, 1):
        if isinstance(it, str):
            it = {"name": "", "url": it}
        if not isinstance(it, dict):
            raise HTTPException(400, "第 %d 条格式不对" % i)
        url = str(it.get("url") or "").strip()
        if not url:
            continue                  # 后台留空的一行：忽略，不算错误
        if not re.match(r"^https?://", url, re.I):
            raise HTTPException(400, "第 %d 条的地址要以 http:// 或 https:// 开头" % i)
        out.append({"name": str(it.get("name") or "").strip()[:SITE_LINKS_NAME_MAX],
                    "url": url[:SITE_LINKS_URL_MAX]})
    db.set_config(SITE_LINKS_KEY, json.dumps(out, ensure_ascii=False))
    return out

router = APIRouter(prefix="/api")

# 文章标签：key → 中文名
BL_TAGS = {"share": "书单", "discuss": "讨论", "find": "分享"}

# 「分享」文章：key 沿用历史值 find，界面上显示为「分享」
# 审核通过后发树叶奖励的标签 → 对应的奖励配置种类（讨论不在表内，不发放）
BL_REWARD_KINDS = {"share": "booklist", "find": "share_article"}

# 后台「书单审核」列表每页条数
REVIEW_PAGE_SIZE = 15

# 文章图片：允许的类型 + 大小上限（1MB）
_IMG_EXTS = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp"}
_IMG_MAX = 1024 * 1024

# 文章内嵌视频：只收浏览器能直接播的容器 + 大小上限（50MB）
_VIDEO_EXTS = {".mp4", ".webm", ".ogv", ".mov", ".m4v"}
_VIDEO_MAX = 50 * 1024 * 1024


def _user_name(u):
    return u["name"] or u["username"]


def _now():
    return db.now()


def _get_article_or_404(blid):
    a = db.q("SELECT * FROM booklists WHERE id=?", (blid,), one=True)
    if not a:
        raise HTTPException(404, "书单不存在")
    return a


def _can_view_article(user, a):
    """可见：已审核 或 作者本人 或 管理员"""
    if a["status"] == "approved":
        return True
    if user and user["id"] and (a["author_id"] == user["id"] or user["role"] == "admin"):
        return True
    return False


def _visible_comments(blid, user):
    """回复列表：普通用户仅见已审查通过的；作者/管理员可见全部（含待审查）"""
    a = _get_article_or_404(blid)
    is_owner = bool(user and user["id"] and (a["author_id"] == user["id"] or user["role"] == "admin"))
    w = "c.booklist_id=? AND c.status='approved'"
    args = [blid]
    if is_owner:
        w = "c.booklist_id=?"
    rows = db.q(
        f"SELECT c.*, u.username AS u_name, u.name AS u_real FROM booklist_comments c "
        f"LEFT JOIN users u ON u.id=c.user_id WHERE {w} ORDER BY c.created_at ASC", args)
    out = []
    for r in rows:
        d = dict(r)
        d["user_name"] = r["u_real"] or r["u_name"] or "已注销"
        d.pop("u_real", None); d.pop("u_name", None)
        out.append(d)
    return out, is_owner


def _record_view(request: Request, blid, user):
    """浏览计数（去重：同一访客同一文章每天只计 1 次）。
    注意：INSERT OR IGNORE 即使被唯一索引忽略也会开启隐式事务，
    必须无条件 commit，否则连接悬挂持写锁导致全站写请求 database is locked"""
    visitor = f"u{user['id']}" if (user and user["id"]) else f"ip{request.client.host}"
    day = _now()[:10]
    c = db.get_conn()
    cur = c.execute("INSERT OR IGNORE INTO booklist_views (booklist_id, visitor, day, created_at) VALUES (?,?,?,?)",
                    (blid, visitor, day, _now()))
    c.commit()
    if cur.rowcount:
        db.ex("UPDATE booklists SET view_count=view_count+1 WHERE id=?", (blid,))


# ---------- 游客/用户可见 ----------
@router.get("/booklists")
def booklists(page: int = Query(1, ge=1), page_size: int = Query(15, ge=1, le=50),
              q: str = Query(""), tag: str = Query(""), user=Depends(auth.get_optional_user)):
    """已审核通过的文章列表（分页，置顶优先 + 时间倒序）；支持 q 搜索标题与内容、tag 按标签筛选
    管理员额外可见「待审核」文章，便于在书单讨论页直接点开审阅"""
    if user and user["role"] == "admin":
        where, args = "a.status IN ('approved','pending')", []
    else:
        where, args = "a.status='approved'", []
    if (q or "").strip():
        like = f"%{q.strip()}%"
        where += " AND (a.title LIKE ? OR a.content LIKE ?)"
        args += [like, like]
    if (tag or "").strip() in BL_TAGS:
        where += " AND a.tag=?"
        args.append(tag.strip())
    total = db.q(f"SELECT COUNT(*) n FROM booklists a WHERE {where}", args, one=True)["n"]
    pages = max(1, (total + page_size - 1) // page_size)
    rows = db.q(
        f"SELECT a.id, a.title, a.content, a.author_id, a.tag, a.pinned, a.status, a.view_count, a.created_at, a.updated_at, "
        f"u.username AS author_username, u.name AS author_real, "
        f"(SELECT COUNT(*) FROM booklist_comments c WHERE c.booklist_id=a.id AND c.status='approved') AS comment_count "
        f"FROM booklists a LEFT JOIN users u ON u.id=a.author_id "
        f"WHERE {where} ORDER BY a.pinned DESC, a.created_at DESC, a.id DESC LIMIT ? OFFSET ?",
        args + [page_size, (page - 1) * page_size])
    items = []
    for r in rows:
        d = dict(r)
        d["author_name"] = r["author_real"] or r["author_username"] or "佚名"
        d["brief"] = (r["content"] or "").replace("\n", " ").strip()[:120]
        d.pop("author_real", None); d.pop("author_username", None)
        items.append(d)
    return {"items": items, "total": total, "page": page, "pages": pages}


@router.get("/booklists/sidebar")
def booklists_sidebar(user=Depends(auth.get_optional_user)):
    """右侧栏：最近回复 + 本月浏览排行"""
    month = _now()[:7]
    recent = db.q(
        "SELECT c.id, c.content, c.booklist_id, c.created_at, u.username AS u_name, u.name AS u_real, a.title AS bl_title "
        "FROM booklist_comments c LEFT JOIN users u ON u.id=c.user_id "
        "LEFT JOIN booklists a ON a.id=c.booklist_id "
        "WHERE c.status='approved' AND a.status='approved' "
        "ORDER BY c.id DESC LIMIT 8")
    recent = [{"id": r["id"], "content": (r["content"] or "").strip()[:60],
               "booklist_id": r["booklist_id"], "booklist_title": r["bl_title"],
               "user_name": r["u_real"] or r["u_name"] or "佚名", "created_at": r["created_at"]}
              for r in recent]
    # ★ 浏览排行必须与**文章页显示的数字**一致。
    #   文章页显示的是 booklists.view_count（累计、同一访客同一天只记 1 次），
    #   而这里原先按 booklist_views 里「本月」的行数统计 —— 于是同一篇文章
    #   文章页写 164 次、排行榜写 71 次，用户一眼就看出「不同步」。
    #   改成直接读 view_count：它本来就是实时累计值，永远是当前真实数字。
    top = db.q(
        "SELECT id AS booklist_id, title, view_count AS views FROM booklists "
        "WHERE status='approved' ORDER BY view_count DESC, id DESC LIMIT 8")
    top = [{"booklist_id": r["booklist_id"], "title": r["title"],
            "views": int(r["views"] or 0)} for r in top]

    # 「最新签到」：最近签到的 10 个用户 + 各自**当前**树叶余额与连签天数。
    # 余额取 user_leaves 的实时值（不是签到当时的值）—— 用户要看的是「他现在有多少」。
    signins = db.q(
        "SELECT s.user_id, s.signin_date, s.created_at, s.leaves, s.bonus, s.streak, "
        "       u.username, u.name AS real_name, "
        "       COALESCE(ul.balance, 0) AS balance "
        "FROM signin_log s LEFT JOIN users u ON u.id=s.user_id "
        "LEFT JOIN user_leaves ul ON ul.user_id=s.user_id "
        "WHERE u.id IS NOT NULL AND u.enabled=1 "
        "ORDER BY s.created_at DESC LIMIT 10")
    latest_signins = []
    for r in signins:
        nm = r["real_name"] or r["username"] or "已注销"
        latest_signins.append({
            "user_id": r["user_id"],
            "name": nm,
            "initial": (nm or "?")[0].upper(),
            "balance": int(r["balance"] or 0),
            "streak": int(r["streak"] or 0),
            "leaves": int(r["leaves"] or 0),
            "bonus": int(r["bonus"] or 0),
            "signin_date": r["signin_date"],
            "created_at": r["created_at"],
        })
    return {"recent_comments": recent, "top_views": top, "latest_signins": latest_signins,
            # 友情链接：和侧栏其它数据一起返回，前端不用再发一次请求
            "links": site_links()}


@router.get("/booklists/mine")
def booklists_mine(user=Depends(get_current_user)):
    """我发表的书单（含审核状态）"""
    rows = db.q(
        "SELECT a.*, (SELECT COUNT(*) FROM booklist_comments c WHERE c.booklist_id=a.id) AS comment_count "
        "FROM booklists a WHERE a.author_id=? ORDER BY a.created_at DESC, a.id DESC", (user["id"],))
    return {"items": [dict(r) for r in rows]}


@router.get("/booklists/{blid}")
def booklist_detail(blid: int, request: Request, user=Depends(auth.get_optional_user)):
    """书单详情 + 回复列表；浏览计数（去重）"""
    a = _get_article_or_404(blid)
    if not _can_view_article(user, a):
        raise HTTPException(404, "书单不存在")
    # 待审文章不计浏览数（尚未公开，避免通过后带着内部浏览记录）
    if a["status"] == "approved":
        _record_view(request, blid, user)
        a = _get_article_or_404(blid)      # 记浏览后重新读取，返回最新浏览量
    comments, is_owner = _visible_comments(blid, user)
    author = db.q("SELECT username, name FROM users WHERE id=?", (a["author_id"],), one=True)
    return {"article": dict(a),
            "author_name": (author["name"] or author["username"]) if author else "佚名",
            "comments": comments, "is_owner": is_owner,
            "can_review_comments": is_owner,
            # 管理员可见「通过申请 / 驳回申请」按钮
            "can_review_article": bool(user and user["role"] == "admin" and a["status"] == "pending")}


@router.post("/booklists")
def booklist_create(request: Request, body=Depends(json_body), user=Depends(get_current_user)):
    """发表文章：需「发表书单」权限；管理员发表直接通过，其余待管理员审核；可选标签（分享/讨论/找书）"""
    if not can(user, "publish_booklist"):
        raise HTTPException(403, "无发表书单权限，请联系管理员开通")
    title = (body.get("title") or "").strip()
    content = (body.get("content") or "").strip()
    tag = (body.get("tag") or "").strip()
    if tag and tag not in BL_TAGS:
        raise HTTPException(400, "标签不合法")
    if not title:
        raise HTTPException(400, "标题不能为空")
    if len(title) > 80:
        raise HTTPException(400, "标题过长（最多 80 字）")
    if not content:
        raise HTTPException(400, "内容不能为空")
    # 管理员与总编（writer 分组）免审批，直接发布
    status = "approved" if auth.is_trusted(user) else "pending"
    blid = db.ex("INSERT INTO booklists (title,content,author_id,status,tag,created_at,updated_at) VALUES (?,?,?,?,?,?,?)",
                 (title, content, user["id"], status, tag, _now(), _now()))
    db.log_audit(user, "booklist_publish", "booklist", blid,
                 f"发表书单《{title}》" + ("" if status == "approved" else "（待审核）"))
    if status == "pending":
        # 通知管理员审核（站内消息 + Server酱）
        notify.notify_admins("新的书单待审核", f"{_user_name(user)} 发表了《{title}》，等待审核。",
                             kind="review", ref_type="booklist", ref_id=blid,
                             extra=[("作者", _user_name(user)), ("标题", title),
                                    ("标签", BL_TAGS.get(tag, "无"))])
    return {"id": blid, "status": status, "ok": True}


@router.put("/booklists/{blid}")
def booklist_update(blid: int, request: Request, body=Depends(json_body), user=Depends(get_current_user)):
    """编辑自己的书单（管理员可编辑任意）：已通过的文章修改后重新进入待审核"""
    a = _get_article_or_404(blid)
    if a["author_id"] != user["id"] and user["role"] != "admin":
        raise HTTPException(403, "只能编辑自己的书单")
    title = (body.get("title") or "").strip()
    content = (body.get("content") or "").strip()
    tag = (body.get("tag") or "").strip()
    if tag and tag not in BL_TAGS:
        raise HTTPException(400, "标签不合法")
    if not title or not content:
        raise HTTPException(400, "标题与内容不能为空")
    # 同上：免审批身份编辑后不必重新送审
    status = "approved" if auth.is_trusted(user) else "pending"
    db.ex("UPDATE booklists SET title=?, content=?, status=?, tag=?, updated_at=? WHERE id=?",
          (title, content, status, tag, _now(), blid))
    db.log_audit(user, "booklist_update", "booklist", blid, f"编辑书单《{title}》")
    return {"id": blid, "status": status, "ok": True}


@router.delete("/booklists/{blid}")
def booklist_delete(blid: int, user=Depends(get_current_user)):
    """删除书单（作者本人或管理员），级联删除回复与浏览记录"""
    a = _get_article_or_404(blid)
    if a["author_id"] != user["id"] and user["role"] != "admin":
        raise HTTPException(403, "只能删除自己的书单")
    db.ex("DELETE FROM booklists WHERE id=?", (blid,))
    db.ex("DELETE FROM booklist_comments WHERE booklist_id=?", (blid,))
    db.ex("DELETE FROM booklist_views WHERE booklist_id=?", (blid,))
    db.log_audit(user, "booklist_delete", "booklist", blid, f"删除书单《{a['title']}》")
    return {"ok": True}


@router.post("/booklists/{blid}/pin")
def booklist_pin(blid: int, request: Request, body=Depends(json_body), user=Depends(require_admin)):
    """管理员置顶 / 取消置顶文章（置顶的文章排在列表最前）"""
    a = _get_article_or_404(blid)
    pinned = 1 if body.get("pinned") else 0
    db.ex("UPDATE booklists SET pinned=? WHERE id=?", (pinned, blid))
    db.log_audit(user, "booklist_pin", "booklist", blid,
                 f"{'置顶' if pinned else '取消置顶'}书单《{a['title']}》")
    return {"ok": True, "pinned": pinned}


def _save_media(file, user, exts, max_bytes, folder, kinds, tip):
    """把上传的图片/视频落盘，返回可访问的 URL。

    图片和视频走的是同一个 /uploads 静态目录（FastAPI 的 StaticFiles 按扩展名给
    Content-Type，并且支持 Range 请求 —— 视频拖动进度条靠的就是它）。
    """
    name = file.filename or ""
    ext = os.path.splitext(name)[1].lower()
    if ext not in exts:
        raise HTTPException(400, "仅支持 " + kinds)
    data = file.file.read()
    if not data:
        raise HTTPException(400, tip + "内容为空")
    if len(data) > max_bytes:
        raise HTTPException(400, "%s大小不能超过 %s" % (tip, _readable_size(max_bytes)))
    fname = f"bl_{user['id']}_{int(time.time())}_{uuid.uuid4().hex[:8]}{ext}"
    with open(os.path.join(folder, fname), "wb") as fh:
        fh.write(data)
    return {"url": f"/uploads/{fname}", "ok": True}


def _readable_size(n):
    if n >= 1024 * 1024:
        return "%dMB" % (n // (1024 * 1024))
    return "%dKB" % (n // 1024)


@router.post("/booklists/upload-image")
def booklist_upload_image(file: UploadFile = File(...), user=Depends(get_current_user)):
    """发表文章时上传内嵌图片（≤1MB），返回图片 URL，供 Markdown 插入"""
    if not can(user, "publish_booklist"):
        raise HTTPException(403, "无发表书单权限，请联系管理员开通")
    return _save_media(file, user, _IMG_EXTS, _IMG_MAX, config.IMAGE_DIR,
                       "JPG/PNG/GIF/WebP/BMP 图片", "图片")


@router.post("/booklists/upload-video")
def booklist_upload_video(file: UploadFile = File(...), user=Depends(get_current_user)):
    """发表文章时上传内嵌视频（≤50MB），返回视频 URL，供 Markdown 插入

    只收浏览器能直接播的容器（mp4/webm/ogv，mov 与 m4v 通常也是 H.264+MP4，
    现代浏览器多数能放）。不做转码：转码要 ffmpeg 长时间占 CPU，而且现在
    客户端上传的本来就是手机直接录的 mp4。
    """
    if not can(user, "publish_booklist"):
        raise HTTPException(403, "无发表书单权限，请联系管理员开通")
    return _save_media(file, user, _VIDEO_EXTS, _VIDEO_MAX, config.IMAGE_DIR,
                       "MP4/WebM/OGV/MOV/M4V 视频", "视频")


# ---------- 回复 ----------
@router.post("/booklists/{blid}/comments")
def booklist_comment(blid: int, request: Request, body=Depends(json_body), user=Depends(get_current_user)):
    """回复书单：登录用户可回复；作者本人/管理员回复直接显示，其余待作者或管理员审查"""
    a = _get_article_or_404(blid)
    if a["status"] != "approved":
        raise HTTPException(400, "书单尚未发布")
    content = (body.get("content") or "").strip()
    if not content:
        raise HTTPException(400, "回复内容不能为空")
    if len(content) > 2000:
        raise HTTPException(400, "回复内容过长（最多 2000 字）")
    # 免审批身份、以及书单作者本人回复，都直接显示
    status = "approved" if (auth.is_trusted(user) or a["author_id"] == user["id"]) else "pending"
    cid = db.ex("INSERT INTO booklist_comments (booklist_id,user_id,content,status,created_at) VALUES (?,?,?,?,?)",
                (blid, user["id"], content, status, _now()))
    # 书单被回复：通知作者本人（自己回复自己不再提醒）
    if a["author_id"] and a["author_id"] != user["id"]:
        _excerpt = content[:60] + ("…" if len(content) > 60 else "")
        notify.notify_user(a["author_id"], "您的书单收到新回复",
                           f"{_user_name(user)} 回复了《{a['title']}》：{_excerpt}",
                           kind="booklist", from_id=user["id"],
                           # ★ 直达**这一篇**书单，不是书单列表页。
                           #   原来写死 "#/booklists"，点「前往查看」只到列表，
                           #   还得自己一页页翻出是哪一篇。
                           link="#/booklist/%d" % blid,
                           ref_type="booklist", ref_id=blid,
                           extra=[("书单", a["title"]), ("回复者", _user_name(user)),
                                  ("回复内容", content[:500])])
    # 回复待审查时，同时提醒管理员（作者审查自己书单的回复，管理员可审查全部）
    if status == "pending":
        notify.notify_admins("新的书单回复待审查",
                             f"{_user_name(user)} 回复了《{a['title']}》：{content[:60]}",
                             kind="review",
                             # ★ 以前这里**没给 link**，消息弹窗底部就只剩一个「关闭」——
                             #   管理员收到「待审查」提醒却点不进去。给上同一条直达链接。
                             link="#/booklist/%d" % blid,
                             ref_type="booklist", ref_id=blid,
                             extra=[("书单", a["title"]), ("回复者", _user_name(user)),
                                    ("回复内容", content[:500])])
    return {"id": cid, "status": status, "ok": True}


@router.post("/booklists/{blid}/comments/{cid}/review")
def booklist_comment_review(blid: int, cid: int, request: Request, body=Depends(json_body), user=Depends(get_current_user)):
    """作者审查自己书单下的回复 / 管理员审查任意回复：approve 通过 / reject 拒绝"""
    a = _get_article_or_404(blid)
    if a["author_id"] != user["id"] and user["role"] != "admin":
        raise HTTPException(403, "只有书单作者或管理员可以审查回复")
    action = body.get("action", "")
    if action not in ("approve", "reject"):
        raise HTTPException(400, "操作类型错误")
    c = db.q("SELECT * FROM booklist_comments WHERE id=? AND booklist_id=?", (cid, blid), one=True)
    if not c:
        raise HTTPException(404, "回复不存在")
    if c["status"] != "pending":
        raise HTTPException(400, "该回复已处理")
    new_status = "approved" if action == "approve" else "rejected"
    # 并发抢占：审核是终态，判断与写入必须在一个条件 UPDATE 里完成。
    # 原来先 SELECT 再 UPDATE，两个管理员同时点「通过」会双双成功、
    # 作者收到两条通知。rowcount 为 0 = 已被别人先审掉了。
    if not db.ex_count("UPDATE booklist_comments SET status=? WHERE id=? AND status='pending'",
                       (new_status, cid)):
        raise HTTPException(400, "该回复已处理")
    db.log_audit(user, "booklist_comment_review", "booklist", blid,
                 f"{'通过' if action == 'approve' else '拒绝'}书单回复 #{cid}")
    # 回复作者本人写的回复被审查后，通知其结果
    if c["user_id"] != user["id"]:
        _ok = action == "approve"
        notify.notify_user(c["user_id"], "书单回复审核结果",
                           f"您在《{a['title']}》下的回复" + ("已通过审核并显示。" if _ok else "未通过审核。"),
                           kind="booklist", link="#/booklists", ref_type="booklist", ref_id=blid,
                           extra=[("书单", a["title"]), ("审核结果", "已通过" if _ok else "未通过")])
    return {"ok": True}


@router.delete("/booklists/{blid}/comments/{cid}")
def booklist_comment_delete(blid: int, cid: int, user=Depends(get_current_user)):
    """删除回复：回复作者本人 / 文章作者 / 管理员可删除"""
    a = _get_article_or_404(blid)
    c = db.q("SELECT * FROM booklist_comments WHERE id=? AND booklist_id=?", (cid, blid), one=True)
    if not c:
        raise HTTPException(404, "回复不存在")
    if user["role"] != "admin" and a["author_id"] != user["id"] and c["user_id"] != user["id"]:
        raise HTTPException(403, "只能删除自己的回复，文章作者与管理员可删除任意回复")
    db.ex("DELETE FROM booklist_comments WHERE id=?", (cid,))
    db.log_audit(user, "booklist_comment_delete", "booklist", blid, f"删除书单回复 #{cid}")
    return {"ok": True}


# ---------- 管理员：审核文章 ----------
@router.get("/admin/booklist-review")
def admin_booklist_review(status: str = Query("pending"), page: int = Query(1),
                          cpage: int = Query(1), user=Depends(require_admin)):
    """管理员审核区：文章 + 待审查回复。

    两处内容都按时间倒序（最新的在最前）分页返回，每页 REVIEW_PAGE_SIZE 条。
    """
    # status 走的是查询参数，加白名单：避免传任意值当「万能筛选」用
    if status not in ("pending", "approved", "rejected"):
        raise HTTPException(400, "状态参数错误")
    size = REVIEW_PAGE_SIZE
    total = db.q("SELECT COUNT(*) n FROM booklists WHERE status=?", (status,), one=True)["n"]
    pages = max(1, (total + size - 1) // size)
    page = max(1, min(int(page or 1), pages))
    rows = db.q(
        "SELECT a.*, u.username AS u_name, u.name AS u_real FROM booklists a "
        "LEFT JOIN users u ON u.id=a.author_id WHERE a.status=? "
        "ORDER BY a.created_at DESC, a.id DESC LIMIT ? OFFSET ?",
        (status, size, (page - 1) * size))
    arts = []
    for r in rows:
        d = dict(r)
        # 两个字段都要取出来，不能写成 a or b（短路会漏掉第二个 pop）
        _real, _uname = d.pop("u_real", None), d.pop("u_name", None)
        d["author_name"] = _real or _uname or "佚名"
        arts.append(d)

    ctotal = db.q("SELECT COUNT(*) n FROM booklist_comments WHERE status='pending'", one=True)["n"]
    cpages = max(1, (ctotal + size - 1) // size)
    cpage = max(1, min(int(cpage or 1), cpages))
    crows = db.q(
        "SELECT c.*, a.title AS bl_title, u.username AS u_name, u.name AS u_real "
        "FROM booklist_comments c LEFT JOIN booklists a ON a.id=c.booklist_id "
        "LEFT JOIN users u ON u.id=c.user_id WHERE c.status='pending' "
        "ORDER BY c.created_at DESC, c.id DESC LIMIT ? OFFSET ?",
        (size, (cpage - 1) * size))
    coms = []
    for r in crows:
        d = dict(r)
        _real, _uname = d.pop("u_real", None), d.pop("u_name", None)
        d["user_name"] = _real or _uname or "已注销"
        coms.append(d)

    return {"articles": arts, "comments": coms,
            "page": page, "pages": pages, "total": total, "size": size,
            "cpage": cpage, "cpages": cpages, "ctotal": ctotal,
            "pending_articles": db.q("SELECT COUNT(*) n FROM booklists WHERE status='pending'", one=True)["n"],
            "pending_comments": ctotal}


@router.post("/admin/booklists/{blid}/review")
def admin_booklist_review_handle(blid: int, request: Request, body=Depends(json_body), user=Depends(require_admin)):
    """管理员审核书单文章：approve 通过（显示）/ reject 拒绝（可带驳回理由，原文带给作者）"""
    action = body.get("action", "")
    reason = (body.get("reason") or "").strip()
    if len(reason) > 200:
        raise HTTPException(400, "驳回理由过长（最多 200 字）")
    if action not in ("approve", "reject"):
        raise HTTPException(400, "操作类型错误")
    a = _get_article_or_404(blid)
    if a["status"] != "pending":
        raise HTTPException(400, "该书单已处理")
    new_status = "approved" if action == "approve" else "rejected"
    db.ex("UPDATE booklists SET status=?, updated_at=? WHERE id=?", (new_status, _now(), blid))
    db.log_audit(user, "booklist_review", "booklist", blid,
                 f"{'审核通过' if action == 'approve' else '拒绝'}书单《{a['title']}》"
                 + (f"，理由：{reason}" if (reason and action == "reject") else ""))
    # 审核通过发放树叶奖励：「书单」「分享」两种标签各按自己的数量发放，讨论不发放
    gained = 0
    rkind = BL_REWARD_KINDS.get((a["tag"] or "").strip())
    if action == "approve" and rkind and a["author_id"]:
        gained = db.grant_leaves(a["author_id"], rkind, db.reward_amount(rkind),
                                 ref_type="booklist", ref_id=blid,
                                 note=f"《{BL_TAGS.get(a['tag'], '文章')}》{a['title']} 审核通过")
        if gained:
            db.log_audit(user, "leaf_reward", "booklist", blid,
                         f"{BL_TAGS.get(a['tag'], '文章')}《{a['title']}》通过，奖励作者 {gained} 树叶")
    # 书单审核结果通知作者
    if a["author_id"]:
        _ok = action == "approve"
        _msg = f"您发表的《{a['title']}》" + ("已通过审核，现已公开展示。" if _ok else "未通过审核。")
        _extra = [("标题", a["title"]), ("审核结果", "已通过" if _ok else "未通过")]
        if not _ok and reason:
            # 驳回理由原文带给作者（显示在「我的消息」里）
            _msg += f"\n\n驳回理由：{reason}"
            _extra.append(("驳回理由", reason))
        if gained:
            _msg += f"奖励 {gained} 片树叶已到账。"
            _extra.append(("树叶奖励", f"+{gained}"))
        notify.notify_user(a["author_id"], "书单审核结果", _msg,
                           kind="review", link="#/booklists", ref_type="booklist", ref_id=blid,
                           extra=_extra)
    return {"ok": True, "leaves": gained}