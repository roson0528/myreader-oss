#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""失败文件重试：failed_bulk 中因编码无法经 FTP RETR 的源文件，
通过 SFTP 按大小匹配真实文件名 -> 读取 -> FTP 写入计划的分类目录。"""
import os, json, sys, time, ftplib, paramiko
from difflib import SequenceMatcher

W = os.path.dirname(os.path.abspath(__file__))
ST = W + "/state"
HOST, PORT, USER, PWD = "192.0.2.200", 21021, "bookadmin", "CHANGE_ME_STRONG_PASSWORD"
BASE = "/books"

def load_done(path):
    s = set()
    if os.path.exists(path):
        for line in open(path, encoding="utf-8"):
            line = line.strip()
            if line:
                s.add(line.split("\t")[0])
    return s

def append_line(path, text):
    with open(path, "a", encoding="utf-8") as fh:
        fh.write(text + "\n")

def main(keep_failed=False, dry_run=False):
    plan = json.load(open(ST + "/plan.json"))
    by_src = {p["src"]: p for p in plan["plans"]}
    fails = [l.split("\t")[0] for l in open(ST + "/failed_bulk.jsonl", encoding="utf-8") if l.strip()]
    if not fails:
        print("无失败文件")
        return
    done = load_done(ST + "/done_bulk.jsonl")
    remaining = [f for f in fails if f not in done]
    print(f"失败 {len(fails)} 个, 待重试 {len(remaining)} 个")

    c = None
    for i in range(8):
        try:
            c = paramiko.SSHClient()
            c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            c.connect(HOST, port=22, username=USER, password=PWD, timeout=30,
                      allow_agent=False, look_for_keys=False)
            break
        except Exception as e:
            print(f"SSH 重试 {i+1}: {type(e).__name__}")
            c = None
            time.sleep(20)
    if c is None:
        print("SSH 不可用，暂缓")
        return
    s = c.open_sftp()
    f = ftplib.FTP(); f.encoding = "gbk"
    f.connect(HOST, PORT, timeout=60); f.login(USER, PWD)
    f.cwd(BASE)

    ok, fail = 0, []
    skipped_junk = 0
    for rel in remaining:
        base = rel.rsplit("/", 1)[-1]
        # AppleDouble/垃圾元数据文件：非书籍，跳过
        if base.startswith("._") or base == ".DS_Store" or "__MACOSX" in rel:
            skipped_junk += 1
            append_line(ST + "/skipped_junk.txt", rel)
            continue
        p = by_src.get(rel)
        if not p:
            continue
        parent = BASE + "/" + rel.rsplit("/", 1)[0]
        wsize = p["size"]
        try:
            cand = [e for e in s.listdir_attr(parent) if e.st_size == wsize]
            if not cand:
                fail.append((rel, "无大小匹配"))
                continue
            # 优先名称相似度最高的
            want = rel.rsplit("/", 1)[-1]
            best = max(cand, key=lambda e: SequenceMatcher(None, want, e.filename).ratio())
            full = parent + "/" + best.filename
            dest = BASE + "/" + p["dest"]
            if dry_run:
                print(f"[dry] {want[:40]} -> {best.filename[:40]} ({wsize/1e6:.1f}MB) -> {p['cat_folder']}/")
                continue
            rf = s.open(full, "rb")
            try:
                try: f.mkd(p["cat_folder"])
                except Exception: pass
                f.storbinary("STOR " + dest, rf, blocksize=1 << 20)
            finally:
                rf.close()
            got = f.size(dest)
            if got == wsize:
                append_line(ST + "/done_bulk.jsonl", f"{rel}\t{p['dest']}\t{wsize}")
                ok += 1
                print(f"OK {rel.split('/')[-1][:44]} ({wsize/1e6:.1f}MB)")
            else:
                try: f.delete(dest)
                except Exception: pass
                fail.append((rel, f"size {got} vs {wsize}"))
        except Exception as e:
            fail.append((rel, type(e).__name__ + ": " + str(e)[:80]))
    # 更新 failed_bulk（只留仍未成功的）；--keep-failed 时跳过（引擎运行中并发使用）
    still = [f"{r}\t{why}" for r, why in fail]
    if not keep_failed:
        with open(ST + "/failed_bulk.jsonl", "w", encoding="utf-8") as fh:
            fh.write("\n".join(still) + ("\n" if still else ""))
    print(f"\n重试完成: 成功 {ok}, 仍失败 {len(fail)}{' (保留原 failed_bulk)' if keep_failed else ''}")
    for r, why in fail:
        print("  FAIL", r.split("/")[-1][:50], why)
    s.close(); f.quit(); c.close()

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--keep-failed", action="store_true",
                    help="不重写 failed_bulk.jsonl（引擎运行中并发使用）")
    ap.add_argument("--dry-run", action="store_true", help="只打印将执行的动作，不复制")
    args = ap.parse_args()
    main(keep_failed=args.keep_failed, dry_run=args.dry_run)