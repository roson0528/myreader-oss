# -*- coding: utf-8 -*-
"""report_sync.py（本地 report 文件夹 → 书架分类自动导入）的回归测试。

带库/带 FTP 的真实跑法（与 test_lite_preset.py 的 HTTP 段同一个思路）：
  1. 纯函数：_skip() 过滤规则、manifest 存取；
  2. 端到端：临时投放区放 md/txt/docx 三份 → run() 入库 3 本
     （owner=test、category=upload、书架分类{临时名}、可读）；
     重跑 = 幂等不重复；改内容 = 更新不新增；
  3. 回收与新鲜度：删投放区文件 → 书架跟着移除；内容改了（哪怕字节数没变）→ 读到最新；
     投放区被清空时默认不删（要 --force）—— 见 §14.119；
  4. 清理：删掉本次创建的书（FTP 副本+行）/书架行/分类，残留必须为 0
     —— 否则会污染 test 账号的书架，连带弄坏 test_lite_reader.js 的还原断言。

命令：venv/bin/python tests/test_report_sync.py
"""
import os, sys, shutil, tempfile, zipfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import report_sync
import db, config, ftp_service, reader
import time

_ok = _fail = 0


def ok(cond, msg):
    global _ok, _fail
    if cond:
        _ok += 1
        print("  ✓ " + msg)
    else:
        _fail += 1
        print("  ✗ " + msg)


TEST_OWNER = "test"
TEST_COLL = "报告同步测试TMP"


def _make_docx(path):
    doc = u'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>
<w:p><w:pPr><w:pStyle w:val="Heading1"/></w:pPr><w:r><w:t>docx标题</w:t></w:r></w:p>
<w:p><w:r><w:t>docx正文段落</w:t></w:r></w:p>
</w:body></w:document>'''
    with zipfile.ZipFile(path, "w") as z:
        z.writestr("[Content_Types].xml",
                   u'<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>'.encode("utf-8"))
        z.writestr("_rels/.rels",
                   u'<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>'.encode("utf-8"))
        z.writestr("word/document.xml", doc.encode("utf-8"))


def _cleanup(uid, tmpdir, manifest_backup):
    prefix = "%s/user_%s/report/" % (config.USER_UPLOAD_DIR, uid)
    rows = db.q("SELECT id, path FROM books WHERE owner_id=? AND path LIKE ?",
                (uid, prefix + "%"), one=False) or []
    for r in rows:
        try:
            ftp_service.delete(r["path"])
        except Exception:
            pass
    ids = [r["id"] for r in rows]
    if ids:
        ph = ",".join("?" * len(ids))
        db.ex("DELETE FROM shelves WHERE book_id IN (%s)" % ph, ids)
        db.ex("DELETE FROM books WHERE id IN (%s)" % ph, ids)
    db.ex("DELETE FROM shelf_collections WHERE user_id=? AND name=?", (uid, TEST_COLL))
    shutil.rmtree(tmpdir, ignore_errors=True)
    if manifest_backup is None:
        if os.path.exists(report_sync.MANIFEST_FILE):
            os.remove(report_sync.MANIFEST_FILE)
    else:
        report_sync.save_manifest(manifest_backup)


def main():
    uid = db.q("SELECT id FROM users WHERE username=? AND enabled=1", (TEST_OWNER,), one=True)
    if not uid:
        ok(False, "测试账号 %s 不存在" % TEST_OWNER)
        sys.exit(1)
    uid = uid["id"]

    # ---- 1. 纯函数 ----
    ok(report_sync._skip("~$临时.docx") and report_sync._skip(".hidden.md")
       and report_sync._skip("x.tmp") and report_sync._skip("note.pdf")
       and not report_sync._skip("报告.md") and not report_sync._skip("报告.DOCX"),
       "_skip()：隐藏/临时/不支持格式被过滤，支持的（含大写后缀）不拦")
    m = {"a": "1", "b": "2"}
    report_sync.save_manifest(m)
    ok(report_sync.load_manifest() == m, "manifest 存取往返一致")

    man_bak = report_sync.load_manifest()
    tmpdir = tempfile.mkdtemp(prefix="report_sync_test_")
    try:
        with open(os.path.join(tmpdir, "测试甲.md"), "w", encoding="utf-8") as fh:
            fh.write("# 甲报告\n\n正文第一段。\n")
        with open(os.path.join(tmpdir, "测试乙.txt"), "w", encoding="utf-8") as fh:
            fh.write("乙报告正文。\n")
        _make_docx(os.path.join(tmpdir, "测试丙.docx"))
        # 干扰项：应被跳过
        open(os.path.join(tmpdir, "~$隐藏.docx"), "w").close()
        open(os.path.join(tmpdir, "笔记.pdf"), "w").close()
        os.mkdir(os.path.join(tmpdir, "子目录"))
        with open(os.path.join(tmpdir, "子目录", "nested.md"), "w", encoding="utf-8") as fh:
            fh.write("子目录里不该导入")

        # ---- 2. 首跑：3 本入库 ----
        st = report_sync.run(report_dir=tmpdir, owner_name=TEST_OWNER,
                             collection_name=TEST_COLL)
        ok(st["new"] == 3 and st["updated"] == 0 and not st["failed"] and st["scanned"] == 3,
           "首跑：投放区 3 个文件全部入库（新增 %d）" % st["new"])
        prefix = "%s/user_%s/report/" % (config.USER_UPLOAD_DIR, uid)
        rows = db.q("SELECT b.path,b.ext,b.title,c.name FROM books b "
                    "JOIN shelves s ON s.book_id=b.id "
                    "JOIN shelf_collections c ON c.id=s.collection_id "
                    "WHERE b.owner_id=? AND b.path LIKE ? AND c.name=?",
                    (uid, prefix + "%", TEST_COLL), one=False)
        ok(len(rows) == 3, "书架「%s」里正好 3 本" % TEST_COLL)
        ok(all(r["ext"] in (".md", ".txt", ".docx") and r["path"].startswith(prefix)
               for r in rows), "入库书都是可读格式、路径都在 upload/user_%d/report/ 下" % uid)
        ftp_ok = all(ftp_service.stat(r["path"]) is not None for r in rows)
        ok(ftp_ok, "FTP 副本都存在（书不会指向不存在的文件）")

        # ---- 3. 重跑：幂等 ----
        st2 = report_sync.run(report_dir=tmpdir, owner_name=TEST_OWNER,
                              collection_name=TEST_COLL)
        ok(st2["new"] == 0 and st2["updated"] == 0 and st2["unchanged"] == 3,
           "重跑幂等：新增 0 / 更新 0 / 未变 3")

        # ---- 4. 内容变了：更新而非新增，书 id 不动 ----
        bid = db.q("SELECT id FROM books WHERE owner_id=? AND path LIKE ? LIMIT 1",
                   (uid, prefix + "%"), one=True)["id"]
        with open(os.path.join(tmpdir, "测试甲.md"), "w", encoding="utf-8") as fh:
            fh.write("# 甲报告（改版）\n\n新正文。\n")
        st3 = report_sync.run(report_dir=tmpdir, owner_name=TEST_OWNER,
                              collection_name=TEST_COLL)
        still = db.q("SELECT id FROM books WHERE id=?", (bid,), one=True)
        ok(st3["updated"] == 1 and st3["new"] == 0 and still is not None,
           "同文件内容变化 → 更新（书 id 不变、进度不丢）")

        # ---- 5. 删书联动（§14.111）：forget_book 删投放区源文件，cron 不会重新导入 ----
        rel_jia = prefix + "测试甲.md"
        report_sync.forget_book(rel_jia, drop_dir=tmpdir)
        ok(not os.path.exists(os.path.join(tmpdir, "测试甲.md"))
           and rel_jia not in report_sync.load_manifest(),
           "forget_book：投放区源文件已删、manifest 已清（删书=删文件）")
        st4 = report_sync.run(report_dir=tmpdir, owner_name=TEST_OWNER,
                              collection_name=TEST_COLL)
        ok(st4["new"] == 0 and st4["unchanged"] == 2 and st4["scanned"] == 2,
           "删源后重跑：只剩乙/丙未变，甲不再被重新导入（新增 0）")

        # ---- 6. 墓碑分支：源文件删不掉（模拟权限失败）→ 墓碑，内容不变不复活 ----
        with open(os.path.join(tmpdir, "测试丁.md"), "w", encoding="utf-8") as fh:
            fh.write("# 丁报告\n\n正文。\n")
        st5 = report_sync.run(report_dir=tmpdir, owner_name=TEST_OWNER,
                              collection_name=TEST_COLL)
        ok(st5["new"] == 1, "新增丁（st5.new=%d）" % st5["new"])
        rel_ding = prefix + "测试丁.md"
        orig_remove = report_sync.os.remove
        report_sync.os.remove = lambda p: (_ for _ in ()).throw(OSError("模拟权限不足"))
        try:
            report_sync.forget_book(rel_ding, drop_dir=tmpdir)
        finally:
            report_sync.os.remove = orig_remove
        m = report_sync.load_manifest()
        ok(m.get(rel_ding, {}).get("deleted") is True
           and os.path.exists(os.path.join(tmpdir, "测试丁.md")),
           "源文件删不掉 → 墓碑标记，文件保留")
        st6 = report_sync.run(report_dir=tmpdir, owner_name=TEST_OWNER,
                              collection_name=TEST_COLL)
        ok(st6["new"] == 0 and st6["unchanged"] >= 3,
           "墓碑未变 → 重跑不复活（新增 0，未变 %d）" % st6["unchanged"])
        with open(os.path.join(tmpdir, "测试丁.md"), "w", encoding="utf-8") as fh:
            fh.write("# 丁报告v2\n\n用户主动改了内容。\n")
        st7 = report_sync.run(report_dir=tmpdir, owner_name=TEST_OWNER,
                              collection_name=TEST_COLL)
        m2 = report_sync.load_manifest()
        ok(st7["updated"] == 1 and not m2.get(rel_ding, {}).get("deleted"),
           "墓碑内容变了 → 重新导入（用户主动改 = 想要它回来）")

        # ---- 7. 投放区删文件 → 书架跟着回收（§14.119：投放区就是真源）----
        #      以前只导入不回收，删了一堆文件书架里还挂着（站长反馈：显示 26 本、实际 8 份）
        rel_yi = prefix + "测试乙.txt"
        bid_yi = db.q("SELECT id FROM books WHERE owner_id=? AND path=?",
                      (uid, rel_yi), one=True)
        os.remove(os.path.join(tmpdir, "测试乙.txt"))
        st8 = report_sync.run(report_dir=tmpdir, owner_name=TEST_OWNER,
                              collection_name=TEST_COLL)
        gone = db.q("SELECT id FROM books WHERE id=?", (bid_yi["id"],), one=True) if bid_yi else None
        ftp_gone = ftp_service.stat(rel_yi) is None if bid_yi else True
        ok(st8["purged"] == 1 and gone is None and ftp_gone,
           "删掉投放区文件 → 再跑即回收（书行与 FTP 副本一起没了）")

        # ---- 8. 内容改了但字节数没变 → 必须读到新内容（缓存新鲜度）----
        v1 = "# 探针甲\n\n第一版正文。\n"
        v2 = "# 探针乙\n\n第二版正文。\n"
        ok(len(v1.encode()) == len(v2.encode()),
           "前置：两版字节数相同（%d），只比大小会漏判" % len(v1.encode()))
        p_mod = os.path.join(tmpdir, "同长改动.md")
        with open(p_mod, "w", encoding="utf-8") as fh:
            fh.write(v1)
        report_sync.run(report_dir=tmpdir, owner_name=TEST_OWNER,
                        collection_name=TEST_COLL)
        row_a = db.q("SELECT * FROM books WHERE owner_id=? AND path=?",
                     (uid, prefix + "同长改动.md"), one=True)
        first = reader.chunks(row_a)[0]["text"]
        time.sleep(1.2)
        with open(p_mod, "w", encoding="utf-8") as fh:
            fh.write(v2)
        report_sync.run(report_dir=tmpdir, owner_name=TEST_OWNER,
                        collection_name=TEST_COLL)
        row_b = db.q("SELECT * FROM books WHERE id=?", (row_a["id"],), one=True)
        second = reader.chunks(row_b)[0]["text"]
        ok("第一版" in first and "第二版" in second,
           "同字节数改内容 → 阅读读到的是最新内容（不是旧缓存）")

        # ---- 9. 投放区被清空 → 默认一本不删，--force 才清（防挂载异常误删）----
        for n in os.listdir(tmpdir):
            fp = os.path.join(tmpdir, n)
            if os.path.isfile(fp):
                os.remove(fp)
        st9 = report_sync.run(report_dir=tmpdir, owner_name=TEST_OWNER,
                              collection_name=TEST_COLL)
        left = db.q("SELECT COUNT(*) n FROM books WHERE owner_id=? AND path LIKE ?",
                    (uid, prefix + "%"), one=True)["n"]
        ok(st9["purged"] == 0 and left > 0 and st9["purge_skipped"],
           "投放区空但没加 force → 一本都不删（保留 %d 本，防挂载异常清空整架）" % left)
        st10 = report_sync.run(report_dir=tmpdir, owner_name=TEST_OWNER,
                               collection_name=TEST_COLL, force=True)
        left2 = db.q("SELECT COUNT(*) n FROM books WHERE owner_id=? AND path LIKE ?",
                     (uid, prefix + "%"), one=True)["n"]
        ok(st10["purged"] == left and left2 == 0,
           "显式 force → 明确要求清空时才真清（移除 %d 本）" % st10["purged"])

    finally:
        _cleanup(uid, tmpdir, man_bak)

    # ---- 5. 清理验证：本次测试一个不留 ----
    prefix = "%s/user_%s/report/" % (config.USER_UPLOAD_DIR, uid)
    n = db.q("SELECT COUNT(*) n FROM books WHERE owner_id=? AND path LIKE ?",
             (uid, prefix + "%"), one=True)["n"]
    c = db.q("SELECT COUNT(*) n FROM shelf_collections WHERE user_id=? AND name=?",
             (uid, TEST_COLL), one=True)["n"]
    ok(n == 0 and c == 0, "清理后残留为 0（books=%d, 分类=%d）—— 不会污染 test 账号书架" % (n, c))

    print("report_sync 回归测试：%d 通过 / %d 失败" % (_ok, _fail))
    sys.exit(0 if _fail == 0 else 1)


if __name__ == "__main__":
    main()