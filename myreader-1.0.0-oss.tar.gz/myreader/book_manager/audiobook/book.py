"""电子书 → 章节正文。

★ 复用云阅读的解析组件（reader.py / formats.py），全部是只读调用，
  不修改它们、也不依赖它们的运行时状态。统一输出 [{idx, title, text}]。

各格式的取法：
  epub / mobi / azw3 → formats.read_epub_toc 拿目录，再逐章 read_epub_chapter
  html / htm         → 直接读文件
  txt / docx / md    → reader.chunks（已经有成熟的分段逻辑）
  pdf                → 不支持（没有可用的 PDF 正文抽取），明确报错而不是静默出空书
"""
import os
import re
import sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE)
import reader as R  # noqa: E402
import formats as F  # noqa: E402


class UnsupportedBook(RuntimeError):
    pass


# 块级标签要变成换行，否则整章会挤成一行，断句就没法做了
_BLOCK_RE = re.compile(
    r"</\s*(p|div|br|li|tr|h[1-6]|section|article|blockquote)\s*>|<\s*br\s*/?\s*>",
    re.I)
_TAG_RE = re.compile(r"<[^>]+>")
_ENT = {"&nbsp;": " ", "&amp;": "&", "&lt;": "<", "&gt;": ">", "&quot;": '"',
        "&#39;": "'", "&apos;": "'", "&mdash;": "—", "&ldquo;": "“", "&rdquo;": "”"}


def html_text(html):
    """HTML → 保留段落边界的纯文本。

    reader._html_to_text 把所有标签换成空格，段落边界就没了；
    有声书按句子合成，段落边界影响停顿与断句，所以这里另写一个。
    """
    if not html:
        return ""
    t = re.sub(r"(?is)<(script|style)[^>]*>.*?</\1>", " ", html)
    t = _BLOCK_RE.sub("\n", t)
    t = _TAG_RE.sub("", t)
    for k, v in _ENT.items():
        t = t.replace(k, v)
    t = re.sub(r"&[a-zA-Z#0-9]{1,8};", " ", t)
    t = t.replace("\u3000", " ").replace("\xa0", " ")
    lines = [re.sub(r"[ \t]+", " ", ln).strip() for ln in t.split("\n")]
    out, blank = [], 0
    for ln in lines:
        if ln:
            out.append(ln)
            blank = 0
        elif out and blank < 1:
            out.append("")
            blank += 1
    return "\n".join(out).strip()


def _epub_like(book):
    """epub / mobi 系：走目录。"""
    toc = R.epub_toc(book)
    if not toc:
        return []
    out = []
    for it in toc:
        try:
            html = R.epub_chapter(book, it.get("href"), "", it.get("fragment") or "")
        except Exception:
            html = ""
        text = html_text(html)
        title = (it.get("title") or "").strip() or ("第 %d 节" % (it.get("idx", 0) + 1))
        # 目录项可能只是封面/版权页，正文为空的跳过，但保留有内容的
        if text:
            out.append({"idx": len(out), "title": title, "text": text})
    return out


def _html_file(book):
    p = _local_path(book)
    if not p or not os.path.isfile(p):
        return []
    with open(p, "rb") as f:
        raw = f.read()
    enc = "utf-8"
    m = re.search(rb'charset=["\']?([\w-]+)', raw[:4096], re.I)
    if m:
        enc = m.group(1).decode("ascii", "ignore")
    try:
        html = raw.decode(enc, "replace")
    except Exception:
        html = raw.decode("utf-8", "replace")
    return [{"idx": 0, "title": book["title"] or "正文", "text": html_text(html)}]


def _local_path(book):
    """书在磁盘上的位置。covers.ensure_local 对 epub 会返回本地副本。"""
    try:
        p = book["path"]
    except Exception:
        return None
    return p


def chapters(book):
    """统一的章节列表。返回 [{idx, title, text}]，已去掉空章节。"""
    k = R.kind(book)
    if k == "pdf":
        raise UnsupportedBook("PDF 暂不支持抽取正文，请先转成 epub 或 txt")
    if k == "unsupported":
        raise UnsupportedBook("不支持的格式：%s" % (book["ext"] or "?"))
    if k in ("epub", "mobi"):
        ch = _epub_like(book)
    elif k == "html":
        ch = _html_file(book)
    else:
        ch = [{"idx": c["idx"], "title": c.get("title") or ("第 %d 节" % (c["idx"] + 1)),
               "text": html_text(c.get("text") or "") if k == "md" else (c.get("text") or "")}
              for c in R.chunks(book)]
    ch = [c for c in ch if (c.get("text") or "").strip()]
    ch = _split_long(ch)
    for i, c in enumerate(ch):
        c["idx"] = i
    if not ch:
        raise UnsupportedBook("这本书解析出来没有正文，无法制作有声书")
    return ch


# 单章超过这么多字就自动分片。
# 起因：实测一本 .azw3 的目录极简，整本书被解析成「1 章 5.7 万字」，
# 于是「每 1 章一个文件」会产出一个巨大的 MP3，既不好传也不好播，
# 中途失败还要整章重来。在**章节层面**先切开，下游（分文件、断点续传、
# 上传）全都不用改一行 —— 切出来的分片就是普通的章。
MAX_CHAPTER_CHARS = 6000


def _split_long(ch, limit=MAX_CHAPTER_CHARS, depth=0):
    """把过长的章节按段落边界切成若干片。深度上限防止极端情况下切不动。"""
    out = []
    for c in ch:
        t = c.get("text") or ""
        if len(t) <= limit or depth >= 4:
            out.append(c)
            continue
        parts = _by_paras(t, limit)
        if len(parts) <= 1:
            out.append(c)
            continue
        for k, p in enumerate(parts):
            out.append({"idx": 0, "title": "%s（%d/%d）" % (c.get("title") or "正文", k + 1, len(parts)),
                        "text": p})
    return out


def _by_paras(text, limit):
    """按段落（空行/换行）累加到接近 limit 就断开；单段本身超长再按句号切。"""
    blocks = [b for b in re.split(r"\n+", text) if b.strip()]
    out, buf = [], ""
    for b in blocks:
        if buf and len(buf) + len(b) + 1 > limit:
            out.append(buf)
            buf = b
        else:
            buf = (buf + "\n" + b) if buf else b
        while len(buf) > limit * 1.6:
            # 段落本身超长（没有换行的整块文本）：退到句末标点切
            cut = max(buf.rfind(x, 0, limit) for x in "。！？…")
            if cut <= 0:
                cut = limit
            else:
                cut += 1
            out.append(buf[:cut])
            buf = buf[cut:]
    if buf.strip():
        out.append(buf)
    return out


def _plan_entry(seq, group, skip):
    """一个文件条目的命名。起名时把被跳过的章排除掉，
    免得文件名里出现"版权信息"这种已经不会被念的内容。"""
    a, b = group[0]["idx"], group[-1]["idx"]
    named = [c for c in group if not (skip and skip(c))]
    if not named:
        named = group
    if len(named) == 1:
        mid = _safe(named[0]["title"])
    else:
        mid = "%s-%s" % (_safe(named[0]["title"]), _safe(named[-1]["title"]))
    return {"seq": seq, "name": "%03d-%s.mp3" % (seq, mid[:80]), "a": a, "b": b}


def plan_files(chs, per_file, skip=None):
    """按「每 N 章一个文件」把章节分组成待产出的 MP3 清单。

    返回 [{seq, name, a, b}]，a/b 是章节下标区间（含两端）。
    名字里的序号补零到 3 位，保证在文件管理器里按名字排序就是播放顺序。

    ★ 分组**永远按完整的章节列表**算，skip 只影响文件名怎么起。
      这一点很重要：分组一旦变化，每个文件覆盖的章节就变了，
      而断点续传的分句缓存是按 (任务, 文件序号, 句序号) 存的 ——
      分组一变全部缓存失效，一本 4 小时的书就得从头再合成一遍。
      所以"跳过版权页"只跳过**该章的声音**，不改变分组和句序号。
    """
    n = max(1, int(per_file or 1))
    out = []
    for i in range(0, len(chs), n):
        out.append(_plan_entry(len(out) + 1, chs[i:i + n], skip))
    return out


# 每字秒数：用于**估算**一段文本要合成多久。只用来分文件，不参与别处。
# 标定口径：《秋园》90,239 字 → 实测 5.9 小时（21,240 秒）→ 0.2354 秒/字；
# 取 0.213 是把它按"含句间停顿前的纯语音"折算后的保守值（实测各章平均误差 17 秒）。
SEC_PER_CHAR = 0.213


def _dp_split(w, F):
    """把权重序列 w 切成 F 段（连续、不重排），最小化「最大段的和」。

    经典 minimax 划分，O(F·n²)，n 是章节数（通常几十到一两百），够快。
    返回 [(a, b)] 下标区间列表。
    """
    n = len(w)
    pre = [0.0] * (n + 1)
    for i, x in enumerate(w):
        pre[i + 1] = pre[i] + x
    INF = float("inf")
    big = [[INF] * (n + 1) for _ in range(F + 1)]
    cut = [[0] * (n + 1) for _ in range(F + 1)]
    big[0][0] = 0.0
    for k in range(1, F + 1):
        for i in range(k, n + 1):
            bv, bc = INF, 0
            for j in range(k - 1, i):
                v = big[k - 1][j]
                if v < INF:
                    s = pre[i] - pre[j]
                    if s > v:
                        v = s
                    if v < bv:
                        bv, bc = v, j
            big[k][i], cut[k][i] = bv, bc
    if big[F][n] == INF:
        return [(0, n)]
    groups, i = [], n
    for k in range(F, 0, -1):
        j = cut[k][i]
        groups.append((j, i))
        i = j
    groups.reverse()
    return groups


def est_minutes(ch, sec_per_char=SEC_PER_CHAR):
    """一章大概要念多久（分钟）。"""
    return len(ch.get("text") or "") * sec_per_char / 60.0


def plan_balanced(chs, target_min=40, max_min=60, skip=None, sec_per_char=SEC_PER_CHAR):
    """按「预估时长」把章节**均衡地**分组成文件（不切章）。

    为什么不是"按句数分"：`_split_long` 会把超长章节按 6000 字切开，所以各章
    **字数**很齐而**句数**差很多（对话密的章句子碎）。实测按字数预测时长逐章平均
    误差 17 秒，按句数 45 秒 —— 按句数分反而更不均匀。

    为什么不是"顺序贪心往目标时长里塞"：短章会单独撑出一个文件。实测《秋园》
    目标 20 分钟时贪心结果的"最大/最小"是 6.66，而下面的均衡划分只有 1.43。

    为什么文件数不能简单按 `总时长/目标` 取整：minimax 的文件数不是单调的，
    《秋园》9 个文件比值 1.43、10 个反而恶化到 2.01。所以这里在目标值附近枚举
    若干文件数，**优先"最大文件不超过上限"**，再在其中挑"最大/最小"最小的那个。

    ★ 只用文本长度估算，不用事后实测时长：分文件边界必须在重跑时算出**完全
      相同**的结果，否则断点续传的分句缓存会全部失效（见 plan_files 的说明）。
    """
    n = len(chs)
    if n == 0:
        return []
    w = []
    for c in chs:
        w.append(0.0 if (skip and skip(c)) else est_minutes(c, sec_per_char))
    total = sum(w)
    tgt = max(1.0, float(target_min or 40))
    cap = max(tgt, float(max_min or 60))
    f0 = max(1, int(round(total / tgt)) if total > 0 else 1)
    lo = max(1, f0 - 3)
    hi = min(n, f0 + 3)
    cands = []
    for F in range(lo, hi + 1):
        g = _dp_split(w, F)
        if len(g) != F:
            continue
        segs = [sum(w[a:b]) for a, b in g]
        mx, mn = max(segs), min(segs)
        cands.append((F, g, mx, mn))
    if not cands:
        return plan_files(chs, max(1, f0), skip)
    ok = [c for c in cands if c[2] <= cap]
    best = min(ok or cands, key=lambda c: (c[2] / max(c[3], 1e-6), c[2]))
    return [_plan_entry(i + 1, chs[a:b], skip) for i, (a, b) in enumerate(best[1])]


_BAD = re.compile(r'[\\/:*?"<>|\r\n\t]+')


def _safe(s, limit=60):
    """把标题变成安全的文件名片段。

    ★ 斜杠不能简单替换成下划线：很多书的目录标题里**本来就带合法的斜杠**，
      比如《秋园》的「第一章 洛阳 南京（1/2）」。一律换成 `_` 会变成
      「（1_2）」，看着像乱码。斜杠在文件名里确实非法必须换，但换成全角的
      `／`（U+FF0F）既合法又跟原样一致，读起来就是「（1／2）」。
      反斜杠同理换全角 `＼`。
    """
    s = (s or "").strip()
    s = s.replace("\\", "＼").replace("/", "／")
    s = _BAD.sub("_", s).strip(" ._")
    return (s or "未命名")[:limit]


# ------------------------------------------------------------------ 非正文识别
# 有声书里把版权页、目录念一遍毫无意义：版权页没人听，目录是一长串章节名。
# 只按**标题**判断，不看内容 —— 正文里也会出现"版权所有"之类的字样，
# 按内容判断必然误伤。匹配的是**整个标题**（先去掉括号里的分节标记和首尾空白），
# 所以「版权战争」这种真正的正文标题不会被误杀。
_FRONT = re.compile(
    r'^(?:'
    r'版权(?:页|信息|声明|所有|说明)?|版權(?:頁|信息)?|'
    r'免责声明|法律声明|声明|'
    r'书名页|書名頁|扉页|扉頁|封面|封底|勒口|护封|书脊|'
    r'内容提要|内容简介|内容介绍|内容摘要|'
    r'图书在版编目(?:\s*\(?CIP\)?)?.*|CIP(?:\s*数据)?.*|'
    r'出版信息|出版说明|出版发行|印刷信息|印次|版次|'
    r'目录|目\s*录|总目录|contents?|'
    r'插页|彩插|插图|'
    r'ISBN.*|'
    r'copyright.*|all rights reserved.*'
    r')$', re.I)

# 去掉标题里的分节标记和序号：「第一章 洛阳 南京（1/2）」→ 先去掉「（1/2）」
_TAIL_PAREN = re.compile(r'[（(【\[][^）)】\]]{0,12}[）)】\]]\s*$')


def clean_title(t):
    t = (t or "").strip()
    for _ in range(3):
        n = _TAIL_PAREN.sub("", t).strip()
        if n == t:
            break
        t = n
    return t


def is_front_matter(title, text="", extra_kw=""):
    """这一章是不是「非正文」（版权页/目录之类），该跳过。

    extra_kw 是用户自己加的额外关键词（逗号分隔），在默认规则之外再加。
    标题命中之后**还要看它确实很短**才跳：一个叫「目录」但有两万字的章节，
    多半是真正的正文内容被起错了名字，宁可念出来也别吞掉。
    """
    t = clean_title(title)
    if not t:
        return False
    hit = bool(_FRONT.match(t))
    if not hit and extra_kw:
        for kw in str(extra_kw).replace("，", ",").split(","):
            kw = kw.strip()
            if kw and kw in t:
                hit = True
                break
    if not hit:
        return False
    # 保险：不是特别短就不跳，避免把正经章节静默吃掉
    return len(text or "") <= 3000


def front_matcher(extra_kw=""):
    """给 plan_files 用的判定函数。"""
    def f(ch):
        return is_front_matter(ch.get("title"), ch.get("text"), extra_kw)
    return f
