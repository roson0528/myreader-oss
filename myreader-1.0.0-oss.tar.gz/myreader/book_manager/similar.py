# -*- coding: utf-8 -*-
"""书库内「同名 / 相似电子书」检索。

**为什么需要**：会员申请共享时，管理员收到的审核消息里只有「谁申请了哪本书」，
管理员无法一眼看出这本书库里是不是已经有了——结果就是同一本书被反复共享、
书库里堆出好几份《底层逻辑》。本模块负责在申请消息里附上：「书库中已有同名电子书：
1、《…》格式 epub 大小 2.05 MB；2、《…》格式 AZW3 大小 2.75 MB」，让管理员据此判断。

**判定口径**（宁清勿滥：结论分「同名」「相似」两档，各自限量，交由管理员判断）：

1. `norm_title` 先把书名归一化成「核心书名」——只剥离明显属于**附属信息**的部分：
   括号补充（作者名、`(Z-Library)`、`（修订版）`、`【豆瓣评分】`）、前置编号
   （`A05169.` / `J5A16797.` / `2024-01`）、尾部书籍编码（`.B09JNHKG31` / `_SoBooKs`）、
   以及全部标点与空白。**不做**同义词替换、不改字序。
2. 归一化后**完全相同**，或一方是另一方的**核心子串**（较短者 ≥ 4 字）→ 「同名」。
   例：《底层逻辑：看清这个世界的底牌 (刘润) (Z-Library)》与
   《A05169. 底层逻辑 看清这个世界的底牌（…）.B09JNHKG31》都归一化成
   「底层逻辑看清这个世界的底牌」，判定同名。
3. 否则用 `difflib` 相似度 ≥ 0.72 → 「相似」。

**性能**：书库有十几万本，逐个归一化全表扫一遍要 1.3 秒（实测），
所以先用「核心书名的前 4 字 / 后 4 字」做 SQL `LIKE` 粗筛，再在候选集里精算。
单次查询在毫秒级。代价是**书名字符被拆散**（如「底 层 逻 辑」）的极端情况会漏，
这种情况在真实数据里可忽略，且不影响主用途。
"""
import re

from difflib import SequenceMatcher

import db

# 括号补充：「(刘润)」「(Z-Library)」「（修订版）」「【豆瓣评分】」「[高清]」
_PAREN = re.compile(r"[（(【\[][^）)】\]]*[）)】\]]")
# 前置编号：A05169. / J5A16797. / 1234_ / 2024-01（要求含数字且有分隔符，避免误伤《1984》）
_DATE_PREFIX = re.compile(r"^\d{4}\s*[-_年./]\s*\d{1,2}\s*[-_月./]?\s*\d{0,2}\s*[日]?\s*[.、_\-—《]*\s*")
_CODE_PREFIX = re.compile(r"^(?=[A-Za-z0-9]*\d)[A-Za-z0-9]{4,}\s*[.、_\-—]\s*")
# 尾部书籍编码：.B09JNHKG31 / _SoBooKs（要求含数字或长度足够，避免吃掉正常书名尾巴）
_CODE_SUFFIX = re.compile(r"[\s.、_\-—]+(?=[A-Za-z0-9]*\d)[A-Za-z0-9]{5,}$")
# 标点与空白（保留中日韩文字、字母、数字、下划线）
_PUNCT = re.compile(r"[^\w\u4e00-\u9fff]+", re.UNICODE)

# 判定门槛
_MIN_CORE = 4          # 核心子串判定要求较短者至少这么长（防「三体」匹配一切）
_SIMILAR_RATIO = 0.72  # 相似度门槛


def norm_title(t):
    """书名归一化成「核心书名」。空书名返回空串。"""
    s = (t or "").strip()
    if not s:
        return ""
    s = _PAREN.sub(" ", s)
    for _ in range(3):          # 前置编号可能连着写好几段（2024-01《…》），循环剥掉
        before = s
        s = _DATE_PREFIX.sub("", s)
        s = _CODE_PREFIX.sub("", s)
        if s == before:
            break
    s = _CODE_SUFFIX.sub("", s)
    return _PUNCT.sub("", s.lower())


def match_kind(needle, hay):
    """两个**已归一化**的书名判定：返回 ('same'|'similar'|None, 分值)"""
    if not needle or not hay:
        return None, 0.0
    if needle == hay:
        return "same", 1.0
    short, long_ = (needle, hay) if len(needle) <= len(hay) else (hay, needle)
    if len(short) >= _MIN_CORE and short in long_:
        return "same", 0.95
    r = SequenceMatcher(None, needle, hay).ratio()
    return ("similar", r) if r >= _SIMILAR_RATIO else (None, r)


def _candidates(core):
    """SQL 粗筛：核心书名的前 4 / 后 4 字出现在原标题里即入选。"""
    if not core:
        return []
    keys = {core[:4]}
    if len(core) > 4:
        keys.add(core[-4:])
    seen, out = set(), []
    for k in keys:
        for r in db.q("SELECT id,title,ext,size FROM books WHERE hidden=0 AND title LIKE ?",
                      ("%" + k + "%",)):
            if r["id"] not in seen:
                seen.add(r["id"])
                out.append(r)
    return out


def find_similar(title, exclude_id=None, limit=3):
    """在书库里找同名/相似电子书。

    返回 {"same": [...], "similar": [...], "more_same": n, "more_similar": n}，
    每项为 {"id","title","ext","size"}。同名排在前面；每档最多 `limit` 条，
    超出部分只计数（避免审核消息长得没法看）。
    """
    core = norm_title(title)
    empty = {"same": [], "similar": [], "more_same": 0, "more_similar": 0}
    if not core:
        return empty
    same, sim = [], []
    for r in _candidates(core):
        if exclude_id and r["id"] == exclude_id:
            continue
        k, sc = match_kind(core, norm_title(r["title"]))
        if not k:
            continue
        item = {"id": r["id"], "title": r["title"], "ext": r["ext"] or "", "size": r["size"] or 0,
                "kind": k, "score": sc}
        (same if k == "same" else sim).append(item)
    # 同名的排前面：完全一致(1.0) → 核心子串(0.95)；相似的按分值降序。
    # 分值并列时书名短的排前面：《底层逻辑：看清这个世界的底牌》优先于
    # 《A05169. 底层逻辑 看清这个世界的底牌（…）.B09JNHKG31》，读起来更像「标准书名」。
    same.sort(key=lambda x: (-x["score"], len(x["title"])))
    sim.sort(key=lambda x: (-x["score"], len(x["title"])))
    return {"same": same[:limit], "similar": sim[:limit],
            "more_same": max(0, len(same) - limit), "more_similar": max(0, len(sim) - limit)}


def _fmt_size(n):
    n = n or 0
    if n >= 1073741824:
        return "%.2f GB" % (n / 1073741824)
    return "%.2f MB" % (n / 1048576)


def _fmt_one(i, n, sep="；"):
    """1、《书名》格式 epub 大小 2.05 MB；"""
    ext = (i["ext"] or "").lstrip(".").upper()
    return "%d、《%s》格式 %s 大小 %s%s" % (n, i["title"], ext or "未知", _fmt_size(i["size"]), sep)


def describe(sim, max_total=6):
    """把检索结果写成审核消息里的一段备注；没有同名/相似书时返回空串。"""
    if not sim or not (sim["same"] or sim["similar"]):
        return ""
    out = []
    if sim["same"]:
        out.append("书库中已有同名电子书：")
        items = sim["same"][:max_total]
        for n, it in enumerate(items, 1):
            out.append(_fmt_one(it, n, "；" if n < len(items) or sim["similar"] or sim["more_same"] else ""))
        if sim["more_same"]:
            out.append("（另有 %d 本同名书未列出）" % sim["more_same"])
    if sim["similar"]:
        out.append("书库中还有相似电子书：" if sim["same"] else "书库中已有相似电子书：")
        items = sim["similar"][:max_total]
        for n, it in enumerate(items, 1):
            out.append(_fmt_one(it, n, "；" if n < len(items) or sim["more_similar"] else ""))
        if sim["more_similar"]:
            out.append("（另有 %d 本相似书未列出）" % sim["more_similar"])
    return "\n".join(out)


def short_hint(sim):
    """一行短提示（后台审核列表用）。没有命中返回空串。"""
    if not sim or not (sim["same"] or sim["similar"]):
        return ""
    parts = []
    if sim["same"]:
        parts.append("书库已有同名 %d 本" % (len(sim["same"]) + sim["more_same"]))
    if sim["similar"]:
        parts.append("相似 %d 本" % (len(sim["similar"]) + sim["more_similar"]))
    return "、".join(parts)


def brief(sim, max_n=5):
    """一行摘要（管理员在消息里一眼看完，不必点开）。"""
    if not sim or not (sim["same"] or sim["similar"]):
        return ""
    out = []
    for it in (sim["same"] + sim["similar"])[:max_n]:
        out.append("%s（%s %.2f MB）" % (it["title"], (it["ext"] or "").lstrip(".").upper() or "未知",
                                        (it["size"] or 0) / 1048576))
    return "；".join(out)
