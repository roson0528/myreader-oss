"""ffmpeg 封装：Opus 片段 → MP3、拼接、背景音乐循环混音。

★ 为什么必须用静态 ffmpeg：TTS 服务器出的是 Opus（`format: opus, bitrate 32k`，见
  tts._call_one），而成品要 MP3，还要跟背景音乐混音。系统里没装 ffmpeg 且 sudo 要密码，
  所以自带一份静态二进制在 tools/bin/ 下 —— 不用 root、不动系统、删目录即可移除。
"""
import os
import subprocess
import sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FFMPEG = os.path.join(BASE, "tools", "bin", "ffmpeg")
FFPROBE = os.path.join(BASE, "tools", "bin", "ffprobe")

# 有声书输出规格。24kHz 单声道 64k：人声内容再往上加码率听不出差别，
# 体积却是线性涨的（一本 10 小时的书 64k 约 280MB）。
OUT_AR = 24000
OUT_BITRATE = "64k"
OUT_CHANNELS = 1


class FfmpegMissing(RuntimeError):
    pass


def available():
    return os.path.isfile(FFMPEG) and os.access(FFMPEG, os.X_OK)


def _run(args, timeout=1800):
    if not available():
        raise FfmpegMissing("找不到 ffmpeg：%s（应为静态二进制）" % FFMPEG)
    p = subprocess.run([FFMPEG, "-hide_banner", "-nostdin"] + args,
                       capture_output=True, text=True, timeout=timeout)
    if p.returncode != 0:
        tail = (p.stderr or "").strip().splitlines()[-6:]
        raise RuntimeError("ffmpeg 失败(%d): %s" % (p.returncode, " / ".join(tail)))
    return p


def to_mp3(src, dst, bitrate=OUT_BITRATE):
    """单个 Opus 片段转 MP3。"""
    _run(["-y", "-v", "error", "-i", src, "-codec:a", "libmp3lame",
          "-b:a", bitrate, "-ar", str(OUT_AR), "-ac", str(OUT_CHANNELS), dst])
    return dst


def concat_mp3(parts, dst):
    """把多个同规格 MP3 顺序拼成一个。

    用 concat 分离器 + `-c copy`：同编码同参数的文件拼接是无损直拷，
    既快又不会二次压缩（整本书几千段，重编码会慢好几倍还会累积损失）。
    """
    if not parts:
        raise RuntimeError("没有可拼接的片段")
    if len(parts) == 1:
        # 只有一段时仍然走一次编码，保证输出规格和文件名统一
        _run(["-y", "-v", "error", "-i", parts[0], "-codec:a", "libmp3lame",
              "-b:a", OUT_BITRATE, "-ar", str(OUT_AR), "-ac", str(OUT_CHANNELS), dst])
        return dst
    d = os.path.dirname(dst) or "."
    lst = os.path.join(d, ".concat.txt")
    with open(lst, "w", encoding="utf-8") as f:
        for p in parts:
            # concat 分离器对单引号敏感，用绝对路径并转义
            f.write("file '%s'\n" % os.path.abspath(p).replace("'", "'\\''"))
    try:
        _run(["-y", "-v", "error", "-f", "concat", "-safe", "0", "-i", lst, "-c", "copy", dst])
    finally:
        try:
            os.remove(lst)
        except OSError:
            pass
    return dst


def silent_mp3(dst, seconds):
    """生成一段静音（章节之间留白用）。"""
    _run(["-y", "-v", "error", "-f", "lavfi",
          "-i", "anullsrc=r=%d:cl=%s" % (OUT_AR, "mono"),
          "-t", "%.3f" % max(0.1, seconds), "-codec:a", "libmp3lame",
          "-b:a", OUT_BITRATE, dst])
    return dst


def mix_bgm(src, bgm_files, dst, volume=0.12):
    """给一段音频铺背景音乐：多个 BGM 顺序播完再从头循环，整体压低到 volume。

    ★ 必须写 `amix=normalize=0`。amix 默认 normalize=1 会把**每个输入除以路数**，
      两路混音时旁白直接被砍掉 6dB —— 实测 mean_volume 从 -21.5dB 掉到 -27.9dB，
      听感明显发闷。normalize=0 后是 -21.9dB，只多出背景音乐那点能量。
    """
    if not bgm_files:
        raise RuntimeError("没有背景音乐")
    if len(bgm_files) == 1:
        loop_in = ["-stream_loop", "-1", "-i", bgm_files[0]]
    else:
        # 多个 BGM 先串成一条，再整体循环 —— 这样是「列表循环」而不是各自叠加
        d = os.path.dirname(dst) or "."
        chain = os.path.join(d, ".bgm_chain.mp3")
        concat_mp3(bgm_files, chain)
        loop_in = ["-stream_loop", "-1", "-i", chain]
    _run(["-y", "-v", "error", "-i", src] + loop_in +
         ["-filter_complex",
          "[1:a]volume=%.4f[b];[0:a][b]amix=inputs=2:duration=first:"
          "dropout_transition=0:normalize=0[out]" % float(volume),
          "-map", "[out]", "-codec:a", "libmp3lame", "-b:a", OUT_BITRATE,
          "-ar", str(OUT_AR), "-ac", str(OUT_CHANNELS), dst])
    return dst


def tag_mp3(path, title="", artist="", album="", track=None, total=None, genre=""):
    """给成品写 ID3 标签，不重新编码。

    用途：音乐播放器认的是标签里的信息，光靠文件名（`001-有约（1／2）.mp3`）
    在手机音乐 App、车机、NAS 音乐服务 里就是一堆无专辑无艺术家的散曲子。

    ★ 必须 `-c copy`：成品已经是 MP3，为了写几个标签重新编码一遍既慢又有损。
    ★ 必须写临时文件再 os.replace：ffmpeg 不能就地覆盖输入文件。
    ★ 写 ID3v2.3 而不是默认的 2.4：老播放器（车机、Audio Station、部分安卓音乐 App）
      对 2.4 支持参差，2.3 兼容性最好；中文在 2.3 里会用 UTF-16 存，没问题。
    """
    if not (title or artist or album):
        return path
    args = ["-y", "-v", "error", "-i", path, "-c", "copy", "-id3v2_version", "3"]
    if title:
        args += ["-metadata", "title=" + title]
    if artist:
        # 两个都写：播放器有的读 artist，有的只看 album_artist（「参与创作的艺术家」）
        args += ["-metadata", "artist=" + artist, "-metadata", "album_artist=" + artist]
    if album:
        args += ["-metadata", "album=" + album]
    if genre:
        args += ["-metadata", "genre=" + genre]
    if track:
        args += ["-metadata", "track=%d%s" % (int(track), ("/%d" % int(total)) if total else "")]
    tmp = path + ".tag.mp3"
    try:
        _run(args + [tmp])
    except Exception:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise
    os.replace(tmp, path)
    return path


def duration(path):
    """时长（秒）。取不到就返回 0 —— 只是显示用，不能因为读不到就让任务失败。"""
    try:
        p = subprocess.run([FFPROBE, "-v", "error", "-show_entries", "format=duration",
                            "-of", "default=nw=1:nk=1", path],
                           capture_output=True, text=True, timeout=60)
        return float((p.stdout or "0").strip() or 0)
    except Exception:
        return 0.0


def concat_decode_mp3(parts, dst):
    """有时长不一致的片段时用的稳妥拼接：解码后重编码。

    纯 `-c copy` 要求所有片段时间基一致；跨来源（比如混过 BGM 的段和没混过的）
    拼在一起偶尔会有爆音，这种时候退到重编码。
    """
    if not parts:
        raise RuntimeError("没有可拼接的片段")
    d = os.path.dirname(dst) or "."
    lst = os.path.join(d, ".concat2.txt")
    with open(lst, "w", encoding="utf-8") as f:
        for p in parts:
            f.write("file '%s'\n" % os.path.abspath(p).replace("'", "'\\''"))
    try:
        _run(["-y", "-v", "error", "-f", "concat", "-safe", "0", "-i", lst,
              "-codec:a", "libmp3lame", "-b:a", OUT_BITRATE, "-ar", str(OUT_AR),
              "-ac", str(OUT_CHANNELS), dst])
    finally:
        try:
            os.remove(lst)
        except OSError:
            pass
    return dst


if __name__ == "__main__":
    print("ffmpeg:", FFMPEG, "available=", available())
    sys.exit(0 if available() else 1)
