// 听书架里《文学回忆录+木心谈木心》的封面（§14.96）——界面端到端
//
// 只读检查：打开 /listen，找到这本书的卡片，确认
//   ①卡片里有 <img class="au-cover">；②src 指向 /api/books/296878/cover；
//   ③图片真的加载出来了（naturalWidth>0，不是 onerror 被藏掉的破图）；
//   ④其它 9 本有声书的封面也都在；⑤全程没有 JS 报错。
//
// 跑法：NODE_PATH=/tmp/pwtest/node_modules node tests/test_ablib_cover_ui.js
const { chromium } = require('playwright-core');
const { execSync } = require('child_process');

const CHROME = '/srv/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome';
const ROOT = '/srv/myreader/book_manager';
const BASE = 'https://127.0.0.1:9000';
const BOOK_ID = 296878;              // 《文学回忆录+木心谈木心》
const TITLE = '文学回忆录';

let pass = 0, fail = 0;
const ck = (name, ok, extra) => {
  if (ok) { pass++; console.log('  ✓ ' + name); }
  else { fail++; console.log('  ✗ ' + name + (extra !== undefined ? '  → ' + JSON.stringify(extra) : '')); }
};

const info = JSON.parse(execSync('venv/bin/python -', {
  cwd: ROOT, encoding: 'utf8', input: `
import sys, json
sys.path.insert(0, '${ROOT}')
import db, auth
u = db.q("SELECT * FROM users WHERE role='admin' AND enabled=1 ORDER BY id LIMIT 1", one=True)
print(json.dumps({"token": auth.create_token(u), "user": dict(u)}))
`}).trim());

(async () => {
  const browser = await chromium.launch({ executablePath: CHROME, args: ['--no-sandbox'] });
  const ctx = await browser.newContext({ ignoreHTTPSErrors: true, viewport: { width: 1280, height: 1000 } });
  await ctx.setExtraHTTPHeaders({ 'Cache-Control': 'no-cache' });
  await ctx.addInitScript(([t, u]) => {
    localStorage.setItem('bm_token', t); localStorage.setItem('bm_user', u);
  }, [info.token, JSON.stringify(info.user)]);
  const p = await ctx.newPage();
  const errs = [];
  p.on('pageerror', e => errs.push(String(e.message)));
  p.on('console', m => { if (m.type() === 'error') errs.push('console: ' + m.text()); });

  // ★ 听书架是 SPA 里的 #/audio 页（#page-audio / #au-list），不是 /listen
  //   —— /listen 是点进去之后的播放页，那里没有列表卡片。
  await p.goto(BASE + '/#/audio', { waitUntil: 'domcontentloaded' });
  await p.reload({ waitUntil: 'domcontentloaded' });
  await p.waitForFunction(() => document.querySelectorAll('#au-list .au-cover').length > 0,
    { timeout: 20000 }).catch(() => {});
  await p.waitForTimeout(1500);

  const cards = await p.evaluate(() => Array.from(document.querySelectorAll('#au-list .au-cover')).map(img => {
    const box = img.closest('a, .au-item, li, div');
    return {
      src: img.getAttribute('src') || '',
      nw: img.naturalWidth, nh: img.naturalHeight,
      shown: img.offsetParent !== null && img.style.display !== 'none',
      text: ((box && box.textContent) || '').trim().slice(0, 60),
    };
  }));
  ck('A 听书架页面渲染出了封面图（至少一张）', cards.length > 0, cards.length);

  const mine = cards.filter(c => c.text.includes('文学回忆录'));
  ck('B 找到《文学回忆录+木心谈木心》这张卡片', mine.length === 1, cards.map(c => c.text));

  if (mine.length) {
    const c = mine[0];
    ck('C 它的封面指向这本书的封面接口', c.src.includes('/api/books/' + BOOK_ID + '/cover'), c.src);
    ck('D 图片真的加载出来了（不是破图占位）', c.nw > 0 && c.nh > 0 && c.shown,
      { naturalWidth: c.nw, naturalHeight: c.nh, shown: c.shown });
  }

  const broken = cards.filter(c => !(c.nw > 0));
  ck('E 没有任何一张封面是破图', broken.length === 0, broken.map(c => ({ src: c.src, nw: c.nw })));
  ck('F 10 本有声书都有封面图', cards.length === 10, cards.length);

  // 顺带用测试账号（test/test）走一遍接口：普通用户看到的 cover_url 也在
  const apiOut = execSync(`curl -sk -X POST ${BASE}/api/login -H 'Content-Type: application/json' ` +
    `-d '{"username":"test","password":"test"}'`, { encoding: 'utf8' });
  let ttoken = '';
  try { ttoken = JSON.parse(apiOut).token || (JSON.parse(apiOut).access_token || ''); } catch (e) { ttoken = ''; }
  if (!ttoken) {
    // 登录接口字段名可能是别的，退一步：直接用本地生成的测试账号 token
    ttoken = execSync('venv/bin/python -', {
      cwd: ROOT, encoding: 'utf8', input: `
import sys; sys.path.insert(0, '${ROOT}')
import db, auth
u = db.q("SELECT * FROM users WHERE username='test' AND enabled=1 LIMIT 1", one=True)
print(auth.create_token(u) if u else '')
`}).trim().split('\n').pop();
  }
  const listed = JSON.parse(execSync(
    `curl -sk -H "Authorization: Bearer ${ttoken}" "${BASE}/api/audiobooks?cat_id=0"`, { encoding: 'utf8' }));
  const items = Array.isArray(listed) ? listed : (listed.items || []);
  const t = items.find(x => (x.title || '').includes('文学回忆录'));
  console.log('  · 测试账号看到 ' + items.length + ' 本' + (t ? ('，其中这本 cover_url=' + t.cover_url) : '（看不到这本，权限所限）'));
  ck('G 测试账号(test)也拿得到这本书的 cover_url（读得到就没算漏）',
    !t || (t.cover_url && t.cover_url.includes('/api/books/' + BOOK_ID + '/cover')),
    t ? { cover: t.cover, url: t.cover_url } : '测试账号看不到这本（权限所限，不算失败）');

  ck('H 全程没有 JS 报错', errs.length === 0, errs.slice(0, 3));

  await browser.close();
  console.log(`\n听书架封面：${pass} 通过 / ${fail} 失败`);
  process.exit(fail ? 1 : 0);
})();
