# -*- coding: utf-8 -*-
"""Server酱推送守卫的回归（不联网、不真推）。

事故背景（2026-10-09，用户投诉「为什么总是推送不相关的 Server酱 测试通知」）：
回归测试会建**真的**测试账号、真的发共享申请/书单，那条路会走到
notify_admins -> push_async -> 真的 POST 到 sctapi.ftqq.com。
审计日志里能查到 zzt_sim_* 发了 16 次共享申请、zzam_pub_* 发了 8 次书单 ——
每跑一次测试，管理员手机就多几条「不相关的推送」。

本脚本**不联网**：把 _serverchan_post 换成收集器，只看它有没有被调用。
"""
import os
import sys
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
os.chdir(_ROOT)
import notify  # noqa: E402

_pass, _fail = [0], [0]


def ck(name, ok, extra=''):
    if ok:
        _pass[0] += 1
        print('  [OK] %s%s' % (name, ('  ' + str(extra)) if extra != '' else ''))
    else:
        _fail[0] += 1
        print('  [FAIL] %s%s' % (name, ('  ' + str(extra)) if extra != '' else ''))


print('=' * 78)
print('A. 测试脚本里必须自动判定为「不许真推」')
print('=' * 78)
_real_argv = sys.argv[0]
try:
    sys.argv[0] = '/srv/myreader/book_manager/tests/test_notify_guard.py'
    ck('★ 入口是 tests/ 下的 test_*.py → 拦', notify.push_suppressed() is True)
    sys.argv[0] = '/srv/myreader/book_manager/tests/verify_ab41.py'
    ck('★ 入口是 tests/ 下的 verify_*.py → 拦', notify.push_suppressed() is True)
    sys.argv[0] = '/srv/myreader/book_manager/venv/bin/python'
    os.environ.pop('BM_NO_SERVERCHAN', None)
    ck('★ 生产入口（uvicorn/python，不是测试脚本）→ 不拦，推送行为不变',
       notify.push_suppressed() is False)
    os.environ['BM_NO_SERVERCHAN'] = '1'
    ck('★ 环境变量 BM_NO_SERVERCHAN=1 → 拦（给外部脚本用）',
       notify.push_suppressed() is True)
    os.environ['BM_NO_SERVERCHAN'] = '0'
    ck('★ 环境变量显式 =0 → 放行（调试真推时可以这样开）',
       notify.push_suppressed() is False)
finally:
    os.environ.pop('BM_NO_SERVERCHAN', None)
    sys.argv[0] = _real_argv

print()
print('=' * 78)
print('B. 被拦时，网络调用一次都不能发出')
print('=' * 78)
sent = []
_real_post = notify._serverchan_post
_real_enabled = notify.serverchan_enabled
notify._serverchan_post = lambda *a, **kw: (sent.append(a), {'ok': True, 'error': ''})[1]
notify.serverchan_enabled = lambda: True          # 就算开关是开的，也不许真推
try:
    sys.argv[0] = '/srv/myreader/book_manager/tests/test_notify_guard.py'
    r = notify.push_async('测试标题', '测试内容')
    ck('push_async 在测试环境返回 False（表示没有推出去）', r is False, r)
    import time
    time.sleep(0.5)                               # 它是后台线程发的，等一等
    ck('★ push_async 没有真的发请求', len(sent) == 0, '发了 %d 次' % len(sent))

    r2 = notify.push_now('测试标题', '测试内容')
    ck('push_now 也拦住', r2.get('ok') is False, r2)
    ck('★ push_now 也没有真的发请求', len(sent) == 0, '发了 %d 次' % len(sent))
    ck('push_now 返回里说明了原因', '测试' in str(r2.get('error')), r2.get('error'))
    ck('测试环境里 push_now 的原因提示清楚', '阻止' in str(r2.get('error')) or '测试' in str(r2.get('error')),
       r2.get('error'))

    print()
    print('  --- 反证：把守卫摘掉，网络调用确实会发生（证明上面不是「本来就发不出去」）---')
    sys.argv[0] = '/srv/myreader/book_manager/venv/bin/python'
    os.environ['BM_NO_SERVERCHAN'] = '0'
    notify.push_async('反证标题', '反证内容')
    time.sleep(0.5)
    ck('★ 去掉守卫后 push_async 真的调了发送函数（说明守卫才是拦住它的原因）',
       len(sent) >= 1, '发了 %d 次' % len(sent))
finally:
    os.environ.pop('BM_NO_SERVERCHAN', None)
    sys.argv[0] = _real_argv          # ★ 反证段把它改成了生产入口，必须还原，
    notify._serverchan_post = _real_post   #   否则下面的 C 段会拿错入口、测出假失败
    notify.serverchan_enabled = _real_enabled

print()
print('=' * 78)
print('C. 真实入口（本脚本自己）就是测试脚本 —— 这是本次事故的现场')
print('=' * 78)
ck('★ 跑本测试时 push_suppressed() 为真（所以以后测试不会再骚扰管理员）',
   notify.push_suppressed() is True, sys.argv[0])

print()
print('=' * 78)
print('通过 %d / 失败 %d' % (_pass[0], _fail[0]))
print('=' * 78)
sys.exit(1 if _fail[0] else 0)
