// 「有声」在 APP 内走原生播放的回归（不需要真机）。
//
// 背景：网页里的 <audio> 一旦 App 切后台/关屏就会被 Chromium 暂停，
// 所以 APP 内要把播放交给原生前台服务（PlaybackService）。但网页是服务器上的
// 最新版、APK 可能是旧的，因此**必须探测**能力，探测不到就落回网页播放。
//
// 这个脚本没法验「真的出声/真的关屏继续放」（那需要真机），
// 它验的是**接线是否正确**：桩一个 Capacitor 插件，检查
//   1. 探测到 version>=4 时确实调用了 startMp3，并传了整本直链清单；
//   2. 老 APK（无 startMp3 / version<4）时**不调用**原生，落回网页播放；
//   3. 原生位置回报能驱动进度条与逐句高亮；
//   4. 播放/暂停/拖动/切章都打到原生对应方法上。
// 本脚本只读服务端数据，不写任何库表。
const { chromium } = require('playwright-core');
const { execSync } = require('child_process');
const CHROME = '/srv/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome';
const ROOT = '/srv/myreader/book_manager';

let pass = 0, fail = 0;
const ck = (n, ok, extra) => {
  if (ok) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (extra ? '  → ' + extra : '')); }
};
const py = (code) => execSync('venv/bin/python -', { cwd: ROOT, encoding: 'utf8', input: code }).trim();

// 注入一个假的 Capacitor 桥：记录所有被调用的原生方法
// idle=true 模拟「刚打开 App、PlaybackService 还没跑过」——此时原生 status()
// 只返回 {version, active:false}，**没有 mode 键**。这是真机的常见初始状态，
// 也是「听有声书没有通知栏横幅」那个 bug 的触发条件，所以必须单独覆盖。
const BRIDGE = (version, idle) => `
window.__nativeCalls = [];
(function () {
  const rec = (name) => function (arg) {
    window.__nativeCalls.push({ name: name, arg: arg || null });
    if (name === 'status') return Promise.resolve(${idle
      ? `{ version: ${version}, btLink: true, active: false }`
      : `{ version: ${version}, mode: 'mp3', playing: false }`});
    return Promise.resolve({ ok: true });
  };
  const plug = {};
  ['status', 'startMp3', 'seek', 'play', 'pause', 'next', 'prev',
   'gotoIndex', 'setVoice', 'setRate', 'stop'].forEach(k => { plug[k] = rec(k); });
  window.Capacitor = { Plugins: { ListenService: plug } };
})();
`;

// 模拟「V3.4 的原生前台服务里**正在**放有声书」：此时网页可能是全新加载的
// （App 冷启动 / WebView 被系统回收后重载），而声音还在后台放着。
const BRIDGE_PLAYING = (title, chapIdx) => `
window.__nativeCalls = [];
(function () {
  const rec = (name) => function (arg) {
    window.__nativeCalls.push({ name: name, arg: arg || null });
    if (name === 'status') return Promise.resolve({
      version: 5, btLink: true, active: true, playing: true, mode: 'mp3',
      title: ${JSON.stringify(title)}, index: ${chapIdx}, total: 38,
      chapter: '第 3 章', positionMs: 65432, durationMs: 600000, bookId: 0
    });
    return Promise.resolve({ ok: true });
  };
  const plug = {};
  ['status', 'startMp3', 'seek', 'play', 'pause', 'next', 'prev',
   'gotoIndex', 'setVoice', 'setRate', 'stop'].forEach(k => { plug[k] = rec(k); });
  window.Capacitor = { Plugins: { ListenService: plug } };
})();
`;

(async () => {
  const info = JSON.parse(py(`
import sys, json
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
import db, auth
u = db.q("SELECT * FROM users WHERE role='admin' AND enabled=1 ORDER BY id LIMIT 1", one=True)
db.ex("DELETE FROM ab_session WHERE user_id=?", (u["id"],))   # 清掉上一轮测试遗留的有声单端锁
lib = db.q("SELECT id, title, total_chapters FROM ab_lib WHERE hidden=0 AND total_chapters>1 ORDER BY id DESC LIMIT 1", one=True)
print(json.dumps({"token": auth.create_token(u), "lib": dict(lib)}))
`));
  const LIB = info.lib;
  const browser = await chromium.launch({ executablePath: CHROME, args: ['--no-sandbox', '--autoplay-policy=no-user-gesture-required'] });

  // ---------------------------------------------- 0. 刚开 App（status 无 mode）：仍必须走原生
  // 这是线上真实故障的回归：探测里多判了一个 st.mode，而 mode 只有播放过才有，
  // 于是首播判死 → 落回网页播放 → 没有前台服务 → 通知栏/锁屏没有横幅。
  {
    const ctx = await browser.newContext({ ignoreHTTPSErrors: true, viewport: { width: 420, height: 900 } });
    await ctx.addInitScript(tk => { localStorage.setItem('bm_token', tk); localStorage.setItem('bm_user', '{"id":1,"role":"admin"}'); try { sessionStorage.setItem('bm_audio_sid', 'fixnative'); } catch (e) {} }, info.token);
    await ctx.addInitScript(BRIDGE(5, true));      // ← idle：status() 里没有 mode
    const page = await ctx.newPage();
    await page.goto('https://127.0.0.1:9000/', { waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(2200);
    await page.evaluate(id => { location.hash = '#/audio/' + id; }, LIB.id);
    await page.waitForTimeout(1200);
    await page.evaluate(id => audioPlay(id, 1, false), LIB.id);
    await page.waitForTimeout(3500);
    const calls = await page.evaluate(() => window.__nativeCalls.map(c => c.name));
    ck('★ status() 里没有 mode 时仍然走原生（否则没有通知栏横幅）',
       calls.includes('startMp3'), calls.join(',') || '(一个原生方法都没调)');
    ck('该情况下也没把网页 audio 当主播放器',
       await page.evaluate(() => !document.querySelector('#ap-slot audio')));
    await ctx.close();
  }

  // ---------------------------------------------- 0b. v4（V3.3）必须落回网页
  // V3.3 的原生 MP3 有相对地址 + 媒体片段两处硬伤，走了反而没声音/重放，
  // 所以门槛提到 v5：v4 一律用网页播放。
  {
    const ctx = await browser.newContext({ ignoreHTTPSErrors: true, viewport: { width: 420, height: 900 } });
    await ctx.addInitScript(tk => { localStorage.setItem('bm_token', tk); localStorage.setItem('bm_user', '{"id":1,"role":"admin"}'); try { sessionStorage.setItem('bm_audio_sid', 'fixnative'); } catch (e) {} }, info.token);
    await ctx.addInitScript(BRIDGE(4, true));
    const page = await ctx.newPage();
    await page.goto('https://127.0.0.1:9000/', { waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(2200);
    await page.evaluate(id => { location.hash = '#/audio/' + id; }, LIB.id);
    await page.waitForTimeout(1200);
    await page.evaluate(id => audioPlay(id, 1, false), LIB.id);
    await page.waitForTimeout(3500);
    const calls = await page.evaluate(() => window.__nativeCalls.map(c => c.name));
    ck('★ v4（V3.3）不走原生 MP3，落回网页播放', !calls.includes('startMp3'), calls.join(','));
    ck('★ v4 时网页 audio 正常挂上（有声音）',
       await page.evaluate(() => !!document.querySelector('#ap-slot audio')));
    await ctx.close();
  }

  // ---------------------------------------------- 1. 新 APK：必须走原生
  {
    const ctx = await browser.newContext({ ignoreHTTPSErrors: true, viewport: { width: 420, height: 900 } });
    await ctx.addInitScript(tk => { localStorage.setItem('bm_token', tk); localStorage.setItem('bm_user', '{"id":1,"role":"admin"}'); try { sessionStorage.setItem('bm_audio_sid', 'fixnative'); } catch (e) {} }, info.token);
    await ctx.addInitScript(BRIDGE(5));
    const page = await ctx.newPage();
    const errs = []; page.on('pageerror', e => errs.push(String(e)));
    await page.goto('https://127.0.0.1:9000/', { waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(2200);
    await page.evaluate(id => { location.hash = '#/audio/' + id; }, LIB.id);
    await page.waitForTimeout(1200);
    await page.evaluate(id => audioPlay(id, 1, false), LIB.id);
    await page.waitForTimeout(3500);

    const calls = await page.evaluate(() => window.__nativeCalls.map(c => c.name));
    ck('探测到新 APK（v5）后调用了 startMp3', calls.includes('startMp3'), calls.join(','));

    const arg = await page.evaluate(() => {
      const c = window.__nativeCalls.find(x => x.name === 'startMp3');
      return c ? c.arg : null;
    });
    ck('startMp3 传了书名', !!arg && !!arg.title, arg && arg.title);
    ck('startMp3 传了整章直链清单', !!arg && Array.isArray(arg.urls) && arg.urls.length >= 2,
       arg ? '章节数=' + (arg.urls || []).length : '无参数');
    ck('直链是带签名的播放地址（含 sig=）',
       !!arg && arg.urls.filter(u => /sig=/.test(u)).length >= 1);
    // 原来这里断言「直链带 #t= 媒体片段」。那条断言**本身就是错的**：
    // #t= 是浏览器 <audio> 的约定，Android MediaPlayer 不支持，
    // 于是原生会把整个文件从头播（一个文件装多章的书每章都重放）。
    // 现在改成网页把起止毫秒单独放在 starts/ends 里传下去，
    // 正确性由上面那两条 ★ 断言把关，这里不再要求 #t=。
    ck('清单里有整章标题（通知栏副标题要用）',
       !!arg && Array.isArray(arg.titles) && arg.titles.length === (arg.urls || []).length);
    // ★ 原生 MediaPlayer.setDataSource() 要绝对地址：相对路径会被当成手机本地文件
    ck('★ 直链是绝对地址（相对路径原生打不开）',
       !!arg && arg.urls.filter(u => /^https?:\/\//.test(u)).length === arg.urls.filter(Boolean).length,
       (arg && arg.urls[0]) || '');
    ck('★ 直链里不再夹 #t= 媒体片段（Android MediaPlayer 不认）',
       !!arg && arg.urls.filter(u => /#t=/.test(u)).length === 0);
    // ★ 本章在文件里的起止毫秒：一个文件装多章时靠它定位
    ck('★ 传了 starts/ends 章节区间且与清单等长',
       !!arg && Array.isArray(arg.starts) && Array.isArray(arg.ends)
       && arg.starts.length === arg.urls.length && arg.ends.length === arg.urls.length);
    ck('★ 区间是递增有效的（后半段起点应 > 0，证明书里确实一个文件装多章）',
       !!arg && arg.ends.some((e, i) => e > arg.starts[i]),
       arg ? JSON.stringify(arg.starts.slice(0, 4)) + ' / ' + JSON.stringify(arg.ends.slice(0, 4)) : '');
    // 原生播放时网页这一路必须**完全不动**：音频元素不该被挂进播放页、也不该有 src，
    // 否则会出现「原生和网页同时出声」。
    ck('原生播放时网页 audio 未挂载、无 src（不会重复出声）',
       await page.evaluate(() => !document.querySelector('#ap-slot audio')));

    // 位置回报 → 进度条与高亮
    await page.evaluate(() => {
      window.__laoshuPlayerState({ mode: 'mp3', playing: true, index: 0, positionMs: 30000, durationMs: 166000 });
    });
    await page.waitForTimeout(600);
    const ui = await page.evaluate(() => {
      const on = document.querySelector('.ap-line.on');
      const cur = document.getElementById('ap-cur');
      return { hasOn: !!on, cur: cur ? cur.textContent : '', play: document.getElementById('ap-play').textContent };
    });
    ck('原生回报位置后进度条时间更新', ui.cur && ui.cur !== '0:00', '当前=' + ui.cur);
    ck('原生回报位置后仍高亮当前句', ui.hasOn);
    ck('原生播放中按钮显示暂停态', ui.play === '⏸', '按钮=' + ui.play);

    // 控件必须打到原生
    await page.evaluate(() => { window.__nativeCalls.length = 0; apToggle(); });
    await page.waitForTimeout(400);
    ck('点播放/暂停打到原生 pause',
       (await page.evaluate(() => window.__nativeCalls.map(c => c.name))).includes('pause'));

    await page.evaluate(() => { window.__nativeCalls.length = 0; apSeekCommit(500); });
    await page.waitForTimeout(400);
    const sk = await page.evaluate(() => window.__nativeCalls.find(c => c.name === 'seek'));
    ck('拖动进度条打到原生 seek（带 ms）', !!sk && typeof sk.arg.ms === 'number' && sk.arg.ms > 0,
       sk ? 'ms=' + sk.arg.ms : '未调用');

    await page.evaluate(() => { window.__nativeCalls.length = 0; auStep(1); });
    await page.waitForTimeout(600);
    const gi = await page.evaluate(() => window.__nativeCalls.find(c => c.name === 'gotoIndex'));
    ck('点下一章打到原生 gotoIndex', !!gi, gi ? JSON.stringify(gi.arg) : '未调用');

    ck('APP 内无 JS 报错', errs.length === 0, errs.slice(0, 2).join(' | '));

    // 收尾：别把测试造的收听进度留在真实账号上
    py(`
import sys
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
import db
u = db.q("SELECT id FROM users WHERE role='admin' AND enabled=1 ORDER BY id LIMIT 1", one=True)
db.ex("DELETE FROM ab_lib_prog WHERE user_id=?", (u['id'],))
`);
    await ctx.close();
  }

  // ---------------------------------------------- 2. 老 APK：必须落回网页播放
  {
    const ctx = await browser.newContext({ ignoreHTTPSErrors: true, viewport: { width: 420, height: 900 } });
    await ctx.addInitScript(tk => { localStorage.setItem('bm_token', tk); localStorage.setItem('bm_user', '{"id":1,"role":"admin"}'); try { sessionStorage.setItem('bm_audio_sid', 'fixnative'); } catch (e) {} }, info.token);
    await ctx.addInitScript(BRIDGE(3, true));   // version 3 = 只有 TTS，没有 MP3
    const page = await ctx.newPage();
    await page.goto('https://127.0.0.1:9000/', { waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(2200);
    await page.evaluate(id => audioPlay(id, 1, false), LIB.id);
    await page.waitForTimeout(5000);
    const calls = await page.evaluate(() => window.__nativeCalls.map(c => c.name));
    ck('★ 老 APK（version 3）不调用 startMp3', !calls.includes('startMp3'), calls.join(','));
    const st = await page.evaluate(() => {
      const a = document.getElementById('aup-audio');
      return { src: !!a.getAttribute('src'), t: a.currentTime };
    });
    ck('★ 老 APK 自动落回网页播放（音频正常在走）', st.src && st.t > 0, JSON.stringify(st));
    py(`
import sys
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
import db
u = db.q("SELECT id FROM users WHERE role='admin' AND enabled=1 ORDER BY id LIMIT 1", one=True)
db.ex("DELETE FROM ab_lib_prog WHERE user_id=?", (u['id'],))
`);
    await ctx.close();
  }

  // ------------------------- 3. 网页全新加载 + 原生还在放：悬浮条必须能认回来
  // 线上真问题：原生把声音放在前台服务里，**网页重载/被系统回收后声音还在放**，
  // 但 AUP 是网页内存对象，重载就没了 —— 悬浮条的显示条件里就有 !AUP，
  // 于是「后台还在放有声书，页面上却完全没有回到有声播放的悬浮条」。
  // 听书那边靠 backtolisten.js 每 3 秒从 status() 重组自己，所以不受影响。
  {
    const ctx = await browser.newContext({ ignoreHTTPSErrors: true, viewport: { width: 420, height: 900 } });
    await ctx.addInitScript(tk => { localStorage.setItem('bm_token', tk); localStorage.setItem('bm_user', '{"id":1,"role":"admin"}'); try { sessionStorage.setItem('bm_audio_sid', 'fixnative'); } catch (e) {} }, info.token);
    // 先把「原生在放哪本」写进 localStorage（等同于用户先前播过）
    await ctx.addInitScript(([id, title]) => {
      localStorage.setItem('au_native_lib', JSON.stringify({ id: id, title: title, chap: 3 }));
    }, [LIB.id, LIB.title]);
    await ctx.addInitScript(BRIDGE_PLAYING(LIB.title, 2));
    const page = await ctx.newPage();
    await page.goto('https://127.0.0.1:9000/', { waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(4500);
    const r = await page.evaluate(() => {
      const el = document.getElementById('au-float');
      return {
        hidden: el.classList.contains('hidden'),
        disp: getComputedStyle(el).display,
        title: (document.getElementById('au-float-title') || {}).textContent || '',
        sub: (document.getElementById('au-float-sub') || {}).textContent || '',
        hasAUP: typeof AUP !== 'undefined' && !!AUP,
      };
    });
    ck('★ 网页全新加载后，原生正在放的有声书能认回来（悬浮条出现）',
       !r.hidden && r.disp !== 'none', JSON.stringify(r));
    // 悬浮条显示的是**当前章标题**（c.title || d.title），不是书名 —— 这是有意的
    const wantTitle = await page.evaluate(async (id) => {
      const d = await api('/api/audiobooks/' + id);
      const chs = (d.chapters || []).slice().sort((a, b) => a.seq - b.seq);
      return chs[2] ? (chs[2].title || d.title) : d.title;
    }, LIB.id);
    ck('★ 认回来的悬浮条显示当前章标题', r.title === wantTitle && !!r.title, r.title + ' ≠ ' + wantTitle);
    // ★ 章总数不能写死：悬浮条上的「第 3/N 章」用的是**真实书目**的章数
    //   （原生只回报 index，total 由网页按当前这本书算），
    //   而选中的是哪本随库里新增有声书而变，写死 38 会一有新书就假失败。
    ck('★ 认回来的悬浮条显示原生回报的章节与进度',
       new RegExp('第\\s*3\\s*/\\s*' + LIB.total_chapters + '\\s*章').test(r.sub)
       && /1:05|0:?1:0/.test(r.sub),
       r.sub + `（期望章总数 ${LIB.total_chapters}）`);

    // 点悬浮条回播放页：**不能再发一次 startMp3**（那会把本章从头重放）
    await page.evaluate(() => auFloatOpen());
    await page.waitForTimeout(2500);
    const calls = await page.evaluate(() => window.__nativeCalls.map(c => c.name));
    ck('★ 点悬浮条回到播放页时不重启原生播放（不再发 startMp3）',
       !calls.includes('startMp3'), calls.join(','));
    ck('★ 点悬浮条确实进了播放页',
       await page.evaluate(() => !document.getElementById('view-audioplay').classList.contains('hidden')));
    await ctx.close();
  }

  // ------------------------- 4. 原生在放「听书」时，有声悬浮条绝不能跟着冒出来
  {
    const ctx = await browser.newContext({ ignoreHTTPSErrors: true, viewport: { width: 420, height: 900 } });
    await ctx.addInitScript(tk => { localStorage.setItem('bm_token', tk); localStorage.setItem('bm_user', '{"id":1,"role":"admin"}'); try { sessionStorage.setItem('bm_audio_sid', 'fixnative'); } catch (e) {} }, info.token);
    await ctx.addInitScript(([id, title]) => {
      localStorage.setItem('au_native_lib', JSON.stringify({ id: id, title: title, chap: 1 }));
    }, [LIB.id, LIB.title]);
    await ctx.addInitScript(`
window.__nativeCalls = [];
(function () {
  const rec = (n) => function (a) {
    window.__nativeCalls.push({ name: n, arg: a || null });
    // mode 是 tts 且带着 bookId：这是「听书」在放，不是有声
    if (n === 'status') return Promise.resolve({ version: 5, active: true, playing: true, mode: 'tts', bookId: 7 });
    return Promise.resolve({ ok: true });
  };
  const p = {};
  ['status','startMp3','seek','play','pause','next','prev','gotoIndex','setVoice','setRate','stop'].forEach(k => p[k] = rec(k));
  window.Capacitor = { Plugins: { ListenService: p } };
})();
`);
    const page = await ctx.newPage();
    await page.goto('https://127.0.0.1:9000/', { waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(4500);
    const r = await page.evaluate(() => ({
      hidden: document.getElementById('au-float').classList.contains('hidden'),
      hasAUP: typeof AUP !== 'undefined' && !!AUP,
      bt: !!document.querySelector('#bm-backtolisten.show'),
    }));
    ck('★ 原生在放「听书」时不认领成有声（有声悬浮条不出现）', r.hidden && !r.hasAUP, JSON.stringify(r));
    ck('★ 听书自己的「回到听书」按钮照常显示', r.bt);
    await ctx.close();
  }

  // ------------------------- 5. 原生没在放：冷启动不该凭空冒悬浮条
  {
    const ctx = await browser.newContext({ ignoreHTTPSErrors: true, viewport: { width: 420, height: 900 } });
    await ctx.addInitScript(tk => { localStorage.setItem('bm_token', tk); localStorage.setItem('bm_user', '{"id":1,"role":"admin"}'); try { sessionStorage.setItem('bm_audio_sid', 'fixnative'); } catch (e) {} }, info.token);
    await ctx.addInitScript(([id, title]) => {
      localStorage.setItem('au_native_lib', JSON.stringify({ id: id, title: title, chap: 1 }));
    }, [LIB.id, LIB.title]);
    await ctx.addInitScript(BRIDGE(5, true));      // active:false
    const page = await ctx.newPage();
    await page.goto('https://127.0.0.1:9000/', { waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(4000);
    const r = await page.evaluate(() => ({
      hidden: document.getElementById('au-float').classList.contains('hidden'),
      hasAUP: typeof AUP !== 'undefined' && !!AUP,
    }));
    ck('★ 原生什么都没放时，冷启动不会凭空冒出有声悬浮条', r.hidden && !r.hasAUP, JSON.stringify(r));
    await ctx.close();
  }
  // ★ 收尾：把自己留下的有声单端锁清掉。
  //   不清的话它会活 40 秒租约，紧接着打开 APP 会误报「正在另一台设备上收听」。
  try {
    py(`import sys; sys.path.insert(0, '${ROOT}')
import db
db.ex("DELETE FROM ab_session WHERE user_id=?", (1,))`);
  } catch (e) {}


  await browser.close();
  console.log(`\n原生播放接线：${pass} 通过 / ${fail} 失败`);
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error('测试异常：', e); process.exit(2); });
