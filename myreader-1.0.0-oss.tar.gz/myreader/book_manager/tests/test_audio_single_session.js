// 有声阅读单端锁：一个账号同一时间只允许**一台设备**放有声书。
// 照听书那套（40 秒租约 + 409 阻断 + 「在这台设备上继续听」抢占 + SSE 实时踢人）。
//
// ★ 只用测试账号 test（uid 45），自己造会话、自己清干净；绝不碰别人的行。
//   所有 HTTP 都带 X-BM-No-Push: 1（测试不得触发推送）。
const { chromium } = require('playwright-core');
const { execSync } = require('child_process');
const CHROME = '/srv/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome';
const ROOT = '/srv/myreader/book_manager';
const BASE = 'https://127.0.0.1:9000';

let pass = 0, fail = 0;
const ck = (n, ok, extra) => {
  if (ok) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (extra ? '  → ' + extra : '')); }
};
const py = (c) => execSync('venv/bin/python -', { cwd: ROOT, encoding: 'utf8', input: c }).trim();

const H = (tok) => ({
  'Authorization': 'Bearer ' + tok, 'Content-Type': 'application/json',
  'X-BM-No-Push': '1', 'Referer': BASE + '/'
});
async function call(method, path, tok, body) {
  const r = await fetch(BASE + path, {
    method, headers: H(tok), body: body === undefined ? undefined : JSON.stringify(body),
    // 自签证书
    dispatcher: undefined
  }).catch(e => { throw e; });
  let j = null;
  try { j = await r.json(); } catch (e) {}
  return { status: r.status, body: j };
}

(async () => {
  process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
  const info = JSON.parse(py(`
import sys, json
sys.path.insert(0, '${ROOT}')
import db, auth
u = db.q("SELECT * FROM users WHERE username='test' AND enabled=1", one=True)
if not u:
    raise SystemExit('测试账号 test 不存在')
print(json.dumps({"tok": auth.create_token(u), "uid": u["id"], "user": dict(u)}))`));
  const UID = info.uid;
  const S1 = 'tst' + Date.now().toString(36) + 'a';
  const S2 = 'tst' + Date.now().toString(36) + 'b';
  const clean = () => py(`
import sys; sys.path.insert(0, '${ROOT}')
import db
db.ex("DELETE FROM ab_session WHERE user_id=?", (${UID},))
db.ex("DELETE FROM ab_lyr_cache WHERE 0") if False else None
print("ok")`);
  clean();

  // ---------------------------------------------------------------- 服务端
  let r = await call('POST', '/api/audiobooks/session/hb', info.tok, { sid: S1, lib_id: 1 });
  ck('A 心跳拿到锁', r.status === 200 && r.body && r.body.owned === true, JSON.stringify(r.body));

  r = await call('GET', '/api/audiobooks/1/ticket?seq=1&chap=1&sid=' + S2, info.tok);
  ck('★ B 取票被挡 409', r.status === 409, 'HTTP ' + r.status);
  ck('★ 提示里点名了是哪本书', /三体/.test(String(r.body && r.body.detail)), JSON.stringify(r.body));
  ck('★ 提示里给了「在这台设备上继续」的出路',
     /这台设备上继续/.test(String(r.body && r.body.detail)), JSON.stringify(r.body));

  const b = await call('GET', '/api/audiobooks/1/ticket?seq=1&chap=1&sid=' + S1, info.tok);
  ck('A 取票正常', b.status === 200 && /sig=/.test(String(b.body && b.body.url)), 'HTTP ' + b.status);

  r = await call('POST', '/api/audiobooks/session/hb', info.tok, { sid: S2, lib_id: 1 });
  ck('★ B 心跳报 owned=false（被抢的那一端靠它兜底停下来）',
     r.status === 200 && r.body && r.body.owned === false, JSON.stringify(r.body));

  r = await call('POST', '/api/audiobooks/session/take', info.tok, { sid: S2, lib_id: 1 });
  ck('B 抢占成功', r.status === 200 && r.body && r.body.stolen === true, JSON.stringify(r.body));

  r = await call('POST', '/api/audiobooks/session/hb', info.tok, { sid: S1, lib_id: 1 });
  ck('★ A 被抢后 owned=false', r.status === 200 && r.body && r.body.owned === false, JSON.stringify(r.body));
  r = await call('GET', '/api/audiobooks/1/ticket?seq=1&chap=1&sid=' + S1, info.tok);
  ck('★ A 被抢后取票 409', r.status === 409, 'HTTP ' + r.status);

  // 不破坏老调用：不带 sid 时行为与以前完全一致
  r = await call('GET', '/api/audiobooks/1/ticket?seq=1&chap=1', info.tok);
  ck('不带 sid 的老调用不受影响', r.status === 200, 'HTTP ' + r.status);

  // 进度上报：被抢的一端不能再写进度
  r = await call('POST', '/api/audiobooks/1/progress', info.tok,
                 { chap: 1, offset: 3, sid: S1 });
  ck('★ 被抢的一端上报进度被拒（不许覆盖对方进度）',
     r.status === 200 && r.body && r.body.owned === false, JSON.stringify(r.body));

  r = await call('POST', '/api/audiobooks/session/release', info.tok, { sid: S2 });
  ck('主动释放成功', r.status === 200 && r.body && r.body.ok === true, JSON.stringify(r.body));
  const left = py(`
import sys; sys.path.insert(0, '${ROOT}')
import db
print(db.q("SELECT COUNT(*) c FROM ab_session WHERE user_id=?", (${UID},), one=True)["c"])`);
  ck('释放后表里没有这个账号的行了', left === '0', '剩 ' + left + ' 行');

  // ---------------------------------------------------------------- 前端
  const ctx = await chromium.launch({ executablePath: CHROME, args: ['--no-sandbox'] });
  const bc = await ctx.newContext({ ignoreHTTPSErrors: true, viewport: { width: 420, height: 900 } });
  await bc.addInitScript(([t, u]) => {
    localStorage.setItem('bm_token', t); localStorage.setItem('bm_user', u);
  }, [info.tok, JSON.stringify(info.user)]);
  // 让取票固定返回 409，验前端会不会弹「在这台设备上继续听」
  await bc.addInitScript(() => {
    const of = window.fetch;
    window.__hb = [];
    window.fetch = function (url, opt) {
      const u = String(url);
      if (u.indexOf('/session/hb') >= 0) {
        window.__hb.push(JSON.parse((opt && opt.body) || '{}'));
        return Promise.resolve(new Response(JSON.stringify({ ok: true, owned: true }),
                                            { status: 200, headers: { 'Content-Type': 'application/json' } }));
      }
      if (window.__force409 && u.indexOf('/ticket') >= 0 && u.indexOf('sid=') >= 0) {
        return Promise.resolve(new Response(
          JSON.stringify({ detail: '该账号正在另一台设备上收听《三体全集(注释图文典藏版)》。\n' +
                                   '同一账号同一时间只能听一本有声书，请先在那边停止，或选择在这台设备上继续听。' }),
          { status: 409, headers: { 'Content-Type': 'application/json' } }));
      }
      return of.apply(this, arguments);
    };
  });
  const page = await bc.newPage();
  const errs = [];
  page.on('pageerror', e => errs.push(String(e).slice(0, 90)));
  await page.goto(BASE + '/', { waitUntil: 'domcontentloaded' });
  await page.waitForFunction(() => typeof audioPlay === 'function', null, { timeout: 20000 });
  await page.waitForTimeout(900);

  const sidInfo = await page.evaluate(() => ({
    sid: AU_SID, stored: sessionStorage.getItem('bm_audio_sid') }));
  ck('前端有会话标识，且落在 sessionStorage（每标签页一个终端）',
     !!sidInfo.sid && sidInfo.stored === sidInfo.sid, JSON.stringify(sidInfo));

  // 先走正常路径：心跳必须带上 sid
  await page.evaluate(() => { window.__force409 = false; AUP = null; audioPlay(2, 1, false); });
  await page.waitForFunction(() => (window.__hb || []).length >= 1, null, { timeout: 25000 }).catch(() => {});
  const hb0 = await page.evaluate(() => window.__hb.slice(0, 1));
  ck('★ 心跳带上了 sid（服务端靠它认终端）',
     hb0.length >= 1 && !!hb0[0].sid && hb0[0].lib_id === 2, JSON.stringify(hb0));

  // 再验 409：取票被挡时要弹抢占框，而不是只 toast
  await page.evaluate(() => {
    window.__force409 = true;
    window.__hb.length = 0;
    document.getElementById('modal-mask').classList.add('hidden');
    AUP = null;
    audioPlay(1, 1, false);
  });
  await page.waitForFunction(() => {
    const m = document.getElementById('modal-mask');
    return m && !m.classList.contains('hidden');
  }, null, { timeout: 25000 }).catch(() => {});
  const modal = await page.evaluate(() => {
    const m = document.getElementById('modal-mask');
    return { shown: !!m && !m.classList.contains('hidden'), text: m ? m.textContent : '' };
  });
  ck('★ 取票 409 → 弹出冲突提示（不是只 toast 一下就完）', modal.shown);
  ck('★ 弹层里有「在这台设备上继续听」按钮', /在这台设备上继续听/.test(modal.text),
     modal.text.slice(0, 60));
  ck('★ 弹层里有「返回」按钮', /返回/.test(modal.text));

  const hbAfter = await page.evaluate(() => window.__hb.length);
  ck('★ 冲突时不再空转心跳（我们本来就没在播）', hbAfter === 0, '心跳 ' + hbAfter + ' 次');

  // 被抢：直接触发锁丢失，看是否停播 + 弹层
  // 模拟「本机正在播，然后被别处抢走」：auLockLost 有防重入（AU_LOCKED 为真就返回），
  // 而上面那条 409 已经把它置真了，所以这里先复位，才是真实时序。
  await page.evaluate(() => {
    document.getElementById('modal-mask').classList.add('hidden');
    AU_LOCKED = false;
    auLockStart();
    auLockLost('该账号已在另一台设备上继续收听。');
  });
  await page.waitForTimeout(300);
  const lost = await page.evaluate(() => ({
    locked: AU_LOCKED,
    modal: !document.getElementById('modal-mask').classList.contains('hidden'),
    text: document.getElementById('modal-mask').textContent,
    hb: AU_HB === null, watch: AU_WATCH_CTL === null }));
  ck('★ 被抢后标记为已掉锁', lost.locked === true);
  ck('★ 被抢后停止心跳与长连接', lost.hb && lost.watch);
  ck('★ 被抢后弹出提示且说明本机已停', lost.modal && /本机已停止播放/.test(lost.text),
     lost.text.slice(0, 70));

  ck('没有 JS 报错', errs.length === 0, errs[0] || '');

  await bc.close();
  clean();
  console.log(`\n有声阅读单端锁：${pass} 通过 / ${fail} 失败`);
  process.exit(fail ? 1 : 0);
})();
