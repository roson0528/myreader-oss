# -*- coding: utf-8 -*-
"""有声书封面：登记后书才补上封面的兜底（§14.96）。

起因：《文学回忆录+木心谈木心》的有声书跑完了，但听书架里没有封面。
根因是**时序** —— `library.register()` 在任务完成时把书的封面抄进 `ab_lib.cover`，
而那本书的封面是**登记之后**才有的，于是 ab_lib.cover 一直是空字符串，
接口 `cover_url` 也就一直是空，前端只能显示占位图。

修法：`ablib_api._book_bits()` 顺带把书上的封面取出来，`_lib_brief()` 在
ab_lib.cover 为空时用它兜底。本脚本只读（除了最后把 lib#10 的封面仍是原值做校验），
不改任何数据。
"""
import json
import os
import ssl
import sys
import urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.chdir(ROOT)

import db  # noqa: E402
import auth  # noqa: E402
import ablib_api as A  # noqa: E402

PASS, FAIL = [], []
BASE = "https://127.0.0.1:9000"


def ck(name, ok, extra=""):
    (PASS if ok else FAIL).append(name)
    print(("  ✓ " if ok else "  ✗ ") + name + (("  → " + str(extra)) if (extra and not ok) else ""))


print("A. _lib_brief 的封面兜底（纯函数，不动数据）")

# 拿真实的 lib#10 当样板，只把 cover 改成各种状态
row = db.q("SELECT * FROM ab_lib WHERE id=10", one=True)
ck("A0 样板存在：听书架里有《文学回忆录+木心谈木心》", row is not None)
lib = dict(row)
book = db.q("SELECT cover FROM books WHERE id=?", (lib["book_id"],), one=True)

# A1 复现修复前的状态：ab_lib.cover 为空
lib_pre = dict(lib); lib_pre["cover"] = ""
d = A._lib_brief(lib_pre, None)
ck("A1 ab_lib.cover 为空时兜底用书上的封面",
   d["cover"] == (book["cover"] or "") and d["cover_url"] == "/api/books/%s/cover" % lib["book_id"],
   {"cover": d["cover"], "url": d["cover_url"], "book_cover": book["cover"]})

# A2 现状：ab_lib.cover 有值
d2 = A._lib_brief(dict(lib), None)
ck("A2 ab_lib.cover 有值时照常用它", d2["cover"] == lib["cover"] and d2["cover_url"] != "")

# A3 两边不一致时以 ab_lib 上的为准（不覆盖显式值）
lib_x = dict(lib); lib_x["cover"] = "custom-cover.jpg"
d3 = A._lib_brief(lib_x, None)
ck("A3 显式写过的封面不被书的覆盖", d3["cover"] == "custom-cover.jpg", d3["cover"])

# A4 书也没有封面（用一个不存在的 book_id）→ 仍然是空，不会给出打不开的 URL
lib_none = dict(lib); lib_none["cover"] = ""; lib_none["book_id"] = 999999999
d4 = A._lib_brief(lib_none, None)
ck("A4 书也没封面时保持为空（不产生坏 URL）", d4["cover"] == "" and d4["cover_url"] == "",
   {"cover": d4["cover"], "url": d4["cover_url"]})

# A5 评分/热度推荐没被这次改动带坏
d5 = A._lib_brief(dict(lib), None)
ck("A5 评分与热度推荐字段照旧存在",
   isinstance(d5.get("rating"), float) and d5.get("guest_featured") in (0, 1),
   {"rating": d5.get("rating"), "gf": d5.get("guest_featured")})
ck("A6 其它字段没少（标题/章节数/时长）",
   d5["title"] == lib["title"] and d5["total_chapters"] == lib["total_chapters"]
   and d5["total_seconds"] == lib["total_seconds"], {k: d5[k] for k in ("title", "total_chapters")})

print("\nB. 线上数据")
n_all = db.q("SELECT COUNT(*) c FROM ab_lib", one=True)["c"]
n_no = db.q("SELECT COUNT(*) c FROM ab_lib WHERE cover IS NULL OR cover=''", one=True)["c"]
ck("B1 听书架每一本都有封面了", n_no == 0, "%d/%d 本没封面" % (n_no, n_all))
r10 = db.q("SELECT cover FROM ab_lib WHERE id=10", one=True)
ck("B2 《文学回忆录+木心谈木心》的 cover 与书一致", r10["cover"] == (book["cover"] or ""),
   {"lib": r10["cover"], "book": book["cover"]})

print("\nC. 封面接口真的给得出图")
tok = auth.create_token(db.q("SELECT * FROM users WHERE role='admin' AND enabled=1 ORDER BY id LIMIT 1", one=True))
req = urllib.request.Request(BASE + "/api/books/%s/cover" % lib["book_id"],
                             headers={"Authorization": "Bearer " + tok})
try:
    with urllib.request.urlopen(req, timeout=30,
                                context=ssl._create_unverified_context()) as resp:
        body = resp.read()
        ctype = resp.headers.get("Content-Type", "")
    ck("C1 /api/books/296878/cover 返回 200 且是图片",
       len(body) > 5000 and ctype.startswith("image"), {"len": len(body), "ctype": ctype})
    ck("C2 拿到的是真图片（Pillow 能打开）", (lambda: __import__("PIL.Image", fromlist=["Image"])
        .open(__import__("io").BytesIO(body)).size)() and True)
except Exception as e:
    ck("C1 /api/books/296878/cover 返回 200 且是图片", False, str(e)[:120])

print("\n" + "=" * 62)
print("有声书封面兜底：%d 通过 / %d 失败" % (len(PASS), len(FAIL)))
for f in FAIL:
    print("  失败：" + f)
sys.exit(1 if FAIL else 0)
