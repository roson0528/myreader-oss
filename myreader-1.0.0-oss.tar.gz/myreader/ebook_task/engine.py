#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
全量执行引擎
阶段1: FTP 并行直通复制（批量电子书，断点续传）
阶段2: 压缩包下载->解压->分类->上传
阶段3: SFTP 兜底（emoji 目录 + 混合编码文件）
"""
import os, sys, json, time, ftplib, threading, queue, io, re, shutil, traceback
from collections import defaultdict

# 连接信息走环境变量（与 book_manager/config.py 同一套变量）
HOST = os.environ.get("BOOKMGR_FTP_HOST", "127.0.0.1")
PORT = int(os.environ.get("BOOKMGR_SFTP_PORT", "22"))
USER = os.environ.get("BOOKMGR_FTP_USER", "bookadmin")
PWD = os.environ.get("BOOKMGR_FTP_PASS", "")
BASE = os.environ.get("BOOKMGR_FTP_BASE", "/books")
W = os.path.dirname(os.path.abspath(__file__))
LOGDIR = W + "/logs"
STDIR = W + "/state"
ADIR = W + "/archives"
XDIR = W + "/extract"

WORKERS = 6
BLOCK = 1 << 20  # 1MB
MAXRETRY = 3

# 导入分类模块
sys.path.insert(0, W)
import classify as CL

LOCK = threading.Lock()

def log(msg):
    line = f"[{time.strftime('%H:%M:%S')}] {msg}"
    print(line, flush=True)
    with open(LOGDIR + "/engine.log", "a", encoding="utf-8") as fh:
        fh.write(line + "\n")

def open_ftp():
    f = ftplib.FTP()
    f.encoding = "gbk"
    f.connect(HOST, PORT, timeout=60)
    f.login(USER, PWD)
    return f

def load_done(path):
    s = set()
    if os.path.exists(path):
        with open(path, encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if line:
                    s.add(line.split("\t")[0])
    return s

def append_line(path, text):
    with open(path, "a", encoding="utf-8") as fh:
        fh.write(text + "\n")

# ---------------- 阶段1：批量复制 ----------------
def bulk_copy():
    plan = json.load(open(STDIR + "/plan.json"))
    plans = [p for p in plan["plans"] if p["via"] == "ftp"]
    done = load_done(STDIR + "/done_bulk.jsonl")
    failed_existing = load_done(STDIR + "/failed_bulk.jsonl")

    tasks = []
    for p in plans:
        if p["src"] in done or p["src"] in failed_existing:
            continue
        tasks.append(p)
    total = len(tasks)
    total_bytes = sum(p["size"] for p in tasks)
    log(f"[阶段1] 待复制 {total} 个文件, 剩余 {total_bytes/1e9:.1f} GB (已跳过 {len(plans)-total})")

    created_dirs = set()
    cnt = [0]
    bytes_done = [0]
    stop = threading.Event()

    def ensure_dir(wf, cat):
        if cat not in created_dirs:
            try:
                wf.mkd(cat)
            except ftplib.error_perm:
                pass
            created_dirs.add(cat)

    def worker():
        r = open_ftp(); w = open_ftp()
        r.cwd(BASE); w.cwd(BASE)
        while not stop.is_set():
            try:
                p = tasks_q.get_nowait()
            except queue.Empty:
                return
            src = BASE + "/" + p["src"]
            dest = BASE + "/" + p["dest"]
            cat = p["cat_folder"]
            ok = False
            for attempt in range(1, MAXRETRY + 1):
                try:
                    ensure_dir(w, cat)
                    rc = r.ntransfercmd("RETR " + src)[0]
                    rc.settimeout(180)
                    wc = w.ntransfercmd("STOR " + dest)[0]
                    wc.settimeout(180)
                    while True:
                        b = rc.recv(BLOCK)
                        if not b:
                            break
                        wc.sendall(b)
                    rc.close(); wc.close()
                    r.voidresp(); w.voidresp()
                    ok = True
                    break
                except Exception as e:
                    try: rc.close()
                    except Exception: pass
                    try: wc.close()
                    except Exception: pass
                    try: r.voidresp()
                    except Exception: pass
                    try: w.voidresp()
                    except Exception: pass
                    if attempt < MAXRETRY:
                        # 重连
                        try: r.quit()
                        except Exception: pass
                        try: w.quit()
                        except Exception: pass
                        time.sleep(1 + attempt)
                        r = open_ftp(); w = open_ftp()
                        r.cwd(BASE); w.cwd(BASE)
                    else:
                        # 最终失败：清理可能的残留目标文件
                        try:
                            w.delete(dest)
                        except Exception:
                            pass
                        append_line(STDIR + "/failed_bulk.jsonl", f"{p['src']}\t{type(e).__name__}: {e}")
            if ok:
                append_line(STDIR + "/done_bulk.jsonl", f"{p['src']}\t{p['dest']}\t{p['size']}")
                with LOCK:
                    cnt[0] += 1; bytes_done[0] += p["size"]

    tasks_q = queue.Queue()
    for p in tasks:
        tasks_q.put(p)
    threads = [threading.Thread(target=worker) for _ in range(WORKERS)]

    def reporter():
        while not stop.is_set():
            time.sleep(20)
            with LOCK:
                c, b = cnt[0], bytes_done[0]
            if total:
                log(f"[阶段1进度] {c}/{total} 文件  {b/1e9:.1f}/{total_bytes/1e9:.1f} GB  ({100.0*c/total:.1f}%)")
            json.dump({"phase": "bulk", "done": c, "total": total,
                       "bytes_done": b, "bytes_total": total_bytes,
                       "pct": 100.0 * c / total if total else 0},
                      open(STDIR + "/progress.json", "w"))

    rep = threading.Thread(target=reporter, daemon=True)
    t0 = time.time()
    for t in threads: t.start()
    rep.start()
    for t in threads: t.join()
    stop.set()
    rep.join(timeout=2)
    with LOCK:
        c, b = cnt[0], bytes_done[0]
    log(f"[阶段1完成] {c}/{total} 文件, {b/1e9:.1f} GB, 用时 {time.time()-t0:.0f}s")
    return c, total

# ---------------- 阶段2：压缩包 ----------------
def classify_inner(rel_ctx, filename):
    """对解压出的电子书分类+命名"""
    cat = CL.classify(filename, rel_ctx)
    fn, title, author = CL.final_name(filename)
    return cat, fn, title, author

def extract_archive(local, dest_dir):
    ext = os.path.splitext(local)[1].lower()
    os.makedirs(dest_dir, exist_ok=True)
    if ext == ".zip":
        import zipfile
        with zipfile.ZipFile(local) as z:
            for info in z.infolist():
                name = info.filename
                if name.startswith("/") or ".." in name.replace("\\", "/").split("/"):
                    continue
                z.extract(info, dest_dir)
    elif ext == ".rar":
        os.system(f"unrar x -o+ -y '{local}' '{dest_dir}/' >/dev/null 2>&1")
    elif ext == ".7z":
        os.system(f"7z x -y -o'{dest_dir}' '{local}' >/dev/null 2>&1")
    else:
        raise RuntimeError(f"unknown archive ext {ext}")

def walk_local(d):
    out = []
    for root, dirs, files in os.walk(d):
        for f in files:
            out.append(os.path.join(root, f))
    return out

def archives_stage():
    plan = json.load(open(STDIR + "/plan.json"))
    archives = plan["archives"]
    done = load_done(STDIR + "/done_archive.jsonl")
    failed = load_done(STDIR + "/failed_archive.jsonl")

    # 全局同名注册表（含 bulk 已用名，避免解压书与 bulk 重名）
    seen = defaultdict(int)
    for p in plan["plans"]:
        seen[(p["cat"], p["name"])] += 1

    # 分组：合并 .partN.rar
    groups = []
    by_key = defaultdict(list)
    for a in archives:
        rel = a["path"]
        base = rel.rsplit("/", 1)[-1]
        m = re.match(r"^(.*?)\.part(\d+)\.rar$", base, re.I)
        if m:
            key = rel.rsplit("/", 1)[0] + "/" + m.group(1)
            by_key[key].append(a)
        else:
            groups.append([a])
    for key, parts in by_key.items():
        parts.sort(key=lambda x: int(re.match(r".*\.part(\d+)\.rar$", x["path"], re.I).group(1)))
        groups.append(parts)

    pending = []
    for g in groups:
        key = g[0]["path"]
        if key in done or key in failed:
            continue
        pending.append(g)
    log(f"[阶段2] 待处理压缩包组 {len(pending)} 组 ({len(archives)} 个文件, {sum(a['size'] for a in archives)/1e9:.2f} GB)")

    ftp = open_ftp()
    for g in pending:
        key = g[0]["path"]
        tag = os.path.basename(key)
        safe = re.sub(r"[^\w\u4e00-\u9fff.-]", "_", tag)
        local_parts = []
        try:
            for a in g:
                lp = os.path.join(ADIR, safe + ("_part%d" % len(local_parts) if len(g) > 1 else "") + os.path.splitext(a["path"])[1])
                with open(lp, "wb") as fh:
                    ftp.retrbinary("RETR " + BASE + "/" + a["path"], fh.write, blocksize=1 << 20)
                local_parts.append(lp)
            ext = os.path.splitext(g[0]["path"])[1].lower()
            src_local = local_parts[0]
            if ext == ".rar" and len(local_parts) > 1:
                src_local = local_parts[0]  # unrar 自动合并 partN
            exdir = os.path.join(XDIR, safe)
            if os.path.exists(exdir):
                shutil.rmtree(exdir)
            extract_archive(src_local, exdir)
            files = walk_local(exdir)
            inner_books = [f for f in files if CL.ext_of(f) in CL.BOOK_EXT]
            log(f"[阶段2] {tag}: 解出 {len(files)} 个文件, 其中电子书 {len(inner_books)}")
            if not inner_books:
                append_line(STDIR + "/failed_archive.jsonl", f"{key}\t无电子书内容(软件/图片等), 跳过")
                log(f"[阶段2] {tag}: 无电子书内容，跳过")
            else:
                ctx = g[0]["path"].rsplit("/", 1)[0]
                for f in inner_books:
                    fn = os.path.basename(f)
                    cat, name, title, author = classify_inner(ctx, fn)
                    # 同名去重
                    if seen[(cat, name)] > 0:
                        e = name.rsplit(".", 1)
                        name = f"{e[0]}({seen[(cat,name)]})" + ("." + e[1] if len(e) == 2 else "")
                    seen[(cat, name)] += 1
                    cdir = CL.CAT_FOLDERS.get(cat, "00_待分类")
                    dest = BASE + "/" + cdir + "/" + name
                    try:
                        try: ftp.mkd(cdir)
                        except Exception: pass
                        ftp.storbinary("STOR " + dest, open(f, "rb"), blocksize=1 << 20)
                        append_line(STDIR + "/done_archive.jsonl", f"{key}!{fn}\t{cat}/{name}")
                    except Exception as e:
                        append_line(STDIR + "/failed_archive.jsonl", f"{key}!{fn}\t{type(e).__name__}: {e}")
            append_line(STDIR + "/done_archive.jsonl", f"{key}\t{tag}")
            log(f"[阶段2] {tag} 完成")
        except Exception as e:
            append_line(STDIR + "/failed_archive.jsonl", f"{key}\t{type(e).__name__}: {e}")
            log(f"[阶段2] {tag} 失败: {e}")
        finally:
            for lp in local_parts:
                try: os.remove(lp)
                except Exception: pass
    try: ftp.quit()
    except Exception: pass
    log("[阶段2完成]")

# ---------------- 阶段3：SFTP 兜底 ----------------
def sftp_stage():
    import paramiko
    plan = json.load(open(STDIR + "/plan.json"))
    pending = plan["sftp_pending"]  # 混合编码文件
    emoji_dirs = ["🔥知乎付费文", "📚 世界史的故事（套装39册）"]
    done = load_done(STDIR + "/done_sftp.jsonl")

    # 重试 SSH（限流恢复）
    c = None
    for i in range(8):
        try:
            c = paramiko.SSHClient()
            c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            c.connect(HOST, port=22, username=USER, password=PWD, timeout=30,
                      allow_agent=False, look_for_keys=False)
            log("[阶段3] SFTP 连接成功")
            break
        except Exception as e:
            log(f"[阶段3] SSH 连接失败(第{i+1}次): {type(e).__name__}")
            c = None
            time.sleep(30)
    if c is None:
        log("[阶段3] SSH 仍不可用，emoji目录/混合编码文件暂缓（记录 pending）")
        return

    s = c.open_sftp()
    seen = defaultdict(int)
    for p in plan["plans"]:
        seen[(p["cat"], p["name"])] += 1
    ftp = open_ftp()

    # 3a) 枚举 emoji 目录下的电子书
    def walk_sftp(path, rel):
        out = []
        try:
            for e in s.listdir_attr(path):
                if e.filename in (".", ".."):
                    continue
                isdir = bool(e.st_mode & 0o040000) if e.st_mode else False
                r = rel + "/" + e.filename if rel else e.filename
                if isdir:
                    out += walk_sftp(path + "/" + e.filename, r)
                else:
                    out.append((path + "/" + e.filename, r, e.st_size))
        except Exception as ex:
            log(f"[阶段3] 枚举 {path} 失败: {ex}")
        return out

    items = []
    for d in emoji_dirs:
        items += walk_sftp(BASE + "/" + d, d)

    # 3b) 混合编码文件：在父目录按大小定位真实文件名
    if pending:
        parent = os.path.dirname(BASE + "/" + pending[0]["path"])
        sz = pending[0]["size"]
        try:
            for e in s.listdir_attr(parent):
                if e.st_size == sz and CL.ext_of(e.filename) in CL.BOOK_EXT:
                    items.append((parent + "/" + e.filename, e.filename, sz))
                    break
        except Exception as ex:
            log(f"[阶段3] 定位混合编码文件失败: {ex}")

    to_copy = []
    for full, rel, sz in items:
        key = rel
        if key in done:
            continue
        ext = CL.ext_of(full)
        if ext not in CL.BOOK_EXT:
            continue
        to_copy.append((full, rel, sz))

    log(f"[阶段3] 待 SFTP 复制 {len(to_copy)} 个文件")
    cnt = 0
    for full, rel, sz in to_copy:
        fn = os.path.basename(full)
        ctx = rel.rsplit("/", 1)[0] if "/" in rel else ""
        if "知乎付费文" in rel:
            ctx = "🔥知乎付费文"
        cat = CL.classify(fn, ctx)
        name, title, author = CL.final_name(fn)
        if seen[(cat, name)] > 0:
            e = name.rsplit(".", 1)
            name = f"{e[0]}({seen[(cat,name)]})" + ("." + e[1] if len(e) == 2 else "")
        seen[(cat, name)] += 1
        cdir = CL.CAT_FOLDERS.get(cat, "00_待分类")
        dest = cdir + "/" + name
        try:
            try: ftp.mkd(cdir)
            except Exception: pass
            rf = s.open(full, "rb")
            ftp.storbinary("STOR " + BASE + "/" + dest, rf, blocksize=1 << 20)
            rf.close()
            append_line(STDIR + "/done_sftp.jsonl", f"{rel}\t{dest}\t{sz}")
            cnt += 1
        except Exception as e:
            append_line(STDIR + "/failed_sftp.jsonl", f"{rel}\t{type(e).__name__}: {e}")
            log(f"[阶段3] {fn} 失败: {e}")
    try: ftp.quit()
    except Exception: pass
    s.close(); c.close()
    log(f"[阶段3完成] {cnt}/{len(to_copy)}")

# ---------------- 主流程 ----------------
if __name__ == "__main__":
    os.makedirs(LOGDIR, exist_ok=True)
    os.makedirs(STDIR, exist_ok=True)
    os.makedirs(ADIR, exist_ok=True)
    os.makedirs(XDIR, exist_ok=True)
    log("===== 引擎启动 =====")
    try:
        bulk_copy()
    except Exception:
        log("bulk 异常:\n" + traceback.format_exc())
    try:
        archives_stage()
    except Exception:
        log("archives 异常:\n" + traceback.format_exc())
    try:
        sftp_stage()
    except Exception:
        log("sftp 异常:\n" + traceback.format_exc())
    log("===== 引擎结束 =====")
