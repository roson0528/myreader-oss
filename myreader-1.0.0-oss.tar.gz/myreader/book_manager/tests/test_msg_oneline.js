// 「我的消息」每条只占**一行**：类型 + 标题 + 发送人 + 时间（+ 回复）。
//
// 背景：原来一条消息占三行 —— 第一行「类型+标题+时间」、第二行正文摘要、
// 第三行「来自谁 + 回复按钮」。一屏看不了几条，「我的消息」卡片高度很大。
// 现在正文摘要去掉（点标题弹窗看全文），其余信息并到同一行。
//
// ★ 发送人只在「标题里没提到他」时单独显示：私信/回复的标题本来就写成
//   「来自 IE6261 的回复」，同一行里再放一遍昵称是浪费手机上那点宽度。
//   信息没丢 —— 昵称就在标题里。这个测试两头都验。
//
// 本测试**只读**（只登录看消息，不发送、不修改任何数据）。
const { chromium } = require('playwright-core');
const { execSync } = require('child_process');
const CHROME = '/srv/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome';
const ROOT = '/srv/myreader/book_manager';
const BASE = 'https://127.0.0.1:9000';

let pass = 0, fail = 0;
const ck = (n, ok, extra) => {
  if (ok) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (extra ? '  → ' + extra : '')); }
};
const py = (c) => execSync('venv/bin/python -', { cwd: ROOT, encoding: 'utf8', input: c }).trim();

(async () => {
  // 用消息最多的账号（示例的 uid=15），只读
  const info = JSON.parse(py(`
import sys, json
sys.path.insert(0, '${ROOT}')
import db, auth
u = db.q("SELECT * FROM users WHERE id=15", one=True)
n = db.q("SELECT COUNT(*) c FROM messages WHERE to_id=15", one=True)["c"]
tot = db.q("SELECT COUNT(*) c FROM messages", one=True)["c"]
print(json.dumps({"tok": auth.create_token(u), "user": dict(u), "n": n, "tot": tot}))`));

  const b = await chromium.launch({ executablePath: CHROME, args: ['--no-sandbox'] });
  const ctx = await b.newContext({ ignoreHTTPSErrors: true, viewport: { width: 420, height: 900 } });
  await ctx.addInitScript(([t, u]) => {
    localStorage.setItem('bm_token', t); localStorage.setItem('bm_user', u);
  }, [info.tok, JSON.stringify(info.user)]);
  const page = await ctx.newPage();
  const errs = [];
  page.on('pageerror', e => errs.push(String(e).slice(0, 90)));
  await page.goto(BASE + '/', { waitUntil: 'domcontentloaded' });
  await page.waitForFunction(() => typeof switchPage === 'function', null, { timeout: 20000 });
  await page.evaluate(() => switchPage('me'));
  await page.waitForTimeout(2500);

  const read = () => page.evaluate(() => {
    const items = Array.from(document.querySelectorAll('#me-msg-list .msg-item'));
    return {
      n: items.length,
      rows: items.map(x => {
        const t = x.querySelector('.msg-title');
        const f = x.querySelector('.msg-from');
        const tm = x.querySelector('.msg-time');
        return {
          h: x.offsetHeight,
          title: t ? t.textContent : null,
          titleLines: t ? t.getClientRects().length : 0,
          from: f ? f.textContent : '',
          time: tm ? tm.textContent : '',
          reply: !!x.querySelector('.msg-reply'),
          kinds: Array.from(x.querySelectorAll('.msg-kind')).map(k => k.textContent),
        };
      }),
      summary: document.querySelectorAll('#me-msg-list .msg-summary').length,
      cardH: (document.getElementById('me-msg-card') || {}).offsetHeight || 0,
    };
  });

  const r1 = await read();
  ck('消息列表有内容', r1.n > 0, r1.n + ' 条');
  ck('★ 每条消息的标题都只有一行（没有折行）',
     r1.rows.every(x => x.titleLines <= 1), JSON.stringify(r1.rows.filter(x => x.titleLines > 1).slice(0, 2)));
  ck('★ 每条消息整行高度都是一行的高度（≤48px）',
     r1.rows.every(x => x.h > 0 && x.h <= 48), '行高 ' + JSON.stringify(r1.rows.map(x => x.h)));
  ck('★ 去掉了正文摘要那一行', r1.summary === 0, '残留 ' + r1.summary + ' 个');
  ck('每条都有标题', r1.rows.every(x => x.title && x.title.trim()), '');
  ck('每条都有发送时间（MM-DD HH:MM）',
     r1.rows.every(x => /^\d\d-\d\d \d\d:\d\d$/.test(x.time)), JSON.stringify(r1.rows.slice(0, 2).map(x => x.time)));
  ck('每条都有类型标签', r1.rows.every(x => x.kinds.length === 1), '');

  // 翻页把「有发送人」「有回复」的样本都找出来
  let withFrom = null, inTitle = null, withReply = null;
  for (let pg = 1; pg <= 4 && (!withFrom || !inTitle || !withReply); pg++) {
    await page.evaluate(n => loadMessages(n), pg);
    await page.waitForTimeout(1300);
    const r = await read();
    for (const x of r.rows) {
      if (!withFrom && x.from) withFrom = x;
      // 标题写成「来自 X 的…」的行：发送人不该再单独出现
      const m = /^来自 (\S+) 的/.exec(x.title || '');
      if (!inTitle && m && !x.from) inTitle = { title: x.title, nick: m[1] };
      if (!withReply && x.reply) withReply = x;
    }
  }
  ck('★ 标题里没提到的发送人会单独显示', !!withFrom,
     withFrom ? `${withFrom.title} ⟨${withFrom.from}⟩` : '没找到样本');
  ck('发送人显示成「来自 X」', !withFrom || /^来自 |^发给 /.test(withFrom.from), withFrom && withFrom.from);
  ck('★ 标题已写「来自 X 的…」时不重复显示同一个昵称', !!inTitle,
     inTitle ? `${inTitle.title}（昵称 ${inTitle.nick} 已在标题里）` : '没找到样本');
  ck('★ 私信有「回复」入口', !!withReply,
     withReply ? `${withReply.title} [回复]` : '没找到样本');

  // 窄屏（iPhone SE 宽度）也必须是一行
  await page.setViewportSize({ width: 360, height: 780 });
  await page.evaluate(() => loadMessages(1));
  await page.waitForTimeout(1300);
  const r2 = await read();
  ck('★ 360px 窄屏下仍然一行不折', r2.rows.every(x => x.titleLines <= 1 && x.h <= 48),
     '行高 ' + JSON.stringify(r2.rows.map(x => x.h)));

  // 卡片确实矮了：5 条消息 + 头部/筛选/分页，应远小于原来三行布局
  ck('「我的消息」卡片高度明显收窄（<520px）', r2.cardH > 0 && r2.cardH < 520, r2.cardH + 'px');
  ck('页面没有 JS 报错', errs.length === 0, errs[0] || '');

  await b.close();
  console.log(`\n我的消息单行布局：${pass} 通过 / ${fail} 失败`);
  process.exit(fail ? 1 : 0);
})();
