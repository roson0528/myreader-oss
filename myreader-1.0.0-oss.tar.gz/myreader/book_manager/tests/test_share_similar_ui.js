// 「我的消息」筛选 + 共享审核同名书提示 的界面回归。
//
// 前置：服务在 https://127.0.0.1:9000 运行，且 tests/test_share_similar_msg.py 已经跑过
//      （它验证后端；本脚本自己造一份界面用的数据，结束时按 id 精确清理）。
// 运行：NODE_PATH=/tmp/pwtest/node_modules node tests/test_share_similar_ui.js
//
// 安全约定：拒绝弹窗里**点按钮只为验证填入**，最后取消，绝不真的驳回别人的申请；
//          用的是 test 账号与临时书，清理只按本脚本建的具体 id。
const { chromium } = require('playwright-core');
const { execSync } = require('child_process');
const CHROME = '/srv/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome';
const ROOT = '/srv/myreader/book_manager';
const BASE = 'https://localhost:9000';

let pass = 0, fail = 0;
const ck = (n, ok, extra) => { if (ok) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (extra ? '  → ' + extra : '')); } };
// 把 Python 片段从 stdin 喂给解释器 —— 不走 shell 引号，中文/引号/换行都不会被吃掉
const py = (code) => execSync('venv/bin/python -', { cwd: ROOT, encoding: 'utf8', input: code }).trim();

const FIXTURE = `
import sys, json, uuid
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
import db, auth, urllib.request, urllib.parse, ssl, json as J
ctx = ssl._create_unverified_context()
me = db.q("SELECT * FROM users WHERE username='test'", one=True)
tag = uuid.uuid4().hex[:6]
core = '界面同名书' + tag
# 书库里已有一本同名（系统书），test 自己那本标题带作者与 (Z-Library) 尾巴
other = db.ex("INSERT INTO books (path,title,author,ext,size,owner_id,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?)",
              ('_zztest/ui-%s.azw3' % tag, core, '测试作者', '.azw3', 2883584, None, db.now(), db.now()))
mine = db.ex("INSERT INTO books (path,title,author,ext,size,owner_id,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?)",
             ('_zztest/ui-%s.epub' % tag, core + ' (界面测试) (Z-Library)', '测试作者', '.epub', 2150000, me['id'], db.now(), db.now()))
rid = db.add_share_request(mine, me['id'])
# 给 test 账号各造一条「系统消息」「用户消息」，UI 才能验证两个筛选都有内容
sysmid = db.add_message(me['id'], '界面测试系统消息', '系统正文', kind='system')
usermid = db.add_message(me['id'], '界面测试用户消息', '用户正文', kind='pm', from_id=1)
# 取一个管理员 token，供浏览器直接注入登录态
adm = db.q("SELECT * FROM users WHERE role='admin' AND enabled=1 ORDER BY id LIMIT 1", one=True)
print(J.dumps({'other': other, 'mine': mine, 'rid': rid, 'core': core,
               'sysmid': sysmid, 'usermid': usermid,
               'atok': db.q("SELECT 1", one=True) and auth.create_token(adm) or '',
               'admin': {'id': adm['id'], 'username': adm['username'],
                         'role': 'admin', 'name': adm['name'] or adm['username']}}))
`;

const CLEANUP = (ids) => `
import sys, json
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
import db
ids = ${JSON.stringify(ids)}
for m in (ids.get('sysmid'), ids.get('usermid')):
    if m: db.ex("DELETE FROM messages WHERE id=?", (m,))
if ids.get('rid'): db.ex("DELETE FROM share_requests WHERE id=?", (ids['rid'],))
for b in (ids.get('mine'), ids.get('other')):
    if b: db.ex("DELETE FROM books WHERE id=?", (b,))
print('cleaned')
`;

(async () => {
  const fx = JSON.parse(py(FIXTURE));
  console.log('  造好数据：书库同名书 #%d，申请人的书 #%d，申请 #%d', fx.other, fx.mine, fx.rid);
  let browser;
  try {
    browser = await chromium.launch({ executablePath: CHROME, headless: true,
      args: ['--no-sandbox', '--ignore-certificate-errors'] });
    const ctx = await browser.newContext({ ignoreHTTPSErrors: true });
    const msgUrls = [];      // 只用来断言「切筛选确实重新拉了接口」

    // ================= A. 用户侧：我的消息筛选 =================
    console.log('\n  ===== A. 用户侧「我的消息」筛选 =====');
    // ★ 登录态必须用 addInitScript 注入：用户端首屏是「游客模式」，
    //   游客流程会把 bm_token 抹掉，等页面加载完再写 localStorage 是存不住的。
    const me = JSON.parse(py(`
import json, ssl, urllib.parse, urllib.request
ctx = ssl._create_unverified_context()
d = urllib.parse.urlencode({'username': 'test', 'password': 'test'}).encode()
r = urllib.request.Request('https://127.0.0.1:9000/api/login', data=d, method='POST')
j = json.loads(urllib.request.urlopen(r, context=ctx, timeout=30).read())
print(json.dumps({'token': j['token'], 'user': j.get('user')}))
`));
    ck('拿到了 test 账号的登录态', !!me.token && !!me.user, (me.user || {}).username);

    const ctx2 = await ctx.browser().newContext({ ignoreHTTPSErrors: true });
    await ctx2.addInitScript(([t, u]) => {
      try { localStorage.setItem('bm_token', t); localStorage.setItem('bm_user', u); } catch (e) {}
    }, [me.token, JSON.stringify(me.user)]);
    const upage = await ctx2.newPage();
    const uerrs = [];
    upage.on('pageerror', e => uerrs.push(String(e)));
    upage.on('dialog', d => d.accept());
    upage.on('request', r => { if (r.url().indexOf('/api/messages?') >= 0) msgUrls.push(r.url()); });

    await upage.goto(BASE + '/#/me', { waitUntil: 'domcontentloaded' });
    await upage.waitForTimeout(3000);
    ck('注入的登录态生效（不是游客模式）',
      (await upage.evaluate(() => (typeof GUEST !== 'undefined') ? !GUEST : false)),
      await upage.evaluate(() => 'guest=' + (typeof GUEST !== 'undefined' ? GUEST : 'undef')
        + ' token=' + (typeof TOKEN !== 'undefined' ? (TOKEN || '').slice(0, 8) : 'undef')));
    ck('「我的」页已切到前台', await upage.evaluate(() => {
      const e = document.getElementById('page-me');
      return !!e && !e.classList.contains('hidden');
    }));

    const chips = await upage.evaluate(() => [...document.querySelectorAll('#me-msg-filter .chip')]
      .map(b => ({ t: b.textContent.trim(), s: b.dataset.scope, on: b.classList.contains('active') })));
    ck('消息卡里有三个筛选胶囊', chips.length === 3, JSON.stringify(chips.map(c => c.t)));
    ck('三个胶囊是「全部 / 用户消息 / 系统消息」',
      chips.map(c => c.t).join(',') === '全部,用户消息,系统消息', chips.map(c => c.t).join(','));
    ck('默认选中「全部」', chips.filter(c => c.on).length === 1 && chips.find(c => c.on).s === 'all',
      JSON.stringify(chips.filter(c => c.on)));

    // ★ 消息改成**一行**布局后页脚没有了：发送人改由 .msg-from 展示，
    //   而且「标题里已经写了同一个昵称」时不重复显示（见 renderMessages）。
    //   所以这里同时取标题，用来判断「是否看得出是谁发的」。
    const kinds = () => upage.evaluate(() => [...document.querySelectorAll('#me-msg-list .msg-item')].map(it => ({
      kind: (it.querySelector('.msg-kind') || {}).textContent || '',
      from: (it.querySelector('.msg-from') || {}).textContent || '',
      title: (it.querySelector('.msg-title') || {}).textContent || '',
    })));

    msgUrls.length = 0;
    await upage.evaluate(() => setMsgScope('system'));
    await upage.waitForTimeout(1800);
    ck('点「系统消息」发出的请求带 scope=system',
      msgUrls.some(u => u.indexOf('scope=system') >= 0), msgUrls.slice(-1)[0] || '(无请求)');
    let items = await kinds();
    ck('系统消息筛选下确实有内容（不是空列表假通过）', items.length > 0, items.length + ' 条');
    ck('系统消息筛选下每条都标着「系统」', items.every(x => x.kind.indexOf('系统') >= 0),
      JSON.stringify(items.map(x => x.kind)));
    ck('系统消息筛选下每条都不显示发送人（系统消息本来就没有发送人）',
      items.length > 0 && items.every(x => !x.from),
      JSON.stringify(items.map(x => x.from)));
    const onNow = await upage.evaluate(() => [...document.querySelectorAll('#me-msg-filter .chip')]
      .filter(b => b.classList.contains('active')).map(b => b.dataset.scope));
    ck('胶囊高亮切到「系统消息」', onNow.length === 1 && onNow[0] === 'system', JSON.stringify(onNow));

    msgUrls.length = 0;
    await upage.evaluate(() => setMsgScope('user'));
    await upage.waitForTimeout(1800);
    ck('点「用户消息」发出的请求带 scope=user',
      msgUrls.some(u => u.indexOf('scope=user') >= 0), msgUrls.slice(-1)[0] || '(无请求)');
    items = await kinds();
    ck('用户消息筛选下确实有内容', items.length > 0, items.length + ' 条');
    // 单行布局下「谁发的」有两种呈现：单独的发送人格，或标题里本身就写了昵称
    ck('用户消息筛选下每条都看得出是谁发的（发送人格，或标题里就写了昵称）',
      items.length > 0 && items.every(x =>
        x.from.indexOf('来自') === 0 || x.from.indexOf('发给') === 0 ||
        /^来自 .+ 的/.test(x.title) || /^已发送给 /.test(x.title)),
      JSON.stringify(items.slice(0, 3).map(x => x.title + ' | ' + x.from)));
    ck('用户消息里不会出现「系统消息」发送人',
      items.length > 0 && items.every(x => x.from.indexOf('系统消息') < 0),
      JSON.stringify(items.map(x => x.from)));

    // 切筛选应回到第 1 页
    await upage.evaluate(() => { msgPage = 99; setMsgScope('all'); });
    await upage.waitForTimeout(1800);
    const pg = await upage.evaluate(() => msgPage);
    ck('切换筛选会回到第 1 页', pg === 1, 'msgPage=' + pg);

    const dotOk = await upage.evaluate(() => {
      const b = document.getElementById('me-msg-unread');
      return !!b;    // 未读徽标节点仍在（筛选不影响未读口径）
    });
    ck('未读徽标仍在（筛选不改变未读口径）', dotOk);

    // ================= B. 后台侧：共享审核同名提示 =================
    console.log('\n  ===== B. 后台共享审核的同名书提示 =====');
    const ctx3 = await ctx.browser().newContext({ ignoreHTTPSErrors: true });
    await ctx3.addInitScript(([t, u]) => {
      try { localStorage.setItem('bm_token', t); localStorage.setItem('bm_user', u); } catch (e) {}
    }, [fx.atok, JSON.stringify(fx.admin)]);
    const page2 = await ctx3.newPage();
    const errs2 = [];
    page2.on('pageerror', e => errs2.push(String(e) + '\n' + (e.stack || '')));
    page2.on('dialog', d => d.accept());
    await page2.goto(BASE + '/admin', { waitUntil: 'domcontentloaded' });
    await page2.waitForTimeout(2500);
    await page2.evaluate(() => switchSec('share'));
    await page2.waitForTimeout(2500);

    const row = await page2.evaluate((rid) => {
      const chk = document.querySelector('#share-list .share-chk[value="' + rid + '"]');
      if (!chk) return null;
      const item = chk.closest('.list-item');
      const badge = item.querySelector('.badge[title]');
      return { has: true, badge: badge ? badge.textContent.trim() : '',
               tip: badge ? badge.getAttribute('title') : '' };
    }, String(fx.rid));
    ck('后台列表里有我造的申请', !!(row && row.has));
    ck('该条目带「书库已有同名 N 本」徽标', !!(row && /书库已有同名/.test(row.badge)), row && row.badge);
    ck('徽标悬停能列出具体书名', !!(row && row.tip.indexOf(fx.core) >= 0), row && row.tip);

    // 勾选 → 点拒绝 → 弹窗里应有「书库中已存在同名电子书」预设
    await page2.evaluate((rid) => {
      document.querySelectorAll('.share-chk').forEach(c => { c.checked = (c.value === String(rid)); });
      updShareSel();
    }, fx.rid);
    await page2.evaluate(() => handleShareRequests('reject'));
    await page2.waitForTimeout(1000);
    const presets = await page2.evaluate(() => [...document.querySelectorAll('.chips .chip[data-rj]')]
      .map(b => b.textContent.trim()));
    ck('拒绝弹窗里有「书库中已存在同名电子书」按钮',
      presets.some(t => t.indexOf('书库中已存在同名电子书') >= 0), JSON.stringify(presets));

    if (presets.length) {
      await page2.evaluate(() => pickRejectReason(0));
      await page2.waitForTimeout(500);
      const val = await page2.evaluate(() => (document.getElementById('admin-rj') || {}).value || '');
      const note = await page2.evaluate(() => (document.getElementById('admin-rj-note') || {}).textContent || '');
      ck('点按钮后理由被填入输入框', val === '书库中已存在同名电子书', val);
      ck('下方说明了对应的是书库哪本书', note.indexOf(fx.core) >= 0, note);
      ck('胶囊点了会高亮（看得出选了哪个）',
        await page2.evaluate(() => { const b = document.querySelector('.chip[data-rj]'); return !!b && b.classList.contains('active'); }));
    }
    // 关键：取消，绝不真的驳回
    await page2.evaluate(() => closeModal());
    await page2.waitForTimeout(500);
    const stillPending = py(`
import sys
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
import db
r = db.q("SELECT status FROM share_requests WHERE id=?", (${fx.rid},), one=True)
print(r['status'] if r else 'gone')
`);
    ck('界面测试没有真的驳回申请（仍是 pending）', stillPending === 'pending', stillPending);

    ck('用户侧无 JS 报错', uerrs.length === 0, uerrs.slice(0, 2).join(' | '));
    if (errs2.length) console.log('\n  --- 后台 JS 报错堆栈 ---\n' + errs2.join('\n'));
    ck('后台侧无 JS 报错', errs2.length === 0, errs2.slice(0, 2).join(' | '));
  } finally {
    if (browser) await browser.close();
    py(CLEANUP({ rid: fx.rid, mine: fx.mine, other: fx.other,
                      sysmid: fx.sysmid, usermid: fx.usermid }));
    console.log('  已按 id 精确清理测试数据');
  }

  console.log('\n  ===== 通过 ' + pass + ' / 失败 ' + fail + ' =====');
  process.exit(fail ? 1 : 0);
})();
