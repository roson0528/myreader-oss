// 「我的」页的账号操作（修改密码 / 后台管理 / 下载APP / 示例天空 / 退出登录）
// 放在页面**顶部**（头像·昵称下面），不再埋在长列表最后一张卡片里
// —— 原来得先滑过消息/阅读/文章/分类/推广/分享/权限一大串才够得着。
//
// 同时校验按钮文案里不再有 🔑 和 ⚙️ 两个 emoji。
//
// 本测试只读，不改任何数据。
const { chromium } = require('playwright-core');
const { execSync } = require('child_process');
const CHROME = '/srv/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome';
const ROOT = '/srv/myreader/book_manager';
const BASE = 'https://127.0.0.1:9000';

let pass = 0, fail = 0;
const ck = (n, ok, extra) => {
  if (ok) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (extra ? '  → ' + extra : '')); }
};
const py = (c) => execSync('venv/bin/python -', { cwd: ROOT, encoding: 'utf8', input: c }).trim();

(async () => {
  // 用管理员账号（uid=15），这样「后台管理」按钮是可见的，能一起验
  const info = JSON.parse(py(`
import sys, json
sys.path.insert(0, '${ROOT}')
import db, auth
u = db.q("SELECT * FROM users WHERE id=15 AND enabled=1", one=True)
print(json.dumps({"tok": auth.create_token(u), "user": dict(u)}))`));

  const b = await chromium.launch({ executablePath: CHROME, args: ['--no-sandbox'] });
  const probe = async (w, h) => {
    const ctx = await b.newContext({ ignoreHTTPSErrors: true, viewport: { width: w, height: h } });
    await ctx.addInitScript(([t, u]) => {
      localStorage.setItem('bm_token', t); localStorage.setItem('bm_user', u);
    }, [info.tok, JSON.stringify(info.user)]);
    const page = await ctx.newPage();
    const errs = [];
    page.on('pageerror', e => errs.push(String(e).slice(0, 90)));
    await page.goto(BASE + '/', { waitUntil: 'domcontentloaded' });
    await page.waitForFunction(() => typeof switchPage === 'function', null, { timeout: 20000 });
    await page.evaluate(() => switchPage('me'));
    await page.waitForTimeout(2000);
    const r = await page.evaluate(() => {
      const pageEl = document.getElementById('page-me');
      const head = pageEl.querySelector('.me-head');
      const act = pageEl.querySelector('.me-actions');
      const msg = document.getElementById('me-msg-card');
      if (!act) return { missing: true };
      const before = (a, b2) => (a.compareDocumentPosition(b2) & Node.DOCUMENT_POSITION_FOLLOWING) ? true : false;
      const last = pageEl.lastElementChild;
      const btns = Array.from(act.querySelectorAll('.btn'));
      // 整个「我的」页里不该再有 🔑 / ⚙️
      const bad = [];
      pageEl.querySelectorAll('button').forEach(x => {
        if (/[\u{1F511}\u{2699}\u{FE0F}]/u.test(x.textContent)) bad.push(x.textContent.trim());
      });
      return {
        missing: false,
        headBeforeAct: before(head, act),
        actBeforeMsg: msg ? before(act, msg) : false,
        isLast: last === act,
        lastClass: String(last.className),
        visible: btns.filter(x => x.offsetParent !== null).map(x => x.textContent.trim()),
        all: btns.map(x => x.textContent.trim()),
        // 等宽网格：同一次渲染里所有可见按钮宽度必须一致（排版整齐的关键）
        widths: [...new Set(btns.filter(x => x.offsetParent !== null).map(x => Math.round(x.offsetWidth)))],
        rows: [...new Set(btns.filter(x => x.offsetParent !== null).map(x => Math.round(x.getBoundingClientRect().top)))].length,
        // 每一行各有几个按钮（按上边距分组）：用来验「每行 2 个」而不是验行数
        rowSizes: Object.values(btns.filter(x => x.offsetParent !== null).reduce((m, x) => {
          const t = Math.round(x.getBoundingClientRect().top);
          (m[t] = m[t] || []).push(x.textContent.trim()); return m;
        }, {})).map(a => a.length),
        actH: act.offsetHeight,
        // 底部导航是否可见 —— 本项目里它才是「App / 移动 Web」的唯一硬标志
        tabbarOn: (() => { const t = document.getElementById('tabbar'); return !!t && getComputedStyle(t).display !== 'none'; })(),
        topOffset: Math.round(act.getBoundingClientRect().top - pageEl.getBoundingClientRect().top),
        bad,
      };
    });
    await ctx.close();
    return { r, errs };
  };

  const p1 = await probe(420, 900);
  const r = p1.r;
  ck('「我的」页里有账号操作卡片', !r.missing);
  ck('★ 位置在头像/昵称下面', r.headBeforeAct === true);
  ck('★ 位置在「我的消息」卡片**上面**（即页面顶部）', r.actBeforeMsg === true);
  ck('★ 不再是页面最后一张卡片', r.isLast === false, '最后一张是 <' + r.lastClass + '>');
  ck('卡片确实落在页面靠上的位置（<200px）', r.topOffset >= 0 && r.topOffset < 200, r.topOffset + 'px');

  const vis = r.visible.join('|');
  for (const label of ['修改密码', '后台管理', '下载APP', '示例天空', '退出登录']) {
    ck('顶部有「' + label + '」按钮', vis.indexOf(label) >= 0, vis);
  }
  ck('★ 按钮文案里已无 🔑 / ⚙️',
     !r.all.some(x => /修改密码/.test(x) && /🔑/.test(x)) && !r.all.some(x => /后台管理/.test(x) && /⚙/.test(x)),
     JSON.stringify(r.all));
  ck('★ 整个「我的」页都不再有 🔑 / ⚙️', r.bad.length === 0, JSON.stringify(r.bad));
  ck('「修改密码」文案只有四个字（emoji 确已去掉）',
     r.all.indexOf('修改密码') >= 0, JSON.stringify(r.all));
  ck('「后台管理」文案只有四个字', r.all.indexOf('后台管理') >= 0, JSON.stringify(r.all));
  ck('★ 同一行里按钮等宽（排版整齐，不因字数多少参差）',
     r.widths.length === 1, '宽度 ' + JSON.stringify(r.widths) + 'px');
  // ★ 这里断言的是「**每行 2 个**」，不是「几行」。
  //   原来是「手机端排成 2 行以内」—— 那是 auto-fit 一行能排 3 个时的口径。
  //   2026-10-11 业主明确要求改成每行 2 个，那么管理员账号（多一个「后台管理」，
  //   共 5 个）必然是 2+2+1 三行 —— 继续断言「≤2 行」就成了**和需求对着干**的旧断言。
  //   换成盯每行的按钮个数：除最后一行外都应该是 2 个。
  ck('★ 手机端每行 2 个按钮（末行可不满）',
     r.rowSizes.length > 0 && r.rowSizes.every((n, i) => i === r.rowSizes.length - 1 ? n <= 2 : n === 2),
     JSON.stringify(r.rowSizes));
  // 高度上限随行数放宽：3 行 × 36px + 2 个 7px 间距 + 卡片内边距 ≈ 147px。
  // 这条挡的是「别失控地高」，不是要求它必须 2 行那么高。
  ck('整块高度克制（≤160px，首屏不抢头像和消息的位置）',
     r.actH > 0 && r.actH <= 160, r.actH + 'px');
  ck('页面没有 JS 报错', p1.errs.length === 0, p1.errs[0] || '');

  // 桌面端同样是顶部
  const p2 = await probe(1280, 900);
  ck('桌面端也在顶部（消息卡片之前）', p2.r.actBeforeMsg === true && p2.r.isLast === false);
  ck('桌面端按钮摊开撑满一行且等宽',
     p2.r.widths.length === 1 && p2.r.rows === 1,
     '宽度 ' + JSON.stringify(p2.r.widths) + 'px，' + p2.r.rows + ' 行');

  // ★ 断点必须和底部导航（.tabbar）**一致**：底部导航在 ≤820px 显示，
  //   那是本项目里「App / 移动 Web」的唯一硬标志。用别的值会出现
  //   「底部导航已经出来了、按钮还是一行仨」这种半移动状态。
  const p3 = await probe(820, 900);
  ck('★ 820px（底部导航出现的临界宽度）底部导航确实已显示', p3.r.tabbarOn === true);
  ck('★ 820px 按钮也已经是每行 2 个（断点与底部导航一致）',
     p3.r.rowSizes.length > 0 &&
     p3.r.rowSizes.every((n, i) => i === p3.r.rowSizes.length - 1 ? n <= 2 : n === 2),
     JSON.stringify(p3.r.rowSizes));

  await b.close();
  console.log(`\n「我的」页顶部操作按钮：${pass} 通过 / ${fail} 失败`);
  process.exit(fail ? 1 : 0);
})();
