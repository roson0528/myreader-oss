/* 极简阅读页 /lite —— 老设备（第七代 Kindle 等）兼容
 *
 * 背景：/reader 的 reader.js 用了箭头函数、模板字符串、async/await、const 与 fetch，
 * 第七代 Kindle 的老 WebKit（约 Safari 5 时代）连脚本都解析不了，整页直接废掉。
 * /lite 是服务端渲染的另一份阅读页：纯 HTML + 纯 CSS1/2 + **零 JavaScript**，
 * 登录用普通 <form> POST + cookie，翻章/调字号全是 <a> 链接。
 *
 * ★ 这个测试的核心手段是 **javaScriptEnabled: false** —— 页面里一行 JS 都不许跑，
 *   连 Playwright 注入的页面脚本都没有（它自己的协议层查询不受影响）。
 *   能在这条限制下把书读完，就能在老 Kindle 上读完 —— 这是拿不到真机时
 *   最接近的等价验证。另外再用「把 fetch/Promise 删掉」来验证自动跳转分支。
 *
 * 跑法：NODE_PATH=/tmp/pwtest/node_modules node tests/test_lite_reader.js
 */
const { chromium } = require('playwright-core');
const { execSync } = require('child_process');
const fs = require('fs');
const CHROME = '/srv/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome';
const ROOT = '/srv/myreader/book_manager';
const BASE = 'https://127.0.0.1:9000';
const TXT_BOOK = 6;      // txt 书
const EPUB_BOOK = 31;    // epub 书
const USER = 'test', PASS = 'test';

let pass = 0, fail = 0;
const ok = (c, m) => { if (c) { pass++; console.log('  ✓ ' + m); } else { fail++; console.log('  ✗ ' + m); } };
const py = code => execSync('venv/bin/python -c "' + code.replace(/"/g, '\\"') + '"',
  { cwd: ROOT, encoding: 'utf8' }).trim();
// 读某个账号存的极简页排版设置（空表示没设过、走默认）
const readFmt = who => JSON.parse(py(
  `import sys, json; sys.path.insert(0, '${ROOT}'); import db
r = db.q("SELECT s.lite_fmt FROM settings s JOIN users u ON u.id=s.user_id WHERE u.username='${who}'", one=True)
raw = (r["lite_fmt"] if r else "") or ""
print(json.dumps(json.loads(raw) if raw else {}))`));

// 用测试账号的令牌读现代端进度接口（等价于手机上打开阅读器时读到的东西）
const readProg = bid => JSON.parse(py(
  `import sys, json; sys.path.insert(0, '${ROOT}'); import db, auth, urllib.request, ssl
u = db.q("SELECT * FROM users WHERE username='${USER}'", one=True)
t = auth.create_token(u)
ctx = ssl._create_unverified_context()
req = urllib.request.Request("https://127.0.0.1:9000/api/books/${bid}/progress", headers={"Authorization": "Bearer " + t})
print(json.dumps(json.loads(urllib.request.urlopen(req, context=ctx, timeout=20).read().decode())))`));

// 直接改测试账号的 lite_fmt（用于验证「每屏字数」这条服务端老路子 —— 预设会取代它）
// ★ 必须走临时文件：JSON 里的引号经「shell → python -c」两层转义后必然失真。
//   这个坑本文件末尾的还原段注释里就写过，我在这里又踩了一次 —— 症状是库里存进
//   一段 {f\:\Kaiti SC... 的坏 JSON，页面回落默认值，cp 改了却看不出变化。
const writeFmt = obj => {
  const f = '/tmp/lite_fmt_write.json';
  fs.writeFileSync(f, JSON.stringify(obj));
  return py(`import sys, json; sys.path.insert(0, '${ROOT}'); import db
v = json.load(open('${f}', encoding='utf-8'))
db.ex("INSERT INTO settings (user_id, lite_fmt) VALUES (?,?) "
      "ON CONFLICT(user_id) DO UPDATE SET lite_fmt=excluded.lite_fmt",
      (${info.uid}, json.dumps(v, ensure_ascii=False)))
r = db.q("SELECT lite_fmt FROM settings WHERE user_id=?", (${info.uid},), one=True)
print(r["lite_fmt"])`);
};

// ★ 章节页现在**不再显示「第 k/N 屏」**了（站长要求整页只留一行导航 + 正文），
//   所以「现在是第几屏 / 是不是同一屏」改用**正文指纹**判断：去掉导航后取正文前 120 字。
//   这比读一个页码显示更硬 —— 它验证的是「看到的内容」，而不是页面上的一个数字。
const digest = html => {
  const body = (/<body[^>]*>([\s\S]*)<\/body>/.exec(html) || ['', html])[1];
  return body.replace(/<div class="nav">[\s\S]*?<\/div>/, '')
             .replace(/<table class="nav">[\s\S]*?<\/table>/, '')
             .replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 120);
};

// ★ 断言「页面上没有 xxx」时，一定要先切掉 <style> —— CSS 注释里本来就会写
//   「层级改用字号/下划线/边框表达」「上一屏 下一屏 | 首页 目录 | …」这类说明文字，
//   直接对整页 indexOf 会被自己的注释绊倒（这个坑犯过两次）。
const vis = html => html.slice(html.indexOf('</style>'));

const info = JSON.parse(execSync('venv/bin/python -', {
  cwd: ROOT, encoding: 'utf8',
  input: `import sys, json
sys.path.insert(0, '${ROOT}')
import db, auth
u = db.q("SELECT * FROM users WHERE username='${USER}' AND enabled=1 LIMIT 1", one=True)
priv = db.q("SELECT id FROM books WHERE owner_id IS NOT NULL AND COALESCE(hidden,0)=0 LIMIT 1", one=True)
# 找一本「测试账号看不到的书」（私人书且没授权给他）—— 书架里放一本，验证不会出现死链
invis = None
for _b in db.q("SELECT * FROM books WHERE owner_id IS NOT NULL AND COALESCE(hidden,0)=0 LIMIT 60", one=False):
    if not auth.can_access_book(u, _b):
        invis = _b["id"]
        break
rows = db.q("SELECT book_id, position, percent, updated_at FROM progress WHERE user_id=?", (u["id"],), one=False)
print(json.dumps({"token": auth.create_token(u), "uid": u["id"],
                  "private_book": (priv["id"] if priv else None),
                  "invis_book": invis,
                  "disp": u["name"] or u["username"],
                  "fmt": ((db.q("SELECT lite_fmt FROM settings WHERE user_id=?", (u["id"],), one=True) or {"lite_fmt": ""})["lite_fmt"] or ""),
                  "admin_fmt": ((db.q("SELECT s.lite_fmt FROM settings s JOIN users u ON u.id=s.user_id WHERE u.role='admin' ORDER BY u.id LIMIT 1", one=True) or {"lite_fmt": ""})["lite_fmt"] or ""),
                  "progress": [dict(r) for r in rows]}))
`}).trim());

(async () => {
  const b = await chromium.launch({ executablePath: CHROME, args: ['--no-sandbox'] });

  // ============ 第一部分：完全禁用 JS 的「老设备」 ============
  const ctx = await b.newContext({ ignoreHTTPSErrors: true, viewport: { width: 600, height: 800 },
    javaScriptEnabled: false });
  const p = await ctx.newPage();
  const errs = [];
  p.on('pageerror', e => errs.push(String(e)));

  // ---- 未登录：给的是登录表单，不是白屏 ----
  await p.goto(BASE + '/lite', { waitUntil: 'domcontentloaded' });
  let html = await p.content();
  ok(html.indexOf('用户名') >= 0 && html.indexOf('type="password"') >= 0,
    '未登录访问 /lite：首页上直接就有账号密码表单（无 JS 也能登录）');
  ok(html.indexOf('范例图书') >= 0 && html.indexOf('书库') >= 0,
    '未登录时首页给出登录表单 + 「访客可见范例图书」的说明，不是空白');

  // ---- 老引擎体检：这一页不许出现任何现代 CSS/JS ----
  const modern = [['<script', '任何脚本'], ['display:flex', 'flex 布局'], ['display: grid', 'grid 布局'],
    ['var(--', 'CSS 变量'], ['column-', '多栏分页'], ['=>', '箭头函数'], ['const ', 'const'],
    ['fetch(', 'fetch'], ['transition', 'CSS 过渡']];
  const bad = modern.filter(([k]) => html.indexOf(k) >= 0).map(([, n]) => n);
  ok(bad.length === 0, '页面里没有任何现代 CSS/JS 特性（' + (bad.length ? '发现: ' + bad.join('/') : '逐个查过 9 项全无') + '）');

  // ---- 无 JS 登录（真表单提交） ----
  await p.goto(BASE + '/lite/login', { waitUntil: 'domcontentloaded' });
  await p.fill('input[name=username]', USER);
  await p.fill('input[name=password]', PASS);
  await Promise.all([p.waitForLoadState('domcontentloaded'), p.click('input[type=submit]')]);
  html = await p.content();
  ok(p.url().indexOf('/lite') >= 0 && html.indexOf('书库') >= 0,
    '无 JS 表单登录成功并跳到书架（' + p.url().replace(BASE, '') + '）');
  const cookie = (await ctx.cookies()).find(c => c.name === 'bm_lite');
  ok(!!cookie && cookie.httpOnly, '登录态落在一个 HttpOnly 的 bm_lite cookie 上');
  ok(html.indexOf('退出') >= 0 && html.indexOf(info.disp) >= 0,
    '书架顶部显示了当前账号（' + info.disp + '）与退出入口');

  // ---- 书架：搜到书、点进目录 ----
  await p.goto(BASE + '/lite/book/' + TXT_BOOK, { waitUntil: 'domcontentloaded' });
  html = await p.content();
  ok(html.indexOf('目录') >= 0 && html.indexOf('/lite/book/' + TXT_BOOK + '/ch/0') >= 0,
    '书的目录页列出了章节链接');

  // ---- 章节正文：纯文本真的渲染出来了 ----
  await p.goto(BASE + '/lite/book/' + TXT_BOOK + '/ch/0', { waitUntil: 'domcontentloaded' });
  const body1 = await p.innerText('body');
  html = await p.content();
  ok(html.indexOf('class="t"') >= 0 && body1.length > 300,
    'txt 章节正文渲染出来了（' + body1.length + ' 字）');
  // ★ 这本 txt 没有分章标记，会被切成 1 块 —— 单块书本来就不该有「下一章」，
  //   所以这里只断言必定存在的「首页/目录」导航，翻章留到 20 章的 epub 上测。
  //   ★ 站长要求这一页只留一行导航：书名/章名/第几章/第几屏/字号按钮/进度提示/页脚
  //     统统删掉，所以这里顺带把「删干净了」也断言上。
  ok(html.indexOf('class="nav"') >= 0 && html.indexOf('>首页</a>') >= 0 &&
     html.indexOf('>目录</a>') >= 0,
    '正文页只有一行导航（首页 / 目录 / 翻屏）');
  ok(html.indexOf('<h1') < 0 && html.indexOf('class="meta"') < 0 &&
     html.indexOf('顶部') < 0 && html.indexOf('第 1/') < 0,
    '正文页不再有书名/章名/「第 x/y 章·第 x/y 屏」/「顶部」（正文自带的 <h1> 不算）');

  // ============ 墨水屏可读性：这一页只许用纯黑与纯白 ============
  // 站长反馈「lite 页面在 kindle 上显示不清楚」。接口一查：原来是「暖纸风」配色 ——
  // 米色底 #f0ebe3、深灰字 #222、蓝链接 #1a4b8c、灰辅助字 #666/#888/#8a8375、
  // 浅色虚线边框。LCD 上好看，**墨水屏上全是坑**：墨水屏只有全黑/全白两级，中间色
  // 会被固件用抖动网点去凑 → 远看发灰、近看有噪点残影。故本页只用 #000 与 #fff，
  // 层级改靠字号/下划线/边框。下面这条扫描就是防止以后又混进中间色。
  const styleCss = (/<style>([\s\S]*?)<\/style>/.exec(html) || ['', ''])[1];
  const hexes = (styleCss.match(/#[0-9a-fA-F]{3,6}/g) || []).map(x => x.toLowerCase());
  const badHex = hexes.filter(x => x !== '#000' && x !== '#fff');
  ok(hexes.length >= 2 && badHex.length === 0,
    'CSS 只用纯黑/纯白（共 ' + hexes.length + ' 处颜色，越界的：' + JSON.stringify(badHex) + '）');
  ok(/background:#fff/.test(styleCss) && /color:#000/.test(styleCss),
    '正文是纯黑字 + 纯白底（墨水屏最高对比、且不触发抖动网点）');
  ok(/a \{ color:#000; text-decoration:underline/.test(styleCss),
    '链接靠「纯黑 + 下划线」区分，不靠颜色（蓝色在墨水屏上会被抖成灰）');
  ok(/-webkit-text-size-adjust:100%/.test(styleCss),
    '声明 -webkit-text-size-adjust:100%：老 WebKit 不会自作主张改正文大小');
  ok(/font-family:sans-serif/.test(styleCss),
    '默认字体是无衬线（黑体）—— 墨水屏上宋体的细横画最容易糊');
  ok(html.indexOf('<meta name="viewport" content="width=device-width, initial-scale=1">') >= 0,
    '页面声明了 viewport=device-width（老移动浏览器缺它就会按 ~980px 排版再缩小，字变糊）');

  // 再用**浏览器自己的样式引擎**复核一遍实际生效值（走 CDP，不是页面脚本）
  const cdpStyle = await ctx.newCDPSession(p);
  await cdpStyle.send('DOM.enable');
  await cdpStyle.send('CSS.enable');
  const domRoot = await cdpStyle.send('DOM.getDocument', { depth: -1 });
  const computedOf = async sel => {
    const n = (await cdpStyle.send('DOM.querySelector',
      { nodeId: domRoot.root.nodeId, selector: sel })).nodeId;
    const cs = (await cdpStyle.send('CSS.getComputedStyleForNode', { nodeId: n })).computedStyle;
    return { get: k => (cs.find(x => x.name === k) || {}).value };
  };
  const csBody = await computedOf('body');
  ok(csBody.get('background-color') === 'rgb(255, 255, 255)' &&
     csBody.get('color') === 'rgb(0, 0, 0)',
    '样式引擎算出来的实际值同样是纯黑字/纯白底（' + csBody.get('color') + ' on ' +
    csBody.get('background-color') + '）');
  const csText = await computedOf('pre.t');
  ok((csText.get('font-family') || '').indexOf('sans-serif') >= 0 &&
     csText.get('color') === 'rgb(0, 0, 0)',
    '正文实际字体为无衬线、颜色为纯黑（' + csText.get('font-family') + '）');

  // ---- epub 也要能读（另一条渲染分支） ----
  await p.goto(BASE + '/lite/book/' + EPUB_BOOK, { waitUntil: 'domcontentloaded' });
  html = await p.content();
  ok(html.indexOf('目录（') >= 0, 'epub 书的目录页正常');
  await p.goto(BASE + '/lite/book/' + EPUB_BOOK + '/ch/1', { waitUntil: 'domcontentloaded' });
  const eb = await p.innerText('body');
  ok(eb.length > 50, 'epub 章节页有内容（' + eb.length + ' 字）');
  html = await p.content();
  ok(html.indexOf('下一屏') >= 0, 'epub 章节页（第 1 屏）有「下一屏」链接');

  // ---- ★ epub 正文里的「同书互链」不能在极简页上留成相对链接 ----
  //   书 #31 的第 0 章就是它自带的目录页（OEBPS/catalog.xhtml），里面链到 chap0.xhtml。
  //   相对链接在 /lite/book/31/ch/0 这个地址下会被解析成 /lite/book/31/ch/chap0.xhtml，
  //   撞上 idx:int 直接 422，页面就糊出一坨 {"detail":[{"type":"int_parsing",...}]}
  //   —— 站长报的原始报错里 input 正是这类 epub 文件名。
  await p.goto(BASE + '/lite/book/' + EPUB_BOOK + '/ch/0?fs=22', { waitUntil: 'domcontentloaded' });
  const catHtml = await p.content();
  const relA = catHtml.match(/<a\b[^>]*href="(?!#|\/|https?:\/\/|data:)[^"]*"/gi) || [];
  ok(relA.length === 0 && catHtml.indexOf('chap0.xhtml') < 0,
    'epub 目录页里没有相对链接了（' + relA.length + ' 个）' + (relA[0] ? ' 例：' + relA[0] : ''));
  ok(catHtml.indexOf('href="/lite/book/' + EPUB_BOOK + '/ch/1?fs=22"') >= 0,
    '正文里链到 chap0.xhtml 的链接被改写成真正的章链接（点得通，不再 422）');

  // ---- 翻到本章最后一屏：那里才该出现「下一章」（先按屏翻，翻到头再按章翻）----
  //     顺带验一下越界的地址会被夹到最后一屏（不会报错、也不会跑出章节）
  await p.goto(BASE + '/lite/book/' + EPUB_BOOK + '/ch/1?off=999999', { waitUntil: 'domcontentloaded' });
  html = await p.content();
  // 页面不显示页码了 → 用「这一屏没有下一屏、只有下一章」来认定它就是最后一屏
  // （第一屏那条已经断言过「有下一屏」，两头一夹就证明夹对了）
  ok(vis(html).indexOf('下一屏') < 0,
    '越界地址被夹到最后一屏（该屏不再有「下一屏」）');
  ok(html.indexOf('下一章') >= 0, '翻到最后一屏才出现「下一章」链接');

  // ---- ★ 导航挪到页面底部 + 左/中/右三列（站长要求：左右手都方便翻页）----
  //   位置：导航必须排在正文**之后**（用它们在 HTML 里的先后顺序判定）
  //   结构：左「上一屏/上一章 + 下一屏/下一章」· 中「首页 目录」· 右与左完全相同
  //   对齐：靠 .nav td.l/.c/.r 的 text-align（静态查 CSS；实际坐标另在文档里记了实测值）
  const navAt = html.indexOf('<table class="nav">');
  const preAt = html.indexOf('<pre class="t">');
  ok(navAt > 0 && (preAt < 0 || navAt > preAt),
    '导航排在正文之后（页面底部），不在顶部');
  const navTbl = (/<table class="nav">[\s\S]*?<\/table>/.exec(html) || [''])[0];
  const tds = [...navTbl.matchAll(/<td class="(\w)">([\s\S]*?)<\/td>/g)]
    .map(m => ({ cls: m[1], txt: m[2].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim() }));
  ok(tds.length === 3 && tds[0].cls === 'l' && tds[1].cls === 'c' && tds[2].cls === 'r',
    '导航是三列（l/c/r）：' + tds.map(t => t.cls).join('/'));
  ok(!!tds[0] && !!tds[2] && tds[0].txt === tds[2].txt && /上一屏|上一章/.test(tds[0].txt) &&
     /下一屏|下一章/.test(tds[0].txt),
    '左右两列内容完全相同（左右手各一组）：' + JSON.stringify(tds[0] && tds[0].txt));
  ok(!!tds[1] && tds[1].txt === '首页 目录',
    '中间一列是「首页 目录」：' + JSON.stringify(tds[1] && tds[1].txt));
  const navCss = (/<style>([\s\S]*?)<\/style>/.exec(html) || ['', ''])[1];
  ok(/\.nav td\.l \{ text-align:left/.test(navCss) && /\.nav td\.c \{ text-align:center/.test(navCss)
     && /\.nav td\.r \{ text-align:right/.test(navCss),
    '三列对齐方式：左贴左、中间居中、右贴右（CSS 静态可查）');

  // ---- 顺链接翻到下一章（模拟老设备点链接，全程零 JS） ----
  await Promise.all([p.waitForLoadState('domcontentloaded'), p.click('text=下一章')]);
  const eb2 = await p.innerText('body');
  ok(p.url().indexOf('/ch/2') >= 0 && eb2.length > 50,
    '点「下一章」真的翻到了第 3 章（' + p.url().replace(BASE, '') + '）');

  // ---- 调字号：纯链接，点了就变 ----
  await p.goto(BASE + '/lite/book/' + TXT_BOOK + '/ch/0?fs=34', { waitUntil: 'domcontentloaded' });
  html = await p.content();
  ok(/<body style="font-size:34px;/.test(html),
    '?fs=34 时正文字号真的变 34px（没有 JS 参与；★ 后面还跟着行距/字体，别把引号写死）');
  const visHtml = vis(html);
  ok(visHtml.indexOf('name="fs"') < 0 && visHtml.indexOf('字号') < 0 &&
     visHtml.indexOf('class="cur"') < 0,
    '章节页不再有「字号：特大」那一块和快捷按钮（站长要求删掉；改字号去书架顶端的下拉框）');

  // ---- 进度：lite 写的进度，现代端接口必须读得到（云端同步的另一半） ----
  const progTxt = readProg(TXT_BOOK), progEp = readProg(EPUB_BOOK);
  ok(progEp.progress && progEp.progress.idx === 2,
    'lite 翻到 epub 第 3 章后，现代端接口读到 idx=2（' + JSON.stringify(progEp.progress && progEp.progress.idx) + '）');
  // ★ 口径变了：分屏之后 lite 知道章内比例，percent 按「(章 + 章内比例)/总章数」算，
  //   与现代阅读器同一口径（老写法按「读到第几章」粗估成 3/20=15%，两边对不上）。
  ok(progEp.percent === 10, 'epub 进度百分比 = (2+0)/20 = 10%（实际 ' + progEp.percent + '%）');
  ok(progTxt.progress && progTxt.progress.idx === 0,
    '单块 txt 书（#6 没有分章）读到 idx=0、percent=' + progTxt.percent + '%（整本一块）');

  // ---- 反向：现代端存的进度，lite 的「继续阅读」要认得 ----
  py(`import sys; sys.path.insert(0, '${ROOT}'); import db, json
db.ex("INSERT INTO progress (user_id,book_id,position,percent,updated_at) VALUES (?,?,?,?,?) "
      "ON CONFLICT(user_id,book_id) DO UPDATE SET position=excluded.position, percent=excluded.percent, updated_at=excluded.updated_at",
      (${info.uid}, ${EPUB_BOOK}, json.dumps({"kind":"epub","mode":"paged","idx":4,"page":0,"scroll":0,"frac":0.5,"dev":"phone"}), 55, db.now()))`);
  await p.goto(BASE + '/lite/book/' + EPUB_BOOK, { waitUntil: 'domcontentloaded' });
  html = await p.content();
  ok(html.indexOf('/lite/book/' + EPUB_BOOK + '/ch/4') >= 0 && html.indexOf('继续阅读') >= 0,
    '现代端存的进度（epub 第 5 章）在 lite 里显示为「继续阅读」，且链接指向第 5 章');
  ok(html.indexOf('55%') >= 0, 'lite 显示的百分比与现代端一致（55%）');

  // ============ 章内定位：按段落边界分屏，每次翻屏服务器都记下地址 ============
  // 需求原文：「屏幕每划过一个段落就记一个独立的地址，服务器保存最后的阅读地址」。
  // 极简页没有 JS，浏览器**不会**上报「他滚到哪儿了」，所以「边划边记」做不到；
  // 改成按段落边界把章节切成「屏」，翻屏就是一次普通链接跳转 —— 每次 GET 服务器都能
  // 记下确切地址（零 JS）。地址存的是**本屏起始字符偏移**（整数）与对应比例：
  // 存「第几屏」不行，字号一变屏的切分就变、屏号整体错位。
  await p.goto(BASE + '/lite/book/' + EPUB_BOOK, { waitUntil: 'domcontentloaded' });
  html = await p.content();
  // ★ page.content() 是浏览器序列化后的 DOM：属性里的 & 会写成 &amp;（curl 看源码才是 &）
  const mPos = /href="\/lite\/book\/\d+\/ch\/4\?fs=\d+(?:&amp;|&)(?:off|fr)=[\d.]+"/.exec(html);
  ok(!!mPos, '续读链接带上了章内地址（' + (mPos ? mPos[0] : '?') + '）');

  // 手机读到本章 50%（只有 frac、没有 off）→ lite 换算成中间那一屏
  await p.goto(BASE + '/lite/book/' + TXT_BOOK + '/ch/0?off=0', { waitUntil: 'domcontentloaded' });
  const firstDigest = digest(await p.content());
  await p.goto(BASE + '/lite/book/' + TXT_BOOK + '/ch/0?fr=0.5', { waitUntil: 'domcontentloaded' });
  const midHtml = await p.content();
  ok(digest(midHtml) !== firstDigest && midHtml.indexOf('上一屏') >= 0 &&
     midHtml.indexOf('下一屏') >= 0,
    '手机读到本章 50% → 打开的就是中间那一屏（正文不是章首那段，且上/下屏都有得翻）');
  const afterMid = readProg(TXT_BOOK);
  ok(Math.abs(afterMid.progress.frac - 0.5) < 0.05 && afterMid.progress.off > 1000,
    'lite 记下的章内位置就在 50% 附近（frac=' + afterMid.progress.frac.toFixed(3) +
    '、off=' + afterMid.progress.off + '），没被拽回章首');

  // ★ 连点三次「下一屏」：每翻一屏，服务器记下的地址都要往前推（本次需求的核心）
  await p.goto(BASE + '/lite/book/' + TXT_BOOK + '/ch/0', { waitUntil: 'domcontentloaded' });
  const trace = [];
  let pageHtml = await p.content();
  for (let i = 0; i < 3; i++) {
    const nx = /href="\/lite\/book\/\d+\/ch\/0\?fs=\d+(?:&amp;|&)off=(\d+)">下一屏/.exec(pageHtml);
    if (!nx) { break; }
    await p.goto(BASE + '/lite/book/' + TXT_BOOK + '/ch/0?fs=22&off=' + nx[1],
      { waitUntil: 'domcontentloaded' });
    pageHtml = await p.content();
    const pr = readProg(TXT_BOOK).progress;
    trace.push({ off: pr.off, frac: pr.frac, pg: pr.page, dg: digest(pageHtml) });
  }
  ok(trace.length === 3 && trace[2].off > trace[1].off && trace[1].off > trace[0].off &&
     trace[2].frac > trace[1].frac && trace[1].frac > trace[0].frac,
    '连点三次「下一屏」，服务器记的地址一路推进：' +
    trace.map(t => 'off=' + t.off).join(' → '));
  ok(new Set(trace.map(t => t.dg)).size === trace.length,
    '每翻一屏看到的正文确实换了一段（三次的正文指纹各不相同）');

  // 存下来的地址真的会被用上：目录页的「继续阅读」直指最后那一屏
  const lastOff = trace[trace.length - 1].off;
  const lastDigest = trace[trace.length - 1].dg;
  await p.goto(BASE + '/lite/book/' + TXT_BOOK, { waitUntil: 'domcontentloaded' });
  const contHtml = await p.content();
  ok(contHtml.indexOf('off=' + lastOff) >= 0 && contHtml.indexOf('继续阅读') >= 0,
    '「继续阅读」直指最后读到的那一屏（off=' + lastOff + '）');
  await Promise.all([p.waitForLoadState('domcontentloaded'), p.click('text=继续阅读')]);
  // ★ 这里绝不能拿 trace 的指纹去比：trace 的几屏都是显式 ?fs=22 取的临时覆盖，
  //   而「继续阅读」用的是**账号里存的字号**（本文件前面保存过 26px）—— 字号一变分屏边界
  //   就变，同一个 off 落在的屏起点可能不同，指纹自然不同（假红过一次）。
  //   真正要验的是两件事：①点下去落到**同一个地址**那一屏；②同一个地址取出来的正文是同一屏。
  const viaCont = await p.content();
  //   ★ 也不能断言「点完存的 off 还是 3698」：字号变了，3698 落在的那一屏起点会更靠前，
  //     服务器按新字号把本屏的真实起点重新记一遍（这正是分屏地址该有的行为）。
  //     真正的不变量是：回到的这一屏**覆盖**刚才读到的 off —— 屏起点 ≤ off < 下一屏起点。
  const afterOff = readProg(TXT_BOOK).progress.off;
  const nx2 = /href="\/lite\/book\/\d+\/ch\/0\?fs=\d+(?:&amp;|&)off=(\d+)">下一屏/.exec(viaCont);
  const afterNext = nx2 ? parseInt(nx2[1], 10) : null;
  ok(afterOff <= lastOff && (afterNext === null || afterNext > lastOff),
    '按「继续阅读」回到的正是刚才那一屏（这一屏是 off=' + afterOff + '…' +
    (afterNext === null ? '章末' : afterNext) + '，读到的 off=' + lastOff + ' 正落在里面）');
  await p.goto(BASE + '/lite/book/' + TXT_BOOK + '/ch/0?fs=22&off=' + lastOff,
    { waitUntil: 'domcontentloaded' });
  ok(digest(await p.content()) === lastDigest,
    '同一个地址再取一次，拿到的正文与翻到那一屏时完全一致（分屏是确定的，不看账号字号）');

  // ★ 站长要求把「上次读到第 N 章：去那里接着读」「本章上次读到第 M 屏」这类提示
  //   （以及外框）全删掉 —— 墨水屏上每多一行就少显示一行正文。这里验「真的没了」。
  await p.goto(BASE + '/lite/book/' + TXT_BOOK + '/ch/0', { waitUntil: 'domcontentloaded' });
  const hintHtml = await p.content();
  ok(hintHtml.indexOf('上次读到') < 0 && hintHtml.indexOf('去那里接着读') < 0 &&
     hintHtml.indexOf('从本章开头读') < 0 && hintHtml.indexOf('class="hint"') < 0,
    '直接打开这一章时不再有「上次读到…」提示框（站内进度照旧存在服务器，只是不显示）');

  // ★ 换字号重新排版后不能把人甩回章首（地址是字符偏移，不是屏号）
  await p.goto(BASE + '/lite/book/' + TXT_BOOK + '/ch/0?off=' + lastOff + '&fs=30',
    { waitUntil: 'domcontentloaded' });
  const offAfter = readProg(TXT_BOOK).progress.off;
  ok(offAfter > 0 && offAfter <= lastOff && lastOff - offAfter < 900,
    '换大字号重新排版后地址仍指向同一段文字（off ' + lastOff + ' → ' + offAfter +
    '），不会被甩回章首');

  // ============ 格式设置：每账号单独存，之后打开的书都按它排版 ============
  await p.goto(BASE + '/lite', { waitUntil: 'domcontentloaded' });
  html = await p.content();
  const iFmt = html.indexOf('/lite/settings'), iRec = html.indexOf('最近在读');
  ok(iFmt >= 0 && iRec >= 0 && iFmt < iRec,
    '格式设置表单就摆在「最近在读」上面（' + iFmt + ' < ' + iRec + '）');
  const fmtBlock = (/<form method="post" action="\/lite\/settings">[\s\S]*?<\/form>/.exec(html) || [''])[0];
  const selNames = (fmtBlock.match(/<select name="(\w+)"/g) || [])
    .map(x => x.replace(/.*name="(\w+)".*/, '$1'));
  ok(selNames.join(',') === 'ff,lh,fs,preset' && fmtBlock.indexOf('value="保存"') >= 0,
    '格式设置就是四个下拉 + 保存按钮，全是普通表单（零 JS）：' + selNames.join('/'));
  // ★ 站长要求：第 4 个下拉由「每屏字数」换成「预设」（预设 = 一台机器的排版档）
  const presetOpts = (/<select name="preset">([\s\S]*?)<\/select>/.exec(fmtBlock) || ['', ''])[1];
  ok(/>自定义<\/option>/.test(presetOpts) && />KPW4<\/option>/.test(presetOpts)
     && />KV<\/option>/.test(presetOpts),
    '第 4 个下拉是「预设」：自定义 / KPW4 / KV（以后按机型往下加）');
  ok(!/<select name="cp">/.test(fmtBlock),
    '「每屏字数」那一列已经从设置行里去掉（不再暴露给用户，服务端默认值仍在）');
  // ★ 站长要求精简：行标签和那两段说明全删掉（Kindle 上每多一行都要多翻一屏）
  ok(!/<(?:h2|p|div)[^>]*>[\s　]*(?:字体|行距|字号|每屏字数)[\s　<]/.test(fmtBlock)
     && html.indexOf('这套设置只属于本账号') < 0
     && html.indexOf('一屏装不满') < 0
     && html.indexOf('格式设置') < 0,
    '设置块里不再有「字体/行距/字号/每屏字数」行标签，也没有那两段说明');
  ok(fmtBlock.indexOf('>黑体</option>') >= 0 && fmtBlock.indexOf('>宋体</option>') >= 0
     && fmtBlock.indexOf('>楷体</option>') >= 0
     && fmtBlock.indexOf('推荐·无衬线') < 0 && fmtBlock.indexOf('衬线）') < 0,
    '字体下拉只写「黑体 / 宋体 / 楷体」，没有括号注释');
  ok(html.indexOf('<option value="39">超大</option>') >= 0,
    '字号多了「超大」档（特大 30 的 130%）');
  await p.goto(BASE + '/lite/book/' + TXT_BOOK + '/ch/0?fs=39', { waitUntil: 'domcontentloaded' });
  ok(/<body style="font-size:39px;/.test(await p.content()),
    '?fs=39 时正文真的是 39px（超大档没被 FS_MAX 夹掉）');
  // ★ 量单屏字数一律显式带 ?fs=，否则会拿「不同字号」的两屏去比（第一版就这么写错了）
  const lenAt = async f => {
    await p.goto(BASE + '/lite/book/' + TXT_BOOK + '/ch/0?fs=' + f, { waitUntil: 'domcontentloaded' });
    return ((/<pre class="t">([\s\S]*?)<\/pre>/.exec(await p.content()) || ['', ''])[1] || '').length;
  };
  const stdPageLen = await lenAt(22);
  ok(stdPageLen > 1150 && stdPageLen < 1350,
    '22px 单屏 ' + stdPageLen + ' 字（按站长给的标定点重标定后的基准，原线性算法给 900 字）');

  // ★★ 每屏字数必须按「平方反比」缩放：每行字数 ∝ 1/字号、每屏行数也 ∝ 1/字号，
  //    所以每屏字数 ∝ 1/字号²。第一版写成线性（1/字号），在 30px 处刚好蒙对，
  //    字号一大就给多了 —— 这正是站长看到的「超大超过一屏」。
  const l30 = await lenAt(30), l39 = await lenAt(39);
  ok(l39 / l30 < 0.68,
    '字号越大每屏字数越少、且按平方反比（30px ' + l30 + ' 字 → 39px ' + l39 +
    ' 字，比值 ' + (l39 / l30).toFixed(2) + '；线性缩放会是 0.77）');
  ok(l39 > 320 && l39 < 470,
    '「超大」单屏落回一屏（39px 现在 ' + l39 + ' 字，原来 592 字，少 ' +
    Math.round((1 - l39 / 592) * 100) + '%）');
  ok(l30 > 700 && l30 < 790,
    '「特大 30px」单屏字数没被这次改动影响（' + l30 + ' 字，与站长说的「刚好占满一屏」一致）');
  // 下面要走首页的设置表单，先把页面挪回去
  await p.goto(BASE + '/lite', { waitUntil: 'domcontentloaded' });

  // ★ 走真实的表单提交（不是直接打接口），这才是老设备上的操作路径
  const cpBefore = readFmt(USER).cp;
  await p.selectOption('select[name=ff]', { label: '楷体' });
  await p.selectOption('select[name=lh]', '2');
  await p.selectOption('select[name=fs]', '26');
  await p.selectOption('select[name=preset]', '');     // 显式选「自定义」
  await Promise.all([p.waitForLoadState('domcontentloaded'), p.click('input[value="保存"]')]);
  html = await p.content();
  const fmtKai = readFmt(USER);
  ok(p.url().indexOf('/lite') >= 0 && html.indexOf('已保存') >= 0,
    '保存后回到书架并提示「已保存」');
  ok(fmtKai.ff === "'Kaiti SC','KaiTi',serif" && fmtKai.lh === 2 && fmtKai.fs === 26 &&
     fmtKai.preset === '' && fmtKai.cp === cpBefore,
    '四项设置按账号落库，且没顺手改掉每屏字数（' + JSON.stringify(fmtKai) + '）');

  // ---- 之后打开的电子书按新格式排版 ----
  await p.goto(BASE + '/lite/book/' + TXT_BOOK + '/ch/0', { waitUntil: 'domcontentloaded' });
  html = await p.content();
  ok(/<body style="font-size:26px; line-height:2\.00; font-family:'Kaiti SC','KaiTi',serif"/.test(html),
    '再打开的章节就用上了保存的字体/行距/字号（楷体/宽松/大）');
  ok(html.indexOf('class="cur"') < 0 && html.indexOf('input[value="特大"]') < 0,
    '章节页不再有字号快捷按钮（站长要求删掉；改字号走书架顶端那四个下拉框）');
  // 每屏字数档位真的在生效：同样在 22px 下，宽松 1500 应比标准 1230 明显多。
  // ★ 表单里已经没有 cp 了（被预设取代），所以这条只能直接改库来验 —— 它是
  //   「没选预设」时的默认分屏依据，不能因为界面上看不到了就当它不存在。
  const cpStd = readFmt(USER).cp;
  writeFmt({ ...readFmt(USER), cp: 1500 });
  await p.goto(BASE + '/lite/book/' + TXT_BOOK + '/ch/0?fs=22', { waitUntil: 'domcontentloaded' });
  const bigPageLen = (/<pre class="t">([\s\S]*?)<\/pre>/.exec(await p.content()) || ['', ''])[1].length;
  ok(bigPageLen > stdPageLen + 200,
    '「每屏字数」档位真的生效（标准 ' + cpStd + ' 时 ' + stdPageLen + ' 字 → 宽松 1500 时 ' +
    bigPageLen + ' 字）');
  writeFmt({ ...readFmt(USER), cp: cpStd });

  // ---- ?fs= 只是本次临时覆盖，不写账号 ----
  await p.goto(BASE + '/lite/book/' + TXT_BOOK + '/ch/0?fs=18', { waitUntil: 'domcontentloaded' });
  html = await p.content();
  const fsSaved = readFmt(USER).fs;
  ok(/font-size:18px/.test(html) && fsSaved === 26,
    '?fs=18 只影响本次显示（18px），账号里存的仍是 ' + fsSaved + '（书店里保存的那个字号）');

  // ---- 别的账号不受影响 ----
  const admBefore = info.admin_fmt ? JSON.parse(info.admin_fmt) : {};
  ok(JSON.stringify(readFmt('admin')) === JSON.stringify(admBefore),
    '改测试账号的格式没有动到别人的账号（admin 仍是 ' + JSON.stringify(readFmt('admin')) + '）');
  const adminProbe = JSON.parse(py(
    `import sys, json, ssl, urllib.request; sys.path.insert(0, '${ROOT}'); import db, auth
u = db.q("SELECT * FROM users WHERE role='admin' AND enabled=1 ORDER BY id LIMIT 1", one=True)
t = auth.create_token(u)
req = urllib.request.Request("https://127.0.0.1:9000/lite/book/${TXT_BOOK}/ch/0",
                             headers={"Authorization": "Bearer " + t})
h = urllib.request.urlopen(req, context=ssl._create_unverified_context(), timeout=20).read().decode()
import re
print(json.dumps(re.findall(r'<body style="([^"]*)"', h)[:1]))`));
  ok(adminProbe[0] === 'font-size:22px; line-height:1.75; font-family:sans-serif',
    'admin 打开同一章仍是默认排版（' + adminProbe[0] + '）');

  // ---- 换一个浏览器重新登录，设置照样生效（存在账号上，不是 cookie 里）----
  const ctx4 = await b.newContext({ ignoreHTTPSErrors: true, javaScriptEnabled: false,
    viewport: { width: 600, height: 800 } });
  const p4 = await ctx4.newPage();
  await p4.goto(BASE + '/lite/login', { waitUntil: 'domcontentloaded' });
  await p4.fill('input[name=username]', USER);
  await p4.fill('input[name=password]', PASS);
  await Promise.all([p4.waitForLoadState('domcontentloaded'), p4.click('input[type=submit]')]);
  await p4.goto(BASE + '/lite/book/' + TXT_BOOK + '/ch/0', { waitUntil: 'domcontentloaded' });
  // ★ 按库里实际存的值断言（写死字号会在改了档位之后莫名其妙地红）
  const fmtNow = readFmt(USER);
  const p4html = await p4.content();
  ok(p4html.indexOf('font-size:' + fmtNow.fs + 'px; line-height:' +
       fmtNow.lh.toFixed(2)) >= 0 && p4html.indexOf("'Kaiti SC'") >= 0,
    '换个浏览器重新登录，排版设置照样生效（存的是 ' + fmtNow.fs + 'px/' + fmtNow.lh +
    '，与库里一致）');
  await ctx4.close();

  // ---- 写要严：非法的设置值直接 400，不写库 ----
  const badFmt = await ctx.request.post(BASE + '/lite/settings',
    { form: { ff: 'evil-font', lh: '2.0', fs: '26', next: '/lite' }, maxRedirects: 0 });
  ok(badFmt.status() === 400 && readFmt(USER).ff === "'Kaiti SC','KaiTi',serif",
    '非法的字体值被拒（HTTP ' + badFmt.status() + '），账号里存的仍是楷体');

  // ---- 读要宽：库里的设置坏了（半截 JSON）也不能让页面打不开，回落默认 ----
  py(`import sys; sys.path.insert(0, '${ROOT}'); import db
db.ex("INSERT INTO settings (user_id, lite_fmt) VALUES (?,?) "
      "ON CONFLICT(user_id) DO UPDATE SET lite_fmt=excluded.lite_fmt", (${info.uid}, '{half'))`);
  await p.goto(BASE + '/lite/book/' + TXT_BOOK + '/ch/0', { waitUntil: 'domcontentloaded' });
  html = await p.content();
  ok(/<body style="font-size:22px; line-height:1\.75; font-family:sans-serif"/.test(html),
    '库里存了半截 JSON 时页面照常打开、回落默认排版（读要宽）');
  await p.goto(BASE + '/lite', { waitUntil: 'domcontentloaded' });
  ok((await p.content()).indexOf('/lite/settings') >= 0, '设置坏掉时首页也照常显示');

  // ============ ★ 设备预设：KPW4 = 一屏 17 行、不用往下滑 ============
  // ★ 先修好库：上面「读要宽」那段**故意**把 lite_fmt 写成半截 JSON 且故意不还原
  //   （它靠「坏设置 → 回落默认排版」来验证容错，还原交给最后的统一还原）。
  //   预设这一段要读库，所以先把设置写成一份干净的默认值。
  writeFmt({ ff: 'sans-serif', lh: 1.75, fs: 22, cp: 1230, preset: '' });
  // 预设 = 一台机器的排版档：选中时自动设好字体/行距/字号，并让章节页按「一屏 N 行」分屏。
  // 下面先把三个下拉**故意选成别的值**再选 KPW4 —— 验证「启用预设会自动盖掉它们」。
  await p.goto(BASE + '/lite', { waitUntil: 'domcontentloaded' });
  await p.selectOption('select[name=ff]', { label: '宋体' });
  await p.selectOption('select[name=lh]', '2.3');
  await p.selectOption('select[name=fs]', '30');
  await p.selectOption('select[name=preset]', 'kpw4');
  await Promise.all([p.waitForLoadState('domcontentloaded'), p.click('input[value="保存"]')]);
  const fmtP = readFmt(USER);
  ok(fmtP.preset === 'kpw4' && fmtP.ff === 'sans-serif' && fmtP.lh === 1.5 && fmtP.fs === 22,
    '选中 KPW4 后自动设置为「黑体 + 紧凑 + 中」（哪怕表单里本来选的是宋体/很宽/特大）：' +
    JSON.stringify(fmtP));

  const pset = JSON.parse(py(`import sys, json; sys.path.insert(0, '${ROOT}'); import lite
p = lite._PRESET_BY_KEY['kpw4']
print(json.dumps({"lines": lite._preset_lines(p, 22, 1.5), "cpl": lite._preset_cpl(p, 22),
                  "vw": p["vw"], "vh": p["vh"], "l26": lite._preset_lines(p, 26, 1.5)}))`));
  ok(pset.lines === 17 && pset.cpl === 23,
    'KPW4 的档位：一屏 ' + pset.lines + ' 行 × 每行 ' + pset.cpl + ' 字（= 站长在真机上数的 17 行）');

  // 真跑到 KPW4 那个视口里（536x621）量：文档高度不能超过视口，否则就要往下滑
  const ctxK = await b.newContext({ ignoreHTTPSErrors: true, javaScriptEnabled: false,
    viewport: { width: pset.vw, height: pset.vh } });
  const pk = await ctxK.newPage();
  await pk.goto(BASE + '/lite/login', { waitUntil: 'domcontentloaded' });
  await pk.fill('input[name=username]', USER);
  await pk.fill('input[name=password]', PASS);
  await Promise.all([pk.waitForLoadState('domcontentloaded'), pk.click('input[type=submit]')]);
  for (const [bid, kind] of [[TXT_BOOK, 'txt'], [EPUB_BOOK, 'epub']]) {
    await pk.goto(BASE + '/lite/book/' + bid + '/ch/0', { waitUntil: 'domcontentloaded' });
    const fit = await pk.evaluate(() => {
      const read = document.querySelector('.read');
      const lh = parseFloat(getComputedStyle(document.body).lineHeight);
      return { doc: document.body.scrollHeight, vh: window.innerHeight,
               lines: Math.round(read.getBoundingClientRect().height / lh),
               chars: read.innerText.replace(/\s/g, '').length };
    });
    ok(fit.doc <= fit.vh, '★ ' + kind + ' 在 KPW4 预设下一屏装完、不用往下滑（文档 ' +
      fit.doc + 'px ≤ 视口 ' + fit.vh + 'px，正文 ' + fit.chars + ' 字）');
    ok(fit.lines <= pset.lines && fit.lines >= Math.round(pset.lines * 0.6),
      '★ ' + kind + ' 一屏排了 ' + fit.lines + ' 行（预算 ' + pset.lines +
      ' 行：不超，也不能太空 —— 本机中文字体不是 1em 时会偏短，真机上是满的）');
  }
  await ctxK.close();

  // ============ 设备预设：KV = 黑体 紧凑 超大、一屏 20 行（站长要求）============
  // KV 的视口是按 20 行反推的（39px × 1.5 × 20 行 + 导航装得下），选中它必须
  // 自动套「黑体 + 紧凑 + 超大」，且 39px 下也要一屏装完、不用往下滑。
  await p.goto(BASE + '/lite', { waitUntil: 'domcontentloaded' });
  await p.selectOption('select[name=preset]', 'kv');
  await Promise.all([p.waitForLoadState('domcontentloaded'), p.click('input[value="保存"]')]);
  const fmtKv = readFmt(USER);
  ok(fmtKv.preset === 'kv' && fmtKv.ff === 'sans-serif' && fmtKv.lh === 1.5 && fmtKv.fs === 39,
    '选中 KV 后自动设置为「黑体 + 紧凑 + 超大（39px）」：' + JSON.stringify(fmtKv));

  const psetV = JSON.parse(py(`import sys, json; sys.path.insert(0, '${ROOT}'); import lite
p = lite._PRESET_BY_KEY['kv']
print(json.dumps({"lines": lite._preset_lines(p, 39, 1.5), "cpl": lite._preset_cpl(p, 39),
                  "vw": p["vw"], "vh": p["vh"]}))`));
  ok(psetV.lines === 20 && psetV.cpl === 25,
    'KV 的档位：一屏 ' + psetV.lines + ' 行 × 每行 ' + psetV.cpl + ' 字（站长要的 20 行）');

  const ctxV = await b.newContext({ ignoreHTTPSErrors: true, javaScriptEnabled: false,
    viewport: { width: psetV.vw, height: psetV.vh } });
  const pv = await ctxV.newPage();
  await pv.goto(BASE + '/lite/login', { waitUntil: 'domcontentloaded' });
  await pv.fill('input[name=username]', USER);
  await pv.fill('input[name=password]', PASS);
  await Promise.all([pv.waitForLoadState('domcontentloaded'), pv.click('input[type=submit]')]);
  for (const [bid, kind] of [[TXT_BOOK, 'txt'], [EPUB_BOOK, 'epub']]) {
    await pv.goto(BASE + '/lite/book/' + bid + '/ch/0', { waitUntil: 'domcontentloaded' });
    const fitV = await pv.evaluate(() => {
      const read = document.querySelector('.read');
      const lh = parseFloat(getComputedStyle(document.body).lineHeight);
      return { doc: document.body.scrollHeight, vh: window.innerHeight,
               lines: Math.round(read.getBoundingClientRect().height / lh) };
    });
    ok(fitV.doc <= fitV.vh, '★ ' + kind + ' 在 KV 预设（39px 超大）下一屏装完（文档 ' +
      fitV.doc + 'px ≤ 视口 ' + fitV.vh + 'px）');
    ok(fitV.lines <= psetV.lines && fitV.lines >= Math.round(psetV.lines * 0.6),
      '★ ' + kind + ' 一屏排了 ' + fitV.lines + ' 行（预算 ' + psetV.lines +
      ' 行：不超、也不太空 —— 本机中文字体不是 1em 时会偏短，真机上是满的）');
  }
  await ctxV.close();

  // KV 切回 KPW4：自动回「黑体 + 紧凑 + 中」（下面「预设没变只调字号」要按 KPW4 继续）
  await p.goto(BASE + '/lite', { waitUntil: 'domcontentloaded' });
  await p.selectOption('select[name=preset]', 'kpw4');
  await Promise.all([p.waitForLoadState('domcontentloaded'), p.click('input[value="保存"]')]);
  ok(readFmt(USER).preset === 'kpw4' && readFmt(USER).fs === 22,
    'KV 切回 KPW4 后自动回「黑体 + 紧凑 + 中（22px）」：' + JSON.stringify(readFmt(USER)));

  // 预设没变、只调字号：按新字号实时重算行数（还是一屏），但不该被拽回 22px
  await p.goto(BASE + '/lite', { waitUntil: 'domcontentloaded' });
  await p.selectOption('select[name=fs]', '26');
  await Promise.all([p.waitForLoadState('domcontentloaded'), p.click('input[value="保存"]')]);
  const fmtP2 = readFmt(USER);
  ok(fmtP2.preset === 'kpw4' && fmtP2.fs === 26,
    '预设还开着时单独调字号是生效的（不会被预设再拽回 22px）：' + JSON.stringify(fmtP2));
  ok(pset.l26 < pset.lines,
    '字号变大后一屏行数自动变少（22px ' + pset.lines + ' 行 → 26px ' + pset.l26 +
    ' 行），仍然刚好一屏');

  // 选回「自定义」：预设关闭
  await p.goto(BASE + '/lite', { waitUntil: 'domcontentloaded' });
  // ★ 用 label 而不是空字符串：selectOption(sel, '') 传空值不会真的选中 value="" 那一项
  await p.selectOption('select[name=preset]', { label: '自定义' });
  await Promise.all([p.waitForLoadState('domcontentloaded'), p.click('input[value="保存"]')]);
  ok(readFmt(USER).preset === '',
    '选回「自定义」就关掉预设（' + JSON.stringify(readFmt(USER)) + '）');


  // ============ ★ 书架板块（站长要求：加在「最近在读」下面、「书库」上面）============
  // 夹具：把测试账号的书架换成固定的两本（一本带分组：先加的 #EPUB、后加的 #TXT），
  // 再塞一本「他看不到的书」进去 —— 现造数据才验得出「按加入时间倒序」和「不给死链」。
  // ★ 走临时文件快照 + 还原（JSON 经 shell→python 两层转义必然失真，这个坑本文件踩过两次）
  const SHELF_SNAP = '/tmp/lite_shelf_snapshot.json';
  fs.writeFileSync(SHELF_SNAP, py(`import sys, json; sys.path.insert(0, '${ROOT}'); import db
u = db.q("SELECT id FROM users WHERE username='${USER}'", one=True)
print(json.dumps({
    "shelf": [dict(r) for r in db.q("SELECT * FROM shelves WHERE user_id=?", (u["id"],), one=False)],
    "cols": [dict(r) for r in db.q("SELECT * FROM shelf_collections WHERE user_id=?", (u["id"],), one=False)]}))`));
  py(`import sys, json; sys.path.insert(0, '${ROOT}'); import db
u = db.q("SELECT id FROM users WHERE username='${USER}'", one=True)
uid = u["id"]
db.ex("DELETE FROM shelves WHERE user_id=?", (uid,))
db.ex("DELETE FROM shelf_collections WHERE user_id=?", (uid,))
cid = db.ex("INSERT INTO shelf_collections (user_id,name,sort_order,created_at) VALUES (?,?,?,?)",
            (uid, "测试分组", 1, db.now()))
db.ex("INSERT INTO shelves (user_id,book_id,added_at,collection_id) VALUES (?,?,?,?)",
      (uid, ${EPUB_BOOK}, "2020-01-01 00:00:00", None))
db.ex("INSERT INTO shelves (user_id,book_id,added_at,collection_id) VALUES (?,?,?,?)",
      (uid, ${TXT_BOOK}, "2021-01-01 00:00:00", cid))
${info.invis_book ? 'db.ex("INSERT OR IGNORE INTO shelves (user_id,book_id,added_at,collection_id) VALUES (?,?,?,?)", (uid, ' + info.invis_book + ', "2022-01-01 00:00:00", None))' : 'pass'}
print("ok")`);

  await p.goto(BASE + '/lite', { waitUntil: 'domcontentloaded' });
  const sv = vis(await p.content());
  const shRec = sv.indexOf('<h2>最近在读</h2>');
  const shSh = sv.indexOf('<h2>书架</h2>');
  const shLib = sv.indexOf('<h2>书库</h2>');
  ok(shRec >= 0 && shSh > shRec && shLib > shSh,
    '★ 书架板块就在「最近在读」下面、「书库」上面（位置 ' + shRec + ' < ' + shSh + ' < ' + shLib + '）');
  const shSeg = sv.slice(shSh, sv.indexOf('</ul>', shSh));
  const shLinks = (shSeg.match(/href="\/lite\/book\/(\d+)"/g) || [])
    .map(x => parseInt(x.replace(/\D+/g, ''), 10));
  ok(shLinks[0] === TXT_BOOK && shLinks[1] === EPUB_BOOK,
    '书架按加入时间倒序（后加的 ' + TXT_BOOK + ' 排在先加的 ' + EPUB_BOOK + ' 前面）：' + shLinks.join(','));
  ok(shSeg.indexOf('测试分组') >= 0,
    '书架里显示分组名（这是书架自己的信息，「书库」里没有）');
  ok(shLinks.every(id => id > 0) && shSeg.indexOf('/lite/book/' + TXT_BOOK + '"') >= 0 &&
     shSeg.indexOf('/lite/book/' + EPUB_BOOK + '"') >= 0,
    '书架每一项都指向那本书的极简页（/lite/book/N）');
  if (info.invis_book) {
    ok(shLinks.indexOf(info.invis_book) < 0,
      '书架里已经看不到的书（#' + info.invis_book + '，别人的私人书）不列出 —— 不给点进去报错的死链');
  }

  // ---- 退出：cookie 清掉，回到未登录状态 ----
  await p.goto(BASE + '/lite/logout', { waitUntil: 'domcontentloaded' });
  await p.goto(BASE + '/lite', { waitUntil: 'domcontentloaded' });
  html = await p.content();
  ok((await ctx.cookies()).filter(c => c.name === 'bm_lite' && c.value).length === 0 &&
     html.indexOf('type="password"') >= 0,
    '退出后 cookie 清空、首页回到登录表单');
  ok(vis(html).indexOf('<h2>书架</h2>') < 0,
    '未登录时没有书架板块（书架是按账号的，游客只看「书库」里访客可见的书）');

  // ---- 访客读不到别人的私人书 ----
  if (info.private_book) {
    await p.goto(BASE + '/lite/book/' + info.private_book, { waitUntil: 'domcontentloaded' });
    ok((await p.innerText('body')).indexOf('书籍不存在') >= 0,
      '访客访问他人的私人书（#' + info.private_book + '）被拒（书籍不存在）');
  }

  // ---- 开放重定向防护 ----
  const r1 = await ctx.request.post(BASE + '/lite/login', {
    form: { username: USER, password: PASS, next: 'https://evil.example.com/x' }, maxRedirects: 0 });
  ok((r1.headers()['location'] || '') === '/lite',
    'next 指向站外时被改写成 /lite（Location: ' + r1.headers()['location'] + '）');
  const r2 = await ctx.request.post(BASE + '/lite/login', {
    form: { username: USER, password: PASS, next: '/lite/book/' + TXT_BOOK }, maxRedirects: 0 });
  ok((r2.headers()['location'] || '') === '/lite/book/' + TXT_BOOK,
    'next 是站内 /lite 相对路径时照常跳回去（Location: ' + r2.headers()['location'] + '）');
  const r3 = await ctx.request.post(BASE + '/lite/login', {
    form: { username: USER, password: 'definitely-wrong', next: '/lite' }, maxRedirects: 0 });
  const r3body = await r3.text();
  ok(r3.status() === 200 && r3body.indexOf('用户名或密码错误') >= 0 && !(r3.headers()['set-cookie'] || '').indexOf('bm_lite=') >= 0,
    '密码错误：不跳转、不种 cookie，只提示「用户名或密码错误」');

  ok(errs.length === 0, '禁用 JS 的全流程里没有任何页面报错');
  await ctx.close();

  // ============ 第二部分：现代浏览器（必须一点不受影响） ============
  const ctx2 = await b.newContext({ ignoreHTTPSErrors: true, viewport: { width: 390, height: 844 } });
  await ctx2.addInitScript(([t, u]) => {
    localStorage.setItem('bm_token', t); localStorage.setItem('bm_user', u);
  }, [info.token, JSON.stringify({ id: info.uid })]);
  const p2 = await ctx2.newPage();
  await p2.goto(BASE + '/reader?id=' + EPUB_BOOK, { waitUntil: 'domcontentloaded' });
  await p2.waitForTimeout(3200);
  const modern2 = await p2.evaluate(() => ({
    url: location.pathname,
    dots: document.querySelectorAll('.theme-dot').length,
    lite: (document.getElementById('lite-link') || {}).getAttribute
      ? document.getElementById('lite-link').getAttribute('href') : '',
  }));
  ok(modern2.url === '/reader' && modern2.dots === 10,
    '现代浏览器打开 /reader 没被转走，阅读器照常可用（' + modern2.dots + ' 个背景圆点）');
  ok(modern2.lite === '/lite/book/' + EPUB_BOOK,
    '设置里的「兼容模式」入口指向当前这本书的极简页（' + modern2.lite + '）');
  await ctx2.close();

  // ============ 第三部分：模拟「跑不动现代阅读器」的设备，必须自动转走 ============
  const ctx3 = await b.newContext({ ignoreHTTPSErrors: true, viewport: { width: 600, height: 800 } });
  // 老引擎没有 fetch / Promise（第七代 Kindle 就是这样）；能力探测里任一缺失都该转走
  await ctx3.addInitScript(() => {
    try { delete window.fetch; } catch (e) {}
    try { delete window.Promise; } catch (e) {}
  });
  const p3 = await ctx3.newPage();
  await p3.goto(BASE + '/reader?id=' + TXT_BOOK, { waitUntil: 'domcontentloaded' });
  await p3.waitForTimeout(1500);
  ok(p3.url().indexOf('/lite/book/' + TXT_BOOK) >= 0,
    '缺少 fetch/Promise 的设备打开 /reader 会被自动送到极简页（' + p3.url().replace(BASE, '') + '）');
  // ★ 光有阅读页兜底不够：老设备平时打开的是站点首页（SPA），那份 app.js 同样是 ES6，
  //   首页也会白屏 —— 用户根本走不到极简页。首页与 #/book/N 也必须兜底。
  await p3.goto(BASE + '/', { waitUntil: 'domcontentloaded' });
  await p3.waitForTimeout(1200);
  ok(p3.url().replace(BASE, '') === '/lite',
    '同一台设备打开站点首页也被送到极简书架（' + p3.url().replace(BASE, '') + '）');
  await p3.goto(BASE + '/#/book/' + EPUB_BOOK, { waitUntil: 'domcontentloaded' });
  await p3.waitForTimeout(1200);
  ok(p3.url().indexOf('/lite/book/' + EPUB_BOOK) >= 0,
    '首页带 #/book/N 时直接送到那本书的极简页（' + p3.url().replace(BASE, '') + '）');
  await ctx3.close();

  await b.close();

  // ============ 还原测试账号的进度数据 ============
  // ★ 快照走临时文件而不是塞进 shell 字符串：JSON 里的引号经「shell → Python 三引号」
  //   两层转义后必然失真（第一版就栽在这，还原直接抛 JSONDecodeError）。
  const SNAP = '/tmp/lite_progress_snapshot.json';
  fs.writeFileSync(SNAP, JSON.stringify({ progress: info.progress, fmt: info.fmt }));
  const shelfSnap = fs.readFileSync(SHELF_SNAP, 'utf8');
  const out = py(`import sys, json; sys.path.insert(0, '${ROOT}'); import db
uid = ${info.uid}
snap = json.load(open('${SNAP}', encoding='utf-8'))
before = snap["progress"]
db.ex("DELETE FROM progress WHERE user_id=? AND book_id IN (?,?)", (uid, ${TXT_BOOK}, ${EPUB_BOOK}))
for r in before:
    if r["book_id"] in (${TXT_BOOK}, ${EPUB_BOOK}):
        db.ex("INSERT INTO progress (user_id,book_id,position,percent,updated_at) VALUES (?,?,?,?,?)",
              (uid, r["book_id"], r["position"], r["percent"], r["updated_at"]))
db.ex("INSERT INTO settings (user_id, lite_fmt) VALUES (?,?) "
      "ON CONFLICT(user_id) DO UPDATE SET lite_fmt=excluded.lite_fmt", (uid, snap["fmt"]))
snap2 = json.loads(open('${SHELF_SNAP}', encoding='utf-8').read())
db.ex("DELETE FROM shelves WHERE user_id=?", (uid,))
db.ex("DELETE FROM shelf_collections WHERE user_id=?", (uid,))
for r in snap2["cols"]:
    db.ex("INSERT INTO shelf_collections (id,user_id,name,sort_order,created_at) VALUES (?,?,?,?,?)",
          (r["id"], r["user_id"], r["name"], r["sort_order"], r["created_at"]))
for r in snap2["shelf"]:
    db.ex("INSERT INTO shelves (id,user_id,book_id,added_at,collection_id) VALUES (?,?,?,?,?)",
          (r["id"], r["user_id"], r["book_id"], r["added_at"], r["collection_id"]))
print("restored")`);
  ok(out.indexOf('restored') >= 0, '测试账号的阅读进度、排版设置与书架已还原（' + out + '）');
  const shelfNow = JSON.parse(py(`import sys, json; sys.path.insert(0, '${ROOT}'); import db
u = db.q("SELECT id FROM users WHERE username='${USER}'", one=True)
print(json.dumps({"shelf": [dict(r) for r in db.q("SELECT * FROM shelves WHERE user_id=?", (u["id"],), one=False)],
                  "cols": [dict(r) for r in db.q("SELECT * FROM shelf_collections WHERE user_id=?", (u["id"],), one=False)]}))`));
  // ★ 比结构不比字符串：Python 的 json.dumps 是 '{"a": 1}'、JS 的 stringify 是 '{"a":1}'，
  //   直接比字符串必然假红（Python 的空格 vs JS 无空格）
  ok(JSON.stringify(shelfNow) === JSON.stringify(JSON.parse(shelfSnap)),
    '书架与分组已还原成测试前的内容（' + shelfNow.shelf.length + ' 本 / ' + shelfNow.cols.length + ' 个分组）');
  ok(readFmt(USER).fs === (JSON.parse(info.fmt || '{}').fs || undefined) ||
     JSON.stringify(readFmt(USER)) === JSON.stringify(JSON.parse(info.fmt || '{}')),
    '排版设置已还原成测试前的内容（' + JSON.stringify(readFmt(USER)) + '）');

  console.log('\n极简阅读页（老设备兼容）：' + pass + ' 通过 / ' + fail + ' 失败');
  process.exit(fail ? 1 : 0);
})();
