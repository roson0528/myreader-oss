// 听书播放器
// 核心思路：音频由服务端逐句合成，合成速度约 0.74 倍实时，
// 所以必须在播放当前句的同时把后面几句提前合成好，否则每次都会卡顿。
const TOKEN = localStorage.getItem('bm_token') || '';
const BID = new URLSearchParams(location.search).get('id');
const audio = new Audio();
audio.preload = 'auto';     // 提前缓冲，换段时不用等解码

// 本标签页的会话号。服务端靠它区分「同一个账号的另一个终端」——
// 一个账号同一时间只允许一个终端听书，否则多终端会成倍占用合成资源。
// 用 sessionStorage 而不是 localStorage：每个标签页各自算一个终端。
const SID = (function () {
  try {
    let s = sessionStorage.getItem('bm_listen_sid');
    if (!s) {
      s = 'sid' + Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
      sessionStorage.setItem('bm_listen_sid', s);
    }
    return s;
  } catch (e) {
    return 'sid' + Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
  }
})();

let INFO = null;            // /listen/info 的返回
let TOTAL = 0;              // 总句数
let CUR = -1;               // 当前句
let VOICE = '';             // 当前音色
let LINE = '';              // 当前线路（TTS 服务器 url；''=自动）
let RATE = parseFloat(localStorage.getItem('bm_rate') || '1') || 1;
let playing = false;
let playToken = 0;          // 防止旧的异步播放覆盖新的
let savedAt = 0;
let finished = false;

// 句子文本窗口（整本书几千句，只按需取一段）
let TEXT_FROM = -1, TEXTS = [];

// 音频 blob 缓存：服务端不落盘，客户端也在播完后释放
const blobs = new Map();      // idx -> objectURL
const pending = new Map();    // idx -> Promise<objectURL>
const KEEP_AROUND = 3;        // 当前句前后各保留几句的客户端缓存

// 每句「实际是哪台服务器合成的」。服务端在响应头 X-Line-Used 里回报，
// 不是前端按配置猜的 —— 自动轮询和兜底换线时，猜一定会猜错。
// 按句记录：用户往回跳时，显示的历史值也才是当时真实用的那台。
const LINE_OF = new Map();    // idx -> '主线一' / '备用一' …

function renderLineUsed() {
  const el = $('l-lineused');
  if (!el) return;
  const n = LINE_OF.get(CUR) || '';
  el.textContent = n;
  el.title = n ? ('当前线路：' + n) : '';
}

// 换音色 / 换线路后，旧句子的「哪台合出来的」不再适用于新请求，清掉重记
function resetLineUsed() {
  LINE_OF.clear();
  renderLineUsed();
}

// ---------------------------------------------------------------- 基础工具
function $(id) { return document.getElementById(id); }

function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// 后端错误体 → 人能看懂的一句话（FastAPI 的 422 detail 是对象数组，
// 直接 new Error 会变成「[object Object]」）
function apiErrText(d, status) {
  const det = d && (d.detail != null ? d.detail : d.message);
  if (typeof det === 'string' && det) return det;
  if (Array.isArray(det)) {
    const parts = det.map(x => {
      if (typeof x === 'string') return x;
      if (x && typeof x === 'object') {
        const loc = Array.isArray(x.loc) ? x.loc.filter(k => k !== 'body' && k !== 'query').join('.') : '';
        return (loc ? loc + '：' : '') + (x.msg || JSON.stringify(x));
      }
      return String(x);
    }).filter(Boolean);
    if (parts.length) return parts.join('；');
  } else if (det && typeof det === 'object') {
    return det.message || det.msg || JSON.stringify(det);
  }
  // 后端什么都没给：返回空串，由调用方给各自合适的兜底文案
  // （登录 401 要说「用户名或密码错误」，别的接口说 HTTP 状态码）
  return '';
}
async function api(path, opts) {
  opts = opts || {};
  const h = opts.headers || {};
  if (TOKEN) h['Authorization'] = 'Bearer ' + TOKEN;
  if (opts.body) h['Content-Type'] = 'application/json';
  const r = await fetch(path, { method: opts.method || 'GET', headers: h, body: opts.body });
  if (r.status === 401) { location.href = '/'; throw new Error('未登录'); }
  const txt = await r.text();
  let data;
  try { data = JSON.parse(txt); } catch (e) { throw new Error('服务返回异常：' + txt.slice(0, 80)); }
  if (!r.ok) {
    const err = new Error(apiErrText(data, r.status) || ('HTTP ' + r.status));
    err.status = r.status;
    throw err;
  }
  return data;
}

// 听书接口统一带上本标签页的会话号
function lapi(path, opts) {
  opts = opts || {};
  const sep = path.indexOf('?') >= 0 ? '&' : '?';
  const p = path + sep + 'sid=' + encodeURIComponent(SID);
  if (opts.body) {
    let b = {};
    try { b = JSON.parse(opts.body) || {}; } catch (e) { b = {}; }
    b.sid = SID;
    opts = { method: opts.method, body: JSON.stringify(b) };
  }
  return api(p, opts);
}

let statusTimer = null;
// 重要提示的保留期。播放过程中「正在合成…」这类状态每秒都在刷新，
// 会把「当前 App 版本不支持后台播放」这种一次性提示瞬间盖掉，
// 所以重要提示用 force=true，保留期内忽略次要提示。
let statusHold = 0;
function showStatus(msg, ms, force) {
  if (!force && Date.now() < statusHold) return;
  const el = $('l-status');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(statusTimer);
  if (force) statusHold = Date.now() + (ms || 0);
  if (ms) statusTimer = setTimeout(() => el.classList.remove('show'), ms);
}
function hideStatus() { $('l-status').classList.remove('show'); }

// 返回图书详情页（返回上一级）。地址必须是 '#/book/'（应用路由）；
// '#!/book/6' 会被路由解析成 seg='!'，兜底成首页，回不到详情页。
// 主动刷新 / 「后台」时置 true：这两种情况是**故意**让声音继续的，
// 页面卸载时不能顺手把它停掉。
let KEEP_PLAYING = false;
let LEAVING = false;        // 正在离开本页，卸载流程已接管收尾

// 「返回」= 走人并停止播放。
// ★ 顺序很重要：原来是「发完 stop 立刻 location.href」，跳转会把还没送达原生的
//   桥接调用丢掉，前台服务收不到 stop，声音就留在后台继续响。
//   改成等原生确认（最多 800ms）再跳转。
async function goBack() {
  LEAVING = true;
  const pending = (USE_NATIVE && nativeStarted) ? nativeStop() : null;
  releaseLock();
  if (pending) {
    try { await Promise.race([pending, new Promise(r => setTimeout(r, 800))]); } catch (e) {}
  }
  location.href = '/#/book/' + BID;
}

// 「后台」：回到图书详情，但继续播放。
// 原生播放器在前台服务里，离开本页声音不断；通知栏/锁屏可继续控制。
function goBackground() {
  if (!USE_NATIVE) {
    showStatus('当前 App 版本不支持后台播放，请更新到最新版本', 4000, true);
    return;
  }
  saveProgress(true);
  KEEP_PLAYING = true;                    // 故意继续播，卸载钩子别来停
  location.href = '/#/book/' + BID;
}

// 安卓系统返回键：返回上一级（图书详情页）。
// 不注册这个监听的话，Capacitor 会退化成 webView.goBack()——
// 也就是「后退到上一个访问过的页面」，层级上并不等于这本书的详情。
(function () {
  const onBack = () => {
    const sm = document.getElementById('l-mask');
    if (sm && sm.classList.contains('show')) { closeSheets(); return; }     // 面板优先关
    goBack();
  };
  let tries = 0;
  (function reg() {
    try {
      const App = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App;
      if (App) { App.addListener('backButton', onBack); return; }
    } catch (e) {}
    // ★ 注册不上就重试，不能就此放弃：插件晚于本脚本就绪时，
    //   返回键会退化成 Capacitor 默认的 webView.goBack()，
    //   那是「后退到上一个访问过的页面」，绕过 goBack()/releaseLock()，
    //   声音就留在后台一直响 —— 用户看到的就是「退出后还在放」。
    if (++tries < 60) setTimeout(reg, 100);
  })();
})();

// 只自动刷新一次：sessionStorage 里留标记，刷新后仍在就不会再刷，避免死循环
function reloadOnce() {
  let done = false;
  try { done = !!sessionStorage.getItem('bm_player_reloaded'); } catch (e) {}
  if (done) { showStatus('播放器版本过旧，请下拉刷新页面', 8000); return; }
  try { sessionStorage.setItem('bm_player_reloaded', '1'); } catch (e) {}
  showStatus('正在更新播放器…', 2000);
  KEEP_PLAYING = true;                    // 只是刷新页面，别把正在听的书停掉
  setTimeout(() => location.reload(), 300);
}

function showBlock(icon, msg, actions) {
  $('l-block-ic').textContent = icon;
  $('l-block-ms').innerHTML = msg;
  const ac = $('l-block-ac');
  ac.innerHTML = '';
  (actions || []).forEach(a => {
    const b = document.createElement('button');
    b.className = a.primary ? 'btn' : 'btn ghost';
    b.textContent = a.label;
    b.onclick = a.onClick;
    ac.appendChild(b);
  });
  $('l-block').classList.add('show');
}

// ---------------------------------------------------------------- 原生播放（APP）
// APP 端声音由原生前台服务里的 MediaPlayer 播放，本页只是遥控器。
// 这样关屏、切 App、甚至离开本页都不会中断播放。
// 纯浏览器取不到插件，自动回退到页面内的 <audio>（下面的 audio.xxx 分支）。
// ★ 不能在脚本求值时只查一次。Capacitor 的插件代理要是晚于本脚本就绪，
//   一次性的查找会**永久**拿到 null：既用不上原生播放，连返回键监听都注册不上。
//   所以改成每次调用现查（用 Proxy 包一层，下面所有 NP.xxx() 写法都不用改）。
let _npPlugin = null;
function getNP() {
  if (_npPlugin) return _npPlugin;
  try {
    const C = window.Capacitor;
    if (C && C.Plugins && C.Plugins.ListenService) _npPlugin = C.Plugins.ListenService;
  } catch (e) {}
  return _npPlugin;
}
const NP = new Proxy({}, {
  get(_t, k) {
    const p = getNP();
    if (!p) return undefined;
    const v = p[k];
    return typeof v === 'function' ? v.bind(p) : v;
  },
});
let USE_NATIVE = false;      // 是否用原生播放（要探测，见 detectNative）
let nativeStarted = false;   // 是否已把播放配置下发给原生服务
let nativeStartIndex = -1;   // 「续听」时记住待播放的句子，点播放才真正开始
let BT_LINK = true;          // 蓝牙联动：连上蓝牙自动播、断开自动停
let BT_LINK_OK = false;      // 当前 APK 是否支持这个开关（插件版本 >= 3）

// 必须探测而不是「有插件就用」：网页是服务器上的最新版，APK 却可能是旧的。
// 旧版插件的 start 只是保活，不会真的出声，直接用会让用户听不到声音。
// 新版 status() 会返回 version，以此区分。
// ★ 用 >= 而不是 ==：每加一项原生能力就抬一次版本号，
//   写成 == 的话每次升级都会把「还没更新 APK 的老用户」一起判死。
async function detectNative() {
  if (!getNP()) return null;
  try {
    const st = await NP.status();
    const ver = st ? Number(st.version) || 0 : 0;
    if (ver >= 2) {
      USE_NATIVE = true;
      BT_LINK_OK = ver >= 3;                  // 蓝牙联动开关是版本 3 才有的
      if (BT_LINK_OK && typeof st.btLink === 'boolean') BT_LINK = st.btLink;
      return st;
    }
  } catch (e) {}
  return null;
}

// 原生状态回调：界面完全跟着原生走，避免两边状态打架
window.__laoshuPlayerState = function (st) {
  if (!USE_NATIVE || !st) return;
  if (st.total) TOTAL = st.total;
  if (typeof st.index === 'number' && st.index >= 0) {
    const moved = (st.index !== CUR);
    CUR = st.index;
    if (moved) { updateUI(); renderWindow(); }
  }
  if (typeof st.voice === 'string' && st.voice && st.voice !== VOICE) {
    VOICE = st.voice;
    $('l-vname').textContent = voiceLabel(VOICE);
  }
  if (typeof st.rate === 'number' && st.rate > 0 && st.rate !== RATE) {
    RATE = st.rate;
    $('l-rate').textContent = String(RATE).replace(/^(\d)$/, '$1.0') + '×';
  }
  setPlaying(!!st.playing);
};

function nativeStart(idx) {
  nativeStarted = true;
  startWatch();
  NP.start({
    baseUrl: location.origin,
    token: TOKEN,
    sid: SID,
    voice: VOICE,
    title: (INFO && INFO.title) || '听书',
    bookId: parseInt(BID, 10) || 0,
    total: TOTAL,
    index: idx,
    rate: RATE,
  }).catch(e => showStatus('无法启动后台播放：' + ((e && e.message) || e), 5000));
}

function nativeStop() {
  nativeStarted = false;
  try { return Promise.resolve(NP.stop()).catch(() => {}); } catch (e) { return null; }
}

// ---------------------------------------------------------------- 蓝牙联动开关
// 打开时：连上蓝牙耳机自动续播、断开蓝牙自动暂停（原有行为，默认开）。
// 关掉后连接/断开蓝牙都不再影响播放。
// 真正干活的是原生 PlaybackService —— 它监听系统音频设备变化，
// 并用一个时间窗区分「蓝牙带出来的 play/pause」和「用户主动按的播放键」。
// 网页这里只是个遥控器，开关值存在 App 的 SharedPreferences 里。

/** 刷新按钮外观。USE_NATIVE 为假（电脑浏览器）时整颗按钮不显示。 */
function renderBtLink() {
  const b = $('l-bt');
  if (!b) return;
  if (!USE_NATIVE) { b.style.display = 'none'; return; }
  b.style.display = '';
  b.textContent = BT_LINK ? '蓝牙✓' : '蓝牙✕';
  b.classList.toggle('on', BT_LINK);
  // 旧 APK（插件 < 3）上没有这两个方法：按钮仍然显示出来，
  // 但标成不可用并提示更新 App —— 直接藏掉的话用户不知道有这个功能。
  b.classList.toggle('na', !BT_LINK_OK);
  if (!BT_LINK_OK) {
    b.title = '当前 App 版本不支持蓝牙联动开关，请更新 App 后使用';
  } else {
    b.title = BT_LINK
      ? '蓝牙联动：开 —— 连上蓝牙自动播放，断开自动暂停（点击关闭）'
      : '蓝牙联动：关 —— 连接或断开蓝牙都不影响播放（点击开启）';
  }
}

/** 从原生读一次开关的真实值（App 那边才是唯一事实来源） */
async function loadBtLink() {
  if (!USE_NATIVE || !BT_LINK_OK) { renderBtLink(); return; }
  try {
    const r = await NP.getBtLink();
    if (r && typeof r.on === 'boolean') BT_LINK = r.on;
  } catch (e) {}
  renderBtLink();
}

async function toggleBtLink() {
  if (!USE_NATIVE) return;
  if (!BT_LINK_OK) { showStatus('当前 App 版本不支持这个开关，请更新 App', 4000); return; }
  const next = !BT_LINK;
  try {
    const r = await NP.setBtLink({ on: next });
    BT_LINK = (r && typeof r.on === 'boolean') ? r.on : next;
    renderBtLink();
    showStatus(BT_LINK
      ? '蓝牙联动已开启：连上蓝牙自动播放，断开自动暂停'
      : '蓝牙联动已关闭：连接或断开蓝牙都不影响播放', 3000);
  } catch (e) {
    showStatus('设置失败：' + ((e && e.message) || e), 4000);
  }
}

// 通知栏 / 锁屏 / 耳机按键：原生自己就能处理播放，
// 这里只需要把界面同步过来（状态会经 __laoshuPlayerState 回来）。
window.__laoshuMediaAction = function (action) {
  if (action === 'stop') { nativeStarted = false; setPlaying(false); }
};

// ---------------------------------------------------------------- 听书锁
// 一个账号同一时间只允许一个终端听书（多终端会成倍占用合成资源）。
// 服务端按 40 秒租约判定：心跳断了就自动释放，所以关页面/断网不会把账号锁死。
let hbTimer = null;
let watchCtl = null;
let watchTimer = null;
let watchGen = 0;      // 主动停止时 +1，用来作废在途的重连

function startHeartbeat() {
  stopHeartbeat();
  // 长句合成要几十秒，期间没有别的请求，必须靠心跳续租。
  // 5 秒一次：这是「锁被抢后多久停下来」的兜底，主通道是下面的长连接。
  hbTimer = setInterval(async () => {
    if (!playing) return;
    try {
      const r = await lapi('/api/books/' + BID + '/listen/heartbeat', { method: 'POST', body: '{}' });
      if (r && r.owned === false) { onLockLost(r.reason || '该账号已在另一台设备上开始听书。'); return; }
      // 当前线路兜底：长连接万一被中间代理缓冲/断开，心跳（5 秒一次）这条通道
      // 也能把「当前线路」带回来（见服务端 listen_heartbeat）。
      if (r && r.line) {
        LINE_OF.set(r.line_idx, r.line);
        if (r.line_idx === CUR) renderLineUsed();
      }
    } catch (e) {
      if (e.status === 409) onLockLost(e.message);
    }
  }, 5000);
}

function stopHeartbeat() {
  if (hbTimer) { clearInterval(hbTimer); hbTimer = null; }
  stopWatch();
}

// 听书锁长连接。用 fetch 流式读取而不是 EventSource ——
// 只有 fetch 才能带上 Authorization 头。
// 好处：网页切到后台、标签页被隐藏时依然收得到，
// 而 setInterval 在后台会被浏览器限流到一分钟一次，根本来不及。
function startWatch() {
  if (watchCtl) return;
  const ctl = new AbortController();
  const myGen = watchGen;
  watchCtl = ctl;
  (async () => {
    try {
      const r = await fetch('/api/books/' + BID + '/listen/watch?sid=' + encodeURIComponent(SID), {
        headers: TOKEN ? { 'Authorization': 'Bearer ' + TOKEN } : {},
        signal: ctl.signal,
      });
      if (!r.ok || !r.body) throw new Error('HTTP ' + r.status);
      const rd = r.body.getReader();
      const dec = new TextDecoder();
      let buf = '';
      for (;;) {
        const { done, value } = await rd.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        let i;
        while ((i = buf.indexOf('\n\n')) >= 0) {
          const chunk = buf.slice(0, i); buf = buf.slice(i + 2);
          for (const line of chunk.split('\n')) {
            if (line.slice(0, 6) !== 'data: ') continue;
            let d; try { d = JSON.parse(line.slice(6)); } catch (e) { continue; }
            // 「当前线路」：APP 的原生后台播放取音频的是 Java 服务，
            // WebView 看不到 X-Line-Used 响应头，只能靠服务端推过来。
            if (d && d.type === 'line') {
              if (d.sid === SID && d.name) {
                LINE_OF.set(d.idx, d.name);
                if (d.idx === CUR) renderLineUsed();
              }
              continue;
            }
            // 其余是「锁被别的终端拿走了」
            if (d && d.sid && d.sid !== SID) {
              onLockLost(d.reason || '该账号已在另一台设备上继续收听。');
              return;
            }
          }
        }
      }
    } catch (e) {
      // 断线（网络抖动/服务重启）→ 稍后重连
    }
    // 已经被 stopWatch() 主动停掉了就别再重连，否则松开锁之后又挂回来
    if (myGen !== watchGen) return;
    watchCtl = null;
    if (watchTimer) clearTimeout(watchTimer);
    watchTimer = setTimeout(() => { if (playing) startWatch(); }, 3000);
  })();
}

function stopWatch() {
  watchGen++;
  if (watchTimer) { clearTimeout(watchTimer); watchTimer = null; }
  if (watchCtl) { try { watchCtl.abort(); } catch (e) {} watchCtl = null; }
}

function releaseLock() {
  stopHeartbeat();
  if (USE_NATIVE) nativeStop();          // 原生模式：由服务停播并释放听书锁
  try { audio.pause(); } catch (e) {}
  try {
    // ★ 进度随停止请求一起发，由服务端保证「先存进度、再释放会话」的顺序。
    //   以前是 saveProgress() 和 releaseLock() 各发一个请求，两者会乱序：
    //   stop 先到把会话删了，后到的 progress 走 _listen_touch 又把它 INSERT 回来，
    //   用户一走账号反而被自己锁住（再进来就提示「已在另一台设备上听书」）。
    const pb = progressBody();
    const payload = pb ? Object.assign({ sid: SID, save_progress: 1 }, pb) : { sid: SID };
    fetch('/api/books/' + BID + '/listen/stop?sid=' + encodeURIComponent(SID), {
      method: 'POST',
      headers: TOKEN ? { 'Authorization': 'Bearer ' + TOKEN, 'Content-Type': 'application/json' }
                     : { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      keepalive: true
    }).catch(() => {});
  } catch (e) {}
}

async function takeOver() {
  try {
    await lapi('/api/books/' + BID + '/listen/start', { method: 'POST', body: JSON.stringify({ take: true }) });
    // 用户点的就是「继续听」，刷新后要直接接着放，
    // 否则会停在暂停状态等用户再点一次播放，看着像没生效。
    try { sessionStorage.setItem('bm_listen_autoplay', '1'); } catch (e) {}
    KEEP_PLAYING = true;                  // 接管后要立刻接着放，别被卸载钩子停掉
    location.reload();
  } catch (e) {
    showBlock('⚠️', esc(e.message), [{ label: '返回', primary: true, onClick: goBack }]);
  }
}

function onLockConflict(msg) {
  showBlock('📱', esc(msg).replace(/\n/g, '<br>'), [
    { label: '在这台设备上继续听', primary: true, onClick: takeOver },
    { label: '返回', onClick: goBack },
  ]);
}

function onLockLost(msg) {
  stopHeartbeat();
  playToken++;                     // 让正在等待的合成结果作废
  try { audio.pause(); } catch (e) {}
  setPlaying(false);
  showBlock('📱', esc(msg).replace(/\n/g, '<br>') + '<br><br>本机已停止播放。', [
    { label: '在这台设备上继续听', primary: true, onClick: takeOver },
    { label: '返回', onClick: goBack },
  ]);
}

// ---------------------------------------------------------------- 句级音频取用
function ensureBlob(idx) {
  if (blobs.has(idx)) return Promise.resolve(blobs.get(idx));
  if (pending.has(idx)) return pending.get(idx);
  const url = '/api/books/' + BID + '/listen/seg/' + idx
            + '?voice=' + encodeURIComponent(VOICE) + '&sid=' + encodeURIComponent(SID)
            + (LINE ? '&line=' + encodeURIComponent(LINE) : '');
  const p = fetch(url, { headers: TOKEN ? { 'Authorization': 'Bearer ' + TOKEN } : {} })
    .then(async r => {
      if (!r.ok) {
        let m = 'HTTP ' + r.status;
        try { const j = await r.json(); m = j.detail || m; } catch (e) {}
        const err = new Error(m);
        err.status = r.status;
        throw err;
      }
      // 「当前线路」由服务端回报**实际产出**这一段的那台服务器，前端不猜。
      // 值经过百分号编码（HTTP 头只能装 latin-1，中文线路名装不进去）。
      try {
        const ln = decodeURIComponent(r.headers.get('X-Line-Used') || '');
        if (ln) {
          LINE_OF.set(idx, ln);
          if (idx === CUR) renderLineUsed();
        }
      } catch (e) {}
      return r.blob();
    })
    .then(b => {
      const u = URL.createObjectURL(b);
      blobs.set(idx, u);
      pending.delete(idx);
      trimBlobs(idx);
      return u;
    })
    .catch(e => { pending.delete(idx); throw e; });
  pending.set(idx, p);
  return p;
}

// 只保留当前句附近的 blob，其余及时释放，避免内存堆积
function trimBlobs(keep) {
  for (const k of Array.from(blobs.keys())) {
    if (Math.abs(k - keep) > KEEP_AROUND) {
      URL.revokeObjectURL(blobs.get(k));
      blobs.delete(k);
    }
  }
}

function clearBlobs() {
  blobs.forEach(u => URL.revokeObjectURL(u));
  blobs.clear();
  pending.clear();
  LINE_OF.clear();          // 换音色/换线路后，旧的「哪台合出来的」全部作废
  renderLineUsed();
}

// 让服务端提前把后面几句排进合成队列（不等待，纯排程）
let prefetchTimer = null;
function serverPrefetch(from, count) {
  clearTimeout(prefetchTimer);
  prefetchTimer = setTimeout(() => {
    lapi('/api/books/' + BID + '/listen/prefetch', {
      method: 'POST',
      body: JSON.stringify({ from: from, count: count, voice: VOICE, line: LINE })
    }).catch(() => {});
  }, 80);
}

function preload(idx) {
  if (idx < 0 || idx >= TOTAL) return;
  ensureBlob(idx).catch(() => {});
}

// ---------------------------------------------------------------- 播放
async function playIdx(idx, autoplay) {
  if (idx < 0) idx = 0;
  if (idx >= TOTAL) { finished = true; setPlaying(false); showStatus('已是最后一句', 2000); return; }
  finished = false;
  const tk = ++playToken;
  CUR = idx;
  updateUI();
  renderWindow();
  saveProgress();

  // 原生播放：把「播哪一句」交给前台服务，本页不再参与声音
  if (USE_NATIVE) {
    startWatch();
    if (!nativeStarted) nativeStart(idx);
    else try { NP.gotoIndex({ index: idx }).catch(() => {}); } catch (e) {}
    return;
  }

  let url;
  try {
    showStatus('正在合成…');
    url = await ensureBlob(idx);
  } catch (e) {
    if (tk === playToken) {
      hideStatus();
      setPlaying(false);
      if (e.status === 409) { onLockLost(e.message); return; }
      // 旧版页面（没带会话号）调新服务端会 400，自动刷新一次换成新版播放器
      if (e.status === 400 && /会话标识/.test(e.message)) { reloadOnce(); return; }
      showStatus('合成失败：' + e.message, 4000);
    }
    return;
  }
  if (tk !== playToken) return;      // 期间用户又点了别的句
  hideStatus();
  audio.src = url;
  audio.playbackRate = RATE;
  if (autoplay !== false) {
    try { await audio.play(); setPlaying(true); startHeartbeat(); startWatch(); }
    catch (e) { setPlaying(false); }
  }
  // 提前把后面几句准备好：客户端取回 + 服务端排程。
  // 服务端本身也会滚动预取 3 段，这里多做一层是为了让浏览器手里就有 blob，
  // 换段时连一次网络往返都省掉。
  preload(idx + 1);
  preload(idx + 2);
  preload(idx + 3);
  serverPrefetch(idx + 4, 8);
}

function togglePlay() {
  if (USE_NATIVE) {
    if (!nativeStarted) { nativeStart(nativeStartIndex >= 0 ? nativeStartIndex : (CUR < 0 ? 0 : CUR)); startWatch(); return; }
    startWatch();
    if (playing) { try { NP.pause().catch(() => {}); } catch (e) {} }
    else { try { NP.play().catch(() => {}); } catch (e) {} }
    return;
  }
  if (playing) { audio.pause(); setPlaying(false); return; }
  if (finished || CUR < 0) { finished = false; playIdx(CUR < 0 ? 0 : CUR, true); return; }
  if (audio.src) { audio.play().then(() => { setPlaying(true); startHeartbeat(); }).catch(() => {}); }
  else { playIdx(CUR < 0 ? 0 : CUR, true); }
}

function step(d) {
  const n = CUR + d;
  if (n < 0) { showStatus('已是第一句', 1500); return; }
  if (n >= TOTAL) { showStatus('已是最后一句', 1500); return; }
  playIdx(n, true);
}

function setPlaying(v) {
  playing = v;
  $('l-play').textContent = v ? '❚❚' : '▶';
  // 听书时别让手机熄屏（keepawake.js）：这个页面本身就是播放页，
  // 正在播就常亮、暂停/出错/读完就松开。APP 里走原生，网页里走 Wake Lock。
  if (typeof keepAwake === 'function') keepAwake(!!v);
}

function cycleRate() {
  const rates = [1, 1.25, 1.5, 2, 0.75];
  RATE = rates[(rates.indexOf(RATE) + 1) % rates.length];
  localStorage.setItem('bm_rate', String(RATE));
  $('l-rate').textContent = RATE.toFixed(2).replace(/0$/, '') + '×';
  if (USE_NATIVE) { try { if (nativeStarted) NP.setRate({ rate: RATE }).catch(() => {}); } catch (e) {} }
  else audio.playbackRate = RATE;
}

audio.addEventListener('ended', () => { if (!finished) playIdx(CUR + 1, true); });
audio.addEventListener('error', () => {
  if (audio.src) { setPlaying(false); showStatus('播放出错，试试下一句', 3000); }
});

// ---------------------------------------------------------------- 界面
async function renderWindow() {
  if (CUR < TEXT_FROM || CUR >= TEXT_FROM + TEXTS.length) {
    try {
      const r = await api('/api/books/' + BID + '/listen/texts?from=' + Math.max(0, CUR - 5) + '&count=30');
      TEXT_FROM = r.from; TEXTS = r.items;
    } catch (e) { return; }
  }
  const box = $('l-texts');
  box.innerHTML = TEXTS.map(s =>
    '<div class="l-seg' + (s.idx === CUR ? ' cur' : (s.idx < CUR ? ' past' : '')) +
    '" data-i="' + s.idx + '" onclick="jumpTo(' + s.idx + ')">' + esc(s.text) + '</div>'
  ).join('');
  const curEl = box.querySelector('.l-seg.cur');
  if (curEl) {
    const body = $('l-body');
    const top = curEl.offsetTop - body.clientHeight * 0.34;
    body.scrollTo({ top: Math.max(0, top), behavior: 'smooth' });
  }
  const c = TEXTS.find(s => s.idx === CUR);
  $('l-chapter').textContent = c && c.title ? c.title : '';
}

function jumpTo(idx) { playIdx(idx, true); }

function updateUI() {
  const pct = TOTAL > 1 ? (CUR / (TOTAL - 1)) * 100 : 0;
  $('l-progress-fill').style.width = pct.toFixed(2) + '%';
  $('l-pos').textContent = (CUR + 1) + ' / ' + TOTAL + '  ·  ' + pct.toFixed(1) + '%';
  renderLineUsed();
  $('l-prev').disabled = CUR <= 0;
  $('l-next').disabled = CUR >= TOTAL - 1;
  $('l-rate').textContent = String(RATE).replace(/^(\d)$/, '$1.0') + '×';
  $('l-vname').textContent = '音色';
  renderBtLink();
}

// 音色显示名。优先「流行音色样板」的名字（萝莉音/夹子音…），
// 其次后台给的标签，最后兜底成「默认音色」——
// 界面上不该出现 pool_49 这种编号（除非实在查不到）。
// 当前线路能提供的音色样板。没选线路（自动）时用全量。
function lineStyles() {
  if (!INFO) return [];
  if (LINE) {
    const l = (INFO.lines || []).find(x => x.id === LINE);
    if (l) return l.voices || [];
  }
  return INFO.styles || [];
}

function lineLabel(id) {
  if (!id) return '自动';
  const l = (INFO && (INFO.lines || []).find(x => x.id === id));
  return l ? l.name : '自动';
}

function voiceLabel(id) {
  if (!id) return '默认音色';
  if (INFO) {
    const st = lineStyles().find(x => x.voice === id)
            || (INFO.styles || []).find(x => x.voice === id);
    if (st) return st.name;
    const v = (INFO.voices || []).find(x => x.id === id);
    if (v && v.label) return v.label;
  }
  return '默认音色';
}

function seekClick(ev) {
  if (!TOTAL) return;
  const r = ev.currentTarget.getBoundingClientRect();
  const f = Math.min(1, Math.max(0, (ev.clientX - r.left) / r.width));
  playIdx(Math.round(f * (TOTAL - 1)), true);
}

// ---------------------------------------------------------------- 抽屉
function openSheet(which) {
  if (which === 'lines') {
    renderLines();
    const h = document.querySelector('#l-sheet-lines .l-sheet-hd h3');
    if (h) h.textContent = '选择线路 · 当前：' + lineLabel(LINE);
  }
  if (which === 'voices') {
    renderVoices();
    const h = document.querySelector('#l-sheet-voices .l-sheet-hd h3');
    if (h) h.textContent = '选择音色' + (VOICE ? ' · 当前：' + voiceLabel(VOICE) : '');
  }
  if (which === 'toc') renderToc();
  $('l-mask').classList.add('show');
  $('l-sheet-' + which).classList.add('show');
}
function closeSheets() {
  $('l-mask').classList.remove('show');
  document.querySelectorAll('.l-sheet').forEach(s => s.classList.remove('show'));
}

// 音色抽屉：列「流行音色样板」（萝莉音/夹子音/御姐音…），
// 而不是把 pool_01~pool_60 的编号丢给用户。
function renderVoices() {
  const box = $('l-voice-list');
  const list = lineStyles();
  if (!list.length) { box.innerHTML = '<div class="empty">没有可选音色</div>'; return; }
  const item = (id, name, gender, on) =>
    '<div class="l-voice' + (on ? ' on' : '') + '" onclick="pickVoice(\'' + esc(id) + '\')">' +
    '<span><span class="nm">' + esc(name) + '</span>' +
    (gender ? '<span class="gg">' + esc(gender) + '</span>' : '') + '</span>' +
    (on ? '<span class="ck">✓</span>' : '') + '</div>';
  const html = list.map(v => item(v.voice, v.name, v.gender, v.voice === VOICE));
  // 当前音色不在样板里（例如后台把默认音色改成了没进样板的编号）时补一条，
  // 否则用户会看到一个都没选中，不知道正在用哪个。
  if (VOICE && !list.some(v => v.voice === VOICE)) {
    html.unshift(item(VOICE, voiceLabel(VOICE), '当前', true));
  }
  box.innerHTML = html.join('');
}

// 线路抽屉：一台服务器一条线路。每条线路只列它「真能合成」的音色，
// 因为各线路模型不同（IndexTTS-2 / GPT-SoVITS v2），音色集也不一样。
function renderLines() {
  const box = $('l-line-list');
  const list = (INFO && INFO.lines) || [];
  if (!list.length) { box.innerHTML = '<div class="empty">没有可用线路</div>'; return; }
  const item = (id, name, sub, on, ok) =>
    '<div class="l-voice l-line' + (on ? ' on' : '') + '" onclick="pickLine(\'' +
    esc(id) + '\')"><span><span class="nm">' +
    (ok === null ? '' : '<span class="dot ' + (ok ? 'ok' : 'bad') + '"></span>') +
    esc(name) + '</span><span class="sub">' + esc(sub) + '</span></span>' +
    (on ? '<span class="ck">✓</span>' : '') + '</div>';
  const html = [item('', '自动', '由服务端按负载和健康度自动分流', !LINE, null)];
  for (const l of list) {
    html.push(item(l.id, l.name,
      l.model + ' · ' + l.count + ' 种音色' + (l.health ? '' : ' · 当前不可用'),
      l.id === LINE, !!l.health));
  }
  box.innerHTML = html.join('');
}

// 换线路要连带处理音色：新线路没有当前音色时，自动落到该线路的第一个音色，
// 否则用户会带着一个这条线路合成不了的音色去点播放。
function pickLine(id) {
  closeSheets();
  const same = (id === LINE);
  LINE = id || '';
  localStorage.setItem('bm_listen_line_' + BID, LINE);
  $('l-vname').textContent = '音色';
  const styles = lineStyles();
  if (styles.length && !styles.some(x => x.voice === VOICE)) {
    VOICE = styles[0].voice;
    localStorage.setItem('bm_listen_voice_' + BID, VOICE);
    showStatus('这条线路没有原来的音色，已切到 ' + voiceLabel(VOICE), 2600);
  }
  saveLine();                    // 让服务端记住，原生后台播放也照这条线路走
  if (same) { showStatus('仍是 ' + lineLabel(LINE) + ' 线路', 1600); return; }
  clearBlobs();                  // 换线路后旧音频全部作废（不同模型的成品不一样）
  if (USE_NATIVE) {
    if (nativeStarted) { try { NP.setVoice({ voice: VOICE }).catch(() => {}); } catch (e) {} }
    else if (CUR >= 0) playIdx(CUR, true);
  } else if (CUR >= 0) {
    playIdx(CUR, playing || true);
  }
  showStatus('已切到 ' + lineLabel(LINE) + ' 线路 · ' + voiceLabel(VOICE), 2200);
}

function pickVoice(id) {
  closeSheets();
  const same = (id === VOICE);
  VOICE = id;
  // 音色按书独立记忆：这本用萝莉音，那本用御姐音，互不影响。
  // 即使选的就是当前音色也要记下来——这是本书的显式偏好，
  // 否则以后后台改了默认音色，这本书会跟着被改掉。
  localStorage.setItem('bm_listen_voice_' + BID, id);
  $('l-vname').textContent = '音色';
  if (USE_NATIVE) {
    if (same) return;                   // 没变化，不必重播
    saveProgress(true);                 // 服务端也按书记住，换设备仍能沿用
    if (nativeStarted) { try { NP.setVoice({ voice: id }).catch(() => {}); } catch (e) {} }
    else if (CUR >= 0) playIdx(CUR, true);
    showStatus('已为本书记住音色 ' + voiceLabel(id), 1800);
    return;
  }
  if (same && audio.src) return;        // 没变化，不必重播
  clearBlobs();                         // 换音色后旧音频全部作废
  if (CUR >= 0) {
    saveProgress(true);                 // 服务端也按书记住，换设备仍能沿用
    playIdx(CUR, playing || true);
  }
  // 放在 playIdx 之后：playIdx 会立刻写「正在合成…」，先写就被它盖掉了
  showStatus('已为本书记住音色 ' + voiceLabel(id), 1800);
}

function renderToc() {
  const box = $('l-chap-list');
  const curChap = (TEXTS.find(s => s.idx === CUR) || {}).chapter;
  box.innerHTML = (INFO.chapters || []).map(c =>
    '<div class="l-chap' + (c.chapter === curChap ? ' on' : '') +
    '" onclick="jumpTo(' + c.start + ')"><span>' + esc(c.title || ('第 ' + (c.chapter + 1) + ' 章')) +
    '</span><span class="cnt">' + c.count + ' 句</span></div>'
  ).join('') || '<div class="empty">没有目录</div>';
}

// ---------------------------------------------------------------- 进度
// 进度载荷。退出播放页时不能单独发这个请求 —— 见 releaseLock() 的说明。
function progressBody() {
  if (CUR < 0 || !TOTAL) return null;
  const pct = TOTAL > 1 ? (CUR / (TOTAL - 1)) * 100 : 0;
  return { seg_idx: CUR, offset: USE_NATIVE ? 0 : (audio.currentTime || 0),
           voice: VOICE, line: LINE, percent: pct };
}

function saveProgress(force) {
  const pb = progressBody();
  if (!pb) return;
  const now = Date.now();
  if (!force && now - savedAt < 8000) return;
  savedAt = now;
  lapi('/api/books/' + BID + '/listen/progress', {
    method: 'PUT', body: JSON.stringify(pb)
  }).catch(() => {});
}

// 单独把线路写进服务端：这时可能还没点播放（saveProgress 会直接返回），
// 而原生后台播放不带 line 参数，只能靠服务端记住的这条。
function saveLine() {
  lapi('/api/books/' + BID + '/listen/line', {
    method: 'POST', body: JSON.stringify({ line: LINE, sid: SID })
  }).catch(() => {});
}

window.addEventListener('beforeunload', () => {
  LEAVING = true;
  // ★ 离开本页就停播。以前这里只存进度，于是除了「返回」按钮和返回键之外，
  //   任何离开方式（点链接、路由跳转、关掉页面）都会让声音留在后台继续响。
  //   「后台」按钮和主动刷新会先置 KEEP_PLAYING，只存进度、不停播。
  //   注意停播分支里**不再单独调 saveProgress**：进度已经随 stop 请求一起发了，
  //   多发一个 PUT 会把它刚释放的会话写回来。
  if (KEEP_PLAYING) saveProgress(true);
  else releaseLock();
});
// 切换 App / 锁屏时存一次进度。但**正在离开本页**时要跳过：
// 卸载流程里 stop 已经把会话释放了，这里再发一个 PUT 会走 _listen_touch
// 把会话写回来（服务端也有宽限期兜底，这里少发一个请求更干净）。
document.addEventListener('visibilitychange', () => {
  if (document.hidden && !LEAVING) saveProgress(true);
});

// ---------------------------------------------------------------- 启动
async function init() {
  if (!BID) { showBlock('❓', '缺少书籍参数'); return; }
  if (!TOKEN) { showBlock('🔒', '请先登录后再使用听书', [{ label: '去登录', primary: true, onClick: () => location.href = '/' }]); return; }

  let info;
  try {
    info = await lapi('/api/books/' + BID + '/listen/info');
  } catch (e) {
    showBlock('⚠️', '无法进入听书：<br>' + esc(e.message), [{ label: '返回', primary: true, onClick: goBack }]);
    return;
  }
  if (!info.enabled) {
    showBlock('🔒', esc(info.reason || '听书暂不可用'),
      [{ label: '返回', primary: true, onClick: goBack }]);
    return;
  }
  INFO = info;
  TOTAL = info.total;
  document.title = '听书 · ' + info.title;
  $('l-title').textContent = info.title;

  // 探测原生播放能力。已经在后台放这本书 → 直接接管，不打断当前播放。
  const nst = await detectNative();
  loadBtLink();                      // 读一次蓝牙联动开关（不阻塞后面的初始化）
  if (USE_NATIVE && nst && nst.active && Number(nst.bookId) === Number(BID)) {
    nativeStarted = true;
    if (nst.total) TOTAL = nst.total;
    if (typeof nst.index === 'number' && nst.index >= 0) CUR = nst.index;
    if (nst.voice) { VOICE = nst.voice; $('l-vname').textContent = '音色'; }
    if (typeof nst.rate === 'number' && nst.rate > 0) {
      RATE = nst.rate;
      $('l-rate').textContent = String(RATE).replace(/^(\d)$/, '$1.0') + '×';
    }
    updateUI();
    await renderWindow();
    setPlaying(!!nst.playing);
    showStatus(nst.playing ? '正在后台播放' : '已接管播放', 2200);
    return;
  }

  // 别的终端正在听：先提示，别让用户白确认一次树叶
  if (info.holder) {
    onLockConflict('该账号正在另一台设备上听《' + (info.holder.title || '未知书籍') + '》。\n' +
                   '同一账号同一时间只能听一本书。');
    return;
  }

  // 这本书还在有效期内（树叶买的、或占的免费名额）就直接进，不再弹确认框。
  // ★ 服务端的 already 是**有限期**的：只在 30 天内为真，过期后这个字段变 false，
  //   下面就会重新弹「免费额度 / 消耗树叶」的确认框 —— 即「到期需重新购买」。
  if (info.already) { /* 还在有效期内，接着听，不再扣也不再提示 */ }

  // 走免费额度：不花钱，但要让用户知道占掉了一个名额（名额 30 天有效）
  if (!info.already && info.quota_ok) {
    const q = info.quota || {};
    const d = q.valid_days || 30;
    const ok = confirm('本次听书使用「免费额度」，不消耗树叶。\n' +
      (q.limit ? '近 ' + d + ' 天内共 ' + q.limit + ' 本，已用 ' + q.used + ' 本，还剩 ' + q.left + ' 本。\n' : '') +
      '⚠ 这个名额只在 ' + d + ' 天内有效，' + d + ' 天后重听本书会重新占用一个名额。\n' +
      '\n确认开始听书？');
    if (!ok) { goBack(); return; }
  }

  // 需消耗树叶：先确认再扣，避免误点
  if (!info.already && info.need_spend) {
    const d = (info.quota && info.quota.valid_days) || 30;
    const ok = confirm('本书需要消耗 ' + info.cost + ' 片树叶才能听书。\n' +
      '当前余额 ' + info.balance + ' 片。\n' +
      '⚠ 权限有效期 ' + d + ' 天，到期后需重新购买。\n\n确认开始听书？');
    if (!ok) { goBack(); return; }
  }

  // 抢听书锁。start 是幂等的：有效期内已扣过树叶不会再扣一次，
  // 这样即使不需要花树叶也会走一遍，避免第一次取音频才发现被别的终端占用。
  try {
    const r = await lapi('/api/books/' + BID + '/listen/start', { method: 'POST', body: '{}' });
    if (info.already) { /* 还在有效期内，不提示 */ }
    else if (info.need_spend) showStatus('已消耗树叶，' + ((info.quota && info.quota.valid_days) || 30) + ' 天内可听，余额 ' + r.balance + ' 片', 3000);
    else if (info.quota_ok && r.quota) showStatus('已用免费额度，还剩 ' + r.quota.left + ' 本（' + (r.quota.valid_days || 30) + ' 天内有效）', 3000);
  } catch (e) {
    if (e.status === 409) { onLockConflict(e.message); return; }
    showBlock('🌿', '树叶不足：<br>' + esc(e.message), [{ label: '返回', primary: true, onClick: goBack }]);
    return;
  }

  // 线路也按书独立：本机记的 > 进度里记的 > 后台给的当前线路 > 自动
  LINE = localStorage.getItem('bm_listen_line_' + BID)
      || (info.progress && info.progress.line) || info.line || '';
  if (LINE && !(info.lines || []).some(x => x.id === LINE)) LINE = '';   // 线路已被后台下线
  // 音色按书独立：本书记住的 > 进度里记的（换设备同样有效）> 后台默认
  const allowed = (info.voices || []).map(v => v.id);
  let v = localStorage.getItem('bm_listen_voice_' + BID)
       || (info.progress && info.progress.voice) || info.default_voice;
  if (allowed.length && allowed.indexOf(v) < 0) v = info.default_voice;
  if (allowed.length && allowed.indexOf(v) < 0) v = allowed[0];
  VOICE = v;
  // 还原出来的音色还必须落在「当前线路的样板表」里。
  // 否则从备用一切回自动时，上次选的备用一音色会以 #03 这种裸编号多列一条。
  {
    const st = lineStyles();
    if (st.length && !st.some(x => x.voice === VOICE)) {
      VOICE = st[0].voice;
      localStorage.setItem('bm_listen_voice_' + BID, VOICE);
    }
  }
  $('l-vname').textContent = '音色';
  $('l-rate').textContent = String(RATE).replace(/^(\d)$/, '$1.0') + '×';

  // 续听
  const start = (info.progress && info.progress.seg_idx > 0) ? info.progress.seg_idx : 0;
  if (start > 0 && start < TOTAL) {
    CUR = start;
    updateUI();
    await renderWindow();
    setPlaying(false);
    let auto = false;
    try {
      auto = sessionStorage.getItem('bm_listen_autoplay') === '1';
      sessionStorage.removeItem('bm_listen_autoplay');
    } catch (e) {}
    if (auto) {
      showStatus('已接管播放', 2000);
      if (USE_NATIVE) { nativeStart(start); return; }
      await playIdx(start, true);
      return;
    }
    showStatus('已跳到上次听到的第 ' + (start + 1) + ' 句', 2600);
    if (USE_NATIVE) {
      // 原生模式：点播放时再把这一句交给原生（nativeStarted 仍是 false）
      nativeStartIndex = start;
      serverPrefetch(start, 8);
      return;
    }
    // 先预热，用户点播放即可立即出声
    preload(start); preload(start + 1); preload(start + 2);
    serverPrefetch(start, 8);
    return;
  }
  if (USE_NATIVE) { nativeStart(0); return; }
  await playIdx(0, true);
}

init();
