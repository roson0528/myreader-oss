#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""汇总最终报告"""
import json, os, time
from collections import defaultdict

W = os.path.dirname(os.path.abspath(__file__))
ST = W + "/state"

def load_lines(path):
    if not os.path.exists(path):
        return []
    with open(path, encoding="utf-8") as fh:
        return [l.rstrip("\n") for l in fh if l.strip()]

def main():
    plan = json.load(open(ST + "/plan.json"))
    plans = plan["plans"]
    stats = plan["stats"]
    done_bulk = load_lines(ST + "/done_bulk.jsonl")
    failed_bulk = load_lines(ST + "/failed_bulk.jsonl")
    done_arch = load_lines(ST + "/done_archive.jsonl")
    failed_arch = load_lines(ST + "/failed_archive.jsonl")
    done_sftp = load_lines(ST + "/done_sftp.jsonl")
    failed_sftp = load_lines(ST + "/failed_sftp.jsonl") if os.path.exists(ST + "/failed_sftp.jsonl") else []

    done_src = set(l.split("\t")[0] for l in done_bulk)
    done_arch_keys = set(l.split("\t")[0] for l in done_arch)
    done_sftp_keys = set(l.split("\t")[0] for l in done_sftp)

    # 分类统计（仅已完成 bulk 的）
    cat_count = defaultdict(int)
    cat_bytes = defaultdict(int)
    for p in plans:
        if p["src"] in done_src:
            cat_count[p["cat_folder"]] += 1
            cat_bytes[p["cat_folder"]] += p["size"]

    n_bulk_done = len(done_src)
    n_bulk_total = len(plans)
    n_failed = len(failed_bulk)

    rep = []
    rep.append("# 图书整理执行报告")
    rep.append(f"\n生成时间：{time.strftime('%Y-%m-%d %H:%M:%S')}")
    rep.append("\n## 一、总体概况\n")
    rep.append(f"- 源目录：`/books`（FTP 192.0.2.200:21021）")
    rep.append(f"- 电子书单文件（计划直接复制）：**{n_bulk_total:,}** 个，约 **273.6 GB**")
    rep.append(f"- 压缩包：**{len(plan['archives'])}** 个，约 **{sum(a['size'] for a in plan['archives'])/1e9:.2f} GB**")
    rep.append(f"- 跳过（封面/配套/未完成等）：**{stats['skipped']:,}** 个")
    rep.append(f"- SFTP 兜底（emoji 目录 + 混合编码）：**{stats['sftp_pending']}** 个 + emoji 目录内文件")
    rep.append(f"\n## 二、复制进度\n")
    rep.append(f"- 直接复制已完成：**{n_bulk_done:,} / {n_bulk_total:,}**（{100.0*n_bulk_done/max(n_bulk_total,1):.1f}%）")
    rep.append(f"- 失败待重试：**{n_failed}**")
    rep.append(f"- 压缩包已处理：**{len(done_arch_keys)}** 组")
    rep.append(f"- SFTP 已复制：**{len(done_sftp_keys)}**")

    rep.append("\n## 三、分类统计（已完成部分）\n")
    rep.append("| 分类目录 | CLC | DDC对照 | 数量 | 体积 |")
    rep.append("|---|---|---|---|---|")
    meta = plan.get("class_meta", {})
    letter_by_folder = {v: k for k, v in plan.get("cat_map", {}).items()}
    for c in plan["categories"]:
        lt = letter_by_folder.get(c, "00")
        ddc = meta.get(lt, {}).get("ddc", "-")
        rep.append(f"| {c} | {lt} | {ddc} | {cat_count.get(c,0):,} | {cat_bytes.get(c,0)/1e9:.1f} GB |")
    rep.append(f"| **合计** | | | **{sum(cat_count.values()):,}** | **{sum(cat_bytes.values())/1e9:.1f} GB** |")

    import csv as _csv, os as _os
    if _os.path.exists(W + "/reports/audit.csv"):
        _m = {}
        for _r in _csv.DictReader(open(W + "/reports/audit.csv")):
            _m[_r["method"]] = _m.get(_r["method"], 0) + 1
        rep.append("\n## 三之补充：分类方法构成（可复核训练）\n")
        for _k, _v in sorted(_m.items(), key=lambda x: -x[1]):
            _note = {"context": "目录/系列上下文（高置信）", "keyword": "CLC词表关键词命中",
                     "en": "英文关键词/兜底", "fallback": "启发式兜底（多为网文短书名）"}.get(_k, "")
            rep.append(f"- **{_k}**：{_v:,} 本 {_note}")
        rep.append("\n> 全量逐本清单见 `reports/audit.csv`（源路径/归入类/DDC/命中词/方法），可直接核对；修改 `clc_terms.json` 词表后重跑 classify.py 即完成一次迭代训练。")

    rep.append("\n## 四、命名规范\n")
    rep.append(f"- 提取到作者并规范为 `书名_作者.后缀`：**{stats.get('renamed',0):,}** 个（对照见 `reports/renamed.csv`）")
    rep.append(f"- 无法确定作者、保留清理后书名：**{stats.get('noauthor',0):,}** 个（清单见 `reports/noauthor.csv`，供人工补录）")
    rep.append(f"- 目录内重名自动加 `(序号)`，源目录任何文件未删除、未修改。")

    rep.append("\n## 五、异常与待处理\n")
    if failed_bulk:
        rep.append(f"### 直接复制失败（{len(failed_bulk)}，见 state/failed_bulk.jsonl）")
        for l in failed_bulk[:20]:
            rep.append(f"- `{l[:120]}`")
    else:
        rep.append("- 直接复制失败：无")
    if failed_arch:
        rep.append(f"### 压缩包失败（{len(failed_arch)}）")
        for l in failed_arch[:20]:
            rep.append(f"- `{l[:120]}`")
    if failed_sftp:
        rep.append(f"### SFTP 失败（{len(failed_sftp)}）")
        for l in failed_sftp[:20]:
            rep.append(f"- `{l[:120]}`")
    rep.append("\n> 说明：`其他(待分类)` 中主要包含「政治/法律/军事/社会学」等社科类书籍（约200余本）与极少数无明确标题的文件；如需单独建「社科·政治·法律类」，可告知，后续可一键移动。")

    open(W + "/reports/REPORT.md", "w", encoding="utf-8").write("\n".join(rep))
    print("\n".join(rep))

if __name__ == "__main__":
    main()
