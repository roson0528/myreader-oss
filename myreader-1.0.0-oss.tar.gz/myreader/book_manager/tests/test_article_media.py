# -*- coding: utf-8 -*-
"""文章内嵌媒体（图片 / 视频）后端回归。

覆盖：视频上传成功与落盘、返回 URL 可访问且 Content-Type / Range 正确、
扩展名与大小与空文件三类拒绝、无发表权限时 403、
以及视频地址写进文章正文后能原样取回。

安全：只建临时账号/临时分组/临时文章，结束按**精确 id** 删除，
上传产生的文件也按**精确文件名**删除；不碰任何真实数据。
运行：venv/bin/python tests/test_article_media.py
"""
import os
import ssl
import sys
import json
import uuid
import urllib.request
import urllib.error
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
os.chdir(_ROOT)
import config, db, auth, booklists  # noqa: E402

BASE = 'https://127.0.0.1:9000'
CTX = ssl._create_unverified_context()

_pass = [0]
_fail = [0]
_created = {'users': [], 'groups': [], 'articles': [], 'files': []}


def check(name, ok, extra=''):
    if ok:
        _pass[0] += 1
        print('  [OK] %s' % name + ('  %s' % extra if extra else ''))
    else:
        _fail[0] += 1
        print('  [FAIL] %s' % name + ('  %s' % extra if extra else ''))


def req(path, token=None, method='GET', data=None, headers=None, raw=None, ctype=None):
    h = dict(headers or {})
    h['X-BM-No-Push'] = '1'      # 测试请求：服务端别真发 Server酱（见 tests/README.md）
    if token:
        h['Authorization'] = 'Bearer ' + token
    if ctype:
        h['Content-Type'] = ctype
    r = urllib.request.Request(BASE + path, data=raw if raw is not None else data,
                               headers=h, method=method)
    try:
        with urllib.request.urlopen(r, context=CTX, timeout=180) as resp:
            body = resp.read()
            return resp.status, dict(resp.headers), body
    except urllib.error.HTTPError as e:
        return e.code, dict(e.headers), e.read()


def hget(headers, name):
    """HTTP 头要做大小写无关查找：urllib 给的键名全是小写"""
    for k, v in (headers or {}).items():
        if k.lower() == name.lower():
            return v
    return ''


def multipart(field, filename, content, extra_fields=None):
    """手工拼 multipart/form-data：测试里不想引第三方依赖"""
    b = '----articleMedia' + uuid.uuid4().hex
    out = []
    for k, v in (extra_fields or {}).items():
        out.append(('--%s\r\nContent-Disposition: form-data; name="%s"\r\n\r\n%s\r\n' % (b, k, v)).encode())
    out.append(('--%s\r\nContent-Disposition: form-data; name="%s"; filename="%s"\r\n'
                'Content-Type: application/octet-stream\r\n\r\n' % (b, field, filename)).encode())
    out.append(content)
    out.append(('\r\n--%s--\r\n' % b).encode())
    return b''.join(out), 'multipart/form-data; boundary=' + b


def make_user(group_id=None, tag='am'):
    uname = 'zzam_%s_%s' % (tag, uuid.uuid4().hex[:8])
    uid = db.ex("INSERT INTO users (username,password_hash,role,enabled,group_id,created_at,can_publish_booklist) "
                "VALUES (?,?,?,?,?,?,?)",
                (uname, auth.hash_password('x' + uuid.uuid4().hex), 'user', 1, group_id,
                 db.now(), 0))
    _created['users'].append(uid)
    return db.q("SELECT * FROM users WHERE id=?", (uid,), one=True)



def cleanup():
    for aid in _created['articles']:
        db.ex("DELETE FROM booklist_comments WHERE booklist_id=?", (aid,))
        db.ex("DELETE FROM booklists WHERE id=?", (aid,))
    for fn in _created['files']:
        p = os.path.join(config.IMAGE_DIR, os.path.basename(fn))
        if os.path.exists(p):
            os.remove(p)
    # 先删用户再删分组：用户引用了分组
    for uid in _created['users']:
        db.ex("DELETE FROM messages WHERE to_id=? OR from_id=?", (uid, uid))
        db.ex("DELETE FROM users WHERE id=?", (uid,))
    for gid in _created['groups']:
        db.ex("DELETE FROM user_groups WHERE id=?", (gid,))


print('=' * 78)
print('A. 视频上传（HTTP，临时账号）')
print('=' * 78)
# 用临时账号 + create_token，而不是登录 test 账号：
# 登录会给真实账号写 last_login 和一条审计日志，测试不该留这些痕迹。
# 注意 /api/login 收的是表单而不是 JSON（JSON 会 422），这里绕开它。
PUB_GROUP = db.q("SELECT id FROM user_groups WHERE can_publish_booklist=1 ORDER BY sort_order LIMIT 1",
                 one=True)['id']
publisher = make_user(group_id=PUB_GROUP, tag='pub')
TOK = auth.create_token(publisher)
check('临时账号有发表权限（否则下面测不到上传）', auth.can(publisher, 'publish_booklist'),
      'group_id=%s' % PUB_GROUP)

clip = open('/tmp/test_clip.mp4', 'rb').read()
body, ctype = multipart('file', '我的视频.mp4', clip)
st, _, resp = req('/api/booklists/upload-video', token=TOK, method='POST', raw=body, ctype=ctype)
d = json.loads(resp or b'{}')
check('视频上传返回 200', st == 200, 'status=%s body=%s' % (st, resp[:160]))
vurl = d.get('url') or ''
check('返回可用的视频 URL', vurl.startswith('/uploads/') and vurl.endswith('.mp4'), vurl)
if vurl:
    _created['files'].append(vurl)
    disk = os.path.join(config.IMAGE_DIR, os.path.basename(vurl))
    check('文件真的落盘了', os.path.exists(disk), disk)
    check('落盘内容与上传的一致', open(disk, 'rb').read() == clip)

if vurl:
    st2, h2, b2 = req(vurl)
    check('传上去的视频能直接访问', st2 == 200, 'status=%s' % st2)
    check('Content-Type 是 video/mp4（浏览器才肯播）',
          hget(h2, 'Content-Type').startswith('video/mp4'), hget(h2, 'Content-Type'))
    check('支持 Range 请求（视频拖进度条要用）',
          hget(h2, 'Accept-Ranges') == 'bytes', hget(h2, 'Accept-Ranges'))
    # 真正发一个 Range 请求，确认回 206 与 Content-Range
    st3, h3, b3 = req(vurl, headers={'Range': 'bytes=0-99'})
    check('Range 请求返回 206 Partial Content', st3 == 206, 'status=%s' % st3)
    check('返回的 Content-Range 正确',
          hget(h3, 'Content-Range').startswith('bytes 0-99/'), hget(h3, 'Content-Range'))
    check('返回的正是前 100 字节', b3 == clip[:100], '%d 字节' % len(b3))

print()
print('=' * 78)
print('B. 图片上传没被改坏（同一个共用函数）')
print('=' * 78)
# 1x1 PNG（只用到头部即可：上传端点只按扩展名判类型，不解码图片）
png = bytes.fromhex('89504e470d0a1a0a0000000d4948445200000001000000010806000000'
                    '1f15c4890000000a49444154789c6300010000050001')
body, ctype = multipart('file', 'p.png', png)
st, _, resp = req('/api/booklists/upload-image', token=TOK, method='POST', raw=body, ctype=ctype)
di = json.loads(resp or b'{}')
check('图片上传仍返回 200', st == 200, 'status=%s body=%s' % (st, resp[:120]))
check('图片 URL 正常', (di.get('url') or '').endswith('.png'), di.get('url'))
if di.get('url'):
    _created['files'].append(di['url'])

print()
print('=' * 78)
print('C. 三类拒绝（进程内直调，不产生垃圾文件）')
print('=' * 78)
from fastapi import HTTPException  # noqa: E402


class FakeUp:
    def __init__(self, filename, content):
        self.filename = filename
        import io
        self.file = io.BytesIO(content)


def expect_400(label, fake, exts, maxb, tip):
    try:
        booklists._save_media(fake, publisher,
                              exts, maxb, config.IMAGE_DIR, tip[0], tip[1])
        return None
    except HTTPException as e:
        return e.status_code, e.detail


r = expect_400('扩展名', FakeUp('evil.exe', b'MZ'), booklists._VIDEO_EXTS, booklists._VIDEO_MAX,
               ('MP4/WebM/OGV/MOV/M4V 视频', '视频'))
check('伪造扩展名（.exe）被拒 400', r and r[0] == 400, str(r))
check('拒绝文案说明了支持的类型', r and 'MP4' in r[1], str(r))

r = expect_400('空文件', FakeUp('a.mp4', b''), booklists._VIDEO_EXTS, booklists._VIDEO_MAX,
               ('MP4/WebM/OGV/MOV/M4V 视频', '视频'))
check('空文件被拒 400', r and r[0] == 400, str(r))

r = expect_400('超大', FakeUp('big.mp4', b'x' * 10), booklists._VIDEO_EXTS, 5,
               ('MP4/WebM/OGV/MOV/M4V 视频', '视频'))
check('超过上限被拒 400', r and r[0] == 400, str(r))
check('拒绝文案报出上限数字', r and ('大小不能超过' in r[1]), str(r))
check('上限文案是人话（KB/MB 而不是字节数）', r and ('KB' in r[1] or 'MB' in r[1]), str(r))

check('视频上限是 50MB', booklists._VIDEO_MAX == 50 * 1024 * 1024, str(booklists._VIDEO_MAX))
check('图片上限仍是 1MB（没被顺手动过）', booklists._IMG_MAX == 1024 * 1024, str(booklists._IMG_MAX))
check('图片白名单没变', booklists._IMG_EXTS == {'.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp'},
      str(sorted(booklists._IMG_EXTS)))

print()
print('=' * 78)
print('D. 无发表权限：403（临时分组 + 临时账号）')
print('=' * 78)
gid = db.ex("INSERT INTO user_groups (code,name,sort_order,can_publish_booklist,is_system,created_at) "
            "VALUES (?,?,?,?,?,?)",
            ('zzam' + uuid.uuid4().hex[:6], '测试无发表权分组', 99, 0, 0, db.now()))
_created['groups'].append(gid)
u = make_user(group_id=gid, tag='nopub')
ntok = auth.create_token(u)
check('临时账号确实没有发表权限', not auth.can(u, 'publish_booklist'), 'group_id=%s' % gid)
body, ctype = multipart('file', 'v.mp4', clip)
st, _, resp = req('/api/booklists/upload-video', token=ntok, method='POST', raw=body, ctype=ctype)
check('无权限账号上传视频被拒 403', st == 403, 'status=%s body=%s' % (st, resp[:120]))
body, ctype = multipart('file', 'p.png', png)
st, _, resp = req('/api/booklists/upload-image', token=ntok, method='POST', raw=body, ctype=ctype)
check('无权限账号上传图片也被拒 403（权限口子没漏）', st == 403, 'status=%s' % st)
st, _, resp = req('/api/booklists/upload-video', method='POST', raw=b'', ctype='application/json')
check('未登录上传被拒 401', st == 401, 'status=%s' % st)

print()
print('=' * 78)
print('E. 视频写进正文后能原样取回')
print('=' * 78)
tag = uuid.uuid4().hex[:6]
content = '# 我的视频分享\n\n![视频](%s)\n\n上面这段视频…' % (vurl or '/uploads/none.mp4')
st, _, resp = req('/api/booklists', token=TOK, method='POST',
                  data=json.dumps({'title': '测试视频文章' + tag, 'content': content, 'tag': 'share'}).encode(),
                  ctype='application/json')
a = json.loads(resp or b'{}')
aid = a.get('id')
check('带视频的文章可以发表', st == 200 and bool(aid), 'status=%s %s' % (st, resp[:160]))
if aid:
    _created['articles'].append(aid)
    st, _, resp = req('/api/booklists/%d' % aid)
    # 待审文章对普通访客不可见（返回 404），这是原有审核逻辑，本次没动
    check('待审文章对外不可见（原有审核逻辑没变）', st in (403, 404), 'status=%s' % st)
    # 正文是否被过滤，以库里存的为准（待审文章走详情接口拿不到正文）
    row = db.q("SELECT title, content, status FROM booklists WHERE id=?", (aid,), one=True)
    c = (row['content'] if row else '') or ''
    check('正文里的视频地址原样保存（没被过滤）', (vurl or 'x') in c, c[:120])
    check('正文的 Markdown 语法没被改写', '![视频](' in c, c[:120])
    check('普通会员发的文章仍是待审状态', (row['status'] if row else '') == 'pending',
          (row['status'] if row else ''))

print()
print('=' * 78)
print('清理与收尾')
print('=' * 78)
cleanup()
left_u = db.q("SELECT COUNT(*) c FROM users WHERE username LIKE 'zzam_%'", one=True)['c']
left_g = db.q("SELECT COUNT(*) c FROM user_groups WHERE code LIKE 'zzam%'", one=True)['c']
left_f = 0
for fn in _created['files']:
    if os.path.exists(os.path.join(config.IMAGE_DIR, os.path.basename(fn))):
        left_f += 1
check('临时账号无残留', left_u == 0, str(left_u))
check('临时分组无残留', left_g == 0, str(left_g))
check('测试上传的文件已清掉', left_f == 0, str(left_f))

print()
print('=' * 78)
print('通过 %d / 失败 %d' % (_pass[0], _fail[0]))
print('=' * 78)
sys.exit(1 if _fail[0] else 0)
