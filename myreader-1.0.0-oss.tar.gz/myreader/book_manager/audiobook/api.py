"""后台管理端点：/api/admin/audiobook/*

全部挂在 require_admin 之下；只新增端点，不改动任何既有路由。
"""
import json
import os
import shutil
import sys
from typing import List

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE)
sys.path.insert(0, os.path.join(BASE, "audiobook"))

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, Body  # noqa: E402

import db  # noqa: E402
from auth import require_admin  # noqa: E402
from audiobook import ai as A  # noqa: E402
from audiobook import book as B  # noqa: E402
from audiobook import mix as M  # noqa: E402
from audiobook import speech as S  # noqa: E402
from audiobook import store as ST  # noqa: E402
from audiobook import worker as W  # noqa: E402

router = APIRouter(prefix="/api/admin/audiobook", tags=["audiobook"])

BGM_DIR = os.path.join(BASE, "data", "audiobook", "bgm")


def _row2job(r):
    d = dict(r)
    for k in ("ai_chars", "bgm"):
        try:
            d[k] = json.loads(d.get(k) or ("{}" if k == "ai_chars" else "[]"))
        except Exception:
            d[k] = {} if k == "ai_chars" else []
    return d


# ---------------------------------------------------------------- 配置
@router.get("/cfg")
def get_cfg(user=Depends(require_admin)):
    c = ST.cfg_all()
    # 密钥给个掩码回显，别把明文丢到前端
    k = c.get("ai_key") or ""
    c["ai_key_set"] = bool(k)
    c["ai_key"] = (k[:6] + "…" + k[-4:]) if len(k) > 12 else ("*" * len(k))
    c["ffmpeg"] = M.available()
    c["worker"] = W.status()
    return c


@router.post("/cfg")
def set_cfg(body=Body(...), user=Depends(require_admin)):
    d = dict(body or {})
    # 掩码原样回传时不覆盖真 key
    if "ai_key" in d and ("…" in str(d["ai_key"]) or set(str(d["ai_key"])) == {"*"}):
        d.pop("ai_key")
    ST.cfg_set({k: v for k, v in d.items() if k in ST.DEFAULT_CFG})
    return {"ok": True, "cfg": get_cfg(user)}


@router.post("/ai/probe")
def ai_probe(user=Depends(require_admin)):
    cfg = ST.cfg_all()
    try:
        return A.probe(cfg)
    except Exception as e:
        raise HTTPException(400, str(e))


@router.get("/ai/models")
def ai_models(user=Depends(require_admin)):
    try:
        return {"models": A.models(ST.cfg_all())}
    except Exception as e:
        raise HTTPException(400, str(e))


# ---------------------------------------------------------------- 可选线路 / 音色
@router.get("/lines")
def lines(user=Depends(require_admin)):
    import tts
    cfg = tts.settings()
    out = []
    for l in tts.line_info(cfg, force=False):
        out.append({"id": l["id"], "name": l["name"], "model": l["model"],
                    "count": l["count"], "health": l["health"],
                    "voices": [{"voice": v["voice"], "name": v["name"],
                                "gender": v.get("gender") or ""} for v in l["voices"]]})
    return {"lines": out}


@router.get("/books")
def books(q: str = "", limit: int = 40, user=Depends(require_admin)):
    """挑书用。只在有正文的格式里找（pdf 抽不了正文，选了也做不了）。"""
    like = "%%%s%%" % (q or "").strip()
    sql = ("SELECT id,title,author,ext FROM books WHERE hidden=0 "
           "AND ext IN ('.epub','.txt','.mobi','.azw3','.azw','.html','.htm','.docx','.md','.markdown') ")
    args = ()
    if (q or "").strip():
        sql += "AND title LIKE ? "
        args = (like,)
    sql += "ORDER BY id DESC LIMIT ?"
    return {"books": [dict(r) for r in db.q(sql, args + (max(1, min(200, limit)),))]}


# ---------------------------------------------------------------- AI 角色分析（制作前先看角色）
def _pool_for(cfg, line):
    """这条线路的音色池（含性别），给角色配音色用。"""
    try:
        import tts
        for l in tts.line_info(cfg, force=False):
            if l["id"] == line:
                return [{"voice": v["voice"], "name": v["name"], "gender": v.get("gender") or ""}
                        for v in l["voices"]]
    except Exception:
        pass
    return []


@router.get("/books/{bid}/chapters")
def book_chapters(bid: int, user=Depends(require_admin)):
    """列出一本书的章节 —— 给「只做第 N 章 / 只分析第 N 章」的选择器用。

    `idx` 是**章节列表下标 + 1**（1 起含两端），和任务参数 chap_from/chap_to
    是同一个口径，也正是成品文件名前面的那个序号。
    长章会被自动切成 （1/2）（2/2） 这样的分片，这里也照原样列出来，
    免得人以为少了几章。
    """
    b = db.q("SELECT * FROM books WHERE id=?", (bid,), one=True)
    if not b:
        raise HTTPException(404, "书不存在")
    try:
        chs = B.chapters(dict(b))
    except Exception as e:
        raise HTTPException(400, str(e))
    out = []
    for c in chs:
        out.append({"idx": c["idx"] + 1,
                    "title": c.get("title") or ("第 %d 节" % (c["idx"] + 1)),
                    "chars": len(c.get("text") or ""),
                    "minutes": round(B.est_minutes(c), 1)})
    return {"book_id": bid, "title": b["title"], "count": len(out), "chapters": out}


@router.post("/analyze")
def analyze_book(body=Body(...), user=Depends(require_admin)):
    """**制作前**先把角色分析出来：有哪些角色、各自多少句台词，并给出默认音色。

    为什么要「制作前」单独做一次：正式制作时的分析是**逐章按需**做的
    （74 章的书要跑十几分钟），而人只想知道「这本书有几个角色、都谁」。
    所以这里只**采样前 N 章**——小说主要角色基本在前几章就出场了，
    采样结果会明确标注「已分析 X/Y 章」，不假装是全书统计。

    换线路或换旁白时传 reuse=true + 上次的 characters，就只重配音色、
    不再调 AI（省时间也省钱）。

    **按章分析**：传 chap_from/chap_to（1 起、含两端）就只分析这几章。
    很多小说每章人物都不同，全书一个音色表并不合适；而且人往往只想先把
    某一章做出来听听效果。分章结果按「章 → 角色 → 台词数」记账后合并，
    把上次的 characters + chap_lines 带回来即可继续累加，重复分析同一章
    是替换那一章的账，不会把台词数翻倍。
    """
    d = dict(body or {})
    bid = int(d.get("book_id") or 0)
    b = db.q("SELECT * FROM books WHERE id=?", (bid,), one=True)
    if not b:
        raise HTTPException(404, "书不存在")
    line = (d.get("line") or "").strip()
    narrator = (d.get("voice") or "").strip()
    cfg_all = ST.cfg_all()

    # ---- 累积状态 ----------------------------------------------------------
    # 分析可以**分章多次做**（每章人物不同），所以要把上一次的结果带回来。
    # ★ 关键：按「章」分别记账（chap_lines），重复分析同一章时**替换**那一章的
    #   统计，而不是累加 —— 否则重分析一次，角色的台词数就翻一倍。
    prev_chars = [c for c in (d.get("characters") or [])
                  if isinstance(c, dict) and (c.get("name") or "").strip()]
    chap_lines = {}
    for k, v in (d.get("chap_lines") or {}).items():
        try:
            k = int(k)
        except Exception:
            continue
        if isinstance(v, dict):
            chap_lines[k] = {str(n): int(x or 0) for n, x in v.items() if str(n).strip()}
    # 角色档案（性别/简介）：优先用已有的，缺了再用本轮 AI 给的补
    meta = {}
    for c in prev_chars:
        n = str(c["name"]).strip()
        meta[n] = {"gender": c.get("gender") or "未知", "desc": c.get("desc") or ""}

    sentences, sampled, total = 0, 0, 0
    reuse = bool(d.get("reuse")) and bool(prev_chars)
    try:
        fr, to = int(d.get("chap_from") or 0), int(d.get("chap_to") or 0)
    except Exception:
        fr = to = 0
    if reuse and not (fr or to):
        # 换线路/换旁白：只重配音色，不再调 AI（省时间也省钱）
        sentences = int(d.get("sentences") or 0)
        sampled = int(d.get("sampled") or 0)
        total = int(d.get("chapters_total") or 0)
    else:
        try:
            chs = B.chapters(dict(b))
        except Exception as e:
            raise HTTPException(400, str(e))
        total = len(chs)
        if fr or to:
            # 指定章节：只分析这几章（含两端，1 起）
            fr = max(1, fr or 1)
            to = min(len(chs), to or len(chs))
            if to < fr:
                raise HTTPException(400, "章节范围不合法：第 %d 到第 %d 章（共 %d 章）"
                                    % (fr, to, len(chs)))
            sel = [c for c in chs if fr <= c["idx"] + 1 <= to]
            if not sel:
                raise HTTPException(400, "第 %d-%d 章没有正文" % (fr, to))
            # 太短的章（标题页/版权页/分册封面）没有对话，跳过；全短就照原样分析
            picked = [c for c in sel if len(c.get("text") or "") >= 200] or sel
        else:
            sample = max(1, min(20, int(d.get("sample") or 3)))
            # 太短的章（标题页/版权页/分册封面）没有对话，采样时跳过，
            # 否则「分析 3 章」可能全是扉页，一个角色都找不出来。
            picked = [c for c in chs if len(c.get("text") or "") >= 200][:sample]
            if not picked:
                picked = chs[:sample]
        for c in picked:
            sents = S.split_sentences(c["text"])
            if not sents:
                continue
            sentences += len(sents)
            try:
                res = A.analyze(sents, cfg_all)
            except Exception as e:
                raise HTTPException(400, "AI 分析失败：%s" % e)
            here = {}
            for ch_ in (res.get("characters") or []):
                n = (ch_.get("name") or "").strip()
                if not n:
                    continue
                m = meta.setdefault(n, {"gender": "未知", "desc": ""})
                if (m["gender"] in ("", "未知")) and ch_.get("gender"):
                    # 同一角色在不同章被标成不同性别时，取第一个非「未知」的
                    m["gender"] = ch_["gender"]
                if not m["desc"] and ch_.get("desc"):
                    m["desc"] = ch_["desc"]
                here.setdefault(n, 0)
            for _k, sp in (res.get("speakers") or {}).items():
                sp = (sp or "").strip()
                # 只认「本章列出的角色」或「之前分析过的角色」，挡掉模型临时编出来的说话人
                if sp and sp != "旁白" and (sp in here or sp in meta):
                    meta.setdefault(sp, {"gender": "未知", "desc": ""})
                    here[sp] = here.get(sp, 0) + 1
            chap_lines[c["idx"] + 1] = here
            sampled += 1

    # ---- 汇总 --------------------------------------------------------------
    lines_sum, chap_of = {}, {}
    for k in sorted(chap_lines):
        for n, ln in chap_lines[k].items():
            lines_sum[n] = lines_sum.get(n, 0) + int(ln or 0)
            chap_of.setdefault(n, [])
            if k not in chap_of[n]:
                chap_of[n].append(k)
    for c in prev_chars:
        n = str(c["name"]).strip()
        # 只有「没进过分章账本」的老结果才用它自带的台词数，避免重复计数
        if n not in lines_sum:
            lines_sum[n] = int(c.get("lines") or 0)
        meta.setdefault(n, {"gender": c.get("gender") or "未知", "desc": c.get("desc") or ""})
    chars = []
    for n in sorted(lines_sum, key=lambda x: (-lines_sum[x], x)):
        m = meta.get(n) or {"gender": "未知", "desc": ""}
        chars.append({"name": n, "gender": m["gender"], "desc": m["desc"],
                      "lines": lines_sum[n], "chapters": sorted(chap_of.get(n, []))})

    pool = _pool_for(tts_settings(), line)
    auto = A.assign_voices(chars, pool, narrator)
    # 人已经手动改过的音色，只要在**新线路上仍然存在**就保留 ——
    # 换线路触发重配时不该把人改过的白改一遍；但如果那个音色在新线路上没有，
    # 就必须丢掉（留着就是一个合成必然失败的 id），改用自动分配的结果。
    prev = d.get("voices") or {}
    valid = set(v["voice"] for v in pool)
    for c in chars:
        keep = (prev.get(c["name"]) or {}).get("voice") if isinstance(prev.get(c["name"]), dict) else None
        if keep and keep in valid and keep != narrator:
            info = next((x for x in pool if x["voice"] == keep), {})
            c["voice"] = keep
            c["voice_name"] = info.get("name") or keep
            continue
        v = auto.get(c["name"]) or {}
        c["voice"] = v.get("voice") or ""
        c["voice_name"] = v.get("name") or ""
    nv = next((x for x in pool if x["voice"] == narrator), {})
    return {"characters": chars, "sentences": sentences, "sampled": sampled,
            "chapters_total": total, "line": line, "narrator": narrator,
            "narrator_name": nv.get("name") or narrator, "pool": len(pool),
            "reused": reuse,
            # 分章分析的状态：分析过的章号 + 每章的角色台词数（前端原样带回即可继续累加）
            "chap_lines": {str(k): chap_lines[k] for k in sorted(chap_lines)},
            "chapters_done": sorted(chap_lines),
            "chap_from": fr, "chap_to": to}


def tts_settings():
    import tts
    return tts.settings()


# ---------------------------------------------------------------- 背景音乐
def _bgm_safe(name):
    import re
    n = re.sub(r"[\\/:*?\"<>|\r\n\t]+", "_", os.path.basename(name or "")).strip(" .")
    return n


@router.get("/bgm")
def bgm_list(user=Depends(require_admin)):
    os.makedirs(BGM_DIR, exist_ok=True)
    out = []
    for n in sorted(os.listdir(BGM_DIR)):
        p = os.path.join(BGM_DIR, n)
        if os.path.isfile(p) and n.lower().endswith((".mp3", ".m4a", ".aac", ".wav", ".flac", ".ogg")):
            out.append({"name": n, "bytes": os.path.getsize(p), "seconds": M.duration(p)})
    return {"files": out, "dir": BGM_DIR}


@router.post("/bgm")
async def bgm_upload(files: List[UploadFile] = File(...), user=Depends(require_admin)):
    os.makedirs(BGM_DIR, exist_ok=True)
    out = []
    for file in (files or []):
        n = _bgm_safe(file.filename)
        if not n or not n.lower().endswith((".mp3", ".m4a", ".aac", ".wav", ".flac", ".ogg")):
            raise HTTPException(400, "只支持音频文件（mp3/m4a/aac/wav/flac/ogg）：%s" % (file.filename or ""))
        dst = os.path.join(BGM_DIR, n)
        with open(dst, "wb") as f:
            shutil.copyfileobj(file.file, f)
        # 统一转成 MP3，避免混音时遇到各种容器
        if not n.lower().endswith(".mp3"):
            try:
                M._run(["-y", "-v", "error", "-i", dst, "-codec:a", "libmp3lame",
                        "-b:a", "96k", dst + ".mp3"])
                os.replace(dst + ".mp3", dst)
            except Exception as e:
                os.remove(dst)
                raise HTTPException(400, "音频转码失败：%s" % e)
        out.append({"name": n, "seconds": M.duration(dst)})
    return {"ok": True, "files": out}


@router.delete("/bgm/{name}")
def bgm_del(name: str, user=Depends(require_admin)):
    p = os.path.join(BGM_DIR, _bgm_safe(name))
    if os.path.isfile(p):
        os.remove(p)
    return {"ok": True}


@router.get("/bgm/file/{name}")
def bgm_get(name: str, user=Depends(require_admin)):
    """试听背景音乐。"""
    from fastapi.responses import FileResponse
    p = os.path.join(BGM_DIR, _bgm_safe(name))
    if not os.path.isfile(p):
        raise HTTPException(404, "没有这个文件")
    return FileResponse(p, media_type="audio/mpeg")


@router.post("/bgm/from-dav")
def bgm_from_dav(body=Body(...), user=Depends(require_admin)):
    """把 NAS（WebDAV）上的音频取到本地 BGM 目录，之后就能像普通背景音乐一样勾选。

    ★ 为什么要先落地到本地：混音是 ffmpeg 读本地文件（mix.mix_bgm），
      直接把远端路径塞进任务里跑，跑到混音那一步才会失败 —— 那时配音已经合成完了。
      所以在这里就下载并校验字节数，缺文件/下载不全当场报错。
    """
    import dav as D
    src = (dict(body or {}).get("path") or "").strip()
    if not src.startswith("/"):
        raise HTTPException(400, "请填 NAS 上的绝对路径（以 / 开头）")
    name = _bgm_safe(src)
    if not name.lower().endswith((".mp3", ".m4a", ".aac", ".wav", ".flac", ".ogg")):
        raise HTTPException(400, "只支持音频文件（mp3/m4a/aac/wav/flac/ogg）")
    os.makedirs(BGM_DIR, exist_ok=True)
    dst = os.path.join(BGM_DIR, name)
    if not D.exists(src):
        raise HTTPException(404, "NAS 上没有这个文件：%s" % src)
    try:
        n = D.get(src, dst)
    except Exception as e:
        raise HTTPException(400, "从 NAS 导入失败：%s" % e)
    # 非 mp3 统一转码，避免混音时遇到各种容器（与上传那条路保持一致）
    if not name.lower().endswith(".mp3"):
        try:
            M._run(["-y", "-v", "error", "-i", dst, "-codec:a", "libmp3lame",
                    "-b:a", "96k", dst + ".mp3"])
            os.replace(dst + ".mp3", dst)
        except Exception as e:
            try:
                os.remove(dst)
            except OSError:
                pass
            raise HTTPException(400, "音频转码失败：%s" % e)
    return {"ok": True, "name": name, "bytes": os.path.getsize(dst),
            "seconds": M.duration(dst)}


# ---------------------------------------------------------------- 任务
@router.post("/jobs")
def job_create(body=Body(...), user=Depends(require_admin)):
    d = dict(body or {})
    try:
        bid = int(d.get("book_id"))
    except Exception:
        raise HTTPException(400, "没选书")
    b = db.q("SELECT id,title,ext FROM books WHERE id=?", (bid,), one=True)
    if not b:
        raise HTTPException(404, "书不存在")
    if not (d.get("line") or "").strip():
        raise HTTPException(400, "没选线路")
    if not (d.get("voice") or "").strip():
        raise HTTPException(400, "没选音色（旁白）")
    if not M.available():
        raise HTTPException(500, "ffmpeg 不可用，无法转 MP3")
    try:
        cfr = max(0, int(d.get("chap_from") or 0))
        cto = max(0, int(d.get("chap_to") or 0))
    except Exception:
        raise HTTPException(400, "章节范围不是数字")
    if cfr and cto and cto < cfr:
        raise HTTPException(400, "章节范围反了：第 %d 到第 %d 章" % (cfr, cto))
    dest_root = (ST.cfg_get("webdav_root") or "").rstrip("/")
    dest = (d.get("dest") or "").strip() or (dest_root + "/" + B._safe(b["title"]))
    jid = ST.job_new(bid, b["title"], d["line"], d["voice"],
                     int(d.get("chapters_per_file") or 1),
                     bool(d.get("ai_enabled")), d.get("ai_chars") or {},
                     d.get("bgm") or [], d.get("bgm_volume"), dest, user["id"],
                     gap_ms=d.get("gap_ms"), chap_gap_ms=d.get("chap_gap_ms"),
                     skip_front=1 if d.get("skip_front", True) else 0,
                     split_mode=("balanced" if d.get("split_mode") == "balanced" else "chapters"),
                     target_min=d.get("target_min"), max_min=d.get("max_min"),
                     chap_from=cfr, chap_to=cto,
                     to_lib=1 if d.get("to_lib") else 0,
                     lib_cat=int(d.get("lib_cat") or 0))
    W._wake.set()
    return {"ok": True, "id": jid}


@router.get("/jobs")
def job_list(limit: int = 50, user=Depends(require_admin)):
    W.start()
    out = []
    for r in ST.job_list(limit=max(1, min(200, limit))):
        d = _row2job(r)
        d.pop("ai_chars", None)
        out.append(d)
    return {"jobs": out, "worker": W.status()}


@router.get("/jobs/{jid}")
def job_get(jid: int, user=Depends(require_admin)):
    r = ST.job_get(jid)
    if not r:
        raise HTTPException(404, "任务不存在")
    d = _row2job(r)
    d["files"] = [dict(x) for x in ST.files_of(jid)]
    d["segs"] = ST.seg_count(jid)
    return d


@router.post("/jobs/{jid}/bgm")
def job_bgm(jid: int, body=Body(...), user=Depends(require_admin)):
    """换背景音乐 / 音量，然后重做整本 —— **保留已合成的配音**。

    ★ 这个路由必须声明在 `/jobs/{jid}/{act}` **之前**：后者是第一段通配，
      会把 `/jobs/35/bgm` 当成 act="bgm" 吃掉并回「不支持的操作」—— 实测踩过。
      同理，任何 /jobs/{jid}/xxx 形式的新路由都要放到通配路由前面。

    ★ 与 act=retry 的关键区别：retry 走 file_clear_from(1)，会把 ab_seg 一起删掉，
      于是整本书的配音要重新合成（几小时）。这里只把 ab_file 置回 pending，
      ab_seg 与本地缓存都留着，工作线程重跑时命中缓存，只重做
      「拼接 → 混音 → 上传」。实测从「小时级」变成「分钟级」。
    """
    r = ST.job_get(jid)
    if not r:
        raise HTTPException(404, "任务不存在")
    d = dict(body or {})
    bgm = d.get("bgm")
    if bgm is None:
        bgm = []
    if not isinstance(bgm, list):
        raise HTTPException(400, "bgm 必须是路径数组")
    bgm = [str(x).strip() for x in bgm if str(x or "").strip()]
    # 音频文件必须现在就在本地，否则任务跑到混音那一步才失败（那时配音已经合成完了）
    for p in bgm:
        if not os.path.isfile(p):
            raise HTTPException(400, "背景音乐文件不存在：%s" % p)
    try:
        vol = float(r["bgm_volume"] if d.get("bgm_volume") is None else d["bgm_volume"])
    except Exception:
        raise HTTPException(400, "音量不是数字")
    if not (0 <= vol <= 1):
        raise HTTPException(400, "音量要在 0~100% 之间")
    ST.job_set(jid, bgm=json.dumps(bgm, ensure_ascii=False), bgm_volume=vol)
    ST.files_redo(jid)
    ST.job_set(jid, status="queued", stage="换背景音乐后重做", error="", done_files=0)
    W._wake.set()
    return {"ok": True, "bgm": bgm, "bgm_volume": vol,
            "seg_kept": ST.seg_count(jid)}


@router.post("/jobs/{jid}/{act}")
def job_act(jid: int, act: str, user=Depends(require_admin)):
    r = ST.job_get(jid)
    if not r:
        raise HTTPException(404, "任务不存在")
    if act not in ("pause", "resume", "cancel", "retry", "delete"):
        raise HTTPException(400, "不支持的操作")
    if act == "delete":
        # ★ 不管什么状态都先置取消标志。只对 running 置的话，"排队中"的任务
        #   可能已经工作线程取走并在合成，删完 ab_job 它还在写 ab_seg。
        W.control(jid, "cancel")
        ST.job_del(jid)
        W._cleanup(jid)
        return {"ok": True}
    if act == "retry":
        ST.file_clear_from(jid, 1)
        ST.job_set(jid, status="queued", error="", stage="重新开始", done_files=0)
        W._wake.set()
        return {"ok": True}
    W.control(jid, act)
    return {"ok": True, "status": ST.job_get(jid)["status"]}


@router.post("/jobs/{jid}/file/{seq}/retry")
def file_retry(jid: int, seq: int, user=Depends(require_admin)):
    """只重做某个文件（比如某一章的角色分配想改一下）。"""
    r = ST.job_get(jid)
    if not r:
        raise HTTPException(404, "任务不存在")
    ST.file_clear_from(jid, seq)
    ST.job_set(jid, status="queued", error="", stage="重做第 %d 个文件" % seq, done_files=seq - 1)
    W._wake.set()
    return {"ok": True}


@router.post("/jobs/{jid}/chars")
def job_chars(jid: int, body=Body(...), user=Depends(require_admin)):
    """人工覆盖角色→音色。改完需要重做对应的文件。"""
    r = ST.job_get(jid)
    if not r:
        raise HTTPException(404, "任务不存在")
    try:
        cur = json.loads(r["ai_chars"] or "{}") or {}
    except Exception:
        cur = {}
    voices = cur.get("voices") or {}
    for name, v in (dict(body or {}).get("voices") or {}).items():
        if isinstance(v, dict) and v.get("voice"):
            voices[name] = {"voice": v["voice"], "name": v.get("name") or v["voice"]}
    cur["voices"] = voices
    ST.job_set(jid, ai_chars=json.dumps(cur, ensure_ascii=False))
    return {"ok": True, "voices": voices}


@router.get("/jobs/{jid}/chars")
def job_chars_get(jid: int, user=Depends(require_admin)):
    r = ST.job_get(jid)
    if not r:
        raise HTTPException(404, "任务不存在")
    try:
        cur = json.loads(r["ai_chars"] or "{}") or {}
    except Exception:
        cur = {}
    # 把每章识别到的角色并起来，并统计**实际分配出去的台词句数**（来自 ab_seg，
    # 那是真正合成过的东西，比分析阶段的推测可靠）。
    chars = {}
    for ch in (cur.get("chapters") or {}).values():
        for c in (ch.get("characters") or []):
            n = c.get("name")
            if n and n not in chars:
                chars[n] = {"name": n, "gender": c.get("gender") or "未知",
                            "desc": c.get("desc") or "", "lines": 0}
    for row in db.q("SELECT speaker, COUNT(*) n FROM ab_seg WHERE job_id=? GROUP BY speaker", (jid,)):
        sp = (row["speaker"] or "").strip()
        if not sp or sp == "旁白":
            continue
        if sp not in chars:
            chars[sp] = {"name": sp, "gender": "未知", "desc": "", "lines": 0}
        chars[sp]["lines"] = row["n"]
    out = sorted(chars.values(), key=lambda x: (-x["lines"], x["name"]))
    # 旁白单独统计，前端要显示它占了多少句
    nb = db.q("SELECT COUNT(*) c FROM ab_seg WHERE job_id=? AND (speaker='' OR speaker='旁白')",
              (jid,), one=True)["c"]
    return {"characters": out, "voices": cur.get("voices") or {},
            "narrator_lines": nb, "total_segs": ST.seg_count(jid)}


@router.get("/progress/{jid}")
def progress(jid: int, user=Depends(require_admin)):
    r = ST.job_get(jid)
    if not r:
        raise HTTPException(404, "任务不存在")
    return _row2job(r)


# ★ 在模块导入时（= 主应用启动时）就把制作线程拉起来。
#   这样服务重启后，上次卡在 running 的任务会被改回 queued 并自动接着跑
#   （见 worker.start 的注释），不需要有人先去点一下后台页面。
#   线程是 daemon，主进程退出时跟着结束，不会拖住 systemd。
try:
    W.start()
except Exception as _e:      # pragma: no cover
    import logging as _lg
    _lg.getLogger("bookmgr").warning("有声书制作线程启动失败：%s", _e)
