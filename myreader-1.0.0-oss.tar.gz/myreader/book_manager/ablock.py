"""有声阅读的单端互斥锁。

需求：**同一个账号多端登录时，只有一个终端能用有声阅读**，
与听书（`listen_session` + `app.py` 里的 `_listen_*`）行为一致。

★ 为什么另起一把锁、而不是复用 listen_session：
  1) 两件事的成本完全不同 —— 听书贵在服务端**逐句现场合成**（多端会成倍烧 GPU），
     有声书只是取现成的 mp3 文件。硬并成一把锁会让「手机听书 + 平板听有声书」
     这种互不干扰的用法也被拦，属于凭空收窄现有功能。
  2) 听书那套已经跑在生产上，动它就要重新验证一圈；独立成表最安全。

设计（与听书刻意保持一致，前端也就能用同一套交互）：
  * **租约制**：每次取票/心跳刷新 `ts`，超过 LEASE 秒没动静即视为该终端已停止。
    所以关页面、断网、进程被杀都不会把账号永久锁死。
  * **抢占**：别人在用时返回 409 并说明「正在哪台设备上用」，
    用户在界面上确认「在这台设备上继续」才带 take=1 抢过来。
  * **实时踢人**：靠 SSE 长连接推送，而不是等下一次心跳 ——
    网页切到后台时 setInterval 会被浏览器限流到一分钟一次，轮询根本来不及，
    对方手上还缓冲着音频，等它自己发现就已经重叠好几秒了。
  * **释放宽限期**：停止播放时客户端会并发发出「存进度」和「释放会话」两个请求，
    顺序没保证。释放先把会话删了，后到的进度请求又 INSERT 回去 ——
    用户一走账号反而被自己锁住。所以记下刚释放的 sid，宽限期内拒绝用同一个 sid 重建。
"""
import asyncio  # noqa: F401  （类型注释用，真正的 loop 由调用方注入）
import threading
import time

from fastapi import HTTPException  # noqa: E402

import db  # noqa: E402

LEASE = 40                # 秒。心跳断这么久就认为该终端已停止
RELEASE_GRACE = 15        # 秒。刚释放的 sid 在此期内不许把会话重建回来

_watchers = {}            # user_id -> set(asyncio.Queue)
MAIN_LOOP = None          # 主事件循环，供线程池里的线程安全投递事件
_released = {}            # (user_id, sid) -> 释放时刻
_released_lock = threading.Lock()


def row(user_id):
    return db.q("SELECT * FROM ab_session WHERE user_id=?", (user_id,), one=True)


def push(user_id, payload):
    """从任意线程把一条事件投给该账号的长连接。

    ★ 必须走 call_soon_threadsafe：FastAPI 的同步 def 路由跑在线程池里，
    直接往 asyncio.Queue 里 put_nowait 属于跨线程操作事件循环，
    轻则丢事件、重则写坏内部状态。
    """
    qs = _watchers.get(user_id)
    if not qs:
        return
    for q in list(qs):
        try:
            if MAIN_LOOP is not None:
                MAIN_LOOP.call_soon_threadsafe(q.put_nowait, payload)
            else:
                q.put_nowait(payload)
        except Exception:
            pass


def notify_kick(user_id, keep_sid, reason):
    """通知该账号下除 keep_sid 之外的所有终端：锁已经不在你手上了"""
    push(user_id, {"sid": keep_sid, "reason": reason})


def _lib_title(lib_id):
    try:
        r = db.q("SELECT title FROM ab_lib WHERE id=?", (lib_id,), one=True)
        return r["title"] if r else ""
    except Exception:
        return ""


def touch(user, lib_id, sid, request=None, take=False):
    """有声阅读互斥：一个账号同一时间只允许一个终端在放。

    每次取票/心跳都刷新一次租约，超过 LEASE 秒没心跳即自动释放。
    take=True 表示用户已确认「在这台设备上继续」，抢占对方。
    返回 True 表示这次是**抢过来的**（调用方据此把对方踢下线）。
    """
    sid = (sid or "").strip()
    if not sid:
        raise HTTPException(400, "缺少会话标识")
    now = time.time()
    r = row(user["id"])
    # 刚被释放掉的会话，不许被在途的进度/心跳请求复活
    if not r:
        with _released_lock:
            rel = _released.get((user["id"], sid))
        if rel and (now - rel) < RELEASE_GRACE:
            return False
    stolen = False
    if r and r["sid"] and r["sid"] != sid and (now - float(r["ts"] or 0)) < LEASE:
        if not take:
            t = _lib_title(r["lib_id"])
            raise HTTPException(409, "该账号正在另一台设备上收听《%s》。\n"
                                     "同一账号同一时间只能听一本有声书，请先在那边停止，"
                                     "或选择在这台设备上继续听。" % (t or "未知有声书"))
        stolen = True
        notify_kick(
            user["id"], sid,
            "该账号已在另一台设备上继续收听，本机已停止播放。\n"
            "同一账号同一时间只能听一本有声书。")
    ua = ip = ""
    if request is not None:
        ua = (request.headers.get("user-agent") or "")[:120]
        ip = (request.client.host if request.client else "")
    db.ex("INSERT INTO ab_session (user_id,lib_id,sid,ua,ip,started_at,ts) "
          "VALUES (?,?,?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET "
          "lib_id=excluded.lib_id, sid=excluded.sid, ua=excluded.ua, ip=excluded.ip, ts=excluded.ts, "
          "started_at=CASE WHEN ab_session.sid=excluded.sid THEN ab_session.started_at "
          "ELSE excluded.started_at END",
          (user["id"], lib_id, sid, ua, ip, db.now(), now))
    return stolen


def release(user, sid=None):
    """停止播放时主动释放，让别人能立刻用（不必等租约到期）。

    同时把这个 sid 记进宽限期表，防止在途的进度/心跳请求把刚删掉的会话 INSERT 回来。
    """
    r = row(user["id"])
    if r and (not sid or not r["sid"] or r["sid"] == sid):
        db.ex("DELETE FROM ab_session WHERE user_id=?", (user["id"],))
        if sid:
            now = time.time()
            with _released_lock:
                _released[(user["id"], sid)] = now
                for k, v in list(_released.items()):
                    if now - v > RELEASE_GRACE:
                        _released.pop(k, None)
        return True
    return False


def holder(user_id, sid=None):
    """当前占用者（排除自己），给前端提示用"""
    r = row(user_id)
    if not r or not r["sid"] or r["sid"] == (sid or ""):
        return None
    if (time.time() - float(r["ts"] or 0)) >= LEASE:
        return None
    return {"lib_id": r["lib_id"], "title": _lib_title(r["lib_id"]),
            "ua": r["ua"] or "", "ip": r["ip"] or "", "started_at": r["started_at"]}
