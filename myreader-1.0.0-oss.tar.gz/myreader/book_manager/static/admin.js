const TOKEN = localStorage.getItem('bm_token') || '';
const USER = JSON.parse(localStorage.getItem('bm_user') || 'null');
let users = [];
let groups = [];

// 把后端错误体变成人能看懂的一句话。
// ★ 坑：FastAPI 的校验错误（422）detail 是【对象数组】，直接 new Error(detail)
//   会被字符串化成「[object Object]」，用户完全看不出哪里错了（背景音乐导入就踩过）。
function apiErrText(d, status) {
  const det = d && (d.detail != null ? d.detail : d.message);
  if (typeof det === 'string' && det) return det;
  if (Array.isArray(det)) {
    const parts = det.map(x => {
      if (typeof x === 'string') return x;
      if (x && typeof x === 'object') {
        const loc = Array.isArray(x.loc) ? x.loc.filter(k => k !== 'body' && k !== 'query').join('.') : '';
        return (loc ? loc + '：' : '') + (x.msg || JSON.stringify(x));
      }
      return String(x);
    }).filter(Boolean);
    if (parts.length) return parts.join('；');
  } else if (det && typeof det === 'object') {
    return det.message || det.msg || JSON.stringify(det);
  }
  // 后端什么都没给：返回空串，由调用方给各自合适的兜底文案
  // （登录 401 要说「用户名或密码错误」，别的接口说 HTTP 状态码）
  return '';
}
function api(path, opts = {}) {
  const headers = opts.headers || {};
  if (TOKEN) headers['Authorization'] = 'Bearer ' + TOKEN;
  return fetch(path, { ...opts, headers }).then(async r => {
    if (r.status === 401) { location.href = '/'; throw new Error('未登录'); }
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(apiErrText(d, r.status) || ('请求失败 ' + r.status));
    return d;
  });
}
function toast(msg) {
  const t = document.getElementById('toast'); t.textContent = msg; t.classList.add('show');
  clearTimeout(t._tm); t._tm = setTimeout(() => t.classList.remove('show'), 2000);
}
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function openModal(html, wide) { document.getElementById('modal-mask').innerHTML = '<div class="modal' + (wide ? ' wide' : '') + '">' + html + '</div>'; document.getElementById('modal-mask').classList.remove('hidden'); }
function closeModal() { document.getElementById('modal-mask').classList.add('hidden'); }

async function init() {
  if (!TOKEN || !USER || USER.role !== 'admin') { location.href = '/'; return; }
  document.getElementById('app').classList.remove('hidden');
  await loadStats(); await loadUsers(); await loadGroups(); await loadLinks(); await loadSyncStatus();
  await loadXlStatus(); await loadXlLog();
  await loadConfig(); await loadLinkBase(); await loadPending(); await loadEnrichStatus();
  await loadSources(); await loadAds(); await loadIntro(); await loadWelcome();
  await loadTtsSettings();
  await loadBooklistBadge();
}
async function loadStats() {
  const s = await api('/api/admin/stats');
  const gb = ((s.books_size || 0) / 1e9).toFixed(1);
  document.getElementById('stats').innerHTML = [
    ['图书', s.books + ' 本'], ['容量', gb + ' GB'], ['用户', s.users + ' 人'],
    ['书架收藏', s.shelves + ' 条'], ['分享', s.shares + ' 条'], ['阅读进度', s.progress + ' 条']
  ].map(x => `<div class="card center"><div style="font-size:24px;font-weight:800;background:var(--grad);-webkit-background-clip:text;background-clip:text;color:transparent">${x[1]}</div><div class="muted">${x[0]}</div></div>`).join('');
  document.getElementById('cat-stats').innerHTML = s.categories.slice(0, 24).map(c =>
    // ★ c.name 可能是 null（书库里存在 category 为空的书，实测有 3 本）：
    //   以前直接 c.name.replace(...) 会抛 TypeError，把整个 loadStats 打断，
    //   结果「分类统计」和它下面本该渲染的内容全都不出来。
    `<span class="tag">${esc(String(c.name || '未分类').replace(/^[A-Z0-9]+_/, ''))} ${c.count}</span>`).join('');
}
let userPage = 1;
let userGroupFilter = '';
let userSel = new Set();
const USER_PAGE_SIZE = 10;
// 用户列表排序：'' = 默认（后端顺序：注册时间倒序）
let userSortKey = '';
let userSortDir = 'desc';
// 用户搜索关键词：用户名 / 昵称 / 邮箱 / 手机号 / 分组，大小写不敏感。
// 走客户端过滤——loadUsers() 本来就是一次全量拉取（分页只在前端做），
// 所以搜索可以做到即时响应，不用为每个字发一次请求。
let userSearch = '';
const USER_SORT_LABEL = { leaves: '树叶', shelf_count: '收藏', last_login: '最后登录',
                          created_at: '注册时间', reading_seconds: '阅读时长' };
function userSortValue(u, k) {
  if (k === 'last_login') return String(u.last_login || '');
  if (k === 'created_at') return String(u.created_at || '');
  return Number(u[k] || 0);
}
function userMatchesSearch(u) {
  if (!userSearch) return true;
  const kw = userSearch.toLowerCase();
  const hay = [u.username, u.name, u.email, u.phone, u.group_name]
    .filter(Boolean).join(' ').toLowerCase();
  return hay.indexOf(kw) >= 0;
}
function sortedUsers() {
  if (!userSortKey) return users;
  const k = userSortKey, dir = userSortDir === 'asc' ? 1 : -1;
  return users.slice().sort((a, b) => {
    const va = userSortValue(a, k), vb = userSortValue(b, k);
    const c = va < vb ? -1 : va > vb ? 1 : 0;
    if (c === 0) return b.id - a.id;      // 同值时按 id 倒序，保证顺序稳定
    return c * dir;
  });
}
function sortUsersBy(key) {
  if (!USER_SORT_LABEL[key]) return;
  if (userSortKey === key) {
    userSortDir = userSortDir === 'desc' ? 'asc' : 'desc';   // 再点一次换方向
  } else {
    // 首次点数值列默认从大到小（最想看的排最前）；日期列同理，最近的在最前
    userSortKey = key;
    userSortDir = 'desc';
  }
  userPage = 1;
  renderUsers();
}
// 当前可见（已过搜索）的用户，按当前排序。分页、全选、结果计数都基于它，
// 否则搜索之后「全选本页」会勾到已被筛掉、根本没显示出来的用户。
function visibleUsers() {
  const list = sortedUsers();
  return userSearch ? list.filter(userMatchesSearch) : list;
}
function setUserSearch(v) {
  userSearch = String(v || '').trim();
  userPage = 1;
  renderUsers();
}
function clearUserSearch() {
  const el = document.getElementById('user-search');
  if (el) el.value = '';
  setUserSearch('');
  if (el) el.focus();
}
function flipUserSortDir() {
  if (!userSortKey) { sortUsersBy('leaves'); return; }
  userSortDir = userSortDir === 'asc' ? 'desc' : 'asc';
  userPage = 1;
  renderUsers();
}
function resetUserSort() {
  userSortKey = '';
  userSortDir = 'desc';
  userPage = 1;
  renderUsers();
}
function userSortArrow(key) {
  if (userSortKey !== key) return '⇅';
  return userSortDir === 'asc' ? '▲' : '▼';
}
async function loadUsers() {
  const q = userGroupFilter ? '?group_id=' + encodeURIComponent(userGroupFilter) : '';
  users = await api('/api/admin/users' + q);
  userPage = 1;
  userSel = new Set();
  renderUsers();
}
function fmtHours(sec) {
  sec = sec || 0;
  if (!sec) return '—';
  const h = sec / 3600;
  if (h < 0.1) return '<0.1 小时';
  return h.toFixed(1) + ' 小时';
}
// 最后登录：列表里只显示到日，鼠标悬停看完整时间。
// 值为空 = 没有登录记录。说明：审计日志只保留 30 天，本列首次上线时按它回填，
// 所以「用户系统上线(2026-09-21)前注册且此后没再登录」的账号会是 —；
// 之后每次登录都会刷新本列，不再随时间丢失。
function fmtLastLogin(u) {
  const t = u.last_login;
  if (!t) return '<span title="没有登录记录">—</span>';
  return `<span title="最后登录 ${esc(t)}">${esc(String(t).slice(0, 10))}</span>`;
}
// 收藏数做成可点的：点开看这个用户具体收藏了哪些书（只读，不改任何状态）
function shelfCell(u, bare) {
  const n = u.shelf_count || 0;
  if (!n) return bare ? '0' : '0 本';
  return `<span class="link-num" onclick="showUserShelf(${u.id})" title="点击查看收藏的书">${bare ? n : n + ' 本'}</span>`;
}
async function showUserShelf(uid) {
  let r;
  try { r = await api('/api/admin/users/' + uid + '/shelf'); }
  catch (e) { return toast(e.message); }
  const items = r.items || [];
  const body = items.length
    ? `<div class="ushelf-list">${items.map((b, i) => `
        <div class="ushelf-item">
          <span class="ushelf-n">${i + 1}</span>
          <div class="ushelf-t">
            <div class="ushelf-title">${esc(b.title)}</div>
            <div class="ushelf-meta">${esc(b.author || '未知作者')}${b.collection_name ? ' · ' + esc(b.collection_name) : ''}${b.added_at ? ' · ' + esc(String(b.added_at).slice(0, 10)) : ''}</div>
          </div>
        </div>`).join('')}</div>`
    : '<p class="muted" style="margin:0;font-size:13px">该用户还没有收藏任何书</p>';
  openModal(`<button class="close" onclick="closeModal()">✕</button>
    <h3>${esc(r.name || r.username)} 的收藏（${r.count} 本）</h3>
    <p class="muted" style="margin:0 0 6px;font-size:12px">账号 ${esc(r.username)}</p>${body}`, true);
}
function renderUsers() {
  const wrap = document.getElementById('user-list');
  const list = visibleUsers();
  const total = list.length;
  const pages = Math.max(1, Math.ceil(total / USER_PAGE_SIZE));
  if (userPage > pages) userPage = pages;
  updateSortBar();
  if (!total) {
    const msg = userSearch
      ? `没有找到匹配「${esc(userSearch)}」的用户`
      : '暂无用户';
    wrap.innerHTML = `<p class="muted" style="margin:0;font-size:13px">${msg}</p>`;
    updateBatchBar(); return;
  }
  updateSearchInfo(total);
  const slice = list.slice((userPage - 1) * USER_PAGE_SIZE, userPage * USER_PAGE_SIZE);
  const allChecked = slice.length && slice.every(u => userSel.has(u.id));
  const th = (key, label, style) => `<th class="sortable${userSortKey === key ? ' sorted' : ''}"`
    + (style ? ` style="${style}"` : '')
    + ` onclick="sortUsersBy('${key}')" title="点击按${label}排序（再点一次换方向）"`
    + `>${label}<span class="sort-arrow">${userSortArrow(key)}</span></th>`;
  const urow = u => `<tr>
        <td><input type="checkbox" ${userSel.has(u.id) ? 'checked' : ''} onclick="toggleUserSel(${u.id}, this.checked)"></td>
        <td><b>${esc(u.username)}</b>${u.role === 'admin' ? ' <span class="badge ok">👑</span>' : ''}${u.enabled ? '' : ' <span class="badge no" title="账号已停用">禁用</span>'}</td>
        <td>${esc(u.name || '—')}</td>
        <td><span class="tag">${esc(u.group_name || '未分组')}</span></td>
        <td>${u.leaves ?? 0}🌿</td>
        <td>${shelfCell(u, true)}</td>
        <td class="muted">${fmtLastLogin(u)}</td>
        <td class="muted">${esc((u.created_at || '').slice(0, 10))}</td>
        <td class="muted">${fmtHours(u.reading_seconds)}</td>
        <td><button class="btn ghost sm" onclick="editUser(${u.id})">编辑</button></td>
      </tr>`;
  // 窄屏版式：10 列的表在手机上要横向拖 370px，「编辑」按钮根本看不到。
  // 卡片把同一批信息拆成几行，勾选框和编辑按钮固定在第一行。
  // 排序原本只能点表头，卡片没有表头，所以补一个下拉选择器（只在窄屏显示）。
  const ucard = u => `<div class="usr-card">
      <div class="usr-head">
        <input type="checkbox" ${userSel.has(u.id) ? 'checked' : ''} onclick="toggleUserSel(${u.id}, this.checked)">
        <b>${esc(u.username)}</b>${u.role === 'admin' ? '<span class="badge ok">👑</span>' : ''}${u.enabled ? '' : '<span class="badge no" title="账号已停用">禁用</span>'}
        <span class="tag">${esc(u.group_name || '未分组')}</span>
        <span class="usr-leaves">${u.leaves ?? 0}🌿</span>
        <button class="btn ghost sm" onclick="editUser(${u.id})">编辑</button>
      </div>
      <div class="usr-row"><span class="usr-k">昵称</span><span class="usr-v">${esc(u.name || '—')}</span></div>
      <div class="usr-row"><span class="usr-k">收藏</span><span class="usr-v">${shelfCell(u)}</span>
        <span class="usr-k">最后登录</span><span class="usr-v muted">${fmtLastLogin(u)}</span></div>
      <div class="usr-row"><span class="usr-k">注册</span><span class="usr-v muted">${esc((u.created_at || '').slice(0, 10))}</span>
        <span class="usr-k">时长</span><span class="usr-v muted">${fmtHours(u.reading_seconds)}</span></div>
    </div>`;
  const sortOpts = Object.keys(USER_SORT_LABEL).map(k =>
    `<option value="${k}" ${userSortKey === k ? 'selected' : ''}>按${USER_SORT_LABEL[k]}</option>`).join('');
  wrap.innerHTML = `<div class="usr-table-wrap" style="overflow-x:auto">
    <table class="user-table">
      <thead><tr><th style="width:34px"><input type="checkbox" ${allChecked ? 'checked' : ''} onclick="toggleAllUsers(this.checked)"></th><th>用户名</th><th>昵称</th><th>分组</th>${th('leaves', '树叶')}${th('shelf_count', '收藏')}${th('last_login', '最后登录')}${th('created_at', '注册时间')}${th('reading_seconds', '阅读时长')}<th></th></tr></thead>
      <tbody>${slice.map(urow).join('')}</tbody>
    </table></div>
    <div class="usr-cards">
      <div class="usr-sort">
        <select onchange="sortUsersBy(this.value)">
          <option value="" ${userSortKey ? '' : 'selected'}>默认排序</option>${sortOpts}
        </select>
        <button class="btn ghost sm" onclick="flipUserSortDir()">${userSortDir === 'asc' ? '升序 ▲' : '降序 ▼'}</button>
        <span class="usr-sel-all">
          <input type="checkbox" ${allChecked ? 'checked' : ''} onclick="toggleAllUsers(this.checked)">全选本页
        </span>
      </div>
      ${slice.map(ucard).join('')}
    </div>
    <div class="pagination" style="margin-top:12px;flex-wrap:wrap">${pages > 1 ? `
      <button ${userPage <= 1 ? 'disabled' : ''} onclick="goUserPage(${userPage - 1})">上一页</button>
      <span style="display:inline-flex;align-items:center;gap:6px;font-size:14px;color:var(--muted)">第
        <input id="user-pager-input" type="number" min="1" max="${pages}" value="${userPage}"
          style="width:64px;padding:6px 8px;border:1.5px solid var(--line);border-radius:8px;text-align:center;font-size:14px"
          onkeydown="if(event.key==='Enter')jumpUserPage()">
        / ${pages} 页</span>
      <button class="btn sm" onclick="jumpUserPage()">跳转</button>
      <button ${userPage >= pages ? 'disabled' : ''} onclick="goUserPage(${userPage + 1})">下一页</button>` : ''}</div>`;
  updateBatchBar();
}
function updateSortBar() {
  const bar = document.getElementById('user-sort-bar');
  const info = document.getElementById('user-sort-info');
  if (!bar || !info) return;
  if (!userSortKey) { bar.style.display = 'none'; info.textContent = ''; return; }
  bar.style.display = 'flex';
  info.textContent = `当前按「${USER_SORT_LABEL[userSortKey]}」${userSortDir === 'asc' ? '升序' : '降序'}排列`;
}
// 搜索时在输入框旁显示「匹配 N 个用户」，让管理员一眼看出过滤生效了
function updateSearchInfo(n) {
  const el = document.getElementById('user-search-info');
  if (!el) return;
  if (!userSearch) { el.style.display = 'none'; el.textContent = ''; return; }
  el.style.display = 'inline';
  el.textContent = `匹配 ${n} 个用户`;
}
function goUserPage(p) { userPage = p; renderUsers(); }
function jumpUserPage() {
  const inp = document.getElementById('user-pager-input');
  const pages = Math.max(1, Math.ceil(visibleUsers().length / USER_PAGE_SIZE));
  let n = parseInt(inp && inp.value, 10);
  if (!n || n < 1) n = 1;
  if (n > pages) n = pages;
  goUserPage(n);
}
function toggleUserSel(id, checked) {
  if (checked) userSel.add(id); else userSel.delete(id);
  const slice = visibleUsers().slice((userPage - 1) * USER_PAGE_SIZE, userPage * USER_PAGE_SIZE);
  const headCb = document.querySelector('#user-list thead input[type=checkbox]');
  if (headCb) headCb.checked = slice.length && slice.every(u => userSel.has(u.id));
  updateBatchBar();
}
function toggleAllUsers(checked) {
  const slice = visibleUsers().slice((userPage - 1) * USER_PAGE_SIZE, userPage * USER_PAGE_SIZE);
  slice.forEach(u => { if (checked) userSel.add(u.id); else userSel.delete(u.id); });
  renderUsers();
}
function clearUserSel() {
  userSel = new Set();
  renderUsers();
}
function updateBatchBar() {
  const bar = document.getElementById('user-batch-bar');
  const cnt = document.getElementById('user-batch-count');
  if (!bar || !cnt) return;
  const n = userSel.size;
  bar.style.display = n ? 'flex' : 'none';
  cnt.textContent = n ? '已选 ' + n + ' 个用户' : '';
}
async function batchUsers(action) {
  const ids = Array.from(userSel);
  if (!ids.length) { toast('请先勾选用户'); return; }
  const label = { enable: '启用', disable: '停用', delete: '删除' }[action] || action;
  if (action === 'delete' && !confirm(`确认删除选中的 ${ids.length} 个用户及其数据？此操作不可恢复`)) return;
  try {
    await api('/api/admin/users/batch', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action, user_ids: ids }) });
    toast('已' + label + ' ' + ids.length + ' 个用户');
    loadUsers();
  } catch (e) { toast(e.message); }
}
function filterUsersByGroup(val) {
  userGroupFilter = val;
  loadUsers();
}
const PERM_NAMES = { share: '分享', edit: '编辑', cover: '传封面', download: '下载', delete: '删除', private_shelf: '私人书架', convert: '格式转换', listen: '听书', public_library: '公共书库', publish_booklist: '发表书单', promote: '推广', invite: '邀请' };
const LIMIT_NAMES = { share_max_days: '单个分享最长天数', share_max_links: '最多分享链接数', download_monthly_limit: '每月下载本数', listen_monthly_limit: '30 天内免费听书本数', shelf_limit: '私人书架最多本数', convert_daily_limit: '每天转换本数', upload_max_mb: '单本上传最大 MB' };
// 这几个数字字段里 0 的含义不一样：大多是「不限」，听书额度是「一本都不免费」。
// 而且听书额度只在没勾「听书」权限时才有意义（勾了就不限量、不扣树叶）。
const LIMIT_HINTS = {
  listen_monthly_limit: '0=没有免费额度，每本都扣树叶；勾了上面的「听书」权限后本项不生效。★ 名额自占用起 30 天内有效，过期后重听同一本书要重新占名额',
  upload_max_mb: '0=不限；只对「私人书架」上传生效，超限会被服务端拒绝',
};
const LIMIT_HINT_DEFAULT = '0=不限';

function groupOptions(selected) {
  return groups.map(g => `<option value="${g.id}" ${g.id === selected ? 'selected' : ''}>${esc(g.name)}${g.is_system ? '（系统）' : ''}</option>`).join('');
}

function showCreateUser() {
  openModal(`<button class="close" onclick="closeModal()">✕</button><h3>新建用户</h3>
    <div class="form-group"><label>用户名</label><input id="nu-name"></div>
    <div class="form-group"><label>密码</label><input id="nu-pw" type="password"></div>
    <div class="form-group"><label>昵称（选填，不可重复）</label><input id="nu-real"></div>
    <div class="form-group"><label>邮箱（选填）</label><input id="nu-email"></div>
    <div class="form-group"><label>手机号（选填）</label><input id="nu-phone"></div>
    <div class="form-group"><label>分组</label><select id="nu-group">${groupOptions()}</select></div>
    <button class="btn block" onclick="createUser()">创建</button>`);
}
async function createUser() {
  const fd = new FormData();
  fd.append('username', document.getElementById('nu-name').value);
  fd.append('password', document.getElementById('nu-pw').value);
  fd.append('name', document.getElementById('nu-real').value);
  fd.append('email', document.getElementById('nu-email').value);
  fd.append('phone', document.getElementById('nu-phone').value);
  fd.append('group_id', document.getElementById('nu-group').value);
  try { await api('/api/admin/users', { method: 'POST', body: fd }); closeModal(); loadUsers(); toast('已创建'); }
  catch (e) { toast(e.message); }
}
function editUser(id) {
  const u = users.find(x => x.id === id);
  openModal(`<button class="close" onclick="closeModal()">✕</button><h3>编辑 ${esc(u.username)}</h3>
    <div class="form-group"><label>分组</label><select id="eu-group">${groupOptions(u.group_id)}</select>
      <p class="muted" style="font-size:12px;margin:4px 0 0">权限与限额由分组决定，修改分组后自动同步</p></div>
    <div class="form-group"><label>昵称</label><input id="eu-name" value="${esc(u.name || '')}"></div>
    <div class="form-group"><label>邮箱</label><input id="eu-email" value="${esc(u.email || '')}"></div>
    <div class="form-group"><label>手机号</label><input id="eu-phone" value="${esc(u.phone || '')}"></div>
    <div class="form-group"><label>树叶数量</label><input id="eu-leaves" type="number" min="0" step="1" value="${u.leaves ?? 0}"></div>
    <div class="form-group"><label>状态</label><select id="eu-enabled">
      <option value="1" ${u.enabled?'selected':''}>启用</option><option value="0" ${!u.enabled?'selected':''}>禁用</option></select></div>
    <div class="form-group"><label>重置密码（留空不改）</label><input id="eu-pw" type="password"></div>
    <div style="display:flex;gap:10px">
      <button class="btn" style="flex:1" onclick="saveUser(${id})">保存</button>
      <button class="btn danger" onclick="delUser(${id})">删除</button>
    </div>`);
}
async function saveUser(id) {
  const fd = new FormData();
  fd.append('group_id', document.getElementById('eu-group').value);
  fd.append('name', document.getElementById('eu-name').value);
  fd.append('email', document.getElementById('eu-email').value);
  fd.append('phone', document.getElementById('eu-phone').value);
  fd.append('leaves', document.getElementById('eu-leaves').value);
  fd.append('enabled', document.getElementById('eu-enabled').value);
  const pw = document.getElementById('eu-pw').value;
  if (pw) fd.append('password', pw);
  try { await api('/api/admin/users/' + id, { method: 'PUT', body: fd }); closeModal(); loadUsers(); toast('已保存'); }
  catch (e) { toast(e.message); }
}
async function delUser(id) {
  if (!confirm('确认删除该用户及其书库数据？')) return;
  try { await api('/api/admin/users/' + id, { method: 'DELETE' }); loadUsers(); toast('已删除'); }
  catch (e) { toast(e.message); }
}

// ---------- 分组管理 ----------
function permBadge(g) {
  const on = Object.keys(PERM_NAMES).filter(p => g['can_' + p]);
  return on.length ? on.map(p => PERM_NAMES[p]).join('、') : '无';
}
function limitText(g) {
  const parts = [];
  if (g.share_max_days > 0) parts.push('分享≤' + g.share_max_days + '天');
  if (g.share_max_links > 0) parts.push('分享' + g.share_max_links + '链');
  if (g.download_monthly_limit > 0) parts.push('下载' + g.download_monthly_limit + '本/月');
  // 勾了「听书」权限 = 不限量不扣树叶，此时「免费本数」根本不生效，
  // 再显示「N本免费」会让人以为额度在起作用。
  if (g.can_listen) parts.push('听书不限量');
  else if (g.listen_monthly_limit > 0) parts.push('听书' + g.listen_monthly_limit + '本/30天免费');
  if (g.shelf_limit > 0) parts.push('书架' + g.shelf_limit + '本');
  if (g.convert_daily_limit > 0) parts.push('转换' + g.convert_daily_limit + '本/天');
  // 奖励：0 也可能是「开了权限但不奖励」，所以和权限分开显示。
  // 两条渠道各自判断 —— 只开了推广没开邀请时，不该看到「邀请」字样。
  if (g.can_promote) parts.push(g.promote_reward > 0 ? ('推广+' + g.promote_reward + '叶/有效注册') : '推广(不奖励)');
  if (g.can_invite) parts.push(g.invite_reward > 0 ? ('邀请+' + g.invite_reward + '叶/有效注册') : '邀请(不奖励)');
  return parts.length ? parts.join(' · ') : '不限';
}
function exchangeText(g) {
  return g.exchange_cost > 0 ? g.exchange_cost + ' 树叶 / 1 个月' : '不可兑换';
}
async function loadGroups() {
  groups = await api('/api/admin/groups');
  const wrap = document.getElementById('group-list');
  // 两套版式，用 CSS 断点切换：宽屏紧凑表格、窄屏卡片。
  // 表格 6 列且 min-width:640px，手机上会横向溢出 330px，
  // 「编辑」按钮被挤出屏幕外，得左右拖着看 —— 手机上改成分组卡片。
  //
  // ★ 宽屏这一版刻意压成**一行一个分组**：以前权限/限额两列会各折成两三行，
  //   5 个分组就占 455px，行高还 79/79/59/59/59 参差不齐（高度全花在换行上）。
  //   现在行高固定，长内容省略号 + title 鼠标悬浮看全文，信息一条不少。
  const rows = groups.map(g => {
    const perms = Object.keys(PERM_NAMES).filter(p => g['can_' + p]).map(p => PERM_NAMES[p]);
    const shown = perms.slice(0, 3);
    const more = perms.length - shown.length;
    return `<tr>
        <td title="${esc(g.name)}"><b>${esc(g.name)}</b>${g.is_system ? ' <span class="badge ok">系统</span>' : ''}<span class="g-mem">${g.members} 人</span></td>
        <td title="${esc(perms.length ? perms.join('、') : '无')}">${perms.length
          ? shown.map(x => `<span class="g-chip">${esc(x)}</span>`).join('')
            + (more > 0 ? `<span class="g-chip more">+${more}</span>` : '')
          : '<span class="muted">无</span>'}</td>
        <td title="${esc(limitText(g))}">${esc(limitText(g))}</td>
        <td title="${esc(exchangeText(g))}" class="${g.exchange_cost > 0 ? '' : 'muted'}">${g.exchange_cost > 0 ? g.exchange_cost + ' 叶/月' : '不可兑换'}</td>
        <td class="g-act"><button class="btn ghost sm" onclick="editGroup(${g.id})">编辑</button></td>
      </tr>`;
  }).join('');
  const cards = groups.map(g => `<div class="grp-card">
      <div class="grp-head">
        <b>${esc(g.name)}</b>${g.is_system ? '<span class="badge ok">系统</span>' : ''}
        <span class="grp-members">${g.members} 人</span>
        <button class="btn ghost sm" onclick="editGroup(${g.id})">编辑</button>
      </div>
      <div class="grp-row"><span class="grp-k">权限</span><span class="grp-v">${esc(permBadge(g))}</span></div>
      <div class="grp-row"><span class="grp-k">限额</span><span class="grp-v">${esc(limitText(g))}</span></div>
      <div class="grp-row"><span class="grp-k">兑换</span><span class="grp-v">${esc(exchangeText(g))}</span></div>
    </div>`).join('');
  wrap.innerHTML =
    `<div class="grp-table-wrap">
       <table class="grp-tb">
         <colgroup><col style="width:22%"><col style="width:30%"><col style="width:29%"><col style="width:12%"><col style="width:7%"></colgroup>
         <thead><tr><th>分组</th><th>权限</th><th>限额</th><th>兑换</th><th></th></tr></thead>
         <tbody>${rows}</tbody>
       </table>
     </div>
     <div class="grp-cards">${cards}</div>`;
  const sel = document.getElementById('user-group-filter');
  if (sel) sel.innerHTML = '<option value="">全部分组</option>' + groups.map(g =>
    `<option value="${g.id}" ${String(g.id) === userGroupFilter ? 'selected' : ''}>${esc(g.name)}</option>`).join('');
}
function groupPermChecks(g, prefix) {
  return Object.keys(PERM_NAMES).map(p =>
    `<label style="display:inline-flex;align-items:center;gap:6px;margin:4px 10px 4px 0;font-size:13px">
      <input type="checkbox" id="${prefix}-${p}" ${g['can_' + p] ? 'checked' : ''}>${PERM_NAMES[p]}</label>`).join('');
}
function groupLimitInputs(g, prefix) {
  return Object.keys(LIMIT_NAMES).map(k =>
    `<div class="form-group"><label>${LIMIT_NAMES[k]}（${LIMIT_HINTS[k] || LIMIT_HINT_DEFAULT}）</label>
      <input id="${prefix}-${k}" type="number" min="0" value="${g[k] || 0}"></div>`).join('')
    + `<div class="form-group"><label>兑换数量（树叶，0=不可兑换；有效期固定 1 个月）</label>
      <input id="${prefix}-exchange_cost" type="number" min="0" value="${g.exchange_cost || 0}"></div>`
    // 推广 / 邀请是两条独立渠道，奖励各填各的。
    // 勾了权限但填 0 = 能推广/邀请但不发树叶（也允许，站长可能只想看数据）
    + `<div class="form-group"><label>「推广」每个有效注册奖励（树叶，0=不奖励）</label>
      <input id="${prefix}-promote_reward" type="number" min="0" value="${g.promote_reward || 0}"></div>
      <div class="form-group"><label>「邀请」每个有效注册奖励（树叶，0=不奖励）</label>
      <input id="${prefix}-invite_reward" type="number" min="0" value="${g.invite_reward || 0}">
      <div class="muted" style="font-size:12px;margin-top:4px">两条渠道要分别勾选上面的「推广」「邀请」权限；奖励数也只对勾了对应权限的成员生效。同一台机器重复注册只算一个有效注册，两条渠道共用这个判定。</div></div>`;
}
function showCreateGroup() {
  const empty = { can_share: 0, can_edit: 0, can_cover: 0, can_download: 0, can_delete: 0, can_private_shelf: 0, can_convert: 0, can_listen: 0, can_public_library: 0, can_promote: 0, can_invite: 0, promote_reward: 0, invite_reward: 0, share_max_days: 0, share_max_links: 0, download_monthly_limit: 0, listen_monthly_limit: 0, shelf_limit: 0, exchange_cost: 0 };
  openModal(`<button class="close" onclick="closeModal()">✕</button><h3>新建分组</h3>
    <div class="form-group"><label>分组名称</label><input id="ng-name"></div>
    <div class="form-group"><label>权限</label><div>${groupPermChecks(empty, 'ng')}</div></div>
    ${groupLimitInputs(empty, 'ng')}
    <button class="btn block" onclick="createGroup()">创建</button>`);
}
async function createGroup() {
  const fd = new FormData();
  fd.append('name', document.getElementById('ng-name').value);
  Object.keys(PERM_NAMES).forEach(p => fd.append('can_' + p, document.getElementById('ng-' + p).checked ? '1' : '0'));
  Object.keys(LIMIT_NAMES).forEach(k => fd.append(k, document.getElementById('ng-' + k).value || '0'));
  fd.append('exchange_cost', document.getElementById('ng-exchange_cost').value || '0');
  fd.append('promote_reward', document.getElementById('ng-promote_reward').value || '0');
  fd.append('invite_reward', document.getElementById('ng-invite_reward').value || '0');
  try { await api('/api/admin/groups', { method: 'POST', body: fd }); closeModal(); loadGroups(); toast('已创建'); }
  catch (e) { toast(e.message); }
}
function editGroup(id) {
  const g = groups.find(x => x.id === id);
  openModal(`<button class="close" onclick="closeModal()">✕</button><h3>编辑分组「${esc(g.name)}」</h3>
    <div class="form-group"><label>分组名称</label><input id="eg-name" value="${esc(g.name)}"></div>
    <div class="form-group"><label>权限</label><div>${groupPermChecks(g, 'eg')}</div></div>
    ${groupLimitInputs(g, 'eg')}
    <div style="display:flex;gap:10px">
      <button class="btn" style="flex:1" onclick="saveGroup(${id})">保存</button>
      ${g.is_system ? '' : `<button class="btn danger" onclick="delGroup(${id})">删除</button>`}
    </div>`);
}
async function saveGroup(id) {
  const fd = new FormData();
  fd.append('name', document.getElementById('eg-name').value);
  Object.keys(PERM_NAMES).forEach(p => fd.append('can_' + p, document.getElementById('eg-' + p).checked ? '1' : '0'));
  Object.keys(LIMIT_NAMES).forEach(k => fd.append(k, document.getElementById('eg-' + k).value || '0'));
  fd.append('exchange_cost', document.getElementById('eg-exchange_cost').value || '0');
  fd.append('promote_reward', document.getElementById('eg-promote_reward').value || '0');
  fd.append('invite_reward', document.getElementById('eg-invite_reward').value || '0');
  try { await api('/api/admin/groups/' + id, { method: 'PUT', body: fd }); closeModal(); loadGroups(); toast('已保存'); }
  catch (e) { toast(e.message); }
}
async function delGroup(id) {
  if (!confirm('确认删除该分组？')) return;
  try { await api('/api/admin/groups/' + id, { method: 'DELETE' }); loadGroups(); toast('已删除'); }
  catch (e) { toast(e.message); }
}

// ---------- 下载与阅读链路域名（§14.114） ----------
// 为什么要有它：站点既能从反向代理域名访问，也能从服务器直达域名访问，前者慢。
// 分享链接/下载/在线阅读/App 安装包这些「我们生成的绝对地址」统一用后台这个变量拼，
// 不再跟着访客的访问域名走。留空 = 跟随访客访问域名。
const LB_PRESETS = ['http://localhost:9000/', 'https://reader.example.com/'];

async function loadLinkBase() {
  try {
    const c = await api('/api/admin/config');
    const v = c.link_base || '';
    const input = document.getElementById('lb-input');
    const sel = document.getElementById('lb-preset');
    if (!input || !sel) return;
    input.value = v;
    sel.value = !v ? '' : (LB_PRESETS.indexOf(v) >= 0 ? v : '__custom__');
    const msg = document.getElementById('lb-msg');
    if (msg) msg.textContent = v ? '' : '当前：跟随访客访问域名';
  } catch (e) {}
}

function onLinkBasePreset() {
  const sel = document.getElementById('lb-preset');
  const input = document.getElementById('lb-input');
  if (!sel || !input) return;
  if (sel.value === '__custom__') { input.focus(); input.select && input.select(); return; }
  input.value = sel.value;
}

async function saveLinkBase() {
  const input = document.getElementById('lb-input');
  const v = ((input && input.value) || '').trim();
  if (v && !/^https?:\/\//i.test(v)) { toast('域名要写成 https://主机[:端口]/ 的形式'); return; }
  if (v && /\s/.test(v)) { toast('域名里不能有空格'); return; }
  try {
    await api('/api/admin/config', { method: 'POST', headers: { 'Content-Type': 'application/json' },
                                     body: JSON.stringify({ link_base: v }) });
    await loadLinkBase();
    const msg = document.getElementById('lb-msg');
    if (msg) msg.textContent = '已保存';
    toast(v ? '链路域名已保存：' + v : '已改为跟随访客访问域名');
  } catch (e) { toast(e.message); }
}

// ---------- 注册审核 ----------
async function loadConfig() {
  try {
    const c = await api('/api/admin/config');
    document.getElementById('reg-review').checked = c.registration_review === '1';
    document.getElementById('reg-invite').checked = c.invite_register === '1';
    const t = await api('/api/terms');
    document.getElementById('terms-content').value = t.content || '';
  } catch (e) {}
}
async function saveTerms() {
  const fd = new FormData();
  fd.append('content', document.getElementById('terms-content').value);
  try { await api('/api/admin/terms', { method: 'PUT', body: fd }); toast('须知已保存'); }
  catch (e) { toast(e.message); }
}
async function toggleRegReview(on) {
  try {
    await api('/api/admin/config', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ registration_review: on ? '1' : '0' }) });
    toast(on ? '已开启注册审核' : '已关闭注册审核');
  }
  catch (e) { toast(e.message); loadConfig(); }
}
async function toggleInviteRegister(on) {
  try {
    await api('/api/admin/config', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ invite_register: on ? '1' : '0' }) });
    toast(on ? '已开启邀请注册：注册必须填邀请码' : '已关闭邀请注册：邀请码可选');
  }
  catch (e) { toast(e.message); loadConfig(); }
}
async function loadPending() {
  try {
    const us = await api('/api/admin/users');
    const pending = us.filter(u => !u.enabled);
    const wrap = document.getElementById('pending-users');
    if (!pending.length) { wrap.innerHTML = '<p class="muted" style="margin:0;font-size:13px">暂无待审核用户</p>'; return; }
    wrap.innerHTML = `<p style="margin:0 0 10px;font-size:13px;font-weight:600;color:#e5484d">待审核（${pending.length} 人）</p>` +
      pending.map(u => `<div class="list-item" style="cursor:default">
        <div class="txt"><div class="tt">${esc(u.username)} 👤 · ${esc(u.name || '—')}</div>
        <div class="aa">${esc(u.email || '')} · ${esc(u.phone || '')} · 注册于 ${esc(u.created_at || '')}</div></div>
        <div style="display:flex;gap:8px">
          <button class="btn sm" onclick="approveUser(${u.id})">✓ 通过</button>
          <button class="btn danger sm" onclick="rejectUser(${u.id}, '${esc(u.username)}')">拒绝</button>
        </div></div>`).join('');
  } catch (e) {}
}
async function approveUser(id) {
  const fd = new FormData(); fd.append('enabled', '1');
  try { await api('/api/admin/users/' + id, { method: 'PUT', body: fd }); toast('已通过审核'); loadPending(); loadUsers(); }
  catch (e) { toast(e.message); }
}
async function rejectUser(id, name) {
  if (!confirm('确认拒绝并删除用户「' + name + '」？')) return;
  try { await api('/api/admin/users/' + id, { method: 'DELETE' }); toast('已拒绝'); loadPending(); loadUsers(); }
  catch (e) { toast(e.message); }
}

// ---------- 批量补录元数据 ----------
async function doEnrich() {
  const btn = document.getElementById('enrich-btn');
  if (btn.disabled) return;
  btn.disabled = true; btn.textContent = '补录中…';
  try {
    await api('/api/admin/enrich', { method: 'POST' });
    toast('已开始批量补录（后台执行）');
    const poll = async () => {
      const s = await api('/api/admin/enrich/status');
      if (s.running) { setTimeout(poll, 2500); return; }
      btn.disabled = false; btn.textContent = '补录元数据';
      if (s.result) toast(`补录完成：更新 ${s.result.done}，失败 ${s.result.fail}，跳过 ${s.result.skipped}`);
      loadStats();
    };
    setTimeout(poll, 2500);
  } catch (e) { toast(e.message); btn.disabled = false; btn.textContent = '补录元数据'; }
}
async function loadEnrichStatus() {
  try {
    const s = await api('/api/admin/enrich/status');
    if (s.running) {
      const btn = document.getElementById('enrich-btn');
      btn.disabled = true; btn.textContent = '补录中…';
      const poll = async () => {
        const st = await api('/api/admin/enrich/status');
        if (st.running) { setTimeout(poll, 2500); return; }
        btn.disabled = false; btn.textContent = '补录元数据';
        if (st.result) toast(`补录完成：更新 ${st.result.done}，失败 ${st.result.fail}，跳过 ${st.result.skipped}`);
      };
      setTimeout(poll, 2500);
    }
  } catch (e) {}
}

// ---------- 同步 ----------
async function loadSyncStatus() {
  try {
    const s = await api('/api/admin/sync/status');
    if (s.time) document.getElementById('sync-status').textContent = `上次同步：${s.time}${s.result ? ' · 新增 ' + s.result.added + ' / 删除 ' + s.result.removed + ' / 更新 ' + s.result.size_updated + '（' + s.result.elapsed + 's）' : ''}`;
  } catch (e) {}
}

// ---------- 迅雷入库（/迅雷/电子书 扫描 + 去重分类入库） ----------
async function loadXlStatus() {
  try {
    const s = await api('/api/admin/xunlei-import/status');
    const el = document.getElementById('xl-status');
    if (!el) return;
    if (s.running) {
      el.textContent = s.phase === 'scan'
        ? '⏳ 正在扫描 ' + (s.base || '') + '… 已发现 ' + (s.files_found || 0) + ' 个文件'
        : '⏳ 正在去重分类入库 ' + (s.base || '') + '…';
      el.style.color = '#e8890c';
    } else if (s.error) {
      el.textContent = '分类入库失败：' + s.error;
      el.style.color = '#e5484d';
    } else if (s.result) {
      const r = s.result;
      const cats = Object.entries(r.by_category || {}).sort((a, b) => b[1] - a[1]).slice(0, 12)
        .map(([k, v]) => k + ':' + v).join(' · ');
      el.textContent = `上次分类入库（${r.base || s.base || ''}）${s.time || ''}：总文件 ${r.total_files} · 非电子书 ${r.not_book} · 与书库重名跳过 ${r.dup_existing} · 内部重名 ${r.dup_internal} · 新导入 ${r.imported} 本（扫描${r.elapsed_scan}s / 导入${r.elapsed_import}s）｜分类：${cats}`;
      el.style.color = '';
    } else {
      el.textContent = '未执行过分类入库（点击右上角「分类入库」，先输入源目录绝对路径）';
      el.style.color = '';
    }
  } catch (e) {}
}
async function doXunleiImport() {
  // 先输入源目录（绝对路径），再执行
  openModal(`<button class="close" onclick="closeModal()">✕</button>
    <h3>分类入库</h3>
    <div class="form-group"><label>源目录（NAS 上的绝对路径）</label>
      <input id="xl-base-input" placeholder="/Media2/Download" value="/Media2/Download"></div>
    <p class="muted" style="font-size:12px">将递归扫描该目录下所有电子书，按去重优先规则分类入库；与书库同名（去扩展名）文件自动跳过，格式更优时替换库内旧格式。目录较大时约需数分钟到数十分钟。</p>
    <button class="btn block" onclick="confirmXunleiImport()">开始入库</button>`);
}
async function confirmXunleiImport() {
  const base = (document.getElementById('xl-base-input').value || '').trim();
  if (!base.startsWith('/')) { toast('请输入以 / 开头的绝对路径'); return; }
  closeModal();
  const btn = document.getElementById('xl-btn');
  btn.disabled = true; btn.textContent = '分类中…';
  try {
    const r = await api('/api/admin/xunlei-import', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ base }) });
    if (r.error) { toast(r.error); btn.disabled = false; btn.textContent = '分类入库'; return; }
    if (r.running && !r.started) { toast('分类入库任务已在运行中'); }
    else { toast('已开始分类入库'); }
    const timer = setInterval(async () => {
      const s = await api('/api/admin/xunlei-import/status').catch(() => null);
      if (!s) return;
      await loadXlStatus(); await loadXlLog();
      if (!s.running) { clearInterval(timer); btn.disabled = false; btn.textContent = '分类入库'; loadStats(); loadXlLog(); }
    }, 3000);
  } catch (e) {
    toast(e.message);
    btn.disabled = false; btn.textContent = '分类入库';
  }
}
// ---------- 分类入库任务日志（纯文字，只显示最近一次） ----------
async function loadXlLog() {
  const el = document.getElementById('xl-log');
  if (!el) return;
  try {
    const d = await api('/api/admin/xunlei-import/log');
    const logs = d.logs || [];
    if (!logs.length) { el.innerHTML = '<p class="muted">暂无分类入库记录</p>'; return; }
    const L = logs[logs.length - 1];        // 最近一次
    const r = L.result;
    if (!r) {
      el.innerHTML = `<p class="muted" style="margin:0">🕐 ${esc(L.time)}${L.error ? ' · <span style="color:#e5484d">失败：' + esc(L.error) + '</span>' : ''}</p>`;
      return;
    }
    const cats = Object.entries(r.by_category || {}).sort((a, b) => b[1] - a[1])
      .map(([k, v]) => `${esc(k)} ${v} 本`).join('，');
    const notMoved = (r.not_moved_samples || []).map(s => `· ${esc(s.name)}（${esc(s.reason)}）`).join(' ');
    el.innerHTML = `
      <p class="muted" style="margin:0 0 6px;font-size:13px">🕐 ${esc(L.time)} · 耗时 ${Math.round(L.running_time || 0)}s${L.error ? ' · <span style="color:#e5484d">失败：' + esc(L.error) + '</span>' : ''}</p>
      <p style="margin:0;font-size:14px;line-height:2">本次扫描 <b>${r.total_files}</b> 个文件，其中非电子书 ${r.not_book} 个（留在原处），
        <b style="color:#16a34a">移动入库 ${r.imported} 本</b>；去重跳过 ${(r.dup_existing || 0) + (r.dup_internal || 0)} 个
        （与书库同名 ${r.dup_existing || 0}、迅雷内部同名合并（格式择优）${r.dup_internal || 0}${r.replaced ? '、替换库内旧格式 ' + r.replaced + ' 本' : ''}）；
        未移动 ${r.not_moved || 0} 个（源缺失 ${r.missing_source || 0}、移动失败 ${r.move_failed || 0}），未移动的文件保留在原目录，未删除。</p>
      <p class="muted" style="margin:4px 0 0;font-size:13px">分类分布：${cats || '本次无移动'}</p>
      ${notMoved ? `<p class="muted" style="margin:6px 0 0;font-size:12px">未移动样例：${notMoved}</p>` : ''}`;
  } catch (e) { el.innerHTML = '<p class="muted">日志加载失败</p>'; }
}
// ---------- 文件去重（size 分组 + 全文件 MD5，仅系统书） ----------
async function doDedup() {
  const btn = document.getElementById('dedup-btn');
  if (!confirm('扫描全库，查找字节级完全相同的重复文件？\n仅处理系统入库的电子书（用户上传除外）。\n将按 size 分组并对 size 相同的文件计算 MD5，耗时较长，可关闭页面稍后回来查看。')) return;
  btn.disabled = true; btn.textContent = '去重中…';
  try {
    const r = await api('/api/admin/dedup/scan', { method: 'POST' });
    if (r.running && !r.started) { toast('去重扫描已在运行中'); btn.disabled = false; btn.textContent = '文件去重'; return; }
    toast('已开始去重扫描');
    const timer = setInterval(async () => {
      const s = await api('/api/admin/dedup/status').catch(() => null);
      if (!s) return;
      if (s.running) {
        const pct = s.total ? Math.round(s.progress / s.total * 100) : 0;
        btn.textContent = s.phase === 'md5' ? '算MD5 ' + pct + '%' : '去重中…';
      } else {
        clearInterval(timer);
        btn.disabled = false; btn.textContent = '文件去重';
        if (s.error) { toast('去重失败：' + s.error); }
        else { loadDedupReport(); }
      }
    }, 3000);
  } catch (e) {
    toast(e.message);
    btn.disabled = false; btn.textContent = '文件去重';
  }
}
let DEDUP_REPORT = null;
let DEDUP_PAGE = 0;
let DEDUP_CHECKED = null; // Set of ids，null=初始未载入
const DEDUP_PAGE_SIZE = 100;

async function loadDedupReport() {
  try {
    const d = await api('/api/admin/dedup/report');
    if (!d.summary || !d.summary.groups) {
      openModal('<button class="close" onclick="closeModal()">✕</button><h3>文件去重报告</h3><p class="muted">尚未生成报告（未执行扫描，或库内无重复文件）</p>');
      return;
    }
    DEDUP_REPORT = d;
    DEDUP_PAGE = 0;
    // 默认全选所有可删除项
    DEDUP_CHECKED = new Set();
    d.groups.forEach(g => g.items.forEach(it => { if (!it.keep) DEDUP_CHECKED.add(it.id); }));
    renderDedupPage();
  } catch (e) { toast(e.message); }
}
// 注：原有一个从未被调用的 checkDedupReport()（只把报告塞进 DEDUP_REPORT），
// 该逻辑已在 loadDedupReport() 里完整实现，故删除这个死函数。
function renderDedupPage() {
  const d = DEDUP_REPORT;
  if (!d) { loadDedupReport(); return; }
  const s = d.summary;
  const groups = d.groups;
  const totalPages = Math.ceil(groups.length / DEDUP_PAGE_SIZE);
  const start = DEDUP_PAGE * DEDUP_PAGE_SIZE;
  const pageGroups = groups.slice(start, start + DEDUP_PAGE_SIZE);
  const body = pageGroups.map((g, idx) => {
    const gi = start + idx;
    const rows = g.items.map(it => {
      const keepBadge = it.keep
        ? '<span class="badge ok">保留</span>'
        : '<label style="display:inline-flex;align-items:center;gap:6px;font-size:12px;cursor:pointer"><input type="checkbox" class="dd-del" value="' + it.id + '" ' + (DEDUP_CHECKED.has(it.id) ? 'checked' : '') + ' onchange="toggleDedup(this)"> 删除</label>';
      const cn = it.chinese ? '<span class="badge" style="background:#eef2ff;color:#4f46e5">中文名</span>' : '';
      return '<div style="display:flex;justify-content:space-between;gap:8px;padding:6px 8px;border-bottom:1px solid var(--line);align-items:center">'
        + '<div style="min-width:0"><div style="font-size:13px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(it.title || it.name) + '</div>'
        + '<div class="muted" style="font-size:11px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(it.path) + ' · ' + (it.size / 1048576).toFixed(2) + ' MB</div></div>'
        + '<div style="display:flex;align-items:center;gap:6px;flex-shrink:0">' + cn + keepBadge + '</div></div>';
    }).join('');
    return '<div style="border:1px solid var(--line);border-radius:10px;margin-bottom:10px;overflow:hidden">'
      + '<div class="muted" style="padding:8px 10px;background:#f7f8fb;font-size:12px">重复组 #' + (gi + 1) + ' · ' + g.count + ' 本完全相同 · MD5 ' + esc(g.md5.slice(0, 12)) + '…</div>'
      + '<div style="padding:4px 8px">' + rows + '</div></div>';
  }).join('');
  const pager = '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">'
    + '<button class="btn ghost sm" onclick="dedupPage(' + (DEDUP_PAGE - 1) + ')" ' + (DEDUP_PAGE <= 0 ? 'disabled' : '') + '>上一页</button>'
    + '<span class="muted" style="font-size:13px">第 ' + (DEDUP_PAGE + 1) + ' / ' + totalPages + ' 页</span>'
    + '<button class="btn ghost sm" onclick="dedupPage(' + (DEDUP_PAGE + 1) + ')" ' + (DEDUP_PAGE >= totalPages - 1 ? 'disabled' : '') + '>下一页</button></div>';
  openModal('<button class="close" onclick="closeModal()">✕</button>'
    + '<h3>文件去重报告</h3>'
    + '<p class="muted" style="font-size:13px">重复组 <b>' + s.groups + '</b> 组 · 已勾选待删除 <b id="dd-sel-count">' + DEDUP_CHECKED.size + '</b> 本（保留中文名/文字最多的，其余默认勾选删除）</p>'
    + '<div style="display:flex;gap:8px;margin-bottom:10px"><button class="btn ghost sm" onclick="dedupSelectAll()">全选</button><button class="btn ghost sm" onclick="dedupClearAll()">清空</button></div>'
    + pager
    + '<div style="max-height:52vh;overflow-y:auto;margin-bottom:12px">' + (body || '<p class="muted">无重复文件</p>') + '</div>'
    + pager
    + '<div style="display:flex;gap:8px"><button class="btn danger block" onclick="confirmDedupDelete()">删除已勾选的 <span id="dd-del-btn-n">' + DEDUP_CHECKED.size + '</span> 个重复文件</button></div>', true);
}
function toggleDedup(cb) {
  const id = parseInt(cb.value);
  if (cb.checked) DEDUP_CHECKED.add(id); else DEDUP_CHECKED.delete(id);
  const c = document.getElementById('dd-sel-count'); if (c) c.textContent = DEDUP_CHECKED.size;
  const b = document.getElementById('dd-del-btn-n'); if (b) b.textContent = DEDUP_CHECKED.size;
}
function dedupPage(p) {
  if (!DEDUP_REPORT) return;
  const totalPages = Math.ceil(DEDUP_REPORT.groups.length / DEDUP_PAGE_SIZE);
  if (p < 0 || p >= totalPages) return;
  DEDUP_PAGE = p;
  renderDedupPage();
}
function dedupSelectAll() {
  DEDUP_CHECKED = new Set();
  DEDUP_REPORT.groups.forEach(g => g.items.forEach(it => { if (!it.keep) DEDUP_CHECKED.add(it.id); }));
  renderDedupPage();
}
function dedupClearAll() {
  DEDUP_CHECKED = new Set();
  renderDedupPage();
}
async function confirmDedupDelete() {
  const ids = Array.from(DEDUP_CHECKED || []);
  if (!ids.length) { toast('未勾选任何文件'); return; }
  if (!confirm('确定删除 ' + ids.length + ' 个重复文件？\n将删除 FTP 上的文件及库内记录，不可恢复。')) return;
  closeModal();
  toast('正在删除 ' + ids.length + ' 个文件，请稍候…');
  try {
    const r = await api('/api/admin/dedup/delete', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ids }) });
    toast('已删除 ' + r.deleted + ' 个，失败 ' + r.failed + ' 个');
    loadStats();
  } catch (e) { toast(e.message); }
}
async function doSync() {
  const btn = document.getElementById('sync-btn');
  btn.disabled = true; btn.textContent = '同步中…';
  try {
    const r = await api('/api/admin/sync', { method: 'POST' });
    if (r.running) { toast('已有同步任务进行中'); }
    else { toast(`同步完成：新增 ${r.added}，删除 ${r.removed}，更新 ${r.size_updated}`); loadStats(); loadSyncStatus(); }
  } catch (e) { toast(e.message); }
  btn.disabled = false; btn.textContent = '同步书库';
}
// ---------- 封面刮削接入资源 ----------
const SOURCE_TYPES = { douban: '豆瓣读书', bing: '必应图片', google: 'Google Books', openlibrary: 'Open Library', ebook: '电子书内图片' };
// 「电子书内图片」不是在线接口，是从电子书文件自己身上取 —— 写清各格式取哪一张，
// 免得站长以为它坏了（txt/docx 这类没图的格式本来就取不到，会顺延到下一个源）。
const SOURCE_HINT = {
  ebook: '从电子书文件内部取图：epub 按阅读顺序取第一张够大的图（封面页/扉页/内嵌照片），pdf 渲染第 1 页，漫画取第一张，mobi/azw3 先取内嵌封面、没有就转 epub 再找。txt、docx 这类没有图片的格式取不到，会自动顺延到下一个源。',
};
let sources = [];
async function loadSources() {
  try {
    sources = await api('/api/admin/sources');
    const wrap = document.getElementById('source-list');
    if (!sources.length) { wrap.innerHTML = '<p class="muted">暂无接入资源</p>'; return; }
    wrap.innerHTML = sources.map((s, i) => `<div class="list-item" style="cursor:default">
      <div class="txt">
        <div class="tt">${i + 1}. ${esc(s.name)} <span class="tag">${esc(SOURCE_TYPES[s.type] || s.type)}</span></div>
        <div class="aa">${s.enabled ? '✅ 启用' : '⏸ 停用'}</div>
      </div>
      <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">
        <button class="btn ghost sm" onclick="moveSource(${s.id},-1)" title="上移">↑</button>
        <button class="btn ghost sm" onclick="moveSource(${s.id},1)" title="下移">↓</button>
        <button class="btn ghost sm" onclick="editSource(${s.id})">编辑</button>
        <button class="btn ghost sm" onclick="toggleSource(${s.id})">${s.enabled ? '停用' : '启用'}</button>
        <button class="btn danger sm" onclick="delSource(${s.id})">删除</button>
      </div></div>`).join('');
  } catch (e) { toast(e.message); }
}
function sourceTypeOpts(sel) {
  return Object.keys(SOURCE_TYPES).map(t => `<option value="${t}" ${t === sel ? 'selected' : ''}>${SOURCE_TYPES[t]}</option>`).join('');
}
function sourceHintHTML(sel) {
  const h = SOURCE_HINT[sel];
  return `<div class="muted" id="so-hint" style="font-size:12px;line-height:1.7;margin-top:6px">${esc(h || '')}</div>`;
}
function showAddSource() {
  openModal(`<button class="close" onclick="closeModal()">✕</button><h3>添加接入资源</h3>
    <div class="form-group"><label>资源名称</label><input id="so-name" placeholder="例如：豆瓣读书（备用）"></div>
    <div class="form-group"><label>类型</label><select id="so-type" onchange="document.getElementById('so-hint').textContent = (SOURCE_HINT[this.value]||'')">${sourceTypeOpts('douban')}</select>${sourceHintHTML('douban')}</div>
    <button class="btn block" onclick="saveSource(0)">添加</button>`);
}
function editSource(id) {
  const s = sources.find(x => x.id === id);
  openModal(`<button class="close" onclick="closeModal()">✕</button><h3>编辑接入资源</h3>
    <div class="form-group"><label>资源名称</label><input id="so-name" value="${esc(s.name)}"></div>
    <div class="form-group"><label>类型</label><select id="so-type" onchange="document.getElementById('so-hint').textContent = (SOURCE_HINT[this.value]||'')">${sourceTypeOpts(s.type)}</select>${sourceHintHTML(s.type)}</div>
    <button class="btn block" onclick="saveSource(${id})">保存</button>`);
}
async function saveSource(id) {
  const fd = new FormData();
  fd.append('name', document.getElementById('so-name').value);
  fd.append('stype', document.getElementById('so-type').value);
  try {
    if (id) { await api('/api/admin/sources/' + id, { method: 'PUT', body: fd }); toast('已保存'); }
    else { await api('/api/admin/sources', { method: 'POST', body: fd }); toast('已添加'); }
    closeModal(); loadSources();
  } catch (e) { toast(e.message); }
}
async function toggleSource(id) {
  const s = sources.find(x => x.id === id);
  const fd = new FormData(); fd.append('enabled', s.enabled ? '0' : '1');
  try { await api('/api/admin/sources/' + id, { method: 'PUT', body: fd }); loadSources(); }
  catch (e) { toast(e.message); }
}
async function delSource(id) {
  if (!confirm('确认删除该接入资源？')) return;
  try { await api('/api/admin/sources/' + id, { method: 'DELETE' }); loadSources(); toast('已删除'); }
  catch (e) { toast(e.message); }
}
async function moveSource(id, dir) {
  const i = sources.findIndex(x => x.id === id);
  const j = i + dir;
  if (i < 0 || j < 0 || j >= sources.length) return;
  const a = sources[i], b = sources[j];
  const fdA = new FormData(); fdA.append('sort_order', j + 1);
  const fdB = new FormData(); fdB.append('sort_order', i + 1);
  try {
    await api('/api/admin/sources/' + a.id, { method: 'PUT', body: fdA });
    await api('/api/admin/sources/' + b.id, { method: 'PUT', body: fdB });
    loadSources();
  } catch (e) { toast(e.message); }
}

// ---------- 广告设置 ----------
async function loadAds() {
  try {
    const d = await api('/api/admin/ads');
    document.getElementById('ad-1').value = d.ad1 || '';
    document.getElementById('ad-2').value = d.ad2 || '';
  } catch (e) {}
}
async function saveAds() {
  try {
    await api('/api/admin/ads', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ad1: document.getElementById('ad-1').value, ad2: document.getElementById('ad-2').value }) });
    toast('广告已保存');
  } catch (e) { toast(e.message); }
}

// ---------- 友情链接管理 ----------
// 显示位置：书单页右侧栏「浏览排行」下面的「友情链接」块（最多 5 条）。
// 名称可以留空 —— 侧栏就直接显示地址本身。
// ★ 后端只收 http/https（防 javascript: 之类进 href），前端这里也顺手拦一道，
//   但**以后端为准**：提示「最多 5 条」的判定两边都做，前端是为了少发一次无效请求。
const LINK_MAX = 5;
let siteLinks = [];

async function loadLinks() {
  try {
    const c = await api('/api/admin/config');
    siteLinks = (c.links || []).slice(0, LINK_MAX);
    renderLinks();
  } catch (e) { toast(e.message); }
}

function renderLinks() {
  const wrap = document.getElementById('link-list');
  if (!wrap) return;
  wrap.innerHTML = siteLinks.length
    ? `<div style="display:flex;flex-direction:column;gap:8px">` + siteLinks.map((x, i) => `
        <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
          <span class="muted" style="font-size:13px;min-width:18px">${i + 1}</span>
          <input class="link-name" data-i="${i}" value="${esc(x.name || '')}" placeholder="名称（可留空）"
                 style="flex:1;min-width:140px;padding:7px 10px;border:1px solid var(--line);border-radius:8px">
          <input class="link-url" data-i="${i}" value="${esc(x.url || '')}" placeholder="https://example.com"
                 style="flex:2;min-width:200px;padding:7px 10px;border:1px solid var(--line);border-radius:8px">
          <button class="btn ghost sm" onclick="delLink(${i})">删除</button>
        </div>`).join('') + `</div>`
    : '<p class="muted" style="font-size:13px;margin:0">还没有友链。点右上角「添加友链」加一条，不填名称就直接显示地址。</p>';
  const addBtn = document.getElementById('link-add-btn');
  if (addBtn) {
    addBtn.disabled = siteLinks.length >= LINK_MAX;
    addBtn.textContent = siteLinks.length >= LINK_MAX ? '已满 5 条' : '添加友链';
  }
}

function showAddLink() {
  if (siteLinks.length >= LINK_MAX) { toast('最多 ' + LINK_MAX + ' 条友链'); return; }
  siteLinks.push({ name: '', url: '' });
  renderLinks();
  const inputs = document.querySelectorAll('.link-url');
  if (inputs.length) inputs[inputs.length - 1].focus();
}

function delLink(i) {
  siteLinks.splice(i, 1);
  renderLinks();
}

async function saveLinks() {
  // 先收回输入框里的当前值：用户填完直接点保存时，input 还没触发 change，
  // 只读 siteLinks 会把刚敲的东西丢掉（这是这类「列表 + 保存」最容易踩的坑）。
  document.querySelectorAll('.link-name').forEach(el => { siteLinks[+el.dataset.i].name = el.value; });
  document.querySelectorAll('.link-url').forEach(el => { siteLinks[+el.dataset.i].url = el.value; });
  const bad = siteLinks.findIndex(x => (x.url || '').trim() && !/^https?:\/\//i.test((x.url || '').trim()));
  if (bad >= 0) { toast('第 ' + (bad + 1) + ' 条的地址要以 http:// 或 https:// 开头'); return; }
  try {
    await api('/api/admin/config', { method: 'POST', headers: { 'Content-Type': 'application/json' },
                                     body: JSON.stringify({ links: siteLinks }) });
    await loadLinks();          // 以后端返回的为准（空行会被丢掉、超长会被截断）
    toast('友链已保存');
  } catch (e) { toast(e.message); }
}

// ---------- 听书（TTS）设置 ----------
// 读取：GET /api/admin/config 的 tts 对象（enabled 为布尔，listen_cost/timeout 可能是字符串或数字）
async function loadTtsSettings() {
  try {
    const c = await api('/api/admin/config');
    const t = c.tts || {};
    const setVal = (id, v) => {
      const el = document.getElementById(id);
      if (el) el.value = (v === null || v === undefined) ? '' : String(v);
    };
    const en = document.getElementById('tts-enabled');
    if (en) en.checked = !!t.enabled;
    renderTtsServers(t.servers || [], t);
    setVal('tts-listen-cost', (t.listen_cost === undefined || t.listen_cost === null || t.listen_cost === '') ? 30 : t.listen_cost);
    setVal('tts-timeout', (t.timeout === undefined || t.timeout === null || t.timeout === '') ? 120 : t.timeout);
  } catch (e) {}
}
// 保存：POST /api/admin/config（JSON），body 里带 tts 对象，后端会与现有配置合并
async function saveTtsSettings() {
  const val = id => { const el = document.getElementById(id); return el ? el.value.trim() : ''; };
  const en = document.getElementById('tts-enabled');
  const cost = parseInt(val('tts-listen-cost'), 10);
  const timeout = parseInt(val('tts-timeout'), 10);
  if (!(cost >= 0)) { toast('每本书消耗树叶需为 0 或正整数'); return; }
  if (!(timeout >= 10)) { toast('单句合成超时需为不小于 10 的整数'); return; }
  const servers = collectTtsServers();
  if (servers === null) return;   // 校验失败，collect 里已提示
  // 默认音色 / 音色白名单已经改成每台服务器各配一份，放在 servers 里一起提交。
  // 不再提交顶层的 default_voice / voices —— 提交空串会把老配置里的值清掉。
  const body = { tts: {
    enabled: !!(en && en.checked),
    servers: servers,
    listen_cost: cost,
    timeout: timeout,
  } };
  try {
    await api('/api/admin/config', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    toast('听书设置已保存');
    loadTtsSettings();
  } catch (e) { toast(e.message); }
}
// ---- TTS 服务器列表（多机分流 / 故障转移）----
// 后端把 tts_servers 存成 JSON 数组；没配过时 settings() 会用旧的单机 base_url 自动合成一条，
// 所以这里拿到的永远是「至少一条」，老配置打开后台就能直接看到、不用手工迁移。
function renderTtsServers(list, t) {
  const box = document.getElementById('tts-servers');
  if (!box) return;
  if (!list.length) list = [{ name: '默认', url: (t && t.base_url) || '', key: (t && t.api_key) || '', model: (t && t.model) || 'indextts-2', enabled: 1 }];
  // 老配置只有一份全局默认音色/白名单。这里把它填进每台服务器，
  // 界面上看到的就是实际生效值；保存后每台就都有自己的一份了。
  ttsLegacy = { default_voice: (t && t.default_voice) || '', voices: (t && t.voices) || '' };
  list = list.map(s => Object.assign({}, s, {
    default_voice: (s.default_voice === null || s.default_voice === undefined || s.default_voice === '')
      ? ttsLegacy.default_voice : s.default_voice,
    voices: (s.voices === null || s.voices === undefined) ? ttsLegacy.voices : s.voices,
  }));
  box.innerHTML = list.map(s => ttsServerRow(s)).join('');
}
let ttsLegacy = { default_voice: '', voices: '' };
// 每台服务器各自一份「默认音色 / 音色白名单」：
// 不同机器可能装不同模型、音色集不一样，统一配一份会互相打架。
function ttsServerRow(s) {
  s = s || {};
  const en = String(s.enabled === undefined ? 1 : s.enabled) !== '0';
  return `<div class="tts-srv">
    <div class="srv-line">
      <input class="srv-name" style="width:88px" placeholder="名称" value="${esc(s.name || '')}">
      <input class="srv-url" style="flex:1;min-width:210px" placeholder="http://198.51.100.3:8500" value="${esc(s.url || '')}">
      <input class="srv-key" style="width:160px" placeholder="API Key" value="${esc(s.key || '')}">
      <input class="srv-model" style="width:110px" placeholder="模型" value="${esc(s.model || 'indextts-2')}">
      <label style="font-size:13px;white-space:nowrap"><input type="checkbox" class="srv-enabled"${en ? ' checked' : ''}> 启用</label>
      <button class="btn ghost" onclick="delTtsServer(this)">删除</button>
    </div>
    <div class="srv-line">
      <span class="srv-lb">默认音色</span>
      <input class="srv-dvoice" style="width:150px" placeholder="如 pool_49" value="${esc(s.default_voice || '')}">
      <span class="srv-lb">音色白名单</span>
      <input class="srv-voices" style="flex:1;min-width:200px" placeholder="逗号分隔的音色 id，留空=这台的音色全部可选" value="${esc(s.voices || '')}">
    </div>
  </div>`;
}
function addTtsServer() {
  const box = document.getElementById('tts-servers');
  if (!box) return;
  const n = box.querySelectorAll('.tts-srv').length + 1;
  box.insertAdjacentHTML('beforeend', ttsServerRow({
    name: '服务器 ' + n, model: 'indextts-2', enabled: 1,
    default_voice: ttsLegacy.default_voice, voices: ttsLegacy.voices }));
}
function delTtsServer(btn) {
  const row = btn.closest('.tts-srv');
  const box = document.getElementById('tts-servers');
  if (row) row.remove();
  if (box && !box.querySelectorAll('.tts-srv').length) {
    box.innerHTML = ttsServerRow({ name: '默认', model: 'indextts-2', enabled: 1 });
  }
}
// 收集并校验。返回 null 表示校验不通过（已 toast）
function collectTtsServers() {
  const box = document.getElementById('tts-servers');
  if (!box) return [];
  const out = [];
  const seen = {};
  for (const row of box.querySelectorAll('.tts-srv')) {
    const g = c => { const el = row.querySelector(c); return el ? el.value.trim() : ''; };
    const url = g('.srv-url');
    if (!url) continue;                      // 地址为空的整行忽略
    if (!/^https?:\/\//i.test(url)) { toast('服务器地址要以 http:// 或 https:// 开头：' + url); return null; }
    const key = url.replace(/\/+$/, '');
    if (seen[key]) { toast('服务器地址重复：' + key); return null; }
    seen[key] = 1;
    const enEl = row.querySelector('.srv-enabled');
    out.push({
      name: g('.srv-name') || key,
      url: key,
      key: g('.srv-key'),
      model: g('.srv-model') || 'indextts-2',
      enabled: (enEl && enEl.checked) ? 1 : 0,
      default_voice: g('.srv-dvoice'),
      voices: g('.srv-voices'),
    });
  }
  if (!out.length) { toast('至少要配置一台 TTS 服务器'); return null; }
  if (out.every(s => !s.enabled)) { toast('至少要启用一台 TTS 服务器'); return null; }
  return out;
}

// 秒 → 小时/分钟
function ttsFmtUptime(sec) {
  const s = Math.max(0, Math.floor(Number(sec) || 0));
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60);
  if (h > 0) return h + ' 小时 ' + m + ' 分钟';
  if (m > 0) return m + ' 分钟';
  return s + ' 秒';
}
async function testTtsConnection() {
  const box = document.getElementById('tts-test-result');
  if (box) box.innerHTML = '<span class="muted" style="font-size:13px">正在逐台测试连接…</span>';
  try {
    const d = await api('/api/admin/tts/test');
    const h = d.health || {};
    const srvs = d.servers || [];
    const rows = srvs.map(x => {
      const hh = x.health || {};
      const vram = (hh.vram_gb !== undefined && hh.vram_gb !== null) ? esc(hh.vram_gb) + ' GB' : '—';
      // uptime 是 /health 一直就返回、但界面从来没有展示过的字段
      const up = (hh.uptime !== undefined && hh.uptime !== null) ? esc(ttsFmtUptime(hh.uptime)) : '—';
      const mark = x.ok
        ? '<b style="color:#1a9c5b">正常</b>'
        : '<b style="color:#c0392b">不通</b>';
      const why = x.ok ? '' : '<span class="muted">　' + esc(hh.error || hh.status || '未知错误') + '</span>';
      const dis = x.enabled ? '' : '<span class="muted">（已停用，不参与派发）</span>';
      return `<div style="padding:4px 0;border-bottom:1px dashed #eee">
        <div>${mark}　<b>${esc(x.name || '')}</b>　<span class="muted">${esc(x.url || '')}</span>${dis}${why}</div>
        <div class="muted" style="font-size:12px">模型：${esc(x.model || '—')}　显存：${vram}　已运行：${up}</div>
      </div>`;
    }).join('');
    const liveN = srvs.filter(x => x.ok && x.enabled).length;
    const enN = srvs.filter(x => x.enabled).length;
    const head = d.ok
      ? `<div><b style="color:#1a9c5b">连接正常</b><span class="muted">　${liveN}/${enN} 台可用${enN > 1 ? '，按轮询分流' : ''}</span>${d.enabled ? '' : '<span class="muted">　（听书总开关当前为关闭）</span>'}</div>`
      : `<div><b style="color:#c0392b">全部服务器都不通</b><span class="muted">　听书会失败，请检查服务是否启动、地址与 API Key 是否正确</span></div>`;
    const sample = (d.voice_sample || []).map(v => {
      const lbl = (v.label && v.label !== v.id) ? '（' + v.label + '）' : '';
      const gd = v.gender ? ' ' + v.gender : '';
      return `<span class="tag">${esc(v.id)}${esc(lbl)}${esc(gd)}</span>`;
    }).join(' ');
    if (box) box.innerHTML = `<div style="font-size:13px;line-height:1.9">
      ${head}${rows}
      ${d.ok ? `<div class="muted" style="margin-top:6px">可用音色：${Number(d.voice_count || 0)} 个${sample ? '　示例：' + sample : ''}</div>` : ''}
    </div>`;
    toast(d.ok ? 'TTS 连接正常' : '所有 TTS 服务器都不通');
  } catch (e) {
    if (box) box.innerHTML = `<div style="font-size:13px"><b style="color:#c0392b">测试失败</b><span class="muted">　${esc(e.message)}</span></div>`;
    toast(e.message);
  }
}

// 消息正文渲染（与 app.js 中同名函数保持一致；admin 页面不加载 app.js，故此处单独实现）
// 转义（防 XSS）→ 指定词语变链接 → 裸网址变链接 → 换行转 <br>
function msgBodyHtml(body, linkUrl, linkText) {
  let h = (String(body == null ? '' : body)).replace(/[&<>"']/g,
    c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const A = (u, t) => `<a href="${u.replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]))}" target="_blank" rel="noopener noreferrer">${t}</a>`;
  const url = String(linkUrl || ''), word = String(linkText || '');
  if (word && /^https?:\/\//i.test(url)) {
    const w = word.replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    if (h.indexOf(w) >= 0) h = h.split(w).join(A(url, w));
  }
  h = h.replace(/\[([^\]\n]+)\]\(([^)\s]+)\)/g, (m, text, u) => {
    const uu = u.replace(/&amp;/g, '&');
    return /^https?:\/\//i.test(uu) ? A(uu, text) : m;
  });
  h = h.replace(/(^|[^"'=>])(https?:\/\/[^\s<>"）)]+)/g, (m, pre, u) => pre + A(u, u));
  return h.replace(/\n/g, '<br>');
}

// ---------- 新注册消息管理 ----------
let welcomeDefault = '', welcomeDefLink = '';
async function loadWelcome() {
  try {
    const d = await api('/api/admin/welcome');
    const el = document.getElementById('welcome-msg');
    if (el) el.value = d.content || '';
    const lk = document.getElementById('welcome-link');
    if (lk) lk.value = d.link || '';
    const sw = document.getElementById('welcome-enabled');
    if (sw) sw.checked = !!d.enabled;
    welcomeDefault = d.default_content || '';
    welcomeDefLink = d.link || '';
  } catch (e) {}
}
async function saveWelcome(content, link, okMsg) {
  try {
    const ta = document.getElementById('welcome-msg');
    const lk = document.getElementById('welcome-link');
    const sw = document.getElementById('welcome-enabled');
    const body = {
      content: content !== undefined ? content : (ta ? ta.value : ''),
      link: link !== undefined ? link : (lk ? lk.value : ''),
      enabled: sw ? sw.checked : true,
    };
    const r = await api('/api/admin/welcome', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    if (ta && content !== undefined) ta.value = r.content || '';
    if (lk && link !== undefined) lk.value = r.link || '';
    toast(okMsg || '欢迎消息已保存');
  } catch (e) { toast(e.message); }
}
function toggleWelcome(on) {
  saveWelcome(undefined, undefined, on ? '已开启新注册欢迎消息' : '已关闭新注册欢迎消息');
}
function resetWelcome() {
  if (!welcomeDefault) { toast('请刷新页面后再试'); return; }
  if (!confirm('恢复为默认文案与默认链接？')) return;
  const ta = document.getElementById('welcome-msg'), lk = document.getElementById('welcome-link');
  if (ta) ta.value = welcomeDefault;
  if (lk) lk.value = welcomeDefLink;
  saveWelcome(undefined, undefined, '已恢复默认内容');
}
// 预览：与用户真实收到的消息完全同一种渲染
function previewWelcome() {
  const ta = document.getElementById('welcome-msg'), lk = document.getElementById('welcome-link');
  const raw = ta ? ta.value : '', url = lk ? lk.value : '';
  const html = msgBodyHtml(raw, url, '使用介绍');
  openModal(`<button class="close" onclick="closeModal()">✕</button>
    <h3 style="margin-bottom:8px">欢迎消息预览</h3>
    <div class="msg-detail-meta">
      <span class="msg-kind sys">系统</span>
      <span class="muted">系统消息</span>
    </div>
    <div class="msg-detail-body">${html || '（无正文）'}</div>
    <div style="margin-top:16px"><button class="btn block ghost" onclick="closeModal()">关闭</button></div>`);
}

// ---------- 功能介绍内容编辑（仅管理员） ----------
async function loadIntro() {
  try {
    const d = await api('/api/admin/intro');
    document.getElementById('intro-content').value = d.content || '';
  } catch (e) {}
}
async function saveIntro() {
  try {
    await api('/api/admin/intro', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ content: document.getElementById('intro-content').value }) });
    toast('功能介绍已保存');
  } catch (e) { toast(e.message); }
}

// ---------- 标签页切换 ----------
let adminBooks = [];
function switchSec(sec) {
  document.querySelectorAll('.admin-tabs .at').forEach(x => x.classList.toggle('active', x.dataset.sec === sec));
  ['overview', 'books', 'listen', 'share', 'booklist', 'reports', 'audit', 'filelog', 'actlog', 'sitestats', 'audiolib'].forEach(s => {
    const el = document.getElementById('sec-' + s);
    if (el) el.classList.toggle('hidden', s !== sec);
  });
  if (sec === 'books') { loadAdminBooks(); loadDup(); }
  if (sec === 'listen') loadListenAdmin();
  if (sec === 'share') { loadShareRequests(1); loadRewards(); }
  if (sec === 'booklist') { loadBooklistReview('pending', 1); loadRewards(); }
  if (sec === 'reports') loadReports();
  if (sec === 'audit') loadAudit();
  if (sec === 'filelog') loadFileLogs();
  if (sec === 'actlog') loadActivity('all');
  if (sec === 'sitestats') loadSiteStats();
  if (sec === 'audiolib') alLoad();
}

// ---------- 审核分页通用 ----------
const REVIEW_PAGE_SIZE = 15;
// 渲染一个「上一页 / 第 x/y 页（共 n 条）/ 下一页」分页条
function reviewPager(elId, page, pages, total, fn) {
  const el = document.getElementById(elId);
  if (!el) return;
  if (!total) { el.innerHTML = ''; return; }
  if (pages <= 1) {
    el.innerHTML = `<span class="muted" style="font-size:12px">共 ${total} 条</span>`;
    return;
  }
  el.innerHTML = `<button ${page <= 1 ? 'disabled' : ''} onclick="${fn}(${page - 1})">上一页</button>
    <span>${page} / ${pages}（共 ${total} 条）</span>
    <button ${page >= pages ? 'disabled' : ''} onclick="${fn}(${page + 1})">下一页</button>`;
}

// ---------- 树叶奖励设置 ----------
async function loadRewards() {
  try {
    const d = await api('/api/admin/config');
    [['reward_booklist', 'reward_booklist'], ['reward_share_article', 'reward_share_article'],
     ['reward_share_request', 'reward_share_request']].forEach(([elId, k]) => {
      const el = document.getElementById(elId);
      if (el) el.value = d[k];
    });
    // 可申请共享的电子书格式（只限制共享，不限制上传）
    shareFmtChoices = d.share_format_choices || [];
    shareFmtOn = d.share_formats || [];
    renderShareFormats();
  } catch (e) {}
}

// ---------- 可申请共享的电子书格式 ----------
let shareFmtChoices = [];   // 全部可选项
let shareFmtOn = [];        // 当前勾选的
function renderShareFormats() {
  const el = document.getElementById('share-fmt-list');
  if (!el) return;
  el.innerHTML = shareFmtChoices.map(x => `<label class="fmt-check"><input type="checkbox" class="share-fmt"
      value="${esc(x)}"${shareFmtOn.includes(x) ? ' checked' : ''} onchange="updShareFmtState()">
      <span>${esc(x.toUpperCase())}</span></label>`).join('');
  updShareFmtState();
}
function shareFmtAll(on) {
  document.querySelectorAll('.share-fmt').forEach(c => { c.checked = !!on; });
  updShareFmtState();
}
function updShareFmtState() {
  // 勾选态同步到 label（不依赖 :has()，兼容性更稳）
  document.querySelectorAll('.fmt-check').forEach(l => {
    const c = l.querySelector('input');
    l.classList.toggle('on', !!(c && c.checked));
  });
  const n = document.querySelectorAll('.share-fmt:checked').length;
  const el = document.getElementById('share-fmt-state');
  if (el) el.textContent = n ? `已选 ${n} 种格式可申请共享` : '当前：所有格式都不允许申请共享';
}
async function saveShareFormats() {
  const fmts = [...document.querySelectorAll('.share-fmt:checked')].map(c => c.value);
  try {
    const r = await api('/api/admin/config', { method: 'POST', headers: { 'Content-Type': 'application/json' },
                                               body: JSON.stringify({ share_formats: fmts }) });
    shareFmtOn = r.share_formats || [];
    renderShareFormats();
    toast(fmts.length ? `已保存：仅这 ${fmts.length} 种格式可申请共享` : '已保存：所有格式都不允许申请共享');
    if (typeof loadShareRequests === 'function') loadShareRequests(sharePage);
  } catch (e) { toast(e.message); }
}
async function saveReward(key) {
  const el = document.getElementById(key);
  if (!el) return;
  const name = { reward_booklist: '「书单」文章通过', reward_share_article: '「分享」文章通过',
                 reward_share_request: '电子书共享通过' }[key] || key;
  try {
    const body = {}; body[key] = el.value;
    const d = await api('/api/admin/config', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    el.value = d[key];
    toast(`${name}奖励已设为 ${d[key]} 树叶` + (d[key] ? '' : '（不发放）'));
  } catch (e) { toast(e.message); }
}

// ---------- 书单审核 ----------
let blReviewStatus = 'pending', blReviewPage = 1, blCommentPage = 1, blComments = [];
const BL_STATUS_TEXT = { pending: '待审核文章', approved: '已通过文章', rejected: '已拒绝文章' };
async function loadBooklistBadge() {
  try {
    const d = await api('/api/admin/booklist-review?status=pending');
    const badge = document.getElementById('bl-badge');
    const n = (d.pending_articles || 0) + (d.pending_comments || 0);
    if (badge) { badge.style.display = n ? '' : 'none'; badge.textContent = n; }
  } catch (e) {}
}
async function loadBooklistReview(status, page) {
  if (status) blReviewStatus = status;
  blReviewPage = Math.max(1, page || 1);
  const sel = document.getElementById('bl-review-sel');
  if (sel) sel.textContent = BL_STATUS_TEXT[blReviewStatus] || '';
  try {
    const d = await api(`/api/admin/booklist-review?status=${blReviewStatus}&page=${blReviewPage}&cpage=${blCommentPage}`);
    blReviewPage = d.page; blCommentPage = d.cpage;
    const wrap = document.getElementById('bl-review-list');
    if (!d.articles.length) { wrap.innerHTML = '<p class="muted" style="margin:0;font-size:13px">暂无</p>'; }
    else {
      wrap.innerHTML = d.articles.map(a => `<div class="list-item">
        <div class="txt">
          <div class="tt">${esc(a.title)} <span class="badge ${a.status === 'pending' ? 'no' : (a.status === 'approved' ? 'ok' : 'bad')}">${({pending:'待审核', approved:'已通过', rejected:'已拒绝'})[a.status]}</span>${a.tag ? ` <span class="badge ${a.tag === 'share' ? 'share' : (a.tag === 'discuss' ? 'discuss' : 'find')}">${({share:'书单', discuss:'讨论', find:'分享'})[a.tag] || ''}</span>` : ''}</div>
          <div class="aa">${esc(a.author_name)} · ${esc(a.created_at || '')} · 阅读 ${a.view_count}</div>
          <div class="aa" style="white-space:pre-wrap;color:#666">${esc((a.content || '').slice(0, 120))}</div>
        </div>
        <div style="display:flex;gap:8px">
          ${a.status === 'pending' ? `<button class="btn sm" onclick="reviewArticle(${a.id},'approve')">通过</button>
          <button class="btn danger sm" onclick="reviewArticle(${a.id},'reject')">拒绝</button>` : ''}
          <button class="btn ghost sm" onclick="reviewArticleDetail(${a.id})">详情</button>
        </div></div>`).join('');
    }
    const tot = document.getElementById('bl-review-total');
    if (tot) tot.textContent = d.total ? `共 ${d.total} 篇` : '';
    reviewPager('bl-review-pager', d.page, d.pages, d.total, 'goBlReviewPage');
    renderBlComments(d.comments || [], d.cpage, d.cpages, d.ctotal);
    loadBooklistBadge();
  } catch (e) { toast(e.message); }
}
function goBlReviewPage(p) { loadBooklistReview(blReviewStatus, p); }
function goBlCommentPage(p) { blCommentPage = p; loadBooklistReview(blReviewStatus, blReviewPage); }
function renderBlComments(comments, page, pages, total) {
  blComments = comments;
  const wrap = document.getElementById('bl-comment-review');
  if (!comments.length) { wrap.innerHTML = '<p class="muted" style="margin:0;font-size:13px">暂无待审查回复</p>'; }
  else {
    wrap.innerHTML = comments.map(c => `<div class="list-item">
      <div class="txt">
        <div class="tt">《${esc(c.bl_title || '书单')}》 · ${esc(c.user_name)}</div>
        <div class="aa" style="white-space:pre-wrap;color:#666">${esc(c.content)}</div>
        <div class="aa">${esc(c.created_at || '')}</div>
      </div>
      <div style="display:flex;gap:8px">
        <button class="btn sm" onclick="reviewBlComment(${c.id},'approve')">通过</button>
        <button class="btn danger sm" onclick="reviewBlComment(${c.id},'reject')">拒绝</button>
      </div></div>`).join('');
  }
  reviewPager('bl-comment-pager', page, pages, total, 'goBlCommentPage');
}

// 驳回理由弹窗（书单审核 / 共享审核通用）：理由会原文显示在申请人「我的消息」里
// presets：可选，给出几个现成理由（点击填进输入框，仍可再改），
//          例如共享审核在书库已有同名书时给「书库中已存在同名电子书」。
let adminRejectCb = null;
function askRejectReason(title, hint, cb, presets) {
  const ps = (presets || []).filter(x => x && x.text);
  const presetHtml = ps.length ? `<div class="form-group">
      <label>常用理由（点击填入，可再修改）</label>
      <div class="chips" style="margin:0">
        ${ps.map((x, i) => `<button type="button" class="chip" data-rj="${esc(x.text)}"
            data-extra="${esc(x.extra || '')}" onclick="pickRejectReason(${i})">${esc(x.label || x.text)}</button>`).join('')}
      </div>
      ${ps.some(x => x.extra) ? `<p class="muted" style="font-size:12px;margin:8px 0 0" id="admin-rj-note"></p>` : ''}
    </div>` : '';
  openModal(`<button class="close" onclick="closeModal()">✕</button>
    <h3>${esc(title)}</h3>
    <p class="muted" style="font-size:13px;line-height:1.7;margin:6px 0 12px">${esc(hint)}</p>
    ${presetHtml}
    <div class="form-group">
      <label>驳回理由（可不填）</label>
      <textarea id="admin-rj" rows="4" maxlength="200"
        placeholder="例如：文件内容不完整 / 与本站收录范围不符 / 正文缺少推荐理由"></textarea>
    </div>
    <div style="display:flex;gap:8px;justify-content:flex-end">
      <button class="btn ghost" onclick="closeModal()">取消</button>
      <button class="btn danger" onclick="submitAdminReject()">确定驳回</button>
    </div>`);
  adminRejectCb = cb;
  window.__rjPresets = ps;      // 供 pickRejectReason 取用（含 extra 说明）
  setTimeout(() => { const t = document.getElementById('admin-rj'); if (t) t.focus(); }, 60);
}
// 点击「常用理由」：把理由正文填进输入框；extra 是对应书库已有书的说明，显示在下方
function pickRejectReason(i) {
  const ps = window.__rjPresets || [];
  const p = ps[i];
  if (!p) return;
  const t = document.getElementById('admin-rj');
  if (t) t.value = p.text;
  const note = document.getElementById('admin-rj-note');
  if (note) note.textContent = p.extra ? '对应书库已有：' + p.extra : '';
  document.querySelectorAll('.chips .chip[data-rj]').forEach(b => b.classList.toggle('active', b.dataset.rj === p.text));
}
function submitAdminReject() {
  const el = document.getElementById('admin-rj');
  const r = (el ? el.value : '').trim();
  if (r.length > 200) { toast('驳回理由最多 200 字'); return; }
  const cb = adminRejectCb; adminRejectCb = null;
  window.__rjPresets = null;
  closeModal();
  if (cb) cb(r);
}
async function reviewArticle(id, action) {
  if (action === 'reject') {
    return askRejectReason('驳回文章', '驳回后文章不会公开展示。理由会原文显示在作者的「我的消息」里。',
                           reason => doReviewArticle(id, 'reject', reason));
  }
  if (!confirm('确定通过该书单？')) return;
  doReviewArticle(id, 'approve', '');
}
async function doReviewArticle(id, action, reason) {
  try {
    const r = await api('/api/admin/booklists/' + id + '/review', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: action, reason: reason || '' })
    });
    toast((action === 'approve' ? '已通过' : '已驳回，理由已通知作者') + (r && r.leaves ? `，奖励作者 ${r.leaves} 树叶` : ''));
    loadBooklistReview(blReviewStatus, blReviewPage);
  } catch (e) { toast(e.message); }
}
async function reviewArticleDetail(id) {
  try {
    const d = await api('/api/booklists/' + id);
    openModal(`<button class="close" onclick="closeModal()">✕</button>
      <h3>${esc(d.article.title)}</h3>
      <p class="muted" style="font-size:12px">${esc(d.author_name)} · ${esc(d.article.created_at || '')}</p>
      <div style="max-height:60vh;overflow-y:auto;white-space:pre-wrap;word-break:break-word">${esc(d.article.content)}</div>`);
  } catch (e) { toast(e.message); }
}
async function reviewBlComment(cid, action) {
  // 管理员审查待审查回复：从当前页缓存里取所属书单（分页后不再全量拉取）
  try {
    const c = (blComments || []).find(x => x.id === cid);
    if (!c) { toast('回复不存在，请刷新列表'); return; }
    await api(`/api/booklists/${c.booklist_id}/comments/${cid}/review`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action })
    });
    toast(action === 'approve' ? '已通过' : '已拒绝');
    loadBooklistReview(blReviewStatus);
  } catch (e) { toast(e.message); }
}

// ---------- 书籍管理（批量操作 + 去重） ----------
let bkPage = 1, bkQ = '';
async function loadAdminBooks(page) {
  if (page) bkPage = page;
  bkQ = document.getElementById('bk-q').value.trim();
  try {
    const d = await api('/api/books?q=' + encodeURIComponent(bkQ) + '&page=' + bkPage + '&size=50');
    adminBooks = d.items;
    const wrap = document.getElementById('admin-book-list');
    wrap.innerHTML = `<div style="overflow-x:auto"><table class="user-table">
      <thead><tr><th><input type="checkbox" onchange="toggleAllBooks(this.checked)"></th><th>书名</th><th>作者</th><th>ISBN</th><th>分类</th><th>大小</th></tr></thead>
      <tbody>${adminBooks.map(b => `<tr>
        <td><input type="checkbox" class="bk-chk" value="${b.id}" onchange="updSelCount()"></td>
        <td>${esc(b.title)}${b.hidden ? ' <span class="badge no">已下架</span>' : ''}${b.guest_featured ? ' <span class="badge ok">推荐</span>' : ''}</td>
        <td>${esc(b.author || '—')}</td>
        <td>${esc(b.isbn || '—')}</td>
        <td>${esc(b.category || '—')}</td>
        <td>${b.size_mb} MB</td>
      </tr>`).join('')}</tbody></table></div>`;
    const pager = document.getElementById('admin-book-pager');
    const totalPages = Math.max(1, Math.ceil(d.total / 50));
    pager.innerHTML = `<button ${bkPage <= 1 ? 'disabled' : ''} onclick="loadAdminBooks(${bkPage - 1})">上一页</button>
      <span>${bkPage} / ${totalPages}（共 ${d.total} 本）</span>
      <button ${bkPage >= totalPages ? 'disabled' : ''} onclick="loadAdminBooks(${bkPage + 1})">下一页</button>`;
  } catch (e) { toast(e.message); }
}
function toggleAllBooks(on) { document.querySelectorAll('.bk-chk').forEach(c => c.checked = on); updSelCount(); }
function selectedBooks() { return [...document.querySelectorAll('.bk-chk:checked')].map(c => parseInt(c.value)); }
function updSelCount() { document.getElementById('bk-sel').textContent = '已选 ' + selectedBooks().length + ' 本'; }
async function batchOp(action) {
  const ids = selectedBooks();
  if (!ids.length) return toast('请先勾选书籍');
  const tip = action === 'delete' ? '确认删除所选 ' + ids.length + ' 本书及其 FTP 文件？' : '将对所选 ' + ids.length + ' 本书批量刮削封面？';
  if (!confirm(tip)) return;
  try {
    const r = await api('/api/books/batch', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: action, ids: ids }) });
    toast('完成 ' + r.done + ' 本' + (r.fail ? '，失败 ' + r.fail + ' 本' : ''));
    loadAdminBooks();
  } catch (e) { toast(e.message); }
}
function guestFeature() {
  const ids = selectedBooks();
  if (!ids.length) return toast('请先勾选书籍');
  openModal(`<button class="close" onclick="closeModal()">✕</button><h3>访客热度推荐</h3>
    <p class="muted" style="font-size:13px">已选 ${ids.length} 本书。设为推荐后：<b>未登录访客</b>可在首页看到并可阅读、下载这些书；<b>登录用户</b>会在首页「🔥 热度推荐」板块看到（最多 6 本）。</p>
    <div style="display:flex;gap:8px;margin-top:12px">
      <button class="btn" onclick="doGuestFeature(1)">设为推荐</button>
      <button class="btn ghost" onclick="doGuestFeature(0)">取消推荐</button>
    </div>`);
}
async function doGuestFeature(featured) {
  const ids = selectedBooks();
  try {
    const r = await api('/api/admin/books/guest-feature', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ book_ids: ids, featured: featured }) });
    closeModal(); toast((featured ? '已设为推荐 ' : '已取消推荐 ') + r.count + ' 本'); loadAdminBooks();
  } catch (e) { toast(e.message); }
}
async function showBatchMove() {
  const ids = selectedBooks();
  if (!ids.length) return toast('请先勾选书籍');
  const folders = await api('/api/cat-folders').catch(() => []);
  const opts = folders.map(f => `<option value="${esc(f.folder)}">${esc(f.letter === '00' ? '待分类' : f.letter + ' · ' + f.label)}</option>`).join('');
  openModal(`<button class="close" onclick="closeModal()">✕</button><h3>批量移动分类</h3>
    <p class="muted" style="font-size:13px">将所选 ${ids.length} 本书移动到目标分类</p>
    <div class="form-group"><label>目标分类</label><select id="bm-cat">${opts}</select></div>
    <button class="btn block" onclick="doBatchMove()">移动</button>`);
}
async function doBatchMove() {
  const ids = selectedBooks();
  const cat = document.getElementById('bm-cat').value;
  try {
    const r = await api('/api/books/batch', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'move', ids: ids, category: cat }) });
    closeModal(); toast('移动完成 ' + r.done + ' 本'); loadAdminBooks();
  } catch (e) { toast(e.message); }
}
async function loadDup() {
  const wrap = document.getElementById('dup-list');
  try {
    const d = await api('/api/admin/duplicates');
    if (!d.groups.length) { wrap.innerHTML = '<p class="muted">未发现重复书籍</p>'; return; }
    wrap.innerHTML = d.groups.slice(0, 50).map(g => `<div class="list-item">
      <div class="txt"><div class="tt">${esc(g.key)} <span class="badge">${g.kind === 'isbn' ? 'ISBN' : '同名'}</span></div>
      <div class="aa">${g.count} 本重复</div></div>
      <div style="display:flex;gap:6px"><button class="btn ghost sm" onclick="viewDup(${JSON.stringify(g.books).replace(/"/g, '&quot;')})">查看</button></div>
    </div>`).join('');
  } catch (e) { wrap.innerHTML = '<p class="muted">加载失败</p>'; }
}
function viewDup(books) {
  openModal(`<button class="close" onclick="closeModal()">✕</button><h3>重复书籍（${books.length} 本）</h3>
    <div style="display:flex;gap:8px;align-items:center;margin-bottom:8px;flex-wrap:wrap">
      <button class="btn sm" onclick="dupSelAll()">全选</button>
      <button class="btn sm" onclick="dupSelInvert()">反选</button>
      <button class="btn danger sm" onclick="dupDelSelected()">删除选中（<span id="dup-sel-count">0</span>本）</button>
    </div>
    <div id="dup-modal-list" style="max-height:55vh;overflow:auto">${books.map(b => `<label class="list-item" style="cursor:pointer">
      <input type="checkbox" class="dup-check" value="${b.id}" onchange="dupSelCount()" style="width:16px;height:16px;flex:none">
      <div class="txt"><div class="tt">${esc(b.title)}${b.hidden ? ' <span class="badge no">已下架</span>' : ''}</div>
      <div class="aa" style="white-space:normal">ID ${b.id} · ${esc(b.author || '佚名')} · ${b.size_mb} MB · ${esc(b.isbn || '无ISBN')}</div>
      <div class="aa" style="white-space:normal;color:#888">目录：${esc(b.path || b.category || '未分类')}</div></div>
    </label>`).join('')}</div>`);
}
function dupSelAll() { document.querySelectorAll('.dup-check').forEach(c => { c.checked = true; }); dupSelCount(); }
function dupSelInvert() { document.querySelectorAll('.dup-check').forEach(c => { c.checked = !c.checked; }); dupSelCount(); }
function dupSelCount() { const el = document.getElementById('dup-sel-count'); if (el) el.textContent = document.querySelectorAll('.dup-check:checked').length; }
async function dupDelSelected() {
  const ids = [...document.querySelectorAll('.dup-check:checked')].map(c => parseInt(c.value));
  if (!ids.length) { toast('请先勾选要删除的书籍'); return; }
  if (!confirm('确认删除选中的 ' + ids.length + ' 本书？')) return;
  try {
    const r = await api('/api/books/batch', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'delete', ids: ids }) });
    closeModal(); toast('已删除 ' + r.done + ' 本' + (r.fail ? '，失败 ' + r.fail + ' 本' : '')); loadAdminBooks(); loadDup();
  } catch (e) { toast(e.message); }
}

// ---------- 举报处理 ----------
async function loadReports() {
  const wrap = document.getElementById('report-list');
  try {
    const d = await api('/api/admin/reports');
    const badge = document.getElementById('report-badge');
    if (d.pending > 0) { badge.style.display = ''; badge.textContent = d.pending; } else badge.style.display = 'none';
    if (!d.reports.length) { wrap.innerHTML = '<p class="muted">暂无举报</p>'; return; }
    wrap.innerHTML = d.reports.map(r => `<div class="list-item">
      <div class="txt"><div class="tt">${esc(r.title || ('书 #' + r.book_id))} <span class="badge ${r.status === 'pending' ? 'no' : 'ok'}">${r.status === 'pending' ? '待处理' : '已处理'}</span></div>
      <div class="aa">理由：${esc(r.reason)}${r.detail ? ' · ' + esc(r.detail) : ''} · 举报人 ${esc(r.username || '游客')} · ${esc((r.created_at||'').slice(0,16))}</div></div>
      ${r.status === 'pending' ? `<div style="display:flex;gap:6px">
        <button class="btn sm" onclick="handleReport(${r.id},'takedown')">下架</button>
        <button class="btn ghost sm" onclick="handleReport(${r.id},'dismiss')">忽略</button></div>` : ''}
    </div>`).join('');
  } catch (e) { wrap.innerHTML = '<p class="muted">加载失败</p>'; }
}
async function handleReport(id, action) {
  try { await api('/api/admin/reports/' + id + '/handle', { method: 'POST', body: new URLSearchParams({ action: action }) }); toast(action === 'takedown' ? '已下架' : '已忽略'); loadReports(); loadAdminBooks(); }
  catch (e) { toast(e.message); }
}

// ---------- 共享审核 ----------
function updShareSel() {
  document.getElementById('share-sel').textContent = '已选 ' + document.querySelectorAll('.share-chk:checked').length + ' 项';
}
let sharePage = 1;
let shareItems = [];        // 当前页共享申请（驳回时用于生成「书库已有同名书」理由）
async function loadShareRequests(page) {
  sharePage = Math.max(1, page || 1);
  const wrap = document.getElementById('share-list');
  try {
    const d = await api(`/api/admin/share-requests?page=${sharePage}&size=${REVIEW_PAGE_SIZE}`);
    sharePage = d.page;
    const badge = document.getElementById('share-badge');
    if (d.pending > 0) { badge.style.display = ''; badge.textContent = d.pending; } else badge.style.display = 'none';
    const tot = document.getElementById('share-total');
    if (tot) tot.textContent = d.total ? `共 ${d.total} 条` : '';
    reviewPager('share-pager', d.page, d.pages, d.total, 'loadShareRequests');
    if (!d.requests.length) { wrap.innerHTML = '<p class="muted">暂无共享申请</p>'; return; }
    const st = { pending: '待审核', approved: '已通过', rejected: '已拒绝' };
    shareItems = d.requests || [];       // 缓存当前页，驳回时用来生成「书库已有同名书」理由
    wrap.innerHTML = d.requests.map(r => `<div class="list-item">
      <div class="txt">
        <div class="tt">${r.status === 'pending' ? `<input type="checkbox" class="share-chk" value="${r.id}" onchange="updShareSel()"> ` : ''}${esc(r.title || ('书 #' + r.book_id))} <span class="badge ${r.status === 'pending' ? 'no' : 'ok'}">${st[r.status] || r.status}</span>${shareSimBadge(r)}</div>
        <div class="aa">${esc(r.author || '佚名')} · ${esc(r.ext || '').toUpperCase().replace('.', '')} · ${r.size ? (r.size/1048576).toFixed(2) + ' MB' : ''} · 上传者 ${esc(r.requester || '')} · ${esc((r.created_at || '').slice(0, 16))}${r.reviewed_at ? ' · 审核于 ' + esc(r.reviewed_at.slice(0, 16)) : ''}</div>
      </div>
    </div>`).join('');
  } catch (e) { wrap.innerHTML = '<p class="muted">加载失败</p>'; }
}
// 书库已有同名/相似书的提示徽标（鼠标悬停看具体书名）
function shareSimBadge(r) {
  const s = r && r.similar;
  if (!s || (!(s.same && s.same.length) && !(s.similar && s.similar.length))) return '';
  const sameN = (s.same || []).length + (s.more_same || 0);
  const simN = (s.similar || []).length + (s.more_similar || 0);
  const list = [].concat(s.same || [], s.similar || [])
    .map(x => `《${x.title}》${(x.ext || '').replace('.', '').toUpperCase()} ${(x.size || 0) / 1048576}MB`)
    .join('\n');
  const txt = [sameN ? `书库已有同名 ${sameN} 本` : '', simN ? `相似 ${simN} 本` : ''].filter(Boolean).join('、');
  return ` <span class="badge" style="background:#fef3c7;color:#92400e;cursor:help" title="${esc(list)}">${esc(txt)}</span>`;
}
// 勾选的申请里有几本在书库已有同名书 → 给「书库中已存在同名电子书」这个现成理由
function shareRejectPresets(ids) {
  const hit = (shareItems || []).filter(r => ids.includes(r.id) && r.similar
    && ((r.similar.same || []).length || (r.similar.more_same || 0)));
  if (!hit.length) return [];
  const names = hit.map(r => `《${r.title}》`).join('、');
  return [{ text: '书库中已存在同名电子书', label: '书库中已存在同名电子书',
            extra: names + (hit.length > 1 ? ` 等 ${hit.length} 本` : '') }];
}
async function handleShareRequests(action) {
  const ids = [...document.querySelectorAll('.share-chk:checked')].map(c => parseInt(c.value));
  if (!ids.length) return toast('请先勾选要审核的申请');
  if (action === 'reject') {
    return askRejectReason('驳回共享申请', '驳回后书籍仍归属上传者。理由会原文显示在申请人的「我的消息」里。',
                           reason => doHandleShareRequests(ids, 'reject', reason),
                           shareRejectPresets(ids));
  }
  doHandleShareRequests(ids, 'approve', '');
}
async function doHandleShareRequests(ids, action, reason) {
  try {
    const r = await api('/api/admin/share-requests/handle', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ids: ids, action: action, reason: reason || '' })
    });
    toast((action === 'approve' ? '已通过 ' : '已驳回 ') + r.done + ' 项' + (r.fail ? '，失败 ' + r.fail + ' 项' : ''));
    loadShareRequests(sharePage);
  } catch (e) { toast(e.message); }
}

// ---------- 审计日志 ----------
let auditPage = 1;
let auditQuery = '';
const AUDIT_PAGE_SIZE = 50;
// 审计动作的中文名。之前「操作」列直接显示 promote_gen 这种英文码，
// 管理员看不懂；这里给常见动作配上中文，原文挂在 title 上备查。
// 没配到的动作仍然原样显示英文码 —— 以后加新动作不用回来改这里。
const AUDIT_LABELS = {
  login: '登录', register: '注册', signin: '签到', download: '下载', upload: '上传',
  welcome_msg: '欢迎消息', admin_welcome: '设为欢迎', message_send: '发消息',
  message_broadcast: '群发消息', message_restore: '恢复消息',
  group_create: '新建分组', group_update: '改分组', group_delete: '删分组',
  group_exchange: '兑换权限', user_update: '改用户', user_delete: '删用户',
  admin_config: '改系统设置', admin_terms: '改用户须知', admin_intro: '改功能介绍',
  admin_ads: '改广告位', admin_listen: '改听书设置', admin_sync: '同步书库',
  admin_enrich: '补全书目', leaf_reward: '树叶奖励',
  booklist_publish: '发表书单', booklist_review: '书单审核', booklist_update: '改书单',
  booklist_delete: '删书单', booklist_pin: '置顶书单',
  booklist_comment_review: '书单回复审核', booklist_comment_delete: '删书单回复',
  book_share_request: '申请共享', book_share_review: '共享审核', book_share_approve: '共享通过',
  book_edit: '改书籍', book_delete: '删书籍', book_takedown: '下架书籍',
  book_batch_move: '批量移动', book_batch_delete: '批量删除', book_batch_scrape: '批量抓取',
  book_enrich: '补全书目', book_report: '举报处理', share_create: '创建分享',
  share_revoke: '取消分享', share_download: '分享下载', site_share: '站外分享',
  share_similar_fail: '相似分享失败', cover_upload: '上传封面', cover_online: '在线抓封面',
  convert: '格式转换', source_update: '改书源', xunlei_import: '迅雷导入',
  guest_feature: '访客推荐', serverchan_test: 'Server酱测试', seed: '初始化数据',
  maintenance_hide_empty_book: '隐藏空书',
  // 推广邀请（本轮新增）
  promote_gen: '生成/更换推广码·邀请码', invite_register: '推广/邀请注册',
  promote_reward: '发放推广奖励', invite_reward: '发放邀请奖励',
  invite_blocked: '邀请码被拒',
};
async function loadAudit() {
  const wrap = document.getElementById('audit-list');
  try {
    const p = new URLSearchParams({ page: auditPage, size: AUDIT_PAGE_SIZE });
    if (auditQuery) p.set('q', auditQuery);
    const d = await api('/api/admin/audit?' + p.toString());
    const total = d.total || 0;
    const pages = Math.max(1, Math.ceil(total / AUDIT_PAGE_SIZE));
    if (auditPage > pages) auditPage = pages;
    if (!d.items || !d.items.length) { wrap.innerHTML = '<p class="muted">暂无审计记录</p>'; return; }
    wrap.innerHTML = `<div style="overflow-x:auto"><table class="user-table">
      <thead><tr><th>时间</th><th>用户</th><th>操作</th><th>对象</th><th>详情</th><th>IP</th></tr></thead>
      <tbody>${d.items.map(a => `<tr>
        <td class="muted">${esc((a.created_at||'').slice(0,16))}</td>
        <td>${esc(a.username || '匿名')}</td>
        <td><span class="tag" title="${esc(a.action)}">${esc(AUDIT_LABELS[a.action] || a.action)}</span></td>
        <td>${esc(a.target_type || '')}${a.target_id ? '#' + a.target_id : ''}</td>
        <td class="perm-cell">${esc(a.detail || '')}</td>
        <td class="muted">${esc(a.ip || '')}</td>
      </tr>`).join('')}</tbody></table></div>
      <div class="pagination" style="margin-top:12px;align-items:center">
        <span class="muted" style="font-size:13px">共 ${total} 条</span>
        ${pages > 1 ? `
        <button ${auditPage <= 1 ? 'disabled' : ''} onclick="goAuditPage(${auditPage - 1})">上一页</button>
        <span>${auditPage} / ${pages}</span>
        <button ${auditPage >= pages ? 'disabled' : ''} onclick="goAuditPage(${auditPage + 1})">下一页</button>` : ''}
      </div>`;
  } catch (e) { wrap.innerHTML = '<p class="muted">加载失败</p>'; }
}
// ---------- 上传下载日志 ----------
// ★ 用户要求「带文件扩展名」：表格里有独立的「类型」列，上方是按类型的汇总胶囊，
//   点胶囊就筛那一种格式。扩展名由后端单独存列（file_logs.ext），不是从文件名现抠。
const FILELOG_PAGE_SIZE = 50;
let filelogPage = 1, filelogQ = '', filelogDays = 30, filelogAction = '', filelogExt = '';

function setFlDays(d) {
  filelogDays = d; filelogPage = 1;
  document.querySelectorAll('#filelog-range button')
    .forEach(b => b.classList.toggle('on', +b.dataset.r === d));
  loadFileLogs();
}
function setFlAction(a) {
  filelogAction = a; filelogPage = 1;
  document.querySelectorAll('#filelog-action button')
    .forEach(b => b.classList.toggle('on', b.dataset.a === a));
  loadFileLogs();
}
function setFlExt(e) { filelogExt = (filelogExt === e ? '' : e); filelogPage = 1; loadFileLogs(); }
function clearFlExt() { filelogExt = ''; filelogPage = 1; loadFileLogs(); }
function searchFileLogs() {
  filelogQ = document.getElementById('filelog-q').value.trim();
  filelogPage = 1; loadFileLogs();
}
function goFileLogPage(n) { filelogPage = n; loadFileLogs(); }
function fmtBytes(n) {
  if (!n) return '';
  const u = ['B', 'KB', 'MB', 'GB']; let i = 0, v = Number(n);
  while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
  return (i ? v.toFixed(1) : v) + u[i];
}
async function loadFileLogs() {
  const wrap = document.getElementById('filelog-list');
  const sum = document.getElementById('filelog-sum');
  const extWrap = document.getElementById('filelog-exts');
  try {
    const p = new URLSearchParams({ page: filelogPage, size: FILELOG_PAGE_SIZE, days: filelogDays });
    if (filelogQ) p.set('q', filelogQ);
    if (filelogAction) p.set('action', filelogAction);
    if (filelogExt) p.set('ext', filelogExt);
    const d = await api('/api/admin/file-logs?' + p.toString());
    const total = d.total || 0;
    const pages = Math.max(1, Math.ceil(total / FILELOG_PAGE_SIZE));
    if (filelogPage > pages) filelogPage = pages;
    const up = (d.by_action || {}).upload || 0, down = (d.by_action || {}).download || 0;
    sum.textContent = `共 ${total} 条 · 上传 ${up} · 下载 ${down}` +
      (filelogQ ? ` · 搜索「${filelogQ}」` : '') + (filelogExt ? ` · 只要 .${filelogExt}` : '');
    extWrap.innerHTML = (d.exts || []).filter(x => x.ext).map(x =>
      `<button class="btn sm" style="padding:3px 9px;font-size:12px;${filelogExt === x.ext ? 'outline:2px solid var(--acc);' : ''}"
        onclick="setFlExt('${esc(x.ext)}')" title="共 ${fmtBytes(x.bytes)}">.${esc(x.ext)} <b>${x.n}</b></button>`
    ).join('') + (filelogExt ? '<button class="btn sm" style="padding:3px 9px;font-size:12px" onclick="clearFlExt()">清除类型</button>' : '');
    if (!d.items || !d.items.length) {
      wrap.innerHTML = '<p class="muted">该条件下没有上传/下载记录</p>';
      return;
    }
    wrap.innerHTML = `<div style="overflow-x:auto"><table class="user-table">
      <thead><tr><th>时间</th><th>用户</th><th>动作</th><th>类型</th><th>文件</th><th>大小</th><th>来源</th><th>书籍</th><th>IP</th></tr></thead>
      <tbody>${d.items.map(a => `<tr>
        <td class="muted">${esc((a.created_at || '').slice(0, 16))}</td>
        <td>${esc(a.username || '匿名')}</td>
        <td><span class="tag">${a.action === 'upload' ? '上传' : '下载'}</span></td>
        <td>${a.ext ? '<b>.' + esc(a.ext) + '</b>' : '<span class="muted">—</span>'}</td>
        <td class="perm-cell" title="${esc(a.filename || '')}">${esc(a.filename || '')}</td>
        <td class="muted">${fmtBytes(a.bytes)}</td>
        <td class="muted">${esc(a.source || '')}</td>
        <td class="perm-cell">${a.book_id ? esc(a.book_title || ('#' + a.book_id)) : ''}</td>
        <td class="muted">${esc(a.ip || '')}</td>
      </tr>`).join('')}</tbody></table></div>
      <div class="pagination" style="margin-top:12px;align-items:center">
        <span class="muted" style="font-size:13px">共 ${total} 条</span>
        ${pages > 1 ? `
        <button ${filelogPage <= 1 ? 'disabled' : ''} onclick="goFileLogPage(${filelogPage - 1})">上一页</button>
        <span>${filelogPage} / ${pages}</span>
        <button ${filelogPage >= pages ? 'disabled' : ''} onclick="goFileLogPage(${filelogPage + 1})">下一页</button>` : ''}
      </div>`;
  } catch (e) {
    wrap.innerHTML = '<p class="muted">加载失败</p>';
  }
}

function searchAudit() {
  auditQuery = document.getElementById('audit-q').value.trim();
  auditPage = 1;
  loadAudit();
}
function goAuditPage(p) { auditPage = p; loadAudit(); }

// ---------- 听书日志 / 阅读日志 ----------
// 数据不在库里，而是按天存在 WebDAV 的 activity/<年>/<日期>.json（保留三年），
// 后端读回来再过滤分页。所以这里的「范围」直接决定要读几个日文件。
let actRange = { all: 'today' };      // 合并页只有一份范围
let actQuery = { all: '' };
let actPage = { all: 1 };
let actSeq = { all: 0 };              // 请求序号：防止旧请求后返回覆盖新结果
let actKind = 'all';                  // 当前类型筛选：all / listen / audio / read
const ACT_LABEL = { listen: '听书', audio: '有声', read: '阅读' };
const ACT_COLOR = { listen: '#3b82f6', audio: '#8b5cf6', read: '#16a34a' };
const ACT_PAGE_SIZE = 50;

function _pad2(n) { return String(n).padStart(2, '0'); }

// 后端一律按北京时间（UTC+8）归档和筛选日文件，所以这里也必须用北京时间算
// 「今天」。不能用浏览器本地时区 —— 服务器是 UTC，跨时区访问会查到相邻一天。
function _bjDate(offsetDays) {
  const d = new Date(Date.now() + 8 * 3600000 - (offsetDays || 0) * 86400000);
  return d.getUTCFullYear() + '-' + _pad2(d.getUTCMonth() + 1) + '-' + _pad2(d.getUTCDate());
}

// 把档位换算成 {start, end}（北京时间日期，和后端一致）
function actDates(r) {
  const today = _bjDate(0);
  if (r === 'yesterday') {
    const y = _bjDate(1);
    return { start: y, end: y };
  }
  if (r === '7' || r === '30') {
    return { start: _bjDate(Number(r) - 1), end: today };
  }
  return { start: today, end: today };
}

function setActKind(k) {
  actKind = k || 'all';
  actPage['all'] = 1;
  const box = document.getElementById('actlog-kind');
  if (box) box.querySelectorAll('button').forEach(b => b.classList.toggle('on', b.dataset.k === actKind));
  loadActivity('all');
}

function setActRange(kind, r) {
  actRange[kind] = r;
  actPage[kind] = 1;
  const box = document.getElementById('actlog-range');
  if (box) box.querySelectorAll('button').forEach(b => b.classList.toggle('on', b.dataset.r === r));
  loadActivity(kind);
}

function searchAct(kind) {
  actQuery[kind] = (document.getElementById('actlog-q').value || '').trim();
  actPage[kind] = 1;
  loadActivity(kind);
}

function goActPage(kind, p) { actPage[kind] = p; loadActivity(kind); }

async function loadActivity(kind) {
  const wrap = document.getElementById('actlog-list');
  const sub = document.getElementById('actlog-sub');
  if (!wrap) return;
  const label = actKind === 'all' ? '' : (ACT_LABEL[actKind] || '');
  const d = actDates(actRange[kind]);
  // 切标签和切范围会连着发请求，慢的那个如果后返回就会把新结果盖掉，
  // 所以每次请求领一个号，回来时不是最新的就丢弃。
  const mySeq = ++actSeq[kind];
  try {
    // 合并页：类型筛选交给后端（kind=all 时返回三类合并结果）
    const p = new URLSearchParams({ kind: actKind, start: d.start, end: d.end,
                                   page: actPage[kind], size: ACT_PAGE_SIZE });
    if (actQuery[kind]) p.set('q', actQuery[kind]);
    const r = await api('/api/admin/activity?' + p.toString());
    if (mySeq !== actSeq[kind]) return;
    const total = r.total || 0;
    const pages = Math.max(1, Math.ceil(total / ACT_PAGE_SIZE));
    if (actPage[kind] > pages) actPage[kind] = pages;
    const rangeTxt = d.start === d.end ? d.start : (d.start + ' ~ ' + d.end);
    sub.textContent = rangeTxt + '：共 ' + total + ' 条' + label + '记录，'
      + (r.users || 0) + ' 位用户，' + (r.books || 0) + ' 本书'
      + ((r.days && r.days.length > 1) ? '（跨 ' + r.days.length + ' 天）' : '');
    if (!r.items || !r.items.length) {
      wrap.innerHTML = '<p class="muted">这段时间没有' + (label || '听书阅读') + '记录</p>';
      return;
    }
    // 合并页要能一眼看出每行是「听书 / 有声 / 阅读」，所以多一列「类型」。
    // 只筛某一类时这一列仍然显示，方便对照。
    const tag = e => {
      const k = e.kind || '';
      const c = ACT_COLOR[k] || '#888';
      return '<span style="display:inline-block;padding:1px 7px;border-radius:999px;font-size:11.5px;'
        + 'color:#fff;background:' + c + '">' + esc(ACT_LABEL[k] || k) + '</span>';
    };
    wrap.innerHTML = `<div style="overflow-x:auto"><table class="user-table">
      <thead><tr><th>时间</th><th>类型</th><th>用户</th><th>书籍</th><th>详情</th><th>IP</th></tr></thead>
      <tbody>${r.items.map(e => `<tr>
        <td class="muted" style="white-space:nowrap">${esc(e.t || '')}</td>
        <td>${tag(e)}</td>
        <td>${esc(e.u || '')}<span class="muted"> #${e.uid || 0}</span></td>
        <td class="perm-cell">${esc(e.book || '')}</td>
        <td class="muted">${esc(e.detail || '')}</td>
        <td class="muted">${esc(e.ip || '')}</td>
      </tr>`).join('')}</tbody></table></div>
      <div class="pagination" style="margin-top:12px;align-items:center">
        <span class="muted" style="font-size:13px">共 ${total} 条</span>
        ${pages > 1 ? `
        <button ${actPage[kind] <= 1 ? 'disabled' : ''} onclick="goActPage('${kind}',${actPage[kind] - 1})">上一页</button>
        <span>${actPage[kind]} / ${pages}</span>
        <button ${actPage[kind] >= pages ? 'disabled' : ''} onclick="goActPage('${kind}',${actPage[kind] + 1})">下一页</button>` : ''}
      </div>`;
  } catch (e) {
    sub.textContent = '';
    wrap.innerHTML = '<p class="muted">加载失败：' + esc(e.message || '') + '</p>';
  }
}

init();

/* ==================== 网站统计 ==================== */
// 设计取向：不用渐变、不用大圆角、不用 emoji。细网格线 + 克制的低饱和配色 +
// 等宽数字，接近印刷品的图表观感。
const SS = {
  ink: '#2b3445', sub: '#8a90a3', grid: '#eef0f5', axis: '#e2e6ee', tip: '#1f2330',
  c: {
    pv: '#3b5f8a',      // 深钢蓝
    ip: '#c08a4e',      // 赭石
    app: '#4e8a72',     // 松绿
    read: '#6b7fa8',    // 灰蓝
    user: '#7d9a6a',    // 橄榄绿
    upload: '#b0763f',  // 琥珀
    dl: '#3b5f8a',
    bl: '#8a6a8f',      // 灰紫
  }
};
let ssData = null;
let ssHasPrev = false;
let ssResizeTimer = null;
// 时间范围：图表/概览卡/每日明细共用同一个窗口，由后端的 ?days= 决定。
// 这两个变量在 loadSiteStats 里按接口返回的 d.days 同步，
// 这样下面所有渲染代码不用改就能跟着档位走。
let ssDays = 7;
let SS_CHART_DAYS = 7;
let SS_TABLE_DAYS = 7;

// 切换「网站统计」的时间范围（1/7/15/30/90 天）
function setSiteRange(days) {
  ssDays = parseInt(days, 10) || 7;
  const box = document.getElementById('ss-range');
  if (box) {
    box.querySelectorAll('button').forEach(b => {
      b.classList.toggle('on', parseInt(b.dataset.d, 10) === ssDays);
    });
  }
  loadSiteStats();
}

function ssFmtNum(v) {
  v = Number(v || 0);
  if (!v) return '0';
  if (v >= 1000000) return (v / 1000000).toFixed(v >= 10000000 ? 0 : 1) + 'M';
  if (v >= 10000) return (v / 1000).toFixed(v >= 100000 ? 0 : 1) + 'k';
  return v.toLocaleString('en-US');
}
function ssFmtDur(sec) {
  sec = Number(sec || 0);
  if (!sec) return '0';
  const h = sec / 3600;
  if (h >= 100) return Math.round(h) + 'h';
  if (h >= 10) return h.toFixed(0) + 'h';
  if (h >= 1) return h.toFixed(1) + 'h';
  const m = sec / 60;
  return (m >= 10 ? Math.round(m) : m.toFixed(1)) + 'm';
}
// 阅读时长按「分钟」画，纵轴单位由量级统一决定：
// 全轴要么都是 m、要么都是 h，不混用（混用会出现 25m → 1.3h 这种看着变小的刻度）
function ssMinAxis(top) {
  const useH = top >= 120;
  return v => {
    if (!v) return '0';
    if (useH) { const h = v / 60; return (h % 1 ? h.toFixed(1) : h.toFixed(0)) + 'h'; }
    return (v % 1 ? v.toFixed(1) : v.toFixed(0)) + 'm';
  };
}

// 轴上限取整：让刻度落在 1/2/2.5/5/10 这种整数上
function ssNiceMax(v, ticks) {
  if (!(v > 0)) return ticks;
  const raw = v / ticks;
  const mag = Math.pow(10, Math.floor(Math.log10(raw)));
  const n = raw / mag;
  const LADDER = [1, 1.5, 2, 2.5, 3, 4, 5, 6, 8, 10];
  const step = (LADDER.find(x => n <= x + 1e-9) || 10) * mag;
  return step * ticks;
}

/* ---------- SVG 图表：柱 + 线，可双轴 ---------- */
function ssChart(hostId, cfg) {
  const host = document.getElementById(hostId);
  if (!host) return;
  const labels = cfg.labels || [];
  const series = (cfg.series || []).filter(s => s && s.values && s.values.length);
  const H = cfg.height || 210;
  const W = Math.max(320, host.clientWidth || 640);
  const hasRight = series.some(s => s.axis === 'right');
  const pad = { t: 14, r: hasRight ? 48 : 14, b: 26, l: 48 };
  const plotW = W - pad.l - pad.r, plotH = H - pad.t - pad.b;

  host.innerHTML = '';
  host.style.position = 'relative';
  const svgNS = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(svgNS, 'svg');
  svg.setAttribute('viewBox', `0 0 ${W} ${H}`);
  svg.setAttribute('width', '100%');
  svg.setAttribute('height', H);
  svg.style.display = 'block';
  svg.style.overflow = 'visible';
  const add = (tag, attrs, text) => {
    const el = document.createElementNS(svgNS, tag);
    for (const k in attrs) el.setAttribute(k, attrs[k]);
    if (text != null) el.textContent = text;
    svg.appendChild(el);
    return el;
  };

  const isNil = v => v === null || v === undefined || v === '';
  const maxOf = ax => Math.max(0, ...series.filter(s => (s.axis || 'left') === ax)
    .flatMap(s => s.values.map(v => Number(v) || 0)));
  const topL = ssNiceMax(maxOf('left'), 4), topR = ssNiceMax(maxOf('right'), 4);
  const yOf = (v, ax) => pad.t + plotH - plotH * ((Number(v) || 0) / ((ax === 'right' ? topR : topL) || 1));
  const n = labels.length || 1, band = plotW / n;

  // 横向网格 + 左右轴刻度
  const yFmtRaw = cfg.yFmt || ssFmtNum, y2FmtRaw = cfg.y2Fmt || ssFmtNum;
  const yFmt = v => yFmtRaw(v, topL), y2Fmt = v => y2FmtRaw(v, topR);
  for (let t = 0; t <= 4; t++) {
    const y = pad.t + plotH - plotH * t / 4;
    add('line', { x1: pad.l, y1: y, x2: pad.l + plotW, y2: y,
      stroke: t === 0 ? SS.axis : SS.grid, 'stroke-width': 1, 'shape-rendering': 'crispEdges' });
    add('text', { x: pad.l - 8, y: y + 3.5, 'text-anchor': 'end', fill: SS.sub,
      'font-size': 10.5, 'font-variant-numeric': 'tabular-nums' }, yFmt(topL * t / 4));
    if (hasRight) {
      add('text', { x: pad.l + plotW + 8, y: y + 3.5, 'text-anchor': 'start', fill: SS.sub,
        'font-size': 10.5, 'font-variant-numeric': 'tabular-nums' }, y2Fmt(topR * t / 4));
    }
  }

  const empty = series.every(s => s.values.every(v => isNil(v) || !Number(v)));
  // 柱：同组并列
  const barSeries = series.filter(s => (s.type || 'bar') === 'bar');
  const gw = band * 0.62, bw = barSeries.length ? gw / barSeries.length : 0;
  barSeries.forEach((s, i) => {
    s.values.forEach((v, k) => {
      const val = Number(v) || 0;
      if (!val || isNil(v)) return;
      const h = plotH * (val / ((s.axis === 'right' ? topR : topL) || 1));
      const x = pad.l + band * k + (band - gw) / 2 + bw * i;
      add('rect', { x: x.toFixed(1), y: (pad.t + plotH - h).toFixed(1),
        width: Math.max(1, bw - 1.5).toFixed(1), height: Math.max(0.8, h).toFixed(1),
        rx: 1.5, fill: s.color || SS.c.pv, opacity: empty ? 0.25 : 1 });
    });
  });
  // 折线
  series.filter(s => s.type === 'line').forEach(s => {
    const ax = s.axis === 'right' ? 'right' : 'left';
    // 缺失值处把线断开，不要拿 0 顶替（那会读成「掉到 0」）
    let dseg = '', seg = [], dots = [];
    const flush = () => {
      if (seg.length) {
        dseg += (dseg ? ' ' : '') + seg.map((q, i) => (i ? 'L' : 'M') + q[0].toFixed(1) + ' ' + q[1].toFixed(1)).join(' ');
        dots = dots.concat(seg);
        seg = [];
      }
    };
    s.values.forEach((v, k) => {
      const x = pad.l + band * k + band / 2;
      if (isNil(v)) { flush(); return; }
      seg.push([x, yOf(v, ax)]);
    });
    flush();
    if (dseg) add('path', { d: dseg, fill: 'none', stroke: s.color || SS.c.ip,
      'stroke-width': s.width || 1.75, 'stroke-linejoin': 'round', 'stroke-linecap': 'round' });
    dots.forEach(p => {
      add('circle', { cx: p[0].toFixed(1), cy: p[1].toFixed(1), r: 2.6,
        fill: '#fff', stroke: s.color || SS.c.ip, 'stroke-width': 1.6 });
    });
  });

  // X 轴日期：太密时隔几个显示
  const every = n > 20 ? Math.ceil(n / 10) : (n > 12 ? 2 : 1);
  labels.forEach((L, k) => {
    if (k % every !== 0 && k !== n - 1) return;
    add('text', { x: (pad.l + band * k + band / 2).toFixed(1), y: H - 8,
      'text-anchor': 'middle', fill: SS.sub, 'font-size': 10.5,
      'font-variant-numeric': 'tabular-nums' }, L);
  });

  if (empty) {
    add('text', { x: pad.l + plotW / 2, y: pad.t + plotH / 2 + 4, 'text-anchor': 'middle',
      fill: '#b6bcc9', 'font-size': 12.5 }, '暂无数据');
  }

  // 悬停：一根透明的热区 + 浮层
  const tip = document.createElement('div');
  tip.className = 'ss-tip';
  tip.style.display = 'none';
  host.appendChild(tip);
  labels.forEach((L, k) => {
    const r = document.createElementNS(svgNS, 'rect');
    r.setAttribute('x', pad.l + band * k); r.setAttribute('y', pad.t);
    r.setAttribute('width', band); r.setAttribute('height', plotH);
    r.setAttribute('fill', 'transparent');
    r.style.cursor = 'crosshair';
    r.addEventListener('mouseenter', () => {
      const rows = series.map(s =>
        `<div class="ss-tip-r"><i style="background:${s.color || SS.c.pv}"></i>
          <span>${esc(s.name)}</span><b>${isNil(s.values[k]) ? '—' : esc((s.fmt || ssFmtNum)(s.values[k]))}</b></div>`).join('');
      tip.innerHTML = `<div class="ss-tip-d">${esc(cfg.labelsFull ? cfg.labelsFull[k] : L)}</div>${rows}`;
      tip.style.display = 'block';
      const x = pad.l + band * k + band / 2;
      tip.style.left = Math.min(Math.max(x, 60), W - 60) + 'px';
      tip.style.top = (pad.t + 6) + 'px';
    });
    r.addEventListener('mouseleave', () => { tip.style.display = 'none'; });
    svg.appendChild(r);
  });
  host.appendChild(svg);
}

/* ---------- 图例 ---------- */
function ssLegend(items) {
  return `<div class="ss-legend">${items.map(i =>
    `<span><i style="background:${i.c}"></i>${esc(i.n)}</span>`).join('')}</div>`;
}

/* ---------- 数据加载 ---------- */
let ssLoading = false;
async function loadSiteStats() {
  const cards = document.getElementById('ss-cards');
  ssLoading = true;
  const host = document.getElementById('sec-sitestats');
  if (host) host.classList.add('ss-loading');
  if (cards) cards.innerHTML = '<p class="muted" style="margin:0;font-size:13px">正在读取统计…</p>';
  try {
    const d = await api('/api/admin/site-stats?days=' + encodeURIComponent(ssDays));
    ssData = d;
    // 以后端为准回填窗口天数（非法值后端会收敛回 7 天，前端跟着对齐）
    SS_CHART_DAYS = SS_TABLE_DAYS = parseInt(d.days, 10) || ssDays;
    ssDays = SS_CHART_DAYS;
    const sub = document.getElementById('ss-range-sub');
    if (sub) sub.textContent = `图表、概览卡、每日明细均为近 ${ssDays} 天，均按天统计`;
    ssHasPrev = Object.values(d.prev_totals || {}).some(v => Number(v) > 0);
    renderSiteStats();
  } catch (e) {
    if (cards) cards.innerHTML = '<p class="muted" style="margin:0;font-size:13px">统计读取失败：' + esc(e.message) + '</p>';
  } finally {
    ssLoading = false;
    if (host) host.classList.remove('ss-loading');
  }
}

function ssDelta(cur, prev) {
  cur = Number(cur || 0); prev = Number(prev || 0);
  if (!prev) return cur ? { t: '新增', k: 'up' } : { t: '—', k: 'flat' };
  const pct = (cur - prev) / prev * 100;
  if (Math.abs(pct) < 0.5) return { t: '持平', k: 'flat' };
  return { t: (pct > 0 ? '▲ ' : '▼ ') + Math.abs(pct).toFixed(pct >= 10 || pct <= -10 ? 0 : 1) + '%', k: pct > 0 ? 'up' : 'down' };
}
function ssCard(label, cur, prev, fmt) {
  const d = ssDelta(cur, prev);
  const cmp = ssHasPrev ? `较前 ${SS_CHART_DAYS} 天` : (d.k === 'flat' ? '' : '');
  return `<div class="ss-card">
    <div class="ss-card-l">${esc(label)}</div>
    <div class="ss-card-v">${esc((fmt || ssFmtNum)(cur))}</div>
    <div class="ss-card-d ${d.k}">${esc(d.t)}<span>${esc(cmp)}</span></div>
  </div>`;
}

// 环比小标（明细表里挂在数值下面）
function ssTrend(t, fmt) {
  if (!t || t.pct === null || t.pct === undefined) {
    return t && t.dir === 'up' ? '<span class="ss-tr up">新增</span>' : '';
  }
  if (t.dir === 'flat') return '<span class="ss-tr flat">持平</span>';
  const arrow = t.dir === 'up' ? '▲' : '▼';
  return `<span class="ss-tr ${t.dir}">${arrow}${Math.abs(t.pct).toFixed(Math.abs(t.pct) >= 10 ? 0 : 1)}%</span>`;
}

function renderSiteStats() {
  const d = ssData; if (!d) return;
  // 图表/概览卡/明细表共用同一个时间窗口（ssDays），由 ?days= 决定
  const chart = d.chart || [];
  const T = d.totals || {}, P = d.prev_totals || {};
  const labels = chart.map(x => x.date.slice(5));
  const labelsFull = chart.map(x => {
    const w = '日一二三四五六'[new Date(x.date + 'T00:00:00').getDay()];
    return `${x.date} 周${w}`;
  });
  const V = k => chart.map(x => (x[k] === null || x[k] === undefined) ? null : Number(x[k]));

  const subs = {
    traffic: `每日访问量（柱）与独立 IP（线）· 近 ${SS_CHART_DAYS} 天`,
    app: '安卓安装包下载次数（按天）',
    reading: '全站每日累计阅读小时数（按天）',
    member: '新增会员 / 会员上传电子书（按天）',
    bookdl: '电子书下载次数 / 书单投稿（按天）',
  };
  for (const k in subs) {
    const el = document.getElementById('ss-sub-' + k);
    if (el) el.textContent = subs[k];
  }

  // 概览卡（近 7 天合计，同比对前 7 天）
  document.getElementById('ss-cards').innerHTML =
    ssCard('访问量', T.pv, P.pv) +
    ssCard('独立 IP', T.ip_count, P.ip_count) +
    ssCard('App 下载', T.app_downloads, P.app_downloads) +
    ssCard('阅读时长', T.reading_seconds, P.reading_seconds, ssFmtDur) +
    ssCard('会员上传', T.uploads, P.uploads) +
    ssCard('新增会员', T.new_users, P.new_users) +
    ssCard('书籍下载', T.book_downloads, P.book_downloads) +
    ssCard('阅读人数', T.reader_count, P.reader_count);

  // 主图：访问量 + 独立IP（双轴）
  ssChart('ss-chart-traffic', {
    labels, labelsFull, height: 250,
    yFmt: ssFmtNum, y2Fmt: ssFmtNum,
    series: [
      { name: '访问量', values: V('pv'), type: 'bar', color: SS.c.pv, fmt: ssFmtNum },
      { name: '独立 IP', values: V('ip_count'), type: 'line', color: SS.c.ip, axis: 'right', fmt: ssFmtNum },
    ]
  });
  document.getElementById('ss-chart-traffic').insertAdjacentHTML('afterbegin',
    ssLegend([{ c: SS.c.pv, n: '访问量' }, { c: SS.c.ip, n: '独立 IP' }]));

  ssChart('ss-chart-app', {
    labels, labelsFull, height: 190,
    series: [{ name: 'App 下载', values: V('app_downloads'), type: 'bar', color: SS.c.app, fmt: v => ssFmtNum(v) + ' 次' }]
  });
  ssChart('ss-chart-reading', {
    labels, labelsFull, height: 190, yFmt: (v, top) => ssMinAxis(top)(v),
    series: [{ name: '阅读时长',
               values: V('reading_seconds').map(v => v === null ? null : v / 60),
               type: 'bar', color: SS.c.read,
               fmt: m => ssFmtDur(m * 60) }]
  });
  ssChart('ss-chart-member', {
    labels, labelsFull, height: 190,
    series: [
      { name: '新增会员', values: V('new_users'), type: 'bar', color: SS.c.user, fmt: v => ssFmtNum(v) + ' 人' },
      { name: '会员上传', values: V('uploads'), type: 'bar', color: SS.c.upload, fmt: v => ssFmtNum(v) + ' 本' },
    ]
  });
  document.getElementById('ss-chart-member').insertAdjacentHTML('afterbegin',
    ssLegend([{ c: SS.c.user, n: '新增会员' }, { c: SS.c.upload, n: '会员上传' }]));

  ssChart('ss-chart-bookdl', {
    labels, labelsFull, height: 190,
    series: [
      { name: '书籍下载', values: V('book_downloads'), type: 'bar', color: SS.c.dl, fmt: v => ssFmtNum(v) + ' 次' },
      { name: '书单投稿', values: V('booklists'), type: 'line', color: SS.c.bl, axis: 'right', fmt: v => ssFmtNum(v) + ' 篇' },
    ]
  });
  document.getElementById('ss-chart-bookdl').insertAdjacentHTML('afterbegin',
    ssLegend([{ c: SS.c.dl, n: '书籍下载' }, { c: SS.c.bl, n: '书单投稿' }]));

  // ---------------- 每日明细（当前窗口 + 环比） ----------------
  const rows = d.table || [];
  const trendKeys = d.trend_keys || [];
  const cols = [['date', '日期'], ['pv', '访问量'], ['ip_count', '独立 IP'], ['app_downloads', 'App 下载'],
                ['reading_seconds', '阅读时长'], ['reader_count', '阅读人数'], ['active_users', '活跃会员'],
                ['new_users', '新增会员'], ['uploads', '会员上传'], ['book_downloads', '书籍下载'],
                ['booklists', '书单投稿'], ['share_requests', '共享申请'], ['errors', '错误']];
  const cell = (k, v, t) => {
    // t 是整行的 trend 映射，要取出该列对应的那个环比再渲染
    const tr = (t && trendKeys.includes(k)) ? ssTrend(t[k]) : '';
    if (k === 'date') return `<td class="ss-d">${esc(v)}</td>`;
    if (v === null || v === undefined) return `<td class="n"><span class="ss-zero">—</span></td>`;
    const txt = k === 'reading_seconds'
      ? (Number(v) ? esc(ssFmtDur(v)) : '<span class="ss-zero">·</span>')
      : (Number(v || 0) ? esc(ssFmtNum(v)) : '<span class="ss-zero">·</span>');
    return `<td class="n">${txt}${tr}</td>`;
  };
  const list = rows.slice().reverse();          // 最新在上
  const today = (d.overview || {}).today;
  const first = rows[0], last = rows[rows.length - 1];
  document.getElementById('ss-table-sub').textContent = rows.length
    ? `近 ${SS_TABLE_DAYS} 天：${first.date} 至 ${last.date}（最新在上，数值下方为较前一日环比；今天为当日累计，环比仅供参考）`
    : '暂无数据';

  // 合计 + 「近 N 天 / 前 N 天」对比行
  const TP = d.table_prev_totals || {};
  const t10 = {};
  cols.slice(1).forEach(c => { t10[c[0]] = rows.reduce((a, r) => a + Number(r[c[0]] || 0), 0); });
  const sumCell = (k, v) => {
    if (v === null || v === undefined) return `<td class="n"><span class="ss-zero">—</span></td>`;
    const txt = k === 'reading_seconds' ? esc(ssFmtDur(v || 0))
      : (Number(v || 0) ? esc(ssFmtNum(v)) : '<span class="ss-zero">·</span>');
    return `<td class="n">${txt}</td>`;
  };
  const footRows = `<tr class="ss-sum">
      <td class="ss-d">近 ${SS_TABLE_DAYS} 天合计</td>
      ${cols.slice(1).map(c => sumCell(c[0], t10[c[0]])).join('')}
    </tr>
    <tr class="ss-sum">
      <td class="ss-d">前 ${SS_TABLE_DAYS} 天合计</td>
      ${cols.slice(1).map(c => sumCell(c[0], TP[c[0]])).join('')}
    </tr>`;

  document.getElementById('ss-table').innerHTML = `<div style="overflow-x:auto">
    <table class="ss-table">
      <thead><tr>${cols.map(c => `<th${c[0] === 'date' ? '' : ' class="n"'}>${c[1]}</th>`).join('')}</tr></thead>
      <tbody>
        ${list.map(r => `<tr${r.date === today ? ' class="today"' : ''}>${cols.map(c => cell(c[0], r[c[0]], r.trend)).join('')}</tr>`).join('')}
      </tbody>
      <tfoot>${footRows}</tfoot>
    </table></div>`;
}

function ssExportCsv() {
  if (!ssData || !(ssData.table || []).length) return;
  // 导出当前窗口的明细（含环比），和页面上看到的表一致
  const cols = [['date', '日期'], ['pv', '访问量'], ['pv_trend', '访问量环比'],
                ['ip_count', '独立IP'], ['app_downloads', 'App下载'],
                ['reading_seconds', '阅读秒数'], ['reading_trend', '阅读时长环比'],
                ['reader_count', '阅读人数'], ['active_users', '活跃会员'],
                ['new_users', '新增会员'], ['uploads', '会员上传'],
                ['book_downloads', '书籍下载'], ['book_downloads_trend', '书籍下载环比'],
                ['booklists', '书单投稿'], ['share_requests', '共享申请'], ['errors', '错误']];
  const tfmt = t => {
    if (!t || t.pct === null || t.pct === undefined) return t && t.dir === 'up' ? '新增' : '';
    if (t.dir === 'flat') return '持平';
    return (t.dir === 'up' ? '+' : '-') + Math.abs(t.pct).toFixed(1) + '%';
  };
  const rows = ssData.table.slice().reverse();   // 最新在上
  const val = (r, k) => {
    if (k.endsWith('_trend')) return JSON.stringify(tfmt((r.trend || {})[k.slice(0, -6)]));
    const v = r[k];
    return JSON.stringify(v === null || v === undefined ? '' : String(v));
  };
  const head = cols.map(c => c[1]).join(',');
  const body = rows.map(r => cols.map(c => val(r, c[0])).join(','));
  // 末两行：近 N 天合计 / 前 N 天合计
  const TP = ssData.table_prev_totals || {};
  const t10 = {};
  cols.forEach(c => {
    if (c[0].endsWith('_trend') || c[0] === 'date') return;
    t10[c[0]] = rows.reduce((a, r) => a + Number(r[c[0]] || 0), 0);
  });
  const sumRow = (label, src) => [JSON.stringify(label)].concat(
    cols.slice(1).map(c => {
      if (c[0].endsWith('_trend')) return JSON.stringify('');
      const v = src[c[0]];
      return JSON.stringify(v === null || v === undefined ? '' : String(v));
    })).join(',');
  body.push(sumRow(`近 ${SS_TABLE_DAYS} 天合计`, t10));
  body.push(sumRow(`前 ${SS_TABLE_DAYS} 天合计`, TP));
  const csv = '\ufeff' + [head].concat(body).join('\r\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
  const t = ssData.table;
  a.download = `网站统计_近${SS_TABLE_DAYS}天_${t[0].date}_${t[t.length - 1].date}.csv`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 3000);
}

window.addEventListener('resize', () => {
  if (!ssData) return;
  clearTimeout(ssResizeTimer);
  ssResizeTimer = setTimeout(() => {
    const sec = document.getElementById('sec-sitestats');
    if (sec && !sec.classList.contains('hidden')) renderSiteStats();
  }, 220);
});


// ================================================================ 听书管理
// 「听书管理」标签页：听书设置（从概览搬来）+ 线路分组权限 + 音色管理。
// 音色数据来自 GET /api/admin/listen/lines，它把各台服务器 /voices（事实）
// 和站点侧的覆盖（重命名/启停/删除/排序）合在一起返回。
let LA = { lines: [], groups: [] };
let LA_PICK = '';

async function loadListenAdmin() {
  const box = document.getElementById('la-lines');
  if (box) box.innerHTML = '<p class="muted" style="font-size:13px">加载中…</p>';
  try {
    LA = await api('/api/admin/listen/lines');
  } catch (e) {
    if (box) box.innerHTML = '<p class="muted" style="font-size:13px">加载失败：' + esc(e.message) + '</p>';
    return;
  }
  if (box) box.querySelectorAll('p').forEach(p => p.remove());
  renderListenGroups();
  fillLinePick();
  renderListenVoices();
}

function laLine() { return (LA.lines || []).find(x => x.url === LA_PICK) || null; }

// ---------- 线路与分组权限 ----------
function renderListenGroups() {
  const box = document.getElementById('la-lines');
  if (!box) return;
  const lines = LA.lines || [];
  if (!lines.length) {
    box.innerHTML = '<p class="muted" style="font-size:13px">还没有启用的 TTS 线路。先在上方「TTS 服务器」里添加并启用一台。</p>';
    return;
  }
  box.innerHTML = lines.map((ln, i) => `
    <div class="card" style="box-shadow:none;border:1px solid var(--line);margin:0 0 10px;padding:12px 14px">
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
        <div>
          <b>${esc(ln.name)}</b>
          <span class="muted" style="font-size:12px"> · ${esc(ln.model || '—')} · ${ln.on_count}/${ln.count} 个音色启用</span>
          <div class="muted" style="font-size:11.5px;word-break:break-all">${esc(ln.url)}</div>
        </div>
        <span class="muted" style="font-size:12px">${ln.custom_ok ? '支持样板定制' : '固定音色（不支持定制）'}</span>
      </div>
      <div style="margin-top:9px" data-line="${esc(ln.url)}">
        <span class="muted" style="font-size:12.5px">可用分组：</span>
        ${(LA.groups || []).map(g => `
          <label style="display:inline-flex;align-items:center;gap:5px;margin:4px 12px 0 0;font-size:13px">
            <input type="checkbox" class="la-g" value="${g.id}" ${(ln.groups || []).includes(g.id) ? 'checked' : ''}>
            ${esc(g.name)}
          </label>`).join('')}
      </div>
    </div>`).join('');
}

async function saveListenGroups() {
  const lines = LA.lines || [];
  let n = 0;
  try {
    for (const ln of lines) {
      const el = document.querySelector(`[data-line="${CSS.escape(ln.url)}"]`);
      if (!el) continue;
      const ids = [...el.querySelectorAll('input.la-g:checked')].map(x => parseInt(x.value, 10));
      const before = (ln.groups || []).slice().sort().join(',');
      if (ids.slice().sort().join(',') === before) continue;   // 没变就不发请求
      await api('/api/admin/listen/groups', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: ln.url, groups: ids }) });
      n++;
    }
  } catch (e) { toast('保存失败：' + e.message); return; }
  toast(n ? `已保存 ${n} 条线路的分组权限` : '没有改动');
  loadListenAdmin();
}

// ---------- 音色列表 ----------
function fillLinePick() {
  const sel = document.getElementById('la-line-pick');
  if (!sel) return;
  const lines = LA.lines || [];
  if (!lines.some(x => x.url === LA_PICK)) LA_PICK = lines.length ? lines[0].url : '';
  sel.innerHTML = lines.map(x => `<option value="${esc(x.url)}"${x.url === LA_PICK ? ' selected' : ''}>${esc(x.name)}（${x.on_count}/${x.count}）</option>`).join('');
}

// 音色管理折叠开关：默认收起，和「制作有声书籍」一致。
// 展开时刷一次列表 —— 收起状态下渲染的内容不保证是最新的。
function lvToggle() {
  var b = document.getElementById('lv-body'), t = document.getElementById('lv-toggle');
  if (!b) return;
  var folded = b.classList.toggle('hidden');
  if (t) t.textContent = folded ? '展开' : '收起';
  if (!folded) { try { renderListenVoices(); } catch (e) {} }
}

function renderListenVoices() {
  const sel = document.getElementById('la-line-pick');
  if (sel) LA_PICK = sel.value || LA_PICK;
  const box = document.getElementById('la-voices');
  const ln = laLine();
  if (!box) return;
  if (!ln) { box.innerHTML = '<p class="muted" style="font-size:13px">没有可管理的线路。</p>'; return; }
  if (!ln.voices.length) {
    box.innerHTML = '<p class="muted" style="font-size:13px">这条线路还没有音色（服务器 /voices 返回空，或都被白名单挡住了）。</p>';
  } else {
    box.innerHTML = `
      <div style="overflow-x:auto"><table class="tbl" style="width:100%;font-size:13px">
        <thead><tr><th style="text-align:left">名称</th><th style="text-align:left">音色 ID</th>
          <th>性别</th><th>启用</th><th>试听</th><th>操作</th></tr></thead>
        <tbody>${ln.voices.map(v => `
          <tr data-vid="${esc(v.id)}">
            <td><input class="la-name" value="${esc(v.name)}" maxlength="24"
                  style="width:130px"><button class="btn ghost" style="padding:2px 8px;margin-left:4px"
                  onclick="laRename('${esc(v.id)}')">改名</button>${v.custom ? ' <span class="muted" style="font-size:11px">定制</span>' : ''}</td>
            <td><code style="font-size:11.5px">${esc(v.id)}</code></td>
            <td style="text-align:center">${esc(v.gender || '—')}</td>
            <td style="text-align:center">
              <label class="switch"><input type="checkbox" ${v.on ? 'checked' : ''}
                onchange="laToggle('${esc(v.id)}', this.checked)"><span class="slider"></span></label>
            </td>
            <td style="text-align:center"><button class="btn ghost" style="padding:2px 9px"
                onclick="laPreview('${esc(v.id)}', this)">试听</button></td>
            <td style="text-align:center"><button class="btn ghost" style="padding:2px 9px;color:#c0392b"
                onclick="laDelete('${esc(v.id)}', ${v.custom ? 1 : 0})">删除</button></td>
          </tr>`).join('')}</tbody>
      </table></div>`;
  }
  // 定制区：只有零样本克隆的线路才谈得上「上传样板」
  const hint = document.getElementById('la-upload-hint');
  const upBox = document.getElementById('la-upload-box');
  const tw = document.getElementById('la-up-text-wrap');
  if (upBox) upBox.style.display = ln.custom_ok ? '' : 'none';
  if (hint && ln.custom_ok) {
    hint.textContent = `当前线路「${ln.name}」是 ${ln.model}，属于零样本克隆：`
      + '上传一段干净的朗读音频（建议 5~15 秒、单人、无背景音），它就会成为一个新音色。'
      + (needsTranscript(ln.model) ? ' 这条线路还需要填「样板里念的那句话」。' : '');
  }
  if (tw && ln.custom_ok) tw.style.display = needsTranscript(ln.model) ? '' : 'none';
}

function needsTranscript(model) { return String(model || '').toLowerCase().indexOf('gpt-sovits') === 0; }

function laVid(el) { const tr = el.closest('tr'); return tr ? tr.dataset.vid : ''; }

async function laRename(vid) {
  const tr = document.querySelector(`#la-voices tr[data-vid="${CSS.escape(vid)}"]`);
  const name = tr ? tr.querySelector('.la-name').value.trim() : '';
  try {
    await api('/api/admin/listen/voice/rename', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url: LA_PICK, id: vid, name }) });
    toast(name ? `已改名为「${name}」` : '已恢复原名');
    loadListenAdmin();
  } catch (e) { toast('改名失败：' + e.message); }
}

async function laToggle(vid, on) {
  try {
    await api('/api/admin/listen/voice/toggle', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url: LA_PICK, id: vid, on: on ? 1 : 0 }) });
    toast(on ? '已启用' : '已停用');
    loadListenAdmin();
  } catch (e) { toast('操作失败：' + e.message); loadListenAdmin(); }
}

async function laDelete(vid, custom) {
  const msg = custom
    ? `确定删除定制音色「${vid}」吗？\n\n它会被从 TTS 主机上真正删除，样板文件也一并移除，无法恢复。`
    : `确定删除内置音色「${vid}」吗？\n\n只是在本站隐藏（机器上的文件保留），以后可以恢复。`;
  if (!confirm(msg)) return;
  try {
    const r = await api('/api/admin/listen/voice/delete', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url: LA_PICK, id: vid }) });
    toast(r.how || '已删除');
    loadListenAdmin();
  } catch (e) { toast('删除失败：' + e.message); }
}

// 试听：拿回 Opus 直接播。同一时刻只留一个，避免叠着响。
let laAudio = null;
async function laPreview(vid, btn) {
  const old = btn ? btn.textContent : '';
  if (btn) { btn.disabled = true; btn.textContent = '合成中'; }
  try {
    const r = await fetch('/api/admin/listen/voice/preview', {
      method: 'POST',
      headers: { 'Authorization': 'Bearer ' + TOKEN, 'Content-Type': 'application/json' },
      body: JSON.stringify({ url: LA_PICK, id: vid }) });
    if (!r.ok) {
      const d = await r.json().catch(() => ({}));
      throw new Error(d.detail || ('HTTP ' + r.status));
    }
    const blob = await r.blob();
    if (laAudio) { try { laAudio.pause(); } catch (e) {} }
    laAudio = new Audio(URL.createObjectURL(blob));
    laAudio.play();
  } catch (e) {
    toast('试听失败：' + e.message);
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = old || '试听'; }
  }
}

async function uploadListenVoice() {
  const box = document.getElementById('la-up-result');
  const f = document.getElementById('la-up-file');
  const name = (document.getElementById('la-up-name') || {}).value || '';
  const text = (document.getElementById('la-up-text') || {}).value || '';
  if (!f || !f.files || !f.files.length) { toast('请先选择样板音频'); return; }
  const fd = new FormData();
  fd.append('url', LA_PICK);
  fd.append('name', name.trim());
  fd.append('text', text.trim());
  fd.append('file', f.files[0]);
  if (box) box.innerHTML = '<p class="muted" style="font-size:13px">上传并定制中，GPT-SoVITS 要转写样板文本，可能需要一会儿…</p>';
  try {
    const r = await fetch('/api/admin/listen/voice/upload', {
      method: 'POST', headers: { 'Authorization': 'Bearer ' + TOKEN }, body: fd });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.detail || ('HTTP ' + r.status));
    if (box) box.innerHTML = `<p style="font-size:13px;color:#137333">✓ 定制成功：<b>${esc(d.name)}</b>（${esc(d.id)}）</p>`;
    f.value = '';
    const n2 = document.getElementById('la-up-name'); if (n2) n2.value = '';
    const t2 = document.getElementById('la-up-text'); if (t2) t2.value = '';
    loadListenAdmin();
  } catch (e) {
    if (box) box.innerHTML = `<p style="font-size:13px;color:#c0392b">✗ 定制失败：${esc(e.message)}</p>`;
  }
}

/* ==========================================================================
   有声听书（「有声」页面的后台设置：分组权限 / 免费章节 / 树叶价格 / 分类 / 书目）
   ========================================================================== */
let AL_CFG = null, AL_GROUPS = [], AL_CATS = [], AL_BOOKS = [];

function alPost(path, obj) {
  return api(path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(obj || {})
  });
}

function alLoad() {
  alLoadCfg();
  alLoadCats();
  alLoadBooks();
}

function alLoadCfg() {
  api('/api/admin/audiobooks/cfg').then(function (d) {
    AL_CFG = d.cfg || {}; AL_GROUPS = d.groups || [];
    alEl('al-free').value = AL_CFG.lib_free_chapters || '0';
    alEl('al-perchap').value = AL_CFG.lib_leaf_per_chapter || '0';
    alEl('al-perbook').value = AL_CFG.lib_leaf_per_book || '0';
    alEl('al-needlogin').checked = String(AL_CFG.lib_need_login || '0') === '1';
    let sel = [];
    try { sel = JSON.parse(AL_CFG.lib_groups || '[]') || []; } catch (e) { sel = []; }
    sel = sel.map(Number);
    if (!AL_GROUPS.length) {
      alEl('al-groups').innerHTML = '<span class="muted">（还没有分组，未设置分组时所有登录用户都能听）</span>';
      return;
    }
    alEl('al-groups').innerHTML = AL_GROUPS.map(function (g) {
      return '<label style="display:inline-flex;align-items:center;gap:6px;margin:0 16px 8px 0;font-weight:normal;cursor:pointer">' +
        '<input type="checkbox" class="al-g" value="' + g.id + '"' +
        (sel.indexOf(Number(g.id)) >= 0 ? ' checked' : '') + ' style="width:auto;margin:0"> ' +
        esc(g.name || ('分组 ' + g.id)) + '</label>';
    }).join('');
  }).catch(function (e) { toast(e.message); });
}
function alEl(id) { return document.getElementById(id); }

function alSaveCfg() {
  const gs = Array.from(document.querySelectorAll('.al-g'))
    .filter(function (x) { return x.checked; }).map(function (x) { return parseInt(x.value, 10); });
  const body = {
    lib_groups: JSON.stringify(gs),
    lib_free_chapters: parseInt(alEl('al-free').value || '0', 10) || 0,
    lib_leaf_per_chapter: parseInt(alEl('al-perchap').value || '0', 10) || 0,
    lib_leaf_per_book: parseInt(alEl('al-perbook').value || '0', 10) || 0,
    lib_need_login: alEl('al-needlogin').checked ? '1' : '0'
  };
  alPost('/api/admin/audiobooks/cfg', body).then(function () {
    alEl('al-cfg-msg').textContent = '已保存';
    toast('有声听书设置已保存');
    setTimeout(function () { alEl('al-cfg-msg').textContent = ''; }, 2500);
  }).catch(function (e) { toast(e.message); });
}

function alLoadCats() {
  api('/api/admin/audiobooks/cats').then(function (d) {
    AL_CATS = d.cats || [];
    let h = '';
    if (!AL_CATS.length) h = '<div class="muted" style="font-size:13px">还没有分类（书籍默认归在「未分类」）</div>';
    h += AL_CATS.map(function (c) {
      return '<div style="display:flex;align-items:center;gap:8px;padding:7px 0;border-bottom:1px solid #eceef4">' +
        '<input value="' + esc(c.name) + '" data-cid="' + c.id + '" style="max-width:240px">' +
        '<span class="muted" style="font-size:12.5px">' + (c.count || 0) + ' 本</span>' +
        '<span style="flex:1"></span>' +
        '<button class="btn ghost sm" onclick="alRenameCat(' + c.id + ')">重命名</button>' +
        '<button class="btn danger sm" onclick="alDelCat(' + c.id + ',' + JSON.stringify(c.name).replace(/"/g, '&quot;') + ')">删除</button>' +
        '</div>';
    }).join('');
    alEl('al-cats').innerHTML = h;
  }).catch(function (e) { toast(e.message); });
}
function alAddCat() {
  const n = (alEl('al-newcat').value || '').trim();
  if (!n) { toast('请填写分类名称'); return; }
  alPost('/api/admin/audiobooks/cats', { name: n }).then(function () {
    alEl('al-newcat').value = ''; toast('已添加分类'); alLoadCats(); alLoadBooks();
  }).catch(function (e) { toast(e.message); });
}
function alRenameCat(cid) {
  const el = document.querySelector('#al-cats input[data-cid="' + cid + '"]');
  if (!el) return;
  alPost('/api/admin/audiobooks/cats/' + cid, { name: el.value }).then(function () {
    toast('已重命名'); alLoadCats(); alLoadBooks();
  }).catch(function (e) { toast(e.message); });
}
function alDelCat(cid, name) {
  if (!confirm('删除分类「' + name + '」？里面的书会变成「未分类」，书本身不会被删除。')) return;
  api('/api/admin/audiobooks/cats/' + cid, { method: 'DELETE' }).then(function () {
    toast('已删除分类'); alLoadCats(); alLoadBooks();
  }).catch(function (e) { toast(e.message); });
}

// 每本书单独的定价设置。留空 / 点「跟随全局」= -1，表示用后台「有声听书」里的集中设置。
let AL_GLOBAL = { free: 0, per_chapter: 0, per_book: 0 };
function alPricingRow(b) {
  const g = AL_GLOBAL || { free: 0, per_chapter: 0, per_book: 0 };
  const raw = {
    free_chapters: b.free_chapters, leaf_per_chapter: b.leaf_per_chapter, leaf_per_book: b.leaf_per_book
  };
  const val = function (k, def) {
    const v = raw[k];
    return (v === null || v === undefined || Number(v) < 0) ? '' : Number(v);
  };
  const inp = function (id, k, ph) {
    return '<input id="' + id + '" type="number" min="-1" placeholder="' + ph + '" value="' +
      val(k) + '" style="width:76px;padding:4px 6px;border:1.5px solid var(--line);border-radius:8px;font-size:12.5px">';
  };
  const follow = '<span class="muted" style="font-size:12px">跟随全局（' +
    g.free + ' 章免费 / ' + g.per_chapter + '🌿每章 / ' + g.per_book + '🌿整本）</span>';
  return '<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-top:8px;' +
      'background:#f7f8fc;border-radius:10px;padding:8px 10px">' +
    '<span class="muted" style="font-size:12.5px">单独设置</span>' +
    '<label style="font-size:12.5px">免费章节 ' + inp('alp-free-' + b.id, 'free_chapters', '全局') + '</label>' +
    '<label style="font-size:12.5px">每章 🌿 ' + inp('alp-ch-' + b.id, 'leaf_per_chapter', '全局') + '</label>' +
    '<label style="font-size:12.5px">整本 🌿 ' + inp('alp-bk-' + b.id, 'leaf_per_book', '全局') + '</label>' +
    '<button class="btn sm" onclick="alSavePricing(' + b.id + ')">保存</button>' +
    '<button class="btn ghost sm" onclick="alResetPricing(' + b.id + ')">跟随全局</button>' +
    follow +
  '</div>';
}
function alPricingVal(id) {
  const el = document.getElementById(id);
  if (!el) return null;
  const v = String(el.value == null ? '' : el.value).trim();
  if (v === '') return -1;                 // 留空 = 跟随全局
  const n = parseInt(v, 10);
  return isNaN(n) ? -1 : Math.max(-1, n);
}
async function alSavePricing(libId) {
  try {
    await alPost('/api/admin/audiobooks/' + libId + '/pricing', {
      free_chapters: alPricingVal('alp-free-' + libId),
      leaf_per_chapter: alPricingVal('alp-ch-' + libId),
      leaf_per_book: alPricingVal('alp-bk-' + libId)
    });
    toast('已保存这本书的定价');
    alLoadBooks();
  } catch (e) { toast(e.message); }
}
async function alResetPricing(libId) {
  try {
    await alPost('/api/admin/audiobooks/' + libId + '/pricing', {
      free_chapters: -1, leaf_per_chapter: -1, leaf_per_book: -1
    });
    toast('已恢复为跟随全局设置');
    alLoadBooks();
  } catch (e) { toast(e.message); }
}

function alLoadBooks() {
  api('/api/admin/audiobooks').then(function (d) {
    AL_BOOKS = d.items || []; AL_CATS = d.cats || [];
    AL_GLOBAL = d.global || { free: 0, per_chapter: 0, per_book: 0 };
    if (!AL_BOOKS.length) {
      alEl('al-books').innerHTML = '<div class="muted" style="font-size:13px">' +
        '还没有有声电子书。在「制作有声书籍」里做完并勾选「加入有声电子书页面」即可加入。</div>';
      return;
    }
    alEl('al-books').innerHTML = AL_BOOKS.map(function (b) {
      let opt = '<option value="0">未分类</option>' + AL_CATS.map(function (c) {
        return '<option value="' + c.id + '"' + (Number(b.cat_id) === Number(c.id) ? ' selected' : '') + '>' +
          esc(c.name) + '</option>';
      }).join('');
      return '<div style="padding:10px 0;border-bottom:1px solid #eceef4">' +
        '<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">' +
          '<b style="font-size:14px">' + esc(b.title) + '</b>' +
          '<span class="muted" style="font-size:12.5px">' + b.total_chapters + ' 章 · ' +
            (b.total_seconds / 3600).toFixed(2) + ' 小时 · 任务 #' + b.job_id + '</span>' +
          (b.hidden ? '<span class="badge" style="background:#fdeaea;color:#e5484d">已隐藏</span>' : '') +
          '<span style="flex:1"></span>' +
          '<select onchange="alSetCat(' + b.id + ', this.value)">' + opt + '</select>' +
          '<button class="btn ghost sm" onclick="alSetHidden(' + b.id + ',' + (b.hidden ? 0 : 1) + ')">' +
            (b.hidden ? '取消隐藏' : '隐藏') + '</button>' +
          '<button class="btn ghost sm" onclick="alRebuild(' + b.id + ')">重建索引</button>' +
          '<button class="btn danger sm" onclick="alUnreg(' + b.id + ',' + JSON.stringify(b.title).replace(/"/g, '&quot;') + ')">移出列表</button>' +
        '</div>' +
        '<div class="muted" style="font-size:12px;margin-top:5px;word-break:break-all">' +
          esc(b.author || '佚名') + ' · ' + esc(b.dest || '') + '</div>' +
        alPricingRow(b) +
      '</div>';
    }).join('');
  }).catch(function (e) { toast(e.message); });
}
function alSetCat(id, v) {
  alPost('/api/admin/audiobooks/' + id, { cat_id: parseInt(v, 10) || 0 })
    .then(function () { toast('已改分类'); alLoadBooks(); }).catch(function (e) { toast(e.message); });
}
function alSetHidden(id, v) {
  alPost('/api/admin/audiobooks/' + id, { hidden: v ? 1 : 0 })
    .then(function () { toast(v ? '已隐藏' : '已取消隐藏'); alLoadBooks(); }).catch(function (e) { toast(e.message); });
}
function alRebuild(id) {
  alPost('/api/admin/audiobooks/' + id + '/rebuild', {}).then(function (r) {
    toast('索引已重建：' + r.chapters + ' 章 / ' + (r.seconds / 3600).toFixed(2) + ' 小时');
    alLoadBooks();
  }).catch(function (e) { toast(e.message); });
}
function alUnreg(id, title) {
  if (!confirm('把「' + title + '」从有声页面移出？\n只删索引，NAS 上的 MP3 原文件不动。')) return;
  api('/api/admin/audiobooks/' + id, { method: 'DELETE' }).then(function () {
    toast('已移出有声页面'); alLoadBooks();
  }).catch(function (e) { toast(e.message); });
}
