# 接口一览

共 **160** 个 HTTP 接口，全部挂在同一个 FastAPI 应用上。下表按前缀分组，详细签名请直接看 `book_manager/app.py` 里对应的路由函数（每个函数上方都有中文说明）。

## 分组概览

| 前缀 | 数量 | 用途 |
| --- | --- | --- |
| `/api/admin` | 55 | 后台：用户、分组、书籍、统计、TTS 线路、配置 |
| `/api/books` | 42 | 书库与阅读：列表、详情、目录、正文分段、封面、上传、下载、分享 |
| `/api/shelf` | 9 |  |
| `/api/me` | 6 | 账号：资料、书架、消息、签到、额度 |
| `/api/share` | 5 | 分享页与提取 |
| `/api/messages` | 5 |  |
| `/api/notes` | 5 |  |
| `/api/signin` | 2 |  |
| `/api/settings` | 2 |  |
| `/api/home-categories` | 2 |  |
| `/api/convert` | 2 |  |
| `/api/shares` | 2 |  |
| `/api/group-exchange` | 2 |  |
| `/api/register` | 1 | 注册 |
| `/api/forgot-password` | 1 |  |
| `/api/reset-password` | 1 |  |
| `/api/login` | 1 | 登录签发令牌 |
| `/api/categories` | 1 | 分类树 |
| `/api/cat-folders` | 1 |  |
| `/api/authors` | 1 |  |
| `/api/home` | 1 |  |
| `/api/reading` | 1 | 阅读进度与时长 |
| `/api/upload` | 1 |  |
| `/api/media-ticket` | 1 |  |
| `/api/ads` | 1 |  |
| `/api/intro` | 1 |  |
| `/api/site` | 1 |  |
| `/api/terms` | 1 |  |
| `/api/health` | 1 | 健康检查 |
| `/` | 1 |  |
| `/admin` | 1 |  |
| `/reader` | 1 |  |
| `/listen` | 1 |  |
| `/s/{token}` | 1 |  |

## 完整清单

鉴权：除 `/api/health`、首页、静态资源、分享页外，一律需要 `Authorization: Bearer <JWT>`；管理接口还要求 `role=admin`。

### /api/register

- `POST /api/register`

### /api/forgot-password

- `POST /api/forgot-password`

### /api/reset-password

- `POST /api/reset-password`

### /api/login

- `POST /api/login`

### /api/me

- `GET /api/me`
- `PUT /api/me`
- `PUT /api/me/password`
- `GET /api/me/recent`
- `GET /api/me/reading-history`
- `DELETE /api/me/progress/{book_id}`

### /api/signin

- `GET /api/signin/status`
- `POST /api/signin`

### /api/categories

- `GET /api/categories`

### /api/cat-folders

- `GET /api/cat-folders`

### /api/books

- `GET /api/books`
- `GET /api/books/{book_id}`
- `PUT /api/books/{book_id}`
- `DELETE /api/books/{book_id}`
- `POST /api/books/ftp-import`
- `GET /api/books/{book_id}/cover`
- `POST /api/books/{book_id}/cover`
- `POST /api/books/{book_id}/cover/online`
- `POST /api/books/{book_id}/enrich`
- `GET /api/books/{book_id}/intro`
- `GET /api/books/{book_id}/read`
- `GET /api/books/{book_id}/search`
- `GET /api/books/{book_id}/toc`
- `GET /api/books/{book_id}/chapter`
- `GET /api/books/{book_id}/txt`
- `GET /api/books/{book_id}/txt-batch`
- `GET /api/books/{book_id}/resource`
- `GET /api/books/{book_id}/file`
- `GET /api/books/{book_id}/progress`
- `PUT /api/books/{book_id}/progress`
- `GET /api/books/{book_id}/listen/info`
- `POST /api/books/{book_id}/listen/start`
- `GET /api/books/{book_id}/listen/seg/{idx}`
- `GET /api/books/{book_id}/listen/texts`
- `GET /api/books/{book_id}/listen/status`
- `POST /api/books/{book_id}/listen/prefetch`
- `POST /api/books/{book_id}/listen/heartbeat`
- `GET /api/books/{book_id}/listen/watch`
- `POST /api/books/{book_id}/listen/stop`
- `POST /api/books/{book_id}/listen/line`
- `GET /api/books/{book_id}/listen/progress`
- `PUT /api/books/{book_id}/listen/progress`
- `POST /api/books/{book_id}/download-ticket`
- `GET /api/books/{book_id}/download`
- `GET /api/books/{book_id}/download.{ext}`
- `POST /api/books/{book_id}/convert`
- `GET /api/books/{book_id}/convert/{fmt}`
- `DELETE /api/books/{book_id}/convert`
- `POST /api/books/{book_id}/share`
- `POST /api/books/batch`
- `POST /api/books/{book_id}/report`
- `POST /api/books/{book_id}/share-request`

### /api/authors

- `GET /api/authors`

### /api/home

- `GET /api/home/hot`

### /api/reading

- `POST /api/reading/heartbeat`

### /api/upload

- `POST /api/upload`

### /api/settings

- `GET /api/settings`
- `PUT /api/settings`

### /api/home-categories

- `GET /api/home-categories`
- `PUT /api/home-categories`

### /api/shelf

- `GET /api/shelf`
- `POST /api/shelf/collections`
- `PUT /api/shelf/collections/reorder`
- `PUT /api/shelf/collections/{cid}`
- `DELETE /api/shelf/collections/{cid}`
- `POST /api/shelf/{book_id}`
- `PUT /api/shelf/{book_id}`
- `DELETE /api/shelf/{book_id}`
- `POST /api/shelf/{book_id}/share`

### /api/media-ticket

- `POST /api/media-ticket`

### /api/convert

- `GET /api/convert/status/{task_id}`
- `GET /api/convert/tasks`

### /api/shares

- `GET /api/shares`
- `DELETE /api/shares/{token}`

### /api/share

- `GET /api/share/{token}`
- `GET /api/share/{token}/cover`
- `POST /api/share/{token}/verify`
- `POST /api/share/{token}/read-ticket`
- `GET /api/share/{token}/download`

### /api/admin

- `GET /api/admin/duplicates`
- `GET /api/admin/reports`
- `POST /api/admin/reports/{rid}/handle`
- `GET /api/admin/share-requests`
- `POST /api/admin/share-requests/handle`
- `GET /api/admin/audit`
- `GET /api/admin/file-logs`
- `GET /api/admin/activity`
- `GET /api/admin/stats`
- `GET /api/admin/site-stats`
- `GET /api/admin/site-stats/flush`
- `POST /api/admin/books/guest-feature`
- `POST /api/admin/sync`
- `GET /api/admin/sync/status`
- `POST /api/admin/xunlei-import`
- `GET /api/admin/xunlei-import/status`
- `GET /api/admin/xunlei-import/log`
- `POST /api/admin/dedup/scan`
- `GET /api/admin/dedup/status`
- `GET /api/admin/dedup/report`
- `POST /api/admin/dedup/delete`
- `POST /api/admin/enrich`
- `GET /api/admin/enrich/status`
- `GET /api/admin/config`
- `POST /api/admin/config`
- `POST /api/admin/serverchan/test`
- `GET /api/admin/ads`
- `PUT /api/admin/ads`
- `GET /api/admin/welcome`
- `PUT /api/admin/welcome`
- `GET /api/admin/intro`
- `PUT /api/admin/intro`
- `GET /api/admin/sources`
- `POST /api/admin/sources`
- `PUT /api/admin/sources/{sid}`
- `DELETE /api/admin/sources/{sid}`
- `GET /api/admin/users`
- `GET /api/admin/users/{uid}/shelf`
- `POST /api/admin/users`
- `PUT /api/admin/users/{uid}`
- `DELETE /api/admin/users/{uid}`
- `POST /api/admin/users/batch`
- `GET /api/admin/listen/lines`
- `POST /api/admin/listen/groups`
- `POST /api/admin/listen/voice/rename`
- `POST /api/admin/listen/voice/toggle`
- `POST /api/admin/listen/voice/delete`
- `POST /api/admin/listen/voice/preview`
- `POST /api/admin/listen/voice/upload`
- `GET /api/admin/tts/test`
- `GET /api/admin/groups`
- `POST /api/admin/groups`
- `PUT /api/admin/groups/{gid}`
- `DELETE /api/admin/groups/{gid}`
- `PUT /api/admin/terms`

### /api/messages

- `GET /api/messages`
- `GET /api/messages/unread`
- `GET /api/messages/notify`
- `POST /api/messages/read`
- `POST /api/messages`

### /api/group-exchange

- `GET /api/group-exchange`
- `POST /api/group-exchange`

### /api/notes

- `GET /api/notes`
- `GET /api/notes/{book_id}`
- `PUT /api/notes/{book_id}`
- `DELETE /api/notes/{book_id}`
- `POST /api/notes/batch-delete`

### /api/ads

- `GET /api/ads`

### /api/intro

- `GET /api/intro`

### /api/site

- `GET /api/site`

### /api/terms

- `GET /api/terms`

### /api/health

- `GET /api/health`

### /

- `GET /`

### /admin

- `GET /admin`

### /reader

- `GET /reader`

### /listen

- `GET /listen`

### /s/{token}

- `GET /s/{token}`

