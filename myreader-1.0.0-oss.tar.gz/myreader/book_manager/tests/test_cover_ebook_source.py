# -*- coding: utf-8 -*-
"""「电子书内图片」封面源（§14.95）。

背景：很多电子书制作时把**纸质版封面的照片**放进正文第一页/扉页，却没写成 EPUB 的
cover 元数据 —— 「提取内嵌封面」取不到，在线刮削又常匹配到别的版本。这个源就是
按阅读顺序去文件里找那一张图，并作为「封面刮削接入资源」里可排序、可启停的一项。

本脚本**不联网、不动线上数据**：
  · EPUB 用 zipfile 现造（含 spine 顺序、大图/小图/无图/SVG 包裹/百分号文件名等边界）；
  · PDF 用 Pillow 现造（走 pdftoppm 渲第 1 页）；
  · CBZ 用 zipfile 现造（取第一张）；
  · cover_sources 表跑前快照、跑后**原样还原**（业主可能调过顺序/启停）。
"""
import io
import os
import shutil
import sys
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.chdir(ROOT)

import config  # noqa: E402
import db  # noqa: E402
import formats  # noqa: E402
import covers  # noqa: E402

PASS = []
FAIL = []


def ck(name, ok, extra=""):
    (PASS if ok else FAIL).append(name)
    print(("  ✓ " if ok else "  ✗ ") + name + (("  → " + str(extra)) if (extra and not ok) else ""))


# ---------------------------------------------------------------- 造图 / 造书
def png(w, h, color=(200, 30, 40), tag=b""):
    """造一张尺寸可控的 PNG（w*h 决定它算不算「够大」）"""
    from PIL import Image
    buf = io.BytesIO()
    Image.new("RGB", (w, h), color).save(buf, "PNG")
    data = buf.getvalue()
    # 末尾塞点注释让不同图字节不同（便于断言取到的是哪一张）
    return data + tag


def jpg(w, h, color=(20, 90, 200)):
    from PIL import Image
    buf = io.BytesIO()
    Image.new("RGB", (w, h), color).save(buf, "JPEG", quality=80)
    return buf.getvalue()


def page(*imgs):
    inner = "".join(f'<img src="{s}"/>' for s in imgs)
    return ('<?xml version="1.0" encoding="utf-8"?>'
            '<html xmlns="http://www.w3.org/1999/xhtml"><body>'
            f'<div>{inner}</div></body></html>').encode("utf-8")


def svg_page(href):
    return ('<?xml version="1.0" encoding="utf-8"?>'
            '<svg xmlns="http://www.w3.org/2000/svg" '
            'xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 600 900">'
            f'<image xlink:href="{href}" width="600" height="900"/></svg>').encode("utf-8")


def build_epub(path, spine, images, cover_id=None):
    """spine: [(item_id, href, bytes)]；images: {href: bytes}（各自 media-type 按后缀）"""
    mt = {".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png",
          ".gif": "image/gif", ".svg": "image/svg+xml"}
    items, refs = [], []
    for iid, href, _ in spine:
        items.append(f'<item id="{iid}" href="{href}" media-type="application/xhtml+xml"/>')
        refs.append(f'<itemref idref="{iid}"/>')
    for href, data in images.items():
        ext = os.path.splitext(href.lower())[1]
        items.append(f'<item id="img_{len(items)}" href="{href}" media-type="{mt.get(ext, "image/png")}"/>')
    meta = f'<meta name="cover" content="{cover_id}"/>' if cover_id else ""
    opf = ('<?xml version="1.0" encoding="utf-8"?>'
           '<package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="bid">'
           '<metadata xmlns:dc="http://purl.org/dc/elements/1.1/">'
           '<dc:title>测试书</dc:title><dc:creator>测试作者</dc:creator>'
           f'{meta}</metadata>'
           f'<manifest>{"".join(items)}</manifest>'
           f'<spine>{"".join(refs)}</spine></package>').encode("utf-8")
    container = ('<?xml version="1.0"?>'
                 '<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">'
                 '<rootfiles><rootfile full-path="OEBPS/content.opf" '
                 'media-type="application/oebps-package+xml"/></rootfiles></container>').encode("utf-8")
    with zipfile.ZipFile(path, "w") as z:
        z.writestr("mimetype", "application/epub+zip")
        z.writestr("META-INF/container.xml", container)
        z.writestr("OEBPS/content.opf", opf)
        for _, href, data in spine:
            z.writestr("OEBPS/" + href, data)
        for href, data in images.items():
            z.writestr("OEBPS/" + href, data)


TMP = os.path.join(config.CACHE_DIR, "test_ebook_src")
shutil.rmtree(TMP, ignore_errors=True)
os.makedirs(TMP, exist_ok=True)

BIG = png(600, 900, (10, 120, 60), b"BIG")          # 够大（min 边 600）
BIG2 = png(700, 1000, (120, 10, 60), b"BIG2")
SMALL = png(48, 48, (255, 255, 255), b"LOGO")        # logo，不该当封面

print("A. read_epub_inner_image：按阅读顺序取图")

# A1 封面就是第一页里的图
p = f"{TMP}/a1.epub"
build_epub(p, [("p1", "text/p1.xhtml", page("../images/cover.png")), ("p2", "text/p2.xhtml", page("../images/other.png"))],
           {"images/cover.png": BIG, "images/other.png": BIG2})
data, mt = formats.read_epub_inner_image(p)
ck("A1 第一页的图被选中（不是第二页的）", data == BIG and mt == "image/png", f"{len(data or b'')}B/{mt}")

# A2 前面有个 logo，应该跳过小图取后面的大图
PHOTO = jpg(700, 1000)
p = f"{TMP}/a2.epub"
build_epub(p, [("p1", "text/p1.xhtml", page("../images/logo.png", "../images/photo.jpg"))],
           {"images/logo.png": SMALL, "images/photo.jpg": PHOTO})
data, mt = formats.read_epub_inner_image(p)
ck("A2 跳过 48×48 的 logo、取后面的大图", data == PHOTO, f"{len(data or b'')}B/{mt}")

# A3 第一页是纯文字，图在第二章
p = f"{TMP}/a3.epub"
build_epub(p, [("p1", "text/p1.xhtml", page()), ("p2", "text/p2.xhtml", page("../images/photo.jpg"))],
           {"images/photo.jpg": jpg(700, 1000)})
data, mt = formats.read_epub_inner_image(p)
ck("A3 纯文字首页跳过、取第二章的图", data and mt == "image/jpeg", f"{mt}")

# A4 SVG 包裹的图（<image xlink:href>）
p = f"{TMP}/a4.epub"
build_epub(p, [("p1", "text/cover.xhtml", svg_page("../images/cover.png"))],
           {"images/cover.png": BIG})
data, mt = formats.read_epub_inner_image(p)
ck("A4 SVG 里的 <image xlink:href> 也能取到", data == BIG, f"{len(data or b'')}B")

# A5 文件名带百分号编码（中文图片名）
CN = "图片/封面.png"
p = f"{TMP}/a5.epub"
build_epub(p, [("p1", "text/p1.xhtml", page("../%E5%9B%BE%E7%89%87/%E5%B0%81%E9%9D%A2.png"))],
           {CN: BIG})
data, mt = formats.read_epub_inner_image(p)
ck("A5 百分号编码的中文图片路径能解析", data == BIG, f"{len(data or b'')}B")

# A6 整本没有图
p = f"{TMP}/a6.epub"
build_epub(p, [("p1", "text/p1.xhtml", page()), ("p2", "text/p2.xhtml", page())], {})
ck("A6 全书无图 → (None, None)", formats.read_epub_inner_image(p) == (None, None))

# A7 引用了一张不存在的图 → 不抛异常
p = f"{TMP}/a7.epub"
build_epub(p, [("p1", "text/p1.xhtml", page("../images/missing.png"))], {})
ck("A7 图片缺失不抛异常，返回 (None, None)", formats.read_epub_inner_image(p) == (None, None))

# A8 全是小图 → 退而取最大的一张（而不是直接放弃）
p = f"{TMP}/a8.epub"
build_epub(p, [("p1", "text/p1.xhtml", page("../images/s1.png", "../images/s2.png"))],
           {"images/s1.png": png(60, 60, tag=b"A"), "images/s2.png": png(200, 200, tag=b"B")})
data, mt = formats.read_epub_inner_image(p)
ck("A8 都不够大时取面积最大的", data == png(200, 200, tag=b"B"), f"{len(data or b'')}B")

# A8b 全是小图时优先取**立式**的（横版横幅当封面很糟）
p = f"{TMP}/a8b.epub"
build_epub(p, [("p1", "text/p1.xhtml", page("../images/banner.png", "../images/portrait.png"))],
           {"images/banner.png": png(600, 160, tag=b"BANNER"), "images/portrait.png": png(150, 220, tag=b"P")})
data, mt = formats.read_epub_inner_image(p)
ck("A8b 小图兜底时选立式、不选大面积的横版横幅", data == png(150, 220, tag=b"P"),
   f"{formats._img_size(data or b'')}")

# A8c 整本只有横图 → 返回 None（不拿横幅凑数）
p = f"{TMP}/a8c.epub"
build_epub(p, [("p1", "text/p1.xhtml", page("../images/banner.png"))],
           {"images/banner.png": png(600, 160, tag=b"BANNER")})
ck("A8c 只有横版图时宁可不给（返回 None，交给占位图）", formats.read_epub_inner_image(p) == (None, None))

# A9 坏文件不能崩
bad = f"{TMP}/bad.epub"
with open(bad, "wb") as fh:
    fh.write(b"not a zip at all")
ck("A9 坏文件不抛异常", formats.read_epub_inner_image(bad) == (None, None))

# A10 有 cover 元数据时也不影响（这个源不看元数据，只看图本身）
p = f"{TMP}/a10.epub"
build_epub(p, [("p1", "text/p1.xhtml", page("../images/cover.png"))], {"images/cover.png": BIG},
           cover_id="img_0")
ck("A10 有 cover 元数据的书同样能取到图", formats.read_epub_inner_image(p)[0] == BIG)

print("\nB. covers.ebook_cover：按格式取图")
# 测试用假书号，直接写进 CACHE_DIR（ensure_local 按 id+size 命中缓存，不会碰 FTP）
BID = 990001


def fake_book(ext, path, size):
    return {"id": BID, "ext": ext, "size": size, "path": "/nonexistent/never-used"}


def put_cache(src, ext):
    """把测试文件放到 ensure_local 会命中的缓存路径"""
    dst = os.path.join(config.CACHE_DIR, f"b{BID}_{BID}{ext}")
    shutil.copyfile(src, dst)
    return dst


# B1 epub
src = f"{TMP}/b1.epub"
build_epub(src, [("p1", "text/p1.xhtml", page("../images/cover.png"))], {"images/cover.png": BIG})
c = put_cache(src, ".epub")
ck("B1 epub 走文件内取图", covers.ebook_cover(fake_book(".epub", c, os.path.getsize(c))) == BIG)

# B2 pdf：Pillow 造一页 PDF，走 pdftoppm 渲染第 1 页
from PIL import Image  # noqa: E402
pdf = f"{TMP}/b2.pdf"
im = Image.new("RGB", (600, 900), (30, 140, 90))
im.save(pdf, "PDF", resolution=72)
c = put_cache(pdf, ".pdf")
got = covers.ebook_cover(fake_book(".pdf", c, os.path.getsize(c)))
ck("B2 pdf 渲染第 1 页返回 JPEG", bool(got) and got[:3] == b"\xff\xd8\xff", f"{(got or b'')[:4]!r} {len(got or b'')}B")

# B3 cbz：漫画，取排序第一张
cbz = f"{TMP}/b3.cbz"
with zipfile.ZipFile(cbz, "w") as z:
    z.writestr("002.jpg", jpg(600, 900, (9, 9, 9)))
    z.writestr("001.jpg", jpg(600, 900, (1, 1, 1)))
    z.writestr("__MACOSX/._001.jpg", b"junkjunkjunk")
c = put_cache(cbz, ".cbz")
got = covers.ebook_cover(fake_book(".cbz", c, os.path.getsize(c)))
ck("B3 cbz 取文件名排序第一张（跳过 __MACOSX）", got == jpg(600, 900, (1, 1, 1)), f"{len(got or b'')}B")

# B4 没有图的格式
ck("B4 txt 返回 None", covers.ebook_cover(fake_book(".txt", "/tmp/x.txt", 10)) is None)
ck("B5 book=None 返回 None（不炸）", covers.ebook_cover(None) is None)
ck("B6 ext 为空返回 None", covers.ebook_cover({"id": 1, "ext": "", "size": 1, "path": "p"}) is None)

print("\nC. 刮削链路：ebook 源参与排序、能被调用、能顺延")
snap = [dict(r) for r in db.q("SELECT * FROM cover_sources ORDER BY sort_order, id")]


def set_sources(items):
    """把 cover_sources 换成给定配置（跑完还原）。

    items 每项是 (名称, 类型, 是否启用enabled)，**顺序**由列表下标决定 ——
    别把「排序号」塞进第三位，那个位置是 enabled：写成 2 会被 enabled=1 的查询过滤掉，
    表现是「源神秘消失」。


    ★ db.ex 有「拒绝不带 WHERE 的全表删」保护（防手滑清表），所以按 id 一条条删，
      不去绕过它 —— 这个保护值得留着。
    """
    for r in db.q("SELECT id FROM cover_sources", one=False):
        db.ex("DELETE FROM cover_sources WHERE id=?", (r["id"],))
    for i, (nm, tp, en) in enumerate(items):
        db.ex("INSERT INTO cover_sources (name,type,enabled,sort_order) VALUES (?,?,?,?)", (nm, tp, en, i + 1))


try:
    # C1 只有 ebook 源 + 有书 → 取到文件内图片
    set_sources([("电子书内图片", "ebook", 1)])
    src = f"{TMP}/c1.epub"
    build_epub(src, [("p1", "text/p1.xhtml", page("../images/cover.png"))], {"images/cover.png": BIG})
    c = put_cache(src, ".epub")
    b = fake_book(".epub", c, os.path.getsize(c))
    ck("C1 链路里 ebook 源取到文件内图片",
       covers.download_online_cover("测试书", "测试作者", b) == BIG)

    # C2 不传 book → ebook 源被跳过（不会误把「没书」当成「没图」报错）
    ck("C2 不传 book 时 ebook 源被跳过", covers.download_online_cover("测试书", "测试作者", None) is None)

    # C3 顺序：在线源排前面且返回了图 → 用在线源，不再去翻文件
    calls = []
    old = covers._SCRAPERS.get("douban")
    covers._SCRAPERS["douban"] = lambda t, a: (calls.append(t) or b"ONLINE")
    try:
        set_sources([("豆瓣读书", "douban", 1), ("电子书内图片", "ebook", 1)])
        got = covers.download_online_cover("测试书", "测试作者", b)
        ck("C3 在线源在前时优先用在线源", got == b"ONLINE" and calls == ["测试书"], f"{got!r}")
    finally:
        if old is not None:
            covers._SCRAPERS["douban"] = old

    # C4 在线源全失败 → 顺延到 ebook 源
    covers._SCRAPERS["douban"] = lambda t, a: None
    try:
        set_sources([("豆瓣读书", "douban", 1), ("电子书内图片", "ebook", 1)])
        got4 = covers.download_online_cover("测试书", "测试作者", b)
        ck("C4 在线源无结果时顺延到 ebook 源", got4 == BIG,
           f"got={len(got4 or b'')}B want={len(BIG)}B sources={[x['type'] for x in covers._source_list()]}")
    finally:
        if old is not None:
            covers._SCRAPERS["douban"] = old

    # C5 停用的 ebook 源不参与（★ 必须另有启用的源：表里一条都不启用时
    #    _source_list() 会退回默认源列表，那是原有行为，不是这里要测的）
    covers._SCRAPERS["douban"] = lambda t, a: None
    try:
        set_sources([("豆瓣读书", "douban", 1), ("电子书内图片", "ebook", 0)])
        ck("C5 停用的 ebook 源不参与刮削",
           covers.download_online_cover("测试书", "测试作者", b) is None)
    finally:
        if old is not None:
            covers._SCRAPERS["douban"] = old

    # C6 未知类型不炸、继续往后走
    set_sources([("乱七八糟", "nosuchtype", 1), ("电子书内图片", "ebook", 1)])
    ck("C6 未知源类型被跳过、后面照常", covers.download_online_cover("测试书", "测试作者", b) == BIG)
finally:
    for r in db.q("SELECT id FROM cover_sources", one=False):
        db.ex("DELETE FROM cover_sources WHERE id=?", (r["id"],))
    for r in snap:
        db.ex("INSERT INTO cover_sources (id,name,type,enabled,sort_order) VALUES (?,?,?,?,?)",
              (r["id"], r["name"], r["type"], r["enabled"], r["sort_order"]))
    now = [dict(r) for r in db.q("SELECT * FROM cover_sources ORDER BY sort_order, id")]
    print("  · 已还原 cover_sources（%d 条）》" % len(now))
    for a, b2 in zip(snap, now):
        if a != b2:
            print("    ！还原不一致", a, b2)

print("\nD. 预置与后台接口")
sys.path.insert(0, ROOT)
import app  # noqa: E402
before = db.q("SELECT * FROM cover_sources WHERE type='ebook'", one=True)
app._seed_cover_sources()
row = db.q("SELECT * FROM cover_sources WHERE type='ebook'", one=True)
ck("D1 预置了「电子书内图片」源且启用", row is not None and row["enabled"] == 1 and row["name"] == "电子书内图片",
   dict(row) if row else None)
ck("D2 它排在在线源后面（sort_order 最大）",
   row is not None and row["sort_order"] >= max(
       (r["sort_order"] for r in db.q("SELECT sort_order FROM cover_sources", one=False)), default=0))
app._seed_cover_sources()
n = db.q("SELECT COUNT(*) c FROM cover_sources WHERE type='ebook'", one=True)["c"]
ck("D3 重复预置不会出现第二条（幂等）", n == 1, n)
if before is None:
    for r in db.q("SELECT id FROM cover_sources WHERE type='ebook'", one=False):
        db.ex("DELETE FROM cover_sources WHERE id=?", (r["id"],))   # 跑前没有则还原掉
    print("  · 已还原：删掉测试预置的 ebook 源（重启后由应用自己预置）")

# 清理测试缓存文件
for f in os.listdir(config.CACHE_DIR):
    if f.startswith(f"b{BID}_") or f.startswith(f"ecv{BID}"):
        try:
            os.remove(os.path.join(config.CACHE_DIR, f))
        except Exception:
            pass
shutil.rmtree(TMP, ignore_errors=True)

print("\n%s" % ("=" * 62))
print("「电子书内图片」封面源：%d 通过 / %d 失败" % (len(PASS), len(FAIL)))
if FAIL:
    for f in FAIL:
        print("  失败：" + f)
sys.exit(1 if FAIL else 0)
