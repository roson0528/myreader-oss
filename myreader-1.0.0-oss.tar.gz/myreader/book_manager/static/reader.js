// 阅读器逻辑（分页模式：仅左右翻页，无上下滑动）
const TOKEN = localStorage.getItem('bm_token') || '';
const BID = new URLSearchParams(location.search).get('id');
// 分享在线阅读（§14.113）：?share=<券>。券只允许读这一本书，身份是游客 ——
// 因此进度、书签、划线、笔记一律不落库，界面上这些入口也一并隐藏。
const SHARE = new URLSearchParams(location.search).get('share') || '';
let KIND = '', TOC = [], curIdx = 0, total = 0;
let MD = false;   // Markdown 书：复用 txt 管线，但内容已是渲染后 HTML
let curPage = 0, pagesInChapter = 1, pendingPage = 0;
let committedIdx = 0, committedPage = 0, renderToken = 0;  // 已“渲染完成”的进度 + 渲染令牌（防异步乱序）
let rendering = false, pendingFlipDir = 0;   // 章节加载中标记 + 暂存翻页方向（防连点跳章节）
let afterPaginate = null, lastQuery = '';
let pdfDoc = null, pdfPage = 1, pdfScale = 1;
let pageCounts = [], pageOffset = [], totalPages = 0, pageMapReady = false, mapToken = 0;
let settings = { theme: 'sepia', font_size: 18, font_family: 'serif', line_height: 1.8, page_width: '92%', brightness: 1.0, flip_effect: 'flip', flip_speed: 380, font_color: '' };
let notesData = { highlights: [], notes: [], bookmarks: [], searches: [] };
let chromeHidden = false;   // 沉浸式：手动隐藏上下栏

// ---------- 设备识别与阅读模式 ----------
const isKindle = /Kindle|Silk/i.test(navigator.userAgent);   // Kindle 实验浏览器（旧 WebKit，多栏支持差）
let MODE = localStorage.getItem('bm_mode') || (isKindle ? 'scroll' : 'paged');   // 'paged' 分页翻页 | 'scroll' 滚动阅读（Kindle 兼容）
let resumeScrollFrac = null;   // 滚动模式恢复位置（0..1）
let savedScroll = null;        // 最近一次滚动位置（0..1），分页模式保存时保留，避免跨模式覆盖
let pendingFrac = null;        // 跨设备恢复：章节内比例（0..1），渲染后映射为页码
let DEV = localStorage.getItem('bm_devid');   // 本机设备标识：用于区分同设备精确恢复 vs 跨设备按比例恢复
if (!DEV) { DEV = ('d' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8)); localStorage.setItem('bm_devid', DEV); }
let _lastFlipAt = 0;
const FLIP_MIN_MS = isKindle ? 420 : 110;   // 翻页防抖：Kindle 触屏/墨水屏延迟大，防连点一次翻多页
function setMode(m) { MODE = m; localStorage.setItem('bm_mode', m); }
// epub/mobi(azw3 转出)/txt 都走同一套分栏渲染与重排逻辑
function isFlowable() { return KIND === 'epub' || KIND === 'mobi' || KIND === 'txt'; }
// rAF 兼容封装：Kindle 等旧内核 rAF 可能不触发，用 setTimeout 兜底保证必定执行
function raf(fn) {
  let done = false;
  const run = () => { if (!done) { done = true; try { fn(); } catch (e) {} } };
  try { if (window.requestAnimationFrame) requestAnimationFrame(run); } catch (e) {}
  setTimeout(run, 40);
}
function textLen(el) { return el ? el.innerHTML.replace(/<[^>]*>/g, '').trim().length : 0; }

// 返回键：回图书详情页（「返回上一级」，不是浏览器式后退）。
// 详情页 → 阅读器是下一级，所以返回一律回详情页。
// 不能用 history.back()：那是退回「上一个访问过的页面」，可能是书架、
// 搜索页，甚至另一本书的详情 —— 层级上并不等于这本书的上一级。
// 地址必须是 '#/book/'（应用路由）；'#!/book/6' 会被路由解析成 seg='!'，
// 落到兜底分支变成首页，回不到详情页。
function goBack() {
  try { flushSave(); } catch (e) {}       // 先把进度存了；pagehide 也会兜底
  location.href = '/#/book/' + BID;
}

// 安卓 App（Capacitor WebView）系统返回键：关抽屉/搜索 → 走 goBack()（回上一页或详情页）
(function () {
  try {
    const App = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App;
    if (!App) return;
    App.addListener('backButton', () => {
      const dm = document.getElementById('drawer-mask');
      if (dm && !dm.classList.contains('hidden')) { closeDrawers(); return; }
      goBack();
    });
  } catch (e) {}
})();

// 后端错误体 → 人能看懂的一句话（FastAPI 的 422 detail 是对象数组，
// 直接 new Error 会变成「[object Object]」）
function apiErrText(d, status) {
  const det = d && (d.detail != null ? d.detail : d.message);
  if (typeof det === 'string' && det) return det;
  if (Array.isArray(det)) {
    const parts = det.map(x => {
      if (typeof x === 'string') return x;
      if (x && typeof x === 'object') {
        const loc = Array.isArray(x.loc) ? x.loc.filter(k => k !== 'body' && k !== 'query').join('.') : '';
        return (loc ? loc + '：' : '') + (x.msg || JSON.stringify(x));
      }
      return String(x);
    }).filter(Boolean);
    if (parts.length) return parts.join('；');
  } else if (det && typeof det === 'object') {
    return det.message || det.msg || JSON.stringify(det);
  }
  // 后端什么都没给：返回空串，由调用方给各自合适的兜底文案
  // （登录 401 要说「用户名或密码错误」，别的接口说 HTTP 状态码）
  return '';
}
function api(path, opts = {}) {
  const headers = opts.headers || {};
  if (SHARE) headers['Authorization'] = 'Share ' + SHARE;
  else if (TOKEN) headers['Authorization'] = 'Bearer ' + TOKEN;
  return fetch(path, { ...opts, headers }).then(async r => {
    if (r.status === 401) {
      // 分享阅读：券过期就提示回分享页重开（本机可能另有登录态，不能跳首页）
      if (SHARE) throw new Error('阅读链接已失效，请回到分享页重新打开');
      // 游客（无 token）：不跳转首页，仅提示
      if (!TOKEN) throw new Error('请注册账号后使用此功能');
      location.href = '/'; throw new Error('未登录');
    }
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(apiErrText(d, r.status) || ('请求失败 ' + r.status));
    return d;
  });
}
let mediaTicket = '';
async function ensureMediaTicket() {
  if (mediaTicket) return;
  try { const r = await api('/api/media-ticket', { method: 'POST' }); mediaTicket = r.ticket; } catch (e) {}
}
function tokenQS() { return '?t=' + encodeURIComponent(mediaTicket); }

async function init() {
  applyModeClass();
  if (MODE === 'scroll') showScrollHint();
  document.addEventListener('click', onScreenClick);
  initGestures();
  initProgressDrag();
  initLinkHandler();
  window.addEventListener('pagehide', flushSave);
  window.addEventListener('beforeunload', flushSave);
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') flushSave(); });
  window.addEventListener('resize', () => { reflowImmediate(); });
  document.addEventListener('keydown', e => {
    if (e.target.closest('input,textarea,select')) return;
    if (e.key === 'ArrowLeft') flip(-1);
    else if (e.key === 'ArrowRight' || e.key === ' ') flip(1);
  });
  try { settings = await api('/api/settings'); } catch (e) {}
  applySettings();
  await loadNotesData();
  if (SHARE) {
    // 分享阅读：藏掉书签/划线的入口，避免点了没反应
    const bm = document.querySelector('#r-topbar button[onclick="addBookmark()"]');
    if (bm) bm.style.display = 'none';
  } else {
    initSelectionCapture();
  }
  const meta = await api('/api/books/' + BID + '/read');
  document.getElementById('r-title').textContent = meta.title;
  KIND = meta.kind;
  if (KIND === 'md') { MD = true; KIND = 'txt'; }   // Markdown 复用 txt 管线（后端已渲染为 HTML）
  applyModeClass();   // KIND 已知后才能决定是否进入整页滚动布局（html.scroll-read）
  startReadingTimer();   // 阅读时长心跳（仅登录用户累计）
  if (KIND === 'epub' || KIND === 'mobi') { await ensureMediaTicket(); return initEpub(); }   // 章节内图片也需要媒体凭证
  if (KIND === 'txt' || KIND === 'docx') return initTxt();
  if (KIND === 'pdf' || KIND === 'html') await ensureMediaTicket();
  if (KIND === 'pdf') return initPdf();
  if (KIND === 'html') return initHtml();
  document.getElementById('r-content').innerHTML = '<div class="empty">该格式暂不支持在线阅读，可下载后本地打开</div>';
  document.getElementById('r-bottom').style.display = 'none';
}
async function loadProgress() {
  try { return await api('/api/books/' + BID + '/progress'); } catch (e) { return { progress: null, percent: 0 }; }
}
async function saveProgress(position, percent, keepalive) {
  if (SHARE) return;                     // 分享阅读：不保存进度
  const opts = { method: 'PUT', headers: { 'Content-Type': 'application/json' } };
  if (TOKEN) opts.headers['Authorization'] = 'Bearer ' + TOKEN;
  opts.body = JSON.stringify({ position, percent });
  if (keepalive) opts.keepalive = true;
  try { await fetch('/api/books/' + BID + '/progress', opts); } catch (e) {}
}
// ---------- 滚动容器探测 ----------
// 各内核（桌面浏览器 / Android WebView / Kindle 旧 WebKit）整页滚动实际挂在哪个元素上并不一致：
// 有的走视口（window.scrollY），有的把滚动放在 body 或内层容器上。若只认 window，
// 就会出现「滚动后进度仍为 0、书签定位回章首」。这里统一探测真正的滚动容器。
function _canScroll(el) {
  try { return !!el && (el.scrollHeight - el.clientHeight) > 4; } catch (e) { return false; }
}
function scrollRoot() {
  const de = document.documentElement, b = document.body;
  const cands = [document.scrollingElement, de, b,
                 document.getElementById('page-view'), document.getElementById('r-content')];
  for (let i = 0; i < cands.length; i++) {
    if (_canScroll(cands[i])) return cands[i];
  }
  return document.scrollingElement || de || b || null;
}
function wY() {
  const r = scrollRoot();
  const winY = window.scrollY || window.pageYOffset || 0;
  if (r && r !== document.documentElement && r !== document.body) return r.scrollTop || 0;
  if (winY) return winY;
  return (r && r.scrollTop) || 0;   // 视口没动但内层容器滚动了
}
function docMaxTop() {
  const r = scrollRoot();
  if (!r) return 0;
  const h = r.scrollHeight || 0;
  const c = r.clientHeight || window.innerHeight || 0;
  return Math.max(0, h - c);
}
function scrollToY(y) {
  const v = Math.max(0, y || 0);
  const r = scrollRoot();
  try { window.scrollTo(0, v); } catch (e) {}
  // 部分内核 window.scrollTo 无效（滚动其实发生在 body/内层容器），补一次直接赋值
  if (r && r !== document.documentElement) {
    try { if (Math.abs((r.scrollTop || 0) - v) > 1) r.scrollTop = v; } catch (e) {}
  } else if (r) {
    try { if (!(window.scrollY || window.pageYOffset) && v > 0) r.scrollTop = v; } catch (e) {}
  }
}
function scrollFrac() {
  const maxTop = docMaxTop();
  if (maxTop <= 0) return 0;
  return Math.max(0, Math.min(1, wY() / maxTop));
}
// 章节内比例（0..1，与阅读模式/设备无关）：进度存档与书签定位统一用它
function chapterFrac() {
  if (MODE === 'scroll') return scrollFrac();
  return pagesInChapter > 1 ? Math.min(1, Math.max(0, committedPage / (pagesInChapter - 1))) : 0;
}
function currentPosition() {
  const kind = (KIND === 'txt' || KIND === 'docx') ? 'txt' : 'epub';
  if (KIND === 'pdf') return { kind: 'pdf', page: pdfPage, dev: DEV };
  if (MODE === 'scroll') {
    savedScroll = scrollFrac();   // 记录本次滚动位置，供其他模式保存时保留
    return { kind, mode: 'scroll', idx: committedIdx, page: 0, scroll: savedScroll, frac: savedScroll, dev: DEV };
  }
  // 分页模式：frac 为章节内比例（设备无关），用于跨设备同步；page 仅本设备精确
  return { kind, mode: 'paged', idx: committedIdx, page: committedPage, scroll: savedScroll, frac: chapterFrac(), dev: DEV };
}

// ---------- 翻页 ----------
let _hintTimer = null;
function fadeHints() {
  clearTimeout(_hintTimer);
  _hintTimer = setTimeout(() => {
    const l = document.getElementById('zh-left'), r = document.getElementById('zh-right');
    if (l) l.style.opacity = '0'; if (r) r.style.opacity = '0';
  }, 2500);
}
function onScreenClick(e) {
  if (e.target.closest('a,button,iframe,canvas,#r-topbar,.drawer,.drawer-mask,input,textarea,select')) return;
  // 能横向滚动的表格：点它是想停住/拖它，别当成翻页点击
  const tw = e.target.closest('.md-tw');
  if (tw && tw.scrollWidth > tw.clientWidth + 4) return;
  // 正在选中文字（划线/批注）时不翻页
  try { if (window.getSelection && window.getSelection().toString().trim().length > 1) return; } catch (err) {}
  const y = e.clientY, h = window.innerHeight;
  if (chromeHidden && y < h * 0.25) { showChrome(); return; }   // 点击阅读区上方 1/4 → 显示上下栏
  const x = e.clientX, w = window.innerWidth;
  if (!w) return;
  if (x < w * 0.3) flip(-1);
  else if (x > w * 0.7) flip(1);
}
function initGestures() {
  let sx = 0, sy = 0;
  document.addEventListener('touchstart', e => { sx = e.touches[0].clientX; sy = e.touches[0].clientY; }, { passive: true });
  document.addEventListener('touchend', e => {
    const dx = e.changedTouches[0].clientX - sx, dy = e.changedTouches[0].clientY - sy;
    // 表格真的横向滚得动时，这一下是「拖表格看右边的列」，不翻页；装得下就照常翻页
    const tw = e.target.closest && e.target.closest('.md-tw');
    if (tw && Math.abs(dx) > 8 && Math.abs(dx) > Math.abs(dy) && tw.scrollWidth > tw.clientWidth + 4) return;
    if (Math.abs(dx) > 55 && Math.abs(dx) > Math.abs(dy) * 1.4) flip(dx < 0 ? 1 : -1);
  }, { passive: true });
}
function flip(dir) {
  fadeHints();
  if (KIND === 'html' || !total) return;
  const now = Date.now();
  if (now - _lastFlipAt < FLIP_MIN_MS) return;   // 防抖：重复事件/连点只翻一页
  _lastFlipAt = now;
  if (rendering) { pendingFlipDir = dir; return; }   // 章节加载中：暂存翻页，加载完成后处理，避免跳章节
  doFlip(dir);
}
function doFlip(dir) {
  if (MODE === 'scroll') { scrollByScreen(dir); return; }
  if (KIND === 'pdf') {
    pdfGoto(pdfPage + dir);
    return;
  }
  if (dir > 0) {
    if (curPage < pagesInChapter - 1) { animateFlip(dir, () => gotoPage(curPage + 1)); }
    else if (curIdx < total - 1) { renderAt(curIdx + 1, 0); }
  } else {
    if (curPage > 0) { animateFlip(dir, () => gotoPage(curPage - 1)); }
    else if (curIdx > 0) { renderAt(curIdx - 1, 'last'); }
  }
}
// 滚动模式：整页 document 滚动（Kindle 旧内核最可靠的滚动方式），到章尾自动进下一章，到章首自动回上一章
function scrollByScreen(dir) {
  const H = window.innerHeight;
  const maxTop = docMaxTop();
  if (dir > 0) {
    if (wY() >= maxTop - 6) {
      if (curIdx < total - 1) { renderAt(curIdx + 1, 0); }
    } else {
      scrollToY(Math.min(maxTop, wY() + H * 0.92));
    }
  } else {
    if (wY() <= 6) {
      if (curIdx > 0) { renderAt(curIdx - 1, 'last'); }
    } else {
      scrollToY(Math.max(0, wY() - H * 0.92));
    }
  }
}
// ---------- 沉浸式上下栏（手动隐藏，点击阅读区上方 1/4 恢复） ----------
function toggleChrome() {
  if (chromeHidden) showChrome();
  else hideChrome();
}
function hideChrome() {
  chromeHidden = true;
  document.getElementById('reader').classList.add('immersive');
  reflowImmediate();   // 隐藏上下栏后，立即按新阅读区重新分页铺满
}
function showChrome() {
  chromeHidden = false;
  document.getElementById('reader').classList.remove('immersive');
  reflowImmediate();
}
// 翻页动画（多种效果 + 可调速度，仅章内翻页）
function animateFlip(dir, apply) {
  let fx = settings.flip_effect || 'flip';
  if (isKindle || MODE === 'scroll') fx = 'none';   // Kindle 墨水屏/滚动模式不需要翻页动画
  if (fx === 'none') { apply(); return; }
  const stage = document.getElementById('flip-stage');
  const view = document.getElementById('page-view');
  const paged = document.getElementById('paged');
  if (!stage || !paged || !view) { apply(); return; }
  const W = view.clientWidth, H = view.clientHeight;
  const dur = settings.flip_speed || 380;
  stage.innerHTML = '';
  const sheet = document.createElement('div');
  sheet.className = 'sheet';
  // ★ 只抄 backgroundColor 的话，羊皮纸/牛皮纸这类有纹理的主题翻页时会闪出一张纯色纸；
  //   backgroundImage 也一起抄过去（渐变是按元素自身尺寸铺的，视觉上一致）。
  const _bs = getComputedStyle(document.body);
  sheet.style.backgroundColor = _bs.backgroundColor;
  sheet.style.backgroundImage = _bs.backgroundImage;
  const win = document.createElement('div');
  win.className = 'win';
  const clone = paged.cloneNode(true);
  clone.style.transform = 'translateX(' + (-curPage * W) + 'px)';
  clone.style.transition = 'none';
  win.appendChild(clone);
  sheet.appendChild(win);
  stage.appendChild(sheet);
  stage.style.display = 'block';
  apply();
  raf(() => {
    sheet.style.transition = `transform ${dur}ms ease-in-out, opacity ${dur}ms ease`;
    if (fx === 'slide') {
      sheet.style.transform = 'translateX(' + (dir > 0 ? '-100%' : '100%') + ')';
    } else if (fx === 'fade') {
      sheet.style.opacity = '0';
      sheet.style.transform = 'scale(1.05)';
    } else if (fx === 'curl') {
      sheet.style.transformOrigin = dir > 0 ? 'left center' : 'right center';
      sheet.style.transform = `rotateY(${dir > 0 ? '-112deg' : '112deg'}) scale(0.97)`;
      sheet.style.opacity = '0.35';
      sheet.style.boxShadow = dir > 0 ? '-50px 0 70px rgba(0,0,0,.4)' : '50px 0 70px rgba(0,0,0,.4)';
    } else { // flip
      sheet.style.transformOrigin = dir > 0 ? 'left center' : 'right center';
      sheet.style.transform = `rotateY(${dir > 0 ? '-96deg' : '96deg'})`;
      sheet.style.opacity = '0.45';
    }
  });
  setTimeout(() => { stage.style.display = 'none'; stage.innerHTML = ''; }, dur + 30);
}
function prevChapter() { flip(-1); }
function nextChapter() { flip(1); }

function pagePad() { return { '100%': 10, '92%': 24, '80%': 40 }[settings.page_width] || 24; }

function ensurePaged() {
  if (!document.getElementById('page-view')) {
    document.getElementById('r-content').innerHTML = '<div id="page-view"><div id="paged"></div></div>';
  }
  return document.getElementById('page-view');
}

// 滚动模式的 class 切换：html.scroll-read（整页滚动）+ #reader.scroll-mode
function applyModeClass() {
  const on = MODE === 'scroll' && isFlowable();
  document.documentElement.classList.toggle('scroll-read', on);
  const r = document.getElementById('reader');
  if (r) r.classList.toggle('scroll-mode', MODE === 'scroll');
}

// 滚动模式布局用内联样式强制生效——不依赖 CSS 规则，Kindle 旧内核也必定生效
function applyScrollLayout() {
  const view = document.getElementById('page-view');
  const paged = document.getElementById('paged');
  if (!view || !paged) return;
  view.style.position = 'static';
  view.style.overflow = 'visible';
  paged.style.height = 'auto';
  paged.style.columnCount = 'auto';
  paged.style.columnWidth = 'auto';
  paged.style.paddingTop = '20px';
  paged.style.paddingLeft = '24px';
  paged.style.paddingRight = '24px';
  paged.style.paddingBottom = Math.round(window.innerHeight * 0.42) + 'px';
  const ch = document.getElementById('chapter-html') || document.getElementById('txt-content');
  if (ch) { ch.style.columnWidth = 'auto'; ch.style.columnCount = 'auto'; }
}
function clearScrollLayout() {
  const view = document.getElementById('page-view');
  const paged = document.getElementById('paged');
  if (view) { view.style.position = ''; view.style.overflow = ''; }
  if (paged) {
    paged.style.height = ''; paged.style.columnCount = ''; paged.style.columnWidth = '';
    paged.style.paddingTop = ''; paged.style.paddingLeft = '';
    paged.style.paddingRight = ''; paged.style.paddingBottom = '';
  }
  const ch = document.getElementById('chapter-html') || document.getElementById('txt-content');
  if (ch) { ch.style.columnWidth = ''; ch.style.columnCount = ''; }
}

function renderPaged(html) {
  ensurePaged();
  document.getElementById('paged').innerHTML = html;
  applyHighlightMarks();
  if (MODE === 'scroll') applyScrollLayout();
  raf(() => {
    if (MODE === 'scroll') {
      // 滚动模式：不做多栏分页，整页纵向流动，按需恢复滚动位置
      const rf = resumeScrollFrac;   // 立刻消费：短章节（maxTop=0）若不消费会把恢复位置泄漏到下一章
      resumeScrollFrac = null;
      const pp = pendingPage;
      pendingPage = 0;
      // 章节高度要等内容/图片/字体布局稳定，按比例多次修正，避免恢复到错误位置
      const applyFrac = (f) => { const mt = docMaxTop(); if (mt > 0) scrollToY(f * mt); };
      if (pp === 'last') {
        const toBottom = () => scrollToY(docMaxTop());
        toBottom(); setTimeout(toBottom, 300); setTimeout(toBottom, 900);
      } else if (rf != null) {
        const f = Math.max(0, Math.min(1, rf));
        applyFrac(f);
        setTimeout(() => applyFrac(f), 300);
        setTimeout(() => applyFrac(f), 900);
      } else {
        scrollToY(0);
      }
      committedIdx = curIdx;
      markToc();
      const cb = afterPaginate; afterPaginate = null;
      rendering = false;
      const pd = pendingFlipDir; pendingFlipDir = 0;
      if (cb) cb();
      if (pd) doFlip(pd);
      saveProg();
      return;
    }
    paginate();
    // 多栏分页失效检测：内容较多却只算出 1 页 → 浏览器不支持 CSS 多栏（如 Kindle 旧内核），自动转滚动模式
    if (pagesInChapter <= 1 && textLen(document.getElementById('paged')) > 2200) {
      setMode('scroll');
      applyModeClass();
      rendering = false;
      pendingFlipDir = 0;
      renderAt(curIdx, 0);
      return;
    }
    let p = pendingPage; pendingPage = 0;
    if (p === 'last') p = pagesInChapter - 1;
    else if (pendingFrac != null && pagesInChapter > 0) {
      // 跨设备恢复：用章节内比例映射到本设备页码
      p = Math.round(Math.min(1, Math.max(0, pendingFrac)) * Math.max(0, pagesInChapter - 1));
      pendingFrac = null;
    }
    if (p == null) p = curPage;
    curPage = Math.max(0, Math.min(p, pagesInChapter - 1));
    committedIdx = curIdx;   // 章节渲染完成，idx 与 page 同步提交
    gotoPage(curPage);
    markToc();
    const cb = afterPaginate; afterPaginate = null;
    rendering = false;
    const pd = pendingFlipDir; pendingFlipDir = 0;
    if (cb) cb();
    if (pd) doFlip(pd);   // 处理加载期间暂存的翻页，防止连点跳章节
  });
}
function paginateInto(innerEl, html, W, H) {
  const P = pagePad();
  const colW = Math.max(120, W - P * 2);
  innerEl.innerHTML = html;
  innerEl.style.padding = '14px ' + P + 'px';
  innerEl.style.columnWidth = colW + 'px';
  innerEl.style.columnGap = (P * 2) + 'px';
  innerEl.style.height = H + 'px';
  innerEl.style.columnFill = 'auto';
  innerEl.querySelectorAll('img').forEach(im => { im.style.maxWidth = colW + 'px'; im.style.height = 'auto'; });
  return Math.max(1, Math.round(innerEl.scrollWidth / W));
}
function paginate() {
  if (MODE === 'scroll') { pagesInChapter = 1; return; }
  const view = document.getElementById('page-view');
  const paged = document.getElementById('paged');
  const W = view.clientWidth || window.innerWidth;
  const H = view.clientHeight || (window.innerHeight - 100);
  pagesInChapter = paginateInto(paged, paged.innerHTML, W, H);
}
function countPages(html) {
  if (MODE === 'scroll') return 1;
  const view = document.getElementById('page-view');
  const W = (view && view.clientWidth) || window.innerWidth;
  const H = (view && view.clientHeight) || (window.innerHeight - 100);
  const m = document.getElementById('measure');
  if (!m) return 1;
  m.style.width = W + 'px';
  m.style.height = H + 'px';
  return paginateInto(document.getElementById('measure-inner'), html, W, H);
}
function gotoPage(p) {
  if (MODE === 'scroll') return;   // 滚动模式不按页滚动
  curPage = Math.max(0, Math.min(pagesInChapter - 1, p));
  committedPage = curPage;   // 页码同步提交
  const view = document.getElementById('page-view');
  const W = view.clientWidth || window.innerWidth;
  view.scrollLeft = curPage * W;
  ensureVisibleImages();   // 兜底：多栏横向滚动下 lazy 可能不触发，强制加载可见页图片
  saveProg();   // 立即保存，避免刷新/退出时丢进度
}
// 强制加载当前可见栏附近的图片（解决 CSS 多栏横向滚动下 loading=lazy 不触发的问题）
function ensureVisibleImages() {
  const view = document.getElementById('page-view');
  const paged = document.getElementById('paged');
  if (!view || !paged) return;
  const W = view.clientWidth || window.innerWidth;
  const left = view.scrollLeft || 0;
  paged.querySelectorAll('img[loading="lazy"]').forEach(im => {
    const r = im.getBoundingClientRect();
    if (r.left >= left - W && r.left <= left + W * 2) {
      im.loading = 'eager';
    }
  });
}
function globalPage() { return (pageOffset[curIdx] || 0) + curPage; }  // 0-based 全书页码
function computePct() {
  if (KIND === 'pdf') return total ? pdfPage / total * 100 : 0;
  if (MODE === 'scroll') return total ? Math.min(100, (curIdx + scrollFrac()) / total * 100) : 0;
  if (pageMapReady && totalPages > 0) return Math.min(100, (globalPage() + 1) / totalPages * 100);
  if (!total) return 0;
  return Math.min(100, (curIdx + (pagesInChapter > 1 ? curPage / pagesInChapter : 0)) / total * 100);
}
function updateProgUI() {
  let pct = Math.round(computePct());
  if (KIND === 'pdf') {
    document.getElementById('r-prog').textContent = `第 ${pdfPage}/${total} 页 · ${pct}%`;
  } else if (pageMapReady && totalPages > 0) {
    document.getElementById('r-prog').textContent = `第 ${globalPage() + 1}/${totalPages} 页 · ${pct}%`;
  } else if (total) {
    document.getElementById('r-prog').textContent = `第 ${curIdx + 1}/${total} 章 · ${pct}%`;
  } else {
    pct = 0;
    document.getElementById('r-prog').textContent = '0%';
  }
  setProgressFill(pct);
}
function setProgressFill(pct) {
  const fill = document.getElementById('r-progressbar-fill');
  const thumb = document.getElementById('r-progressbar-thumb');
  if (fill) fill.style.width = pct + '%';
  if (thumb) thumb.style.left = pct + '%';
}
function saveProg() {
  const pct = Math.round(computePct());
  updateProgUI();
  saveProgress(currentPosition(), pct);
}
function flushSave() {
  saveProgress(currentPosition(), Math.round(computePct()), true);
}
// 周期自动保存（兜底）：Kindle 等设备 pagehide/beforeunload 可能不触发，
// 部分老内核甚至不派发 scroll 事件，所以阅读期间定时检查位置并保存。
// 滚动模式位置连续变化，轮询间隔更短，保证进度不丢。
let _autoSaveT = null, _lastSig = '';
function startAutoSave() {
  if (_autoSaveT) return;
  const tick = () => {
    _autoSaveT = setTimeout(tick, MODE === 'scroll' ? 4000 : 8000);
    if (!KIND || rendering) return;
    try {
      const sig = JSON.stringify(currentPosition()) + '|' + Math.round(computePct());
      if (sig !== _lastSig) { _lastSig = sig; saveProg(); }
    } catch (e) {}
  };
  tick();
}
// 滚动模式：整页滚动时（防抖）保存进度
let _svt = null, _svAttached = false;
function attachScrollSave() {
  if (_svAttached) return;
  _svAttached = true;
  const onScroll = () => {
    committedIdx = curIdx;
    clearTimeout(_svt);
    _svt = setTimeout(() => { saveProg(); }, 250);
  };
  // 滚动可能发生在视口，也可能在 body / 内层容器上（各内核不同），全部监听；
  // 元素上的 scroll 事件不冒泡，document 必须用 capture 才能收到
  const opt = { passive: true };
  try { window.addEventListener('scroll', onScroll, opt); } catch (e) { window.addEventListener('scroll', onScroll); }
  try { document.addEventListener('scroll', onScroll, { passive: true, capture: true }); }
  catch (e) { document.addEventListener('scroll', onScroll, true); }
  ['page-view', 'r-content'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('scroll', onScroll, opt);
  });
}
// 阅读时长心跳：每 30 秒上报一次有效阅读时长（登录用户 + 页面可见 + 非渲染中才累计）
let _readingT = null;
function startReadingTimer() {
  if (_readingT || SHARE) return;        // 分享阅读：不计阅读时长

  const tick = () => {
    _readingT = setTimeout(tick, 30000);
    if (!TOKEN || !KIND) return;
    if (document.visibilityState !== 'visible') return;
    if (rendering) return;
    try {
      fetch('/api/reading/heartbeat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + TOKEN },
        // book_id / kind：供后台统计沉淀（用户日/周/月时长、书籍阅读人数与次数），只存不展示
        body: JSON.stringify({ seconds: 30, book_id: parseInt(BID, 10) || 0,
                               kind: MD ? 'md' : (KIND || '') })
      }).catch(() => {});
    } catch (e) {}
  };
  tick();
}

// ---------- 全书页码地图（总页数/进度条） ----------
// 章节 HTML 缓存（LRU）：翻页返回秒开，避免重复请求与重复分栏渲染
const CHAPTER_CACHE_MAX = 16;
const chapterCache = new Map();
async function fetchChapterHtml(i) {
  const hit = chapterCache.get(i);
  if (hit !== undefined) {
    chapterCache.delete(i); chapterCache.set(i, hit);   // 刷新最近使用
    return hit;
  }
  const html = await fetch(`/api/books/${BID}/chapter?idx=${i}&t=${encodeURIComponent(mediaTicket)}`, { headers: TOKEN ? { Authorization: 'Bearer ' + TOKEN } : {} }).then(r => r.text());
  chapterCache.set(i, html);
  if (chapterCache.size > CHAPTER_CACHE_MAX) {
    chapterCache.delete(chapterCache.keys().next().value);
  }
  return html;
}
// 无缓存直连（buildPageMap 预取用，避免污染翻页缓存）
async function fetchChapterHtmlRaw(i) {
  return fetch(`/api/books/${BID}/chapter?idx=${i}&t=${encodeURIComponent(mediaTicket)}`, { headers: TOKEN ? { Authorization: 'Bearer ' + TOKEN } : {} }).then(r => r.text());
}
let txtAll = null;
async function getTxtAll() {
  if (txtAll) return txtAll;
  const r = await api(`/api/books/${BID}/txt-batch`);
  txtAll = r.chunks || [];
  return txtAll;
}
async function buildPageMap() {
  if (MODE === 'scroll') { pageMapReady = false; totalPages = 0; return; }   // 滚动模式无分页，进度按章节比例
  if (KIND === 'pdf') {
    pageCounts = new Array(total).fill(1);
    pageOffset = new Array(total);
    let acc = 0;
    for (let i = 0; i < total; i++) { pageOffset[i] = acc; acc += 1; }
    totalPages = total; pageMapReady = true; updateProgUI(); return;
  }
  if (!isFlowable()) return;
  if (!total) return;
  const token = ++mapToken;
  const N = total;
  pageCounts = new Array(N).fill(1);
  pageOffset = new Array(N).fill(0);
  let acc = 0, chunks = null;
  for (let i = 0; i < N; i++) {
    if (token !== mapToken) return;
    let n = 1;
    try {
      if (KIND === 'txt') {
        if (!chunks) chunks = await getTxtAll();
        const c = chunks[i];
        n = c ? countPages('<div id="txt-content"' + (MD ? ' class="md"' : '') + '>' + contentHtml(c.text) + '</div>') : 1;
      } else {
        n = countPages('<div id="chapter-html">' + await fetchChapterHtmlRaw(i) + '</div>');
      }
    } catch (e) { n = 1; }
    pageCounts[i] = n;
    pageOffset[i] = acc;
    acc += n;
    // 每章让出主线程（setTimeout 0），后台建图不阻塞用户翻页/渲染
    await new Promise(r => setTimeout(r, 0));
    if (i % 5 === 0 || i === N - 1) {
      totalPages = acc; updateProgUI();
    }
  }
  if (token !== mapToken) return;
  totalPages = acc; pageMapReady = true; updateProgUI();
}
function chapterOfPage(g) {
  for (let i = total - 1; i >= 0; i--) if ((pageOffset[i] || 0) <= g) return i;
  return 0;
}
function jumpToGlobalPage(g) {
  if (KIND === 'pdf') { pdfGoto(g + 1); return; }
  if (!isFlowable()) return;
  pendingFlipDir = 0;
  g = Math.max(0, Math.min((totalPages || 1) - 1, g));
  const i = chapterOfPage(g);
  const p = g - (pageOffset[i] || 0);
  renderAt(i, p);
}
function initProgressDrag() {
  const bar = document.getElementById('r-progressbar');
  if (!bar || MODE === 'scroll') return;   // 滚动模式进度条仅作显示，不支持拖拽跳页
  let dragging = false;
  const pctFrom = e => {
    const r = bar.getBoundingClientRect();
    return r.width ? Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)) : 0;
  };
  const preview = p => {
    setProgressFill(Math.round(p * 100));
    let txt = '';
    if (KIND === 'pdf') txt = `第 ${Math.max(1, Math.round(p * total))}/${total} 页`;
    else if (pageMapReady && totalPages) txt = `第 ${Math.max(1, Math.round(p * totalPages))}/${totalPages} 页`;
    else if (total) txt = `第 ${Math.max(1, Math.round(p * total))}/${total} 章`;
    document.getElementById('r-prog').textContent = txt;
  };
  const commit = p => {
    if (KIND === 'pdf') { pdfGoto(Math.max(1, Math.round(p * total))); return; }
    if (pageMapReady && totalPages) { jumpToGlobalPage(Math.round(p * totalPages) - 1); return; }
    if (total) {
      const i = Math.min(total - 1, Math.floor(p * total));
      renderAt(i, 0);
    }
  };
  bar.addEventListener('pointerdown', e => {
    dragging = true; bar.classList.add('dragging');
    try { bar.setPointerCapture(e.pointerId); } catch (err) {}
    preview(pctFrom(e)); e.preventDefault();
  });
  bar.addEventListener('pointermove', e => { if (dragging) preview(pctFrom(e)); });
  bar.addEventListener('pointerup', e => {
    if (!dragging) return;
    dragging = false; bar.classList.remove('dragging');
    commit(pctFrom(e));
  });
  bar.addEventListener('pointercancel', () => { dragging = false; bar.classList.remove('dragging'); });
}
// ---------- 注释/链接点击处理（避免版面错乱） ----------
function locateEl(el) {
  const paged = document.getElementById('paged');
  const view = document.getElementById('page-view');
  if (!paged || !el) return;
  if (MODE === 'scroll') {
    scrollToY(el.getBoundingClientRect().top + wY() - 60);   // 滚动模式：整页滚动到锚点
    saveProg();
    return;
  }
  const W = view.clientWidth || window.innerWidth;
  const col = Math.floor((el.getBoundingClientRect().left - paged.getBoundingClientRect().left) / W);
  if (col >= 0 && col < pagesInChapter) gotoPage(col);
}
function initLinkHandler() {
  document.getElementById('r-content').addEventListener('click', e => {
    const a = e.target.closest('a');
    if (!a) return;
    const href = (a.getAttribute('href') || '').trim();
    e.preventDefault();
    e.stopPropagation();
    if (!href) return;
    // 1) 纯锚点：同章节内跳转
    if (href.startsWith('#')) {
      const t = document.getElementById(decodeURIComponent(href.slice(1)));
      if (t) locateEl(t);
      return;
    }
    // 2) 外部链接
    if (/^https?:\/\//i.test(href) || href.startsWith('data:') || href.startsWith('mailto:')) {
      if (/^https?:\/\//i.test(href)) window.open(href, '_blank');
      return;
    }
    // 3) 书内跨章节链接：relative.xhtml#anchor（目录/脚注/内部引用）
    const hashIdx = href.indexOf('#');
    const clean = (hashIdx >= 0 ? href.slice(0, hashIdx) : href).split('?')[0];
    const frag = hashIdx >= 0 ? href.slice(hashIdx + 1) : '';
    const target = resolveChapterHref(clean);
    if (target >= 0) jumpToChapterFragment(target, frag);
  });
}
function normPath(p) {
  const parts = [];
  for (const seg of String(p || '').split('/')) {
    if (!seg || seg === '.') continue;
    if (seg === '..') { parts.pop(); continue; }
    parts.push(seg);
  }
  return parts.join('/');
}
function resolveChapterHref(rel) {
  if (!rel) return -1;
  const normRel = normPath(rel);
  const hrefs = TOC.map(c => normPath(c.href || ''));
  // 1) 精确匹配完整路径
  let i = hrefs.indexOf(normRel);
  if (i >= 0) return i;
  // 2) 相对当前章节目录解析
  const cur = (TOC[curIdx] || {}).href || '';
  const base = cur.includes('/') ? cur.slice(0, cur.lastIndexOf('/') + 1) : '';
  const full = normPath(base + rel);
  i = hrefs.indexOf(full);
  if (i >= 0) return i;
  // 3) 按文件名兜底（忽略目录差异）
  const leaf = normRel.split('/').pop().toLowerCase();
  if (leaf) {
    for (let k = 0; k < TOC.length; k++) {
      if (hrefs[k].split('/').pop().toLowerCase() === leaf) return k;
    }
  }
  return -1;
}
function findFragmentEl(frag) {
  if (!frag) return null;
  const keys = [frag];
  try { keys.push(decodeURIComponent(frag)); } catch (e) {}
  for (const k of keys) {
    if (!k) continue;
    const el = document.getElementById(k);
    if (el) return el;
    const named = document.getElementsByName(k);
    if (named && named.length) return named[0];
  }
  return null;
}
function jumpToChapterFragment(idx, frag) {
  if (idx < 0 || idx >= total) return;
  pendingFlipDir = 0;
  // 目标就是当前章节：直接定位锚点/回页首，无需重新渲染
  if (idx === curIdx && !rendering) {
    const t = findFragmentEl(frag);
    if (t) { locateEl(t); return; }
    gotoPage(0);
    return;
  }
  afterPaginate = () => {
    const t = findFragmentEl(frag);
    if (t) locateEl(t);
    else gotoPage(0);
  };
  renderAt(idx, 0);
}

// ---------- epub ----------
async function initEpub() {
  const t = await api('/api/books/' + BID + '/toc');
  TOC = t.chapters; total = TOC.length;
  if (!total) { document.getElementById('r-content').innerHTML = '<div class="empty">无内容</div>'; return; }
  renderToc();
  const prog = await loadProgress();
  const FRESH = new URLSearchParams(location.search).get('fresh');
  const IDX = parseInt(new URLSearchParams(location.search).get('idx') || '');
  const POS = parseFloat(new URLSearchParams(location.search).get('pos') || '');
  const LOCATE = decodeURIComponent(new URLSearchParams(location.search).get('locate') || '');
  let start = 0, page = 0, frac = null;
  if (!isNaN(IDX) && IDX >= 0) {
    // 从「笔记」页跳转：idx 指定章节，pos 指定章内比例（0..1）。
    // 书签没有可检索的文字，只能靠 pos 才能在章内精确定位。
    start = IDX; page = 0;
    if (!isNaN(POS)) {
      const pf = Math.max(0, Math.min(1, POS));
      if (MODE === 'scroll') resumeScrollFrac = pf; else frac = pf;
    }
  }
  else if (!FRESH && prog.progress && prog.progress.kind === 'epub') {
    start = prog.progress.idx || 0;
    // 同设备同模式才用精确 page/scroll；跨设备或换模式一律用设备无关的 frac 比例
    const sameDev = prog.progress.dev != null && prog.progress.dev === DEV && prog.progress.mode === MODE;
    const pf = (prog.progress.frac != null) ? prog.progress.frac : null;
    if (MODE === 'scroll') {
      if (sameDev && prog.progress.scroll != null) resumeScrollFrac = prog.progress.scroll;
      else if (pf != null) resumeScrollFrac = pf;
      else if (prog.progress.scroll != null) resumeScrollFrac = prog.progress.scroll;
    } else {
      if (sameDev) { page = prog.progress.page || 0; }
      else if (pf != null) { frac = pf; page = 0; }
      else { page = prog.progress.page || 0; }
    }
    if (prog.progress.scroll != null) savedScroll = prog.progress.scroll;
  }
  // 新书 / 从头读：默认从第一页（封面）开始，不再跳到正文
  curIdx = Math.min(start, total - 1);
  committedIdx = curIdx; committedPage = page;   // 先按恢复位置提交，渲染完成后再精确提交
  if (LOCATE) afterPaginate = () => locateParagraph(LOCATE);
  await renderChapter(curIdx, page, frac);
  buildPageMap();
  startAutoSave();
  if (MODE === 'scroll') attachScrollSave();
}
async function renderChapter(i, page, frac) {
  const token = ++renderToken;
  rendering = true;
  curIdx = i;
  pendingPage = (page == null ? 0 : page);
  pendingFrac = (frac == null ? null : frac);
  try {
    const html = await fetchChapterHtml(i);   // 命中缓存时翻页秒开
    if (token !== renderToken) return;   // 过期渲染，丢弃
    renderPaged('<div id="chapter-html">' + html + '</div>');
  } catch (e) {
    if (token === renderToken) { rendering = false; pendingFlipDir = 0; }
  }
}
// 统一章节渲染分发：txt/docx/md 走 txt 分段接口，epub/mobi 走章节接口
// （漏判会把 txt/md 送到 /chapter 接口，返回 400「请用 txt 接口读取」）
function renderAt(i, page, frac) {
  if (KIND === 'txt') return renderTxtChunk(i, page, frac);
  return renderChapter(i, page, frac);
}

// ---------- txt ----------
async function initTxt() {
  const t = await api('/api/books/' + BID + '/toc');
  TOC = t.chapters; total = TOC.length;
  renderToc();
  const prog = await loadProgress();
  const FRESH = new URLSearchParams(location.search).get('fresh');
  const IDX = parseInt(new URLSearchParams(location.search).get('idx') || '');
  const POS = parseFloat(new URLSearchParams(location.search).get('pos') || '');
  const LOCATE = decodeURIComponent(new URLSearchParams(location.search).get('locate') || '');
  let start = 0, page = 0, frac = null;
  if (!isNaN(IDX) && IDX >= 0) {
    // 从「笔记」页跳转：idx 指定章节，pos 指定章内比例（0..1）
    start = IDX; page = 0;
    if (!isNaN(POS)) {
      const pf = Math.max(0, Math.min(1, POS));
      if (MODE === 'scroll') resumeScrollFrac = pf; else frac = pf;
    }
  }
  else if (!FRESH && prog.progress && prog.progress.kind === 'txt') {
    start = prog.progress.idx || 0;
    // 同设备同模式才用精确 page/scroll；跨设备或换模式一律用设备无关的 frac 比例
    const sameDev = prog.progress.dev != null && prog.progress.dev === DEV && prog.progress.mode === MODE;
    const pf = (prog.progress.frac != null) ? prog.progress.frac : null;
    if (MODE === 'scroll') {
      if (sameDev && prog.progress.scroll != null) resumeScrollFrac = prog.progress.scroll;
      else if (pf != null) resumeScrollFrac = pf;
      else if (prog.progress.scroll != null) resumeScrollFrac = prog.progress.scroll;
    } else {
      if (sameDev) { page = prog.progress.page || 0; }
      else if (pf != null) { frac = pf; page = 0; }
      else { page = prog.progress.page || 0; }
    }
    if (prog.progress.scroll != null) savedScroll = prog.progress.scroll;
  }
  curIdx = Math.min(start, Math.max(0, total - 1));
  committedIdx = curIdx; committedPage = page;
  if (LOCATE) afterPaginate = () => locateParagraph(LOCATE);
  await renderTxtChunk(curIdx, page, frac);
  buildPageMap();
  startAutoSave();
  if (MODE === 'scroll') attachScrollSave();
}
async function renderTxtChunk(i, page, frac) {
  const token = ++renderToken;
  rendering = true;
  curIdx = i;
  pendingPage = (page == null ? 0 : page);
  pendingFrac = (frac == null ? null : frac);
  try {
    const c = await api(`/api/books/${BID}/txt?idx=${i}`);
    if (token !== renderToken) return;
    renderPaged('<div id="txt-content"' + (MD ? ' class="md"' : '') + '>' + contentHtml(c.text) + '</div>');
  } catch (e) {
    if (token === renderToken) { rendering = false; pendingFlipDir = 0; }
  }
}
function txtToHtml(text) {
  return String(text || '').split(/\r?\n/).map(l => {
    const t = l.replace(/\s+$/, '');
    return t ? '<p>' + esc(t) + '</p>' : '<p><br></p>';
  }).join('');
}
// md 的 text 已是后端渲染的 HTML，直接使用；txt/docx 仍走纯文本转段落
function contentHtml(text) { return MD ? mdWrapTables(text) : txtToHtml(text); }

/* Markdown 表格一律套一层 .md-tw 容器：
   · 手机上窄屏时表格可以左右拖看，不再压到相邻一栏（分页模式尤其明显）；
   · 表格整体尽量不跨栏被切断。
   用正则而不是建临时 DOM：后端 python-markdown 输出的表格不会嵌套，一章渲染一次，正则更省。 */
function mdWrapTables(html) {
  const s = String(html || '');
  if (s.indexOf('<table') < 0 || s.indexOf('class="md-tw"') >= 0) return s;  // 没表格 / 已处理过，别叠套
  return s.replace(/<table[\s\S]*?<\/table>/gi, m => '<div class="md-tw">' + m + '</div>');
}

// ---------- html ----------
async function initHtml() {
  document.getElementById('r-content').innerHTML = `<iframe src="/api/books/${BID}/file${tokenQS()}" style="width:100%;height:100%;border:none"></iframe>`;
  document.getElementById('r-bottom').style.display = 'none';
}

// ---------- pdf ----------
let pdfjs = null;
function loadPdfLib() {
  return new Promise((res, rej) => {
    if (window.pdfjsLib) return res();
    const s = document.createElement('script');
    s.src = '/static/vendor/pdf.min.js';
    s.onload = () => res();
    s.onerror = () => rej(new Error('pdf.js 加载失败'));
    document.head.appendChild(s);
  });
}
async function initPdf() {
  try {
    await loadPdfLib();
    pdfjs = window.pdfjsLib;
    pdfjs.GlobalWorkerOptions.workerSrc = '/static/vendor/pdf.worker.min.js';
    document.getElementById('r-content').innerHTML = '<div id="pdf-wrap"></div>';
    const url = `/api/books/${BID}/file${tokenQS()}`;
    pdfDoc = await pdfjs.getDocument(url).promise;
    total = pdfDoc.numPages;
    renderToc();
    const prog = await loadProgress();
    if (prog.progress && prog.progress.kind === 'pdf') pdfPage = Math.min(total, Math.max(1, prog.progress.page || 1));
    await renderPdfPage();
    buildPageMap();
    startAutoSave();
  } catch (e) {
    document.getElementById('r-content').innerHTML = `<div class="empty">PDF 加载失败：${e.message}<br><a href="/api/books/${BID}/file${tokenQS()}">直接打开</a></div>`;
  }
}
async function renderPdfPage() {
  const wrap = document.getElementById('pdf-wrap');
  wrap.innerHTML = '<p class="muted">加载中…</p>';
  const page = await pdfDoc.getPage(pdfPage);
  const vp1 = page.getViewport({ scale: 1 });
  const containerWidth = Math.min(wrap.clientWidth - 20, 720);
  pdfScale = containerWidth / vp1.width;
  const vp = page.getViewport({ scale: pdfScale });
  const canvas = document.createElement('canvas');
  canvas.width = vp.width; canvas.height = vp.height;
  wrap.innerHTML = '';
  wrap.appendChild(canvas);
  await page.render({ canvasContext: canvas.getContext('2d'), viewport: vp }).promise;
  updateProgUI();
  saveProgress({ kind: 'pdf', page: pdfPage }, pdfPage / total * 100);
  markToc();
}
function pdfGoto(n) {
  if (!pdfDoc) return;
  n = Math.max(1, Math.min(total, n));
  if (n === pdfPage) return;
  pdfPage = n; renderPdfPage();
}

// ---------- 目录/设置/搜索 ----------
function renderToc() {
  const list = document.getElementById('toc-list');
  const bms = notesData.bookmarks || [];
  let bmHtml = '';
  if (bms.length) {
    bmHtml = `<div style="padding:4px 0 10px;border-bottom:1px solid #eee;margin-bottom:6px">
      <div style="font-weight:700;color:#4a6cf7;font-size:13px;margin-bottom:4px">书签（${bms.length}）</div>
      ${bms.map(m => {
        const f = (typeof m.frac === 'number' && isFinite(m.frac)) ? m.frac : 'null';
        return `<div class="toc-item bm" onclick="gotoBookmark(${m.idx || 0}, ${m.page || 0}, ${f})">🔖 ${esc(m.label || m.chapter || '书签')}</div>`;
      }).join('')}
    </div>`;
  }
  if (!TOC.length) { list.innerHTML = bmHtml + '<p class="muted">无目录</p>'; return; }
  const items = TOC.map((c, i) => ({ c, i })).filter(x => !x.c.front);
  if (!items.length) { list.innerHTML = bmHtml + '<p class="muted">无目录</p>'; return; }
  list.innerHTML = bmHtml + items.map(x => {
    const pad = 10 + (x.c.level || 0) * 14;
    return `<div class="toc-item" style="padding-left:${pad}px" data-i="${x.i}" onclick="gotoToc(${x.i})">${esc(x.c.title || ('第' + (x.i + 1) + '节'))}</div>`;
  }).join('');
}
function gotoBookmark(idx, page, frac) {
  closeDrawers();
  pendingFlipDir = 0;
  idx = idx || 0;
  const f = (typeof frac === 'number' && isFinite(frac)) ? Math.max(0, Math.min(1, frac)) : null;
  if (KIND === 'pdf') { pdfGoto(idx + 1); return; }
  // 滚动模式：书签存的是章节内比例，按比例滚到对应位置（page 在滚动模式下无意义）
  if (MODE === 'scroll') {
    if (idx === curIdx && !rendering) {
      const mt = docMaxTop();
      scrollToY(f != null && mt > 0 ? f * mt : 0);
      saveProg();
      return;
    }
    if (f != null) resumeScrollFrac = f;   // 先记下，渲染完成后由 renderPaged 按比例定位
    renderAt(idx, 0);
    return;
  }
  // 分页模式：同章直接翻到对应页，跨章用比例映射到本设备页码
  if (idx === curIdx && !rendering) {
    if (f != null && pagesInChapter > 1) gotoPage(Math.round(f * (pagesInChapter - 1)));
    else gotoPage(0);
    return;
  }
  renderAt(idx, 0, f);
}
function gotoToc(i) {
  closeDrawers();
  pendingFlipDir = 0;   // 显式跳转覆盖暂存翻页
  if (KIND === 'pdf') pdfGoto(i + 1);
  else if (KIND === 'txt') renderTxtChunk(i, 0);
  else {
    const frag = (TOC[i] && TOC[i].fragment) || '';
    jumpToChapterFragment(i, frag);   // 跳到章节并定位到目录锚点（章节内具体位置）
  }
}
function markToc() {
  document.querySelectorAll('.toc-item').forEach(x => x.classList.toggle('active', parseInt(x.dataset.i) === curIdx));
}
function scrollTocToCurrent() {
  const active = document.querySelector('.toc-item.active');
  if (active) active.scrollIntoView({ block: 'center' });
}
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function toast(msg) {
  let el = document.getElementById('r-toast');
  if (!el) {
    el = document.createElement('div');
    el.id = 'r-toast';
    el.style.cssText = 'position:fixed;top:56px;left:50%;transform:translateX(-50%);background:rgba(31,36,48,.9);color:#fff;padding:8px 16px;border-radius:20px;font-size:13px;z-index:300;pointer-events:none;transition:opacity .3s';
    document.body.appendChild(el);
  }
  el.textContent = msg; el.style.opacity = '1';
  clearTimeout(el._t); el._t = setTimeout(() => { el.style.opacity = '0'; }, 2000);
}

// ---------- 内容搜索 ----------
async function doSearch() {
  const q = document.getElementById('search-q').value.trim();
  const wrap = document.getElementById('search-results');
  if (!q) { wrap.innerHTML = ''; return; }
  lastQuery = q;
  recordSearch(q);
  wrap.innerHTML = '<p class="muted">搜索中…</p>';
  try {
    const r = await api(`/api/books/${BID}/search?q=${encodeURIComponent(q)}`);
    if (!r.matches.length) { wrap.innerHTML = `<p class="muted">未找到「${esc(q)}」</p>`; return; }
    wrap.innerHTML = r.matches.map(m =>
      `<div class="sr-item" onclick="jumpToMatch(${m.idx})">
        <div class="st">${esc(m.title)} <span class="muted">(${m.count}处)</span></div>
        <div class="ss">…${esc(m.snippet)}…</div></div>`).join('');
  } catch (e) { wrap.innerHTML = '<p class="muted">' + esc(e.message) + '</p>'; }
}
function jumpToMatch(idx) {
  closeDrawers();
  pendingFlipDir = 0;
  afterPaginate = () => { highlight(lastQuery); locateHighlight(); };
  if (KIND === 'txt') renderTxtChunk(idx, 0);
  else if (KIND === 'pdf') pdfGoto(idx + 1);
  else renderChapter(idx, 0);
}
function highlight(q) {
  if (!q) return;
  const root = document.getElementById('chapter-html') || document.getElementById('txt-content');
  if (!root) return;
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  const nodes = [];
  while (walker.nextNode()) nodes.push(walker.currentNode);
  nodes.forEach(n => {
    const txt = n.nodeValue;
    const idx = txt.toLowerCase().indexOf(q.toLowerCase());
    if (idx >= 0) {
      const mark = document.createElement('mark');
      const parent = n.parentNode;
      if (txt.slice(0, idx)) parent.insertBefore(document.createTextNode(txt.slice(0, idx)), n);
      mark.textContent = txt.slice(idx, idx + q.length);
      parent.insertBefore(mark, n);
      if (txt.slice(idx + q.length)) parent.insertBefore(document.createTextNode(txt.slice(idx + q.length)), n);
      parent.removeChild(n);
    }
  });
}
function locateHighlight() {
  const root = document.getElementById('chapter-html') || document.getElementById('txt-content');
  if (!root) return;
  const m = root.querySelector('mark');
  if (!m) return;
  const paged = document.getElementById('paged');
  const view = document.getElementById('page-view');
  if (!paged || !view) return;
  const W = view.clientWidth || window.innerWidth;
  const col = Math.floor((m.getBoundingClientRect().left - paged.getBoundingClientRect().left) / W);
  if (col >= 0 && col < pagesInChapter) gotoPage(col);
}

// ---------- 笔记（划线/批注/书签，云端同步 WebDAV） ----------
async function loadNotesData() {
  if (SHARE) { notesData = { highlights: [], notes: [], bookmarks: [], searches: [] }; return; }
  try { notesData = await api('/api/notes/' + BID); }
  catch (e) { notesData = { highlights: [], notes: [], bookmarks: [], searches: [] }; }
}
let _notesSaveT = null;
function saveNotes() {
  clearTimeout(_notesSaveT);
  _notesSaveT = setTimeout(() => {
    api('/api/notes/' + BID, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(notesData) }).catch(() => {});
  }, 400);
}
function _curChapter() {
  const c = TOC && TOC[curIdx] ? TOC[curIdx] : null;
  return c ? (c.title || ('第' + (curIdx + 1) + '节')) : '';
}
// 笔记/书签时间统一用北京时间（UTC+8），与后端 db.now() 保持一致。
// toISOString() 取的是 UTC，直接使用会比实际时间少 8 小时（20:00 会显示成 12:00）。
function _now() { return new Date(Date.now() + 8 * 3600 * 1000).toISOString().slice(0, 19).replace('T', ' '); }
function noteGuard() {   // 游客/分享阅读：笔记/书签功能提示注册
  if (SHARE) { toast('分享阅读不保存书签与笔记，注册后可完整使用'); return false; }
  if (TOKEN) return true;
  toast('请注册账号后使用此功能');
  return false;
}
function addHighlight(text, note) {
  if (!noteGuard()) return;
  notesData.highlights = notesData.highlights || [];
  notesData.highlights.unshift({ id: Date.now() + Math.random().toString(36).slice(2, 6), text: text,
                                 chapter: _curChapter(), idx: curIdx, page: committedPage,
                                 frac: chapterFrac(),   // 章内比例：文字定位失败时的位置兜底
                                 note: note || '', created_at: _now() });
  saveNotes(); applyHighlightMarks(); toast(note ? '已保存划线 + 批注' : '已保存划线');
}
function addBookmark() {
  if (!noteGuard()) return;
  notesData.bookmarks = notesData.bookmarks || [];
  const ts = _now();
  // frac：章节内比例（0..1，与阅读模式无关）。滚动模式下 page 恒为 0，
  // 只存 page 会让书签只能定位到章首，所以必须同时记录 frac。
  notesData.bookmarks.unshift({ id: Date.now() + Math.random().toString(36).slice(2, 6), chapter: _curChapter(),
                                idx: curIdx, page: committedPage, frac: chapterFrac(), mode: MODE,
                                label: ts.slice(5, 16) + ' · ' + _curChapter(), created_at: ts });
  saveNotes(); renderToc(); toast('已添加书签');
}
function recordSearch(q) {
  notesData.searches = notesData.searches || [];
  notesData.searches.unshift({ q: q, created_at: _now() });
  notesData.searches = notesData.searches.slice(0, 50);
  saveNotes();
}

// 将当前用户的所有划线在正文中用「下划线 + 淡黄背景」标识（仿 Kindle）
function applyHighlightMarks() {
  const root = document.getElementById('chapter-html') || document.getElementById('txt-content');
  if (!root) return;
  // 清除旧标记（还原文本）
  root.querySelectorAll('mark.hl').forEach(m => {
    const p = m.parentNode;
    p.replaceChild(document.createTextNode(m.textContent), m);
    p.normalize();
  });
  (notesData.highlights || []).forEach(h => {
    const t = String(h.text || '').trim();
    if (t) markText(root, t.slice(0, 40));   // 用开头片段匹配（跨节点选择兼容）
  });
}
function markText(root, text) {
  if (!text) return;
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  const nodes = [];
  while (walker.nextNode()) nodes.push(walker.currentNode);
  for (let k = 0; k < nodes.length; k++) {
    const n = nodes[k];
    const txt = n.nodeValue;
    const idx = txt.indexOf(text);
    if (idx >= 0) {
      const parent = n.parentNode;
      if (parent && parent.closest && parent.closest('mark')) continue;
      const mark = document.createElement('mark');
      mark.className = 'hl';
      mark.textContent = txt.slice(idx, idx + text.length);
      if (txt.slice(0, idx)) parent.insertBefore(document.createTextNode(txt.slice(0, idx)), n);
      parent.insertBefore(mark, n);
      if (txt.slice(idx + text.length)) parent.insertBefore(document.createTextNode(txt.slice(idx + text.length)), n);
      parent.removeChild(n);
      return;   // 仅标记第一处
    }
  }
}
// 定位到划线/批注所在的自然段
function locateParagraph(text) {
  const root = document.getElementById('chapter-html') || document.getElementById('txt-content');
  if (!root || !text) return;
  const key = String(text).slice(0, 20);
  let el = null;
  root.querySelectorAll('mark.hl').forEach(m => { if (!el && m.textContent.indexOf(key) >= 0) el = m; });
  if (!el) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    while (walker.nextNode()) {
      if (walker.currentNode.nodeValue.indexOf(key) >= 0) { el = walker.currentNode; break; }
    }
  }
  if (!el) return;
  const p = el.closest ? (el.closest('p') || el.parentElement) : el.parentElement;
  if (p) locateEl(p);
}

let selText = '';
function _selectionLastRect(sel) {
  try {
    if (!sel || !sel.rangeCount) return null;
    const range = sel.getRangeAt(sel.rangeCount - 1);
    // 多行选区：getClientRects 返回每一行的矩形，取最后一行（末行）矩形
    const rects = range.getClientRects();
    if (rects && rects.length) {
      for (let i = rects.length - 1; i >= 0; i--) {
        const rc = rects[i];
        if (rc && (rc.width > 0 || rc.height > 0)) return rc;
      }
    }
    const b = range.getBoundingClientRect();
    if (b && (b.width > 0 || b.height > 0)) return b;
    // 兜底：用选区焦点所在元素的位置
    const node = sel.focusNode;
    const el = (node && node.nodeType === 1) ? node : (node && node.parentElement);
    if (el && el.getBoundingClientRect) return el.getBoundingClientRect();
    return null;
  } catch (e) { return null; }
}
function checkSelection() {
  const popup = document.getElementById('sel-popup');
  if (!popup) return;
  const sel = window.getSelection();
  const text = sel ? sel.toString().trim() : '';
  if (text && text.length > 1) {
    const r = _selectionLastRect(sel);
    selText = text.slice(0, 500);
    popup.style.display = 'block';
    const left = r ? r.left + r.width / 2 - 60 : window.innerWidth / 2 - 60;
    const top = r ? r.bottom + 8 : window.innerHeight / 2 - 60;
    popup.style.left = Math.max(8, Math.min(window.innerWidth - 150, left)) + 'px';
    popup.style.top = Math.max(8, Math.min(window.innerHeight - 44, top)) + 'px';
  } else {
    popup.style.display = 'none';
  }
}
// 选中文字划线 / 写批注（兼容 Kindle：同时监听 selectionchange / mouseup / touchend）
function initSelectionCapture() {
  const popup = document.createElement('div');
  popup.id = 'sel-popup';
  popup.style.cssText = 'position:fixed;z-index:120;display:none;background:#333a47;color:#fff;border-radius:8px;padding:6px 8px;box-shadow:0 6px 18px rgba(0,0,0,.3);font-size:13px;font-family:sans-serif';
  popup.innerHTML = '<button data-act="hl" style="background:none;border:none;color:#fff;cursor:pointer;padding:4px 10px;font-size:14px">划线</button>'
    + '<button data-act="note" style="background:none;border:none;color:#fff;cursor:pointer;padding:4px 10px;font-size:14px">批注</button>';
  document.body.appendChild(popup);
  document.addEventListener('selectionchange', () => checkSelection());
  document.addEventListener('mouseup', () => setTimeout(checkSelection, 60));
  document.addEventListener('touchend', () => setTimeout(checkSelection, 120));
  popup.addEventListener('click', e => {
    const act = e.target.getAttribute('data-act');
    if (!act || !selText) return;
    const t = selText;
    popup.style.display = 'none';
    if (act === 'hl') { addHighlight(t, ''); }
    else showNoteModal(t);
    try { window.getSelection().removeAllRanges(); } catch (err) {}
  });
}
// 居中多行批注弹窗
function showNoteModal(text) {
  const old = document.getElementById('note-modal');
  if (old) old.remove();
  const mask = document.createElement('div');
  mask.id = 'note-modal';
  mask.style.cssText = 'position:fixed;inset:0;background:rgba(20,22,32,.5);z-index:330;display:flex;align-items:center;justify-content:center;padding:20px';
  mask.innerHTML = `<div style="background:#fff;border-radius:14px;padding:20px;width:min(480px,92vw);box-shadow:0 20px 60px rgba(0,0,0,.35)">
    <h3 style="margin:0 0 6px;font-size:17px">写下批注（可留空）</h3>
    <p style="color:#888;font-size:13px;margin:0 0 12px;max-height:44px;overflow:hidden;line-height:1.5">${esc(String(text).slice(0, 80))}</p>
    <textarea id="note-modal-ta" rows="6" placeholder="输入你的想法…" style="width:100%;box-sizing:border-box;padding:10px 12px;border:1.5px solid #e6e8ee;border-radius:10px;font-size:15px;font-family:inherit;line-height:1.6;resize:vertical"></textarea>
    <div style="display:flex;gap:8px;margin-top:14px">
      <button class="btn block" onclick="confirmNoteModal()">保存</button>
      <button class="btn ghost block" onclick="closeNoteModal()">取消</button>
    </div></div>`;
  mask._text = text;
  mask.addEventListener('click', e => { if (e.target === mask) closeNoteModal(); });
  document.body.appendChild(mask);
  setTimeout(() => { const ta = document.getElementById('note-modal-ta'); if (ta) ta.focus(); }, 80);
}
function closeNoteModal() { const m = document.getElementById('note-modal'); if (m) m.remove(); }
function confirmNoteModal() {
  const m = document.getElementById('note-modal');
  const ta = m && document.getElementById('note-modal-ta');
  if (!m) return;
  addHighlight(m._text || '', ta ? ta.value.trim() : '');
  closeNoteModal();
}

function toggleDrawer(name) {
  const drawers = ['settings', 'toc', 'search'];
  let show = false;
  drawers.forEach(d => {
    const el = document.getElementById('drawer-' + d);
    if (d === name && el.classList.contains('hidden')) { el.classList.remove('hidden'); show = true; }
    else el.classList.add('hidden');
  });
  document.getElementById('drawer-mask').style.display = show ? 'block' : 'none';
  if (name === 'toc' && show) { markToc(); scrollTocToCurrent(); }
  if (name === 'search' && show) setTimeout(() => document.getElementById('search-q').focus(), 120);
}
function closeDrawers() {
  ['settings', 'toc', 'search'].forEach(d => document.getElementById('drawer-' + d).classList.add('hidden'));
  document.getElementById('drawer-mask').style.display = 'none';
}

// ---------- 设置 ----------
// 进入滚动模式的一次性操作提示
function showScrollHint() {
  try {
    if (localStorage.getItem('bm_scroll_hint')) return;
    localStorage.setItem('bm_scroll_hint', '1');
    const el = document.createElement('div');
    el.textContent = '滚动模式：上下滑动，或点屏幕右侧向下 / 左侧向上翻页';
    el.style.cssText = 'position:fixed;top:16px;left:50%;transform:translateX(-50%);background:rgba(31,36,48,.86);color:#fff;padding:9px 16px;border-radius:20px;font-size:13px;z-index:200;pointer-events:none;transition:opacity .5s;max-width:90vw;text-align:center;box-shadow:0 4px 14px rgba(0,0,0,.25)';
    document.body.appendChild(el);
    setTimeout(() => { el.style.opacity = '0'; }, 3200);
    setTimeout(() => el.remove(), 3800);
  } catch (e) {}
}

// 阅读模式切换：分页 ↔ 滚动
function applyMode(m) {
  setMode(m === 'scroll' ? 'scroll' : 'paged');
  applyModeClass();
  if (MODE === 'scroll') showScrollHint();
  if (isFlowable()) {
    if (MODE === 'scroll') attachScrollSave();
    else clearScrollLayout();   // 回到分页前清掉滚动模式的内联布局
    renderAt(curIdx, 0);   // 重排当前章（滚动模式无分页，直接纵向排布）
  }
}

// 百分比跳转：输入 0~100 的进度（如 93.33），跳到对应位置
function jumpPct() {
  const inp = document.getElementById('set-jump-pct');
  const v = parseFloat(inp && inp.value);
  if (isNaN(v)) { if (inp) { inp.focus(); inp.select(); } return; }
  const pct = Math.max(0, Math.min(100, v)) / 100;
  closeDrawers();
  if (!total) return;
  if (KIND === 'pdf') { pdfGoto(Math.max(1, Math.round(pct * total))); return; }
  if (MODE === 'scroll') {
    const target = pct * total - 1e-9;             // 全书进度 → 章节索引 + 章内比例
    const i = Math.min(total - 1, Math.max(0, Math.floor(target)));
    const inner = Math.max(0, Math.min(1, target - i));
    if (i === curIdx && document.getElementById('page-view')) jumpScrollTo(inner);
    else { afterPaginate = () => jumpScrollTo(inner); renderAt(i, 0); }
    return;
  }
  if (pageMapReady && totalPages > 0) {
    jumpToGlobalPage(Math.round(pct * totalPages) - 1);
  } else {
    const i = Math.min(total - 1, Math.floor(pct * total));
    renderAt(i, 0);
  }
}
function jumpScrollTo(inner) {
  const maxTop = docMaxTop();
  scrollToY(maxTop > 0 ? inner * maxTop : 0);
  saveProg();
}

function applySettings() {
  setBg(settings.theme);
  // 兼容模式入口：指向当前这本书的极简页（老设备/无 JS 用）
  var _ll = document.getElementById('lite-link');
  if (_ll) _ll.href = '/lite/book/' + BID;
  document.getElementById('set-fs').value = settings.font_size;
  document.getElementById('set-ff').value = settings.font_family;
  document.getElementById('set-lh').value = settings.line_height;
  document.getElementById('set-pw').value = settings.page_width;
  document.getElementById('set-br').value = settings.brightness || 1.0;
  document.getElementById('set-fx').value = settings.flip_effect || 'flip';
  document.getElementById('set-spd').value = settings.flip_speed || 380;
  document.getElementById('set-mode').value = MODE;
  document.getElementById('spd-val').textContent = (settings.flip_speed || 380) + 'ms';
  applyFontSize(settings.font_size);
  applyFontFamily(settings.font_family);
  applyLineHeight(settings.line_height);
  applyPageWidth(settings.page_width);
  applyBrightness(settings.brightness || 1.0);
  document.querySelectorAll('.theme-dot').forEach(d => d.classList.toggle('active', d.dataset.theme === themeKey(settings.theme)));
  document.querySelectorAll('.fc-opt').forEach(d => d.classList.toggle('active', d.dataset.color === (settings.font_color || '')));
}
// 背景风格表：key → { 名称, 正文默认字色 }。
// ★ 背景的**实际样式**在 reader.html 的 CSS 类（body.th-<key>）里，这里只管字色、
//   选中态和兜底 —— 有质感的背景（羊皮纸/牛皮纸/纸纹/竹青）是 CSS 渐变画的，
//   不引图片，所以 JS 这边不需要知道它们长什么样。
// ★ 老用户 settings.theme 里存的是 light/sepia/green/dark，一个都没改 key，
//   认不出来的值统一回落到米黄，绝不让阅读器白屏或抛错。
const THEMES = {
  light:     { name: '白色',   fg: '#1f2430' },
  sepia:     { name: '米黄',   fg: '#3a3329' },
  green:     { name: '护眼绿', fg: '#223a26' },
  dark:      { name: '夜间',   fg: '#cbd0da' },
  parchment: { name: '羊皮纸', fg: '#4a3a22' },
  kraft:     { name: '牛皮纸', fg: '#45331c' },
  paper:     { name: '纸纹',   fg: '#333333' },
  bamboo:    { name: '竹青',   fg: '#2a4520' },
  linen:     { name: '亚麻',   fg: '#2f3336' },
  silver:    { name: '银灰',   fg: '#2b3036' },
};
// ★ night（墨夜）2026-10-14 下线换成 silver（银灰）：已经选过墨夜的用户，
//   库里存的还是 'night'，这里做个跳转让他们落到新的银灰，而不是掉回米黄。
const THEME_ALIAS = { night: 'silver' };
function themeKey(t) { t = THEME_ALIAS[t] || t; return THEMES[t] ? t : 'sepia'; }
function setBg(theme) {
  const key = themeKey(theme);
  const t = THEMES[key];
  // 先把旧的 th-* 摘掉再挂新的：classList 在遍历中删元素会漏，所以先复制一份
  Array.prototype.slice.call(document.body.classList).forEach(c => {
    if (c.indexOf('th-') === 0) document.body.classList.remove(c);
  });
  document.body.classList.add('th-' + key);
  // 用户已手动指定字体色则优先，否则按主题自动配色
  const fg = settings.font_color || t.fg;
  document.body.style.color = fg;
  document.getElementById('r-content').style.color = fg;
}
function setFontColor(el) {
  const c = el.dataset.color;
  document.body.style.color = c;
  document.getElementById('r-content').style.color = c;
  settings.font_color = c;
  document.querySelectorAll('.fc-opt').forEach(d => d.classList.toggle('active', d === el));
  persistSettings();
}
function setTheme(el) {
  const theme = themeKey(el.dataset.theme);
  settings.theme = theme; setBg(theme);
  document.querySelectorAll('.theme-dot').forEach(d => d.classList.toggle('active', d === el));
  persistSettings();
}
function applyFontSize(v) {
  document.getElementById('fs-val').textContent = v;
  document.documentElement.style.setProperty('--rfs', v + 'px');
  settings.font_size = +v; persistSettings();
  rePaginate();
}
function applyFontFamily(v) { document.documentElement.style.setProperty('--rf', v); settings.font_family = v; persistSettings(); rePaginate(); }
function applyLineHeight(v) { document.getElementById('lh-val').textContent = v; document.documentElement.style.setProperty('--rlh', v); settings.line_height = +v; persistSettings(); rePaginate(); }
function applyPageWidth(v) { document.documentElement.style.setProperty('--rpw', v); settings.page_width = v; persistSettings(); rePaginate(); }
function applyBrightness(v) {
  v = Math.max(0.3, Math.min(1, +v || 1));
  document.getElementById('br-val').textContent = Math.round(v * 100) + '%';
  document.getElementById('brightness-overlay').style.opacity = (1 - v).toFixed(2);
  settings.brightness = v; persistSettings();
}
function applyFlipEffect(v) { settings.flip_effect = v; persistSettings(); }
function applyFlipSpeed(v) {
  v = Math.max(120, Math.min(1000, +v || 380));
  document.getElementById('spd-val').textContent = v + 'ms';
  settings.flip_speed = v; persistSettings();
}
function adjustFont(dir) {
  const s = document.getElementById('set-fs');
  const v = Math.max(+s.min, Math.min(+s.max, (+s.value || settings.font_size) + dir));
  s.value = v;
  applyFontSize(v);
}
let _rt;
function rePaginate() {
  if (!isFlowable() || MODE === 'scroll') return;
  clearTimeout(_rt);
  _rt = setTimeout(doRePaginate, 180);
}
// 隐藏/显示上下栏或窗口尺寸变化后立即重排（双 rAF 等布局稳定后执行）
function reflowImmediate() {
  if (!isFlowable() || MODE === 'scroll') return;
  clearTimeout(_rt);
  raf(() => raf(doRePaginate));
}
function doRePaginate() {
  const el = document.getElementById('paged');
  const view = document.getElementById('page-view');
  if (!el || !view) return;
  const W = view.clientWidth || window.innerWidth;
  // 记录当前阅读位置（占本章内容总宽的比例），重排后保持大致同一处
  const frac = el.scrollWidth ? (view.scrollLeft || curPage * W) / el.scrollWidth : 0;
  paginate();
  curPage = Math.max(0, Math.min(pagesInChapter - 1, Math.round(frac * (el.scrollWidth / W))));
  gotoPage(curPage);
  scheduleMapRebuild();
}
let _mr;
function scheduleMapRebuild() {
  if (!isFlowable()) return;
  clearTimeout(_mr);
  _mr = setTimeout(() => { pageMapReady = false; buildPageMap(); }, 700);
}
let _st;
function persistSettings() {
  clearTimeout(_st);
  _st = setTimeout(() => {
    const fd = new FormData();
    fd.append('theme', settings.theme); fd.append('font_size', settings.font_size);
    fd.append('font_family', settings.font_family); fd.append('line_height', settings.line_height);
    fd.append('page_width', settings.page_width); fd.append('brightness', settings.brightness);
    fd.append('flip_effect', settings.flip_effect); fd.append('flip_speed', settings.flip_speed);
    api('/api/settings', { method: 'PUT', body: fd }).catch(() => {});
  }, 500);
}

init();
