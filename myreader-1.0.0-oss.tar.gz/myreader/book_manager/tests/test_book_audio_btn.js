// 图书详情页的「有声阅读」按钮：有有声版的电子书，「开始阅读」右边多一个入口，
// 点了直接进这本有声电子书的**章节目录**（#/audio/<lib_id>）。
//
// 这是**只读测试**：全程不改任何数据（不需要造消息、不需要改推荐位）。
// 用测试账号 test（uid 45，本身有有声权限）。
//
// 几个容易做错、所以专门盯住的点：
//   ① 按钮必须在「开始阅读」**右边**（DOM 顺序），不是随便塞在按钮区；
//   ② 「有声阅读」和「听书」是两码事：听书=现场合成 TTS，有声阅读=做好的成品音频，
//      两套权限两套进度。测试里同时断言这两个按钮都在且各自独立；
//   ③ 没有有声版的书**不该**有这个按钮（否则点进去 404）；
//   ④ 访客不该有（访客进不去有声，§14.74）；
//   ⑤ 从图书详情进有声详情后，「← 返回」要回**那本书的详情**，而不是一路甩到有声列表；
//      从有声列表进来的，「← 返回」仍要回列表（别把原来的行为改坏了）；
//   ⑥ 硬件返回键（appBack）在有声详情/播放页以前没有分支，会直接退出 App —— 一并锁住。
//   ⑦ 后台「听书设置」的总开关：关掉时详情页**不给听书入口**，开了恢复（本次需求）。
//      ★ 这条**绝不去改线上开关**（改坏了站上听书就停了）：用 route 拦截把服务端下发的
//        listen_enabled 换成另一个值，验前端两个方向都对。测试本身仍然完全是只读的。
const { chromium } = require('playwright-core');
const ROOT = '/srv/myreader/book_manager';
const BASE = 'https://127.0.0.1:9000';
const CHROME = '/srv/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome';
const { execSync } = require('child_process');
const fs = require('fs');
const py = (c) => {
  fs.writeFileSync('/tmp/_auBtn.py', c);
  return execSync(`cd ${ROOT} && venv/bin/python /tmp/_auBtn.py`, { encoding: 'utf8' }).trim();
};
let pass = 0, fail = 0;
const ck = (n, ok, e) => { console.log((ok ? '  ✓ ' : '  ✗ ') + n + (e ? '  → ' + e : '')); ok ? pass++ : fail++; };

(async () => {
  process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
  // 都从库里现查，不写死：借一本有有声版的公共书 + 一本肯定没有有声版的书
  const info = JSON.parse(py(`
import sys, json; sys.path.insert(0,'.')
import db, auth
u = db.q("SELECT * FROM users WHERE username='test' AND enabled=1", one=True)
lib = db.q("""SELECT l.id lib_id, l.book_id, l.title, l.total_chapters
              FROM ab_lib l JOIN books b ON b.id=l.book_id
              WHERE l.hidden=0 AND COALESCE(b.hidden,0)=0 AND l.cover IS NOT NULL AND l.cover<>''
              ORDER BY l.sort, l.id LIMIT 1""", one=True)
plain = db.q("""SELECT b.id, b.title FROM books b
                WHERE COALESCE(b.hidden,0)=0 AND b.owner_id IS NULL
                  AND NOT EXISTS (SELECT 1 FROM ab_lib l WHERE l.book_id=b.id AND COALESCE(l.hidden,0)=0)
                ORDER BY b.id LIMIT 1""", one=True)
import tts
glib = db.q("""SELECT l.book_id, b.title FROM ab_lib l JOIN books b ON b.id=l.book_id
               WHERE l.hidden=0 AND COALESCE(b.hidden,0)=0 AND COALESCE(b.guest_featured,0)=1
               ORDER BY l.sort, l.id LIMIT 1""", one=True)
print(json.dumps({'tok': auth.create_token(u), 'user': {'id': u['id'], 'username': u['username'],
      'name': u['name'], 'role': u['role']}, 'lib': dict(lib), 'plain': dict(plain),
      'listen_on': bool(tts.settings()['enabled']),
      'guestlib': (dict(glib) if glib else None)}))`));
  const LIB = info.lib, PLAIN = info.plain;
  console.log(`  用书：有声版《${LIB.title}》book=${LIB.book_id} lib=${LIB.lib_id}；无有声版《${PLAIN.title}》book=${PLAIN.id}`);

  const browser = await chromium.launch({ args: ['--no-sandbox'], executablePath: CHROME });
  const errs = [];
  const mkPage = async (tok, usr) => {
    const ctx = await browser.newContext({ ignoreHTTPSErrors: true, viewport: { width: 1400, height: 1000 }, baseURL: BASE });
    if (tok) await ctx.addInitScript(([t, u]) => {
      localStorage.setItem('bm_token', t); localStorage.setItem('bm_user', u);
    }, [tok, JSON.stringify(usr)]);
    const p = await ctx.newPage();
    p.on('pageerror', e => errs.push(e.message));
    return [ctx, p];
  };
  // 详情页按钮区里所有按钮的文字（按 DOM 顺序）
  const btnLabels = (p) => p.$$eval('#detail-body .card.actions button', bs => bs.map(b => b.textContent.trim()));
  const hash = (p) => p.evaluate(() => location.hash);

  try {
    const [ctx, page] = await mkPage(info.tok, info.user);

    // ── 1. 有有声版的书：按钮在「开始阅读」右边
    await page.goto('/#/book/' + LIB.book_id, { waitUntil: 'domcontentloaded', timeout: 90000 });
    await page.waitForSelector('#detail-body .card.actions', { timeout: 30000 });
    await page.waitForTimeout(2000);
    const labels = await btnLabels(page);
    ck('★ 详情页有「有声阅读」按钮', labels.includes('有声阅读'), JSON.stringify(labels.slice(0, 5)));
    const iRead = labels.indexOf('📖 开始阅读'), iAudio = labels.indexOf('有声阅读');
    ck('★ 「有声阅读」就在「开始阅读」右边（紧邻）',
       iRead >= 0 && iAudio === iRead + 1, `开始阅读@${iRead} 有声阅读@${iAudio}`);
    ck('「开始阅读」和「有声阅读」都单独存在（两个不同功能）',
       labels.some(x => x.includes('开始阅读')) && labels.includes('有声阅读'), JSON.stringify(labels));
    // 「听书」按钮现在跟着后台总开关走：线上开关是开是关，这里都必须对得上
    ck('「听书」按钮的存在与后台总开关一致（线上现在' + (info.listen_on ? '启用' : '停用') + '）',
       labels.some(x => x.startsWith('听书')) === info.listen_on, JSON.stringify(labels));

    // ── 1b. 后台「听书」总开关：关掉不给入口，打开恢复（★ 本次需求）
    //    全程 route 拦截，**不动线上开关**（见文件头 ⑦）
    const API_BOOK = /\/api\/books\/\d+(\?|$)/;
    const detailWith = async enabled => {
      await ctx.unroute(API_BOOK);
      await ctx.route(API_BOOK, async route => {
        const resp = await route.fetch();
        let j = null;
        try { j = await resp.json(); } catch (e) { return route.fulfill({ response: resp }); }
        j.listen_enabled = enabled;
        j.has_listen_progress = true;      // 让「继续听书」也有机会出现，才能验它跟着藏
        j.listen_paid = true;
        await route.fulfill({ response: resp, json: j });
      });
      // ★ 两次导航：先回首页（保证是真实源——用 about:blank 中转会让 localStorage
      //   不可用、凭空报 JS 错），再进详情，这样每次都是全新拉取的详情数据。
      await page.goto('/', { waitUntil: 'domcontentloaded', timeout: 90000 });
      await page.goto('/#/book/' + LIB.book_id, { waitUntil: 'domcontentloaded', timeout: 90000 });
      await page.waitForSelector('#detail-body .card.actions', { timeout: 30000 });
      await page.waitForTimeout(1500);
      // ★ 「继续听书」在「阅读进度」卡片里，不在 .card.actions 里 —— 要扫整个详情页
      return page.$$eval('#detail-body button', bs => bs.map(b => b.textContent.trim()));
    };
    const offL = await detailWith(false);
    ck('★★ 后台停用听书时，详情页没有「听书」按钮', !offL.some(x => x.startsWith('听书')),
       JSON.stringify(offL));
    ck('★ 停用听书时「继续听书」也一并藏起来（有听书进度也不给入口）',
       !offL.some(x => x.includes('继续听书')), JSON.stringify(offL));
    ck('★ 停用听书不影响「有声阅读」（成品音频，另一套开关）', offL.includes('有声阅读'));
    const onL = await detailWith(true);
    ck('★★ 后台启用听书后，「听书」按钮恢复显示', onL.some(x => x.startsWith('听书')),
       JSON.stringify(onL));
    ck('★ 启用听书时「继续听书」也回来', onL.some(x => x.includes('继续听书')),
       JSON.stringify(onL));
    await ctx.unroute(API_BOOK);
    const flag = await page.evaluate(() => detailBook && detailBook.listen_enabled);
    ck('拦截下发 true 后前端确实按这个字段走（detailBook.listen_enabled=true）', flag === true,
       'detailBook.listen_enabled=' + flag);
    // 去掉拦截后走真实接口，字段必须等于后台开关的实际状态
    // ★ 参数要传进去：evaluate 的回调在**浏览器**里跑，那边没有 Node 的 LIB
    const realFlag = await page.evaluate(
      id => api('/api/books/' + id).then(b => b.listen_enabled), LIB.book_id);
    ck('★ 真实接口下发的 listen_enabled 与后台开关一致（线上现在' +
       (info.listen_on ? '启用' : '停用') + '）', realFlag === info.listen_on,
       'listen_enabled=' + realFlag);

    // ── 2. 点它 → 直接进这本有声书的章节目录
    await page.locator('#detail-body .card.actions button', { hasText: '有声阅读' }).click();
    await page.waitForSelector('#view-audio:not(.hidden)', { timeout: 20000 });
    await page.waitForTimeout(2500);
    ck('★★ 跳到的是这本有声书的详情地址 #/audio/' + LIB.lib_id,
       (await hash(page)) === '#/audio/' + LIB.lib_id, await hash(page));
    const auTitle = await page.locator('#au-detail-title').innerText().catch(() => '');
    ck('★ 显示的就是这本有声书', auTitle.includes(LIB.title), 'au-detail-title=' + auTitle);
    const chapCount = await page.locator('#au-detail-body .ad-chap').count();
    ck('★★ 确实是章节目录（列出了章节）', chapCount > 0, '章节 ' + chapCount + ' 条 / 共 ' + LIB.total_chapters + ' 章');

    // ── 3. 「← 返回」回**那本书的详情**，不是有声列表
    await page.locator('#view-audio .navbar button.back').click();
    await page.waitForTimeout(2500);
    ck('★★ 从图书详情进来，「← 返回」回的是那本书的详情',
       (await hash(page)) === '#/book/' + LIB.book_id, await hash(page));
    ck('★ 回到详情页界面也切回来了（不是空白）',
       await page.locator('#view-detail').isVisible().catch(() => false)
       && (await page.locator('#detail-body h2').innerText().catch(() => '')).includes(LIB.title));

    // ── 4. 硬件返回键：以前有声详情页没有分支，会直接退出 App
    await page.locator('#detail-body .card.actions button', { hasText: '有声阅读' }).click();
    await page.waitForSelector('#view-audio:not(.hidden)', { timeout: 20000 });
    await page.waitForTimeout(2000);
    const handled = await page.evaluate(() => appBack());
    await page.waitForTimeout(2000);
    ck('★ 有声详情页按硬件返回键被接管（不再直接退出 App）', handled === true, 'appBack()=' + handled);
    ck('★ 硬件返回键同样回到那本书的详情',
       (await hash(page)) === '#/book/' + LIB.book_id, await hash(page));

    // ── 5. 从有声**列表**进去的，返回仍回列表（别把原行为改坏）
    await page.evaluate(() => switchPage('audio'));
    await page.waitForSelector('#au-list .au-card', { timeout: 30000 });
    await page.locator('#au-list .au-card').first().click();
    await page.waitForSelector('#view-audio:not(.hidden)', { timeout: 20000 });
    await page.waitForTimeout(2000);
    const h1 = await hash(page);
    await page.locator('#view-audio .navbar button.back').click();
    await page.waitForTimeout(2500);
    const h2 = await hash(page);
    ck('★ 从有声列表进去的，「← 返回」仍回有声列表',
       h1.startsWith('#/audio/') && (h2 === '#/audio' || h2 === '#/audio/'), `${h1} → ${h2}`);
    ck('回到的是有声列表界面（卡片在）', await page.locator('#au-list .au-card').first().isVisible().catch(() => false));

    // ── 6. 没有有声版的书：不该有这个按钮
    await page.goto('/#/book/' + PLAIN.id, { waitUntil: 'domcontentloaded', timeout: 90000 });
    await page.waitForSelector('#detail-body .card.actions', { timeout: 30000 });
    await page.waitForTimeout(2000);
    const l2 = await btnLabels(page);
    ck('★ 没有有声版的书不显示「有声阅读」（否则点进去是 404）',
       !l2.includes('有声阅读'), JSON.stringify(l2.slice(0, 5)));
    ck('这种书仍有「开始阅读」', l2.some(x => x.includes('开始阅读')));

    // ── 7. 访客不该有（访客进不去有声 / 听书）
    //   ★ 这步原来一直红：访客只能看到 guest_featured=1 的书，原来用的是 LIB 那本
    //     （guest_featured=0）→ 访客压根看不到这本书的详情 → 等按钮区必然超时。
    //     换成一本「访客可见**且**有有声版」的书，详情页才真的渲染出来，
    //     「访客看不到有声阅读」这条断言也才真正验到东西。
    ck('存在「访客可见且有有声版」的书（本步前提）', !!info.guestlib, JSON.stringify(info.guestlib));
    const guestBook = info.guestlib ? info.guestlib.book_id : LIB.book_id;
    const [ctxG, gpage] = await mkPage(null, null);
    await gpage.goto('/#/book/' + guestBook, { waitUntil: 'domcontentloaded', timeout: 90000 });
    await gpage.waitForSelector('#detail-body .card.actions', { timeout: 30000 });
    await gpage.waitForTimeout(2500);
    const l3 = await gpage.$$eval('#detail-body .card.actions button', bs => bs.map(b => b.textContent.trim()));
    ck('★ 访客看不到「有声阅读」（访客听不了有声，给了只会点出 403）',
       !l3.includes('有声阅读'), JSON.stringify(l3.slice(0, 5)));
    ck('★ 访客也看不到「听书」（服务端同样拒绝匿名流量）',
       !l3.some(x => x.startsWith('听书')), JSON.stringify(l3.slice(0, 5)));
    await ctxG.close();

    ck('整个过程没有 JS 报错', errs.length === 0, errs.slice(0, 2).join(' | '));
    await ctx.close();
  } finally {
    await browser.close();
  }

  console.log(`\n图书详情「有声阅读」按钮：${pass} 通过 / ${fail} 失败`);
  process.exit(fail ? 1 : 0);
})();
