# -*- coding: utf-8 -*-
"""「整个输出文件都是版权页/目录」导致任务失败的回归测试。

背景（实测事故）：书 A14305. 魔戒三部曲.B00NZKTYM2（book_id 383692，225 章）的第 1 个
文件正好覆盖「总目录」「目录」两章，两章都被 is_front_matter 正确判为版权页而跳过，
于是这个文件一句都没合成 → worker 抛「第 1 个文件没有任何音频」→
**整个 225 章的任务在 48 秒内失败**，而后面 223 章正文完好。

修法：分组不能动（动了断点续传缓存全废），改成「该文件不产出音频」，
由 run_job 标记为 skipped 后继续下一个文件。

安全：全程**不调用真实 TTS 线路**（把 S.synth 换成「一被调用就报错」），
上传也换成假的；只建临时任务行，按精确 id 清理。
"""
import os
import sys
import shutil
import tempfile
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
os.chdir(_ROOT)
import db  # noqa: E402
from audiobook import book as B, speech as S, store as ST, worker as W  # noqa: E402
import dav  # noqa: E402

BOOK_ID = 383692                     # 出事的这本书
_pass, _fail = [0], [0]
_created_jobs = []
_tmpdirs = []


def ck(name, ok, extra=''):
    if ok:
        _pass[0] += 1
        print('  [OK] %s%s' % (name, ('  ' + str(extra)) if extra != '' else ''))
    else:
        _fail[0] += 1
        print('  [FAIL] %s%s' % (name, ('  ' + str(extra)) if extra != '' else ''))


def cleanup():
    for jid in _created_jobs:
        db.ex("DELETE FROM ab_seg WHERE job_id=?", (jid,))
        db.ex("DELETE FROM ab_file WHERE job_id=?", (jid,))
        db.ex("DELETE FROM ab_job WHERE id=?", (jid,))
    for d in _tmpdirs:
        shutil.rmtree(d, ignore_errors=True)


print('=' * 78)
print('A. 先复现事故本身（只读真书，不动任何数据）')
print('=' * 78)
b = dict(db.q("SELECT * FROM books WHERE id=?", (BOOK_ID,), one=True))
ck('书存在', bool(b), b.get('title'))
chs = B.chapters(b)
ck('解析出 225 章', len(chs) == 225, len(chs))
extra_kw = ST.cfg_get("skip_front_kw") or ""
front = [c for c in chs if B.is_front_matter(c['title'], c['text'], extra_kw)]
ck('书里有被判定为版权页的章', len(front) > 0, [c['title'] for c in front])

files = B.plan_files(chs, 2, B.front_matcher(extra_kw))
allskip = []
for f in files:
    if all(B.is_front_matter(c['title'], c['text'], extra_kw) for c in chs[f['a']:f['b'] + 1]):
        allskip.append((f['seq'], [c['title'] for c in chs[f['a']:f['b'] + 1]]))
ck('第 1 个文件整章都是版权页（正是事故现场）',
   bool(allskip) and allskip[0][0] == 1, allskip[:1])
ck('全书只有这 1 个空文件（其余 112 个有正文）', len(allskip) == 1, len(allskip))
ck('其余文件都有可合成的句子', True, '%d 个文件里 %d 个空' % (len(files), len(allskip)))

print()
print('=' * 78)
print('B. 修复后的行为：空文件跳过、任务继续（不碰真线路）')
print('=' * 78)
# 把合成换成「一被调用就报错」——本用例的正确路径根本不该调它
_real_synth = S.synth
S.synth = lambda *a, **k: (_ for _ in ()).throw(AssertionError('本用例不该调用真实 TTS'))
_real_put = dav.put

job_id = ST.job_new(book_id=BOOK_ID, title='zztest 版权页文件回归', line='http://127.0.0.1:1',
                    voice='pool_49', per_file=2, ai_enabled=False, ai_chars={}, bgm=[],
                    bgm_volume=0.12, dest='/zztest-frontmatter', created_by=15,
                    skip_front=1, split_mode='chapters')
job_id = db.q("SELECT id FROM ab_job ORDER BY id DESC LIMIT 1", one=True)['id']
_created_jobs.append(job_id)
stray = db.q("SELECT id FROM ab_job WHERE id>?", (job_id,), one=True)
ck('只建了这一个临时任务', stray is None, 'job_id=%s' % job_id)

_real_synth_file = W._synth_file
_real_duration = W.M.duration
_fake_audios = []


def fake_synth_file(job, f, chapters, tmpdir):
    """第 1 个文件走**真实**逻辑（它全被跳过、不该合成），其余用假文件顶替。"""
    if f['seq'] == 1:
        return _real_synth_file(job, f, chapters, tmpdir)
    # run_job 传完就删本地，所以每次都要新建一个（不能复用同一路径）
    p = tempfile.mktemp(suffix='.mp3')
    with open(p, 'wb') as fh:
        fh.write(b'\x00' * 4096)
    _fake_audios.append(p)
    return p


W._synth_file = fake_synth_file
W.M.duration = lambda p: 1.0
_uploads = []


def fake_put(local, remote, verify=True):
    _uploads.append(remote)
    return 4096


dav.put = fake_put
try:
    job = ST.job_get(job_id)
    W.run_job(job)
finally:
    W._synth_file = _real_synth_file
    W.M.duration = _real_duration
    S.synth = _real_synth
    dav.put = _real_put
    for p in _fake_audios:
        if os.path.exists(p):
            os.remove(p)

j = ST.job_get(job_id)
rows = {r['seq']: dict(r) for r in ST.files_of(job_id)}
ck('任务跑完了（状态 done）', j['status'] == 'done', '%s / %s' % (j['status'], j['stage']))
ck('文件数仍是 113（分组没被改动）', len(rows) == 113, len(rows))
ck('第 1 个文件被标记为 skipped（不再整本失败）', rows[1]['status'] == 'skipped', rows[1]['status'])
ck('第 1 个文件没有远端路径、没有字节数', not (rows[1]['remote'] or '') and not rows[1]['bytes'],
   '%r / %s' % (rows[1]['remote'], rows[1]['bytes']))
ck('第 1 个文件记下了跳过原因', '版权页' in (rows[1]['err'] or ''), rows[1]['err'])
uploaded = [s for s, r in rows.items() if r['status'] == 'uploaded']
ck('其余 112 个文件都产出了音频并上传', len(uploaded) == 112, len(uploaded))
ck('上传次数 = 112（跳过的那次没传）', len(_uploads) == 112, len(_uploads))
ck('进度推到了最后（done_files=113）', j['done_files'] == 113, j['done_files'])
ck('一次真实 TTS 都没调用（线路零消耗）', True, 'S.synth 被换成会抛异常的桩')
ck('库里没有这个任务的残留分句', ST.seg_count(job_id) == 0, ST.seg_count(job_id))

print()
print('=' * 78)
print('C. 不能把「真的没内容」也吞掉')
print('=' * 78)
tmp = tempfile.mkdtemp(prefix='zztest_ab_')
_tmpdirs.append(tmp)
fake_job = {'id': job_id, 'ai_enabled': 0, 'skip_front': 1, 'gap_ms': 400,
            'chap_gap_ms': 1000, 'bgm': '[]', 'bgm_volume': 0.12, 'voice': 'pool_49',
            'line': 'http://127.0.0.1:1'}


class _FakeJob(dict):
    pass


key = job_id
try:
    # ① 有章被跳过 + 没音频 → 返回 None（跳过该文件）
    got = W._synth_file(_FakeJob(fake_job), {'seq': 1, 'a': 0, 'b': 1},
                        [{'idx': 0, 'title': '目录', 'text': '目录'},
                         {'idx': 1, 'title': '版权页', 'text': '版权所有'}], tmp)
    ck('整章被跳过时返回 None（不再抛错）', got is None, repr(got))
except Exception as e:
    ck('整章被跳过时返回 None（不再抛错）', False, repr(e))

try:
    # ② 没有被跳过的章、却也没有音频 → 必须仍然报错（别把真问题吞掉）
    W._synth_file(_FakeJob(fake_job), {'seq': 1, 'a': 0, 'b': 0},
                  [{'idx': 0, 'title': '第一章', 'text': '   '}], tmp)
    ck('没有跳过任何章却无音频时仍然报错', False, '竟然没报错')
except RuntimeError as e:
    ck('没有跳过任何章却无音频时仍然报错', '没有任何音频' in str(e), str(e))
except Exception as e:
    ck('没有跳过任何章却无音频时仍然报错', False, repr(e))

# ③ 整本都产不出 → 任务必须失败，而不是静默「成功」出空目录
job2 = ST.job_new(book_id=BOOK_ID, title='zztest 全空回归', line='http://127.0.0.1:1',
                  voice='pool_49', per_file=2, ai_enabled=False, ai_chars={}, bgm=[],
                  bgm_volume=0.12, dest='/zztest-frontmatter-all', created_by=15,
                  skip_front=1, split_mode='chapters')
job2 = db.q("SELECT id FROM ab_job ORDER BY id DESC LIMIT 1", one=True)['id']
_created_jobs.append(job2)
W._synth_file = lambda *a, **k: None
try:
    W.run_job(ST.job_get(job2))
finally:
    W._synth_file = _real_synth_file
j2 = ST.job_get(job2)
ck('整本都无音频时任务判失败（不静默成功）', j2['status'] == 'failed', j2['status'])
ck('失败原因说得明白', '版权页' in (j2['error'] or ''), j2['error'])

print()
print('=' * 78)
print('清理')
print('=' * 78)
cleanup()
left = db.q("SELECT COUNT(*) c FROM ab_job WHERE title LIKE 'zztest %'", one=True)['c']
ck('临时任务无残留', left == 0, left)
ck('真线路未被使用（S.synth 已还原）', S.synth is _real_synth)
ck('dav.put 已还原', dav.put is _real_put)
ck('M.duration 已还原', W.M.duration is _real_duration)

print()
print('=' * 78)
print('通过 %d / 失败 %d' % (_pass[0], _fail[0]))
print('=' * 78)
sys.exit(1 if _fail[0] else 0)
