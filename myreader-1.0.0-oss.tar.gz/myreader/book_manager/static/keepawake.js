/* 播放时不让手机熄屏 —— 听书页（listen.html）与有声播放页（index.html）共用。
 *
 * 为什么单独一个文件：听书是独立页面（listen.html 只引 listen.js），
 * 有声播放页在 SPA 里（index.html 引 app.js + audio.js）。两边都要这个能力，
 * 复制两份迟早改漏一边，所以抽成一个共用小文件，两个页面各引一次。
 *
 * 两条实现路线，优先原生：
 *   1) APP 内：调用原生插件 ListenService.keepAwake（给 Activity 加
 *      FLAG_KEEP_SCREEN_ON）。最可靠，老 WebView 也管用。
 *   2) 网页/较新 WebView：用浏览器的 Screen Wake Lock API。
 *   3) 两者都没有（老 WebView）：静默跳过 —— 绝不能因为拿不到这个能力就影响播放。
 *
 * ★ 两种实现都**只在应用处于前台时有效**：切后台/锁屏后系统会自己放开，
 *   不会出现「人走了屏幕还亮着」把电耗光的情形。回到前台若还在播，
 *   必须自己再要一把（浏览器的 wakeLock 在页面转入后台时会被自动释放）。
 *
 * 调用方只负责表达「现在该不该常亮」：
 *   · 听书页：播放/暂停时 keepAwake(playing)；
 *   · 有声页：播放中**且人就在播放页**时 keepAwake(true)，离开播放页 keepAwake(false)。
 *     （后台放音不该让屏幕一直亮着 —— 手机装口袋里屏幕还亮最费电。）
 */
let _wakeLockObj = null;     // 浏览器那一把；null 表示没持有
let _wakeWant = false;       // 上层希望常亮吗
let _wakeLast = null;        // 上次真正下发的值：避免 timeupdate 每 250ms 都去调原生/申请锁

function keepAwake(on) {
  on = !!on;
  _wakeWant = on;
  if (_wakeLast === on) return;      // 状态没变就不重复下发
  _wakeLast = on;

  // ---- 1) APP 内优先走原生 ----
  let P = null;
  try { P = (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.ListenService) || null; } catch (e) { P = null; }
  if (P && typeof P.keepAwake === 'function') {
    try { P.keepAwake({ on: on }).catch(function () {}); } catch (e) {}
    return;
  }

  // ---- 2) 浏览器 Screen Wake Lock ----
  if (!('wakeLock' in navigator)) return;    // 老 WebView：交给原生那条路，这里什么都不做
  try {
    if (!on) {
      const w = _wakeLockObj;
      _wakeLockObj = null;
      if (w) w.release().catch(function () {});
      return;
    }
    if (_wakeLockObj) return;
    navigator.wakeLock.request('screen').then(function (w) {
      // 申请是异步的：回来时可能已经又暂停了
      if (!_wakeWant) { w.release().catch(function () {}); return; }
      _wakeLockObj = w;
      w.addEventListener('release', function () {
        if (_wakeLockObj === w) _wakeLockObj = null;
      });
    }).catch(function () {});     // 失败就算了，不能影响播放
  } catch (e) { /* 同上 */ }
}

// 回到前台且还在播 → 把锁续上（浏览器在页面转后台时已经自动释放了那一把）
document.addEventListener('visibilitychange', function () {
  if (_wakeWant && !document.hidden) {
    _wakeLast = null;            // 强制重新下发一次
    keepAwake(true);
  }
});
