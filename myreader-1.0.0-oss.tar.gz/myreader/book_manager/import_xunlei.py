# -*- coding: utf-8 -*-
"""把源目录（绝对路径，如 /Media2/Download）下的电子书：分类后 MOVE 进书库分类文件夹（库内自持，不留引用）。
流程：SFTP 全量扫描 → 按【文件名去掉扩展名】(忽略大小写)去重 →
      同名组内按格式优先级 EPUB>AZW3>AZW>KFX>MOBI>TXT>PDF 只保留一份 →
      若新文件格式比库内同名(去扩展名)文件更好，删除库内旧格式并以新格式替代
      （仅限文件名完全相同、扩展名不同）→
      中图法分类 → WebDAV MOVE(失败则FTP/SFTP搬移) 到 FTP_BASE/<分类>/<规整文件名> → 以相对路径入库。
库里已有同名（去扩展名）且格式更好/相同的文件算重复，不搬不移不删；源目录内部同名的保留格式最优那份搬入，
其余留在原目录。
可作库使用（app 管理员后台“分类入库”按钮）：
    import import_xunlei
    import_xunlei.start_import(base="/Media2/Download")   # 后台线程执行；base 为源目录绝对路径
    import_xunlei.xunlei_status()                         # 轮询状态
也可命令行直接跑：python3 import_xunlei.py [/源目录绝对路径]
"""
import os, sys, json, time, threading
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "ebook_task"))
import config, db, classify, covers, paramiko, ftp_service

DEFAULT_BASE = "/Media2/Download"
TARGET_BASE = config.FTP_BASE          # 书库存储根（相对路径据此解析）
SCAN_OUT = os.path.join(config.DATA_DIR, "xunlei_files.json")

# ---------------- 任务状态（供后台轮询） ----------------
_state = {"running": False, "phase": "", "files_found": 0, "time": None,
          "result": None, "error": None, "base": "", "lock": threading.Lock()}


def xunlei_status():
    with _state["lock"]:
        return {k: v for k, v in _state.items() if k != "lock"}


def _set(**kw):
    with _state["lock"]:
        for k, v in kw.items():
            _state[k] = v


def ext_of(name):
    return ("." + name.rsplit(".", 1)[-1].lower()) if "." in name else ""


# ---------------- 智能去重：识别同一本书的不同命名 ----------------
# 例：“三重门-韩寒”、“三重门”、“三重门-我的小书屋下载” 视为同一本书，只保留一个
_SRC_TAGS = ("下载", "书屋", "书包", "网盘", "百度", "迅雷", "资源", "网站", "站",
             "download", "baidu", "pan", "share", "txt", "全集", "合集")


def norm_title(t):
    """标题归一化：剥来源后缀(我的小书屋下载等) → 去括号注释 → 去标点/空格/连接符，得纯核心串"""
    if not t:
        return ""
    import re as _re
    s = t.lower()
    for tag in ("我的小书屋下载", "小书屋下载", "小书屋", "书包网", "百度网盘",
                "网盘下载", "网盘", "txt下载", "txt", "迅雷下载", "迅雷"):
        s = s.replace(tag, "")
    s = _re.sub(r"[（(【\[].*?[）)】\]]", "", s)
    s = _re.sub(r"[\W_]+", "", s, flags=_re.UNICODE)
    return s.strip()


def looks_like_source(a):
    """作者/后缀里带来源标记（我的小书屋下载、书包网等）或过长 → 视为无真实作者"""
    if not a:
        return True
    a = a.strip().lower()
    return len(a) > 12 or any(k in a for k in _SRC_TAGS)


def author_compat(la, ca):
    """库内作者 vs 候选作者是否可视为同一本书（一侧无作者/来源标记 → 同书；作者名互相包含 → 同书）"""
    la, ca = (la or "").strip().lower(), (ca or "").strip().lower()
    if looks_like_source(ca) or looks_like_source(la):
        return True
    if not la or not ca:
        return True
    return la == ca or la in ca or ca in la


def better_candidate(j, prev):
    """择优保留：有真实作者 > 无作者；同条件取体积大者"""
    def real(job):
        a = (job["author"] or "").strip().lower()
        return "" if looks_like_source(a) else a
    ja, pa = real(j), real(prev)
    if bool(ja) != bool(pa):
        return bool(ja)
    return (j["size"] or 0) > (prev["size"] or 0)


def _sftp_move(src_abs, dst_rel):
    """兜底搬移：SFTP 下载到本地 → 上传到目标 → 删除源文件。成功返回目标大小。"""
    import tempfile
    local = os.path.join(tempfile.gettempdir(), "xl_mv_" + str(abs(hash(src_abs)) % 10 ** 10) + ext_of(src_abs))
    try:
        size = ftp_service.download_to(src_abs, local, timeout=600)
        ftp_service.makedirs(dst_rel.rsplit("/", 1)[0])
        ftp_service.upload_file(local, dst_rel)
        ftp_service.delete(src_abs)
        return size
    except Exception:
        return None
    finally:
        if os.path.exists(local):
            try: os.remove(local)
            except Exception: pass


def _move_to_library(rel, folder, new_name, base):
    """把 base/rel 移动到 TARGET_BASE/folder/new_name；成功返回 (相对路径, 大小)
    目标名唯一性由调用方（并发 taken 集合）保证，这里不再逐文件 stat。"""
    src = base + "/" + rel
    dst_rel = folder + "/" + new_name
    ftp_service.makedirs(folder)                 # 确保分类目录存在（WebDAV MOVE 目标目录必须已建）
    if ftp_service.rename(src, dst_rel):        # WebDAV MOVE → FTP rename 兜底
        return dst_rel
    return None


def _scan(base):
    """SFTP 全量扫描目录，返回文件清单 [{path,size}]，进度写入状态"""
    files, dirs, errors = [], 0, []
    t0 = time.time()
    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    c.connect(config.SFTP_HOST, port=config.SFTP_PORT, username=config.FTP_USER,
              password=config.FTP_PASS, timeout=30, allow_agent=False, look_for_keys=False)
    s = c.open_sftp()
    DIRBIT = 0o040000

    def walk(path, rel, depth):
        nonlocal dirs
        if depth > 30:
            return
        try:
            entries = s.listdir_attr(path)
        except Exception as e:
            errors.append((rel, str(e)))
            return
        for e in entries:
            if e.filename in ('.', '..', '@eaDir', '#recycle', '.bt'):
                continue
            r = rel + '/' + e.filename if rel else e.filename
            if e.st_mode & DIRBIT:
                dirs += 1
                walk(path + '/' + e.filename, r, depth + 1)
            else:
                files.append({'path': r, 'size': e.st_size})
        if len(files) % 5000 < 50:
            _set(files_found=len(files))
    try:
        walk(base, '', 1)
    finally:
        s.close(); c.close()
    _set(files_found=len(files))
    manifest = {"base": base, "files": files, "dirs": dirs, "errors": errors[:50],
                "elapsed": round(time.time() - t0, 1)}
    with open(SCAN_OUT, "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False)
    return manifest


def _move_import(manifest, base=DEFAULT_BASE):
    """按【文件名去掉扩展名】去重（格式优先级 EPUB>AZW3>AZW>KFX>MOBI>TXT>PDF）；
    新文件格式比库内同名文件的格式更好 → 删除库内旧格式，以新格式替代（仅限文件名完全相同、扩展名不同）"""
    from concurrent.futures import ThreadPoolExecutor
    files = manifest["files"]
    total = len(files)
    rows = db.q("SELECT id, path, size, title, author FROM books")
    existing_paths = {r["path"] for r in rows}
    # 库内文件名(去扩展名,小写) → [(路径, 格式优先级, id)]：用于同名判定与格式替换
    FMT_PRIO = {"epub": 0, "azw3": 1, "azw": 2, "kfx": 3, "mobi": 4, "txt": 5, "pdf": 6}
    def fmt_rank(ext):
        return FMT_PRIO.get((ext or "").lstrip(".").lower(), 7)
    lib_by_base = {}
    for r in rows:
        bn = r["path"].rsplit("/", 1)[-1].rsplit(".", 1)[0].lower()
        if bn:
            lib_by_base.setdefault(bn, []).append((r["path"], fmt_rank(ext_of(r["path"])), r["id"]))
    cands = [f for f in files if ext_of(f["path"]) in config.BOOK_EXTS]
    not_book = total - len(cands)

    # ---- 阶段1：按文件名(去扩展名,忽略大小写)分组去重 + 格式择优 + 替换判定 + 分类（毫秒级） ----
    groups = {}
    for f in cands:
        bn = f["path"].rsplit("/", 1)[-1].rsplit(".", 1)[0].lower()
        groups.setdefault(bn, []).append(f)

    dup_existing = dup_internal = replaced = 0
    jobs, replace_del, cat_stat = [], [], {}
    t1 = time.time()
    for bn, g in groups.items():
        best = min(g, key=lambda f: (fmt_rank(ext_of(f["path"])), -(f["size"] or 0)))
        in_rank = fmt_rank(ext_of(best["path"]))
        if bn in lib_by_base:                          # 1) 库里已有同名(无扩展名)
            lib_best = min(rk for _, rk, _ in lib_by_base[bn])
            if in_rank < lib_best:                     # 新格式更好 → 删库内旧格式，以新格式替代
                for old_path, _rk, old_id in lib_by_base[bn]:
                    replace_del.append((old_path, old_id))
                    existing_paths.discard(old_path)
                replaced += 1
                dup_existing += len(g) - 1             # 组内其它格式留在迅雷
                jobs.append(_build_job(best, classify, covers, os, ext_of))
            else:                                      # 库里格式更好或相同 → 整组跳过
                dup_existing += len(g)
            continue
        if len(g) > 1:                                 # 2) 迅雷内部同名 → 只留格式优先级最高的一份
            dup_internal += len(g) - 1
            g = [best]
        jobs.append(_build_job(best, classify, covers, os, ext_of))

    # ---- 阶段2：并发搬移 + 并发删除被替换的库内旧文件，共享已占用目标名 ----
    taken_lock = threading.Lock()
    taken = {p.lower() for p in existing_paths}   # 目标名占用集（统一小写，避免 I_文学 大小写不匹配）
    moved, missing_source, move_failed, del_ok, del_fail = [], 0, 0, 0, 0

    def do_move(job):
        folder, new_name = job["folder"], job["new_name"]
        with taken_lock:
            b, e = os.path.splitext(new_name)
            cand = new_name
            k = 1
            while (folder + "/" + cand).lower() in taken:
                cand = b + f"({k}){e}"
                k += 1
            taken.add((folder + "/" + cand).lower())
        dst = _move_to_library(job["rel"], folder, cand, base)
        if dst is None:
            with taken_lock:
                st = ftp_service.stat(base + "/" + job["rel"])
            return job, ("missing" if st is None else "failed"), None
        return job, "ok", dst

    def do_delete(path):
        try:
            return 1 if ftp_service.delete(path) else 0
        except Exception:
            return 0

    WORKERS = 12
    not_moved_samples = []
    with ThreadPoolExecutor(max_workers=WORKERS) as ex:
        del_futs = {ex.submit(do_delete, p): (p, oid) for p, oid in replace_del}   # 并发删除被替换的旧文件
        for job, status, dst in ex.map(do_move, jobs):
            if status == "ok":
                moved.append((job, dst))
            elif status == "missing":
                missing_source += 1
                if len(not_moved_samples) < 40:
                    not_moved_samples.append({"name": job["rel"].rsplit("/", 1)[-1], "reason": "源文件不存在"})
            else:
                move_failed += 1
                if len(not_moved_samples) < 40:
                    not_moved_samples.append({"name": job["rel"].rsplit("/", 1)[-1], "reason": "移动失败"})
            n = len(moved)
            if n % 500 < 3:
                _set(files_found=n, phase="import")
        del_ok_ids = [oid for f, (_p, oid) in del_futs.items() if f.result()]      # 只在文件删除成功时删行
    del_ok, del_fail = len(del_ok_ids), len(replace_del) - len(del_ok_ids)

    # ---- 阶段3：删除被替换的旧记录 → 批量入库 + 每分类移动统计 ----
    _delete_rows(del_ok_ids)
    batch, moved_by_cat = [], {}
    for job, dst_rel in moved:
        moved_by_cat[job["cat"]] = moved_by_cat.get(job["cat"], 0) + 1
        batch.append((dst_rel, job["title"], job["author"], job["folder"], job["cat"],
                      job["ddc"], job["ext"], job["size"], db.now(), db.now()))
        if len(batch) >= 2000:
            _insert_batch(batch)
            batch = []
    if batch:
        _insert_batch(batch)
    imported = len(moved)
    return {"total_files": total, "not_book": not_book, "dup_existing": dup_existing,
            "dup_internal": dup_internal, "replaced": replaced,
            "replaced_del_fail": del_fail,
            "imported": imported, "moved": imported,
            "missing_source": missing_source, "move_failed": move_failed,
            "not_moved": missing_source + move_failed,
            "not_moved_samples": not_moved_samples,
            "elapsed_scan": manifest.get("elapsed"), "elapsed_import": round(time.time() - t1, 1),
            "by_category": {k: v for k, v in sorted(moved_by_cat.items())}}


def _build_job(f, classify, covers, os, ext_of):
    """由候选文件生成搬移任务（分类 + 规整文件名）"""
    name = f["path"].rsplit("/", 1)[-1]
    try:
        cat = classify.classify(name, name) or "00"
    except Exception:
        cat = "00"
    folder = classify.CAT_FOLDERS.get(cat, "00_待分类")
    try:
        _fn, title, author = classify.final_name(name)
    except Exception:
        title, author = os.path.splitext(name)[0], ""
    if not title:
        title = os.path.splitext(name)[0]
    ext = ext_of(name)
    try:
        new_name = covers.normalize_filename(title, author, ext) or name
    except Exception:
        new_name = name
    cls = classify.CLASSES.get(cat, {"ddc": "-"})
    return {"rel": f["path"], "folder": folder, "new_name": new_name,
            "title": title, "author": author, "cat": cat, "ddc": cls.get("ddc", "-"),
            "ext": ext, "size": f["size"]}


def _delete_rows(ids):
    """删除指定 book id 的行及其关联记录（分小批，避免长事务锁库）"""
    if not ids:
        return
    for i in range(0, len(ids), 1000):
        chunk = ids[i:i + 1000]
        ph = ",".join("?" * len(chunk))
        c = db.get_conn()
        c.execute("DELETE FROM books WHERE id IN (%s)" % ph, chunk)
        for t in ("shelves", "progress", "shares", "book_grants"):
            try:
                c.execute("DELETE FROM %s WHERE book_id IN (%s)" % (t, ph), chunk)
            except Exception:
                pass
        c.commit()


def _insert_batch(batch):
    import sqlite3
    for attempt in range(6):
        try:
            c = db.get_conn()
            c.executemany("INSERT OR IGNORE INTO books (path,title,author,category,clc,ddc,ext,size,created_at,updated_at)"
                          " VALUES (?,?,?,?,?,?,?,?,?,?)", batch)
            c.commit()
            return
        except sqlite3.OperationalError as e:
            if "locked" in str(e).lower() and attempt < 5:
                time.sleep(5)
                continue
            raise


def start_import(base=None):
    """后台线程执行扫描+搬移入库；已在运行则直接返回 running=True。
    base：源目录绝对路径（如 /Media2/Download），为空时用 DEFAULT_BASE。"""
    base = (base or DEFAULT_BASE or "").strip().rstrip("/")
    if not base.startswith("/"):
        return {"running": False, "started": False, "error": "源目录必须是绝对路径（以 / 开头）"}
    with _state["lock"]:
        if _state["running"]:
            return {"running": True, "started": False}
        _state["running"] = True
        _state["phase"] = "scan"
        _state["files_found"] = 0
        _state["result"] = None
        _state["error"] = None
        _state["base"] = base

    def worker():
        _t0 = time.time()
        try:
            manifest = _scan(base)
            if not manifest.get("files"):
                err = "源目录 %s 下未发现任何文件（目录不存在、不可访问或为空）" % base
                if manifest.get("errors"):
                    err += "：" + str(manifest["errors"][0][1])
                _set(error=err, phase="")
                _save_log(None, error=err, st0=_t0)
                return
            _set(phase="import")
            rpt = _move_import(manifest, base)
            rpt["scan_errors"] = len(manifest.get("errors", []))
            rpt["base"] = base
            _set(result=rpt, phase="", time=db.now())
            _save_log(rpt, st0=_t0)
        except Exception as e:
            _set(error=str(e), phase="")
            _save_log(None, error=str(e), st0=_t0)
        finally:
            with _state["lock"]:
                _state["running"] = False
    threading.Thread(target=worker, daemon=True, name="xunlei-import").start()
    return {"running": True, "started": True}


LOG_FILE = os.path.join(config.DATA_DIR, "xunlei_import_log.json")


def _save_log(rpt, error=None, st0=None):
    """把任务结果写入日志文件（管理员后台“任务日志”展示），保留最近 10 次"""
    try:
        import json as _json
        logs = []
        if os.path.exists(LOG_FILE):
            try:
                with open(LOG_FILE, encoding="utf-8") as f:
                    logs = _json.load(f)
            except Exception:
                logs = []
        entry = {"time": db.now(),
                 "running_time": round((time.time() - (st0 or time.time())), 1),
                 "error": error, "result": rpt}
        logs.append(entry)
        with open(LOG_FILE, "w", encoding="utf-8") as f:
            _json.dump(logs[-10:], f, ensure_ascii=False, indent=1)
    except Exception:
        pass


def get_log():
    """返回最近的任务日志列表（供 /api/admin/xunlei-import/log）"""
    try:
        if os.path.exists(LOG_FILE):
            with open(LOG_FILE, encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return []


if __name__ == "__main__":
    _base = sys.argv[1] if len(sys.argv) > 1 else None
    r = start_import(_base)
    print("任务已启动:", r)
    if r.get("error"):
        print("失败:", r["error"])
        sys.exit(1)
    while True:
        st = xunlei_status()
        if st["running"]:
            p = st["phase"]
            print("进度: %s %s" % (p, "已发现 %d 个文件" % st["files_found"] if p == "scan" else ""), flush=True)
            time.sleep(3)
            continue
        if st["error"]:
            print("失败:", st["error"])
            break
        rpt = st["result"]
        print("=== 移动入库完成 ===")
        print("总文件:", rpt["total_files"], "| 非电子书:", rpt["not_book"],
              "| 与书库同名跳过:", rpt["dup_existing"], "| 迅雷内部同名合并(格式择优):", rpt["dup_internal"], "| 替换库内旧格式:", rpt.get("replaced", 0),
              "| 移动入库:", rpt["imported"], "| 源缺失:", rpt["missing_source"],
              "| 移动失败:", rpt["move_failed"],
              "| 扫描%.0fs 搬移%.1fs" % (rpt["elapsed_scan"], rpt["elapsed_import"]))
        print("分类分布:", rpt["by_category"])
        break