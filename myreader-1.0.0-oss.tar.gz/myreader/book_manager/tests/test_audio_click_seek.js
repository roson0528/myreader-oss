// 「点章节里的某一句 → 声音跳到那句」的回归（原生 + 网页两条路都要验）。
//
// 背景：站长提的需求「点击章节内的某一段文字，对应的声音也跳到当前位置」。
// 这个功能其实一直挂着 onclick="auSeekTo(章内相对秒)"，但**原生那条路是坏的**：
//   seek 真的发出去了（实测 21911ms，对），可逐句高亮**不动**。
//   因为原生路的逐句高亮完全靠「位置回报」驱动（约 500ms 一次，暂停时压根不来），
//   而 auSeekTo 的原生分支只调了 apSyncUi()（进度条）没调 AUPOnTime()（高亮）。
//   修法：两条路 seek 之后都主动 AUPOnTime()，并解除「手动滚动 6 秒不抢滚动条」，
//   否则用户滚下去点一句，画面一动不动，同样像没点上。
//
// 这个脚本只读服务端数据，不写库表。
const { chromium } = require('playwright-core');
const { execSync } = require('child_process');
const CHROME = '/srv/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome';
const ROOT = '/srv/myreader/book_manager';

let pass = 0, fail = 0;
const ck = (n, ok, extra) => {
  if (ok) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (extra ? '  → ' + extra : '')); }
};
const py = (c) => execSync('venv/bin/python -', { cwd: ROOT, encoding: 'utf8', input: c }).trim();

// 桩一个 Capacitor 插件。★ status() 故意**不返回 positionMs**：
// 真机上暂停时原生也不回报位置，这正是「高亮不跟」的触发条件，
// 所以只有「点完立刻自己重画」才能过。
const BRIDGE = `
window.__nativeCalls = [];
(function () {
  const rec = (n) => function (a) {
    window.__nativeCalls.push({ name: n, arg: a || null });
    if (n === 'status') return Promise.resolve({ version: 5, btLink: true, active: false });
    return Promise.resolve({ ok: true });
  };
  const p = {};
  ['status','startMp3','seek','play','pause','next','prev','gotoIndex','setVoice','setRate','stop']
    .forEach(k => { p[k] = rec(k); });
  window.Capacitor = { Plugins: { ListenService: p } };
})();
`;

(async () => {
  const info = JSON.parse(py(`
import sys, json
sys.path.insert(0, '${ROOT}')
import db, auth
u = db.q("SELECT * FROM users WHERE role='admin' AND enabled=1 ORDER BY id LIMIT 1", one=True)
db.ex("DELETE FROM ab_session WHERE user_id=?", (u["id"],))   # 清掉上一轮测试遗留的有声单端锁
# 挑一个「章内至少 8 句、且不是文件内第 1 章」的章 —— 两个坑一起覆盖
c = db.q("""SELECT lib_id, seq, file_seq, start_sec, n_segs FROM ab_lib_chap
             WHERE n_segs >= 8 AND start_sec > 1 ORDER BY lib_id, seq LIMIT 1""", one=True)
print(json.dumps({"tok": auth.create_token(u), "user": dict(u), "c": dict(c)}))`));
  const T = info.c;
  console.log(`  目标：库 ${T.lib_id} 第 ${T.seq} 章（文件 ${T.file_seq}，章内 ${T.n_segs} 句）`);

  const browser = await chromium.launch({
    executablePath: CHROME, args: ['--no-sandbox', '--autoplay-policy=no-user-gesture-required'] });

  for (const mode of ['native', 'web']) {
    const ctx = await browser.newContext({ ignoreHTTPSErrors: true, viewport: { width: 420, height: 900 } });
    await ctx.addInitScript(([t, u]) => {
      localStorage.setItem('bm_token', t); localStorage.setItem('bm_user', u);
      // ★ 固定一个有声会话号：同一个测试里的多个浏览器上下文就是「同一台设备」，
      //   不会自己跟自己抢那把单端锁（真实世界里同一台设备本来就该是同一个 sid）。
      try { sessionStorage.setItem('bm_audio_sid', 'fixclickseek'); } catch (e) {}
    }, [info.tok, JSON.stringify(info.user)]);
    if (mode === 'native') await ctx.addInitScript(BRIDGE);
    const page = await ctx.newPage();
    const errs = [];
    page.on('pageerror', e => errs.push(String(e).slice(0, 90)));
    await page.goto('https://127.0.0.1:9000/', { waitUntil: 'domcontentloaded' });
    await page.waitForFunction(() => typeof audioPlay === 'function', null, { timeout: 20000 });
    await page.waitForTimeout(900);
    await page.evaluate(([lib, ch]) => audioPlay(lib, ch, false), [T.lib_id, T.seq]);
    await page.waitForTimeout(mode === 'native' ? 3000 : 4200);

    const st = await page.evaluate(() => ({
      native: AUP.native, n: AUP.segs.length,
      s5: AUP.segs[5] ? AUP.segs[5].start_sec : null,
      s6: AUP.segs[6] ? AUP.segs[6].start_sec : null,
      txt5: AUP.segs[5] ? AUP.segs[5].text.slice(0, 18) : '',
      chapStart: AUP.chapStart }));
    ck(`${mode}：走${mode === 'native' ? '原生' : '网页'}播放`, st.native === (mode === 'native'), 'native=' + st.native);
    ck(`${mode}：章内有足够的句子`, st.n >= 8, '句数=' + st.n);

    // 模拟「用户先手动滚下去找句子」—— 这会种下 6 秒的滚动锁
    await page.evaluate(() => { AUP.scrollLockUntil = Date.now() + 6000; });
    await page.evaluate(() => { window.__nativeCalls && (window.__nativeCalls.length = 0); });
    await page.click('#aup-l5');
    await page.waitForTimeout(900);

    const r = await page.evaluate(() => {
      const a = Array.from(document.querySelectorAll('.ap-line'));
      const on = a.findIndex(e => e.classList.contains('on'));
      const wrap = document.getElementById('aup-texts');   // ★ 注意是 aup- 不是 ap-
      const cur = document.getElementById('aup-l5');
      return { on,
               txt: on >= 0 ? a[on].textContent.slice(0, 18) : '',
               done: a.filter(e => e.classList.contains('done')).length,
               seeks: (window.__nativeCalls || []).filter(c => c.name === 'seek').map(c => c.arg && c.arg.ms),
               ct: AUP.audio ? AUP.audio.currentTime : null,
               chapStart: AUP.chapStart,
               lock: AUP.scrollLockUntil,
               // 画面有没有跟着滚（点的那句应落在文字区可视范围内）
               scrolled: !!wrap && !!cur &&
                         cur.offsetTop >= wrap.scrollTop - 4 &&
                         cur.offsetTop + cur.clientHeight <= wrap.scrollTop + wrap.clientHeight + 4 };
    });

    ck(`${mode}：★ 点第 5 句后高亮立刻跳到第 5 句（不等位置回报）`,
       r.on === 5, '高亮=' + r.on + ' "' + r.txt + '"');
    ck(`${mode}：★ 高亮的是被点的那句文字`,
       r.txt === st.txt5, JSON.stringify(r.txt) + ' vs ' + JSON.stringify(st.txt5));
    ck(`${mode}：★ 点后解除滚动锁（画面要跟着过去）`, r.lock === 0, 'lock=' + r.lock);
    ck(`${mode}：★ 被点的句子滚进可视区`, r.scrolled);

    if (mode === 'native') {
      ck(`${mode}：★ 真的把 seek 打到原生，且是章内相对毫秒`,
         r.seeks.length >= 1 && Math.abs(r.seeks[r.seeks.length - 1] - Math.round(st.s5 * 1000)) <= 2,
         JSON.stringify(r.seeks) + ' 期望≈' + Math.round(st.s5 * 1000));
    } else {
      ck(`${mode}：★ 网页音频跳到 chapStart + 该句偏移`,
         r.ct !== null && Math.abs(r.ct - (r.chapStart + st.s5)) < 3,
         'currentTime=' + (r.ct === null ? '-' : r.ct.toFixed(2)) + ' 期望≈' + (r.chapStart + st.s5).toFixed(2));
    }

    // 再点第 6 句，确认不是「只能跳一次」
    await page.evaluate(() => { window.__nativeCalls && (window.__nativeCalls.length = 0); });
    await page.click('#aup-l6');
    await page.waitForTimeout(800);
    const r2 = await page.evaluate(() => {
      const a = Array.from(document.querySelectorAll('.ap-line'));
      return { on: a.findIndex(e => e.classList.contains('on')),
               seeks: (window.__nativeCalls || []).filter(c => c.name === 'seek').map(c => c.arg && c.arg.ms),
               ct: AUP.audio ? AUP.audio.currentTime : null };
    });
    ck(`${mode}：★ 连续点第 6 句也跟得上`, r2.on === 6, '高亮=' + r2.on);
    if (mode === 'native') {
      ck(`${mode}：第 6 句的 seek 也是对的`,
         r2.seeks.length >= 1 && Math.abs(r2.seeks[r2.seeks.length - 1] - Math.round(st.s6 * 1000)) <= 2,
         JSON.stringify(r2.seeks));
    } else {
      ck(`${mode}：第 6 句的网页跳转也是对的`,
         r2.ct !== null && Math.abs(r2.ct - (r.chapStart + st.s6)) < 3,
         'currentTime=' + (r2.ct === null ? '-' : r2.ct.toFixed(2)));
    }

    ck(`${mode}：没有 JS 报错`, errs.length === 0, errs[0] || '');
    await ctx.close();
  }
  // ★ 收尾：把自己留下的有声单端锁清掉。
  //   不清的话它会活 40 秒租约，紧接着打开 APP 会误报「正在另一台设备上收听」。
  try {
    py(`import sys; sys.path.insert(0, '${ROOT}')
import db
db.ex("DELETE FROM ab_session WHERE user_id=?", (1,))`);
  } catch (e) {}


  await browser.close();
  console.log(`\n点击文字跳转：${pass} 通过 / ${fail} 失败`);
  process.exit(fail ? 1 : 0);
})();
