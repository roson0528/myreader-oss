#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""阅读统计沉淀（只存不展示，供后期「年度阅读总结」「热门书籍分析」用）

所有数据落在远程 WebDAV（与书籍本体、网站统计同一套存储），目录结构：

    reading_stats/days/<年>/<YYYY-MM-DD>.json   当天明细：用户 × 书籍 × 时段
    reading_stats/users/<uid>/<YYYY>.json       每用户每年：日/周/月时长 + 书单 + 时段分布
    reading_stats/books/<book_id>.json          每本书累计：时长 / 阅读人数 / 阅读次数 / 按天曲线

写入方式与网站统计（stats.py）一致：请求路径里只做**内存自增**，后台线程每 60 秒
落盘一次；落盘失败只记日志、不抛给业务；进程重启不丢当天数据（启动时把当天文件
读回来合并）。业务侧只多一次内存加法，不影响正常访问。

统计口径
--------
* 时长：阅读器每 30 秒心跳上报一次有效秒数（页面可见 + 非渲染中才发），服务端累加
* 阅读次数 opens：同一用户读同一本书，间隔超过 30 分钟算一次新的「开读」
* 阅读人数：同一本书去重后的用户数
* 汇总 rollup：按「日期键覆盖式合并」，同一份日文件反复汇总也不会重复计数（幂等）

手工用法（一般由 cron 每天跑一次汇总）：
    python3 reading_stats.py --rollup          # 汇总最近 3 天（自愈：漏跑的天也补上）
    python3 reading_stats.py --rollup --days 40 # 补历史
    python3 reading_stats.py --prune           # 清理三年以前的数据
    python3 reading_stats.py --status          # 看当前内存/落盘状态
"""
import os
import sys
import json
import time
import threading
from datetime import datetime, timedelta, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config          # noqa: F401  （保持与其它模块一致的导入顺序）
import db
import ftp_service

ROOT = "reading_stats"
RETENTION_DAYS = 365 * 3           # 历史保留三年
FLUSH_SEC = 60                     # 落盘间隔
SESSION_GAP = 30 * 60              # 同一用户同一本书，超过 30 分钟算新的一次开读
MAX_READERS = 5000                 # 单本书最多记这么多阅读用户
MAX_SESSIONS = 20000               # 会话跟踪表上限（防止内存无限增长）

_lock = threading.RLock()
_pending = {}                      # (date, uid) -> {sec, opens, hours{}, books{bid:{sec,opens,title,kind}}}
_last_seen = {}                    # (uid, bid) -> 最后一次心跳的时间戳
_day_cache = {}                    # date -> (doc, ts)
_last_error = ""
_flush_lock = threading.Lock()
_thread = None

_TZ = timezone(timedelta(hours=8))


# ---------------------------------------------------------------- 基础工具
def _bj_now():
    return datetime.now(_TZ)


def today():
    return _bj_now().strftime("%Y-%m-%d")


def _hour():
    return _bj_now().hour


def day_path(date):
    return "%s/days/%s/%s.json" % (ROOT, date[:4], date)


def user_path(uid, year):
    return "%s/users/%s/%s.json" % (ROOT, uid, year)


def book_path(bid):
    return "%s/books/%s.json" % (ROOT, bid)


def log(msg):
    try:
        line = "[%s] %s" % (db.now(), msg)
        path = os.path.join(config.DATA_DIR, "reading_stats.log")
        with open(path, "a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except Exception:
        pass


def _read_json(path):
    global _last_error
    try:
        raw = ftp_service.read_bytes(path)
        if not raw:
            return None
        d = json.loads(raw.decode("utf-8"))
        return d if isinstance(d, dict) else None
    except Exception as e:
        _last_error = ("读 %s: %s" % (path, e))[:200]
        return None


def _write_json(path, doc):
    global _last_error
    try:
        ftp_service.write_bytes(path, json.dumps(doc, ensure_ascii=False).encode("utf-8"))
        return True
    except Exception as e:
        _last_error = ("写 %s: %s" % (path, e))[:200]
        return False


# ---------------------------------------------------------------- 书籍标题缓存
_title_cache = {}                  # bid -> (title, ts)


def book_title(bid):
    """取书名（带 1 小时缓存；心跳里带上，日文件才是自洽的）"""
    try:
        bid = int(bid or 0)
    except Exception:
        return ""
    if not bid:
        return ""
    now = time.time()
    hit = _title_cache.get(bid)
    if hit and now - hit[1] < 3600:
        return hit[0]
    try:
        r = db.q("SELECT title FROM books WHERE id=?", (bid,), one=True)
        t = (r["title"] if r else "") or ""
    except Exception:
        t = ""
    with _lock:
        _title_cache[bid] = (t, now)
        if len(_title_cache) > 5000:
            for k in list(_title_cache)[:2500]:
                _title_cache.pop(k, None)
    return t


# ---------------------------------------------------------------- 记录入口
def record(user_id, book_id=0, seconds=30, kind="", title=""):
    """记一次阅读心跳（只做内存累加，绝不做 I/O）。

    user_id / book_id 缺一就退化成「只记总时长」；旧客户端没带 book_id 也能正常工作。
    """
    try:
        uid = int(user_id or 0)
        bid = int(book_id or 0)
        sec = max(0, min(3600, int(seconds or 0)))
        if not uid or sec <= 0:
            return
        date = today()
        h = _hour()
        now_ts = time.time()
        with _lock:
            key = (date, uid)
            ent = _pending.get(key)
            if ent is None:
                ent = _pending[key] = {"sec": 0, "opens": 0, "hours": {}, "books": {}}
            ent["sec"] += sec
            ent["hours"][str(h)] = ent["hours"].get(str(h), 0) + sec
            if bid:
                bk = ent["books"].get(str(bid))
                if bk is None:
                    bk = ent["books"][str(bid)] = {"sec": 0, "opens": 0,
                                                   "title": str(title or "")[:200],
                                                   "kind": str(kind or "")[:20]}
                bk["sec"] += sec
                if title and not bk.get("title"):
                    bk["title"] = str(title)[:200]
                # 会话判定：隔了 30 分钟以上再读，算新的一次「开读」
                lk = (uid, bid)
                prev = _last_seen.get(lk)
                if prev is None or now_ts - prev > SESSION_GAP:
                    ent["opens"] += 1
                    bk["opens"] += 1
                _last_seen[lk] = now_ts
                if len(_last_seen) > MAX_SESSIONS:
                    for k in list(_last_seen)[:MAX_SESSIONS // 2]:
                        _last_seen.pop(k, None)
    except Exception:
        pass


# ---------------------------------------------------------------- 当天明细落盘
def _blank_day(date):
    return {"date": date, "updated_at": db.now(), "users": {}, "books": {}}


def load_day(date, use_cache=True):
    """读某天明细（带缓存；已封盘的过去日期永不失效）"""
    with _lock:
        hit = _day_cache.get(date)
        if hit and (date < today() or time.time() - hit[1] < 120):
            return hit[0]
    doc = _read_json(day_path(date))
    if not doc:
        return None
    with _lock:
        _day_cache[date] = (doc, time.time())
    return doc


def _merge_pending(doc, date):
    """把内存里的待落盘数据并进当天明细（同一天重复调用结果一致）"""
    with _lock:
        items = [(k[1], v) for k, v in _pending.items() if k[0] == date]
    for uid, ent in items:
        ukey = str(uid)
        ud = doc["users"].get(ukey)
        if ud is None:
            ud = doc["users"][ukey] = {"sec": 0, "opens": 0, "hours": {}, "books": {}}
        ud["sec"] += ent["sec"]
        ud["opens"] += ent["opens"]
        for hh, ss in ent["hours"].items():
            ud["hours"][hh] = ud["hours"].get(hh, 0) + ss
        for bkey, bsrc in ent["books"].items():
            bd = ud["books"].get(bkey)
            if bd is None:
                bd = ud["books"][bkey] = {"sec": 0, "opens": 0,
                                          "title": bsrc.get("title", ""),
                                          "kind": bsrc.get("kind", "")}
            bd["sec"] += bsrc["sec"]
            bd["opens"] += bsrc["opens"]
            if bsrc.get("title") and not bd.get("title"):
                bd["title"] = bsrc["title"]
            # 书籍维度
            book = doc["books"].get(bkey)
            if book is None:
                book = doc["books"][bkey] = {"sec": 0, "opens": 0, "readers": [],
                                             "title": bsrc.get("title", ""),
                                             "kind": bsrc.get("kind", "")}
            book["sec"] += bsrc["sec"]
            book["opens"] += bsrc["opens"]
            if bsrc.get("title") and not book.get("title"):
                book["title"] = bsrc["title"]
            rs = book.setdefault("readers", [])
            if uid not in rs and len(rs) < MAX_READERS:
                rs.append(uid)
    return doc


def flush():
    """把内存累计写进当天的 WebDAV 文件。返回落盘的天数。"""
    if not _flush_lock.acquire(blocking=False):
        return 0
    try:
        with _lock:
            dates = sorted({k[0] for k in _pending})
        saved = 0
        for date in dates:
            doc = load_day(date) or _blank_day(date)
            doc = _merge_pending(doc, date)
            doc["updated_at"] = db.now()
            if _write_json(day_path(date), doc):
                with _lock:
                    for k in [k for k in _pending if k[0] == date]:
                        _pending.pop(k, None)
                    _day_cache[date] = (doc, time.time())
                saved += 1
        return saved
    finally:
        _flush_lock.release()


def _loop():
    # 启动时先把今天已经落盘的数据读回来，避免重启后重复累加
    try:
        load_day(today())
    except Exception:
        pass
    while True:
        time.sleep(FLUSH_SEC)
        try:
            flush()
        except Exception as e:
            log("落盘异常：%s" % e)


def start():
    """启动后台落盘线程（重复调用无害）"""
    global _thread
    with _lock:
        if _thread and _thread.is_alive():
            return False
        _thread = threading.Thread(target=_loop, daemon=True, name="reading-stats-flusher")
        _thread.start()
        return True


# ---------------------------------------------------------------- 汇总（日 → 用户年度 / 书籍累计）
def _recompute_user(ud):
    """按日期键重算用户的日/周/月/时段/书单/连续天数（幂等）"""
    days = ud.get("days") or {}
    day_opens = ud.get("day_opens") or {}
    day_books = ud.get("day_books") or {}
    day_hours = ud.get("day_hours") or {}
    weeks, months, hours = {}, {}, {}
    books = {}
    total_sec = total_opens = 0
    for date in sorted(days):
        sec = int(days.get(date) or 0)
        total_sec += sec
        total_opens += int(day_opens.get(date) or 0)
        try:
            y, w, _ = datetime.strptime(date, "%Y-%m-%d").isocalendar()
            wk = "%d-W%02d" % (y, w)
        except Exception:
            wk = date[:7]
        weeks[wk] = weeks.get(wk, 0) + sec
        months[date[:7]] = months.get(date[:7], 0) + sec
        for hh, ss in (day_hours.get(date) or {}).items():
            hours[str(hh)] = hours.get(str(hh), 0) + int(ss or 0)
        for bid, bd in (day_books.get(date) or {}).items():
            e = books.get(bid)
            if e is None:
                e = books[bid] = {"title": bd.get("title", ""), "kind": bd.get("kind", ""),
                                  "sec": 0, "opens": 0, "days": 0,
                                  "first": date, "last": date}
            e["sec"] += int(bd.get("sec") or 0)
            e["opens"] += int(bd.get("opens") or 0)
            e["days"] += 1
            if date < e["first"]:
                e["first"] = date
            if date > e["last"]:
                e["last"] = date
            if bd.get("title") and not e["title"]:
                e["title"] = bd["title"]
    # 时段分布：按天明细里的 hours 相加
    # 最长连续阅读天数（年度总结的“坚持”指标）
    max_streak = cur = 0
    prev = None
    for date in sorted(days):
        if prev is not None:
            try:
                d1 = datetime.strptime(prev, "%Y-%m-%d")
                d2 = datetime.strptime(date, "%Y-%m-%d")
                cur = cur + 1 if (d2 - d1).days == 1 else 1
            except Exception:
                cur = 1
        else:
            cur = 1
        max_streak = max(max_streak, cur)
        prev = date
    ud["weeks"], ud["months"], ud["hours"] = weeks, months, hours
    ud["books"] = books
    ud["total_sec"], ud["total_opens"] = total_sec, total_opens
    ud["book_count"] = len(books)
    ud["active_days"] = len([d for d in days if int(days.get(d) or 0) > 0])
    ud["max_streak"] = max_streak
    keys = sorted(days)
    ud["first_day"] = keys[0] if keys else ""
    ud["last_day"] = keys[-1] if keys else ""
    return ud


def _recompute_book(bk):
    """按日期键重算书籍累计（幂等）"""
    days = bk.get("days") or {}
    readers = set(bk.get("readers") or [])
    total_sec = total_opens = 0
    for date in sorted(days):
        d = days.get(date) or {}
        total_sec += int(d.get("sec") or 0)
        total_opens += int(d.get("opens") or 0)
        for u in (d.get("readers") or []):
            if len(readers) < MAX_READERS:
                readers.add(int(u))
    bk["total_sec"] = total_sec
    bk["opens"] = total_opens
    bk["readers"] = sorted(readers)[:MAX_READERS]
    # 人数取历史最大值：三年以前的天明细会被清理，但累计人数不该缩水
    bk["reader_count"] = max(int(bk.get("reader_count") or 0), len(readers))
    bk["days_read"] = len([d for d in days if int((days.get(d) or {}).get("sec") or 0) > 0])
    keys = sorted(days)
    bk["first_read"] = keys[0] if keys else ""
    bk["last_read"] = keys[-1] if keys else ""
    return bk


def _book_meta(bid):
    """从库里补作者/分类（书可能已被删，取不到就留空）"""
    try:
        r = db.q("SELECT title, author, category FROM books WHERE id=?", (int(bid),), one=True)
        if r:
            return {"title": r["title"] or "", "author": r["author"] or "",
                    "category": r["category"] or ""}
    except Exception:
        pass
    return {}


def rollup_day(date):
    """把某天的明细汇总进「用户年度文件」和「书籍累计文件」。返回 (用户数, 书籍数)。"""
    doc = load_day(date, use_cache=False)
    if not doc:
        return (0, 0)
    year = date[:4]
    users = doc.get("users") or {}
    books = doc.get("books") or {}
    n_users = n_books = 0
    for uid, ud in users.items():
        uf = _read_json(user_path(uid, year)) or {
            "user_id": int(uid), "year": year,
            "days": {}, "day_opens": {}, "day_books": {}, "day_hours": {}}
        uf.setdefault("days", {})
        uf.setdefault("day_opens", {})
        uf.setdefault("day_books", {})
        uf.setdefault("day_hours", {})
        uf["days"][date] = int(ud.get("sec") or 0)
        uf["day_opens"][date] = int(ud.get("opens") or 0)
        uf["day_books"][date] = {k: {"sec": int(v.get("sec") or 0),
                                     "opens": int(v.get("opens") or 0),
                                     "title": v.get("title", ""),
                                     "kind": v.get("kind", "")}
                                 for k, v in (ud.get("books") or {}).items()}
        uf["day_hours"][date] = {str(h): int(s or 0)
                                 for h, s in (ud.get("hours") or {}).items()}
        uf = _recompute_user(uf)
        uf["updated_at"] = db.now()
        if _write_json(user_path(uid, year), uf):
            n_users += 1
    for bid, bd in books.items():
        bf = _read_json(book_path(bid)) or {"book_id": int(bid), "days": {}}
        bf.setdefault("days", {})
        bf["days"][date] = {"sec": int(bd.get("sec") or 0),
                            "opens": int(bd.get("opens") or 0),
                            "readers": [int(u) for u in (bd.get("readers") or [])][:MAX_READERS]}
        meta = _book_meta(bid)
        for k, v in meta.items():
            if v and not bf.get(k):
                bf[k] = v
        bf["kind"] = bf.get("kind") or bd.get("kind") or ""
        bf["title"] = bf.get("title") or bd.get("title") or ""
        bf = _recompute_book(bf)
        bf["updated_at"] = db.now()
        if _write_json(book_path(bid), bf):
            n_books += 1
    return (n_users, n_books)


def rollup(days=3, include_today=False):
    """汇总最近 N 天（默认只到昨天；cron 在 00:20 跑，昨天一定已封盘）。

    覆盖式合并 → 漏跑/重跑都安全。include_today=True 时连当天一起汇总
    （当天数据还会继续增长，主要用于测试和按需刷新）。
    """
    flush()                                    # 先把内存里的写下去，保证当次汇总完整
    n = 0
    start = 0 if include_today else 1
    for i in range(start, max(start, int(days)) + 1):
        date = (_bj_now() - timedelta(days=i)).strftime("%Y-%m-%d")
        try:
            u, b = rollup_day(date)
            if u or b:
                n += 1
                log("汇总 %s：用户 %d 份 / 书籍 %d 份" % (date, u, b))
        except Exception as e:
            log("汇总 %s 失败：%s" % (date, e))
    return n


def prune(days=RETENTION_DAYS):
    """清理三年以前的数据：删除老日文件 + 收缩用户/书籍文件里的老日期。"""
    cut = (_bj_now() - timedelta(days=days)).strftime("%Y-%m-%d")
    removed = 0
    # 1) 老日文件
    for date in _list_day_dates():
        if date < cut:
            try:
                if ftp_service.delete(day_path(date)):
                    removed += 1
                    with _lock:
                        _day_cache.pop(date, None)
            except Exception:
                pass
    # 2) 用户 / 书籍文件里的老日期（保留累计总数，只删明细）
    for p in _list_paths("%s/users" % ROOT):
        doc = _read_json(p)
        if not doc:
            continue
        changed = False
        for key in ("days", "day_opens", "day_books"):
            m = doc.get(key) or {}
            for date in [d for d in m if d < cut]:
                m.pop(date, None)
                changed = True
        if changed:
            _write_json(p, doc)
    for p in _list_paths("%s/books" % ROOT):
        doc = _read_json(p)
        if not doc:
            continue
        m = doc.get("days") or {}
        old = [d for d in m if d < cut]
        if old:
            for d in old:
                m.pop(d, None)
            _write_json(p, doc)
    log("清理完成：删除 %d 个老日文件（%s 以前）" % (removed, cut))
    return removed


def _list_day_dates():
    """列出所有日文件对应的日期（走 WebDAV 目录列表）"""
    out = []
    try:
        years = ftp_service.list_dir("%s/days" % ROOT) or []
    except Exception:
        return out
    for y in years:
        yname = y.get("name") if isinstance(y, dict) else str(y)
        if not (yname and yname.isdigit()):
            continue
        try:
            files = ftp_service.list_dir("%s/days/%s" % (ROOT, yname)) or []
        except Exception:
            continue
        for f in files:
            fname = f.get("name") if isinstance(f, dict) else str(f)
            if fname.endswith(".json"):
                out.append(fname[:-5])
    return out


def _list_paths(sub):
    """列出某个子目录下的全部 json 文件路径（两层：users/<uid>/<year>.json）"""
    out = []
    try:
        dirs = ftp_service.list_dir(sub) or []
    except Exception:
        return out
    for d in dirs:
        dname = d.get("name") if isinstance(d, dict) else str(d)
        if not dname:
            continue
        try:
            files = ftp_service.list_dir("%s/%s" % (sub, dname)) or []
        except Exception:
            continue
        for f in files:
            fname = f.get("name") if isinstance(f, dict) else str(f)
            if fname.endswith(".json"):
                out.append("%s/%s/%s" % (sub, dname, fname))
    return out


def status():
    """给排查用：内存待落盘、最近错误、缓存天数"""
    with _lock:
        pend = {("%s/u%s" % (k[0], k[1])): {"sec": v["sec"], "books": len(v["books"])}
                for k, v in _pending.items()}
        return {"pending": pend, "last_error": _last_error,
                "cached_days": sorted(_day_cache), "sessions": len(_last_seen)}


# ---------------------------------------------------------------- 命令行
if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="阅读统计：汇总 / 清理 / 状态")
    ap.add_argument("--rollup", action="store_true", help="汇总最近 N 天")
    ap.add_argument("--days", type=int, default=3, help="汇总天数（默认 3，自愈）")
    ap.add_argument("--today", action="store_true", help="连当天一起汇总（默认只到昨天）")
    ap.add_argument("--prune", action="store_true", help="清理三年以前的数据")
    ap.add_argument("--status", action="store_true", help="查看当前状态")
    a = ap.parse_args()
    if a.status:
        print(json.dumps(status(), ensure_ascii=False, indent=1))
    if a.prune:
        print("清理：%d 个老日文件" % prune())
    if a.rollup:
        print("汇总：%d 天有数据" % rollup(days=a.days, include_today=a.today))
    if not (a.status or a.prune or a.rollup):
        ap.print_help()
