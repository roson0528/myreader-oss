#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""共享审核「同名电子书提示」+ 群发按系统消息 + 消息筛选，三个功能的回归测试。

覆盖：
  A. similar.py 纯函数：书名归一化 / 同名相似判定 / 消息备注文案
  B. 功能1：共享申请发给管理员的通知里带「书库中已有同名电子书」备注（进程内，stub 掉通知）
  C. 功能1b：后台共享审核列表带 similar 字段，够前端生成「书库中已存在同名电子书」理由
  D. 功能2：群发按「系统消息」投递（进程内 stub 收件人，**绝不发真实群发**）
  E. 功能3：/api/messages 的 scope 筛选（用 test 账号，HTTP）

安全约定（务必保持）：
  * **不真发群发**：D 段把 db.q / db.add_message 换成假的，只在内存里看参数；
  * **不真发通知**：B 段把 notify.notify_admins 换成收集器；
  * 清理只按本脚本建的**具体 id** 删，绝不按 username LIKE 或 id>快照 这类宽条件。
"""
import os
import sys
import json
import time
import ssl
import uuid
import urllib.request
import urllib.parse
import urllib.error
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
import db
import auth
import similar
import notify

BASE = "https://127.0.0.1:9000"
CTX = ssl._create_unverified_context()
_pass = _fail = 0
_created = {"users": [], "books": [], "share_requests": [], "messages": []}


def check(name, ok, extra=""):
    global _pass, _fail
    print(("  [OK] " if ok else "  [FAIL] ") + name + (("  " + str(extra)) if extra else ""))
    if ok:
        _pass += 1
    else:
        _fail += 1


def req(method, path, token=None, body=None):
    data = json.dumps(body).encode() if body is not None else None
    r = urllib.request.Request(BASE + path, data=data, method=method,
                               headers={'X-BM-No-Push': '1'})   # 测试请求：别真发 Server酱
    if token:
        r.add_header("Authorization", "Bearer " + token)
    if data:
        r.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(r, context=CTX, timeout=60) as resp:
            return resp.status, json.loads(resp.read().decode() or "{}")
    except urllib.error.HTTPError as e:
        raw = e.read().decode()
        try:
            return e.code, json.loads(raw or "{}")
        except Exception:
            return e.code, {"raw": raw[:300]}


def login(un, pw):
    fd = urllib.parse.urlencode({"username": un, "password": pw}).encode()
    r = urllib.request.Request(BASE + "/api/login", data=fd, method="POST")
    with urllib.request.urlopen(r, context=CTX, timeout=30) as resp:
        return json.loads(resp.read().decode())["token"]


def make_user(username, role="user"):
    uid = db.ex("INSERT INTO users (username,password_hash,role,quota,enabled,group_id,name,email,phone,created_at) "
                "VALUES (?,?,?,?,?,?,?,?,?,?)",
                (username, auth.hash_password("zztest"), role, 50, 1, 5, username,
                 username + "@local.test", "19900000000", db.now()))
    _created["users"].append(uid)
    return uid


def make_book(title, owner_id, ext=".epub", size=1024):
    tag = uuid.uuid4().hex[:10]
    bid = db.ex("INSERT INTO books (path,title,author,ext,size,owner_id,created_at,updated_at) "
                "VALUES (?,?,?,?,?,?,?,?)",
                ("_zztest/%s%s" % (tag, ext), title, "测试作者", ext, size, owner_id, db.now(), db.now()))
    _created["books"].append(bid)
    return bid


def cleanup():
    for mid in _created["messages"]:
        db.ex("DELETE FROM messages WHERE id=?", (mid,))
    for rid in _created["share_requests"]:
        db.ex("DELETE FROM share_requests WHERE id=?", (rid,))
    for bid in _created["books"]:
        db.ex("DELETE FROM books WHERE id=?", (bid,))
    for uid in _created["users"]:
        db.ex("DELETE FROM messages WHERE to_id=? OR from_id=?", (uid, uid))
        db.ex("DELETE FROM users WHERE id=?", (uid,))


print("=" * 78)
print("A. similar.py 纯函数")
print("=" * 78)

# 用户举例里的三种写法，归一化后必须是同一个核心书名
SAMPLE = [
    "底层逻辑：看清这个世界的底牌 (刘润) (Z-Library)",
    "底层逻辑：看清这个世界的底牌",
    "A05169. 底层逻辑 看清这个世界的底牌（拥有看透世界的底牌，启动“开挂”的人生。“5分钟商学院”背后的思维方式）.B09JNHKG31",
]
cores = [similar.norm_title(t) for t in SAMPLE]
check("三种写法归一化成同一核心书名", len(set(cores)) == 1, cores[0])
check("核心书名剥掉了作者与 (Z-Library)", cores[0] == "底层逻辑看清这个世界的底牌", cores[0])
check("归一化剥掉前置编号 A05169. 与尾部编码 .B09JNHKG31",
      "a05169" not in cores[0] and "b09jnhkg31" not in cores[0], cores[0])
check("不再残留标点/空格", not any(c in cores[0] for c in " ：:（）()【】."), cores[0])
check("《2021-10《底层逻辑》刘润》剥掉日期前缀", similar.norm_title("2021-10《底层逻辑》刘润") == "底层逻辑刘润",
      similar.norm_title("2021-10《底层逻辑》刘润"))
check("纯数字书名《1984》不被当成编号剥掉", similar.norm_title("1984") == "1984")
check("《三体全集(注释图文典藏版)》→ 三体全集", similar.norm_title("三体全集(注释图文典藏版)") == "三体全集")
check("空书名安全", similar.norm_title("") == "" and similar.norm_title(None) == "")

n = similar.norm_title("底层逻辑：看清这个世界的底牌")
k1, s1 = similar.match_kind(n, similar.norm_title(SAMPLE[2]))
check("完全相同的核心书名 → 同名(1.0)", k1 == "same" and s1 == 1.0, (k1, s1))
k2, s2 = similar.match_kind(n, similar.norm_title("底层逻辑（95后毕业新人…）"))
check("一方是另一方核心子串且够长 → 同名", k2 == "same", (k2, s2, similar.norm_title("底层逻辑（95后…）")))
k3, s3 = similar.match_kind(similar.norm_title("三体"), n)
check("太短的子串不误判（《三体》不该匹配一切）", k3 is None, (k3, s3))
k4, _ = similar.match_kind(n, similar.norm_title("商业的底层逻辑"))
check("只是沾词的不同书 → 不同名", k4 is None)
k5, s5 = similar.match_kind(similar.norm_title("底层逻辑：看清这个世界的底牌（修订版）"), n)
check("括号补充不影响判定", k5 == "same", (k5, s5))

print()
print("=" * 78)
print("B. find_similar 真实书库检索（只读）")
print("=" * 78)
t0 = time.time()
sim = similar.find_similar(SAMPLE[0])
cost = time.time() - t0
same_ids = [x["id"] for x in sim["same"]]
check("检索耗时可接受（< 0.5 秒）", cost < 0.5, "%.3f 秒" % cost)
check("能命中书库里已有的同名书", len(sim["same"]) + sim["more_same"] >= 2,
      "同名 %d 本" % (len(sim["same"]) + sim["more_same"]))
titles = [x["title"] for x in sim["same"]]
check("命中包含《底层逻辑：看清这个世界的底牌》",
      any(t.strip() == "底层逻辑：看清这个世界的底牌" for t in titles), titles[:3])
check("命中包含 A05169 那本（ASIN 尾巴不影响）",
      any("A05169" in t for t in titles), titles[:3])
check("结果带格式与大小（消息要用）",
      all(x["ext"] and isinstance(x["size"], int) for x in sim["same"]),
      [(x["ext"], x["size"]) for x in sim["same"][:2]])
check("短书名《三体》的相似结果有界、不是洪水（不至几十上百条）",
      len(similar.find_similar("三体")["similar"]) <= 20,
      "相似 %d 条" % len(similar.find_similar("三体")["similar"]))
check("短书名《三体》仍然只把核心同名的判为同名",
      all(similar.norm_title(x["title"]) == "三体" for x in similar.find_similar("三体")["same"]),
      [x["title"] for x in similar.find_similar("三体")["same"]])
check("空书名返回空结果",
      not any(similar.find_similar("")["same"]), "ok")
check("exclude_id 生效（把自己排除掉）",
      len([x for x in similar.find_similar("底层逻辑：看清这个世界的底牌",
                                           exclude_id=479531)["same"]
           if x["id"] == 479531]) == 0)

txt = similar.describe(sim)
print("\n  --- 实际生成的备注 ---")
for line in txt.split("\n"):
    print("    " + line)
check("备注首行是「书库中已有同名电子书：」", txt.startswith("书库中已有同名电子书："), txt.split("\n")[0])
check("备注按「1、《书名》格式 EPUB 大小 2.05 MB；」格式编号",
      "1、《" in txt and "》格式" in txt and "大小" in txt and "MB" in txt)
check("条目之间用「；」分隔", "；" in txt or len(sim["same"]) == 1)
check("没有同名/相似书时备注为空", similar.describe({"same": [], "similar": [], "more_same": 0, "more_similar": 0}) == "")
check("short_hint 给出一行短提示", "书库已有同名" in similar.short_hint(sim), similar.short_hint(sim))

print()
print("=" * 78)
print("C. 功能1：共享申请通知里带同名书备注（进程内，不发真实通知）")
print("=" * 78)
u = make_user("zzt_sim_" + uuid.uuid4().hex[:8])
core = "测试同名书" + uuid.uuid4().hex[:6]
other = make_book(core, None, ".azw3", 2883584)                 # 书库里已有的同名书
mine = make_book(core + " (测试上传者) (Z-Library)", u, ".epub", 2150000)

captured = []
real_notify = notify.notify_admins
notify.notify_admins = lambda title, body="", **kw: captured.append((title, body, kw))
try:
    import app as A
    test_user = db.q("SELECT * FROM users WHERE id=?", (u,), one=True)
    check("测试账号不是免审批身份（否则不会通知管理员）", not auth.is_trusted(test_user),
          "is_trusted=%s role=%s" % (auth.is_trusted(test_user), test_user["role"]))
    allowed = A.share_allowed_formats()          # None = 后台没设过，不限制
    if allowed is not None and "epub" not in allowed and allowed:
        db.ex("UPDATE books SET ext=? WHERE id=?", ("." + sorted(allowed)[0], mine))
    check("测试用书可申请共享（否则后面测不到通知）", A.share_format_ok(A._accessible_book_or_404(mine, test_user)),
          "allowed=%s" % (allowed,))
    r = A.share_request(mine, user=test_user)
    check("申请提交成功", r.get("status") == "pending", r)
    if r.get("id"):
        _created["share_requests"].append(r["id"])
    check("给管理员发了通知", len(captured) == 1, len(captured))
    title, body, kw = captured[0] if captured else ("", "", {})
    print("\n  --- 管理员实际收到的消息 ---")
    for line in body.split("\n"):
        print("    " + line)
    check("消息正文仍保留原句（不影响原功能）", "申请共享" in body and "等待审核" in body)
    check("消息正文附上了「书库中已有同名电子书：」", "书库中已有同名电子书：" in body)
    check("备注里列出了书库里那本书的书名", core in body, core)
    check("备注里带该书格式与大小", "AZW3" in body.upper() and "2.75 MB" in body, body[-120:])
    check("备注与自己那本同名书（不在库里）无关：不重复列出自己",
          body.count(core) >= 1)

    # 检索异常不能挡住申请
    captured.clear()
    real_find = similar.find_similar
    similar.find_similar = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("模拟检索炸了"))
    try:
        mine2 = make_book("异常测试书" + uuid.uuid4().hex[:6], u, ".epub", 1000)
        r2 = A.share_request(mine2, user=test_user)
        if r2.get("id"):
            _created["share_requests"].append(r2["id"])
        check("检索异常时申请照常提交", r2.get("status") == "pending", r2)
        check("检索异常时仍会通知管理员（只是没有备注）",
              len(captured) == 1 and "书库中已有同名电子书" not in captured[0][1])
        n = db.q("SELECT COUNT(*) c FROM audit_logs WHERE action='share_similar_fail'", one=True)["c"]
        check("检索异常写入了审计日志便于排查", n >= 1, n)
    finally:
        similar.find_similar = real_find
finally:
    notify.notify_admins = real_notify

print()
print("=" * 78)
print("D. 功能1b：后台共享审核列表带 similar（HTTP，只读）")
print("=" * 78)
admin = db.q("SELECT * FROM users WHERE role='admin' AND enabled=1 ORDER BY id LIMIT 1", one=True)
atok = auth.create_token(admin)
st, d = req("GET", "/api/admin/share-requests?page=1&size=50", token=atok)
check("共享审核列表接口可用", st == 200 and "requests" in d, st)
found = [x for x in (d.get("requests") or []) if x.get("book_id") == mine]
check("我造的申请在列表里", len(found) == 1, len(found))
if found:
    s = found[0].get("similar")
    check("列表条目带 similar 检索结果", isinstance(s, dict) and "same" in s, type(s).__name__)
    check("similar 里能找到书库同名书",
          any(other == x["id"] or core in x["title"] for x in (s or {}).get("same", [])),
          [x["id"] for x in (s or {}).get("same", [])])
    check("前端理由文案所需字段齐全（title/ext/size）",
          all(x.get("title") and x.get("ext") is not None and x.get("size") is not None
              for x in (s or {}).get("same", [])[:1]))
st2, d2 = req("GET", "/api/admin/share-requests?page=1&size=50", token=login("test", "test"))
check("普通会员访问共享审核列表被拒（权限未变）", st2 in (401, 403), st2)

print()
print("=" * 78)
print("E. 功能2：群发按「系统消息」投递（进程内 stub，绝不真发）")
print("=" * 78)
import app as A
sent = []
real_q = db.q
real_add = db.add_message


def fake_q(sql, args=(), one=False):
    if "FROM users WHERE enabled=1" in sql:
        return [{"id": 990001}, {"id": 990002}]
    return real_q(sql, args, one)


db.q = fake_q
db.add_message = lambda *a, **k: sent.append({"args": a, "kw": k})
try:
    admin_user = {"id": admin["id"], "username": admin["username"], "role": "admin",
                  "name": admin["name"] or admin["username"]}
    r = A.message_send(None, {"content": "测试群发内容", "broadcast": True}, user=admin_user)
    check("群发接口返回成功", r.get("ok") and r.get("count") == 2, r)
    recips = [x for x in sent if x["args"][0] in (990001, 990002)]
    check("给每个收件人各写一条消息", len(recips) == 2, len(recips))
    if recips:
        kw = recips[0]["kw"]
        check("群发消息 from_id 为空（界面才会显示「系统消息」）", kw.get("from_id") in (None, ""),
              repr(kw.get("from_id")))
        check("群发消息 kind=system（才算系统消息，可被筛选）", kw.get("kind") == "system", kw.get("kind"))
        check("标题不再含管理员昵称「%s」" % admin_user["name"],
              admin_user["name"] not in (recips[0]["args"][1] or ""), recips[0]["args"][1])
        check("正文原样保留", recips[0]["args"][2] == "测试群发内容")
    receipt = [x for x in sent if x["args"][0] == admin["id"]]
    check("管理员自己那条回执也按系统消息记", len(receipt) == 1 and (receipt[0]["kw"].get("kind") == "system"),
          [(x["args"][0], x["kw"].get("kind")) for x in sent])
finally:
    db.q = real_q
    db.add_message = real_add
n = db.q("SELECT COUNT(*) c FROM audit_logs WHERE action='message_broadcast' AND detail LIKE '%测试%'", one=True)["c"]
# 审计里应记下是谁群发的
last = db.q("SELECT detail FROM audit_logs WHERE action='message_broadcast' ORDER BY id DESC LIMIT 1", one=True)
check("群发仍留审计（并记录发起人）",
      bool(last) and (admin["name"] or "") in (last["detail"] or ""),
      last["detail"] if last else "")
check("stub 生效：真实收件人一条消息都没发", len(sent) > 0 and all(x["args"][0] in (990001, 990002, admin["id"]) for x in sent))

print()
print("=" * 78)
print("F. 功能3：消息筛选 scope（HTTP，test 账号）")
print("=" * 78)
me = db.q("SELECT * FROM users WHERE username='test'", one=True)
mtok = login("test", "test")
system_mid = db.add_message(me["id"], "zzt系统消息", "系统正文", kind="system")
user_mid = db.add_message(me["id"], "zzt用户消息", "用户正文", kind="pm", from_id=admin["id"])
_created["messages"] += [system_mid, user_mid]

st_all, d_all = req("GET", "/api/messages?page=1&page_size=50", token=mtok)
st_def, d_def = req("GET", "/api/messages?page=1&page_size=50&scope=all", token=mtok)
st_u, d_u = req("GET", "/api/messages?page=1&page_size=50&scope=user", token=mtok)
st_s, d_s = req("GET", "/api/messages?page=1&page_size=50&scope=system", token=mtok)
check("四个请求都成功", all(x == 200 for x in (st_all, st_def, st_u, st_s)),
      (st_all, st_def, st_u, st_s))
check("不传 scope 与 scope=all 结果一致（不影响现有功能）",
      d_all.get("total") == d_def.get("total"), (d_all.get("total"), d_def.get("total")))


def ids(d):
    return [x["id"] for x in d.get("items") or []]


check("scope=user 里能看到我造的用户消息", user_mid in ids(d_u))
check("scope=user 里看不到系统消息", system_mid not in ids(d_u))
check("scope=system 里能看到我造的系统消息", system_mid in ids(d_s))
check("scope=system 里看不到用户消息", user_mid not in ids(d_s))
check("scope=user 的每一条都确实有发送人", all(x.get("from_id") for x in d_u.get("items") or []))
check("scope=system 的每一条都确实没有发送人（界面显示「系统消息」）",
      all(not x.get("from_id") for x in d_s.get("items") or []))
check("两个筛选的条数相加 = 全部", d_u.get("total", 0) + d_s.get("total", 0) == d_def.get("total", 0),
      (d_u.get("total"), d_s.get("total"), d_def.get("total")))
check("非法 scope 不报错且按全部处理",
      req("GET", "/api/messages?scope=xxx", token=mtok)[1].get("total") == d_def.get("total"))
check("未读数是总数、不随筛选变化", d_u.get("unread") == d_def.get("unread"))
check("消息里 from_name 仍是「系统」（原来的显示逻辑没动）",
      any((x.get("from_name") == "系统") for x in d_s.get("items") or []) or d_s.get("total") == 0)

cleanup()
print()
print("=" * 78)
print("通过 %d / 失败 %d" % (_pass, _fail))
print("=" * 78)
sys.exit(1 if _fail else 0)
