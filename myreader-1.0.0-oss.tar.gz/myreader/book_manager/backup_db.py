#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""书库数据库自动备份

用途：为「我的阅读」书库做每日快照，确保消息历史、书单、用户等数据
在任何误操作后都能回退。使用 SQLite 在线备份 API，运行中的服务无需停机。

用法：
    venv/bin/python backup_db.py            # 备份一次，保留最近 14 份
    venv/bin/python backup_db.py --keep 30  # 自定义保留份数
    venv/bin/python backup_db.py --no-offsite   # 只做本地备份，跳过异地冗余
    venv/bin/python backup_db.py --list     # 列出已有备份

备份位置：data/backups/library-YYYYmmdd-HHMMSS.db

异地冗余（每次备份自动执行，失败不影响本地备份）：
    1) 跨磁盘副本 → /srv/bookmgr-offsite/      （/dev/sda2，与 /data 不同盘，保留 7 份）
    2) 异地上传   → NAS WebDAV 的 db_backup/          （另一台机器，保留 3 份）
    可用环境变量 BOOKMGR_OFFSITE_DIR 覆盖跨盘副本目录。

恢复方法（整体回退，需停服务）：
    export XDG_RUNTIME_DIR=/run/user/1000
    systemctl --user stop bookmgr.service
    cp data/library.db data/library.db.broken        # 先留证据
    rm -f data/library.db-wal data/library.db-shm    # 注意：WAL 必须一起删掉
    cp data/backups/library-<时间戳>.db data/library.db
    systemctl --user start bookmgr.service

只捞回某张表（例如消息）时不必整体覆盖，可直接把行拷进当前库。
"""
import os
import shutil
import sqlite3
import sys
import time
from datetime import datetime, timedelta, timezone

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

DB_PATH = os.path.join(BASE_DIR, "data", "library.db")
BACKUP_DIR = os.path.join(BASE_DIR, "data", "backups")
DEFAULT_KEEP = 14

# ---------- 异地冗余 ----------
# 本地 14 份备份全部落在 /data（/dev/sdb1）同一块盘上：盘坏、分区损坏或被
# 误删，就没有任何第二副本 —— 这是全套备份体系里最大的单点风险。
# 因此每次备份再多做两份：
#   1) 跨磁盘副本：写到 /home（/dev/sda2，与 /data 不同物理盘）
#   2) 异地上传：经 WebDAV 传到 NAS（另一台机器），防整机丢失
# 两者都失败也不影响本地备份本身（各自 try/except 兜住）。
OFFSITE_DIR = os.environ.get("BOOKMGR_OFFSITE_DIR") or "/srv/bookmgr-offsite"
OFFSITE_KEEP = 7          # 跨盘副本保留份数
DAV_DIR = "db_backup"     # NAS WebDAV 上的目录（相对 FTP_BASE）
DAV_KEEP = 3              # 异机只留最近几份


def beijing_now():
    return datetime.now(timezone.utc) + timedelta(hours=8)


def make_backup(keep=DEFAULT_KEEP, offsite=True):
    os.makedirs(BACKUP_DIR, exist_ok=True)
    stamp = beijing_now().strftime("%Y%m%d-%H%M%S")
    final = os.path.join(BACKUP_DIR, f"library-{stamp}.db")
    tmp = final + ".part"

    src = sqlite3.connect(f"file:{DB_PATH}?mode=ro", uri=True, timeout=60)
    dst = sqlite3.connect(tmp)
    try:
        with dst:
            src.backup(dst)          # 在线热备份，不锁库
    finally:
        dst.close()
        src.close()

    # 校验备份可用后改名
    chk = sqlite3.connect(tmp)
    try:
        ok = chk.execute("PRAGMA integrity_check").fetchone()[0]
        if ok != "ok":
            raise RuntimeError(f"备份完整性校验失败: {ok}")
        counts = {}
        for t in ("users", "messages", "booklists", "books"):
            try:
                counts[t] = chk.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
            except sqlite3.Error:
                counts[t] = -1
    finally:
        chk.close()
    os.replace(tmp, final)

    removed = prune(keep)
    size_mb = os.path.getsize(final) / 1024 / 1024
    print(f"[{beijing_now():%Y-%m-%d %H:%M:%S}] 备份完成 {os.path.basename(final)} "
          f"({size_mb:.1f} MB) 用户={counts['users']} 消息={counts['messages']} "
          f"书单={counts['booklists']} 图书={counts['books']}"
          + (f" 清理旧备份 {len(removed)} 份" if removed else ""))

    # 异地冗余：任何一步失败都不影响已经落盘的本地备份
    if offsite:
        try:
            p, rm = _offsite_copy(final)
            print(f"    跨盘副本 → {p}" + (f"（清理 {len(rm)} 份）" if rm else ""))
        except Exception as e:
            print(f"    跨盘副本失败：{type(e).__name__}: {e}")
        try:
            p, rm = _dav_upload(final)
            print(f"    异地上传 → NAS:{p}" + (f"（清理 {len(rm)} 份）" if rm else ""))
        except Exception as e:
            print(f"    异地上传失败：{type(e).__name__}: {e}")
    return final


def _offsite_copy(final):
    """把刚生成的备份复制到另一块物理盘（/data=sdb1，/home=sda2）。"""
    os.makedirs(OFFSITE_DIR, exist_ok=True)
    name = os.path.basename(final)
    dst = os.path.join(OFFSITE_DIR, name)
    tmp = dst + ".part"
    shutil.copy2(final, tmp)
    os.replace(tmp, dst)          # 原子落位，避免半成品被当成有效副本
    fs = sorted(f for f in os.listdir(OFFSITE_DIR)
                if f.startswith("library-") and f.endswith(".db"))
    removed = []
    if OFFSITE_KEEP > 0 and len(fs) > OFFSITE_KEEP:
        for f in fs[:-OFFSITE_KEEP]:
            try:
                os.remove(os.path.join(OFFSITE_DIR, f))
                removed.append(f)
            except OSError:
                pass
    return dst, removed


def _dav_upload(final):
    """上传到 NAS（另一台机器）。ftp_service.upload_file 会自动建父目录。"""
    import ftp_service
    name = os.path.basename(final)
    ftp_service.upload_file(final, f"{DAV_DIR}/{name}")
    # 远端保留最近 DAV_KEEP 份（文件名自带时间戳，字典序即时间序）
    removed = []
    try:
        items = ftp_service.list_dir(DAV_DIR) or []
    except Exception:
        items = []
    names = sorted(it["name"] for it in items
                   if isinstance(it, dict) and (it.get("name") or "").endswith(".db"))
    if DAV_KEEP > 0 and len(names) > DAV_KEEP:
        for n in names[:-DAV_KEEP]:
            try:
                ftp_service.delete(f"{DAV_DIR}/{n}")
                removed.append(n)
            except Exception:
                pass
    return f"{DAV_DIR}/{name}", removed


def backups():
    if not os.path.isdir(BACKUP_DIR):
        return []
    fs = [os.path.join(BACKUP_DIR, f) for f in os.listdir(BACKUP_DIR)
          if f.startswith("library-") and f.endswith(".db")]
    return sorted(fs)


def prune(keep=DEFAULT_KEEP):
    fs = backups()
    removed = fs[:-keep] if keep > 0 and len(fs) > keep else []
    for f in removed:
        try:
            os.remove(f)
        except OSError:
            pass
    # 清掉中断留下的临时文件
    for f in os.listdir(BACKUP_DIR):
        if f.endswith(".part"):
            try:
                os.remove(os.path.join(BACKUP_DIR, f))
            except OSError:
                pass
    return removed


def main():
    args = sys.argv[1:]
    if "--list" in args:
        fs = backups()
        if not fs:
            print("暂无备份")
        for f in fs:
            st = os.stat(f)
            print(f"{os.path.basename(f)}  {st.st_size/1024/1024:8.1f} MB  "
                  f"{datetime.fromtimestamp(st.st_mtime):%Y-%m-%d %H:%M:%S}")
        print(f"共 {len(fs)} 份，目录 {BACKUP_DIR}")
        return
    keep = DEFAULT_KEEP
    if "--keep" in args:
        keep = int(args[args.index("--keep") + 1])
    make_backup(keep, offsite="--no-offsite" not in args)


if __name__ == "__main__":
    main()
