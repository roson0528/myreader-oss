# 部署

下面是一台 Linux 服务器从零到跑起来的完整流程，生产实践里用 systemd 守护 + Nginx 反代。

## 1. 准备

```bash
# Python 3.10+
python3 -V
# 可选系统命令
apt install -y ffmpeg catdoc
# calibre 提供 ebook-convert（mobi/azw3 → epub），按官方方式安装即可

sudo mkdir -p /srv/myreader && sudo chown "$USER" /srv/myreader
git clone <本仓库> /srv/myreader/app   # 或解压 tar.gz
```

## 2. 依赖与配置

```bash
cd /srv/myreader/app
python3 -m venv venv
./venv/bin/pip install -r requirements.txt

cp .env.example .env
$EDITOR .env        # BOOKMGR_SECRET / 存储后端 / 管理员口令
```

`config.py`、`report_sync.py` 都从环境变量取值，**不要把 .env 提交到仓库**（`.gitignore` 已忽略）。

## 3. 建库与首启

```bash
cd book_manager
../venv/bin/python -c "import db; db.init_db()"
bash start.sh                     # 前台跑一次，确认能起来
```

访问 `http://<ip>:9000`，用 `BOOKMGR_ADMIN_USER`/`BOOKMGR_ADMIN_PASS` 登录，**立刻改口令**，然后到后台配置：

- 存储后端（WebDAV/FTP 地址、账号、书库根目录）
- 下载通道域名（`link_base`，留空=同源）
- 站点名称、公告、注册开关

## 4. systemd 常驻

`/etc/systemd/system/myreader.service`：

```ini
[Unit]
Description=myreader book service
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=myreader
WorkingDirectory=/srv/myreader/app/book_manager
EnvironmentFile=/srv/myreader/app/.env
ExecStart=/srv/myreader/app/venv/bin/python -m uvicorn app:app --host 127.0.0.1 --port 9000
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now myreader
sudo systemctl status myreader
curl -s localhost:9000/api/health
```

## 5. 反向代理（Nginx）

```nginx
server {
    listen 443 ssl http2;
    server_name reader.example.com;

    ssl_certificate     /etc/letsencrypt/live/reader.example.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/reader.example.com/privkey.pem;

    client_max_body_size 200m;          # 上传电子书/安装包

    location / {
        proxy_pass http://127.0.0.1:9000;
        proxy_http_version 1.1;
        proxy_set_header Host              $host;
        proxy_set_header X-Real-IP         $remote_addr;
        proxy_set_header X-Forwarded-For   $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 300s;        # 大文件下载 / 转换
        proxy_buffering off;            # 流式返回（PDF、音频）
    }
}
```

> 站内所有链接默认**同源相对路径**；只有「图书下载」和「App 安装包」走后台配置的下载通道域名（`link_base`），适合让下载走另一条链路。

## 6. 定时任务

```cron
# 每 5 分钟同步技术报告投放区（新增/更新/回收）
*/5 * * * * cd /srv/myreader/app/book_manager && ../venv/bin/python report_sync.py >> data/report_sync.log 2>&1

# 每天 04:10 备份数据库
10 4 * * * cd /srv/myreader/app/book_manager && ../venv/bin/python backup_db.py >> data/backup.log 2>&1

# 每周清一次缓存
30 4 * * 1 cd /srv/myreader/app/book_manager && ../venv/bin/python tools/clean_cache.py
```

## 7. 升级

```bash
cd /srv/myreader/app
git pull                              # 或解压新包覆盖代码，别覆盖 data/
./venv/bin/pip install -r requirements.txt
systemctl restart myreader
curl -s localhost:9000/api/health
```

**数据库迁移**在 `db.py` 的 `init_db()` 里做（`CREATE TABLE IF NOT EXISTS` + 补列），启动即自动执行，不需要单独迁移命令。升级前建议先跑一次 `backup_db.py`。

## 8. 备份与恢复

- 逻辑备份：`backup_db.py` 用 `sqlite3 VACUUM INTO` 生成一致性快照（含 WAL 未落盘事务）。
- 数据面：书本身在存储后端，本地只有缓存，**备份优先级：数据库 > .env > 存储后端**。
- 恢复：停服务 → 覆盖 `data/library.db` → 起服务 → `curl /api/health`。

## 9. 常见问题

| 现象 | 原因 / 处理 |
| --- | --- |
| 首页能开、书打不开 | 存储后端连不上：看 `data/*.log`，用 `ftp_service.list_dir("/")` 单独验证 |
| 改了文档阅读器还是旧内容 | 检查 `books.updated_at` 是否更新（同步任务是否跑）、`data/cache/b{id}_*` 是否残留 |
| 书架数量和目录不一致 | 跑一次 `report_sync.py`（会回收源文件已删除的书），或看日志里「移除 N」 |
| 上传大文件 413 | Nginx `client_max_body_size` |
| mobi/azw3 打不开 | 没装 calibre，或 `ebook-convert` 不在 PATH |
