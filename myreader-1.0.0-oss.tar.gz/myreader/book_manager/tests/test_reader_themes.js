/* 阅读器「阅读设置 → 背景」风格：4 个纯色 + 4 个质感（羊皮纸/牛皮纸/纸纹/竹青）
 *
 * 站点主 2026-10-14 要求：「阅读设置里可否多加几个背景风格？比如羊皮纸和多看阅读的
 * 背景质感风格」。质感全部是 CSS 渐变，不引外部图片（阅读器跑在 WebView 里）。
 *
 * ★ 这个测试刻意“量化”而不是截图：本机没有能看图的眼睛，所以用
 *   ①计算后的 background-color / background-image 判断主题真的换了、
 *   ②按 WCAG 公式算正文与底色的对比度（≥4.5 才算能看），
 *   ③量圆点行有没有顶出抽屉（320px 手机 + 系统大字体）。
 *
 * 跑法：NODE_PATH=/tmp/pwtest/node_modules node tests/test_reader_themes.js
 */
const { chromium } = require('playwright-core');
const { execSync } = require('child_process');
const CHROME = '/srv/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome';
const ROOT = '/srv/myreader/book_manager';
const BASE = 'https://127.0.0.1:9000';
const BOOK = +(process.argv[2] || 31);

const THEMES = [
  { key: 'light', name: '白色', textured: false },
  { key: 'sepia', name: '米黄', textured: false },
  { key: 'green', name: '护眼绿', textured: false },
  { key: 'dark', name: '夜间', textured: false },
  { key: 'parchment', name: '羊皮纸', textured: true },
  { key: 'kraft', name: '牛皮纸', textured: true },
  { key: 'paper', name: '纸纹', textured: true },
  { key: 'bamboo', name: '竹青', textured: true },
  { key: 'linen', name: '亚麻', textured: true },
  { key: 'silver', name: '银灰', textured: true },
];

let pass = 0, fail = 0;
const ok = (c, m) => { if (c) { pass++; console.log('  ✓ ' + m); } else { fail++; console.log('  ✗ ' + m); } };

function creds(pyUser) {
  return JSON.parse(execSync('venv/bin/python -', {
    cwd: ROOT, encoding: 'utf8',
    input: `import sys, json
sys.path.insert(0, '${ROOT}')
import db, auth
u = db.q("SELECT * FROM users WHERE username='${pyUser}' AND enabled=1 LIMIT 1", one=True)
print(json.dumps({"token": auth.create_token(u), "user": dict(u)}))
`}).trim());
}

(async () => {
  const me = creds('test');

  const b = await chromium.launch({ executablePath: CHROME, args: ['--no-sandbox'] });
  const ctx = await b.newContext({ ignoreHTTPSErrors: true, viewport: { width: 390, height: 844 },
    isMobile: true, hasTouch: true, deviceScaleFactor: 2 });
  await ctx.setExtraHTTPHeaders({ 'Cache-Control': 'no-cache' });
  await ctx.addInitScript(([t, u]) => {
    localStorage.setItem('bm_token', t); localStorage.setItem('bm_user', u);
  }, [me.token, JSON.stringify(me.user)]);

  const p = await ctx.newPage();
  const errs = [];
  p.on('pageerror', e => errs.push(String(e)));
  await p.goto(BASE + '/reader?id=' + BOOK, { waitUntil: 'domcontentloaded' });
  await p.waitForTimeout(3500);

  // ---------- 页面真的读到正文了（不然下面测的都是空气） ----------
  const body = await p.evaluate(() => {
    const el = document.querySelector('#chapter-html, #txt-content');
    return { text: el ? (el.innerText || '').trim().length : 0, cls: document.body.className };
  });
  ok(body.text > 200, '阅读器正常打开了正文（' + body.text + ' 字）');
  // 记下测试账号原本用的背景，跑完点回去（设置存在服务端，不能靠 SQL 快照）
  const origTheme = (body.cls.match(/th-([a-z]+)/) || [])[1] || 'sepia';
  console.log('  · 测试账号原来的背景是「' + origTheme + '」，跑完会点回去');

  // ---------- 打开设置抽屉 ----------
  // ★ 阅读器打开抽屉的函数叫 toggleDrawer('settings')（不是 openDrawer）；
  //   之前写错了名字又被 typeof 守卫吞掉，于是「抽屉没开」→ 量到的宽高全是 0 却看着像通过。
  await p.evaluate(() => { toggleDrawer('settings'); });
  await p.waitForTimeout(400);
  const opened = await p.evaluate(() => !document.getElementById('drawer-settings').classList.contains('hidden'));
  ok(opened, '设置抽屉确实打开了（后面量尺寸的前提）');
  const dots = await p.$$eval('.theme-dot', els => els.map(e => ({
    theme: e.dataset.theme || '', title: e.title || '', cls: e.className })));
  ok(dots.length === 10, '设置里有 10 个背景圆点（现有 ' + dots.length + ' 个）');
  const keys = dots.map(d => d.theme).join(',');
  ok(keys === 'light,sepia,green,dark,parchment,kraft,paper,bamboo,linen,silver',
    '10 个圆点的顺序与主题 key 都对（' + keys + '）');
  ok(dots.every(d => d.title && d.cls.indexOf('t-' + d.theme) >= 0),
    '每个圆点都有名字（悬浮提示）和对应配色样式');

  // ---------- 字体色：「透明」已下线，只剩纯白/纯黑 ----------
  const fcs = await p.$$eval('.fc-opt', els => els.map(e => ({
    color: e.dataset.color || '', text: (e.innerText || '').trim(), active: e.classList.contains('active') })));
  ok(fcs.length === 2, '字体色只剩 2 个选项（现有 ' + fcs.length + ' 个：' + fcs.map(f => f.text).join('/') + '）');
  ok(!fcs.some(f => f.color === 'transparent' || f.text.indexOf('透明') >= 0),
    '「透明」字体色已经删掉（页面上找不到它）');
  ok(fcs.map(f => f.color).join(',') === '#ffffff,#1f2430', '剩下的是纯白与纯黑（' + fcs.map(f => f.color).join(',') + '）');
  const afterWhite = await p.evaluate(() => {
    setFontColor(document.querySelector('.fc-opt[data-color="#ffffff"]'));
    return getComputedStyle(document.getElementById('r-content')).color;
  });
  ok(afterWhite === 'rgb(255, 255, 255)', '点「纯白」正文真的变白（' + afterWhite + '）');
  const backAuto = await p.evaluate(() => {
    setFontColor(document.querySelector('.fc-opt[data-color="#1f2430"]'));
    const c = getComputedStyle(document.getElementById('r-content')).color;
    settings.font_color = ''; setBg(settings.theme);
    return { picked: c, auto: getComputedStyle(document.getElementById('r-content')).color };
  });
  ok(backAuto.picked === 'rgb(31, 36, 48)' && backAuto.auto !== 'rgba(0, 0, 0, 0)',
    '点「纯黑」生效，清空后又回到跟随主题的自动配色（' + backAuto.picked + ' → ' + backAuto.auto + '）');

  // ---------- 逐个点亮，量背景/字色/对比度 ----------
  const seen = {};
  for (const t of THEMES) {
    await p.evaluate(k => { setTheme(document.querySelector('.theme-dot[data-theme="' + k + '"]')); }, t.key);
    await p.waitForTimeout(250);
    const r = await p.evaluate(() => {
      const cs = getComputedStyle(document.body);
      const lum = c => {
        const m = (c.match(/\d+(\.\d+)?/g) || []).slice(0, 3).map(Number).map(v => {
          v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
        });
        return 0.2126 * m[0] + 0.7152 * m[1] + 0.0722 * m[2];
      };
      const fg = getComputedStyle(document.getElementById('r-content')).color;
      const l1 = lum(cs.backgroundColor), l2 = lum(fg);
      return {
        cls: document.body.className,
        bg: cs.backgroundColor,
        img: cs.backgroundImage,
        fg: fg,
        ratio: (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05),
        active: document.querySelectorAll('.theme-dot.active').length,
        activeKey: (document.querySelector('.theme-dot.active') || {}).dataset
          ? document.querySelector('.theme-dot.active').dataset.theme : '',
        text: (document.querySelector('#chapter-html, #txt-content').innerText || '').trim().length,
      };
    });
    seen[t.key] = r;
    const textured = r.img && r.img !== 'none';
    ok(r.cls.indexOf('th-' + t.key) >= 0, '「' + t.name + '」选中后 body 挂上 th-' + t.key + '（' + r.cls + '）');
    ok(textured === t.textured,
      '「' + t.name + '」' + (t.textured ? '有纹理' : '是纯色') + '（background-image ' +
      (textured ? '有 ' + r.img.split('gradient').length + ' 层渐变' : '为 none') + '）');
    ok(r.active === 1 && r.activeKey === t.key, '「' + t.name + '」只有一个圆点高亮且就是它自己');
    ok(r.ratio >= 4.5, '「' + t.name + '」正文字色对比度 ' + r.ratio.toFixed(2) + ':1 ≥ 4.5（' + r.fg + ' on ' + r.bg + '）');
    ok(r.text > 200, '「' + t.name + '」换背景后正文还在（' + r.text + ' 字）');
  }
  ok(seen.parchment.img !== seen.paper.img && seen.kraft.img !== seen.parchment.img,
    '6 个质感主题的纹理各不相同（不是同一张图换色）');
  ok(new Set(THEMES.filter(t => t.textured).map(t => seen[t.key].img)).size === 6,
    '6 个质感主题各是一套独立纹理（' + new Set(THEMES.filter(t => t.textured).map(t => seen[t.key].img)).size + ' 套）');
  ok(new Set(THEMES.map(t => seen[t.key].bg)).size === 10,
    '10 个主题的底色互不相同（' + new Set(THEMES.map(t => seen[t.key].bg)).size + ' 种）');

  // ---------- 窄屏 + 系统大字体：圆点不能顶出抽屉 ----------
  await p.setViewportSize({ width: 320, height: 720 });
  await p.evaluate(() => { document.documentElement.style.fontSize = '21px'; });
  await p.waitForTimeout(400);
  const wide = await p.evaluate(() => {
    const row = document.querySelector('.theme-row');
    const dr = document.getElementById('drawer-settings');
    const rr = row.getBoundingClientRect(), dd = dr.getBoundingClientRect();
    const tops = Array.prototype.map.call(row.children, c => Math.round(c.getBoundingClientRect().top));
    return { rowW: Math.round(rr.width), rowSW: row.scrollWidth, rowRight: Math.round(rr.right),
      drawerRight: Math.round(dd.right), drawerSW: dr.scrollWidth, drawerCW: dr.clientWidth,
      rows: new Set(tops).size };
  });
  ok(wide.rowSW <= wide.rowW + 1, '320px + 大字体下圆点行没有横向溢出（scrollW ' + wide.rowSW + ' ≤ ' + wide.rowW + '）');
  ok(wide.rowRight <= wide.drawerRight + 1, '圆点行没有顶出抽屉右边缘（' + wide.rowRight + ' ≤ ' + wide.drawerRight + '）');
  ok(wide.drawerSW <= wide.drawerCW + 1, '抽屉本身没有横向滚动（scrollW ' + wide.drawerSW + ' ≤ clientW ' + wide.drawerCW + '）');
  ok(wide.rows >= 2, '圆点自动折成了 ' + wide.rows + ' 行（不是硬挤在一行）');
  await p.evaluate(() => { document.documentElement.style.fontSize = ''; });

  // ---------- 换了主题要能记住（刷新后还在） ----------
  await p.setViewportSize({ width: 390, height: 844 });
  await p.evaluate(() => { setTheme(document.querySelector('.theme-dot[data-theme="parchment"]')); });
  await p.waitForTimeout(900);
  await p.reload({ waitUntil: 'domcontentloaded' });
  await p.waitForTimeout(3500);
  const after = await p.evaluate(() => ({
    cls: document.body.className, img: getComputedStyle(document.body).backgroundImage,
    text: (document.querySelector('#chapter-html, #txt-content').innerText || '').trim().length,
  }));
  ok(after.cls.indexOf('th-parchment') >= 0 && after.img !== 'none',
    '重开阅读器仍是羊皮纸（' + after.cls + '）');
  ok(after.text > 200, '重开后正文照常显示（' + after.text + ' 字）');

  // ---------- 落到一个陌生主题名也不能白屏（老数据/脏数据兜底） ----------
  const fb = await p.evaluate(() => {
    setBg('这不是一个主题');
    const cs = getComputedStyle(document.body);
    return { cls: document.body.className, bg: cs.backgroundColor };
  });
  ok(fb.cls.indexOf('th-sepia') >= 0, '认不出的主题名回落到米黄（' + fb.cls + '），不会白屏');
  // 下线的旧主题 night（墨夜）→ 跳到 silver（银灰），不能让人掉回米黄
  const alias = await p.evaluate(() => {
    setBg('night');
    return { cls: document.body.className, key: themeKey('night'), img: getComputedStyle(document.body).backgroundImage };
  });
  ok(alias.key === 'silver' && alias.cls.indexOf('th-silver') >= 0 && alias.img !== 'none',
    '旧的「墨夜(night)」设置会跳到新的「银灰(silver)」（' + alias.cls + '）');

  ok(errs.length === 0, '全程没有 JS 报错' + (errs.length ? '：' + errs[0].slice(0, 120) : ''));

  // ---------- 把测试账号的背景点回原来的（设置存在服务端，别留下痕迹） ----------
  await p.evaluate(k => { setTheme(document.querySelector('.theme-dot[data-theme="' + k + '"]')); }, origTheme);
  await p.waitForTimeout(1200);
  const back = await p.evaluate(() => document.body.className);
  ok(back.indexOf('th-' + origTheme) >= 0, '已把测试账号的背景还原成「' + origTheme + '」');
  await b.close();

  console.log('\n阅读器背景风格：' + pass + ' 通过 / ' + fail + ' 失败');
  process.exit(fail ? 1 : 0);
})();
