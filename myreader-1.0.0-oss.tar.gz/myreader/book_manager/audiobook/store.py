"""有声书的数据层：自己的表，建在同一个 library.db 里。

为什么不另开一个库文件：后台要跟书本、用户、树叶这些数据放在一起才好备份
（§14.29 的整机备份是拷 library.db），而多开一个库反而要改备份逻辑。
表名统一 `ab_` 前缀，和既有表零交集 —— 既有功能不会看到它们。

建表是**惰性**的（第一次用到才建），所以不需要动 db.py 的 init_db()。
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import db  # noqa: E402

SCHEMA = """
CREATE TABLE IF NOT EXISTS ab_job (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  book_id INTEGER NOT NULL,
  title TEXT NOT NULL DEFAULT '',
  line TEXT NOT NULL DEFAULT '',
  voice TEXT NOT NULL DEFAULT '',
  chapters_per_file INTEGER NOT NULL DEFAULT 1,
  status TEXT NOT NULL DEFAULT 'queued',
  stage TEXT NOT NULL DEFAULT '',
  ai_enabled INTEGER NOT NULL DEFAULT 0,
  ai_chars TEXT NOT NULL DEFAULT '{}',
  bgm TEXT NOT NULL DEFAULT '[]',
  bgm_volume REAL NOT NULL DEFAULT 0.12,
  dest TEXT NOT NULL DEFAULT '',
  total_chapters INTEGER NOT NULL DEFAULT 0,
  total_files INTEGER NOT NULL DEFAULT 0,
  done_files INTEGER NOT NULL DEFAULT 0,
  total_segs INTEGER NOT NULL DEFAULT 0,
  done_segs INTEGER NOT NULL DEFAULT 0,
  error TEXT NOT NULL DEFAULT '',
  created_by INTEGER,
  created_at TEXT NOT NULL DEFAULT '',
  updated_at TEXT NOT NULL DEFAULT '',
  finished_at TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS ab_file (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  job_id INTEGER NOT NULL,
  seq INTEGER NOT NULL,
  name TEXT NOT NULL DEFAULT '',
  a INTEGER NOT NULL DEFAULT 0,
  b INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'pending',
  remote TEXT NOT NULL DEFAULT '',
  bytes INTEGER NOT NULL DEFAULT 0,
  seconds REAL NOT NULL DEFAULT 0,
  err TEXT NOT NULL DEFAULT '',
  updated_at TEXT NOT NULL DEFAULT '',
  UNIQUE(job_id, seq)
);
CREATE TABLE IF NOT EXISTS ab_seg (
  job_id INTEGER NOT NULL,
  file_seq INTEGER NOT NULL,
  idx INTEGER NOT NULL,
  voice TEXT NOT NULL DEFAULT '',
  speaker TEXT NOT NULL DEFAULT '',
  cache TEXT NOT NULL DEFAULT '',
  seconds REAL NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT '',
  PRIMARY KEY (job_id, file_seq, idx)
);
CREATE TABLE IF NOT EXISTS ab_cfg (
  k TEXT PRIMARY KEY,
  v TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS ix_ab_file_job ON ab_file(job_id, seq);
CREATE INDEX IF NOT EXISTS ix_ab_seg_job ON ab_seg(job_id, file_seq);
"""

_ready = False


def init():
    """惰性建表 + 补列。可重复调用。"""
    global _ready
    if _ready:
        return
    for stmt in SCHEMA.strip().split(";"):
        s = stmt.strip()
        if s:
            db.ex(s)
    _migrate()
    _ready = True


# 后加的列：老库里的表已经建好了，CREATE TABLE IF NOT EXISTS 不会补列，
# 只能自己 ALTER。每项 (列名, 建列 SQL 片段)。
_MIGRATE = (
    ("gap_ms", "gap_ms INTEGER NOT NULL DEFAULT 400"),
    ("chap_gap_ms", "chap_gap_ms INTEGER NOT NULL DEFAULT 1000"),
    ("skip_front", "skip_front INTEGER NOT NULL DEFAULT 1"),
    # 制作完成后是否把成品登记进「有声」页面，以及归到哪个分类（0=未分类）。
    # 存在任务行上而不是内存里：任务重启后会续跑，勾没勾必须还在。
    ("to_lib", "to_lib INTEGER NOT NULL DEFAULT 0"),
    ("lib_cat", "lib_cat INTEGER NOT NULL DEFAULT 0"),
    ("skipped", "skipped TEXT NOT NULL DEFAULT ''"),
    # 分文件方式：chapters=每 N 章一个（默认，老行为） / balanced=按预估时长均衡划分
    ("split_mode", "split_mode TEXT NOT NULL DEFAULT 'chapters'"),
    ("target_min", "target_min INTEGER NOT NULL DEFAULT 40"),
    ("max_min", "max_min INTEGER NOT NULL DEFAULT 60"),
    # 只做指定章节（1 起、含两端）。0 表示不做限制 = 整本。
    # 起因：很多小说每章人物都不同，全书一个音色表不合适；
    # 人只想先做第 3 章听听效果，也没必要等整本几十小时。
    ("chap_from", "chap_from INTEGER NOT NULL DEFAULT 0"),
    ("chap_to", "chap_to INTEGER NOT NULL DEFAULT 0"),
)


def _migrate():
    """给老库补新列 / 换新主键。已经对的不动，可重复调用。"""
    try:
        have = set(r["name"] for r in db.q("PRAGMA table_info(ab_job)"))
        for col, ddl in _MIGRATE:
            if col not in have:
                db.ex("ALTER TABLE ab_job ADD COLUMN %s" % ddl)
    except Exception:
        # 补列失败不能把整个模块带崩（最坏就是新功能不可用）
        import traceback
        traceback.print_exc()
    try:
        _migrate_seg_pk()
    except Exception:
        import traceback
        traceback.print_exc()


def _migrate_seg_pk():
    """把 ab_seg 的主键从 (job_id, idx) 换成 (job_id, file_seq, idx)。

    ★ 老主键是 (job_id, idx)，**不含 file_seq**，等于说"一个任务里同一个句序号
      只能有一行"。后果很严重：只要两个文件的分句记录同时存在（比如重跑某个
      文件、或者跳过版权页删记录），后来的那个文件的同序号记录会把先前的**直接
      顶掉** —— 实测重跑文件 1 时，文件 3 已经合成好的 283 条记录被吃掉到 0 条，
      等于白合成一遍。新主键让每个文件各占一份，互不干扰。

    SQLite 改不了主键，只能建新表搬数据。
    """
    row = db.q("SELECT sql FROM sqlite_master WHERE type='table' AND name='ab_seg'", one=True)
    if not row or not row["sql"]:
        return
    norm = " ".join((row["sql"] or "").split())
    if "PRIMARY KEY (job_id, file_seq, idx)" in norm:
        return                      # 已经是新主键
    db.ex("ALTER TABLE ab_seg RENAME TO ab_seg_pkold")
    db.ex("""CREATE TABLE ab_seg (
      job_id INTEGER NOT NULL,
      file_seq INTEGER NOT NULL,
      idx INTEGER NOT NULL,
      voice TEXT NOT NULL DEFAULT '',
      speaker TEXT NOT NULL DEFAULT '',
      cache TEXT NOT NULL DEFAULT '',
      seconds REAL NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT '',
      PRIMARY KEY (job_id, file_seq, idx))""")
    db.ex("INSERT OR IGNORE INTO ab_seg (job_id,file_seq,idx,voice,speaker,cache,seconds,created_at) "
          "SELECT job_id,file_seq,idx,voice,speaker,cache,seconds,created_at FROM ab_seg_pkold")
    db.ex("DROP TABLE ab_seg_pkold")
    import sys
    print("[audiobook] ab_seg 主键已升级为 (job_id, file_seq, idx)", file=sys.stderr)


# ------------------------------------------------------------------ 任务
JOB_COLS = ("id, book_id, title, line, voice, chapters_per_file, status, stage, ai_enabled, "
            "ai_chars, bgm, bgm_volume, dest, total_chapters, total_files, done_files, "
            "total_segs, done_segs, error, created_by, created_at, updated_at, finished_at, "
            "gap_ms, chap_gap_ms, skip_front, skipped, "
            "split_mode, target_min, max_min, chap_from, chap_to, to_lib, lib_cat")


def job_new(book_id, title, line, voice, per_file, ai_enabled, ai_chars, bgm,
            bgm_volume, dest, created_by, gap_ms=400, chap_gap_ms=1000, skip_front=1,
            split_mode="chapters", target_min=40, max_min=60, chap_from=0, chap_to=0,
            to_lib=0, lib_cat=0):
    init()
    now = db.now()
    # ★ db.ex() 返回的是影响行数，不是游标（没有 .lastrowid），所以自己取一次
    db.ex(
        "INSERT INTO ab_job (book_id,title,line,voice,chapters_per_file,status,ai_enabled,"
        "ai_chars,bgm,bgm_volume,dest,created_by,created_at,updated_at,"
        "gap_ms,chap_gap_ms,skip_front,split_mode,target_min,max_min,"
        "chap_from,chap_to,to_lib,lib_cat) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (book_id, title, line, voice, int(per_file or 1), "queued", 1 if ai_enabled else 0,
         json.dumps(ai_chars or {}, ensure_ascii=False), json.dumps(bgm or [], ensure_ascii=False),
         float(bgm_volume if bgm_volume is not None else 0.12), dest or "", created_by, now, now,
         max(0, min(5000, int(gap_ms if gap_ms is not None else 400))),
         max(0, min(20000, int(chap_gap_ms if chap_gap_ms is not None else 1000))),
         1 if skip_front else 0,
         ("balanced" if split_mode == "balanced" else "chapters"),
         max(5, min(600, int(target_min or 40))),
         max(5, min(1200, int(max_min or 60))),
         max(0, int(chap_from or 0)), max(0, int(chap_to or 0)),
         1 if to_lib else 0, max(0, int(lib_cat or 0))))
    return db.q("SELECT last_insert_rowid() AS r", one=True)["r"]


def job_get(job_id):
    init()
    return db.q("SELECT %s FROM ab_job WHERE id=?" % JOB_COLS, (job_id,), one=True)


def job_list(limit=100, status=None):
    init()
    if status:
        return db.q("SELECT %s FROM ab_job WHERE status=? ORDER BY id DESC LIMIT ?" % JOB_COLS,
                    (status, limit))
    return db.q("SELECT %s FROM ab_job ORDER BY id DESC LIMIT ?" % JOB_COLS, (limit,))


def job_set(job_id, **kw):
    init()
    if not kw:
        return
    kw["updated_at"] = db.now()
    cols = ", ".join("%s=?" % k for k in kw)
    db.ex("UPDATE ab_job SET %s WHERE id=?" % cols, tuple(kw.values()) + (job_id,))


def job_del(job_id):
    init()
    db.ex("DELETE FROM ab_seg WHERE job_id=?", (job_id,))
    db.ex("DELETE FROM ab_file WHERE job_id=?", (job_id,))
    db.ex("DELETE FROM ab_job WHERE id=?", (job_id,))


def job_next_queued():
    """取一个待跑的任务。同一时刻只跑一个 —— 合成本来就吃满 TTS 并发，
    再多开任务只会让两台机器互相排队，不如串行跑得快。"""
    init()
    return db.q("SELECT %s FROM ab_job WHERE status='queued' ORDER BY id LIMIT 1" % JOB_COLS,
                one=True)


# ------------------------------------------------------------------ 文件
def file_reset(job_id, files):
    """按章节规划重写 ab_file。已 uploaded 的保留（断点续传不重传）。"""
    init()
    keep = {}
    for r in db.q("SELECT seq,status,remote,bytes,seconds FROM ab_file WHERE job_id=?", (job_id,)):
        if r["status"] == "uploaded":
            keep[r["seq"]] = r
    db.ex("DELETE FROM ab_file WHERE job_id=?", (job_id,))
    now = db.now()
    for f in files:
        k = keep.get(f["seq"])
        if k:
            db.ex("INSERT INTO ab_file (job_id,seq,name,a,b,status,remote,bytes,seconds,updated_at) "
                  "VALUES (?,?,?,?,?,?,?,?,?,?)",
                  (job_id, f["seq"], f["name"], f["a"], f["b"], "uploaded",
                   k["remote"], k["bytes"], k["seconds"], now))
        else:
            db.ex("INSERT INTO ab_file (job_id,seq,name,a,b,status,updated_at) VALUES (?,?,?,?,?,?,?)",
                  (job_id, f["seq"], f["name"], f["a"], f["b"], "pending", now))


def files_of(job_id):
    init()
    return db.q("SELECT * FROM ab_file WHERE job_id=? ORDER BY seq", (job_id,))


def file_set(job_id, seq, **kw):
    init()
    if not kw:
        return
    kw["updated_at"] = db.now()
    cols = ", ".join("%s=?" % k for k in kw)
    db.ex("UPDATE ab_file SET %s WHERE job_id=? AND seq=?" % cols, tuple(kw.values()) + (job_id, seq))


def file_clear_from(job_id, seq):
    """把 seq 及其之后的重置为 pending —— 「重新生成某一章」用。

    ★ 注意：它连 ab_seg 一起删。整本重做要重新合成全部配音（几小时），
      只想换背景音乐/音量时请用 files_redo —— 那个保留配音缓存。
    """
    init()
    db.ex("UPDATE ab_file SET status='pending', remote='', bytes=0, seconds=0, err='', "
          "updated_at=? WHERE job_id=? AND seq>=?", (db.now(), job_id, seq))
    db.ex("DELETE FROM ab_seg WHERE job_id=? AND file_seq>=?", (job_id, seq))


def files_redo(job_id):
    """把所有文件置回 pending，但**保留 ab_seg**（配音缓存）。

    为什么单独有这个：背景音乐、音量这类只影响「混音」的改动，不该让整本书
    重新合成 —— 那要几小时。文件状态回到 pending 后工作线程会重新走一遍
    _synth_file，命中 ab_seg + 本地缓存就直接复用配音，只重做
    「拼接 → 混音 → 上传」。实测 10 秒级 vs 小时级的区别。
    """
    init()
    db.ex("UPDATE ab_file SET status='pending', remote='', bytes=0, seconds=0, err='', "
          "updated_at=? WHERE job_id=?", (db.now(), job_id))


# ------------------------------------------------------------------ 片段（断点续传的核心）
def seg_put(job_id, file_seq, idx, voice, speaker, cache, seconds):
    init()
    # ★ 任务行已经没了就不要再写。人删除任务的那一刻，工作线程可能正卡在
    #   一次合成请求里（_check 已经过了、seg_put 还没执行），请求回来就会写进
    #   一行谁也删不掉的孤儿 ab_seg。这个守卫让孤儿行不可能产生 ——
    #   实测每次"合成中删除"都会漏下 1 行。
    if db.q("SELECT 1 FROM ab_job WHERE id=?", (job_id,), one=True) is None:
        return
    db.ex("INSERT OR REPLACE INTO ab_seg (job_id,file_seq,idx,voice,speaker,cache,seconds,created_at) "
          "VALUES (?,?,?,?,?,?,?,?)",
          (job_id, file_seq, idx, voice or "", speaker or "", cache, seconds, db.now()))


def seg_del_range(job_id, file_seq, lo, hi):
    """删掉某个句序号区间内的分句记录，返回被删掉的缓存相对路径。

    ★ 跳过版权页时必须删干净：拼接是**从 ab_seg 读**的，
      只"不再合成"不够 —— 上一次跑出来的那些分句还在表里、缓存文件还在盘上，
      照样会被拼进成品里，"跳过"就成了假跳过。
    """
    init()
    rels = [r["cache"] for r in db.q(
        "SELECT cache FROM ab_seg WHERE job_id=? AND file_seq=? AND idx>=? AND idx<=?",
        (job_id, file_seq, lo, hi))]
    db.ex("DELETE FROM ab_seg WHERE job_id=? AND file_seq=? AND idx>=? AND idx<=?",
          (job_id, file_seq, lo, hi))
    return rels


def seg_of_file(job_id, file_seq):
    init()
    return db.q("SELECT * FROM ab_seg WHERE job_id=? AND file_seq=? ORDER BY idx", (job_id, file_seq))


def seg_count(job_id):
    init()
    return db.q("SELECT COUNT(*) c FROM ab_seg WHERE job_id=?", (job_id,), one=True)["c"]


# ------------------------------------------------------------------ 配置（AI 接口等）
DEFAULT_CFG = {
    "ai_protocol": "openai-completions",   # 或 openai-responses
    "ai_base_url": "",
    "ai_key": "",
    "ai_model": "",
    "ai_timeout": "180",
    "ai_prompt": "",                        # 留空用内置提示词
    "webdav_root": "/music",
    # 句间停顿（毫秒）。合成出来的句子之间原本是**零间隔**直接拼接的，
    # 听着像连珠炮、没有喘气的地方。默认 400ms。
    "gap_ms": "400",
    # 章与章之间的停顿，比句间更长，用来分隔章节。
    "chap_gap_ms": "1000",
    # 是否跳过版权页/目录这类非正文（默认跳过）
    "skip_front": "1",
    # ---- 「有声」页面（ablib_api / library）的设置，同样只能写白名单里的键 ----
    "lib_groups": "[]",           # 允许收听的分组 id 列表（JSON），[] = 不限制
    "lib_free_chapters": "0",     # 免费章节数，0 = 不启用
    "lib_leaf_per_chapter": "0",  # 超出免费后每章消耗树叶，0 = 不收费
    "lib_leaf_per_book": "0",     # 整本买断树叶，0 = 不提供
    "lib_need_login": "0",        # 是否必须登录才能听
    # 额外要跳过的章节标题关键词，逗号分隔（在默认规则之外再加）
    "skip_front_kw": "",
    # 同时制作几本有声书。每本书都绑在自己的线路上（ab_job.line），
    # 有几台 TTS 机器就可以同时做几本 —— 两台机器各做一本，比排队串行快一倍。
    # 设成 1 就是以前的老行为（严格串行）。
    "max_concurrent": "2",
}


def cfg_all():
    init()
    out = dict(DEFAULT_CFG)
    for r in db.q("SELECT k,v FROM ab_cfg"):
        out[r["k"]] = r["v"]
    return out


def cfg_get(k, default=""):
    return cfg_all().get(k, default)


def cfg_set(d):
    init()
    for k, v in (d or {}).items():
        if k not in DEFAULT_CFG:
            continue
        db.ex("INSERT OR REPLACE INTO ab_cfg (k,v) VALUES (?,?)", (k, "" if v is None else str(v)))
