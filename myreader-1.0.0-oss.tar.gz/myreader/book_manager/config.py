# -*- coding: utf-8 -*-
"""图书管理系统配置"""
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
DB_PATH = os.path.join(DATA_DIR, "library.db")
COVER_DIR = os.path.join(DATA_DIR, "covers")   # 封面本地缓存（源在 FTP）
CONVERT_DIR = os.path.join(DATA_DIR, "converted")  # mobi/azw3 转 epub 缓存
UPLOAD_DIR = os.path.join(DATA_DIR, "uploads")     # 用户上传
CACHE_DIR = os.path.join(DATA_DIR, "cache")        # 阅读/下载临时
IMAGE_DIR = os.path.join(DATA_DIR, "article_images")  # 书单讨论文章内嵌图片

for d in (DATA_DIR, COVER_DIR, CONVERT_DIR, UPLOAD_DIR, CACHE_DIR, IMAGE_DIR):
    os.makedirs(d, exist_ok=True)

# FTP 服务器（管理分类后的书库）
# 存储后端地址与口令全部走环境变量：开源版不含任何真实地址/凭据
FTP_HOST = os.environ.get("BOOKMGR_FTP_HOST", "127.0.0.1")
FTP_PORT = int(os.environ.get("BOOKMGR_FTP_PORT", "21"))
FTP_USER = os.environ.get("BOOKMGR_FTP_USER", "bookadmin")
FTP_PASS = os.environ.get("BOOKMGR_FTP_PASS", "")
FTP_BASE = os.environ.get("BOOKMGR_FTP_BASE", "/books")

# WebDAV（主存储后端：更稳定、原生 UTF-8、可复用连接）；FTP/SFTP 作为兜底
WEBDAV_HOST = FTP_HOST
WEBDAV_PORT = int(os.environ.get("BOOKMGR_WEBDAV_PORT", "5005"))

# 会员上传书籍在 WebDAV/FTP 上的专属目录（相对于 FTP_BASE）；文件按 upload/{user_id}/ 归档，仅上传者可见
USER_UPLOAD_DIR = "upload"

# 刮削/提取的封面在 FTP 上的目录（相对于 FTP_BASE）；本地 data/covers 仅作临时缓存
FTP_COVER_DIR = "封面"

# SFTP（兜底/枚举）
SFTP_HOST = os.environ.get("BOOKMGR_SFTP_HOST", FTP_HOST)
SFTP_PORT = int(os.environ.get("BOOKMGR_SFTP_PORT", "22"))

# 认证
JWT_SECRET = os.environ.get("BOOKMGR_SECRET", "dev-secret-please-change")
JWT_ALG = "HS256"
TOKEN_TTL = 7 * 24 * 3600  # 7 天

# 游客（未登录）可试读的范例图书 ID；0 = 不开放游客试读
PUBLIC_SAMPLE_BOOK_ID = int(os.environ.get("BOOKMGR_SAMPLE_BOOK_ID", "0"))

# 阅读支持的格式（上传/同步导入允许的电子书格式，尽量覆盖全部常见电子书格式）
BOOK_EXTS = {
    # EPUB / HTML 类
    ".epub", ".html", ".htm", ".xhtml", ".oeb", ".opf",
    # Kindle / Mobipocket 类
    ".mobi", ".azw", ".azw1", ".azw3", ".azw4", ".kf8", ".kfx", ".kpf", ".tpz", ".prc", ".pdb",
    # 纯文本 / 富文本 / 办公文档类
    ".txt", ".rtf", ".md", ".markdown", ".doc", ".docx", ".odt", ".pml", ".tcr",
    # 固定版式 / 扫描类
    ".pdf", ".djvu", ".djv", ".chm", ".xps", ".oxps", ".uvz",
    # FictionBook
    ".fb2", ".fbz",
    # 其他电子书
    ".lit", ".lrf", ".lrx", ".lrs", ".snb", ".umd", ".ibooks",
    # 漫画
    ".cbz", ".cbr", ".cb7", ".cbt",
}
READABLE_EXTS = {".epub", ".mobi", ".azw3", ".txt", ".pdf", ".html", ".htm", ".docx", ".md", ".markdown"}

# 默认管理员（首次启动创建）
DEFAULT_ADMIN = {"username": "admin", "password": "admin123"}
DEFAULT_USER_QUOTA = 100

# FTP 自动同步周期（秒），0 表示关闭后台定时同步（仍可手动触发）
SYNC_INTERVAL = int(os.environ.get("BOOKMGR_SYNC_INTERVAL", "600"))

# 服务监听
HOST = "0.0.0.0"
PORT = 9000
