# -*- coding: utf-8 -*-
"""回归测试：每本书单独定价 + 管理员兑换后必须真的解锁。

覆盖两个真实缺陷：
  1. 管理员点「兑换」→ 接口 200，但那一章**永远是锁的**（_spend 对管理员直接
     返回 0 又不写购买记录，而 chap_locked 看的是购买记录）。
  2. 每本书单独设置免费章节/价格后，必须覆盖全局设置；恢复 -1 必须回到全局。
自建自清：只用测试账号，跑完删掉自己造的 ab_lib_buy 行。
"""
import json, ssl, sys, urllib.error, urllib.request
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
import db, auth
from audiobook import library as L

CTX = ssl._create_unverified_context()
PASS = FAIL = 0
def check(name, ok, extra=''):
    global PASS, FAIL
    if ok: PASS += 1; print('  ✓ %s %s' % (name, extra))
    else:  FAIL += 1; print('  ✗ %s %s' % (name, extra))

def call(m, p, obj=None, tk=None):
    h = {'X-BM-No-Push': '1'}; data = None
    if tk: h['Authorization'] = 'Bearer ' + tk
    if obj is not None:
        data = json.dumps(obj).encode(); h['Content-Type'] = 'application/json'
    r = urllib.request.Request('https://127.0.0.1:9000' + p, method=m, data=data, headers=h)
    try:
        x = urllib.request.urlopen(r, context=CTX, timeout=25)
        return x.status, json.loads(x.read())
    except urllib.error.HTTPError as e:
        try: return e.code, json.loads(e.read())
        except Exception: return e.code, {}

adm = db.q("SELECT * FROM users WHERE username='admin'", one=True)
usr = db.q("SELECT * FROM users WHERE username='test'", one=True)
assert adm and usr, '缺少 admin / test 账号'
ATK, UTK = auth.create_token(adm), auth.create_token(usr)
LIB = 3

saved = dict(L.cfg())
# ★ 这本书的定价覆盖要先**快照**再改，收尾时原样写回。
#   直接写死还原成 -1 会把管理员在这期间单独设好的价格抹掉。
L.init()
_row = db.q("SELECT free_chapters, leaf_per_chapter, leaf_per_book FROM ab_lib WHERE id=?", (LIB,), one=True)
saved_pricing = (int(_row["free_chapters"]), int(_row["leaf_per_chapter"]), int(_row["leaf_per_book"]))
try:
    # --- 1. 管理员不受限：兑换后必须解锁 ---
    L.cfg_set({'lib_free_chapters': 1, 'lib_leaf_per_chapter': 5, 'lib_leaf_per_book': 30})
    db.ex('DELETE FROM ab_lib_buy WHERE user_id=? AND lib_id=?', (adm['id'], LIB))
    st, d = call('GET', '/api/audiobooks/%d' % LIB, tk=ATK)
    check('管理员看到收费章', d['access']['per_chapter'] == 5 and d['access']['free'] == 1)
    check('管理员直接全解锁', d['access']['bought_book'] is True)
    check('管理员所有章都不上锁', all(not c['locked'] for c in d['chapters']))
    st, d = call('POST', '/api/audiobooks/%d/unlock' % LIB, {'kind': 'chapter', 'chap': 3}, tk=ATK)
    check('管理员兑换返回 200', st == 200, str(d)[:60])
    st, d = call('GET', '/api/audiobooks/%d' % LIB, tk=ATK)
    c3 = [c for c in d['chapters'] if c['seq'] == 3][0]
    check('★ 管理员兑换后第 3 章解锁（修复前永远 True）', c3['locked'] is False)
    st, d = call('GET', '/api/audiobooks/%d/ticket?seq=3&chap=3' % LIB, tk=ATK)
    check('管理员能取到播放凭证', st == 200, str(d)[:50])

    # --- 2. 普通用户：按每本书的定价扣费 ---
    db.ex('DELETE FROM ab_lib_buy WHERE user_id=? AND lib_id=?', (usr['id'], LIB))
    st, d = call('GET', '/api/audiobooks/%d' % LIB, tk=UTK)
    check('普通用户用全局价（每章 5）', d['access']['per_chapter'] == 5)
    bal0 = db.q('SELECT balance FROM user_leaves WHERE user_id=?', (usr['id'],), one=True)['balance']

    st, d = call('POST', '/api/admin/audiobooks/%d/pricing' % LIB,
                 {'free_chapters': 3, 'leaf_per_chapter': 7, 'leaf_per_book': 50}, tk=ATK)
    check('后台设置每本定价', st == 200 and d['pricing'] == {'free': 3, 'per_chapter': 7, 'per_book': 50})
    st, d = call('GET', '/api/audiobooks/%d' % LIB, tk=UTK)
    check('★ 单独定价覆盖全局（免费 3 章）', d['access']['free'] == 3)
    check('★ 单独定价覆盖全局（每章 7）', d['access']['per_chapter'] == 7)
    check('前 3 章免费、第 4 章收费',
          [c['locked'] for c in d['chapters']][:4] == [False, False, False, True])
    st, d = call('POST', '/api/audiobooks/%d/unlock' % LIB, {'kind': 'chapter', 'chap': 4}, tk=UTK)
    check('★ 按每本价扣 7 而不是全局 5', st == 200 and d.get('spent') == 7, 'spent=%s' % d.get('spent'))
    bal1 = db.q('SELECT balance FROM user_leaves WHERE user_id=?', (usr['id'],), one=True)['balance']
    check('余额只少 7', bal1 == bal0 - 7, '%s → %s' % (bal0, bal1))
    st, d = call('GET', '/api/audiobooks/%d/ticket?seq=4&chap=4' % LIB, tk=UTK)
    check('★ 普通用户兑换后能取播放凭证', st == 200)

    # --- 3. 恢复跟随全局 ---
    st, d = call('POST', '/api/admin/audiobooks/%d/pricing' % LIB,
                 {'free_chapters': -1, 'leaf_per_chapter': -1, 'leaf_per_book': -1}, tk=ATK)
    check('恢复跟随全局', st == 200 and d['pricing'] == {'free': 1, 'per_chapter': 5, 'per_book': 30},
          str(d.get('pricing')))
    check('库里存的是 -1（不是抄一份全局值）',
          d['raw'] == {'free_chapters': -1, 'leaf_per_chapter': -1, 'leaf_per_book': -1})
    st, d = call('POST', '/api/admin/audiobooks/%d/pricing' % LIB, {'free_chapters': -5}, tk=ATK)
    check('非法值 -5 被拒', st == 400)
finally:
    L.cfg_set({k: v for k, v in saved.items() if k.startswith('lib_')})
    for u in (adm, usr):
        db.ex('DELETE FROM ab_lib_buy WHERE user_id=? AND lib_id=?', (u['id'], LIB))
    L.pricing_set(LIB, free=saved_pricing[0], per_chapter=saved_pricing[1], per_book=saved_pricing[2])

print('\n  结果：%d 通过 / %d 失败' % (PASS, FAIL))
sys.exit(1 if FAIL else 0)
