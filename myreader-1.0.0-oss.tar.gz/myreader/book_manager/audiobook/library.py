# -*- coding: utf-8 -*-
"""「有声」页面的数据层：把制作好的有声书变成 App 里可浏览、可播放的电子书。

和制作模块（worker/store）的关系：
* 制作模块只管「把书合成 MP3 传到 NAS」，产出的是 `ab_job` / `ab_file` / `ab_seg`；
* 本模块把这些产出**登记**成一本有声电子书（`ab_lib`），并把它拆成
  「章」与「句」两级索引（`ab_lib_chap` / `ab_lib_seg`），供详情页列章节、
  播放器做「歌词式」文字同步。

★ 时长不重新测量，全部由 `ab_seg` 的每句秒数**复刻拼接过程**算出来：
  worker 拼一个文件时的顺序是「句子 → gap → 句子 → …」，章与章之间换成更长的
  chap_gap，且**第一个片段前面不插静音**。这里按同一套规则累加，
  得到的每个文件内偏移与成品 MP3 完全一致（这也是能精确同步的原因）。
★ 句子的文字不依赖缓存文件（合成完就被删了），而是用**同样的断句规则**
  重新切一遍书中该章的正文 —— 只要 `split_sentences` 与 worker 一致，
  第 k 句文字的 idx 就与 `ab_seg.idx` 一一对应。

表名继续用 `ab_` 前缀，与既有表零交集。
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import db  # noqa: E402
from audiobook import book as B, speech as S, store as ST  # noqa: E402

SCHEMA = """
CREATE TABLE IF NOT EXISTS ab_lib (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  job_id INTEGER NOT NULL,
  book_id INTEGER NOT NULL DEFAULT 0,
  title TEXT NOT NULL DEFAULT '',
  author TEXT NOT NULL DEFAULT '',
  intro TEXT NOT NULL DEFAULT '',
  cover TEXT NOT NULL DEFAULT '',
  cat_id INTEGER NOT NULL DEFAULT 0,
  dest TEXT NOT NULL DEFAULT '',
  total_files INTEGER NOT NULL DEFAULT 0,
  total_chapters INTEGER NOT NULL DEFAULT 0,
  total_seconds REAL NOT NULL DEFAULT 0,
  line TEXT NOT NULL DEFAULT '',
  voice TEXT NOT NULL DEFAULT '',
  hidden INTEGER NOT NULL DEFAULT 0,
  sort INTEGER NOT NULL DEFAULT 0,
  -- 每本书可单独定价：-1 = 跟随后台「有声听书」里的全局设置（默认值）
  free_chapters INTEGER NOT NULL DEFAULT -1,
  leaf_per_chapter INTEGER NOT NULL DEFAULT -1,
  leaf_per_book INTEGER NOT NULL DEFAULT -1,
  created_by INTEGER,
  created_at TEXT NOT NULL DEFAULT '',
  updated_at TEXT NOT NULL DEFAULT '',
  UNIQUE(job_id)
);
CREATE TABLE IF NOT EXISTS ab_lib_chap (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  lib_id INTEGER NOT NULL,
  seq INTEGER NOT NULL,
  chapter_idx INTEGER NOT NULL DEFAULT 0,
  title TEXT NOT NULL DEFAULT '',
  file_seq INTEGER NOT NULL DEFAULT 0,
  file_name TEXT NOT NULL DEFAULT '',
  start_sec REAL NOT NULL DEFAULT 0,
  dur_sec REAL NOT NULL DEFAULT 0,
  n_segs INTEGER NOT NULL DEFAULT 0,
  UNIQUE(lib_id, seq)
);
CREATE TABLE IF NOT EXISTS ab_lib_seg (
  lib_id INTEGER NOT NULL,
  chap_seq INTEGER NOT NULL,
  idx INTEGER NOT NULL,
  text TEXT NOT NULL DEFAULT '',
  start_sec REAL NOT NULL DEFAULT 0,
  dur_sec REAL NOT NULL DEFAULT 0,
  PRIMARY KEY(lib_id, chap_seq, idx)
);
CREATE TABLE IF NOT EXISTS ab_lib_cat (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL DEFAULT '',
  sort INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS ab_lib_prog (
  user_id INTEGER NOT NULL,
  lib_id INTEGER NOT NULL,
  chap_seq INTEGER NOT NULL DEFAULT 1,
  offset REAL NOT NULL DEFAULT 0,
  percent REAL NOT NULL DEFAULT 0,
  seconds REAL NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL DEFAULT '',
  PRIMARY KEY(user_id, lib_id)
);
CREATE TABLE IF NOT EXISTS ab_lib_buy (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  lib_id INTEGER NOT NULL,
  kind TEXT NOT NULL DEFAULT '',
  chap_seq INTEGER NOT NULL DEFAULT 0,
  leaves INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS ix_abl_chap ON ab_lib_chap(lib_id, seq);
CREATE INDEX IF NOT EXISTS ix_abl_prog ON ab_lib_prog(user_id, lib_id);
CREATE INDEX IF NOT EXISTS ix_abl_buy ON ab_lib_buy(user_id, lib_id);
"""

_ready = False

# 「有声听书」的后台设置（存在既有的 ab_cfg 键值表里，键名统一 lib_ 前缀，见 §14.54）
DEFAULTS = {
    "lib_groups": "[]",          # 允许收听的分组 id 列表；[] = 不限制
    "lib_free_chapters": "0",    # 免费章节数（前 N 章免费），0 = 不启用
    "lib_leaf_per_chapter": "0",  # 超出免费章节后，每章要多少树叶；0 = 不收费
    "lib_leaf_per_book": "0",     # 一次性买断整本要多少树叶；0 = 不收费
    "lib_need_login": "0",       # 是否必须登录才能听
}


# 后加的表列：老库要 ALTER 补上（CREATE TABLE IF NOT EXISTS 不会改已存在的表）
_MIGRATE = [
    ("ab_lib", "free_chapters INTEGER NOT NULL DEFAULT -1"),
    ("ab_lib", "leaf_per_chapter INTEGER NOT NULL DEFAULT -1"),
    ("ab_lib", "leaf_per_book INTEGER NOT NULL DEFAULT -1"),
]


def init():
    global _ready
    if _ready:
        return
    # ★ 必须按分号拆开逐条执行：db.ex() 走的是 sqlite3 的 execute，
    #   一次只能一条语句（store.init 也是这么做的）。
    for stmt in SCHEMA.strip().split(";"):
        s = stmt.strip()
        if s:
            db.ex(s)
    for tbl, col in _MIGRATE:
        name = col.split()[0]
        have = {r["name"] for r in db.q("PRAGMA table_info(%s)" % tbl)}
        if name not in have:
            db.ex("ALTER TABLE %s ADD COLUMN %s" % (tbl, col))
    _ready = True


# ------------------------------------------------------------------ 每本书的定价
# 约定：字段值 < 0 表示「跟随后台全局设置」，>= 0 表示这本书单独指定。
# 这样默认行为完全等于老的「集中设置」，管理员想单独调某一本再填数字即可。
def book_pricing(lib):
    """返回这本书**实际生效**的 {free, per_chapter, per_book}。

    lib 为 None 时直接用全局设置。任何一项没单独设（-1）就回落到全局值。
    """
    g_free, g_ch, g_book = free_chapters(), leaf_per_chapter(), leaf_per_book()
    if not lib:
        return {"free": g_free, "per_chapter": g_ch, "per_book": g_book}
    def pick(key, glob):
        try:
            v = dict(lib).get(key)
        except Exception:
            v = None
        if v is None:
            return glob
        v = int(v)
        return glob if v < 0 else v
    return {"free": pick("free_chapters", g_free),
            "per_chapter": pick("leaf_per_chapter", g_ch),
            "per_book": pick("leaf_per_book", g_book)}


def pricing_set(lib_id, free=None, per_chapter=None, per_book=None):
    """单独设置某本书的定价；传 None 表示保持原样，传 -1 表示恢复跟随全局。"""
    init()
    sets, args = [], []
    for col, val in (("free_chapters", free), ("leaf_per_chapter", per_chapter),
                     ("leaf_per_book", per_book)):
        if val is None:
            continue
        sets.append(col + "=?")
        args.append(int(val))
    if not sets:
        return
    sets.append("updated_at=?")
    args.append(db.now())
    args.append(lib_id)
    db.ex("UPDATE ab_lib SET " + ",".join(sets) + " WHERE id=?", tuple(args))


# ------------------------------------------------------------------ 索引重建
def _chapters_of(job):
    b = db.q("SELECT * FROM books WHERE id=?", (job["book_id"],), one=True)
    if not b:
        return None, None
    return dict(b), B.chapters(b)


def _timeline_for_file(job, chs, frow, segrows):
    """复刻 worker 的拼接顺序，算出每句在成品 MP3 里的偏移。

    返回 (chapters, segs)：
      chapters = [{chapter_idx, title, seq, file_seq, file_name, start_sec, dur_sec, n_segs}]
      segs     = {chapter_idx: [{idx, text, start_sec, dur_sec}]}
    """
    gap = max(0, int(job["gap_ms"] or 0)) / 1000.0
    cgap = max(0, int(job["chap_gap_ms"] if job["chap_gap_ms"] is not None else 0)) / 1000.0
    do_skip = bool(job["skip_front"])
    extra_kw = ST.cfg_get("skip_front_kw") or ""

    by_idx = {int(r["idx"]): r for r in segrows if r["seconds"] and r["seconds"] > 0}

    seq_idx = 0
    order = []      # [(章, 该章的句子行)] —— 按 worker 的拼接顺序
    # 与 worker 完全一致：句序号照占，跳过的章只是不合成
    for ch in chs[frow["a"]:frow["b"] + 1]:
        sents = S.split_sentences(ch["text"])
        if do_skip and B.is_front_matter(ch["title"], ch["text"], extra_kw):
            seq_idx += len(sents)
            continue
        if not sents:
            continue
        rows = []
        for li, s in enumerate(sents):
            idx = seq_idx
            seq_idx += 1
            r = by_idx.get(idx)
            if not r:
                # 这一句没有音频记录（被跳过或失败后重跑过）——不能凭猜测补时间
                continue
            rows.append({"idx": idx, "text": s, "raw": float(r["seconds"] or 0)})
        if rows:
            order.append((ch, rows))

    # ---------------------------------------------------------- 统一分配时间轴
    n = sum(len(rows) for _, rows in order)
    if not n:
        return [], {}
    raw_total = sum(r["raw"] for _, rows in order for r in rows)
    n_gap = max(0, n - len(order))       # 句间停顿：每章第一句前面不插
    n_cgap = max(0, len(order) - 1)      # 章间停顿：文件第一句前面不插
    target = float(frow["seconds"] or 0)
    # ★ 逐段拼接有固定开销：成品比「各段秒数 + 停顿」多一点（实测每段约 13ms，
    #   是编码器延迟与补帧；一本书累计能差十几秒）。用 ab_file.seconds
    #   （ffprobe 量出来的真值）反解出每段开销再逐句分摊，偏移就与成品严格对齐。
    #   这也是「歌词」能对得上的关键 —— 不校准的话越往后越漂。
    base = raw_total + n_gap * gap + n_cgap * cgap
    pad = ((target - base) / n) if (target > base and n) else 0.0

    t = 0.0
    out_ch, out_segs = [], {}
    for ci, (ch, rows) in enumerate(order):
        # ★ 时间轴**跨章连续累加**（第一版每章把 t 清零，于是第 2 章的 start_sec
        #   变成「章内相对时间」，显示成从 1.0s 开始，其实在 166s 处）
        if ci > 0 and cgap > 0.02:
            t += cgap
        for k, r in enumerate(rows):
            if k > 0 and gap > 0.02:
                t += gap
            r["start_sec"] = t
            r["dur_sec"] = r["raw"] + pad
            t += r["dur_sec"]
        # 章的时长 = 最后一句结束 − 第一句开始（含章内句间停顿与拼接开销）
        c_start = rows[0]["start_sec"]
        c_end = rows[-1]["start_sec"] + rows[-1]["dur_sec"]
        out_ch.append({
            "chapter_idx": int(ch["idx"]),
            "title": (ch["title"] or "").strip() or ("第 %d 章" % (int(ch["idx"]) + 1)),
            "file_seq": int(frow["seq"]),
            "file_name": frow["name"] or "",
            "start_sec": c_start,
            "dur_sec": max(0.0, c_end - c_start),
            "end_sec": c_end,
            "n_segs": len(rows),
        })
        out_segs[int(ch["idx"])] = rows
    return out_ch, out_segs


def build_index(lib_id, job_id):
    """按 ab_file / ab_seg 重建这本书的章与句索引（幂等，可重复调用）。"""
    init()
    job = ST.job_get(job_id)
    if not job:
        raise RuntimeError("任务不存在：%s" % job_id)
    b, chs = _chapters_of(job)
    if not chs:
        raise RuntimeError("书不存在或解析不出章节：book_id=%s" % job["book_id"])

    db.ex("DELETE FROM ab_lib_chap WHERE lib_id=?", (lib_id,))
    db.ex("DELETE FROM ab_lib_seg WHERE lib_id=?", (lib_id,))

    total_sec = 0.0
    seq = 0
    files = db.q("SELECT * FROM ab_file WHERE job_id=? AND status='uploaded' ORDER BY seq", (job_id,))
    for frow in files:
        segrows = db.q("SELECT idx, seconds FROM ab_seg WHERE job_id=? AND file_seq=? ORDER BY idx",
                       (job_id, frow["seq"]))
        ch_list, seg_map = _timeline_for_file(job, chs, frow, segrows)
        file_end = 0.0
        for c in ch_list:
            seq += 1
            db.ex("INSERT INTO ab_lib_chap (lib_id,seq,chapter_idx,title,file_seq,file_name,"
                  "start_sec,dur_sec,n_segs) VALUES (?,?,?,?,?,?,?,?,?)",
                  (lib_id, seq, c["chapter_idx"], c["title"], c["file_seq"], c["file_name"],
                   c["start_sec"], c["dur_sec"], c["n_segs"]))
            for r in seg_map.get(c["chapter_idx"]) or []:
                db.ex("INSERT INTO ab_lib_seg (lib_id,chap_seq,idx,text,start_sec,dur_sec) "
                      "VALUES (?,?,?,?,?,?)",
                      (lib_id, seq, r["idx"], r["text"], r["start_sec"], r["dur_sec"]))
            file_end = max(file_end, c.get("end_sec") or 0.0)
        # ★ 整本总时长按**成品文件的实际时长**（ab_file.seconds，ffprobe 量的）累加，
        #   不用重建值 —— 重建只负责「文件内偏移」，总量以实物为准。
        total_sec += float(frow["seconds"] or 0) or file_end
    db.ex("UPDATE ab_lib SET total_chapters=?, total_seconds=?, updated_at=? WHERE id=?",
          (seq, total_sec, db.now(), lib_id))
    return {"chapters": seq, "seconds": total_sec}


# ------------------------------------------------------------------ 登记 / 注销
def register(job_id, cat_id=0, created_by=None, hidden=0):
    """把某个已完成任务登记成一本有声电子书（重复调用是更新，不会重复建行）。"""
    init()
    job = ST.job_get(job_id)
    if not job:
        raise RuntimeError("任务不存在：%s" % job_id)
    if job["status"] != "done":
        raise RuntimeError("任务还没完成，不能登记：状态 %s" % job["status"])
    b = db.q("SELECT * FROM books WHERE id=?", (job["book_id"],), one=True)
    now = db.now()
    row = db.q("SELECT * FROM ab_lib WHERE job_id=?", (job_id,), one=True)
    n_files = db.q("SELECT COUNT(*) c FROM ab_file WHERE job_id=? AND status='uploaded'",
                   (job_id,), one=True)["c"]
    if row:
        lib_id = row["id"]
        # ★ 标题优先用**书**记录里的，而不是建任务时抄下来的 job.title。
        #   书在入库后还会被刮削/清洗（去掉「A14305.」「.B00NZKTYM2」这类原始文件名尾巴、
        #   补封面），但 job.title 是建任务那一刻的快照、永远不会跟着变。
        #   只认 job.title 的话，有声书就会一直挂着「A14305. 魔戒三部曲.B00NZKTYM2」这种名字。
        #   书不存在时才退回 job.title。
        db.ex("UPDATE ab_lib SET title=?,author=?,intro=?,cover=?,dest=?,total_files=?,"
              "line=?,voice=?,updated_at=?,hidden=? WHERE id=?",
              ((b["title"] if b and b["title"] else job["title"]),
               (b["author"] if b else "") or "", (b["intro"] if b else "") or "",
               (b["cover"] if b else "") or "", job["dest"], n_files, job["line"], job["voice"],
               now, 1 if hidden else 0, lib_id))
    else:
        db.ex("INSERT INTO ab_lib (job_id,book_id,title,author,intro,cover,cat_id,dest,"
              "total_files,line,voice,hidden,sort,created_by,created_at,updated_at) "
              "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
              (job_id, job["book_id"],
               (b["title"] if b and b["title"] else job["title"]),
               (b["author"] if b else "") or "",
               (b["intro"] if b else "") or "", (b["cover"] if b else "") or "", int(cat_id or 0),
               job["dest"], n_files, job["line"], job["voice"], 1 if hidden else 0, 0,
               created_by, now, now))
        lib_id = db.q("SELECT id FROM ab_lib WHERE job_id=?", (job_id,), one=True)["id"]
    info = build_index(lib_id, job_id)
    return lib_id, info


def unregister(lib_id):
    init()
    db.ex("DELETE FROM ab_lib_chap WHERE lib_id=?", (lib_id,))
    db.ex("DELETE FROM ab_lib_seg WHERE lib_id=?", (lib_id,))
    db.ex("DELETE FROM ab_lib WHERE id=?", (lib_id,))


# ------------------------------------------------------------------ 查询
def _running_of(lib):
    """播放这本书需要读的目录（成品音频在 NAS 上，通过 WebDAV 取）。"""
    return (lib["dest"] or "").rstrip("/")


def list_libs(cat_id=None, include_hidden=False, q=None):
    init()
    sql = "SELECT * FROM ab_lib WHERE 1=1"
    args = []
    if cat_id:
        sql += " AND cat_id=?"
        args.append(int(cat_id))
    if not include_hidden:
        sql += " AND hidden=0"
    if q:
        sql += " AND (title LIKE ? OR author LIKE ?)"
        args += ["%" + q + "%", "%" + q + "%"]
    sql += " ORDER BY sort, id DESC"
    return [dict(r) for r in db.q(sql, tuple(args))]


def get_lib(lib_id):
    init()
    r = db.q("SELECT * FROM ab_lib WHERE id=?", (lib_id,), one=True)
    return dict(r) if r else None


def get_lib_by_job(job_id):
    init()
    r = db.q("SELECT * FROM ab_lib WHERE job_id=?", (job_id,), one=True)
    return dict(r) if r else None


def chapters(lib_id, brief=False):
    init()
    cols = "seq,chapter_idx,title,file_seq,start_sec,dur_sec,n_segs" if brief else "*"
    return [dict(r) for r in db.q(
        "SELECT %s FROM ab_lib_chap WHERE lib_id=? ORDER BY seq" % cols, (lib_id,))]


def chapter(lib_id, seq):
    init()
    r = db.q("SELECT * FROM ab_lib_chap WHERE lib_id=? AND seq=?", (lib_id, seq), one=True)
    return dict(r) if r else None


def segs(lib_id, chap_seq):
    init()
    return [dict(r) for r in db.q(
        "SELECT idx,text,start_sec,dur_sec FROM ab_lib_seg WHERE lib_id=? AND chap_seq=? ORDER BY idx",
        (lib_id, chap_seq))]


# ------------------------------------------------------------------ 分类
def cats(include_empty_names=True):
    init()
    return [dict(r) for r in db.q("SELECT * FROM ab_lib_cat ORDER BY sort, id")]


def cat_add(name, sort=0):
    init()
    name = (name or "").strip()
    if not name:
        raise RuntimeError("分类名不能为空")
    if db.q("SELECT id FROM ab_lib_cat WHERE name=?", (name,), one=True):
        raise RuntimeError("分类已存在：%s" % name)
    db.ex("INSERT INTO ab_lib_cat (name,sort,created_at) VALUES (?,?,?)", (name, int(sort or 0), db.now()))
    return db.q("SELECT id FROM ab_lib_cat ORDER BY id DESC LIMIT 1", one=True)["id"]


def cat_rename(cid, name):
    init()
    name = (name or "").strip()
    if not name:
        raise RuntimeError("分类名不能为空")
    dup = db.q("SELECT id FROM ab_lib_cat WHERE name=? AND id<>?", (name, cid), one=True)
    if dup:
        raise RuntimeError("分类已存在：%s" % name)
    db.ex("UPDATE ab_lib_cat SET name=? WHERE id=?", (name, cid))


def cat_del(cid):
    """删分类：把书归到「未分类」，绝不连书一起删。"""
    init()
    db.ex("UPDATE ab_lib SET cat_id=0 WHERE cat_id=?", (cid,))
    db.ex("DELETE FROM ab_lib_cat WHERE id=?", (cid,))


def cat_name(cid):
    if not cid:
        return "未分类"
    r = db.q("SELECT name FROM ab_lib_cat WHERE id=?", (cid,), one=True)
    return r["name"] if r else "未分类"


def cat_counts():
    init()
    out = {}
    for r in db.q("SELECT cat_id, COUNT(*) c FROM ab_lib WHERE hidden=0 GROUP BY cat_id"):
        out[int(r["cat_id"] or 0)] = r["c"]
    return out


# ------------------------------------------------------------------ 听读进度
def progress_get(user_id, lib_id):
    init()
    r = db.q("SELECT * FROM ab_lib_prog WHERE user_id=? AND lib_id=?", (user_id, lib_id), one=True)
    return dict(r) if r else None


def progress_put(user_id, lib_id, chap_seq, offset=0.0, percent=None, seconds=None):
    init()
    now = db.now()
    old = progress_get(user_id, lib_id)
    total = 0.0
    if seconds is None:
        seconds = (old["seconds"] if old else 0.0) or 0.0
    if percent is None:
        mc = db.q("SELECT COUNT(*) c FROM ab_lib_chap WHERE lib_id=?", (lib_id,), one=True)["c"]
        percent = (float(chap_seq) / mc * 100.0) if mc else 0.0
    if old:
        db.ex("UPDATE ab_lib_prog SET chap_seq=?,offset=?,percent=?,seconds=?,updated_at=? "
              "WHERE user_id=? AND lib_id=?",
              (int(chap_seq), float(offset or 0), float(percent), float(seconds), now, user_id, lib_id))
    else:
        db.ex("INSERT INTO ab_lib_prog (user_id,lib_id,chap_seq,offset,percent,seconds,updated_at) "
              "VALUES (?,?,?,?,?,?,?)",
              (user_id, lib_id, int(chap_seq), float(offset or 0), float(percent), float(seconds), now))


def progress_all(user_id):
    init()
    return {int(r["lib_id"]): dict(r) for r in db.q(
        "SELECT * FROM ab_lib_prog WHERE user_id=?", (user_id,))}


# ------------------------------------------------------------------ 后台设置
def cfg():
    out = dict(DEFAULTS)
    try:
        for k in DEFAULTS:
            v = ST.cfg_get(k, None)
            if v not in (None, ""):
                out[k] = v
    except Exception:
        pass
    return out


def cfg_set(d):
    init()
    for k, v in (d or {}).items():
        if k in DEFAULTS:
            ST.cfg_set({k: "" if v is None else str(v)})
    return cfg()


def groups():
    c = cfg()
    try:
        return [int(x) for x in json.loads(c.get("lib_groups") or "[]")]
    except Exception:
        return []


def free_chapters():
    try:
        return max(0, int(cfg().get("lib_free_chapters") or 0))
    except Exception:
        return 0


def leaf_per_chapter():
    try:
        return max(0, int(cfg().get("lib_leaf_per_chapter") or 0))
    except Exception:
        return 0


def leaf_per_book():
    try:
        return max(0, int(cfg().get("lib_leaf_per_book") or 0))
    except Exception:
        return 0


def user_group_ids(user):
    """用户所属分组 id 列表。

    ★ 复用听书那边的口径（listen_admin.ug + group_id），**不自己 JOIN 表**：
      分组权限这块最危险的失败模式就是「宽 except 把逻辑错误吞成默认放行」
      （§14.39 踩过），所以字段怎么取也只走一个地方，两处口径必须一致。
    """
    if not user:
        return []
    import listen_admin
    gid = listen_admin.ug(user, "group_id", 0)
    try:
        gid = int(gid or 0)
    except (TypeError, ValueError):
        gid = 0
    return [gid] if gid else []
