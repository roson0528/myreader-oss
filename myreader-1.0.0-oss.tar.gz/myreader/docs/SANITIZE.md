# 开源脱敏说明

本仓库从一套真实在跑的系统整理而来，对外发布前做了**白名单式收集 + 全量脱敏**：只带代码，不带任何运行数据，也不带真实的基础设施信息。

## 一、带了什么、没带什么

**收录**：`book_manager/`（后端 + 前端 + 测试 + 运维小工具）、`ebook_task/`（书库扫描分类）、文档与启动脚本。

**不收录**（均在 `.gitignore` 或打包时排除）：

| 排除项 | 原因 |
| --- | --- |
| `data/`（数据库、缓存、封面、上传、备份、日志） | 真实业务数据 |
| `venv/`、`__pycache__/`、`*.bak-*` | 可再生成 / 历史备份 |
| `report/`（技术报告投放区） | 内部文档 |
| 内部技术报告、证书接入与运维手册类文档 | 含服务器与网络细节 |
| `static/*.apk`、`static/update/`、`static/internal/` | 客户端安装包（几十 MB 二进制） |
| 与本机 NAS 布局强绑定的备份脚本 | 部署专用 |
| TTS 试验脚本目录 | 非运行时依赖 |

## 二、脱敏规则表

| 类别 | 原始形态 | 替换为 |
| --- | --- | --- |
| 口令 | 真实存储口令 | `CHANGE_ME_STRONG_PASSWORD` / 空 + 环境变量 |
| 公网域名 | 真实主域与业务域名 | `example.com`、`reader.example.com`、`localhost` |
| 内网 IP | `192.168.<内网>/24` | `192.0.2.x`（RFC 5737 文档网段） |
| 组网 IP | `100.64.0.0/10` 段 | `198.51.100.x` |
| 账号 | 真实运维/站长账号名 | `bookadmin`、`admin` |
| 测试账号口令 | 真实测试口令 | `test` |
| 品牌 | 真实站点名与工作室名 | 「云阅读」「示例工作室」 |
| 安装包名 | 真实 APK 名 | `myreader.apk` |
| 服务器路径 | `/data/apps/<项目>/...`、`/home/<用户>/...` | `/srv/myreader/...` |
| 存储路径 | `/homes/<用户>PC/Ebook` | `/books` |
| 基础设施品牌 | 具体 NAS 品牌名 | 「NAS」 |
| 默认管理员 | 写死 | `BOOKMGR_ADMIN_USER/PASS` 环境变量 |

## 三、代码层面的改动（不只是替换字符串）

真实系统里这些值是写死的，开源版改成**可配置**，行为更规范：

| 文件 | 改动 |
| --- | --- |
| `config.py` | `FTP_* / WEBDAV_* / SFTP_*` 全部改为 `os.environ.get(...)`；`PUBLIC_SAMPLE_BOOK_ID` 改环境变量（默认 0，关闭游客试读） |
| `app.py` | `DEFAULT_LINK_BASE`、`DEFAULT_WELCOME_LINK` 改为环境变量（默认同源 / 空）；静态挂载目录缺失时自动创建，不带安装包目录也能起 |
| `report_sync.py` | 投放区目录、归属账号、书架分类改为环境变量 |
| `ebook_task/*.py` | 写死的服务器路径改为由 `__file__` 推导；连接信息改环境变量；`classify.py` 不再在 import 时硬读扫描结果 |
| `tests/*.py` | 写死的项目绝对路径改成由 `__file__` 推导，换个目录也能跑 |
| `start.sh` | 自动加载根目录 `.env`，端口/监听地址可覆盖 |
| `requirements.txt` | 从 `pip freeze` 全量清单精简为真实运行依赖 |

## 四、自己复核一遍

拿到包后可以这样确认没有残留：

```bash
# 1. 把下面换成本次实际替换过的模式（这里只示意写法，不带真实值）
grep -rIn -e "<真实内网网段>" -e "<真实域名>" -e "<真实账号名>" \
     -e "/data/apps/<项目路径>" --include="*.py" --include="*.js" --include="*.md" . \
  | grep -v "static/vendor/"

# 2. 语法自检
find . -name "*.py" -exec python3 -m py_compile {} \;
for f in $(find . -name "*.js" -not -path "*/vendor/*"); do node --check "$f"; done

# 3. 凭据自检：配置里的口令应全部来自环境变量
grep -rn "PASS\|SECRET\|TOKEN" book_manager/config.py
```

## 五、使用开源版时的注意

1. `.env.example` 里的默认口令只是占位，**上线必须改**。
2. 开源版默认不带任何书库数据；空库启动后需要接一个 WebDAV/FTP 后端，或用 `report_sync.py` 往投放区丢文档来上架。
3. 前端 `static/logo.png` 是脚本生成的占位图，换成自己的即可。

## 六、如果发现遗漏

脱敏是逐文件跑规则 + 人工复核的，仍可能漏掉某些间接信息（例如某段注释里的具体型号）。发现后欢迎提 issue 或 PR 修正。
