"""库内去重：修复"一书多分类 / 一书多份"（保守版）。
规则：
  1) 标题含卷册/系列标记（第N册、卷一、（上）、套装共N册、卷三十二…）的书【绝不合并】；
  2) 标题含期刊期号（第N期、总第N期）的书【绝不合并】——不同期不是重复；
  3) 其余书按"核心书名(剥括号注释/书名号) + 作者兼容"分组，每组只保留一本
     （优先有真实作者 > 体积大 > id小），删除其余副本的行 + NAS 文件。

★ 2026-10-03 修复（原版会误删分册，务必保留这两个修复）：
   原 `author_compat()` 把「作者不是干净短名」等同于「与任何书都兼容」：
       if not author_ok(a) or not author_ok(b): return True
   而 `author_ok()` 只认 `len<=12 且不含源站词`，于是长描述串一律被判兼容。
   后果：《古今图书集成》429 个**不同分册**（区分信息写在 author 里，
   如「陈梦雷-博物汇编神异典二氏部汇考」「…医部全录卷047至…」，title 全是
   「古今图书集成」）被合并成 1 本，一次删掉 428 册。
   现在区分「源站垃圾」与「长但真实的作者」：只有垃圾才放弃作者作为身份依据，
   真实的（哪怕很长的）作者必须相同或互相包含。另新增期刊期号排除
   （《文史知识》36 期月刊也曾被当成重复）。
用法：python3 dedup_library.py            # 干跑，只统计+样例
      python3 dedup_library.py --apply    # 真正删除
"""
import sys, os, re, time, threading
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config, db, ftp_service
from concurrent.futures import ThreadPoolExecutor

VOL_PATTERNS = [
    r"第\s*[0-9一二三四五六七八九十百千]+\s*[册卷部集辑篇章节回]",     # 第1册/第一卷/第3部/第7回
    r"[（(【\[]\s*卷\s*[0-9一二三四五六七八九十百千]+",              # （卷一）（卷三十二）
    r"[（(【\[]\s*[0-9一二三四五六七八九十百千]+\s*[册卷部]",        # （第135册）/(2册)/(三卷)
    r"[（(【\[]\s*[上下中左右]+\s*[）)】\]]",                        # （上）（上中下）
    r"[（(【\[]\s*[0-9一二三四五六七八九十百千]+\s*[）)】\]]",        # （六）（二十四）
    r"[0-9一二三四五六七八九十百千]+\s*卷",                          # 17卷/十二卷
    r"卷\s*[0-9一二三四五六七八九十百千]+",                          # 卷三十二至三十四
    r"套装(共)?\s*[0-9一二三四五六七八九十百千]+\s*册",              # 套装共10册
    r"[（(【\[]\s*(全|共)\s*[0-9一二三四五六七八九十百千]+\s*[册卷部]",  # （全2册）
]
VOL_RE = re.compile("|".join(VOL_PATTERNS))
# 期刊期号：不同期是不同出版物，不是重复
SERIAL_RE = re.compile(r"第\s*[0-9一二三四五六七八九十百千]+\s*期|总第\s*[0-9]+\s*期")
FORMAT_RE = re.compile(
    r"[（(【\[]\s*(绘本|漫画|连环画|图文本|青少|青少年|少年版|拼音|注音|少儿|儿童|学生|大字|精简|缩写|节选|无障碍|彩图|插图本)[）)】\]]")
SRC_TAGS = ("我的小书屋下载", "小书屋", "书包网", "百度网盘", "网盘", "txt下载", "迅雷下载", "迅雷")
# 作者字段里的「源站垃圾/非作者信息」标记——只有命中这些才放弃把作者当身份依据
AUTHOR_JUNK = ("下载", "书屋", "书包", "网盘", "迅雷", "com", "www", "txt", "扫描", "整理", "未知", "佚名")
_PUNCT = re.compile(r"[\W_]+", flags=re.UNICODE)
_BRACKET = re.compile(r"[（(【\[].*?[）)】\]]")


def has_volume(title):
    return bool(VOL_RE.search(title or ""))


def is_serial(title):
    """期刊/连载：第N期、总第N期 —— 绝不参与合并"""
    return bool(SERIAL_RE.search(title or ""))


def is_format(title):
    return bool(FORMAT_RE.search(title or ""))


def core_title(title):
    """核心书名：仅『[书名].作者.格式』(括号后带点)取括号内为标题；否则剥括号注释/书名号/来源标记/作者后缀，去标点"""
    if not title:
        return ""
    s = title.lower()
    s = s.replace("《", "").replace("》", "")
    m = re.match(r"^\s*[\[【]\s*([^\]】]{2,40})[\]】]\s*\.", s)
    if m:
        s = m.group(1)                    # [鹿鼎記].金庸.繁體 → 鹿鼎記（【精品汇】等标签不带点，不命中）
    s = _BRACKET.sub("", s)
    for tag in SRC_TAGS:
        s = s.replace(tag, "")
    s = re.sub(r"作者.{0,10}$", "", s)    # 《三重门》作者：韩寒 → 三重门
    return _PUNCT.sub("", s)


def author_ok(a):
    """作者字段是否像一个可信的干净短名。**仅用于挑选保留哪一本**，不用于判定同一本书"""
    a = (a or "").strip().lower()
    if not a:
        return False
    return len(a) <= 12 and not any(k in a for k in AUTHOR_JUNK)


def author_junk(a):
    """作者字段是源站垃圾/非作者信息（或为空）→ 不能用来区分书籍身份"""
    a = (a or "").strip().lower()
    if not a:
        return True
    return any(k in a for k in AUTHOR_JUNK)


_AUTHOR_BRACKET = re.compile(r"[（(【\[].*?[）)】\]]")
_AUTHOR_TAIL = re.compile(r"(著|译|编著|主编|编|等|著译)+$")


def norm_author(a):
    """作者名归一化：去括号补充、去尾部『著/译/编/等』、去标点。
    用于判定两个作者是否**是同一个名字**。"""
    a = (a or "").strip().lower()
    a = _AUTHOR_BRACKET.sub("", a)
    a = _AUTHOR_TAIL.sub("", a)
    return _PUNCT.sub("", a)


def author_compat(a, b):
    """两侧作者是否可视为同一本书。

    一侧为空、或一侧是源站垃圾 → 无法区分，视为兼容（保住「无作者」与
    「有作者」之间那些合理的合并，例如《巴黎圣母院》空作者 ↔ 雨果）。
    否则两侧都是**真实作者**（哪怕名字很长、含括号外文名），**必须归一化后完全相同**。

    ★ 修复一：旧版 `not author_ok(a) or not author_ok(b) → True` 把「作者不干净」
    等同于「兼容一切」，而 `author_ok` 只认「≤12 字且不含源站词」，于是
    「陈梦雷-博物汇编神异典二氏部汇考」这类**分册描述串**被判兼容，
    《古今图书集成》429 个不同分册被合并成 1 本（详见模块 docstring）。

    ★ 修复二：旧版用 `a in b or b in a` 子串匹配，会把**不同作品**当成同一本：
    「怪物」⊂「移魂怪物」、「探险」⊂「继续探险」都是倪匡两个不同的故事。
    删除不可逆，因此这里宁严勿宽——归一化后必须完全相等。
    代价是「雨果」与「维克多·雨果」不再合并（少删几本重复），
    这比删掉一本不同的书安全得多。
    """
    a, b = (a or "").strip().lower(), (b or "").strip().lower()
    if not a or not b:
        return True
    if author_junk(a) or author_junk(b):
        return True
    na, nb = norm_author(a), norm_author(b)
    if not na or not nb:
        return True
    return na == nb


def _keep_best(group):
    def score(b):
        return (1 if author_ok(b["author"]) else 0, b["size"] or 0, -b["id"])
    return max(group, key=score)


def main():
    apply = "--apply" in sys.argv
    rows = db.q("SELECT id, path, title, author, category, size FROM books")
    print("库总数:", len(rows))

    vol_cnt = sum(1 for r in rows if has_volume(r["title"]) or is_format(r["title"]))
    ser_cnt = sum(1 for r in rows if is_serial(r["title"]))
    print("含卷册/格式标记(不参与去重):", vol_cnt)
    print("含期刊期号(不参与去重)    :", ser_cnt)

    groups = {}
    for r in rows:
        if has_volume(r["title"]) or is_format(r["title"]) or is_serial(r["title"]):
            continue
        c = core_title(r["title"])
        if len(c) >= 2:
            groups.setdefault(c, []).append(r)

    merged, to_delete, stats = {}, [], {"组数": 0, "保留": 0, "删除": 0, "跨分类组": 0}
    for c, grp in groups.items():
        if len(grp) < 2:
            continue
        # 作者兼容分组：真实作者不同则拆开
        clusters = []
        for r in sorted(grp, key=lambda x: x["id"]):
            placed = False
            for cl in clusters:
                if author_compat(cl[0]["author"], r["author"]):
                    cl.append(r)
                    placed = True
                    break
            if not placed:
                clusters.append([r])
        for cl in clusters:
            if len(cl) < 2:
                continue
            keep = _keep_best(cl)
            cats = {r["category"] for r in cl}
            stats["组数"] += 1
            stats["保留"] += 1
            if len(cats) > 1:
                stats["跨分类组"] += 1
            for r in cl:
                if r["id"] != keep["id"]:
                    stats["删除"] += 1
                    to_delete.append(r)
            merged.setdefault(c, []).append((keep, len(cl)))

    print("=== 去重统计(%s) ===" % ("执行" if apply else "干跑"))
    print("重复组:", stats["组数"], "| 保留:", stats["保留"], "| 删除:", stats["删除"], "| 其中跨分类组:", stats["跨分类组"])
    if not apply:
        for c, kps in sorted(merged.items(), key=lambda kv: -sum(k for _, k in kv[1]))[:6]:
            keep, n = kps[0]
            print("  样例:", c, "| 合并%d本 → 保留[%s] %s" % (sum(k for _, k in kps), keep["category"], keep["title"][:30]))
        print("（未实际删除，加 --apply 执行）")
        return

    # ── 执行 ──────────────────────────────────────────────────────────────
    # 默认：把 NAS 文件**移入隔离区**（同盘 rename，可回滚），再删库行。
    # 只有显式 --hard 才真正删除文件——39 GB 不可逆操作不该一次做绝。
    hard = "--hard" in sys.argv
    trash_root = "_dedup_trash/%s" % time.strftime("%Y%m%d-%H%M%S")
    failed = []
    lock = threading.Lock()

    def do_file(r):
        path = r["path"]
        if not path:
            return 0
        try:
            if hard:
                ok = ftp_service.delete(path)
            else:
                dst = "%s/%s" % (trash_root, path)
                ftp_service.makedirs(dst.rsplit("/", 1)[0])
                ok = ftp_service.rename(path, dst)
            if not ok:
                with lock:
                    failed.append((path, "返回 False"))
                return 0
            return 1
        except Exception as e:
            with lock:
                failed.append((path, str(e)[:60]))
            return 0

    ids = [r["id"] for r in to_delete]
    with ThreadPoolExecutor(max_workers=12) as ex:
        res = list(ex.map(do_file, to_delete))
    moved = sum(res)
    if hard:
        print("删除 NAS 文件:", moved, "| 失败(可能已不存在):", len(ids) - moved)
    else:
        print("移入隔离区  :", moved, "| 失败:", len(failed), "| 隔离区:", trash_root)
        for p, e in failed[:5]:
            print("   失败:", p[:70], "|", e)

    for i in range(0, len(ids), 2000):
        chunk = ids[i:i + 2000]
        ph = ",".join("?" * len(chunk))
        c = db.get_conn()
        c.execute("DELETE FROM books WHERE id IN (%s)" % ph, chunk)
        for t in ("shelves", "progress", "shares", "book_grants"):
            try:
                c.execute("DELETE FROM %s WHERE book_id IN (%s)" % (t, ph), chunk)
            except Exception:
                pass
        c.commit()
    print("删除库行    :", len(ids))
    print("库总数      :", db.q("SELECT COUNT(*) c FROM books", one=True)["c"])
    if not hard:
        print()
        print("文件已移入隔离区 %s（确认无误后彻底清空）：" % trash_root)
        print("    venv/bin/python dedup_library.py --purge-trash %s" % trash_root)


def purge_trash(relpath):
    """彻底删除隔离区目录（rmtree 对 WebDAV 是递归 DELETE）"""
    print("正在删除隔离区:", relpath)
    ok = ftp_service.rmtree(relpath)
    print("rmtree 返回:", ok)


if __name__ == "__main__":
    if "--purge-trash" in sys.argv:
        i = sys.argv.index("--purge-trash")
        if i + 1 >= len(sys.argv):
            print("用法: dedup_library.py --purge-trash _dedup_trash/<时间戳>")
            sys.exit(1)
        purge_trash(sys.argv[i + 1])
    else:
        main()
