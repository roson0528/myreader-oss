"""断句、引号切分、逐句合成与断点缓存。

三个设计决定，都是为了「整本书能跑完」这件事：

1) **断句与「旁白/对白」切分放在 Python 里确定性做**，不交给 AI。
   实测 AI 会把「老陈把茶碗往桌上一顿，说：“这事我不答应。”」整行标成同一个
   说话人 —— 而它其实是旁白 + 对白两段。让 AI 判「谁在说」就够了，
   「哪一段是引号内」是正则就能做准的事，不该花 token 也不该赌模型。

2) **每一句合成完立刻落盘并记进 ab_seg**。这是断点续传的最小粒度：
   服务重启、暂停、取消之后接着跑，已合成的句子不会重合成
   （TTS 单句 2~6 秒，一本书几千句，重跑一遍是几小时的差别）。

3) **按句合成而不是按章合成**：TTS 主机单次请求有长度上限，
   而且整章一次请求失败就要整章重来。
"""
import os
import re
import sys
import unicodedata

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE)

# 单次请求送给 TTS 的最大字数。TTSS 主机对超长文本会拒或截断，
# 这里保守取 100 字；超长句在逗号/顿号处再切一刀。
MAX_CHARS = 100

# 句末标点。省略号单独列出来是因为「……」后面很少再有标点。
_END = "。！？!?…"
# 引号对：中文直角引号、双引号、单引号、书名号里的对话也常见
_QUOTE_PAIRS = [("「", "」"), ("『", "』"), ("“", "”"), ("‘", "’"), ('"', '"'), ("'", "'")]
# 只认这几个「不可能是开引号」的收尾引号做并句。
# 直引号 " 和 ' 既可能是开也可能是闭，拿来并句会把下一句开头是引号的情况误并。
_CLOSERS = "”』」’"


def split_sentences(text):
    """把一段正文切成句子。保留段落边界造成的换行。"""
    out = []
    for para in (text or "").split("\n"):
        para = para.strip()
        if not para:
            continue
        buf = []
        for ch in para:
            buf.append(ch)
            if ch in _END:
                # 句末标点后面的收尾引号/括号要跟着这一句走
                pass
                s = "".join(buf).strip()
                if s:
                    out.append(s)
                buf = []
        tail = "".join(buf).strip()
        if tail:
            # 段落末尾没有句末标点（标题、诗句）也算一句
            out.append(tail)
    # 「……说：“……。”」这种，右引号被句号切到了下一句开头，要并回上一句。
    # ★ 不能要求 `len(s) > 1`：只剩一个右引号时（s == "”"）同样要并，
    #   否则会多出一句只有一个引号的「句子」——实测出现过，还被 AI 当成了一句台词。
    merged = []
    for s in out:
        if merged and s and s[0] in _CLOSERS:
            merged[-1] += s[0]
            s = s[1:].strip()
            if not s:
                continue
        merged.append(s)
    return _cap(merged)


def _cap(sents):
    """超长句在次级标点处再切，避免单次 TTS 请求过长。

    还要兜住「整句一个标点都没有」的情况（长串数字、无标点的意识流段落）：
    标点切完仍然超长的，按字数硬切。否则会把 1000 字的请求丢给 TTS 主机，
    要么被拒要么被截断，而截断是静默丢内容 —— 有声书里就是「漏读了一段」。
    """
    out = []
    for s in sents:
        if len(s) <= MAX_CHARS:
            out.append(s)
            continue
        parts, buf = [], ""
        for piece in re.split(r"(?<=[，,、；;：:])", s):
            if len(buf) + len(piece) > MAX_CHARS and buf:
                parts.append(buf)
                buf = piece
            else:
                buf += piece
        if buf:
            parts.append(buf)
        for p in (x.strip() for x in parts):
            if not p:
                continue
            while len(p) > MAX_CHARS:
                out.append(p[:MAX_CHARS])
                p = p[MAX_CHARS:]
            if p:
                out.append(p)
    return out


def split_spans(sentence):
    """把一句切成 [(kind, text)]，kind ∈ {'narration','dialog'}。

    只有引号**内**的内容算对白。嵌套引号按最外层配对，内层不单独切
    （小说里「他说：“……”」这种，内层双引号整体属于对白）。
    """
    spans = []
    i, n = 0, len(sentence)
    cur = ""
    while i < n:
        ch = sentence[i]
        pair = next((p for p in _QUOTE_PAIRS if p[0] == ch), None)
        if not pair:
            cur += ch
            i += 1
            continue
        open_c, close_c = pair
        if cur.strip():
            spans.append(("narration", cur.strip()))
        cur = ""
        j = i + 1
        depth = 1
        inner = ""
        while j < n:
            if sentence[j] == open_c and open_c != close_c:
                depth += 1
            elif sentence[j] == close_c:
                depth -= 1
                if depth == 0:
                    break
            inner += sentence[j]
            j += 1
        if inner.strip():
            spans.append(("dialog", inner.strip()))
        i = j + 1 if j < n else n
        # 引号后面紧跟的收尾标点（“……”说。）算旁白
    if cur.strip():
        spans.append(("narration", cur.strip()))
    if not spans:
        spans = [("narration", sentence.strip())]
    return [(k, t) for k, t in spans if t]


def voice_of(spans, speaker_map, narrator):
    """给一句里的每一段选音色。speaker_map: {角色名: 音色id}。"""
    out = []
    for kind, t in spans:
        if kind == "narration":
            out.append((narrator, "", t))
        else:
            name = _match_speaker(t, speaker_map)
            out.append((speaker_map.get(name) or narrator, name, t))
    return out


def _match_speaker(dialog, speaker_map):
    """AI 只给了「谁说的」，这里按对话内容回查角色名。

    实际的归属是逐句做的（见 ai.analyze_chapter 输出 idx→speaker），
    speaker_map 的键就是角色名，调用方按句子下标直接取；这个函数只是兜底。
    """
    for name in speaker_map:
        if name and name in dialog:
            return name
    return ""


# 各家线路返回的都是 opus（Ogg 封装）。这里只做**便宜的**前置判断：
# 空、太短、不是已知的音频容器，就直接当成坏数据。真正的解码校验由 worker
# 里紧接着的 ffmpeg 转换承担 —— 那一步失败同样会整句重来。
_AUDIO_MAGIC = (b"OggS", b"ID3", b"RIFF", b"fLaC",
                b"\xff\xfb", b"\xff\xf3", b"\xff\xf2", b"\xff\xfa")


def ok_audio(b):
    """这段字节看起来是不是一段能解码的音频。

    ★ 起因：线路偶发返回 0 字节，代码不校验就落盘，ffmpeg 打开即 EOF，
      整个任务在跑到一半时失败（实测《妖楼》第 2 个文件第 56 句）；
      更糟的是坏字节一旦进缓存，重跑永远复用那份坏文件。
    """
    if not b or len(b) < 512:
        return False
    return any(bytes(b[:len(m)]) == m for m in _AUDIO_MAGIC)


# 文本净化（safe_text / _gbk_safe / _TTS_CHAR_MAP）已上移到 **tts.py**。
# ★ 原因：那段逻辑是「线路怎么编码」的知识，而且在线听书不经过本模块 ——
#   只放在这里的话，在线听书那条路就完全没有净化。现在由 tts._call_one 统一兜底。
#   这里保留同名入口，既有的调用方与回归测试不用改。
def safe_text(text):
    """把线路编不出来的字符折成发音等价的写法（实现在 tts.safe_text）。"""
    import tts
    return tts.safe_text(text)


def synth(text, voice, line, cfg=None):
    """合成一句，返回 (opus_bytes, 实际线路)。失败向上抛，由 worker 决定重试。

    这里刻意**不走 tts 的 SynthQueue**：那个队列是给在线听书用的，
    优先级、并发都是按「用户正在等」调的；批量制作走它会把在线听书挤慢。
    批量任务是后台作业，慢一点没关系，不能影响听书。
    """
    import tts
    cfg = cfg or tts.settings()
    text = safe_text(text)
    if not text.strip():
        raise RuntimeError("这一句没有可合成的文本（全是线路不支持的字符）")
    audio, _gen, used = tts.call_tts(text, voice=voice, cfg=cfg, line=line or None)
    return audio, used


def seg_path(tmpdir, idx, seq=0):
    """分句的 opus 中间文件路径。

    ★ 文件名必须带**文件序号** seq。只按句序号命名的话，第 2 个文件的第 0 句
      和第 3 个文件的第 0 句会写到同一个文件上，互相覆盖 —— 实测重跑文件 1
      时把文件 3 已合成好的缓存整片覆盖掉了。seq=0 保留老命名（兼容旧记录）。
    """
    d = os.path.join(tmpdir, "opus")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "%06d.opus" % idx if not seq else "f%03d_%06d.opus" % (seq, idx))


def seg_mp3_path(tmpdir, idx, seq=0):
    d = os.path.join(tmpdir, "mp3")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "%06d.mp3" % idx if not seq else "f%03d_%06d.mp3" % (seq, idx))
