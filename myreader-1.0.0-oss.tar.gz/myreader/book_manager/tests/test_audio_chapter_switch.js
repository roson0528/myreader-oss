// 「有声」切章错位的回归（不需要真机）。
//
// 线上现象（用户报）：在播放页点第 5 章，**播放器/文字却停在第 2 章**，
// 文字内容与声音不同步 —— 也就是「点这章放/显示那章」。
//
// 真因（已复现）：APP 内的原生播放要把**整本**直链清单一次性交给前台服务。
// 取完整本票据是异步的（长书上百章，串行时十几秒），这段时间里原生**还在放旧章**
// 并照常回报 index=旧章，而旧的 auOnNativeState() 会照着这个回报把
// AUP.chap 改回旧章。于是：
//     startMp3.index = 4（第 5 章，音频是对的）
//     AUP.chap      = 2（第 2 章，界面/文字/进度/落库全错）
// 修法：① auNativePlay 在取票据**之前**钉住用户点的那一章；
//       ② 发出切章后设 switchTo，原生报回旧章期间一律丢弃该帧（15 秒兜底）；
//       ③ 票据改并发取，别让用户等十几秒。
//
// 本脚本只读服务端数据，不写任何库表。
const { chromium } = require('playwright-core');
const { execSync } = require('child_process');
const CHROME = '/srv/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome';
const ROOT = '/srv/myreader/book_manager';

let pass = 0, fail = 0;
const ck = (n, ok, extra) => {
  if (ok) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (extra ? '  → ' + extra : '')); }
};
const py = (code) => execSync('venv/bin/python -', { cwd: ROOT, encoding: 'utf8', input: code }).trim();

// 原生服务「正在放第 2 章」：index=1
const BRIDGE = `
window.__nativeCalls = [];
(function () {
  const rec = (name) => function (arg) {
    window.__nativeCalls.push({ name: name, arg: arg || null });
    if (name === 'status') return Promise.resolve({ version: 5, btLink: true, active: true,
      playing: true, mode: 'mp3', index: 1, total: 186, chapter: '旧章',
      positionMs: 30000, durationMs: 60000, bookId: 0 });
    return Promise.resolve({ ok: true });
  };
  const plug = {};
  ['status','startMp3','seek','play','pause','next','prev','gotoIndex','setVoice','setRate','stop'].forEach(k => { plug[k] = rec(k); });
  window.Capacitor = { Plugins: { ListenService: plug } };
})();
`;

(async () => {
  const info = JSON.parse(py(`
import sys, json
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
import db, auth
u = db.q("SELECT * FROM users WHERE role='admin' AND enabled=1 ORDER BY id LIMIT 1", one=True)
db.ex("DELETE FROM ab_session WHERE user_id=?", (u["id"],))   # 清掉上一轮测试遗留的有声单端锁
lib = db.q("SELECT id,title FROM ab_lib WHERE hidden=0 AND total_chapters>6 ORDER BY total_chapters DESC LIMIT 1", one=True)
print(json.dumps({"token": auth.create_token(u), "lib": dict(lib)}))
`));
  const LIB = info.lib.id;
  const browser = await chromium.launch({ executablePath: CHROME, args: ['--no-sandbox'] });
  const ctx = await browser.newContext({ ignoreHTTPSErrors: true, viewport: { width: 420, height: 900 } });
  await ctx.addInitScript(tk => { localStorage.setItem('bm_token', tk); localStorage.setItem('bm_user', '{"id":1,"role":"admin"}'); try { sessionStorage.setItem('bm_audio_sid', 'fixchapterswitch'); } catch (e) {} }, info.token);
  await ctx.addInitScript(BRIDGE);
  const page = await ctx.newPage();
  const errs = [];
  page.on('pageerror', e => errs.push(String(e)));
  await page.goto('https://127.0.0.1:9000/', { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(2000);

  const d = await page.evaluate(id => api('/api/audiobooks/' + id), LIB);
  const chs = (d.chapters || []).slice().sort((a, b) => a.seq - b.seq);
  const from = chs[1], to = chs[4];                 // 第 2 章 → 第 5 章
  const wantIdx = chs.findIndex(c => c.seq === to.seq);
  console.log('  用《' + info.lib.title + '》第 ' + from.seq + ' 章 → 第 ' + to.seq + ' 章（期望 index=' + wantIdx + '）');

  // 模拟真机：票据要一张张发请求，慢
  await page.evaluate(() => {
    const real = window.api;
    window.api = function (u, opt) {
      if (String(u).indexOf('/ticket') >= 0) return new Promise(r => setTimeout(() => r(real(u, opt)), 25));
      return real(u, opt);
    };
  });

  // ---------------------------------------------------- A. 切章途中，旧章状态不能改写目标
  await page.evaluate(([id, c]) => { window.__nativeCalls = []; audioPlay(id, c, false); }, [LIB, to.seq]);
  // ★ 必须等原生会话真的建立（AUP.native）：整本取票是异步的，这本书章数最多，
  //   本脚本还故意把 ticket 拖慢 25ms/张，十几二十秒才置真。以前只等 10 秒，
  //   于是 auOnNativeState 因为 AUP.native 还是 false 直接 return，
  //   后面两条断言必然假红（nativePos=0）。
  let nativeOn = false;
  for (let i = 0; i < 90; i++) {
    await page.waitForTimeout(1000);
    nativeOn = await page.evaluate(() => !!(AUP && AUP.native));
    if (nativeOn) break;
  }
  ck('原生会话已建立（AUP.native）', nativeOn);
  let reverted = false;
  for (let i = 0; i < 40; i++) {
    await page.waitForTimeout(250);
    await page.evaluate(() => {
      window.__laoshuPlayerState({ version: 5, mode: 'mp3', active: true, playing: true,
        index: 1, total: 186, chapter: '旧章', positionMs: 31000, durationMs: 60000, bookId: 0 });
    });
    const now = await page.evaluate(() => AUP && AUP.chap);
    if (now === from.seq) reverted = true;
  }
  const after = await page.evaluate(() => {
    const sm = window.__nativeCalls.filter(c => c.name === 'startMp3').pop();
    return { index: sm ? sm.arg.index : null,
             title: sm ? (sm.arg.titles || [])[sm.arg.index] : '',
             chap: AUP && AUP.chap, chapStart: AUP && AUP.chapStart };
  });

  console.log('');
  ck('★ 点了第 ' + to.seq + ' 章，交给原生的 index 就是它（不是旧章）',
     after.index === wantIdx, '实际 index=' + after.index);
  ck('★ 章节名也对得上', after.title === (to.title || ('第 ' + to.seq + ' 章')), after.title);
  ck('★ 切章途中，旧章节的状态回报没能把 AUP.chap 拽回去',
     !reverted && after.chap === to.seq, 'AUP.chap=' + after.chap + ' 期间被拽回过=' + reverted);
  ck('★ 章起点跟着目标章走（文字高亮/进度都按它算）',
     Math.abs((after.chapStart || 0) - (to.start_sec || 0)) < 0.01,
     'chapStart=' + after.chapStart + ' 期望=' + to.start_sec);

  // ---------------------------------------------------- B. 原生真的切到位后，必须恢复跟随
  await page.evaluate(([seq]) => {
    window.__laoshuPlayerState({ version: 5, mode: 'mp3', active: true, playing: true,
      index: seq, total: 186, chapter: '新章', positionMs: 5000, durationMs: 60000, bookId: 0 });
  }, [wantIdx]);
  const follow = await page.evaluate(() => ({ switchTo: AUP.switchTo, pos: AUP.nativePos, idx: AUP.idx }));
  ck('★ 原生切到位后解除拦截（否则后面永远不会再同步）', !follow.switchTo, 'switchTo=' + follow.switchTo);
  ck('★ 切到位后位置正常跟进', follow.pos === 5000, 'nativePos=' + follow.pos);

  // ---------------------------------------------------- C. 并发取票：长书点章不该卡十几秒
  // ★ 先清掉当前会话再量。同书同章再调一次 audioPlay 现在等于「回到播放页、接着放」，
  //   本来就**不该**再发 startMp3 了（见 §14.72 与 test_audio_native_resume.js），
  //   拿它来量取票耗时永远等不到 startMp3、必然耗满 20 秒。
  //   这一段要量的是「全新开始一章」的取票耗时，所以先置空会话。
  const ms = await page.evaluate(async ([id, seq]) => {
    AUP = null;
    const t0 = Date.now();
    await audioPlay(id, seq, false);
    // 等到 startMp3 真的发出为止（最多 20 秒）
    for (let i = 0; i < 200; i++) {
      if (window.__nativeCalls.filter(c => c.name === 'startMp3').length >= 1) break;
      await new Promise(r => setTimeout(r, 100));
    }
    return Date.now() - t0;
  }, [LIB, to.seq]);
  const nChap = chs.length;
  ck('★ 整本 ' + nChap + ' 章取票耗时 ' + (ms / 1000).toFixed(1) + 's（串行会 >' +
     (nChap * 25 / 1000).toFixed(0) + 's）', ms < nChap * 25 * 0.7,
     ms + 'ms');

  ck('过程中页面无 JS 报错', errs.length === 0, errs.slice(0, 2).join(' | '));
  // ★ 收尾：把自己留下的有声单端锁清掉。
  //   不清的话它会活 40 秒租约，紧接着打开 APP 会误报「正在另一台设备上收听」。
  try {
    py(`import sys; sys.path.insert(0, '${ROOT}')
import db
db.ex("DELETE FROM ab_session WHERE user_id=?", (1,))`);
  } catch (e) {}


  await browser.close();
  console.log('');
  console.log('有声切章：' + pass + ' 通过 / ' + fail + ' 失败');
  process.exit(fail ? 1 : 0);
})();
