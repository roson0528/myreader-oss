// 两件事（都是「我的」/ 书库导航体验）：
//
// 1) 搜索结果配固定链接（#/search/关键字）。
//    原来 search() 只改内存里的 curQ、不动 hash，从结果点进详情再返回时
//    全靠全局状态碰运气：同一会话内凑合能用，一刷新或走 bfcache 回来就没了。
//    现在 closeDetail() 的 lastHash 指向 #/search/...，返回能精确回到那次搜索，
//    链接也能直接分享/收藏。
//
// 2) 「我的」页里「我的文章」卡片下面加「书库分类」：文本链接形式，
//    显示分类名与书籍数量，点一下进该分类。
const { chromium } = require('playwright-core');
const { execSync } = require('child_process');
const CHROME = '/srv/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome';
const ROOT = '/srv/myreader/book_manager';
const BASE = 'https://127.0.0.1:9000';

let pass = 0, fail = 0;
const ck = (n, ok, extra) => {
  if (ok) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (extra ? '  → ' + extra : '')); }
};
const py = (c) => execSync('venv/bin/python -', { cwd: ROOT, encoding: 'utf8', input: c }).trim();

(async () => {
  const info = JSON.parse(py(`
import sys, json
sys.path.insert(0, '${ROOT}')
import db, auth
u = db.q("SELECT * FROM users WHERE username='test' AND enabled=1", one=True)
print(json.dumps({"tok": auth.create_token(u), "user": dict(u)}))`));
  const KW = '三体';

  const b = await chromium.launch({ executablePath: CHROME, args: ['--no-sandbox'] });
  const ctx = await b.newContext({ ignoreHTTPSErrors: true, viewport: { width: 1280, height: 950 } });
  await ctx.addInitScript(([t, u]) => {
    localStorage.setItem('bm_token', t); localStorage.setItem('bm_user', u);
  }, [info.tok, JSON.stringify(info.user)]);
  const page = await ctx.newPage();
  const errs = [];
  page.on('pageerror', e => errs.push(String(e).slice(0, 90)));
  await page.goto(BASE + '/', { waitUntil: 'domcontentloaded' });
  await page.waitForFunction(() => typeof search === 'function', null, { timeout: 20000 });
  await page.waitForTimeout(1500);

  // ---------------------------------------------------------- 搜索固定链接
  await page.fill('#search-q', KW);
  await page.press('#search-q', 'Enter');
  await page.waitForTimeout(1800);
  const want = '#/search/' + encodeURIComponent(KW);
  ck('★ 搜索后地址栏变成固定链接', await page.evaluate(() => location.hash) === want,
     await page.evaluate(() => location.hash));
  const n1 = await page.evaluate(() => document.querySelectorAll('#book-grid .book-card').length);
  ck('搜索结果有内容', n1 > 0, n1 + ' 张卡');

  await page.evaluate(() => document.querySelector('#book-grid .book-card').click());
  await page.waitForTimeout(1500);
  ck('点书进入详情页', await page.evaluate(() => /^#\/book\/\d+$/.test(location.hash)),
     await page.evaluate(() => location.hash));

  await page.evaluate(() => closeDetail());
  await page.waitForTimeout(1800);
  ck('★ 返回后仍停在搜索固定链接', await page.evaluate(() => location.hash) === want,
     await page.evaluate(() => location.hash));
  ck('★ 返回后搜索结果原样还在',
     await page.evaluate(() => document.querySelectorAll('#book-grid .book-card').length) === n1);
  ck('★ 返回后搜索框里关键字还在',
     await page.evaluate(() => document.getElementById('search-q').value) === KW);

  // 直接打开固定链接（等价于分享给别人 / 刷新）
  await page.goto(BASE + '/' + want, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction(() => typeof search === 'function', null, { timeout: 20000 });
  await page.waitForTimeout(2000);
  const n4 = await page.evaluate(() => document.querySelectorAll('#book-grid .book-card').length);
  const q4 = await page.evaluate(() => document.getElementById('search-q').value);
  ck('★ 直接打开固定链接就能复现同一次搜索', n4 === n1 && q4 === KW,
     `${n4} 张卡（预期 ${n1}），关键字 ${JSON.stringify(q4)}`);

  await page.evaluate(() => clearSearch());
  await page.waitForTimeout(1500);
  ck('清空搜索回到首页', await page.evaluate(() => location.hash) === '#/library',
     await page.evaluate(() => location.hash));

  // ---------------------------------------------------------- 我的 → 书库分类
  await page.evaluate(() => switchPage('me'));
  await page.waitForTimeout(1500);
  const me = await page.evaluate(() => {
    const arts = document.getElementById('me-articles-card');
    const cats = document.getElementById('me-cats-card');
    const links = Array.from(document.querySelectorAll('#me-cats-list .me-cat-link'));
    const order = (arts && cats)
      ? ((arts.compareDocumentPosition(cats) & Node.DOCUMENT_POSITION_FOLLOWING) ? 'after' : 'before')
      : 'n/a';
    return { exists: !!cats, order, n: links.length, h: cats ? cats.offsetHeight : 0,
             first: links.slice(0, 3).map(a => a.textContent.trim()) };
  });
  ck('★ 「我的」页里有「书库分类」卡片', me.exists);
  ck('★ 位置就在「我的文章」卡片下面', me.order === 'after', me.order);
  ck('★ 是文本链接且带书籍数量', me.n > 0 && /\d/.test(me.first.join('')), JSON.stringify(me.first));
  ck('卡片可见（不是空壳）', me.h > 0, '高 ' + me.h);

  const picked = await page.evaluate(() => {
    const a = document.querySelectorAll('#me-cats-list .me-cat-link')[1];
    const t = a ? a.textContent.trim() : ''; if (a) a.click(); return t;
  });
  await page.waitForTimeout(2000);
  const cat = await page.evaluate(() => ({
    hash: location.hash,
    cards: document.querySelectorAll('#book-grid .book-card').length }));
  ck('★ 点分类链接能进到该分类', /^#\/category\//.test(cat.hash), `${picked} → ${cat.hash}`);
  ck('分类页面有书', cat.cards > 0, cat.cards + ' 张卡');

  ck('页面没有 JS 报错', errs.length === 0, errs[0] || '');
  await b.close();
  console.log(`\n搜索固定链接 + 书库分类：${pass} 通过 / ${fail} 失败`);
  process.exit(fail ? 1 : 0);
})();
